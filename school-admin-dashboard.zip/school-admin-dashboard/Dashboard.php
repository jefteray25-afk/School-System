<?php
require __DIR__ . '/includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/includes/admin-nav.php';
include 'config/database.php';
require_once __DIR__ . '/modules/students/student-registration-helper.php';
require_once __DIR__ . '/modules/settings/school-year-helper.php';
require_once __DIR__ . '/modules/settings/backup-settings-helper.php';
require_once __DIR__ . '/modules/settings/settings-permissions-roles.php';
require_once __DIR__ . '/modules/invoice/receipt-turnover-bulletin-helper.php';

registration_ensure_pending_table($conn);
$pendingRegistrationCount = $conn->query("SELECT COUNT(*) AS count FROM student_registration_pending WHERE status = 'Pending'")->fetch_assoc()['count'] ?? 0;
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
$activeSchoolYear = school_year_get_active($conn);
$activeSchoolYearLabel = $activeSchoolYear['label'] ?? school_year_default_label();
$enrollmentOpen = (int) ($activeSchoolYear['enrollment_open'] ?? 0) === 1;
$currentYearStudentCount = 0;
$currentYearPendingCount = 0;
$currentYearStudentsMissingLrn = 0;
$currentYearPendingMissingLrn = 0;
$currentYearOfflineCount = 0;
$todayRegistrationCount = 0;
$currentYearFeeSetupCount = 0;
$currentYearFeeTypeCount = 0;
$todayFeeSyncCount = 0;
$todayFeeCopyCount = 0;
$todayActiveCollections = 0.0;
$todayOldCollections = 0.0;
$todayTotalCollections = 0.0;
$todayTransactionCount = 0;
$currentYearUnpaidStudents = 0;
$currentYearOutstandingBalance = 0.0;
$todayLogbookDraftCount = 0;
$todayLogbookFinalizedCount = 0;
$lastBackupStatus = 'Never Run';
$lastBackupAt = null;
$lastBackupFile = '';
$receiptBulletinReady = receipt_turnover_bulletin_ensure_table($conn);
$receiptBulletinRows = $receiptBulletinReady ? receipt_turnover_bulletin_load($conn, 40) : [];
$activeReceiptBulletins = array_values(array_filter($receiptBulletinRows, static function ($row) {
    return receipt_turnover_bulletin_normalize_status((string) ($row['status'] ?? 'active')) === 'active';
}));
$receiptBulletinPreview = array_slice($activeReceiptBulletins, 0, 5);

$studentYearStmt = $conn->prepare("SELECT COUNT(*) AS count FROM students WHERE COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?");
if ($studentYearStmt) {
    $studentYearStmt->bind_param("ss", $activeSchoolYearLabel, $activeSchoolYearLabel);
    $studentYearStmt->execute();
    $currentYearStudentCount = (int) (($studentYearStmt->get_result()->fetch_assoc()['count'] ?? 0));
    $studentYearStmt->close();
}

$pendingYearStmt = $conn->prepare("SELECT COUNT(*) AS count FROM student_registration_pending WHERE status = 'Pending' AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?");
if ($pendingYearStmt) {
    $pendingYearStmt->bind_param("ss", $activeSchoolYearLabel, $activeSchoolYearLabel);
    $pendingYearStmt->execute();
    $currentYearPendingCount = (int) (($pendingYearStmt->get_result()->fetch_assoc()['count'] ?? 0));
    $pendingYearStmt->close();
}

$studentsMissingLrnStmt = $conn->prepare("SELECT COUNT(*) AS count FROM students WHERE COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ? AND (lrn IS NULL OR TRIM(lrn) = '')");
if ($studentsMissingLrnStmt) {
    $studentsMissingLrnStmt->bind_param("ss", $activeSchoolYearLabel, $activeSchoolYearLabel);
    $studentsMissingLrnStmt->execute();
    $currentYearStudentsMissingLrn = (int) (($studentsMissingLrnStmt->get_result()->fetch_assoc()['count'] ?? 0));
    $studentsMissingLrnStmt->close();
}

$pendingMissingLrnStmt = $conn->prepare("SELECT COUNT(*) AS count FROM student_registration_pending WHERE status = 'Pending' AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ? AND (lrn IS NULL OR TRIM(lrn) = '')");
if ($pendingMissingLrnStmt) {
    $pendingMissingLrnStmt->bind_param("ss", $activeSchoolYearLabel, $activeSchoolYearLabel);
    $pendingMissingLrnStmt->execute();
    $currentYearPendingMissingLrn = (int) (($pendingMissingLrnStmt->get_result()->fetch_assoc()['count'] ?? 0));
    $pendingMissingLrnStmt->close();
}

$offlineStmt = $conn->prepare("SELECT COUNT(*) AS count FROM student_registration_pending WHERE COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ? AND source_channel IN ('offline_import', 'offline_sync')");
if ($offlineStmt) {
    $offlineStmt->bind_param("ss", $activeSchoolYearLabel, $activeSchoolYearLabel);
    $offlineStmt->execute();
    $currentYearOfflineCount = (int) (($offlineStmt->get_result()->fetch_assoc()['count'] ?? 0));
    $offlineStmt->close();
}

$todayRegistrationStmt = $conn->prepare("SELECT COUNT(*) AS count FROM student_registration_pending WHERE DATE(submitted_at) = CURDATE() AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?");
if ($todayRegistrationStmt) {
    $todayRegistrationStmt->bind_param("ss", $activeSchoolYearLabel, $activeSchoolYearLabel);
    $todayRegistrationStmt->execute();
    $todayRegistrationCount = (int) (($todayRegistrationStmt->get_result()->fetch_assoc()['count'] ?? 0));
    $todayRegistrationStmt->close();
}

$feeSetupStmt = $conn->prepare("SELECT COUNT(*) AS count, COUNT(DISTINCT fee_type_id) AS fee_types FROM fee WHERE COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?");
if ($feeSetupStmt) {
    $feeSetupStmt->bind_param("ss", $activeSchoolYearLabel, $activeSchoolYearLabel);
    $feeSetupStmt->execute();
    $feeSummary = $feeSetupStmt->get_result()->fetch_assoc() ?: [];
    $currentYearFeeSetupCount = (int) ($feeSummary['count'] ?? 0);
    $currentYearFeeTypeCount = (int) ($feeSummary['fee_types'] ?? 0);
    $feeSetupStmt->close();
}

$feeSyncStmt = $conn->prepare("SELECT COUNT(*) AS count FROM audit_logs WHERE action = 'Synced fee accounts' AND DATE(log_date) = CURDATE()");
if ($feeSyncStmt) {
    $feeSyncStmt->execute();
    $todayFeeSyncCount = (int) (($feeSyncStmt->get_result()->fetch_assoc()['count'] ?? 0));
    $feeSyncStmt->close();
}

$feeCopyStmt = $conn->prepare("SELECT COUNT(*) AS count FROM audit_logs WHERE action = 'Copied fee setup between school years' AND DATE(log_date) = CURDATE()");
if ($feeCopyStmt) {
    $feeCopyStmt->execute();
    $todayFeeCopyCount = (int) (($feeCopyStmt->get_result()->fetch_assoc()['count'] ?? 0));
    $feeCopyStmt->close();
}

$unpaidSummaryStmt = $conn->prepare("SELECT
    COUNT(DISTINCT CASE WHEN balance > 0 THEN student_id END) AS unpaid_students,
    COALESCE(SUM(balance), 0) AS outstanding_balance
    FROM accounts
    WHERE COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?");
if ($unpaidSummaryStmt) {
    $unpaidSummaryStmt->bind_param("ss", $activeSchoolYearLabel, $activeSchoolYearLabel);
    $unpaidSummaryStmt->execute();
    $unpaidSummary = $unpaidSummaryStmt->get_result()->fetch_assoc() ?: [];
    $currentYearUnpaidStudents = (int) ($unpaidSummary['unpaid_students'] ?? 0);
    $currentYearOutstandingBalance = (float) ($unpaidSummary['outstanding_balance'] ?? 0);
    $unpaidSummaryStmt->close();
}

$activeCollectionsStmt = $conn->prepare("SELECT
    COALESCE(SUM(p.amount), 0) AS total_amount,
    COUNT(*) AS transaction_count
    FROM payments p
    INNER JOIN accounts a ON a.id = p.account_id
    WHERE DATE(p.date_paid) = CURDATE()
      AND COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ?
      AND COALESCE(NULLIF(TRIM(p.school_year_label), ''), ?) = ?");
if ($activeCollectionsStmt) {
    $activeCollectionsStmt->bind_param("ssss", $activeSchoolYearLabel, $activeSchoolYearLabel, $activeSchoolYearLabel, $activeSchoolYearLabel);
    $activeCollectionsStmt->execute();
    $activeCollections = $activeCollectionsStmt->get_result()->fetch_assoc() ?: [];
    $todayActiveCollections = (float) ($activeCollections['total_amount'] ?? 0);
    $todayTransactionCount += (int) ($activeCollections['transaction_count'] ?? 0);
    $activeCollectionsStmt->close();
}

$oldCollectionsStmt = $conn->prepare("SELECT
    COALESCE(SUM(p.amount_paid), 0) AS total_amount,
    COUNT(*) AS transaction_count
    FROM old_student_payments p
    INNER JOIN old_students s ON s.id = p.old_student_id
    WHERE DATE(COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00'))) = CURDATE()
      AND COALESCE(NULLIF(TRIM(s.school_year_label), ''), ?) = ?");
if ($oldCollectionsStmt) {
    $oldCollectionsStmt->bind_param("ss", $activeSchoolYearLabel, $activeSchoolYearLabel);
    $oldCollectionsStmt->execute();
    $oldCollections = $oldCollectionsStmt->get_result()->fetch_assoc() ?: [];
    $todayOldCollections = (float) ($oldCollections['total_amount'] ?? 0);
    $todayTransactionCount += (int) ($oldCollections['transaction_count'] ?? 0);
    $oldCollectionsStmt->close();
}

$todayTotalCollections = $todayActiveCollections + $todayOldCollections;

$logbookTodayStmt = $conn->prepare("SELECT
    SUM(CASE WHEN is_finalized = 1 THEN 1 ELSE 0 END) AS finalized_count,
    SUM(CASE WHEN is_finalized = 0 THEN 1 ELSE 0 END) AS draft_count
    FROM logbook_shift_notes
    WHERE log_date = CURDATE()");
if ($logbookTodayStmt) {
    $logbookTodayStmt->execute();
    $logbookToday = $logbookTodayStmt->get_result()->fetch_assoc() ?: [];
    $todayLogbookFinalizedCount = (int) ($logbookToday['finalized_count'] ?? 0);
    $todayLogbookDraftCount = (int) ($logbookToday['draft_count'] ?? 0);
    $logbookTodayStmt->close();
}

backup_settings_ensure_table($conn);
$backupSettings = backup_settings_get($conn);
$lastBackupStatus = (string) ($backupSettings['last_backup_status'] ?? 'Never Run');
$lastBackupAt = $backupSettings['last_backup_at'] ?? null;
$lastBackupFile = trim((string) ($backupSettings['last_backup_file'] ?? ''));

// Get today's date
$today = date('F j, Y');

// Get logged-in admin name
$adminName = htmlspecialchars($_SESSION['username']);

$currentRole = (string) ($_SESSION['role'] ?? '');
$isRegistrarStaff = is_registrar_staff_role($currentRole);
$isAccountingStaff = is_accounting_staff_role($currentRole);
$isSpecializedStaff = $isRegistrarStaff || $isAccountingStaff;
$canViewReceiptBulletin = hasPermission($currentRole, 'financial', 'view');
$dashboardTitle = $isRegistrarStaff ? 'Registrar Operations Overview' : ($isAccountingStaff ? 'Accounting Operations Overview' : 'School Year Overview');
$dashboardSummary = $isRegistrarStaff
    ? 'Registrar work for ' . $activeSchoolYearLabel . ' is surfaced first so student intake, pending approvals, and document follow-up stay focused.'
    : ($isAccountingStaff
        ? 'Accounting work for ' . $activeSchoolYearLabel . ' is surfaced first so collections, invoices, logbook, and backup checks stay visible.'
        : 'The important work for ' . $activeSchoolYearLabel . ' is highlighted first so staff can act faster without scanning the whole page.');
$dashboardContextLabel = $isRegistrarStaff ? 'Registrar Dashboard' : ($isAccountingStaff ? 'Accounting Dashboard' : 'Operations Dashboard');
$primaryActionHref = $isRegistrarStaff
    ? '/school-admin-dashboard/modules/students/student-list.php'
    : ($isAccountingStaff ? '/school-admin-dashboard/modules/accounts/account-list.php' : 'modules/dashboard/owner-dashboard.php');
$primaryActionLabel = $isRegistrarStaff
    ? 'Open Registrar'
    : ($isAccountingStaff ? 'Open Finance' : 'Owner Dashboard');
$primaryActionIcon = $isRegistrarStaff
    ? 'fas fa-user-graduate'
    : ($isAccountingStaff ? 'fas fa-wallet' : 'fas fa-chart-pie');

// AUDIT LOGGING: Track dashboard access
include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');
$user = $_SESSION['username'] ?? 'unknown';
$action = "Accessed dashboard";
$module = "Dashboard";
$details = "Role: " . ($_SESSION['role'] ?? 'unknown');
audit_log($conn, $user, $action, $module, $details);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>School Admin and Finance Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --dash-bg: #f2f6fb;
            --dash-panel: #ffffff;
            --dash-ink: #172941;
            --dash-muted: #64748b;
            --dash-line: #dbe6f2;
            --dash-soft: #f7fbff;
            --dash-brand: #274a6f;
            --dash-brand-2: #426f98;
            --dash-blue-soft: #edf6ff;
            --dash-green-soft: #eaf8f1;
            --dash-green: #19764d;
            --dash-warning-soft: #fff6df;
            --dash-warning: #9a6a00;
            --dash-danger-soft: #fdecee;
            --dash-danger: #a33a44;
        }
        body {
            background: linear-gradient(180deg, #f8fbff 0%, var(--dash-bg) 100%);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
            color: var(--dash-ink);
            min-height: 100vh;
        }
        .navbar {
            background: #172941 !important;
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.08em;
        }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .nav-link.active { border-bottom: 2px solid #3897f0; }
        .dashboard-header {
            text-align: center;
            margin-top: 26px;
            margin-bottom: 14px;
        }
        .dashboard-header img {
            width: 64px;
            height: 64px;
            object-fit: contain;
            margin-bottom: 8px;
            background: #fff;
            border: 1px solid var(--dash-line);
            padding: 6px;
        }
        .dashboard-header h1 {
            font-size: 1.16rem;
            color: var(--dash-ink);
            font-weight: 800;
            margin-bottom: 0;
        }
        .stats-row {
            display: flex;
            flex-wrap: wrap;
            gap: 22px;
            justify-content: center;
            margin-bottom: 20px;
        }
        .stat-card {
            background: var(--dash-panel);
            border-radius: 16px;
            border: 1px solid var(--dash-line);
            box-shadow: 0 10px 28px rgba(23,41,65,0.07);
            padding: 20px 22px;
            min-width: 170px;
            max-width: 250px;
            text-align: center;
            flex: 1 1 160px;
            position: relative;
        }
        .stat-card .fa {
            font-size: 1.85em;
            margin-bottom: 8px;
            color: var(--dash-brand-2);
        }
        .stat-title {
            font-size: 1em;
            color: var(--dash-muted);
            font-weight: 600;
        }
        .stat-value {
            font-size: 1.3em;
            font-weight: bold;
            color: var(--dash-ink);
        }
        .calendar-card {
            background: #f7fafc;
            border-radius: 10px;
            border: 1px solid #eaf4ff;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 18px 0 10px 0;
        }
        .calendar-icon {
            font-size: 2em;
            color: #517fa4;
            margin-bottom: 4px;
        }
        .calendar-date {
            font-size: 1.12em;
            font-weight: 500;
            color: #23395d;
        }
        .admin-card {
            background: #f7fafc;
            border-radius: 10px;
            border: 1px solid #eaf4ff;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 18px 0 10px 0;
        }
        .admin-icon {
            font-size: 2em;
            color: #517fa4;
            margin-bottom: 4px;
        }
        .admin-name {
            font-size: 1.13em;
            font-weight: 500;
            color: #23395d;
        }
        .hero-card {
            max-width: 1120px;
            margin: 0 auto 24px auto;
            background: linear-gradient(135deg, #172941 0%, #274a6f 58%, #426f98 100%);
            color: #fff;
            border-radius: 22px;
            box-shadow: 0 18px 42px rgba(23,41,65,0.16);
            padding: 26px 30px;
            position: relative;
            overflow: hidden;
        }
        .hero-card::after {
            content: "";
            position: absolute;
            right: -64px;
            bottom: -82px;
            width: 260px;
            height: 260px;
            border-radius: 50%;
            border: 46px solid rgba(255,255,255,0.055);
            pointer-events: none;
        }
        .hero-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 12px;
        }
        .hero-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 14px;
        }
        .hero-badge {
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.14);
            color: #fff;
            border-radius: 999px;
            padding: 8px 14px;
            font-size: 0.95rem;
        }
        .hero-action-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            border-radius: 999px;
            padding: 9px 15px;
            background: rgba(255,255,255,0.16);
            border: 1px solid rgba(255,255,255,0.22);
            color: #fff;
            text-decoration: none;
            font-weight: 600;
            transition: background 0.18s ease, transform 0.18s ease;
            position: relative;
            z-index: 1;
        }
        .hero-action-btn:hover {
            background: rgba(255,255,255,0.24);
            color: #fff;
            transform: translateY(-1px);
        }
        .attention-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 14px;
        }
        .attention-card {
            background: var(--dash-panel);
            border-radius: 16px;
            border: 1px solid var(--dash-line);
            border-left: 5px solid #f0ad4e;
            box-shadow: 0 10px 26px rgba(23,41,65,0.07);
            padding: 18px 18px 16px;
        }
        .attention-card.critical { border-left-color: #dc3545; }
        .attention-card.healthy { border-left-color: #198754; }
        .attention-topline {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            margin-bottom: 8px;
        }
        .attention-label {
            color: var(--dash-ink);
            font-weight: 700;
        }
        .attention-value {
            font-size: 1.7rem;
            font-weight: 800;
            color: var(--dash-ink);
            line-height: 1;
            margin-bottom: 8px;
        }
        .attention-note {
            color: var(--dash-muted);
            font-size: 0.94rem;
        }
        .section-wrap {
            max-width: 1120px;
            margin: 0 auto 26px auto;
        }
        .monitor-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 14px;
        }
        .monitor-card {
            background: var(--dash-panel);
            border-radius: 16px;
            border: 1px solid var(--dash-line);
            box-shadow: 0 10px 24px rgba(23,41,65,0.06);
            padding: 18px 18px 16px;
        }
        .monitor-card.secondary {
            background: var(--dash-soft);
            box-shadow: none;
        }
        .monitor-icon {
            color: var(--dash-brand-2);
            font-size: 1.4rem;
            margin-bottom: 8px;
        }
        .monitor-title {
            color: var(--dash-ink);
            font-weight: 700;
            margin-bottom: 6px;
        }
        .monitor-value {
            font-size: 1.7rem;
            font-weight: 700;
            color: var(--dash-ink);
            line-height: 1;
            margin-bottom: 8px;
        }
        .monitor-note {
            color: var(--dash-muted);
            font-size: 0.94rem;
        }
        .ops-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 14px;
        }
        .ops-card {
            background: var(--dash-panel);
            border-radius: 16px;
            border: 1px solid var(--dash-line);
            box-shadow: 0 10px 24px rgba(23,41,65,0.06);
            padding: 18px 18px 16px;
        }
        .ops-topline {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            margin-bottom: 8px;
        }
        .ops-label {
            color: var(--dash-muted);
            font-size: 0.82rem;
            font-weight: 700;
            letter-spacing: 0.05em;
            text-transform: uppercase;
        }
        .ops-value {
            font-size: 1.45rem;
            font-weight: 800;
            color: var(--dash-ink);
            line-height: 1.15;
            margin-bottom: 6px;
        }
        .ops-subvalue {
            color: var(--dash-brand-2);
            font-size: 0.94rem;
            font-weight: 600;
            margin-bottom: 4px;
        }
        .ops-note {
            color: var(--dash-muted);
            font-size: 0.92rem;
            line-height: 1.45;
        }
        .ops-chip {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border-radius: 999px;
            padding: 6px 10px;
            font-size: 0.8rem;
            font-weight: 700;
            background: var(--dash-blue-soft);
            color: var(--dash-brand);
        }
        .ops-chip.success {
            background: var(--dash-green-soft);
            color: var(--dash-green);
        }
        .ops-chip.warning {
            background: var(--dash-warning-soft);
            color: var(--dash-warning);
        }
        .ops-chip.danger {
            background: var(--dash-danger-soft);
            color: var(--dash-danger);
        }
        .receipt-bulletin-preview {
            background: var(--dash-panel);
            border: 1px solid var(--dash-line);
            border-radius: 16px;
            box-shadow: 0 10px 24px rgba(23,41,65,0.06);
            overflow: hidden;
        }
        .receipt-bulletin-head {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
            padding: 15px 18px;
            border-bottom: 1px solid var(--dash-line);
            background: linear-gradient(180deg, #ffffff, #f8fbff);
        }
        .receipt-bulletin-title-wrap {
            display: flex;
            align-items: center;
            gap: 0.78rem;
            min-width: 0;
        }
        .receipt-bulletin-icon {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: var(--dash-blue-soft);
            color: var(--dash-brand-2);
            border: 1px solid #cfe3ee;
            flex: 0 0 auto;
        }
        .receipt-bulletin-kicker {
            color: var(--dash-muted);
            font-size: 0.72rem;
            font-weight: 850;
            letter-spacing: 0.07em;
            text-transform: uppercase;
        }
        .receipt-bulletin-title {
            color: var(--dash-ink);
            font-size: 1.02rem;
            font-weight: 850;
            line-height: 1.2;
            margin-top: 2px;
        }
        .receipt-bulletin-note {
            color: var(--dash-muted);
            font-size: 0.86rem;
            margin-top: 2px;
        }
        .receipt-bulletin-head-actions {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 0.45rem;
            flex-wrap: wrap;
        }
        .receipt-bulletin-count {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            border-radius: 999px;
            padding: 0.32rem 0.62rem;
            background: var(--dash-green-soft);
            color: var(--dash-green);
            border: 1px solid #c8ead8;
            font-size: 0.78rem;
            font-weight: 850;
            white-space: nowrap;
        }
        .receipt-bulletin-action {
            border-radius: 10px;
            font-weight: 800;
            white-space: nowrap;
        }
        .receipt-bulletin-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
        }
        .receipt-bulletin-table thead th {
            background: #f4f8fc;
            color: var(--dash-muted);
            font-size: 0.7rem;
            font-weight: 900;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            padding: 0.7rem 0.8rem;
            border-bottom: 1px solid var(--dash-line);
            white-space: nowrap;
        }
        .receipt-bulletin-table tbody td {
            color: var(--dash-ink);
            font-size: 0.86rem;
            padding: 0.78rem 0.8rem;
            border-bottom: 1px solid #edf2f7;
            vertical-align: top;
        }
        .receipt-bulletin-table tbody tr:last-child td {
            border-bottom: 0;
        }
        .receipt-bulletin-channel {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 88px;
            border-radius: 999px;
            padding: 0.3rem 0.62rem;
            font-size: 0.74rem;
            font-weight: 900;
            border: 1px solid #d7e4ee;
            background: #f3f7fb;
            color: #49697f;
            white-space: nowrap;
        }
        .receipt-bulletin-channel.cash {
            background: var(--dash-green-soft);
            border-color: #c8ead8;
            color: var(--dash-green);
        }
        .receipt-bulletin-channel.bank_gcash {
            background: var(--dash-blue-soft);
            border-color: #cfe3ee;
            color: var(--dash-brand);
        }
        .receipt-bulletin-channel.other {
            background: var(--dash-warning-soft);
            border-color: #eadcb2;
            color: var(--dash-warning);
        }
        .receipt-bulletin-range {
            color: var(--dash-ink);
            font-weight: 900;
            white-space: nowrap;
            overflow-wrap: anywhere;
        }
        .receipt-bulletin-text {
            color: var(--dash-muted);
            font-size: 0.86rem;
            line-height: 1.45;
            overflow-wrap: anywhere;
        }
        .receipt-bulletin-meta {
            color: var(--dash-muted);
            font-size: 0.76rem;
            line-height: 1.35;
            white-space: nowrap;
        }
        .receipt-bulletin-meta strong,
        .receipt-bulletin-meta span {
            display: block;
        }
        .receipt-bulletin-meta strong {
            color: var(--dash-ink);
            font-weight: 850;
        }
        .receipt-bulletin-empty {
            padding: 16px 18px;
            color: var(--dash-muted);
            font-weight: 650;
            text-align: center;
            background: #fbfdff;
        }
        .info-title {
            font-size: 1.02em;
            color: var(--dash-ink);
            font-weight: 650;
            margin-bottom: 10px;
        }
        /* Floating round buttons */
        .floating-buttons {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 1050;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .float-btn {
            background: var(--dash-brand);
            color: #fff;
            border: none;
            border-radius: 16px;
            width: 54px;
            height: 54px;
            font-size: 1.4em;
            box-shadow: 0 12px 28px rgba(23,41,65,0.18);
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.2s;
            cursor: pointer;
        }
        .float-btn:hover {
            background: #172941;
        }
        @media (max-width: 900px) {
            .receipt-bulletin-head {
                align-items: stretch;
                flex-direction: column;
            }
            .receipt-bulletin-head-actions {
                justify-content: flex-start;
            }
            .receipt-bulletin-action {
                width: 100%;
                justify-content: center;
            }
            .receipt-bulletin-table,
            .receipt-bulletin-table thead,
            .receipt-bulletin-table tbody,
            .receipt-bulletin-table tr,
            .receipt-bulletin-table td {
                display: block;
                width: 100%;
            }
            .receipt-bulletin-table thead {
                display: none;
            }
            .receipt-bulletin-table tbody tr {
                border-bottom: 1px solid var(--dash-line);
                padding: 0.65rem 0;
            }
            .receipt-bulletin-table tbody tr:last-child {
                border-bottom: 0;
            }
            .receipt-bulletin-table tbody td {
                display: grid;
                grid-template-columns: 86px minmax(0, 1fr);
                gap: 0.65rem;
                border-bottom: 0;
                padding: 0.34rem 0.85rem;
            }
            .receipt-bulletin-table tbody td::before {
                content: attr(data-label);
                color: var(--dash-muted);
                font-size: 0.7rem;
                font-weight: 900;
                letter-spacing: 0.05em;
                text-transform: uppercase;
            }
            .receipt-bulletin-range,
            .receipt-bulletin-meta {
                white-space: normal;
            }
            .stats-row { flex-direction: column; gap: 10px;}
            .stat-card, .calendar-card, .admin-card { min-width: 140px; max-width: 100%; }
            .floating-buttons { right: 12px; bottom: 12px; }
            .float-btn { width: 50px; height: 50px; font-size: 1.25em; }
        }
        @media (max-width: 576px) {
            .dashboard-header h1 { font-size: 1.01rem;}
            .dashboard-header img { width: 34px; height: 34px;}
            .stats-row { gap: 7px;}
            .stat-card, .calendar-card, .admin-card { padding: 10px 3px; font-size: 0.97em;}
            .hero-card { padding: 20px 18px; border-radius: 18px; }
        }
    </style>
</head>
<body>
<!-- Navbar -->
<?php render_admin_nav('dashboard'); ?>

<!-- Header -->
<div class="dashboard-header">
    <img src="/school-admin-dashboard/uploads/logo1.png" alt="School Logo" class="mb-2 rounded shadow-sm">
    <h1>The Lord's Wisdom Academy Of Caloocan Inc.</h1>
</div>

<div class="hero-card">
    <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">
        <div>
            <div class="text-uppercase small fw-semibold opacity-75"><?= htmlspecialchars($dashboardContextLabel) ?></div>
            <h2 class="h4 mb-2"><?= htmlspecialchars($dashboardTitle) ?></h2>
            <div class="opacity-90"><?= htmlspecialchars($dashboardSummary) ?></div>
            <div class="hero-meta">
                <span class="hero-badge"><i class="fas fa-calendar-days me-1"></i><?= htmlspecialchars($activeSchoolYearLabel) ?></span>
                <span class="hero-badge"><i class="fas fa-door-open me-1"></i><?= $enrollmentOpen ? 'Enrollment Open' : 'Enrollment Closed' ?></span>
                <span class="hero-badge"><i class="fas fa-calendar-alt me-1"></i><?= htmlspecialchars($today) ?></span>
            </div>
            <div class="hero-actions">
                <a class="hero-action-btn" href="<?= htmlspecialchars($primaryActionHref) ?>">
                    <i class="<?= htmlspecialchars($primaryActionIcon) ?>"></i>
                    <span><?= htmlspecialchars($primaryActionLabel) ?></span>
                </a>
                <?php if ($isRegistrarStaff): ?>
                    <a class="hero-action-btn" href="/school-admin-dashboard/modules/settings/settings-backup-restore.php">
                        <i class="fas fa-database"></i>
                        <span>Backup Desk</span>
                    </a>
                <?php elseif ($isAccountingStaff): ?>
                    <a class="hero-action-btn" href="/school-admin-dashboard/modules/logbook/logbook.php">
                        <i class="fas fa-book"></i>
                        <span>Open Logbook</span>
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="text-end">
            <div class="small opacity-75">Logged in as</div>
            <div class="fw-semibold"><?= $adminName ?></div>
            <div class="small opacity-75 mt-1"><?= htmlspecialchars($_SESSION['role'] ?? '') ?></div>
        </div>
    </div>
</div>

<?php if ($isRegistrarStaff): ?>
<div class="section-wrap mb-4">
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <div class="info-title mb-0"><i class="fas fa-triangle-exclamation me-1"></i>Registrar Priorities</div>
        <span class="text-muted small">Student intake, follow-up, and backup visibility</span>
    </div>
    <div class="attention-grid">
        <div class="attention-card <?= $currentYearPendingCount > 0 ? 'critical' : 'healthy' ?>">
            <div class="attention-topline">
                <div class="attention-label">Pending Queue</div>
                <span class="ops-chip <?= $currentYearPendingCount > 0 ? 'warning' : 'success' ?>"><i class="fas fa-user-clock"></i><?= number_format($currentYearPendingCount) ?></span>
            </div>
            <div class="attention-value"><?= number_format($currentYearPendingCount) ?></div>
            <div class="attention-note">Registration records still waiting for registrar review.</div>
        </div>
        <div class="attention-card <?= ($currentYearStudentsMissingLrn + $currentYearPendingMissingLrn) > 0 ? 'critical' : 'healthy' ?>">
            <div class="attention-topline">
                <div class="attention-label">LRN Follow-up</div>
                <span class="ops-chip <?= ($currentYearStudentsMissingLrn + $currentYearPendingMissingLrn) > 0 ? 'warning' : 'success' ?>"><i class="fas fa-id-card"></i><?= number_format($currentYearStudentsMissingLrn + $currentYearPendingMissingLrn) ?></span>
            </div>
            <div class="attention-value"><?= number_format($currentYearStudentsMissingLrn + $currentYearPendingMissingLrn) ?></div>
            <div class="attention-note">Official and pending records that still need LRN completion.</div>
        </div>
        <div class="attention-card <?= $lastBackupAt ? 'healthy' : 'critical' ?>">
            <div class="attention-topline">
                <div class="attention-label">Backup Check</div>
                <span class="ops-chip <?= stripos($lastBackupStatus, 'success') !== false ? 'success' : 'warning' ?>"><i class="fas fa-database"></i><?= htmlspecialchars($lastBackupStatus) ?></span>
            </div>
            <div class="attention-value"><?= $lastBackupAt ? htmlspecialchars(date('M j', strtotime((string) $lastBackupAt))) : 'No run' ?></div>
            <div class="attention-note"><?= $lastBackupAt ? 'Latest recorded backup is visible before registrar encoding continues.' : 'Create a backup before major registrar updates.' ?></div>
        </div>
    </div>
</div>

<div class="stats-row section-wrap">
    <div class="stat-card">
        <i class="fas fa-users"></i>
        <div class="stat-title">Students This Year</div>
        <div class="stat-value"><?= number_format($currentYearStudentCount) ?></div>
    </div>
    <div class="stat-card">
        <i class="fas fa-user-clock"></i>
        <div class="stat-title">Pending This Year</div>
        <div class="stat-value"><?= number_format($currentYearPendingCount) ?></div>
    </div>
    <div class="stat-card">
        <i class="fas fa-calendar-plus"></i>
        <div class="stat-title">Registrations Today</div>
        <div class="stat-value"><?= number_format($todayRegistrationCount) ?></div>
    </div>
    <div class="stat-card">
        <i class="fas fa-plug-circle-xmark"></i>
        <div class="stat-title">Offline Registrations</div>
        <div class="stat-value"><?= number_format($currentYearOfflineCount) ?></div>
    </div>
</div>

<div class="section-wrap mb-4">
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <div class="info-title mb-0"><i class="fas fa-link me-1"></i>Registrar Shortcuts</div>
        <span class="text-muted small">Direct access to registrar workspaces you actually use</span>
    </div>
    <div class="ops-grid">
        <div class="ops-card">
            <div class="ops-topline">
                <div class="ops-label">Student List</div>
                <span class="ops-chip success"><i class="fas fa-user-graduate"></i>Open</span>
            </div>
            <div class="ops-value">Official Records</div>
            <div class="ops-subvalue">Browse, add, edit, and export active student records.</div>
            <div class="ops-note"><a href="/school-admin-dashboard/modules/students/student-list.php">Open registrar desk</a></div>
        </div>
        <div class="ops-card">
            <div class="ops-topline">
                <div class="ops-label">Pending Registration</div>
                <span class="ops-chip <?= $currentYearPendingCount > 0 ? 'warning' : 'success' ?>"><i class="fas fa-user-clock"></i><?= number_format($currentYearPendingCount) ?></span>
            </div>
            <div class="ops-value">Queue Review</div>
            <div class="ops-subvalue">Approve or reject pending registration submissions.</div>
            <div class="ops-note"><a href="/school-admin-dashboard/modules/students/student-registration-pending.php">Open pending queue</a></div>
        </div>
        <div class="ops-card">
            <div class="ops-topline">
                <div class="ops-label">Backup Desk</div>
                <span class="ops-chip <?= stripos($lastBackupStatus, 'success') !== false ? 'success' : 'warning' ?>"><i class="fas fa-database"></i><?= htmlspecialchars($lastBackupStatus) ?></span>
            </div>
            <div class="ops-value">Manual Backup</div>
            <div class="ops-subvalue">Create and download registrar-side backup proof when needed.</div>
            <div class="ops-note"><a href="/school-admin-dashboard/modules/settings/settings-backup-restore.php">Open backup desk</a></div>
        </div>
    </div>
</div>
<?php elseif ($isAccountingStaff): ?>
<div class="section-wrap mb-4">
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <div class="info-title mb-0"><i class="fas fa-triangle-exclamation me-1"></i>Accounting Priorities</div>
        <span class="text-muted small">Collections, logbook follow-up, and backup visibility</span>
    </div>
    <div class="attention-grid">
        <div class="attention-card <?= $todayTransactionCount > 0 ? 'healthy' : 'critical' ?>">
            <div class="attention-topline">
                <div class="attention-label">Today's Collections</div>
                <span class="ops-chip success"><i class="fas fa-coins"></i><?= number_format($todayTransactionCount) ?> txn</span>
            </div>
            <div class="attention-value">PHP <?= number_format($todayTotalCollections, 2) ?></div>
            <div class="attention-note">Combined active and old-account collections recorded today.</div>
        </div>
        <div class="attention-card <?= $todayLogbookDraftCount > 0 ? 'critical' : 'healthy' ?>">
            <div class="attention-topline">
                <div class="attention-label">Open Logbook Drafts</div>
                <span class="ops-chip <?= $todayLogbookDraftCount > 0 ? 'warning' : 'success' ?>"><i class="fas fa-book"></i><?= number_format($todayLogbookDraftCount) ?></span>
            </div>
            <div class="attention-value"><?= number_format($todayLogbookDraftCount) ?></div>
            <div class="attention-note">Draft turnover notes that still need daily completion.</div>
        </div>
        <div class="attention-card <?= $lastBackupAt ? 'healthy' : 'critical' ?>">
            <div class="attention-topline">
                <div class="attention-label">Backup Check</div>
                <span class="ops-chip <?= stripos($lastBackupStatus, 'success') !== false ? 'success' : 'warning' ?>"><i class="fas fa-database"></i><?= htmlspecialchars($lastBackupStatus) ?></span>
            </div>
            <div class="attention-value"><?= $lastBackupAt ? htmlspecialchars(date('M j', strtotime((string) $lastBackupAt))) : 'No run' ?></div>
            <div class="attention-note"><?= $lastBackupAt ? 'Latest backup status is visible before finance work continues.' : 'Create a manual backup before major accounting changes.' ?></div>
        </div>
    </div>
</div>

<div class="stats-row section-wrap">
    <div class="stat-card">
        <i class="fas fa-coins"></i>
        <div class="stat-title">Today's Collections</div>
        <div class="stat-value">PHP <?= number_format($todayTotalCollections, 2) ?></div>
    </div>
    <div class="stat-card">
        <i class="fas fa-wallet"></i>
        <div class="stat-title">Outstanding Balance</div>
        <div class="stat-value">PHP <?= number_format($currentYearOutstandingBalance, 2) ?></div>
    </div>
    <div class="stat-card">
        <i class="fas fa-user-group"></i>
        <div class="stat-title">Unpaid Students</div>
        <div class="stat-value"><?= number_format($currentYearUnpaidStudents) ?></div>
    </div>
    <div class="stat-card">
        <i class="fas fa-book"></i>
        <div class="stat-title">Logbook Finalized</div>
        <div class="stat-value"><?= number_format($todayLogbookFinalizedCount) ?></div>
    </div>
</div>

<div class="section-wrap mb-4">
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <div class="info-title mb-0"><i class="fas fa-link me-1"></i>Accounting Shortcuts</div>
        <span class="text-muted small">Daily finance workspaces without registrar-only pages</span>
    </div>
    <div class="ops-grid">
        <div class="ops-card">
            <div class="ops-topline">
                <div class="ops-label">Finance Desk</div>
                <span class="ops-chip success"><i class="fas fa-wallet"></i>Open</span>
            </div>
            <div class="ops-value">Student Accounts</div>
            <div class="ops-subvalue">Review balances, payment desks, and account summaries.</div>
            <div class="ops-note"><a href="/school-admin-dashboard/modules/accounts/account-list.php">Open finance desk</a></div>
        </div>
        <div class="ops-card">
            <div class="ops-topline">
                <div class="ops-label">Logbook</div>
                <span class="ops-chip <?= $todayLogbookDraftCount > 0 ? 'warning' : 'success' ?>"><i class="fas fa-book"></i><?= number_format($todayLogbookDraftCount) ?> draft</span>
            </div>
            <div class="ops-value">Daily Turnover</div>
            <div class="ops-subvalue">Review draft and finalized shift notes for the day.</div>
            <div class="ops-note"><a href="/school-admin-dashboard/modules/logbook/logbook.php">Open logbook</a></div>
        </div>
        <div class="ops-card">
            <div class="ops-topline">
                <div class="ops-label">Invoice Desk</div>
                <span class="ops-chip success"><i class="fas fa-file-invoice"></i>Open</span>
            </div>
            <div class="ops-value">Invoice Reports</div>
            <div class="ops-subvalue">Open invoice compilation and daily collection views.</div>
            <div class="ops-note"><a href="/school-admin-dashboard/modules/invoice/invoice-view.php">Open invoice desk</a></div>
        </div>
        <div class="ops-card">
            <div class="ops-topline">
                <div class="ops-label">Backup Desk</div>
                <span class="ops-chip <?= stripos($lastBackupStatus, 'success') !== false ? 'success' : 'warning' ?>"><i class="fas fa-database"></i><?= htmlspecialchars($lastBackupStatus) ?></span>
            </div>
            <div class="ops-value">Manual Backup</div>
            <div class="ops-subvalue">Create and download accounting-side backup proof when needed.</div>
            <div class="ops-note"><a href="/school-admin-dashboard/modules/settings/settings-backup-restore.php">Open backup desk</a></div>
        </div>
    </div>
</div>
<?php else: ?>
<div class="section-wrap mb-4">
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <div class="info-title mb-0"><i class="fas fa-triangle-exclamation me-1"></i>Needs Attention</div>
        <span class="text-muted small">Urgent and follow-up signals first</span>
    </div>
    <div class="attention-grid">
        <div class="attention-card <?= $currentYearPendingCount > 0 ? 'critical' : 'healthy' ?>">
            <div class="attention-topline">
                <div class="attention-label">Pending Queue</div>
                <span class="ops-chip <?= $currentYearPendingCount > 0 ? 'warning' : 'success' ?>"><i class="fas fa-user-clock"></i><?= number_format($currentYearPendingCount) ?></span>
            </div>
            <div class="attention-value"><?= number_format($currentYearPendingCount) ?></div>
            <div class="attention-note">Registration records waiting for review in the active school year.</div>
        </div>
        <div class="attention-card <?= ($currentYearStudentsMissingLrn + $currentYearPendingMissingLrn) > 0 ? 'critical' : 'healthy' ?>">
            <div class="attention-topline">
                <div class="attention-label">LRN Follow-up</div>
                <span class="ops-chip <?= ($currentYearStudentsMissingLrn + $currentYearPendingMissingLrn) > 0 ? 'warning' : 'success' ?>"><i class="fas fa-id-card"></i><?= number_format($currentYearStudentsMissingLrn + $currentYearPendingMissingLrn) ?></span>
            </div>
            <div class="attention-value"><?= number_format($currentYearStudentsMissingLrn + $currentYearPendingMissingLrn) ?></div>
            <div class="attention-note">Combined official and pending records that still need LRN attention.</div>
        </div>
        <div class="attention-card <?= $todayLogbookDraftCount > 0 ? 'critical' : 'healthy' ?>">
            <div class="attention-topline">
                <div class="attention-label">Open Logbook Drafts</div>
                <span class="ops-chip <?= $todayLogbookDraftCount > 0 ? 'warning' : 'success' ?>"><i class="fas fa-book"></i><?= number_format($todayLogbookDraftCount) ?></span>
            </div>
            <div class="attention-value"><?= number_format($todayLogbookDraftCount) ?></div>
            <div class="attention-note">Draft logbook entries still waiting for final review today.</div>
        </div>
        <div class="attention-card <?= stripos($lastBackupStatus, 'failed') !== false ? 'critical' : (stripos($lastBackupStatus, 'success') !== false ? 'healthy' : '') ?>">
            <div class="attention-topline">
                <div class="attention-label">Backup Health</div>
                <span class="ops-chip <?= stripos($lastBackupStatus, 'success') !== false ? 'success' : (stripos($lastBackupStatus, 'failed') !== false ? 'danger' : 'warning') ?>"><i class="fas fa-database"></i><?= htmlspecialchars($lastBackupStatus) ?></span>
            </div>
            <div class="attention-value"><?= $lastBackupAt ? htmlspecialchars(date('M j', strtotime((string) $lastBackupAt))) : 'No run' ?></div>
            <div class="attention-note"><?= $lastBackupAt ? 'Last backup recorded at ' . htmlspecialchars(date('g:i A', strtotime((string) $lastBackupAt))) : 'No backup run has been recorded yet.' ?></div>
        </div>
    </div>
</div>

<!-- Primary Snapshot -->
<div class="stats-row section-wrap">
    <div class="stat-card">
        <i class="fas fa-users"></i>
        <div class="stat-title">Students This Year</div>
        <div class="stat-value"><?= number_format($currentYearStudentCount) ?></div>
    </div>
    <div class="stat-card">
        <i class="fas fa-user-clock"></i>
        <div class="stat-title">Pending This Year</div>
        <div class="stat-value"><?= number_format($currentYearPendingCount) ?></div>
        <a href="modules/students/student-registration-pending.php" class="btn btn-sm btn-outline-primary mt-2">Open Queue</a>
    </div>
    <div class="stat-card">
        <i class="fas fa-coins"></i>
        <div class="stat-title">Today's Collections</div>
        <div class="stat-value">PHP <?= number_format($todayTotalCollections, 2) ?></div>
    </div>
    <div class="stat-card">
        <i class="fas fa-wallet"></i>
        <div class="stat-title">Outstanding Balance</div>
        <div class="stat-value">PHP <?= number_format($currentYearOutstandingBalance, 2) ?></div>
    </div>
</div>

<div class="section-wrap mb-4">
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <div class="info-title mb-0"><i class="fas fa-chart-line me-1"></i>Operations Snapshot</div>
        <span class="text-muted small">Primary financial and operational health</span>
    </div>
    <div class="ops-grid">
        <div class="ops-card">
            <div class="ops-topline">
                <div class="ops-label">Today's Collections</div>
                <span class="ops-chip success"><i class="fas fa-coins"></i><?= number_format($todayTransactionCount) ?> txn</span>
            </div>
            <div class="ops-value">PHP <?= number_format($todayTotalCollections, 2) ?></div>
            <div class="ops-subvalue">Active: PHP <?= number_format($todayActiveCollections, 2) ?> | Old: PHP <?= number_format($todayOldCollections, 2) ?></div>
            <div class="ops-note">Quick total of todayÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢s recorded collections so the owner can see income without opening a full report.</div>
        </div>
        <div class="ops-card">
            <div class="ops-topline">
                <div class="ops-label">Outstanding Balance</div>
                <span class="ops-chip <?= $currentYearUnpaidStudents > 0 ? 'warning' : 'success' ?>"><i class="fas fa-user-group"></i><?= number_format($currentYearUnpaidStudents) ?> unpaid</span>
            </div>
            <div class="ops-value">PHP <?= number_format($currentYearOutstandingBalance, 2) ?></div>
            <div class="ops-subvalue">Active school year unpaid student coverage</div>
            <div class="ops-note">Shows how much balance is still open and how many students still need follow-up.</div>
        </div>
        <div class="ops-card">
            <div class="ops-topline">
                <div class="ops-label">Today's Logbook</div>
                <span class="ops-chip <?= $todayLogbookDraftCount > 0 ? 'warning' : 'success' ?>"><i class="fas fa-book"></i><?= number_format($todayLogbookFinalizedCount) ?> finalized</span>
            </div>
            <div class="ops-value"><?= number_format($todayLogbookDraftCount) ?> draft</div>
            <div class="ops-subvalue">Morning and afternoon entries for <?= htmlspecialchars(date('F j, Y')) ?></div>
            <div class="ops-note">Useful to check whether the day is already closed properly or still waiting for logbook review.</div>
        </div>
        <div class="ops-card">
            <div class="ops-topline">
                <div class="ops-label">Last Backup</div>
                <span class="ops-chip <?= stripos($lastBackupStatus, 'success') !== false ? 'success' : (stripos($lastBackupStatus, 'failed') !== false ? 'danger' : 'warning') ?>"><i class="fas fa-database"></i><?= htmlspecialchars($lastBackupStatus) ?></span>
            </div>
            <div class="ops-value"><?= $lastBackupAt ? htmlspecialchars(date('M j, Y g:i A', strtotime((string) $lastBackupAt))) : 'Not yet run' ?></div>
            <div class="ops-subvalue"><?= $lastBackupFile !== '' ? htmlspecialchars($lastBackupFile) : 'No backup file recorded yet' ?></div>
            <div class="ops-note">Pulled from the backup schedule settings so backup health is visible from the main dashboard.</div>
        </div>
    </div>
</div>

<div class="section-wrap mb-4">
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <div class="info-title mb-0"><i class="fas fa-signal me-1"></i>Secondary Watchlist</div>
        <span class="text-muted small">Useful checks that matter, but are less urgent than the top attention row</span>
    </div>
    <div class="monitor-grid">
        <div class="monitor-card secondary">
            <div class="monitor-icon"><i class="fas fa-id-card"></i></div>
            <div class="monitor-title">Students Missing LRN</div>
            <div class="monitor-value"><?= number_format($currentYearStudentsMissingLrn) ?></div>
            <div class="monitor-note">Official student records this year that still need LRN follow-up.</div>
        </div>
        <div class="monitor-card secondary">
            <div class="monitor-icon"><i class="fas fa-user-clock"></i></div>
            <div class="monitor-title">Pending Missing LRN</div>
            <div class="monitor-value"><?= number_format($currentYearPendingMissingLrn) ?></div>
            <div class="monitor-note">Pending registrations this year that still have no LRN entered yet.</div>
        </div>
        <div class="monitor-card secondary">
            <div class="monitor-icon"><i class="fas fa-plug-circle-xmark"></i></div>
            <div class="monitor-title">Offline Registrations</div>
            <div class="monitor-value"><?= number_format($currentYearOfflineCount) ?></div>
            <div class="monitor-note">Imported or synced offline registration entries under the active school year.</div>
        </div>
        <div class="monitor-card secondary">
            <div class="monitor-icon"><i class="fas fa-calendar-plus"></i></div>
            <div class="monitor-title">Registrations Today</div>
            <div class="monitor-value"><?= number_format($todayRegistrationCount) ?></div>
            <div class="monitor-note">All registration submissions recorded today for the active school year.</div>
        </div>
    </div>
</div>

<?php endif; ?>

<?php if ($canViewReceiptBulletin): ?>
<div class="section-wrap mb-4">
    <div class="receipt-bulletin-preview">
        <div class="receipt-bulletin-head">
            <div class="receipt-bulletin-title-wrap">
                <span class="receipt-bulletin-icon"><i class="fas fa-clipboard-list"></i></span>
                <span>
                    <span class="receipt-bulletin-kicker">Office Turnover</span>
                    <span class="receipt-bulletin-title">Receipt Turnover Bulletin</span>
                    <span class="receipt-bulletin-note">Read-only preview for physical OR cash and bank/GCash range reminders.</span>
                </span>
            </div>
            <div class="receipt-bulletin-head-actions">
                <span class="receipt-bulletin-count"><i class="fas fa-circle-check"></i><?= number_format(count($activeReceiptBulletins)) ?> Active</span>
                <a class="btn btn-outline-primary btn-sm receipt-bulletin-action" href="/school-admin-dashboard/modules/invoice/invoice-receipts.php?bulletin=1">
                    <i class="fas fa-receipt me-1"></i>Open Receipt Ledger
                </a>
            </div>
        </div>
        <?php if (!$receiptBulletinReady): ?>
            <div class="receipt-bulletin-empty"><?= htmlspecialchars(receipt_turnover_bulletin_missing_message()) ?></div>
        <?php elseif (!$receiptBulletinPreview): ?>
            <div class="receipt-bulletin-empty">No active receipt turnover bulletin notes.</div>
        <?php else: ?>
            <table class="receipt-bulletin-table">
                <thead>
                    <tr>
                        <th>Use</th>
                        <th>Range</th>
                        <th>Note</th>
                        <th>Saved</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($receiptBulletinPreview as $bulletin): ?>
                        <?php
                        $bulletinChannel = receipt_turnover_bulletin_normalize_channel((string) ($bulletin['receipt_channel'] ?? $bulletin['title'] ?? 'cash'));
                        $bulletinRange = trim((string) ($bulletin['receipt_scope'] ?? '')) ?: '-';
                        $bulletinText = trim((string) ($bulletin['note_text'] ?? ''));
                        $bulletinBy = trim((string) ($bulletin['created_by'] ?? '')) ?: 'Unknown';
                        $bulletinDateRaw = trim((string) ($bulletin['created_at'] ?? ''));
                        $bulletinDate = $bulletinDateRaw !== '' && strtotime($bulletinDateRaw) ? date('M j, g:i A', strtotime($bulletinDateRaw)) : $bulletinDateRaw;
                        ?>
                        <tr>
                            <td data-label="Use"><span class="receipt-bulletin-channel <?= htmlspecialchars($bulletinChannel) ?>"><?= htmlspecialchars(receipt_turnover_bulletin_channel_label($bulletinChannel)) ?></span></td>
                            <td data-label="Range" class="receipt-bulletin-range"><?= htmlspecialchars($bulletinRange) ?></td>
                            <td data-label="Note" class="receipt-bulletin-text"><?= htmlspecialchars($bulletinText) ?></td>
                            <td data-label="Saved" class="receipt-bulletin-meta"><strong><?= htmlspecialchars($bulletinBy) ?></strong><span><?= htmlspecialchars($bulletinDate) ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php if (count($activeReceiptBulletins) > count($receiptBulletinPreview)): ?>
                <div class="receipt-bulletin-empty py-2">+<?= number_format(count($activeReceiptBulletins) - count($receiptBulletinPreview)) ?> more active note(s) in Receipt Ledger.</div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>
<!-- Floating Buttons -->
<div class="floating-buttons">
    <button class="float-btn" id="todoBtn" title="To-Do List"><i class="fas fa-list-check"></i></button>
</div>

<!-- To-Do List Modal -->
<div class="modal fade" id="todoModal" tabindex="-1" aria-labelledby="todoModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form class="modal-content" id="todoForm" autocomplete="off">
            <div class="modal-header bg-success text-light">
                <h5 class="modal-title" id="todoModalLabel"><i class="fas fa-list-check"></i> To-Do List / Reminders</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <ul class="list-group mb-3" id="todoList"></ul>
                <div class="input-group">
                    <input type="text" class="form-control" id="todoInput" placeholder="Add a new reminder...">
                    <button class="btn btn-success" type="button" id="addTodoBtn"><i class="fas fa-plus"></i></button>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" data-bs-dismiss="modal"><i class="fas fa-save"></i> Done</button>
            </div>
        </form>
    </div>
</div>

<footer class="text-center py-4 text-muted small">
    &copy; <?= date("Y") ?> The Lord's Wisdom Academy Of Caloocan Inc. | School Admin and Finance Management System
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // To-Do List handlers (client-side, localStorage)
    function loadTodos() {
        let todos = JSON.parse(localStorage.getItem('dashboard_todos') || "[]");
        let list = document.getElementById('todoList');
        list.innerHTML = "";
        todos.forEach(function(todo, idx) {
            let li = document.createElement("li");
            li.className = "list-group-item d-flex justify-content-between align-items-center";
            li.innerHTML = `<span>${todo}</span>
                <button type="button" class="btn btn-sm btn-danger" title="Remove" onclick="removeTodo(${idx})"><i class="fas fa-times"></i></button>`;
            list.appendChild(li);
        });
    }
    function saveTodos(todos) {
        localStorage.setItem('dashboard_todos', JSON.stringify(todos));
    }
    function removeTodo(idx) {
        let todos = JSON.parse(localStorage.getItem('dashboard_todos') || "[]");
        todos.splice(idx, 1);
        saveTodos(todos);
        loadTodos();
    }
    document.getElementById('todoBtn').addEventListener('click', function() {
        loadTodos();
        let modal = new bootstrap.Modal(document.getElementById('todoModal'));
        modal.show();
    });
    document.getElementById('addTodoBtn').addEventListener('click', function() {
        let input = document.getElementById('todoInput');
        let val = input.value.trim();
        if (val) {
            let todos = JSON.parse(localStorage.getItem('dashboard_todos') || "[]");
            todos.push(val);
            saveTodos(todos);
            loadTodos();
            input.value = "";
        }
    });
    document.getElementById('todoInput').addEventListener('keydown', function(e){
        if (e.key === 'Enter') document.getElementById('addTodoBtn').click();
    });
</script>
<?= admin_session_warning_script() ?>
</body>
</html>
<?php $conn->close(); ?>


