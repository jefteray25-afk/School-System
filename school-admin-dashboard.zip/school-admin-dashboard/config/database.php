<?php

require_once __DIR__ . '/app-env.php';

if (!function_exists('database_read_config')) {
    /**
     * Load database settings from environment variables first, then from an optional
     * local override file. This keeps the shared codebase stable while allowing
     * stronger production credentials outside the default config.
     */
    function database_read_config(): array
    {
        $config = [
            'host' => getenv('SCHOOL_DB_HOST') ?: 'localhost',
            'user' => getenv('SCHOOL_DB_USER') ?: 'root',
            'pass' => getenv('SCHOOL_DB_PASS') ?: '',
            'name' => getenv('SCHOOL_DB_NAME') ?: 'school_admin',
        ];

        $localConfigPath = __DIR__ . '/database.local.php';
        if (is_file($localConfigPath)) {
            $localConfig = require $localConfigPath;
            if (is_array($localConfig)) {
                $config = array_merge($config, array_intersect_key($localConfig, $config));
            }
        }

        return $config;
    }
}

if (!function_exists('database_open_connection')) {
    /**
     * Open a MySQL connection with safer defaults and generic end-user errors.
     */
    function database_open_connection(?array $override = null): mysqli
    {
        $config = database_read_config();
        if (is_array($override)) {
            $config = array_merge($config, array_intersect_key($override, $config));
        }

        mysqli_report(MYSQLI_REPORT_OFF);
        $connection = @new mysqli(
            (string) $config['host'],
            (string) $config['user'],
            (string) $config['pass'],
            (string) $config['name']
        );

        if ($connection->connect_error) {
            error_log(
                sprintf(
                    'School Admin DB connection failed for "%s@%s/%s": %s',
                    (string) $config['user'],
                    (string) $config['host'],
                    (string) $config['name'],
                    $connection->connect_error
                )
            );

            http_response_code(500);
            exit(app_is_production()
                ? 'A database connection error occurred. Please contact the administrator.'
                : 'A database connection error occurred. Please check local configuration.');
        }

        $connection->set_charset('utf8mb4');
        $connection->query("SET SESSION sql_mode = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'");

        return $connection;
    }
}

$databaseConfig = database_read_config();
$db_host = (string) $databaseConfig['host'];
$db_user = (string) $databaseConfig['user'];
$db_pass = (string) $databaseConfig['pass'];
$db_name = (string) $databaseConfig['name'];

$conn = database_open_connection($databaseConfig);
