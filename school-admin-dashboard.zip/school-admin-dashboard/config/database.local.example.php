<?php

return [
    'host' => 'localhost',
    'user' => 'school_admin_user',
    'pass' => 'change-this-password',
    'name' => 'school_admin',
];
