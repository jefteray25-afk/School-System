<?php

/**
 * Example local environment bootstrap.
 *
 * Copy the values you need into your web server environment, system variables,
 * or a local-only bootstrap include on the live machine.
 *
 * Expected values:
 * - SCHOOL_APP_ENV=local|staging|production
 * - SCHOOL_DB_HOST=localhost
 * - SCHOOL_DB_USER=school_admin_user
 * - SCHOOL_DB_PASS=strong-password
 * - SCHOOL_DB_NAME=school_admin
 */

putenv('SCHOOL_APP_ENV=production');
putenv('SCHOOL_DB_HOST=localhost');
putenv('SCHOOL_DB_USER=school_admin_user');
putenv('SCHOOL_DB_PASS=change-this');
putenv('SCHOOL_DB_NAME=school_admin');
