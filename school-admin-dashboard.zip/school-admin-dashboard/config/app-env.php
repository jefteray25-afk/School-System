<?php

if (!function_exists('app_env')) {
    function app_env(): string
    {
        $value = getenv('SCHOOL_APP_ENV') ?: 'local';
        $value = strtolower(trim((string) $value));
        return in_array($value, ['local', 'staging', 'production'], true) ? $value : 'local';
    }
}

if (!function_exists('app_is_production')) {
    function app_is_production(): bool
    {
        return app_env() === 'production';
    }
}

if (!function_exists('app_env_label')) {
    function app_env_label(): string
    {
        return strtoupper(app_env());
    }
}
