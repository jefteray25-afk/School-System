﻿<?php
require __DIR__ . '/config/database.php';
require_once __DIR__ . '/modules/settings/school-info-helper.php';

$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";
$schoolLogo = '/school-admin-dashboard/uploads/logo1.png';
$schoolContactLine = '';

if (isset($conn) && $conn instanceof mysqli) {
    $conn->set_charset('utf8mb4');
    $schoolInfo = get_school_information($conn);
    $schoolName = school_info_display_name($schoolInfo);
    $schoolLogo = school_info_logo_path($schoolInfo);
    $schoolContactLine = school_info_contact_line($schoolInfo);
}

$assetBase = '/school-admin-dashboard/assets/portal-videos';
$assetPriority = ['mp4', 'webm', 'ogg', 'jpg', 'jpeg', 'png', 'gif'];
$docRoot = rtrim((string) ($_SERVER['DOCUMENT_ROOT'] ?? ''), '/\\');

$tiles = [];
for ($i = 1; $i <= 9; $i++) {
    $slot = sprintf('%02d', $i);
    $found = null;

    foreach ($assetPriority as $ext) {
        $url = sprintf('%s/%s.%s', $assetBase, $slot, $ext);
        $fs = $url;
        if ($docRoot !== '' && str_starts_with($url, '/')) {
            $fs = $docRoot . str_replace('/', DIRECTORY_SEPARATOR, $url);
        }

        if (is_file($fs)) {
            $isVideo = in_array($ext, ['mp4', 'webm', 'ogg'], true);
            $kind = $isVideo ? 'video' : 'image';
            $mime = $isVideo
                ? ($ext === 'webm' ? 'video/webm' : ($ext === 'ogg' ? 'video/ogg' : 'video/mp4'))
                : ($ext === 'png' ? 'image/png' : ($ext === 'gif' ? 'image/gif' : 'image/jpeg'));

            $found = [
                'url' => $url,
                'kind' => $kind,
                'mime' => $mime,
                'slot' => $slot,
            ];
            break;
        }
    }

    // If no asset exists for this slot, show the school logo so the mosaic never looks "broken".
    if ($found === null && is_string($schoolLogo) && $schoolLogo !== '') {
        $tiles[] = [
            'url' => $schoolLogo,
            'kind' => 'image',
            'mime' => 'image/png',
            'slot' => $slot,
            'is_placeholder' => true,
        ];
    } else {
        $tiles[] = $found;
    }
}

// Preferred tile slot that controls sound (1..9). If that slot is not a video,
// we automatically pick the first video tile (so the toggle never "looks broken").
$preferredAudioSlotNumber = 4;
$audioSlotNumber = $preferredAudioSlotNumber;
if ($audioSlotNumber < 1 || $audioSlotNumber > 9) {
    $audioSlotNumber = 4;
}

$selected = $tiles[$audioSlotNumber - 1] ?? null;
if (!is_array($selected) || (($selected['kind'] ?? '') !== 'video')) {
    foreach ($tiles as $idx => $asset) {
        if (is_array($asset) && (($asset['kind'] ?? '') === 'video')) {
            $audioSlotNumber = $idx + 1;
            break;
        }
    }
}

$soundSlot = sprintf('%02d', $audioSlotNumber);
$hasAudioVideo = isset($tiles[$audioSlotNumber - 1]) && is_array($tiles[$audioSlotNumber - 1]) && (($tiles[$audioSlotNumber - 1]['kind'] ?? '') === 'video');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($schoolName) ?> | Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --ink: #0f172a;
            --muted: rgba(15, 23, 42, 0.72);
            --glass: rgba(255, 255, 255, 0.78);
            --glassBorder: rgba(255, 255, 255, 0.55);
            --brandA: #0b3a68;
            --brandB: #2f7bbd;
        }

        html, body {
            height: 100%;
        }

        body {
            margin: 0;
            background: #0b1220;
            color: var(--ink);
            overflow: hidden;
            font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
        }

        .bg-mosaic {
            position: fixed;
            inset: 0;
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            grid-template-rows: repeat(3, minmax(0, 1fr));
            gap: 12px;
            padding: 14px;
            background:
                radial-gradient(1200px 520px at 10% 10%, rgba(47, 123, 189, 0.24), transparent 60%),
                radial-gradient(900px 620px at 85% 20%, rgba(230, 184, 79, 0.18), transparent 62%),
                radial-gradient(920px 640px at 40% 105%, rgba(11, 58, 104, 0.22), transparent 62%),
                linear-gradient(140deg, #0b1220 0%, #0b1220 50%, #111a2b 100%);
        }

        .tile {
            position: relative;
            border-radius: 16px;
            overflow: hidden;
            background:
                radial-gradient(520px 260px at 35% 25%, rgba(47, 123, 189, 0.30), transparent 55%),
                radial-gradient(520px 300px at 70% 80%, rgba(11, 58, 104, 0.32), transparent 60%),
                linear-gradient(140deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02));
            border: 1px solid rgba(255,255,255,0.08);
            box-shadow: 0 22px 55px rgba(0,0,0,0.32);
        }

        .tile video {
            width: 100%;
            height: 100%;
            object-fit: cover;
            filter: saturate(1.12) contrast(1.06) brightness(1.15);
            transform: scale(1.02);
            display: block;
        }

        .tile img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            /* show the whole poster/frame; background fills letterbox areas */
            background: rgba(0,0,0,0.16);
            filter: saturate(1.05) contrast(1.02) brightness(1.14);
            transform: none;
            display: block;
        }

        .tile img.logo-fallback {
            padding: 18px;
            opacity: 0.92;
        }

        /* For very wide banners (or very tall portrait clips), "cover" crops too much.
           We'll auto-apply this class via JS based on aspect ratio. */
        .tile.fit-contain video {
            object-fit: contain;
            transform: none;
            background: rgba(0,0,0,0.16);
        }

        .tile::after {
            content: '';
            position: absolute;
            inset: 0;
            background:
                radial-gradient(500px 260px at 20% 10%, rgba(255,255,255,0.10), transparent 58%),
                linear-gradient(180deg, rgba(0,0,0,0.12), rgba(0,0,0,0.18));
            pointer-events: none;
        }

        .stage-overlay {
            position: fixed;
            inset: 0;
            background:
                radial-gradient(700px 420px at 50% 45%, rgba(255,255,255,0.10), rgba(255,255,255,0.00) 70%),
                linear-gradient(180deg, rgba(0,0,0,0.34), rgba(0,0,0,0.18));
            pointer-events: none;
        }

        .film-grain {
            position: fixed;
            inset: 0;
            pointer-events: none;
            background-image:
                repeating-linear-gradient(0deg, rgba(0,0,0,0.02) 0px, rgba(0,0,0,0.02) 1px, rgba(0,0,0,0.00) 2px, rgba(0,0,0,0.00) 4px),
                repeating-linear-gradient(90deg, rgba(255,255,255,0.04) 0px, rgba(255,255,255,0.04) 1px, rgba(255,255,255,0.00) 2px, rgba(255,255,255,0.00) 6px);
            mix-blend-mode: overlay;
            opacity: 0.32;
        }

        .portal-wrap {
            position: relative;
            z-index: 2;
            height: 100%;
            display: grid;
            place-items: center;
            padding: 26px 14px;
        }

        .portal {
            width: min(980px, 100%);
            border-radius: 22px;
            border: 1px solid var(--glassBorder);
            background: var(--glass);
            box-shadow: 0 40px 120px rgba(15,23,42,0.22), 0 12px 30px rgba(15,23,42,0.18);
            backdrop-filter: blur(14px);
            -webkit-backdrop-filter: blur(14px);
            overflow: hidden;
            position: relative;
            transform: translateY(10px);
            animation: reveal 520ms ease-out forwards;
        }

        @keyframes reveal {
            from { opacity: 0; transform: translateY(14px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .portal::before {
            content: '';
            position: absolute;
            inset: -1px;
            background:
                radial-gradient(600px 260px at 25% 0%, rgba(47, 123, 189, 0.26), transparent 60%),
                radial-gradient(640px 300px at 85% 15%, rgba(11, 58, 104, 0.22), transparent 62%),
                linear-gradient(135deg, rgba(255,255,255,0.64), rgba(255,255,255,0.18));
            opacity: 0.95;
            pointer-events: none;
        }

        .portal-inner {
            position: relative;
            z-index: 1;
            padding: 28px;
        }

        .brand-row {
            display: flex;
            gap: 16px;
            align-items: center;
        }

        .brand-logo {
            width: 74px;
            height: 74px;
            border-radius: 18px;
            background: rgba(255,255,255,0.88);
            border: 1px solid rgba(15,23,42,0.10);
            box-shadow: 0 12px 30px rgba(15,23,42,0.14);
            padding: 8px;
            object-fit: contain;
        }

        .kicker {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 0.92rem;
            color: rgba(11, 58, 104, 0.82);
            letter-spacing: 0.16em;
            text-transform: uppercase;
        }

        .title {
            margin: 6px 0 0 0;
            font-family: ui-serif, Georgia, "Times New Roman", Times, serif;
            font-weight: 800;
            letter-spacing: 0.02em;
            font-size: clamp(1.5rem, 3.6vw, 2.25rem);
            line-height: 1.12;
        }

        .meta {
            margin-top: 8px;
            color: var(--muted);
            font-size: 0.98rem;
        }

        .meta small {
            display: block;
            margin-top: 4px;
        }

        .cta-row {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 18px;
        }

        .cta {
            border: none;
            border-radius: 14px;
            padding: 14px 18px;
            font-weight: 800;
            letter-spacing: 0.02em;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: transform 140ms ease, box-shadow 140ms ease;
            text-decoration: none;
        }

        .cta.primary {
            background: linear-gradient(135deg, var(--brandA), var(--brandB));
            color: #fff;
            box-shadow: 0 18px 35px rgba(11, 58, 104, 0.32);
        }

        .cta.primary:hover,
        .cta.primary:focus {
            transform: translateY(-1px);
            box-shadow: 0 22px 42px rgba(11, 58, 104, 0.36);
            color: #fff;
        }

        .cta.sound {
            background: rgba(255,255,255,0.70);
            border: 1px solid rgba(15,23,42,0.14);
            color: rgba(15,23,42,0.86);
            box-shadow: 0 12px 26px rgba(0,0,0,0.12);
        }

        
        .cta.sound[disabled] {
            opacity: 0.55;
            cursor: not-allowed;
            transform: none !important;
        }
        
        .cta.sound:hover,
        .cta.sound:focus {
            transform: translateY(-1px);
            color: rgba(15,23,42,0.92);
        }

        .grid {
            margin-top: 22px;
            display: grid;
            grid-template-columns: 1.15fr 0.85fr;
            gap: 18px;
        }

        .panel {
            background: rgba(255,255,255,0.58);
            border: 1px solid rgba(15,23,42,0.10);
            border-radius: 18px;
            padding: 18px;
        }

        .panel h3 {
            margin: 0 0 10px 0;
            font-size: 0.98rem;
            font-weight: 900;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            color: rgba(11, 58, 104, 0.85);
        }

        .steps {
            margin: 0;
            padding-left: 18px;
            color: rgba(15,23,42,0.78);
        }

        .steps li {
            margin-bottom: 6px;
        }

        .foot {
            text-align: center;
            margin-top: 14px;
            color: rgba(15,23,42,0.54);
            font-size: 0.9rem;
        }

        @media (max-width: 920px) {
            .grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 520px) {
            .bg-mosaic {
                gap: 10px;
                padding: 10px;
            }
            .tile {
                border-radius: 14px;
            }
            .portal-inner {
                padding: 20px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            .portal {
                animation: none;
                transform: none;
            }
            .tile video {
                display: none;
            }
        }
    </style>
</head>
<body>
<div class="bg-mosaic" aria-hidden="true">
<?php foreach ($tiles as $idx => $asset): $tileSlot = sprintf("%02d", $idx + 1); $isAudioTile = ($tileSlot === $soundSlot); ?>
<div class="tile" data-slot="<?= htmlspecialchars($tileSlot) ?>">
            <?php if (is_array($asset) && ($asset['kind'] ?? '') === 'video'): ?>
                <video muted loop autoplay playsinline preload="metadata" <?= $isAudioTile ? "id=\"portalAudioVideo\"" : "" ?>>
                    <source src="<?= htmlspecialchars((string) $asset['url']) ?>" type="<?= htmlspecialchars((string) $asset['mime']) ?>">
                </video>
            <?php elseif (is_array($asset) && ($asset['kind'] ?? '') === 'image'): ?>
                <img src="<?= htmlspecialchars((string) $asset['url']) ?>" class="<?= !empty($asset['is_placeholder']) ? 'logo-fallback' : '' ?>" alt="" loading="lazy" decoding="async">
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>
<div class="stage-overlay" aria-hidden="true"></div>
<div class="film-grain" aria-hidden="true"></div>

<div class="portal-wrap">
    <div class="portal">
        <div class="portal-inner">
            <div class="brand-row">
                <img class="brand-logo" src="<?= htmlspecialchars($schoolLogo) ?>" alt="School Logo">
                <div>
                    <div class="kicker"><i class="fa-solid fa-school"></i> Enrollment Portal</div>
                    <h1 class="title"><?= htmlspecialchars($schoolName) ?></h1>
                    <div class="meta">
                        <?= $schoolContactLine !== '' ? htmlspecialchars($schoolContactLine) : 'Please complete the student registration form to enter the approval queue.' ?>
                        <small><i class="fa-solid fa-shield-halved"></i> Submissions go to the admin pending queue before being added to the student master list.</small>
                    </div>
                    <div class="cta-row">
                        <a class="cta primary" href="student-registration.php">
                            <i class="fa-solid fa-user-plus"></i>
                            Start Student Registration
                        </a>
                        <button class="cta sound" type="button" id="soundToggle" aria-pressed="false" title="Toggle sound for tile <?= htmlspecialchars($soundSlot) ?>" <?= $hasAudioVideo ? "" : "disabled" ?>>
                            <i class="fa-solid fa-volume-xmark"></i>
                            <span><?= $hasAudioVideo ? "Sound Off" : "No Sound" ?></span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="grid">
                <div class="panel">
                    <h3>What Happens Next</h3>
                    <ol class="steps">
                        <li>Fill out student details and submit.</li>
                        <li>Admin reviews the request in the pending queue.</li>
                        <li>Once approved, the student appears in Registrar and Finance.</li>
                    </ol>
                </div>
                <div class="panel">
                    <h3>Tiles</h3>
                    <div class="text-muted">
                        Add assets named <strong>01</strong> through <strong>09</strong> in <code><?= htmlspecialchars($assetBase) ?></code> (mp4/webm/ogg/jpg/png/gif).
                    </div>
                </div>
            </div>

            <div class="foot">&copy; <?= date('Y') ?> School Admin Dashboard</div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function () {
  const btn = document.getElementById('soundToggle');
  const video = document.getElementById('portalAudioVideo');
  if (!btn || !video) return;
  if (btn.hasAttribute('disabled')) return;

  // Default muted; browsers block autoplay with sound.
  video.muted = true;
  video.volume = 0.65;

  function setState(on) {
    btn.setAttribute('aria-pressed', on ? 'true' : 'false');
    const icon = btn.querySelector('i');
    const label = btn.querySelector('span');
    if (icon) icon.className = on ? 'fa-solid fa-volume-high' : 'fa-solid fa-volume-xmark';
    if (label) label.textContent = on ? 'Sound On' : 'Sound Off';
  }

  setState(false);

  btn.addEventListener('click', async function () {
    const isOn = btn.getAttribute('aria-pressed') === 'true';
    if (isOn) {
      video.muted = true;
      setState(false);
      return;
    }

    try {
      video.muted = false;
      await video.play();
      setState(true);
    } catch (e) {
      // If playback is blocked, keep it muted and keep UI off.
      video.muted = true;
      setState(false);
    }
  });
})();
</script>
<script>
(function () {
  // Auto-fix "banner" videos: if the aspect ratio is too wide or too tall,
  // switch to contain so the whole frame is visible (no cropping).
  const WIDE_RATIO = 2.10;
  const TALL_RATIO = 0.70;

  document.querySelectorAll('.tile video').forEach((v) => {
    function applyFit() {
      const w = v.videoWidth || 0;
      const h = v.videoHeight || 0;
      if (!w || !h) return;
      const r = w / h;
      if (r > WIDE_RATIO || r < TALL_RATIO) {
        const tile = v.closest('.tile');
        if (tile) tile.classList.add('fit-contain');
      }
    }

    v.addEventListener('loadedmetadata', applyFit, { passive: true });
    if (v.readyState >= 1) applyFit();
  });
})();
</script>
</body>
</html>



