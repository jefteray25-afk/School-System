    <footer>
        <hr>
        <p style="text-align:center;">&copy; <?= date("Y") ?> School Admin Dashboard</p>
    </footer>
</body>
</html>