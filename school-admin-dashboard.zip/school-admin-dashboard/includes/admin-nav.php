<?php

if (!function_exists('school_year_get_active_label')) {
    require_once __DIR__ . '/../modules/settings/school-year-helper.php';
}

function is_limited_admin_operator_role(?string $role): bool
{
    return in_array((string) $role, ['Administrator 1', 'Administrator 2'], true);
}

function render_admin_nav(string $activeKey, bool $showThemeToggle = false): void
{
    $username = $_SESSION['username'] ?? '';
    $role = $_SESSION['role'] ?? '';
    $items = [
        'dashboard' => ['/school-admin-dashboard/Dashboard.php', 'Dashboard'],
        'logbook' => ['/school-admin-dashboard/modules/logbook/logbook.php', 'Logbook'],
        'search' => ['/school-admin-dashboard/modules/search/global-search.php', 'Global Search'],
        'students' => ['/school-admin-dashboard/modules/students/student-list.php', 'Registrar'],
        'accounts' => ['/school-admin-dashboard/modules/accounts/account-list.php', 'Finance'],
        'old_accounts' => ['/school-admin-dashboard/modules/old accounts/student-old-account-list.php', 'Old Accounts'],
        'fees' => ['/school-admin-dashboard/modules/financial/fee-list.php', 'Fees'],
        'invoice' => ['/school-admin-dashboard/modules/invoice/invoice-view.php', 'Invoice'],
        'reports' => ['/school-admin-dashboard/modules/reports/reports-dashboard.php', 'Reports'],
        'rollover' => ['/school-admin-dashboard/modules/rollover/year-end-rollover.php', 'Year-End Rollover'],
        'settings' => ['/school-admin-dashboard/modules/settings/settings-dashboard.php', 'Settings'],
    ];

    if (is_limited_admin_operator_role($role) || function_exists('is_specialized_staff_role') && is_specialized_staff_role($role)) {
        unset($items['search']);
    }
    if (function_exists('is_view_staff_role') && is_view_staff_role($role)) {
        unset($items['search'], $items['fees'], $items['settings']);
    }
    if ($role === 'Staff') {
        unset($items['reports']);
    }
    if (function_exists('is_registrar_staff_role') && is_registrar_staff_role($role)) {
        unset($items['logbook'], $items['accounts'], $items['old_accounts'], $items['fees'], $items['invoice'], $items['reports']);
    }
    if (function_exists('is_accounting_staff_role') && is_accounting_staff_role($role)) {
        unset($items['students'], $items['old_accounts'], $items['fees']);
    }
    if (function_exists('can_access_reports_dashboard') && !can_access_reports_dashboard($role)) {
        unset($items['reports']);
    }
    if (function_exists('can_access_year_end_rollover') && !can_access_year_end_rollover($role)) {
        unset($items['rollover']);
    }
    $activeSchoolYearLabel = '';
    if (isset($GLOBALS['conn']) && $GLOBALS['conn'] instanceof mysqli) {
        $activeSchoolYearLabel = school_year_get_active_label($GLOBALS['conn']);
    }
    ?>
    <style>
        :root {
            --app-topbar-height: 0px;
            --app-sidebar-width: 248px;
        }
        body {
            padding-top: 0 !important;
            padding-left: calc(var(--app-sidebar-width) + 14px) !important;
        }
        .app-topbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1040;
            height: var(--app-topbar-height);
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 1rem;
            padding: 0.55rem 1.15rem 0.55rem calc(var(--app-sidebar-width) + 1.3rem);
            background: transparent !important;
            border-bottom: 0 !important;
            box-shadow: none !important;
            pointer-events: none;
        }
        .app-topbar-actions {
            display: flex;
            align-items: center;
            gap: 0.65rem;
            pointer-events: auto;
        }
        .app-sidebar-user .badge {
            font-size: 0.72rem;
            font-weight: 600;
        }
        .app-sidebar-toggle,
        .theme-toggle-btn {
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            width: 40px !important;
            height: 40px !important;
            border-radius: 10px !important;
            border: 1px solid rgba(255, 255, 255, 0.14) !important;
            color: rgba(248, 251, 255, 0.92) !important;
            background: rgba(255, 255, 255, 0.06) !important;
            box-shadow: none !important;
        }
        .app-sidebar-toggle:hover,
        .theme-toggle-btn:hover {
            background: rgba(255, 255, 255, 0.12) !important;
            color: #ffffff !important;
        }
        .app-sidebar {
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            z-index: 1035;
            width: var(--app-sidebar-width);
            padding: 1rem 0.9rem 1rem;
            display: flex;
            flex-direction: column;
            background: linear-gradient(180deg, #203a5f 0%, #233f66 40%, #1d3452 100%);
            border-right: 1px solid rgba(255, 255, 255, 0.08);
            box-shadow: 12px 0 30px rgba(24, 42, 68, 0.12);
            overflow-y: auto;
        }
        .app-sidebar-brand {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            padding: 0.4rem 0.45rem 0.9rem;
            text-decoration: none;
            color: #f8fbff;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 0.95rem;
        }
        .app-sidebar-brand i {
            font-size: 1.18rem;
        }
        .app-sidebar .brand-stack {
            display: flex;
            flex-direction: column;
            line-height: 1.08;
        }
        .app-sidebar .brand-title {
            color: #ffffff;
            font-size: 1rem;
            font-weight: 700;
        }
        .app-sidebar .brand-year {
            margin-top: 0.16rem;
            color: rgba(255, 255, 255, 0.72);
            font-size: 0.78rem;
            font-weight: 500;
        }
        .app-sidebar-nav {
            display: flex;
            flex-direction: column;
            gap: 0.28rem;
            flex: 1 1 auto;
        }
        .app-sidebar-link {
            display: flex;
            align-items: center;
            justify-content: space-between;
            min-height: 42px;
            padding: 0.62rem 0.8rem;
            border-radius: 12px;
            color: rgba(248, 251, 255, 0.9);
            font-size: 0.94rem;
            font-weight: 600;
            line-height: 1.2;
            text-decoration: none;
            border: 1px solid transparent;
            transition: background-color 0.18s ease, border-color 0.18s ease, color 0.18s ease, transform 0.18s ease;
        }
        .app-sidebar-link:hover,
        .app-sidebar-link:focus {
            color: #ffffff;
            background: rgba(255, 255, 255, 0.08);
            border-color: rgba(255, 255, 255, 0.08);
            transform: translateX(1px);
        }
        .app-sidebar-link.active {
            color: #ffffff;
            background: rgba(255, 255, 255, 0.15);
            border-color: rgba(255, 255, 255, 0.12);
            box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.03);
        }
        .app-sidebar-group {
            border-radius: 14px;
        }
        .app-sidebar-group[open] {
            background: rgba(255, 255, 255, 0.05);
        }
        .app-sidebar-group-summary {
            list-style: none;
            cursor: pointer;
        }
        .app-sidebar-group-summary::-webkit-details-marker {
            display: none;
        }
        .app-sidebar-group-summary .caret {
            font-size: 0.82rem;
            transition: transform 0.18s ease;
        }
        .app-sidebar-group[open] .app-sidebar-group-summary .caret {
            transform: rotate(90deg);
        }
        .app-sidebar-subnav {
            display: flex;
            flex-direction: column;
            gap: 0.22rem;
            padding: 0.2rem 0.35rem 0.45rem 1rem;
        }
        .app-sidebar-subnav .app-sidebar-link {
            min-height: 36px;
            padding: 0.52rem 0.75rem;
            font-size: 0.88rem;
            font-weight: 600;
            color: rgba(248, 251, 255, 0.82);
        }
        .app-sidebar-user {
            margin-top: auto;
            padding: 0.95rem 0.9rem;
            border-radius: 16px;
            background: rgba(255, 255, 255, 0.07);
            border: 1px solid rgba(255, 255, 255, 0.08);
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.04);
        }
        .app-sidebar-user-label {
            display: flex;
            align-items: center;
            gap: 0.55rem;
            color: #ffffff;
            font-size: 0.94rem;
            font-weight: 700;
            margin-bottom: 0.45rem;
        }
        .app-sidebar-user-name {
            color: rgba(248, 251, 255, 0.95);
            font-size: 0.93rem;
            font-weight: 600;
            margin-bottom: 0.6rem;
            word-break: break-word;
        }
        .app-sidebar-user-role {
            margin-bottom: 0;
        }
        .app-sidebar-logout-dock {
            padding-top: 1rem;
            margin-top: 1rem;
            border-top: 1px solid rgba(255, 255, 255, 0.08);
        }
        .app-sidebar-logout {
            width: 100%;
            border-radius: 10px;
        }
        .app-sidebar-footer {
            margin-top: auto;
            padding-top: 1.4rem;
        }
        @media (min-width: 992px) {
            .app-topbar {
                display: none;
            }
            .app-sidebar-toggle {
                display: none !important;
            }
            .app-sidebar.collapse {
                display: flex !important;
            }
            .app-sidebar.collapse.show {
                display: flex !important;
            }
        }
        @media (max-width: 991.98px) {
            :root {
                --app-topbar-height: 58px;
            }
            body {
                padding-left: 0 !important;
                padding-top: calc(var(--app-topbar-height) + 8px) !important;
            }
            .app-topbar {
                display: flex;
                padding: 0.9rem 1rem !important;
                background: linear-gradient(90deg, #203a5f 0%, #27486f 52%, #2c537d 100%) !important;
                border-bottom: 1px solid rgba(255, 255, 255, 0.12) !important;
                box-shadow: 0 12px 28px rgba(24, 42, 68, 0.16) !important;
                pointer-events: auto;
            }
            .app-sidebar {
                width: min(320px, calc(100vw - 1rem));
                max-width: 100%;
                top: calc(var(--app-topbar-height) + 6px);
                left: 0.5rem;
                bottom: 0.75rem;
                border-radius: 18px;
                border: 1px solid rgba(255, 255, 255, 0.1);
                box-shadow: 0 16px 36px rgba(18, 33, 54, 0.28);
            }
            .app-sidebar.collapse.show {
                display: flex !important;
            }
        }
    </style>
    <header class="app-topbar">
        <div class="app-topbar-actions">
            <?php if ($showThemeToggle): ?>
                <button class="theme-toggle-btn" id="themeToggleBtn" title="Toggle theme">
                    <i class="fas fa-moon"></i>
                </button>
            <?php endif; ?>
            <button class="btn app-sidebar-toggle" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavSidebar" aria-controls="mainNavSidebar" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </header>
    <aside class="app-sidebar collapse show" id="mainNavSidebar">
        <a class="app-sidebar-brand" href="/school-admin-dashboard/Dashboard.php">
            <i class="fas fa-graduation-cap"></i>
            <span class="brand-stack">
                <span class="brand-title">School Admin</span>
                <?php if ($activeSchoolYearLabel !== ''): ?>
                    <span class="brand-year"><?= htmlspecialchars($activeSchoolYearLabel) ?></span>
                <?php endif; ?>
            </span>
        </a>
        <nav class="app-sidebar-nav">
            <?php foreach ($items as $key => [$href, $label]): ?>
                <a class="app-sidebar-link<?= $activeKey === $key ? ' active' : '' ?>" href="<?= htmlspecialchars($href) ?>">
                    <span><?= htmlspecialchars($label) ?></span>
                </a>
            <?php endforeach; ?>
        </nav>
        <div class="app-sidebar-footer">
            <div class="app-sidebar-user">
                <div class="app-sidebar-user-label">
                    <i class="fas fa-user-shield"></i>
                    <span>Current Session</span>
                </div>
                <div class="app-sidebar-user-name"><?= htmlspecialchars($username) ?></div>
                <div class="app-sidebar-user-role"><span class="badge bg-secondary"><?= htmlspecialchars($role) ?></span></div>
            </div>
            <div class="app-sidebar-logout-dock">
                <a href="/school-admin-dashboard/logout.php" class="btn btn-sm btn-outline-light app-sidebar-logout">
                    <i class="fas fa-sign-out-alt me-2"></i>Logout
                </a>
            </div>
        </div>
    </aside>
    <?php
}
