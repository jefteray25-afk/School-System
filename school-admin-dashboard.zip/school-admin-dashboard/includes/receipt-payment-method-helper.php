<?php
require_once __DIR__ . '/schema-migration.php';

function receipt_payment_methods_set_last_error(string $message): void
{
    $GLOBALS['receipt_payment_methods_last_error'] = $message;
}

function receipt_payment_methods_last_error(): string
{
    return (string) ($GLOBALS['receipt_payment_methods_last_error'] ?? '');
}

function receipt_payment_methods_table_exists(mysqli $conn): bool
{
    $result = $conn->query("SHOW TABLES LIKE 'receipt_payment_methods'");
    $exists = $result instanceof mysqli_result && $result->num_rows > 0;
    if ($result instanceof mysqli_result) {
        $result->close();
    }
    return $exists;
}

function receipt_payment_methods_supported_methods(): array
{
    return ['Cash', 'GCash', 'Bank Transfer'];
}

function ensure_receipt_payment_methods_table(mysqli $conn): void
{
    if (receipt_payment_methods_table_exists($conn)) {
        return;
    }
    schema_migration_attempt($conn, "
        CREATE TABLE IF NOT EXISTS receipt_payment_methods (
            id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            booklet_no INT(11) NOT NULL,
            receipt_no INT(11) NOT NULL,
            used_by VARCHAR(40) NOT NULL,
            method_name VARCHAR(30) NOT NULL,
            amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            reference_number VARCHAR(80) DEFAULT NULL,
            note VARCHAR(255) DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            KEY idx_receipt_payment_methods_lookup (booklet_no, receipt_no),
            KEY idx_receipt_payment_methods_used_by (used_by),
            KEY idx_receipt_payment_methods_method (method_name)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
}

function receipt_payment_methods_normalize(array $rawMethods): array
{
    $normalized = [];
    foreach ($rawMethods as $row) {
        if (!is_array($row)) {
            continue;
        }
        $method = trim((string) ($row['method'] ?? ''));
        $amount = round((float) str_replace(',', '', (string) ($row['amount'] ?? '0')), 2);
        $referenceNumber = trim((string) ($row['reference_number'] ?? ''));
        $note = trim((string) ($row['note'] ?? ''));
        if ($method === '' && $amount <= 0 && $referenceNumber === '' && $note === '') {
            continue;
        }
        $normalized[] = [
            'method' => $method,
            'amount' => $amount,
            'reference_number' => $referenceNumber,
            'note' => $note,
        ];
    }
    return $normalized;
}

function receipt_payment_methods_total(array $methods): float
{
    $total = 0.0;
    foreach ($methods as $method) {
        $total += (float) ($method['amount'] ?? 0);
    }
    return round($total, 2);
}

function receipt_payment_methods_validate(array $methods, float $expectedTotal, ?string &$error = null): bool
{
    $error = null;
    if (!$methods) {
        $error = 'Add at least one payment method breakdown.';
        return false;
    }
    if (count($methods) > 3) {
        $error = 'Only up to 3 payment methods can be used in one receipt.';
        return false;
    }

    $supported = receipt_payment_methods_supported_methods();
    $seen = [];
    foreach ($methods as $index => $methodRow) {
        $lineNo = $index + 1;
        $method = (string) ($methodRow['method'] ?? '');
        $amount = (float) ($methodRow['amount'] ?? 0);
        $referenceNumber = trim((string) ($methodRow['reference_number'] ?? ''));

        if ($method === '' || !in_array($method, $supported, true)) {
            $error = "Payment method row {$lineNo} is invalid.";
            return false;
        }
        if (isset($seen[$method])) {
            $error = "Payment method {$method} can only be used once per receipt.";
            return false;
        }
        $seen[$method] = true;
        if ($amount <= 0) {
            $error = "Payment method row {$lineNo} must have an amount greater than zero.";
            return false;
        }
        if (($method === 'GCash' || $method === 'Bank Transfer') && $referenceNumber === '') {
            $error = "Reference number is required for {$method}.";
            return false;
        }
    }

    $actualTotal = receipt_payment_methods_total($methods);
    if (abs($actualTotal - round($expectedTotal, 2)) > 0.009) {
        $error = 'Payment method breakdown total must match the total posted payment amount.';
        return false;
    }
    return true;
}

function receipt_payment_methods_replace_for_receipt(mysqli $conn, int $bookletNo, int $receiptNo, string $usedBy, array $methods): bool
{
    receipt_payment_methods_set_last_error('');
    ensure_receipt_payment_methods_table($conn);
    if (!receipt_payment_methods_table_exists($conn)) {
        receipt_payment_methods_set_last_error(
            schema_migration_missing_schema_message('split payment method breakdowns')
        );
        return false;
    }

    $deleteStmt = $conn->prepare('DELETE FROM receipt_payment_methods WHERE booklet_no = ? AND receipt_no = ?');
    if (!$deleteStmt) {
        receipt_payment_methods_set_last_error('Failed to prepare payment method cleanup: ' . $conn->error);
        return false;
    }
    $deleteStmt->bind_param('ii', $bookletNo, $receiptNo);
    if (!$deleteStmt->execute()) {
        receipt_payment_methods_set_last_error('Failed to clear existing payment method rows: ' . $deleteStmt->error);
        $deleteStmt->close();
        return false;
    }
    $deleteStmt->close();

    $insertStmt = $conn->prepare('
        INSERT INTO receipt_payment_methods (booklet_no, receipt_no, used_by, method_name, amount, reference_number, note)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ');
    if (!$insertStmt) {
        receipt_payment_methods_set_last_error('Failed to prepare payment method insert: ' . $conn->error);
        return false;
    }

    foreach ($methods as $methodRow) {
        $method = (string) ($methodRow['method'] ?? '');
        $amount = round((float) ($methodRow['amount'] ?? 0), 2);
        $referenceNumber = trim((string) ($methodRow['reference_number'] ?? ''));
        $note = trim((string) ($methodRow['note'] ?? ''));
        $insertStmt->bind_param('iissdss', $bookletNo, $receiptNo, $usedBy, $method, $amount, $referenceNumber, $note);
        if (!$insertStmt->execute()) {
            receipt_payment_methods_set_last_error('Failed to insert payment method row: ' . $insertStmt->error);
            $insertStmt->close();
            return false;
        }
    }

    $insertStmt->close();
    return true;
}

function receipt_payment_methods_build_legacy_summary(array $methods, string $overallNote = ''): array
{
    $overallNote = trim($overallNote);
    if (!$methods) {
        return [
            'method_label' => '',
            'reference_summary' => '',
            'note_summary' => $overallNote,
        ];
    }

    if (count($methods) === 1) {
        $method = $methods[0];
        return [
            'method_label' => (string) ($method['method'] ?? ''),
            'reference_summary' => trim((string) ($method['reference_number'] ?? '')),
            'note_summary' => $overallNote,
        ];
    }

    $parts = [];
    $referenceParts = [];
    foreach ($methods as $method) {
        $methodName = (string) ($method['method'] ?? '');
        $amount = (float) ($method['amount'] ?? 0);
        $parts[] = $methodName . ': PHP ' . number_format($amount, 2);
        $referenceNumber = trim((string) ($method['reference_number'] ?? ''));
        if ($referenceNumber !== '') {
            $referenceParts[] = $methodName . ': ' . $referenceNumber;
        }
    }

    $noteSummary = 'Split: ' . implode('; ', $parts);
    if ($overallNote !== '') {
        $noteSummary .= ' | Note: ' . $overallNote;
    }

    return [
        'method_label' => 'Split Payment',
        'reference_summary' => implode('; ', $referenceParts),
        'note_summary' => $noteSummary,
    ];
}

function receipt_payment_methods_summary_text(array $methods): string
{
    $parts = [];
    foreach ($methods as $method) {
        $methodName = trim((string) ($method['method'] ?? ''));
        $amount = (float) ($method['amount'] ?? 0);
        if ($methodName === '' || $amount <= 0) {
            continue;
        }
        $part = $methodName . ': PHP ' . number_format($amount, 2);
        $referenceNumber = trim((string) ($method['reference_number'] ?? ''));
        if ($referenceNumber !== '') {
            $part .= ' (Ref#: ' . $referenceNumber . ')';
        }
        $parts[] = $part;
    }
    return implode('; ', $parts);
}

function receipt_payment_methods_load(mysqli $conn, int $bookletNo, int $receiptNo, ?string $usedBy = null): array
{
    ensure_receipt_payment_methods_table($conn);
    if ($usedBy !== null && $usedBy !== '') {
        $stmt = $conn->prepare('
            SELECT method_name, amount, reference_number, note
            FROM receipt_payment_methods
            WHERE booklet_no = ? AND receipt_no = ? AND used_by = ?
            ORDER BY id ASC
        ');
        if (!$stmt) {
            return [];
        }
        $stmt->bind_param('iis', $bookletNo, $receiptNo, $usedBy);
    } else {
        $stmt = $conn->prepare('
            SELECT method_name, amount, reference_number, note
            FROM receipt_payment_methods
            WHERE booklet_no = ? AND receipt_no = ?
            ORDER BY id ASC
        ');
        if (!$stmt) {
            return [];
        }
        $stmt->bind_param('ii', $bookletNo, $receiptNo);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $methods = [];
    while ($row = $result->fetch_assoc()) {
        $methods[] = [
            'method' => (string) ($row['method_name'] ?? ''),
            'amount' => (float) ($row['amount'] ?? 0),
            'reference_number' => trim((string) ($row['reference_number'] ?? '')),
            'note' => trim((string) ($row['note'] ?? '')),
        ];
    }
    $stmt->close();
    return $methods;
}

function receipt_payment_methods_from_legacy_fields(?string $methodLabel, ?string $referenceNumber = null, ?string $paymentNote = null): array
{
    $methodLabel = trim((string) $methodLabel);
    $referenceNumber = trim((string) $referenceNumber);
    $paymentNote = trim((string) $paymentNote);
    if ($methodLabel === '') {
        return [];
    }
    return [[
        'method' => $methodLabel,
        'amount' => 0.0,
        'reference_number' => $referenceNumber,
        'note' => $paymentNote,
    ]];
}

function receipt_payment_methods_for_display(mysqli $conn, int $bookletNo, int $receiptNo, ?string $usedBy, ?string $legacyMethodLabel = null, ?string $legacyReference = null, ?string $legacyPaymentNote = null): array
{
    $methods = [];
    if ($bookletNo > 0 && $receiptNo > 0) {
        $methods = receipt_payment_methods_load($conn, $bookletNo, $receiptNo, $usedBy);
    }
    if ($methods) {
        return $methods;
    }
    return receipt_payment_methods_from_legacy_fields($legacyMethodLabel, $legacyReference, $legacyPaymentNote);
}

function receipt_payment_methods_display_label(array $methods, string $fallback = 'Not Set'): string
{
    if (!$methods) {
        return $fallback;
    }
    if (count($methods) === 1) {
        return trim((string) ($methods[0]['method'] ?? '')) ?: $fallback;
    }
    return 'Split Payment';
}

function receipt_payment_methods_reference_display(array $methods, string $fallback = '-'): string
{
    if (!$methods) {
        return $fallback;
    }
    $parts = [];
    foreach ($methods as $method) {
        $referenceNumber = trim((string) ($method['reference_number'] ?? ''));
        if ($referenceNumber === '') {
            continue;
        }
        $methodName = trim((string) ($method['method'] ?? ''));
        $parts[] = ($methodName !== '' ? $methodName . ': ' : '') . $referenceNumber;
    }
    return $parts ? implode('; ', $parts) : $fallback;
}

function receipt_payment_methods_note_display(array $methods, string $fallback = '-'): string
{
    if (!$methods) {
        return $fallback;
    }
    $parts = [];
    foreach ($methods as $method) {
        $note = trim((string) ($method['note'] ?? ''));
        if ($note === '') {
            continue;
        }
        $methodName = trim((string) ($method['method'] ?? ''));
        $parts[] = ($methodName !== '' ? $methodName . ': ' : '') . $note;
    }
    return $parts ? implode('; ', $parts) : $fallback;
}

function receipt_payment_methods_is_legacy_placeholder(array $methods): bool
{
    if (count($methods) !== 1) {
        return false;
    }

    $methodName = trim((string) ($methods[0]['method'] ?? ''));
    $amount = (float) ($methods[0]['amount'] ?? 0);

    return $methodName !== '' && $amount <= 0;
}

function receipt_payment_methods_extract_reference_from_text(?string $text): string
{
    $text = trim((string) $text);
    if ($text === '') {
        return '';
    }

    if (preg_match('/Ref#:\s*([^\)]+)/i', $text, $matches)) {
        return trim((string) ($matches[1] ?? ''));
    }

    return '';
}
