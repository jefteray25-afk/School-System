<?php

function record_conflict_normalize_value($value): string
{
    if ($value === null) {
        return '';
    }

    if (is_bool($value)) {
        return $value ? '1' : '0';
    }

    if (is_float($value)) {
        return number_format($value, 2, '.', '');
    }

    if (is_int($value)) {
        return (string) $value;
    }

    return trim((string) $value);
}

function record_conflict_token(array $payload): string
{
    ksort($payload);
    $normalized = [];
    foreach ($payload as $key => $value) {
        $normalized[(string) $key] = record_conflict_normalize_value($value);
    }

    return hash('sha256', json_encode($normalized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

function student_record_conflict_payload(array $row): array
{
    return [
        'lastname' => $row['lastname'] ?? '',
        'firstname' => $row['firstname'] ?? '',
        'middlename' => $row['middlename'] ?? '',
        'lrn' => $row['lrn'] ?? '',
        'birthday' => $row['birthday'] ?? '',
        'age' => $row['age'] ?? '',
        'gender' => $row['gender'] ?? '',
        'address' => $row['address'] ?? '',
        'contact' => $row['contact'] ?? '',
        'grade' => $row['grade'] ?? '',
        'strand' => $row['strand'] ?? '',
        'section' => $row['section'] ?? '',
        'date_enrolled' => $row['date_enrolled'] ?? '',
        'photo' => $row['photo'] ?? '',
        'guardian_name' => $row['guardian_name'] ?? '',
        'guardian_contact' => $row['guardian_contact'] ?? '',
        'school_year_label' => $row['school_year_label'] ?? '',
    ];
}

function account_record_conflict_payload(array $row): array
{
    return [
        'type' => $row['type'] ?? '',
        'balance' => isset($row['balance']) ? (float) $row['balance'] : 0,
        'notes' => $row['notes'] ?? '',
        'school_year_label' => $row['school_year_label'] ?? '',
    ];
}
