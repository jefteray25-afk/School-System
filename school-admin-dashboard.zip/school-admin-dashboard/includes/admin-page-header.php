<?php

function render_school_page_header(
    string $schoolName,
    ?string $schoolLogo = '/school-admin-dashboard/uploads/logo1.png',
    string $subtitle = '',
    string $wrapperClass = 'dashboard-header',
    string $imageClass = 'mb-2 rounded shadow-sm',
    string $subtitleClass = ''
): void {
    ?>
    <div class="<?= htmlspecialchars($wrapperClass) ?>">
        <?php if ($schoolLogo !== null && trim($schoolLogo) !== ''): ?>
            <img src="<?= htmlspecialchars($schoolLogo) ?>" alt="School Logo" class="<?= htmlspecialchars($imageClass) ?>">
        <?php endif; ?>
        <h1><?= htmlspecialchars($schoolName) ?></h1>
        <?php if (trim($subtitle) !== ''): ?>
            <p<?= $subtitleClass !== '' ? ' class="' . htmlspecialchars($subtitleClass) . '"' : '' ?>><?= htmlspecialchars($subtitle) ?></p>
        <?php endif; ?>
    </div>
    <?php
}
