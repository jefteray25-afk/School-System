<?php

/**
 * Schema migration control.
 *
 * Goal (Phase 3): prevent runtime CREATE/ALTER during normal page loads.
 * Only allow schema changes when the migration runner explicitly enables it.
 */

if (!function_exists('schema_migration_mode_enabled')) {
    function schema_migration_mode_enabled(): bool
    {
        return defined('SCHOOL_SCHEMA_MIGRATION_MODE') && SCHOOL_SCHEMA_MIGRATION_MODE === true;
    }
}

if (!function_exists('schema_migration_attempt')) {
    /**
     * Execute a schema-changing SQL statement only in migration mode.
     */
    function schema_migration_attempt(mysqli $conn, string $sql): bool
    {
        if (!schema_migration_mode_enabled()) {
            return false;
        }

        return $conn->query($sql) === true;
    }
}

if (!function_exists('schema_migration_notice')) {
    function schema_migration_notice(string $message): void
    {
        if (PHP_SAPI === 'cli') {
            fwrite(STDOUT, $message . PHP_EOL);
            return;
        }

        // Do not echo in web mode; keep it silent.
        error_log($message);
    }
}

if (!function_exists('schema_migration_missing_schema_message')) {
    function schema_migration_missing_schema_message(string $feature): string
    {
        return 'Database schema is not ready for ' . $feature . '. Run tools/migrate.php on the server/admin machine.';
    }
}

