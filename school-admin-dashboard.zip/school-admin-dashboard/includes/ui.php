<?php

if (!function_exists('ui_alert')) {
    function ui_alert(string $type, string $message, bool $dismissible = true): void
    {
        $type = in_array($type, ['success', 'danger', 'warning', 'info', 'primary', 'secondary', 'light', 'dark'], true)
            ? $type
            : 'info';

        $message = trim($message);
        if ($message === '') {
            return;
        }

        $classes = 'alert alert-' . $type;
        if ($dismissible) {
            $classes .= ' alert-dismissible fade show';
        }

        echo '<div class="' . htmlspecialchars($classes) . '" role="alert">';
        echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
        if ($dismissible) {
            echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
        }
        echo '</div>';
    }
}

if (!function_exists('ui_css_link')) {
    function ui_css_link(): void
    {
        echo '<link rel="stylesheet" href="/school-admin-dashboard/assets/css/app-ui.css">';
    }
}

