﻿<?php
/**
 * Receipt Registry Helper Functions
 * Usage: include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/includes-receipt-helper.php';
 * All functions assume $conn (mysqli) database connection is available.
 */

require_once __DIR__ . '/schema-migration.php';

const REGULAR_BOOKLET_MIN = 230;
const REGULAR_BOOKLET_MAX = 1000;
const REGULAR_BOOKLET_RECEIPT_ANCHOR = 269;
const REGULAR_RECEIPT_START = 13451;
const REGULAR_RECEIPTS_PER_BOOKLET = 50;

const SPECIAL_BOOKLET_MIN = 1;
const SPECIAL_BOOKLET_MAX = 1000;
const SPECIAL_BOOKLET_STORAGE_OFFSET = 1000;
const SPECIAL_RECEIPT_START = 1;
const SPECIAL_RECEIPTS_PER_BOOKLET = 50;

function is_regular_booklet_number(int $booklet_no): bool {
    return $booklet_no >= REGULAR_BOOKLET_MIN && $booklet_no <= REGULAR_BOOKLET_MAX;
}

function is_legacy_special_booklet_number(int $booklet_no): bool {
    return $booklet_no >= 1 && $booklet_no <= 100;
}

function is_special_booklet_storage_number(int $booklet_no): bool {
    return $booklet_no >= (SPECIAL_BOOKLET_STORAGE_OFFSET + SPECIAL_BOOKLET_MIN)
        && $booklet_no <= (SPECIAL_BOOKLET_STORAGE_OFFSET + SPECIAL_BOOKLET_MAX);
}

function booklet_storage_to_display_parts(int $booklet_no): array {
    if (is_special_booklet_storage_number($booklet_no)) {
        $display = $booklet_no - SPECIAL_BOOKLET_STORAGE_OFFSET;
        return [$display, true];
    }

    if (is_legacy_special_booklet_number($booklet_no)) {
        return [$booklet_no + (SPECIAL_BOOKLET_MIN - 1), true];
    }

    return [$booklet_no, false];
}

function booklet_display_to_storage_number(int $display_no, bool $is_special): int {
    if ($is_special) {
        return SPECIAL_BOOKLET_STORAGE_OFFSET + $display_no;
    }

    return $display_no;
}

function parse_booklet_input_to_storage($raw): ?int {
    $value = trim((string) $raw);
    if ($value === '') {
        return null;
    }

    if (preg_match('/^S\s*([0-9]+)$/i', $value, $matches)) {
        $display = (int) $matches[1];
        if ($display >= SPECIAL_BOOKLET_MIN && $display <= SPECIAL_BOOKLET_MAX) {
            return booklet_display_to_storage_number($display, true);
        }
        return null;
    }

    if (!preg_match('/^[0-9]+$/', $value)) {
        return null;
    }

    $numeric = (int) $value;
    if (is_special_booklet_storage_number($numeric) || is_regular_booklet_number($numeric) || is_legacy_special_booklet_number($numeric)) {
        return $numeric;
    }

    if ($numeric >= SPECIAL_BOOKLET_MIN && $numeric <= SPECIAL_BOOKLET_MAX) {
        return booklet_display_to_storage_number($numeric, true);
    }

    return null;
}

function booklet_label_from_stored(int $booklet_no): string {
    [$display, $is_special] = booklet_storage_to_display_parts($booklet_no);
    return $is_special ? 'S' . $display : (string) $display;
}

function receipt_window_for_regular_booklet(int $booklet_no): array {
    $start = REGULAR_RECEIPT_START + ($booklet_no - REGULAR_BOOKLET_RECEIPT_ANCHOR) * REGULAR_RECEIPTS_PER_BOOKLET;
    $end = $start + REGULAR_RECEIPTS_PER_BOOKLET - 1;
    return [$start, $end];
}

function receipt_window_for_special_booklet_display(int $display_no): array {
    $start = SPECIAL_RECEIPT_START + ($display_no - SPECIAL_BOOKLET_MIN) * SPECIAL_RECEIPTS_PER_BOOKLET;
    $end = $start + SPECIAL_RECEIPTS_PER_BOOKLET - 1;
    return [$start, $end];
}

function receipt_window_for_booklet(int $booklet_no): array {
    [$display, $is_special] = booklet_storage_to_display_parts($booklet_no);

    if ($is_special) {
        return receipt_window_for_special_booklet_display($display);
    }

    return receipt_window_for_regular_booklet($display);
}

function booklet_filter_storage_values(int $booklet_no): array {
    if (!is_special_booklet_storage_number($booklet_no)) {
        return [$booklet_no];
    }

    $display_no = $booklet_no - SPECIAL_BOOKLET_STORAGE_OFFSET;
    if ($display_no >= SPECIAL_BOOKLET_MIN && $display_no <= 100) {
        return [$display_no, $booklet_no];
    }

    return [$booklet_no];
}

function ensure_receipts_registry_schema(mysqli $conn): void {
    static $initialized = false;
    if ($initialized) {
        return;
    }

    if (!schema_migration_mode_enabled()) {
        $initialized = true;
        return;
    }

    $columnResult = $conn->query("SHOW COLUMNS FROM receipts_registry LIKE 'used_by'");
    $column = $columnResult ? $columnResult->fetch_assoc() : null;
    $columnType = strtolower((string) ($column['Type'] ?? ''));

    if ($columnType !== '' && strpos($columnType, "'other_payment'") === false) {
        schema_migration_attempt($conn, "ALTER TABLE receipts_registry MODIFY COLUMN used_by ENUM('payments','old_student_payments','other_payment') NOT NULL");
    }

    $indexResult = $conn->query("SHOW INDEX FROM receipts_registry WHERE Key_name = 'idx_receipts_registry_booklet_receipt'");
    if ($indexResult && $indexResult->num_rows === 0) {
        schema_migration_attempt($conn, "CREATE INDEX idx_receipts_registry_booklet_receipt ON receipts_registry (booklet_no, receipt_no)");
    }

    $blankUsedByResult = $conn->query("SELECT COUNT(*) AS blank_count FROM receipts_registry WHERE used_by = ''");
    $blankUsedByCount = 0;
    if ($blankUsedByResult) {
        $blankUsedByRow = $blankUsedByResult->fetch_assoc();
        $blankUsedByCount = (int) ($blankUsedByRow['blank_count'] ?? 0);
    }

    if ($blankUsedByCount > 0) {
        // Backfill legacy rows created before other_payment was added to the enum.
        schema_migration_attempt($conn, "
            UPDATE receipts_registry rr
            INNER JOIN other_payments op ON op.payment_id = rr.used_id
            SET rr.used_by = 'other_payment'
            WHERE rr.used_by = ''
        ");

        schema_migration_attempt($conn, "
            UPDATE receipts_registry
            SET used_by = 'payments'
            WHERE used_by = '' AND used_id > 0
        ");
    }

    $initialized = true;
}

function ensure_receipt_history_table(mysqli $conn): void {
    ensure_receipts_registry_schema($conn);
    static $initialized = false;
    if ($initialized) {
        return;
    }

    if (!schema_migration_mode_enabled()) {
        $initialized = true;
        return;
    }

    $sql = "
    CREATE TABLE IF NOT EXISTS receipt_registry_history (
        id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
        receipt_no INT(11) NOT NULL,
        booklet_no INT(11) NOT NULL,
        action_type VARCHAR(32) NOT NULL,
        used_by VARCHAR(64) DEFAULT NULL,
        used_id INT(11) DEFAULT NULL,
        reason VARCHAR(255) DEFAULT NULL,
        actor_username VARCHAR(100) DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ";
    schema_migration_attempt($conn, $sql);
    $initialized = true;
}

function receipt_registry_actor(): string {
    return $_SESSION['username'] ?? 'system';
}

function log_receipt_registry_event(mysqli $conn, int $receipt_no, int $booklet_no, string $action_type, ?string $used_by = null, ?int $used_id = null, ?string $reason = null, ?string $actor_username = null): bool {
    ensure_receipt_history_table($conn);
    $actor = $actor_username ?? receipt_registry_actor();
    $stmt = $conn->prepare("INSERT INTO receipt_registry_history (receipt_no, booklet_no, action_type, used_by, used_id, reason, actor_username) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iississ", $receipt_no, $booklet_no, $action_type, $used_by, $used_id, $reason, $actor);
    $success = $stmt->execute();
    $stmt->close();
    return $success;
}

function get_receipt_registry_entry(mysqli $conn, int $receipt_no, ?int $booklet_no = null): ?array {
    ensure_receipts_registry_schema($conn);
    if ($booklet_no !== null) {
        $stmt = $conn->prepare("SELECT receipt_no, booklet_no, used_by, used_id, used_at, voided, void_reason, voided_by, voided_at FROM receipts_registry WHERE receipt_no = ? AND booklet_no = ? LIMIT 1");
        $stmt->bind_param("ii", $receipt_no, $booklet_no);
    } else {
        $stmt = $conn->prepare("SELECT receipt_no, booklet_no, used_by, used_id, used_at, voided, void_reason, voided_by, voided_at FROM receipts_registry WHERE receipt_no = ? LIMIT 1");
        $stmt->bind_param("i", $receipt_no);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $entry = $result ? $result->fetch_assoc() : null;
    $stmt->close();
    return $entry ?: null;
}

/**
 * Checks if a receipt number is already used globally (excluding voided).
 * Returns true if used, false if available.
 */
function is_receipt_used(mysqli $conn, int $receipt_no, ?int $booklet_no = null): bool {
    ensure_receipts_registry_schema($conn);
    if ($booklet_no !== null) {
        $stmt = $conn->prepare("SELECT COUNT(*) FROM receipts_registry WHERE receipt_no = ? AND booklet_no = ? AND voided = 0");
        $stmt->bind_param("ii", $receipt_no, $booklet_no);
    } else {
        $stmt = $conn->prepare("SELECT COUNT(*) FROM receipts_registry WHERE receipt_no = ? AND voided = 0");
        $stmt->bind_param("i", $receipt_no);
    }
    $stmt->execute();
    $stmt->bind_result($used);
    $stmt->fetch();
    $stmt->close();
    return $used > 0;
}

function reserve_receipt(mysqli $conn, int $receipt_no, int $booklet_no, string $used_by): bool {
    ensure_receipts_registry_schema($conn);
    if (is_receipt_used($conn, $receipt_no, $booklet_no)) {
        return false;
    }
    $stmt = $conn->prepare("INSERT INTO receipts_registry (receipt_no, booklet_no, used_by, used_id) VALUES (?, ?, ?, 0)");
    $stmt->bind_param("iis", $receipt_no, $booklet_no, $used_by);
    $success = $stmt->execute();
    $stmt->close();
    if ($success) {
        log_receipt_registry_event($conn, $receipt_no, $booklet_no, 'issued', $used_by, 0, 'Initial receipt issue');
    }
    return $success;
}

function reserve_or_reuse_receipt(mysqli $conn, int $receipt_no, int $booklet_no, string $used_by, ?string $reason = null): array {
    ensure_receipts_registry_schema($conn);
    $existing = get_receipt_registry_entry($conn, $receipt_no, $booklet_no);
    if (!$existing) {
        $success = reserve_receipt($conn, $receipt_no, $booklet_no, $used_by);
        return ['success' => $success, 'reused' => false, 'message' => $success ? '' : 'Failed to reserve receipt.'];
    }

    if ((int) $existing['voided'] === 0) {
        return ['success' => false, 'reused' => false, 'message' => 'Receipt is already active.'];
    }

    $stmt = $conn->prepare("UPDATE receipts_registry SET used_by = ?, used_id = 0, used_at = CURRENT_TIMESTAMP, voided = 0, void_reason = NULL, voided_by = NULL, voided_at = NULL WHERE receipt_no = ? AND booklet_no = ?");
    $stmt->bind_param("sii", $used_by, $receipt_no, $booklet_no);
    $success = $stmt->execute();
    $stmt->close();

    if ($success) {
        $reuseReason = $reason ?: 'Reused after prior void';
        log_receipt_registry_event($conn, $receipt_no, $booklet_no, 'reused', $used_by, 0, $reuseReason);
    }

    return ['success' => $success, 'reused' => true, 'message' => $success ? '' : 'Failed to reuse voided receipt.'];
}

function attach_receipt_to_payment(mysqli $conn, int $receipt_no, int $payment_id, ?int $booklet_no = null): bool {
    ensure_receipts_registry_schema($conn);
    $entry = get_receipt_registry_entry($conn, $receipt_no, $booklet_no);
    if ($booklet_no !== null) {
        $stmt = $conn->prepare("UPDATE receipts_registry SET used_id = ? WHERE receipt_no = ? AND booklet_no = ?");
        $stmt->bind_param("iii", $payment_id, $receipt_no, $booklet_no);
    } else {
        $stmt = $conn->prepare("UPDATE receipts_registry SET used_id = ? WHERE receipt_no = ?");
        $stmt->bind_param("ii", $payment_id, $receipt_no);
    }
    $success = $stmt->execute();
    $stmt->close();
    if ($success && $entry) {
        log_receipt_registry_event(
            $conn,
            $receipt_no,
            (int) $entry['booklet_no'],
            'linked',
            $entry['used_by'],
            $payment_id,
            'Receipt linked to payment record'
        );
    }
    return $success;
}

function get_next_receipt_no_in_range(mysqli $conn, int $start, int $end): int {
    ensure_receipts_registry_schema($conn);
    $stmt = $conn->prepare("SELECT receipt_no FROM receipts_registry WHERE receipt_no BETWEEN ? AND ? AND voided = 0 ORDER BY receipt_no ASC");
    $stmt->bind_param("ii", $start, $end);
    $stmt->execute();
    $result = $stmt->get_result();
    $used = [];
    while ($row = $result->fetch_assoc()) {
        $used[] = (int) $row['receipt_no'];
    }
    $stmt->close();

    for ($receipt = $start; $receipt <= $end; $receipt++) {
        if (!in_array($receipt, $used, true)) {
            return $receipt;
        }
    }

    return $end + 1;
}

function get_next_regular_receipt_no(mysqli $conn): int {
    // Prefer the currently visible payment booklet (configured in Settings > Receipt Registry).
    ensure_receipt_booklet_registry($conn);

    $stmt = $conn->prepare("SELECT storage_number FROM receipt_booklet_registry WHERE booklet_type = 'regular' AND is_active = 1 AND status = 'active' ORDER BY display_number ASC LIMIT 1");
    $preferredStorage = null;
    if ($stmt) {
        $stmt->execute();
        $stmt->bind_result($preferredStorage);
        $stmt->fetch();
        $stmt->close();
    }

    if ($preferredStorage) {
        [$start, $end] = receipt_window_for_booklet((int) $preferredStorage);
        return get_next_receipt_no_in_range($conn, $start, $end);
    }

    // Fallback: global scan (supports back-entry ranges).
    [$start, ] = receipt_window_for_booklet(REGULAR_BOOKLET_MIN);
    [, $end] = receipt_window_for_booklet(REGULAR_BOOKLET_MAX);
    return get_next_receipt_no_in_range($conn, $start, $end);
}

function get_next_special_receipt_no(mysqli $conn): int {
    ensure_receipt_booklet_registry($conn);

    $stmt = $conn->prepare("SELECT storage_number FROM receipt_booklet_registry WHERE booklet_type = 'special' AND is_active = 1 AND status = 'active' ORDER BY display_number ASC LIMIT 1");
    $preferredStorage = null;
    if ($stmt) {
        $stmt->execute();
        $stmt->bind_result($preferredStorage);
        $stmt->fetch();
        $stmt->close();
    }

    if ($preferredStorage) {
        [$start, $end] = receipt_window_for_booklet((int) $preferredStorage);
        return get_next_receipt_no_in_range($conn, $start, $end);
    }

    [$start, ] = receipt_window_for_booklet(booklet_display_to_storage_number(SPECIAL_BOOKLET_MIN, true));
    [, $end] = receipt_window_for_booklet(booklet_display_to_storage_number(SPECIAL_BOOKLET_MAX, true));
    return get_next_receipt_no_in_range($conn, $start, $end);
}

function get_next_receipt_no(mysqli $conn): int {
    ensure_receipts_registry_schema($conn);
    $stmt = $conn->prepare("SELECT MAX(receipt_no) FROM receipts_registry WHERE receipt_no IS NOT NULL AND voided = 0");
    $stmt->execute();
    $stmt->bind_result($max_receipt_no);
    $stmt->fetch();
    $stmt->close();
    $next = $max_receipt_no ? ($max_receipt_no + 1) : REGULAR_RECEIPT_START;
    return $next;
}

function get_receipts_for_booklet(mysqli $conn, int $booklet_no): array {
    ensure_receipts_registry_schema($conn);
    [$start, $end] = receipt_window_for_booklet($booklet_no);
    $stmt = $conn->prepare("SELECT receipt_no FROM receipts_registry WHERE booklet_no = ? AND receipt_no BETWEEN ? AND ? AND voided = 0");
    $stmt->bind_param("iii", $booklet_no, $start, $end);
    $stmt->execute();
    $res = $stmt->get_result();
    $used = [];
    while ($row = $res->fetch_assoc()) {
        $used[] = intval($row['receipt_no']);
    }
    $stmt->close();
    $next = null;
    for ($i = $start; $i <= $end; $i++) {
        if (!in_array($i, $used, true)) {
            $next = $i;
            break;
        }
    }
    return [$used, $next];
}

function ensure_payments_void_archive_table(mysqli $conn): void {
    static $initialized = false;
    if ($initialized) {
        return;
    }

    if (!schema_migration_mode_enabled()) {
        $initialized = true;
        return;
    }

    schema_migration_attempt($conn, "
        CREATE TABLE IF NOT EXISTS payments_voided (
            id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            original_payment_id INT(11) NOT NULL,
            account_id INT(11) NOT NULL,
            amount DECIMAL(10,2) NOT NULL,
            date_paid DATETIME NOT NULL,
            remarks VARCHAR(255) NULL,
            created_at TIMESTAMP NULL,
            official_receipt VARCHAR(50) NULL,
            receipt_no INT(11) NULL,
            receipt_note VARCHAR(255) NULL,
            reference_number VARCHAR(80) NULL,
            payment_note TEXT NULL,
            booklet_no INT(11) NULL,
            school_year_label VARCHAR(30) NULL,
            void_reason VARCHAR(255) NULL,
            voided_by INT(11) NULL,
            voided_at DATETIME NOT NULL,
            voided_receipt_no INT(11) NULL,
            voided_booklet_no INT(11) NULL,
            KEY idx_voided_original_payment (original_payment_id),
            KEY idx_voided_account (account_id),
            KEY idx_voided_voided_at (voided_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");

    $colRef = $conn->query("SHOW COLUMNS FROM payments_voided LIKE 'reference_number'");
    if ($colRef && $colRef->num_rows === 0) {
        schema_migration_attempt($conn, "ALTER TABLE payments_voided ADD COLUMN reference_number VARCHAR(80) NULL AFTER receipt_note");
    }
    $colNote = $conn->query("SHOW COLUMNS FROM payments_voided LIKE 'payment_note'");
    if ($colNote && $colNote->num_rows === 0) {
        schema_migration_attempt($conn, "ALTER TABLE payments_voided ADD COLUMN payment_note TEXT NULL AFTER reference_number");
    }

    $initialized = true;
}

function ensure_payments_prepared_by_column(mysqli $conn): void {
    static $initialized = false;
    if ($initialized) {
        return;
    }

    if (!schema_migration_mode_enabled()) {
        $initialized = true;
        return;
    }

    $res = $conn->query("SHOW COLUMNS FROM payments LIKE 'prepared_by'");
    if ($res && $res->num_rows === 0) {
        schema_migration_attempt($conn, "ALTER TABLE payments ADD COLUMN prepared_by VARCHAR(100) NULL AFTER receipt_note");
    }

    $initialized = true;
}

function ensure_payments_reference_note_columns(mysqli $conn): void
{
    static $initialized = false;
    if ($initialized) {
        return;
    }

    if (!schema_migration_mode_enabled()) {
        $initialized = true;
        return;
    }

    $res = $conn->query("SHOW COLUMNS FROM payments LIKE 'reference_number'");
    if ($res && $res->num_rows === 0) {
        schema_migration_attempt($conn, "ALTER TABLE payments ADD COLUMN reference_number VARCHAR(80) NULL AFTER receipt_note");
    }

    $res2 = $conn->query("SHOW COLUMNS FROM payments LIKE 'payment_note'");
    if ($res2 && $res2->num_rows === 0) {
        schema_migration_attempt($conn, "ALTER TABLE payments ADD COLUMN payment_note TEXT NULL AFTER reference_number");
    }

    $initialized = true;
}

function void_receipt(mysqli $conn, int $receipt_no, string $void_reason, int $voided_by, ?int $booklet_no = null): bool {
    ensure_receipts_registry_schema($conn);

    // receipts_registry is keyed by receipt_no. If the caller provides a booklet number that
    // doesn't match the stored row (migration/back-entry edge cases), fall back to receipt_no
    // lookup so Super Admin can still void the receipt safely.
    $entry = get_receipt_registry_entry($conn, $receipt_no, $booklet_no);
    if (!$entry && $booklet_no !== null) {
        $entry = get_receipt_registry_entry($conn, $receipt_no, null);
    }

    if (!$entry || (int) $entry['voided'] === 1) {
        return false;
    }

    $effectiveBookletNo = (int) ($entry['booklet_no'] ?? 0);

    // Archive table is DDL and may auto-commit; do it before the transaction.
    $usedBy = (string) ($entry['used_by'] ?? '');
    if ($usedBy === 'payments' || $usedBy === 'other_payment') {
        ensure_payments_void_archive_table($conn);
    }

    $conn->begin_transaction();

    // If booklet matches, void the exact row; otherwise void by receipt_no only (safe because unique).
    if ($booklet_no !== null && $effectiveBookletNo === (int) $booklet_no) {
        $stmt = $conn->prepare("UPDATE receipts_registry SET voided = 1, void_reason = ?, voided_by = ?, voided_at = NOW() WHERE receipt_no = ? AND booklet_no = ? AND voided = 0");
        $stmt->bind_param("siii", $void_reason, $voided_by, $receipt_no, $booklet_no);
    } else {
        $stmt = $conn->prepare("UPDATE receipts_registry SET voided = 1, void_reason = ?, voided_by = ?, voided_at = NOW() WHERE receipt_no = ? AND voided = 0");
        $stmt->bind_param("sii", $void_reason, $voided_by, $receipt_no);
    }
    $success = $stmt->execute();
    $stmt->close();
    if (!$success) {
        $conn->rollback();
        return false;
    }

    $historyOk = log_receipt_registry_event(
        $conn,
        $receipt_no,
        $effectiveBookletNo,
        'voided',
        $entry['used_by'],
        (int) $entry['used_id'],
        $void_reason
    );
    if (!$historyOk) {
        $conn->rollback();
        return false;
    }

    // IMPORTANT: For your workflow, voiding a receipt means the linked payment was an error.
    // We reverse it: move payment row to payments_voided archive, restore account balance, and
    // remove the payment from active tables so SOA/Payment Desk no longer treats it as paid.
    $usedId = (int) ($entry['used_id'] ?? 0);
    if ($usedId > 0 && ($usedBy === 'payments' || $usedBy === 'other_payment')) {
        $payments = [];
        if ($effectiveBookletNo > 0) {
            $payStmt = $conn->prepare("
                SELECT id, account_id, amount, date_paid, remarks, created_at, official_receipt, receipt_no, receipt_note, reference_number, payment_note, booklet_no, school_year_label
                FROM payments
                WHERE receipt_no = ? AND booklet_no = ?
                ORDER BY id ASC
            ");
            $payStmt->bind_param('ii', $receipt_no, $effectiveBookletNo);
        } else {
            $payStmt = $conn->prepare("
                SELECT id, account_id, amount, date_paid, remarks, created_at, official_receipt, receipt_no, receipt_note, reference_number, payment_note, booklet_no, school_year_label
                FROM payments
                WHERE receipt_no = ?
                ORDER BY id ASC
            ");
            $payStmt->bind_param('i', $receipt_no);
        }
        $payStmt->execute();
        $payRes = $payStmt->get_result();
        while ($payRes && $paymentRow = $payRes->fetch_assoc()) {
            $payments[] = $paymentRow;
        }
        $payStmt->close();

        if (!$payments) {
            $fallbackStmt = $conn->prepare("SELECT id, account_id, amount, date_paid, remarks, created_at, official_receipt, receipt_no, receipt_note, reference_number, payment_note, booklet_no, school_year_label FROM payments WHERE id = ? LIMIT 1");
            $fallbackStmt->bind_param('i', $usedId);
            $fallbackStmt->execute();
            $fallbackRes = $fallbackStmt->get_result();
            $fallbackPayment = $fallbackRes ? $fallbackRes->fetch_assoc() : null;
            $fallbackStmt->close();
            if ($fallbackPayment) {
                $payments[] = $fallbackPayment;
            }
        }

        foreach ($payments as $payment) {
            $amount = (float) ($payment['amount'] ?? 0);
            $accountId = (int) ($payment['account_id'] ?? 0);

            $restore = $conn->prepare("UPDATE accounts SET balance = balance + ? WHERE id = ?");
            $restore->bind_param('di', $amount, $accountId);
            if (!$restore->execute()) {
                $restore->close();
                $conn->rollback();
                return false;
            }
            $restore->close();

            $archive = $conn->prepare("
                INSERT INTO payments_voided (
                    original_payment_id, account_id, amount, date_paid, remarks, created_at,
                    official_receipt, receipt_no, receipt_note, reference_number, payment_note, booklet_no, school_year_label,
                    void_reason, voided_by, voided_at, voided_receipt_no, voided_booklet_no
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?)
            ");
            if (!$archive) {
                $conn->rollback();
                return false;
            }
            $origPaymentId = (int) ($payment['id'] ?? 0);
            $paidAt = (string) ($payment['date_paid'] ?? '');
            $remarks = (string) ($payment['remarks'] ?? '');
            $createdAt = $payment['created_at'] ?? null;
            $officialReceipt = $payment['official_receipt'] ?? null;
            $origReceiptNo = $payment['receipt_no'] ?? null;
            $receiptNote = $payment['receipt_note'] ?? null;
            $referenceNumber = $payment['reference_number'] ?? null;
            $paymentNote = $payment['payment_note'] ?? null;
            $origBookletNo = $payment['booklet_no'] ?? null;
            $schoolYear = $payment['school_year_label'] ?? null;

            $archive->bind_param(
                'iidssssisssissiii',
                $origPaymentId,
                $accountId,
                $amount,
                $paidAt,
                $remarks,
                $createdAt,
                $officialReceipt,
                $origReceiptNo,
                $receiptNote,
                $referenceNumber,
                $paymentNote,
                $origBookletNo,
                $schoolYear,
                $void_reason,
                $voided_by,
                $receipt_no,
                $effectiveBookletNo
            );
            if (!$archive->execute()) {
                $archive->close();
                $conn->rollback();
                return false;
            }
            $archive->close();

            $paymentId = (int) ($payment['id'] ?? 0);
            if ($usedBy === 'other_payment') {
                $cleanupOther = $conn->prepare("DELETE FROM other_payments WHERE payment_id = ?");
                $cleanupOther->bind_param('i', $paymentId);
                $cleanupOther->execute();
                $cleanupOther->close();
            }

            $deletePay = $conn->prepare("DELETE FROM payments WHERE id = ?");
            $deletePay->bind_param('i', $paymentId);
            if (!$deletePay->execute()) {
                $deletePay->close();
                $conn->rollback();
                return false;
            }
            $deletePay->close();
        }
    } elseif ($usedId > 0 && $usedBy === 'old_student_payments') {
        // Legacy: detach only (old_student_payments already has deleted_at for manual workflows).
        $detach = $conn->prepare("
            UPDATE old_student_payments
            SET receipt_no = NULL,
                booklet_no = NULL,
                note = CASE
                    WHEN note IS NULL OR TRIM(note) = '' THEN 'Receipt voided'
                    WHEN note LIKE '%Receipt voided%' THEN note
                    ELSE CONCAT(note, ' (Receipt voided)')
                END
            WHERE id = ?
        ");
        if ($detach) {
            $detach->bind_param('i', $usedId);
            $detach->execute();
            $detach->close();
        }
    }

    $conn->commit();
    return true;
}

function get_receipt_history(mysqli $conn, ?int $receipt_no = null, int $limit = 100, ?int $booklet_no = null): array {
    ensure_receipt_history_table($conn);
    if ($receipt_no && $booklet_no !== null) {
        $stmt = $conn->prepare("SELECT receipt_no, booklet_no, action_type, used_by, used_id, reason, actor_username, created_at FROM receipt_registry_history WHERE receipt_no = ? AND booklet_no = ? ORDER BY created_at DESC, id DESC LIMIT ?");
        $stmt->bind_param("iii", $receipt_no, $booklet_no, $limit);
    } elseif ($receipt_no) {
        $stmt = $conn->prepare("SELECT receipt_no, booklet_no, action_type, used_by, used_id, reason, actor_username, created_at FROM receipt_registry_history WHERE receipt_no = ? ORDER BY created_at DESC, id DESC LIMIT ?");
        $stmt->bind_param("ii", $receipt_no, $limit);
    } else {
        $stmt = $conn->prepare("SELECT receipt_no, booklet_no, action_type, used_by, used_id, reason, actor_username, created_at FROM receipt_registry_history ORDER BY created_at DESC, id DESC LIMIT ?");
        $stmt->bind_param("i", $limit);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    $stmt->close();
    return $rows;
}

function receipt_booklet_registry_seed_rows(): array {
    static $rows = null;
    if ($rows !== null) {
        return $rows;
    }

    $rows = [];

    for ($bookletNo = REGULAR_BOOKLET_MIN; $bookletNo <= REGULAR_BOOKLET_MAX; $bookletNo++) {
        [$rangeStart, $rangeEnd] = receipt_window_for_regular_booklet($bookletNo);
        $rows[] = [
            'booklet_code' => (string) $bookletNo,
            'booklet_type' => 'regular',
            'display_number' => $bookletNo,
            'storage_number' => $bookletNo,
            'range_start' => $rangeStart,
            'range_end' => $rangeEnd,
        ];
    }

    for ($displayNo = SPECIAL_BOOKLET_MIN; $displayNo <= SPECIAL_BOOKLET_MAX; $displayNo++) {
        [$rangeStart, $rangeEnd] = receipt_window_for_special_booklet_display($displayNo);
        $rows[] = [
            'booklet_code' => 'S' . $displayNo,
            'booklet_type' => 'special',
            'display_number' => $displayNo,
            'storage_number' => booklet_display_to_storage_number($displayNo, true),
            'range_start' => $rangeStart,
            'range_end' => $rangeEnd,
        ];
    }

    return $rows;
}

function ensure_receipt_booklet_registry(mysqli $conn): void {
    static $initialized = false;
    if ($initialized) {
        return;
    }

    if (!schema_migration_mode_enabled()) {
        $initialized = true;
        return;
    }

    schema_migration_attempt($conn, "
        CREATE TABLE IF NOT EXISTS receipt_booklet_registry (
            id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            booklet_code VARCHAR(32) NOT NULL,
            booklet_type ENUM('regular','special') NOT NULL,
            display_number INT(11) NOT NULL,
            storage_number INT(11) NOT NULL,
            range_start INT(11) NOT NULL,
            range_end INT(11) NOT NULL,
            status ENUM('active','non_active','full','archived') NOT NULL DEFAULT 'active',
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            notes VARCHAR(255) DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_receipt_booklet_code (booklet_code),
            UNIQUE KEY uniq_receipt_booklet_storage (storage_number),
            KEY idx_receipt_booklet_type (booklet_type),
            KEY idx_receipt_booklet_status (status),
            KEY idx_receipt_booklet_active (is_active),
            KEY idx_receipt_booklet_display (display_number)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");

    $statusResult = $conn->query("SHOW COLUMNS FROM receipt_booklet_registry LIKE 'status'");
    $statusColumn = $statusResult ? $statusResult->fetch_assoc() : null;
    $statusType = strtolower((string) ($statusColumn['Type'] ?? ''));
    if ($statusType !== '' && strpos($statusType, "'non_active'") === false) {
        schema_migration_attempt($conn, "ALTER TABLE receipt_booklet_registry MODIFY COLUMN status ENUM('active','non_active','full','archived') NOT NULL DEFAULT 'active'");
    }

    $isActiveResult = $conn->query("SHOW COLUMNS FROM receipt_booklet_registry LIKE 'is_active'");
    if (!$isActiveResult || $isActiveResult->num_rows === 0) {
        schema_migration_attempt($conn, "ALTER TABLE receipt_booklet_registry ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER status");
        schema_migration_attempt($conn, "CREATE INDEX idx_receipt_booklet_active ON receipt_booklet_registry (is_active)");
    }

    $notesResult = $conn->query("SHOW COLUMNS FROM receipt_booklet_registry LIKE 'notes'");
    if (!$notesResult || $notesResult->num_rows === 0) {
        schema_migration_attempt($conn, "ALTER TABLE receipt_booklet_registry ADD COLUMN notes VARCHAR(255) DEFAULT NULL AFTER is_active");
    }

    $seedRows = receipt_booklet_registry_seed_rows();
    $seedRowCount = count($seedRows);
    $countResult = $conn->query("SELECT COUNT(*) AS total_rows FROM receipt_booklet_registry");
    $existingRowCount = 0;
    if ($countResult) {
        $countRow = $countResult->fetch_assoc();
        $existingRowCount = (int) ($countRow['total_rows'] ?? 0);
    }

    if ($existingRowCount < $seedRowCount) {
        $insertSql = "
            INSERT INTO receipt_booklet_registry (
                booklet_code,
                booklet_type,
                display_number,
                storage_number,
                range_start,
                range_end,
                status,
                is_active
            ) VALUES (?, ?, ?, ?, ?, ?, 'active', 1)
            ON DUPLICATE KEY UPDATE
                booklet_type = VALUES(booklet_type),
                display_number = VALUES(display_number),
                storage_number = VALUES(storage_number),
                range_start = VALUES(range_start),
                range_end = VALUES(range_end)
        ";
        $stmt = $conn->prepare($insertSql);
        foreach ($seedRows as $row) {
            $stmt->bind_param(
                "ssiiii",
                $row['booklet_code'],
                $row['booklet_type'],
                $row['display_number'],
                $row['storage_number'],
                $row['range_start'],
                $row['range_end']
            );
            $stmt->execute();
        }
        $stmt->close();
    }

    $initialized = true;
}

function receipt_booklet_registry_rows(mysqli $conn, ?string $type = null): array {
    ensure_receipt_booklet_registry($conn);

    if ($type === 'regular' || $type === 'special') {
        $stmt = $conn->prepare("
            SELECT booklet_code, booklet_type, display_number, storage_number, range_start, range_end, status, is_active, notes, created_at, updated_at
            FROM receipt_booklet_registry
            WHERE booklet_type = ?
            ORDER BY display_number ASC
        ");
        $stmt->bind_param("s", $type);
    } else {
        $stmt = $conn->prepare("
            SELECT booklet_code, booklet_type, display_number, storage_number, range_start, range_end, status, is_active, notes, created_at, updated_at
            FROM receipt_booklet_registry
            ORDER BY FIELD(booklet_type, 'regular', 'special'), display_number ASC
        ");
    }

    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    $stmt->close();
    return $rows;
}

function receipt_booklet_registry_summary(mysqli $conn): array {
    ensure_receipt_booklet_registry($conn);

    $summarySql = "
        SELECT
            COUNT(*) AS total_booklets,
            SUM(CASE WHEN booklet_type = 'regular' THEN 1 ELSE 0 END) AS regular_booklets,
            SUM(CASE WHEN booklet_type = 'special' THEN 1 ELSE 0 END) AS special_booklets,
            SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) AS active_booklets,
            SUM(CASE WHEN status = 'non_active' THEN 1 ELSE 0 END) AS non_active_booklets,
            SUM(CASE WHEN status = 'full' THEN 1 ELSE 0 END) AS full_booklets,
            SUM(CASE WHEN status = 'archived' THEN 1 ELSE 0 END) AS archived_booklets,
            MIN(created_at) AS first_seeded_at,
            MAX(updated_at) AS last_updated_at
        FROM receipt_booklet_registry
    ";
    return $conn->query($summarySql)->fetch_assoc() ?: [];
}

function receipt_booklet_registry_payment_rows(mysqli $conn, string $type, bool $active_only = false): array {
    ensure_receipt_booklet_registry($conn);

    if ($active_only) {
        $stmt = $conn->prepare("
            SELECT booklet_code, booklet_type, display_number, storage_number, range_start, range_end, status, is_active, notes
            FROM receipt_booklet_registry
            WHERE booklet_type = ? AND is_active = 1 AND status = 'active'
            ORDER BY display_number ASC
        ");
        $stmt->bind_param("s", $type);
    } else {
        $stmt = $conn->prepare("
            SELECT booklet_code, booklet_type, display_number, storage_number, range_start, range_end, status, is_active, notes
            FROM receipt_booklet_registry
            WHERE booklet_type = ?
            ORDER BY display_number ASC
        ");
        $stmt->bind_param("s", $type);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    $stmt->close();
    return $rows;
}

function receipt_booklet_registry_payment_summary(mysqli $conn): array {
    ensure_receipt_booklet_registry($conn);

    $summarySql = "
        SELECT
            COUNT(*) AS total_visible,
            SUM(CASE WHEN booklet_type = 'regular' THEN 1 ELSE 0 END) AS regular_visible,
            SUM(CASE WHEN booklet_type = 'special' THEN 1 ELSE 0 END) AS special_visible
        FROM receipt_booklet_registry
        WHERE is_active = 1 AND status = 'active'
    ";
    return $conn->query($summarySql)->fetch_assoc() ?: [];
}

function receipt_booklet_registry_status_options(): array {
    return [
        'active' => 'Active',
        'non_active' => 'Non-active',
        'full' => 'Full',
        'archived' => 'Archived',
    ];
}

function receipt_booklet_registry_update(mysqli $conn, int $storage_number, string $status, int $is_active, ?string $notes = null): array {
    ensure_receipt_booklet_registry($conn);

    $status = trim($status);
    $status_options = receipt_booklet_registry_status_options();
    if (!isset($status_options[$status])) {
        return ['success' => false, 'message' => 'Invalid booklet status.'];
    }

    $is_active = $is_active === 1 ? 1 : 0;
    $notes = trim((string) $notes);
    $notes = $notes !== '' ? mb_substr($notes, 0, 255) : null;

    $select_stmt = $conn->prepare("
        SELECT booklet_code, booklet_type, status, is_active, notes
        FROM receipt_booklet_registry
        WHERE storage_number = ?
        LIMIT 1
    ");
    $select_stmt->bind_param("i", $storage_number);
    $select_stmt->execute();
    $result = $select_stmt->get_result();
    $current = $result ? $result->fetch_assoc() : null;
    $select_stmt->close();

    if (!$current) {
        return ['success' => false, 'message' => 'Booklet record was not found.'];
    }

    $current_status = (string) ($current['status'] ?? 'active');
    $current_active = (int) ($current['is_active'] ?? 0);
    $current_notes = trim((string) ($current['notes'] ?? ''));
    $new_notes = $notes ?? '';

    if ($current_status === $status && $current_active === $is_active && $current_notes === $new_notes) {
        return [
            'success' => true,
            'changed' => false,
            'booklet_code' => (string) ($current['booklet_code'] ?? $storage_number),
            'message' => 'No booklet changes were needed.',
        ];
    }

    $update_stmt = $conn->prepare("
        UPDATE receipt_booklet_registry
        SET status = ?, is_active = ?, notes = ?
        WHERE storage_number = ?
        LIMIT 1
    ");
    $update_stmt->bind_param("sisi", $status, $is_active, $notes, $storage_number);
    $success = $update_stmt->execute();
    $update_stmt->close();

    if (!$success) {
        return ['success' => false, 'message' => 'Failed to update booklet settings.'];
    }

    return [
        'success' => true,
        'changed' => true,
        'booklet_code' => (string) ($current['booklet_code'] ?? $storage_number),
        'booklet_type' => (string) ($current['booklet_type'] ?? ''),
        'old_status' => $current_status,
        'new_status' => $status,
        'old_active' => $current_active,
        'new_active' => $is_active,
        'old_notes' => $current_notes,
        'new_notes' => $new_notes,
        'message' => 'Booklet settings updated successfully.',
    ];
}

function receipt_booklet_registry_create(mysqli $conn, string $booklet_type, int $display_number, string $status, int $is_active, ?string $notes = null): array {
    ensure_receipt_booklet_registry($conn);

    $booklet_type = trim(strtolower($booklet_type));
    if (!in_array($booklet_type, ['regular', 'special'], true)) {
        return ['success' => false, 'message' => 'Invalid booklet type.'];
    }

    $status_options = receipt_booklet_registry_status_options();
    if (!isset($status_options[$status])) {
        return ['success' => false, 'message' => 'Invalid booklet status.'];
    }

    if ($booklet_type === 'regular') {
        if ($display_number < REGULAR_BOOKLET_MIN || $display_number > REGULAR_BOOKLET_MAX) {
            return ['success' => false, 'message' => 'Regular booklet number must be between ' . REGULAR_BOOKLET_MIN . ' and ' . REGULAR_BOOKLET_MAX . '.'];
        }
        $booklet_code = (string) $display_number;
        $storage_number = $display_number;
        [$range_start, $range_end] = receipt_window_for_regular_booklet($display_number);
    } else {
        if ($display_number < SPECIAL_BOOKLET_MIN || $display_number > SPECIAL_BOOKLET_MAX) {
            return ['success' => false, 'message' => 'S booklet number must be between S' . SPECIAL_BOOKLET_MIN . ' and S' . SPECIAL_BOOKLET_MAX . '.'];
        }
        $booklet_code = 'S' . $display_number;
        $storage_number = booklet_display_to_storage_number($display_number, true);
        [$range_start, $range_end] = receipt_window_for_special_booklet_display($display_number);
    }

    $is_active = $is_active === 1 ? 1 : 0;
    $notes = trim((string) $notes);
    $notes = $notes !== '' ? mb_substr($notes, 0, 255) : null;

    $existing_stmt = $conn->prepare("
        SELECT booklet_code
        FROM receipt_booklet_registry
        WHERE booklet_code = ? OR storage_number = ?
        LIMIT 1
    ");
    $existing_stmt->bind_param("si", $booklet_code, $storage_number);
    $existing_stmt->execute();
    $existing_result = $existing_stmt->get_result();
    $existing = $existing_result ? $existing_result->fetch_assoc() : null;
    $existing_stmt->close();

    if ($existing) {
        return ['success' => false, 'message' => 'That booklet already exists in the registry.'];
    }

    $range_stmt = $conn->prepare("
        SELECT booklet_code
        FROM receipt_booklet_registry
        WHERE (
            range_start <= ? AND range_end >= ?
        ) OR (
            range_start <= ? AND range_end >= ?
        ) OR (
            range_start >= ? AND range_end <= ?
        )
        LIMIT 1
    ");
    $range_stmt->bind_param("iiiiii", $range_start, $range_start, $range_end, $range_end, $range_start, $range_end);
    $range_stmt->execute();
    $range_result = $range_stmt->get_result();
    $range_overlap = $range_result ? $range_result->fetch_assoc() : null;
    $range_stmt->close();

    if ($range_overlap) {
        return ['success' => false, 'message' => 'That booklet range overlaps an existing registered booklet.'];
    }

    $insert_stmt = $conn->prepare("
        INSERT INTO receipt_booklet_registry (
            booklet_code,
            booklet_type,
            display_number,
            storage_number,
            range_start,
            range_end,
            status,
            is_active,
            notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $insert_stmt->bind_param(
        "ssiiiisis",
        $booklet_code,
        $booklet_type,
        $display_number,
        $storage_number,
        $range_start,
        $range_end,
        $status,
        $is_active,
        $notes
    );
    $success = $insert_stmt->execute();
    $insert_stmt->close();

    if (!$success) {
        return ['success' => false, 'message' => 'Failed to create the new booklet.'];
    }

    return [
        'success' => true,
        'booklet_code' => $booklet_code,
        'booklet_type' => $booklet_type,
        'storage_number' => $storage_number,
        'range_start' => $range_start,
        'range_end' => $range_end,
        'status' => $status,
        'is_active' => $is_active,
        'notes' => $notes ?? '',
        'message' => 'New booklet registered successfully.',
    ];
}

function receipt_booklet_registry_mark_full(mysqli $conn, int $storage_number): array {
    ensure_receipt_booklet_registry($conn);

    $select_stmt = $conn->prepare("
        SELECT booklet_code, booklet_type, status, is_active, notes
        FROM receipt_booklet_registry
        WHERE storage_number = ?
        LIMIT 1
    ");
    $select_stmt->bind_param("i", $storage_number);
    $select_stmt->execute();
    $result = $select_stmt->get_result();
    $current = $result ? $result->fetch_assoc() : null;
    $select_stmt->close();

    if (!$current) {
        return ['success' => false, 'message' => 'Booklet record was not found.'];
    }

    if ((string) ($current['status'] ?? '') === 'full' && (int) ($current['is_active'] ?? 0) === 0) {
        return [
            'success' => true,
            'changed' => false,
            'booklet_code' => (string) ($current['booklet_code'] ?? $storage_number),
            'message' => 'Booklet is already marked full.',
        ];
    }

    $update_stmt = $conn->prepare("
        UPDATE receipt_booklet_registry
        SET status = 'full', is_active = 0
        WHERE storage_number = ?
        LIMIT 1
    ");
    $update_stmt->bind_param("i", $storage_number);
    $success = $update_stmt->execute();
    $update_stmt->close();

    if (!$success) {
        return ['success' => false, 'message' => 'Failed to mark booklet as full.'];
    }

    return [
        'success' => true,
        'changed' => true,
        'booklet_code' => (string) ($current['booklet_code'] ?? $storage_number),
        'booklet_type' => (string) ($current['booklet_type'] ?? ''),
        'old_status' => (string) ($current['status'] ?? ''),
        'old_active' => (int) ($current['is_active'] ?? 0),
        'message' => 'Booklet marked as full and hidden from payment entry.',
    ];
}

function receipt_booklet_registry_activate_next(mysqli $conn, int $storage_number): array {
    ensure_receipt_booklet_registry($conn);

    $current_stmt = $conn->prepare("
        SELECT booklet_code, booklet_type, display_number, storage_number
        FROM receipt_booklet_registry
        WHERE storage_number = ?
        LIMIT 1
    ");
    $current_stmt->bind_param("i", $storage_number);
    $current_stmt->execute();
    $current_result = $current_stmt->get_result();
    $current = $current_result ? $current_result->fetch_assoc() : null;
    $current_stmt->close();

    if (!$current) {
        return ['success' => false, 'message' => 'Current booklet was not found.'];
    }

    $next_stmt = $conn->prepare("
        SELECT booklet_code, booklet_type, display_number, storage_number, status, is_active
        FROM receipt_booklet_registry
        WHERE booklet_type = ?
          AND display_number > ?
          AND status <> 'archived'
        ORDER BY display_number ASC
        LIMIT 1
    ");
    $next_stmt->bind_param("si", $current['booklet_type'], $current['display_number']);
    $next_stmt->execute();
    $next_result = $next_stmt->get_result();
    $next = $next_result ? $next_result->fetch_assoc() : null;
    $next_stmt->close();

    if (!$next) {
        return ['success' => false, 'message' => 'No next booklet is registered yet.'];
    }

    if ((string) ($next['status'] ?? '') === 'active' && (int) ($next['is_active'] ?? 0) === 1) {
        return [
            'success' => true,
            'changed' => false,
            'booklet_code' => (string) ($next['booklet_code'] ?? ''),
            'message' => 'The next booklet is already active and visible.',
        ];
    }

    $activate_stmt = $conn->prepare("
        UPDATE receipt_booklet_registry
        SET status = 'active', is_active = 1
        WHERE storage_number = ?
        LIMIT 1
    ");
    $activate_stmt->bind_param("i", $next['storage_number']);
    $success = $activate_stmt->execute();
    $activate_stmt->close();

    if (!$success) {
        return ['success' => false, 'message' => 'Failed to activate the next booklet.'];
    }

    return [
        'success' => true,
        'changed' => true,
        'current_booklet_code' => (string) ($current['booklet_code'] ?? ''),
        'booklet_code' => (string) ($next['booklet_code'] ?? ''),
        'booklet_type' => (string) ($next['booklet_type'] ?? ''),
        'old_status' => (string) ($next['status'] ?? ''),
        'old_active' => (int) ($next['is_active'] ?? 0),
        'message' => 'Next booklet activated successfully.',
    ];
}

function receipt_booklet_registry_set_visible_booklet(mysqli $conn, int $storage_number): array {
    ensure_receipt_booklet_registry($conn);

    $current_stmt = $conn->prepare("
        SELECT booklet_code, booklet_type, status, is_active
        FROM receipt_booklet_registry
        WHERE storage_number = ?
        LIMIT 1
    ");
    $current_stmt->bind_param("i", $storage_number);
    $current_stmt->execute();
    $current_result = $current_stmt->get_result();
    $current = $current_result ? $current_result->fetch_assoc() : null;
    $current_stmt->close();

    if (!$current) {
        return ['success' => false, 'message' => 'Selected booklet was not found.'];
    }

    $bookletType = (string) ($current['booklet_type'] ?? '');
    $currentStatus = (string) ($current['status'] ?? '');
    if ($bookletType === '') {
        return ['success' => false, 'message' => 'Selected booklet type is invalid.'];
    }
    if (in_array($currentStatus, ['full', 'archived'], true)) {
        return ['success' => false, 'message' => 'Full or archived booklets cannot be set as the visible payment booklet.'];
    }

    $visibleBefore = [];
    $visible_stmt = $conn->prepare("
        SELECT booklet_code, storage_number
        FROM receipt_booklet_registry
        WHERE booklet_type = ?
          AND is_active = 1
        ORDER BY display_number ASC
    ");
    $visible_stmt->bind_param("s", $bookletType);
    $visible_stmt->execute();
    $visible_result = $visible_stmt->get_result();
    while ($row = $visible_result->fetch_assoc()) {
        $visibleBefore[] = $row;
    }
    $visible_stmt->close();

    if ((int) ($current['is_active'] ?? 0) === 1 && count($visibleBefore) === 1 && (int) ($visibleBefore[0]['storage_number'] ?? 0) === $storage_number) {
        return [
            'success' => true,
            'changed' => false,
            'booklet_code' => (string) ($current['booklet_code'] ?? $storage_number),
            'booklet_type' => $bookletType,
            'visible_before' => array_map(static fn($row) => (string) ($row['booklet_code'] ?? ''), $visibleBefore),
            'visible_after' => array_map(static fn($row) => (string) ($row['booklet_code'] ?? ''), $visibleBefore),
            'message' => 'That booklet is already the only visible payment booklet for this type.',
        ];
    }

    $conn->begin_transaction();

    $hide_stmt = $conn->prepare("
        UPDATE receipt_booklet_registry
        SET is_active = 0
        WHERE booklet_type = ?
    ");
    $hide_stmt->bind_param("s", $bookletType);
    $hide_success = $hide_stmt->execute();
    $hide_stmt->close();

    if (!$hide_success) {
        $conn->rollback();
        return ['success' => false, 'message' => 'Failed to reset current visible booklets.'];
    }

    $show_stmt = $conn->prepare("
        UPDATE receipt_booklet_registry
        SET status = 'active', is_active = 1
        WHERE storage_number = ?
        LIMIT 1
    ");
    $show_stmt->bind_param("i", $storage_number);
    $show_success = $show_stmt->execute();
    $show_stmt->close();

    if (!$show_success) {
        $conn->rollback();
        return ['success' => false, 'message' => 'Failed to set the preferred visible booklet.'];
    }

    $conn->commit();

    return [
        'success' => true,
        'changed' => true,
        'booklet_code' => (string) ($current['booklet_code'] ?? $storage_number),
        'booklet_type' => $bookletType,
        'old_status' => $currentStatus,
        'old_active' => (int) ($current['is_active'] ?? 0),
        'visible_before' => array_map(static fn($row) => (string) ($row['booklet_code'] ?? ''), $visibleBefore),
        'visible_after' => [(string) ($current['booklet_code'] ?? $storage_number)],
        'message' => 'Preferred visible payment booklet updated successfully.',
    ];
}

function receipt_booklet_usage_map(mysqli $conn, array $booklet_rows): array {
    ensure_receipts_registry_schema($conn);

    $usage = [];
    $storage_numbers = [];

    foreach ($booklet_rows as $booklet_row) {
        $storage_no = (int) ($booklet_row['storage_number'] ?? 0);
        $range_start = (int) ($booklet_row['range_start'] ?? 0);
        $range_end = (int) ($booklet_row['range_end'] ?? 0);
        if ($storage_no <= 0 || $range_start <= 0 || $range_end <= 0) {
            continue;
        }

        $usage[$storage_no] = [
            'used' => [],
            'next' => $range_start,
            'range_start' => $range_start,
            'range_end' => $range_end,
        ];
        $storage_numbers[] = $storage_no;
    }

    if (!$storage_numbers) {
        return $usage;
    }

    $placeholders = implode(',', array_fill(0, count($storage_numbers), '?'));
    $types = str_repeat('i', count($storage_numbers));
    $stmt = $conn->prepare("
        SELECT booklet_no, receipt_no
        FROM receipts_registry
        WHERE voided = 0 AND booklet_no IN ($placeholders)
        ORDER BY booklet_no ASC, receipt_no ASC
    ");
    $stmt->bind_param($types, ...$storage_numbers);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $storage_no = (int) $row['booklet_no'];
        $receipt_no = (int) $row['receipt_no'];
        if (!isset($usage[$storage_no])) {
            continue;
        }
        if ($receipt_no < $usage[$storage_no]['range_start'] || $receipt_no > $usage[$storage_no]['range_end']) {
            continue;
        }
        $usage[$storage_no]['used'][] = $receipt_no;
    }
    $stmt->close();

    foreach ($usage as $storage_no => $entry) {
        $used_lookup = array_fill_keys($entry['used'], true);
        $next = null;
        for ($candidate = $entry['range_start']; $candidate <= $entry['range_end']; $candidate++) {
            if (!isset($used_lookup[$candidate])) {
                $next = $candidate;
                break;
            }
        }
        $usage[$storage_no]['next'] = $next;
    }

    return $usage;
}

function receipt_booklet_monitoring_map(mysqli $conn, array $booklet_rows): array {
    ensure_receipts_registry_schema($conn);

    $monitoring = [];
    $storage_numbers = [];

    foreach ($booklet_rows as $booklet_row) {
        $storage_no = (int) ($booklet_row['storage_number'] ?? 0);
        $range_start = (int) ($booklet_row['range_start'] ?? 0);
        $range_end = (int) ($booklet_row['range_end'] ?? 0);
        if ($storage_no <= 0 || $range_start <= 0 || $range_end <= 0) {
            continue;
        }

        $capacity = max(0, ($range_end - $range_start) + 1);
        $monitoring[$storage_no] = [
            'capacity' => $capacity,
            'active_used' => [],
            'active_used_count' => 0,
            'voided_count' => 0,
            'last_used_at' => null,
            'last_used_receipt' => null,
            'next_available' => $range_start,
            'remaining_count' => $capacity,
            'near_full' => false,
            'fully_used' => false,
            'range_start' => $range_start,
            'range_end' => $range_end,
        ];
        $storage_numbers[] = $storage_no;
    }

    if (!$storage_numbers) {
        return $monitoring;
    }

    $placeholders = implode(',', array_fill(0, count($storage_numbers), '?'));
    $types = str_repeat('i', count($storage_numbers));
    $sql = "
        SELECT booklet_no, receipt_no, used_at, voided
        FROM receipts_registry
        WHERE booklet_no IN ($placeholders)
        ORDER BY booklet_no ASC, used_at DESC, receipt_no DESC
    ";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$storage_numbers);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $storage_no = (int) ($row['booklet_no'] ?? 0);
        if (!isset($monitoring[$storage_no])) {
            continue;
        }

        $receipt_no = (int) ($row['receipt_no'] ?? 0);
        if ($receipt_no <= 0) {
            continue;
        }

        if ($monitoring[$storage_no]['last_used_at'] === null && !empty($row['used_at'])) {
            $monitoring[$storage_no]['last_used_at'] = $row['used_at'];
            $monitoring[$storage_no]['last_used_receipt'] = $receipt_no;
        }

        if ((int) ($row['voided'] ?? 0) === 1) {
            $monitoring[$storage_no]['voided_count']++;
            continue;
        }

        if ($receipt_no < $monitoring[$storage_no]['range_start'] || $receipt_no > $monitoring[$storage_no]['range_end']) {
            continue;
        }

        $monitoring[$storage_no]['active_used'][] = $receipt_no;
    }
    $stmt->close();

    foreach ($monitoring as $storage_no => $entry) {
        $used_lookup = array_fill_keys($entry['active_used'], true);
        $active_used_count = count($used_lookup);
        $next_available = null;

        for ($candidate = $entry['range_start']; $candidate <= $entry['range_end']; $candidate++) {
            if (!isset($used_lookup[$candidate])) {
                $next_available = $candidate;
                break;
            }
        }

        $remaining_count = max(0, $entry['capacity'] - $active_used_count);
        $monitoring[$storage_no]['active_used_count'] = $active_used_count;
        $monitoring[$storage_no]['next_available'] = $next_available;
        $monitoring[$storage_no]['remaining_count'] = $remaining_count;
        $monitoring[$storage_no]['fully_used'] = $remaining_count === 0;
        $monitoring[$storage_no]['near_full'] = $remaining_count > 0 && $remaining_count <= 10;
        unset($monitoring[$storage_no]['active_used']);
    }

    return $monitoring;
}

function receipt_booklet_monitoring_summary(array $monitoring_map): array {
    $summary = [
        'total_booklets' => count($monitoring_map),
        'near_full_count' => 0,
        'full_count' => 0,
        'with_remaining_count' => 0,
    ];

    foreach ($monitoring_map as $entry) {
        if (!empty($entry['fully_used'])) {
            $summary['full_count']++;
        } elseif (($entry['remaining_count'] ?? 0) > 0) {
            $summary['with_remaining_count']++;
        }

        if (!empty($entry['near_full'])) {
            $summary['near_full_count']++;
        }
    }

    return $summary;
}

function receipt_registry_voided_summary(mysqli $conn): array {
    ensure_receipts_registry_schema($conn);

    $sql = "
        SELECT
            COUNT(*) AS total_voided,
            SUM(CASE WHEN booklet_no >= " . (SPECIAL_BOOKLET_STORAGE_OFFSET + SPECIAL_BOOKLET_MIN) . " THEN 1 ELSE 0 END) AS special_voided,
            SUM(CASE WHEN booklet_no >= " . REGULAR_BOOKLET_MIN . " AND booklet_no <= " . REGULAR_BOOKLET_MAX . " THEN 1 ELSE 0 END) AS regular_voided,
            MAX(voided_at) AS last_voided_at
        FROM receipts_registry
        WHERE voided = 1
    ";

    return $conn->query($sql)->fetch_assoc() ?: [];
}

function receipt_booklet_registry_active_snapshot(mysqli $conn, string $type): array {
    ensure_receipt_booklet_registry($conn);

    $rows = receipt_booklet_registry_rows($conn, $type);
    $monitoring = receipt_booklet_monitoring_map($conn, $rows);
    $activeCurrent = null;
    $nextAvailableBooklet = null;

    foreach ($rows as $row) {
        $storageNumber = (int) ($row['storage_number'] ?? 0);
        $status = (string) ($row['status'] ?? '');
        $isActive = (int) ($row['is_active'] ?? 0) === 1;
        $monitor = $monitoring[$storageNumber] ?? null;

        if ($activeCurrent === null && $status === 'active' && $isActive) {
            $activeCurrent = [
                'booklet_code' => (string) ($row['booklet_code'] ?? ''),
                'storage_number' => $storageNumber,
                'display_label' => booklet_label_from_stored($storageNumber),
                'next_receipt' => $monitor['next_available'] ?? null,
                'remaining_count' => $monitor['remaining_count'] ?? null,
                'near_full' => !empty($monitor['near_full']),
                'fully_used' => !empty($monitor['fully_used']),
            ];
        }

        if ($nextAvailableBooklet === null && $status !== 'archived' && (!$isActive || $status !== 'active')) {
            $nextAvailableBooklet = [
                'booklet_code' => (string) ($row['booklet_code'] ?? ''),
                'storage_number' => $storageNumber,
                'display_label' => booklet_label_from_stored($storageNumber),
                'status' => $status,
                'is_active' => $isActive ? 1 : 0,
            ];
        }
    }

    return [
        'current' => $activeCurrent,
        'next' => $nextAvailableBooklet,
    ];
}
?>
