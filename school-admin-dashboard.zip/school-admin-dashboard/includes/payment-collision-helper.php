<?php

function payment_collision_normalize_rows(array $rows): array
{
    $normalized = [];
    foreach ($rows as $row) {
        $normalized[] = array_map(static function ($value): string {
            if ($value === null) {
                return '';
            }
            if (is_float($value) || is_int($value)) {
                return number_format((float) $value, 2, '.', '');
            }
            return trim((string) $value);
        }, $row);
    }

    usort($normalized, static function (array $a, array $b): int {
        return strcmp(json_encode($a), json_encode($b));
    });

    return $normalized;
}

function payment_collision_token(array $rows): string
{
    return hash('sha256', json_encode(payment_collision_normalize_rows($rows), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

function active_payment_balance_snapshot(mysqli $conn, int $studentId, string $schoolYearLabel): array
{
    $rows = [];
    $stmt = $conn->prepare("
        SELECT id, type, balance
        FROM accounts
        WHERE student_id = ?
          AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?
        ORDER BY id ASC
    ");
    if (!$stmt) {
        return $rows;
    }

    $stmt->bind_param('iss', $studentId, $schoolYearLabel, $schoolYearLabel);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $rows[] = [
            'id' => (int) ($row['id'] ?? 0),
            'type' => (string) ($row['type'] ?? ''),
            'balance' => (float) ($row['balance'] ?? 0),
        ];
    }
    $stmt->close();

    return $rows;
}

function old_payment_balance_snapshot(mysqli $conn, int $studentId): array
{
    $rows = [];
    $stmt = $conn->prepare("
        SELECT fee_type, balance
        FROM old_student_fees
        WHERE old_student_id = ?
        ORDER BY fee_type ASC
    ");
    if (!$stmt) {
        return $rows;
    }

    $stmt->bind_param('i', $studentId);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $rows[] = [
            'fee_type' => (string) ($row['fee_type'] ?? ''),
            'balance' => (float) ($row['balance'] ?? 0),
        ];
    }
    $stmt->close();

    return $rows;
}
