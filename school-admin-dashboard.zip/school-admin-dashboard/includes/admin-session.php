<?php

function admin_session_config() {
    return [
        'idle_timeout_seconds' => 15 * 60,
        'absolute_timeout_seconds' => 8 * 60 * 60,
        'warning_seconds' => 2 * 60,
        'login_path' => '/school-admin-dashboard/Admin.php',
    ];
}

function admin_security_headers(): void {
    if (headers_sent()) {
        return;
    }

    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; font-src 'self' data: https://cdnjs.cloudflare.com; connect-src 'self'; frame-ancestors 'self'; base-uri 'self'; form-action 'self'");
}

function admin_session_start() {
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    admin_security_headers();

    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function admin_session_redirect_to_login($reason = 'session_expired') {
    $config = admin_session_config();
    $target = $config['login_path'] . '?reason=' . urlencode($reason);
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Location: ' . $target);
    exit();
}

function admin_session_forbidden($message = 'Access denied.') {
    http_response_code(403);
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    exit($message);
}

function admin_session_init_login() {
    admin_session_start();
    $_SESSION['loggedin'] = true;
    $_SESSION['login_time'] = time();
    $_SESSION['last_activity'] = time();
}

function admin_session_sync_live_role() {
    if (empty($_SESSION['username'])) {
        return;
    }

    $databasePath = dirname(__DIR__) . '/config/database.php';
    if (!file_exists($databasePath)) {
        return;
    }

    require $databasePath;
    if (!isset($conn) || !($conn instanceof mysqli)) {
        return;
    }

    $username = (string) $_SESSION['username'];
    $stmt = $conn->prepare("SELECT id, role FROM admins WHERE username = ? LIMIT 1");
    if (!$stmt) {
        return;
    }

    $stmt->bind_param('s', $username);
    $stmt->execute();
    $stmt->bind_result($liveId, $liveRole);
    $found = $stmt->fetch();
    $stmt->close();

    if (!$found) {
        session_unset();
        session_destroy();
        admin_session_redirect_to_login('login_required');
    }

    if (isset($liveId)) {
        $_SESSION['user_id'] = (int) $liveId;
    }

    if (isset($liveRole) && $_SESSION['role'] !== $liveRole) {
        $_SESSION['role'] = $liveRole;
    }
}

function admin_session_require_login() {
    admin_session_start();

    admin_security_headers();
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');

    if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
        admin_session_redirect_to_login('login_required');
    }

    $config = admin_session_config();
    $now = time();
    $lastActivity = (int) ($_SESSION['last_activity'] ?? 0);
    $loginTime = (int) ($_SESSION['login_time'] ?? 0);

    if ($lastActivity > 0 && ($now - $lastActivity) > $config['idle_timeout_seconds']) {
        session_unset();
        session_destroy();
        admin_session_redirect_to_login('idle_timeout');
    }

    if ($loginTime > 0 && ($now - $loginTime) > $config['absolute_timeout_seconds']) {
        session_unset();
        session_destroy();
        admin_session_redirect_to_login('absolute_timeout');
    }

    admin_session_sync_live_role();
    $_SESSION['last_activity'] = $now;
}

function admin_csrf_token(): string {
    admin_session_start();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return (string) $_SESSION['csrf_token'];
}

function admin_csrf_validate(?string $token): bool {
    $sessionToken = (string) ($_SESSION['csrf_token'] ?? '');
    $requestToken = (string) ($token ?? '');

    return $sessionToken !== '' && $requestToken !== '' && hash_equals($sessionToken, $requestToken);
}

function admin_require_post_csrf(string $tokenField = 'csrf_token'): void {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        admin_session_forbidden('Invalid request method.');
    }

    if (!admin_csrf_validate($_POST[$tokenField] ?? '')) {
        admin_session_forbidden('Invalid CSRF token.');
    }
}

function admin_session_warning_script() {
    $config = admin_session_config();
    $loginUrl = $config['login_path'];
    $idleSeconds = (int) $config['idle_timeout_seconds'];
    $warningSeconds = (int) $config['warning_seconds'];
    $loginUrlJson = json_encode($loginUrl);

    return <<<HTML
<script>
(function () {
    const idleSeconds = {$idleSeconds};
    const warningSeconds = {$warningSeconds};
    const loginUrl = {$loginUrlJson};
    let warningShown = false;
    let lastActivity = Date.now();

    function resetActivity() {
        lastActivity = Date.now();
        warningShown = false;
    }

    function checkIdle() {
        const elapsed = Math.floor((Date.now() - lastActivity) / 1000);
        const remaining = idleSeconds - elapsed;
        if (remaining <= 0) {
            window.location.href = loginUrl + '?reason=idle_timeout';
            return;
        }
        if (!warningShown && remaining <= warningSeconds) {
            warningShown = true;
            alert('Your admin session will expire in about ' + Math.max(1, Math.ceil(remaining / 60)) + ' minute(s) due to inactivity.');
        }
    }

    ['click', 'keydown', 'mousemove', 'scroll', 'touchstart', 'input'].forEach(function (eventName) {
        window.addEventListener(eventName, resetActivity, { passive: true });
    });
    setInterval(checkIdle, 30000);
})();
</script>
HTML;
}
