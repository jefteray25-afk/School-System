<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>School Admin Dashboard</title>
    <link rel="stylesheet" href="/school-admin-dashboard/assets/css/style.css">
</head>
<body>
    <header>
        <h1>School Admin Dashboard</h1>
        <?php if (isset($_SESSION['username'], $_SESSION['role'])): ?>
            <div style="float:right;">
                Logged in as <strong><?= htmlspecialchars($_SESSION['username']) ?></strong> (<?= htmlspecialchars($_SESSION['role']) ?>)
                <a href="/school-admin-dashboard/logout.php" style="color:#fff;">Logout</a>
            </div>
        <?php endif; ?>
        <nav>
            <a href="/school-admin-dashboard/Dashboard.php">Home</a> |
            <a href="/school-admin-dashboard/modules/students/student-list.php">Students</a> |
            <a href="/school-admin-dashboard/modules/admissions/application-list.php">Admissions</a> |
            <a href="/school-admin-dashboard/modules/accounts/account-list.php">Accounts</a> |
            <a href="/school-admin-dashboard/modules/financial/fee-setup.php">Financial</a> |
            <a href="/school-admin-dashboard/modules/documents/upload.php">Documents</a> |
            <a href="/school-admin-dashboard/modules/courses/course-list.php">Courses</a> |
            <a href="/school-admin-dashboard/modules/reports/registration-summary.php">Reports</a> |
            <a href="/school-admin-dashboard/modules/settings/roles.php">Settings</a> |
            <a href="/school-admin-dashboard/modules/audit/logs.php">Audit Logs</a> |
            <a href="/school-admin-dashboard/modules/communication/announcements.php">Communication</a> |
            <a href="/school-admin-dashboard/modules/dashboard/analytics.php">Analytics</a>
        </nav>
        <hr>
    </header>