document.addEventListener('DOMContentLoaded', function () {
    // Sidebar toggle
    document.getElementById('menu-toggle').addEventListener('click', function () {
        let sidebar = document.getElementById('sidebar');
        let pageContent = document.getElementById('page-content-wrapper');
        if (sidebar.style.display === 'none') {
            sidebar.style.display = '';
            pageContent.style.marginLeft = '220px';
        } else {
            sidebar.style.display = 'none';
            pageContent.style.marginLeft = '0';
        }
    });

    // Dark mode toggle
    let darkToggle = document.getElementById('darkModeToggle');
    darkToggle.addEventListener('click', function () {
        document.documentElement.classList.toggle('dark-mode');
        // Optionally persist preference
        localStorage.setItem('darkMode', document.documentElement.classList.contains('dark-mode') ? '1' : '0');
    });

    // Load persisted dark mode
    if (localStorage.getItem('darkMode') === '1') {
        document.documentElement.classList.add('dark-mode');
    }
});