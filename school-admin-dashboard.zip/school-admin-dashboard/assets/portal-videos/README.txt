Portal Mosaic Assets

This folder provides up to 9 background tiles for school.php.

Slots:
  01 .. 09

Supported per slot (choose one file per slot):
  Video: mp4, webm, ogg (muted + loop recommended)
  Image: jpg, jpeg, png, gif

Selection order per slot (first existing wins):
  mp4 -> webm -> ogg -> jpg -> jpeg -> png -> gif

Example:
  01.mp4 (tile 1 video)
  02.jpg (tile 2 image)
  03.gif (tile 3 animated gif)

Notes:
- Keep assets small for fast loading.
- Autoplay videos require muted audio in most browsers.
- Missing slots will show the fallback gradient tile.

