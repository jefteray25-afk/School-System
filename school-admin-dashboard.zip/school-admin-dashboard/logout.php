<?php
require __DIR__ . '/includes/admin-session.php';
admin_session_start();

// Include DB connection
include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/config/database.php');

// AUDIT LOGGING: Track logout
include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');
$user = $_SESSION['username'] ?? 'unknown';
$action = "Logged out";
$module = "Authentication";
$details = "Role: " . ($_SESSION['role'] ?? 'unknown');
audit_log($conn, $user, $action, $module, $details);

session_unset();       // Unset all session variables
session_destroy();     // Destroy the session
header("Location: Admin.php"); // Redirect to login page
exit();
?>
