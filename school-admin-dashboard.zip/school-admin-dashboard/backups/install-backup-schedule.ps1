$taskPrefix = 'SchoolAdminBackup'
$batchPath = 'C:\xampp\htdocs\school-admin-dashboard\backups\backup-script.bat'
$taskNamesToDelete = @(
    'SchoolAdminBackup-1000',
    'SchoolAdminBackup-1201',
    'SchoolAdminBackup-1630'
)

if (-not (Test-Path $batchPath)) {
    Write-Error "Backup batch file not found: $batchPath"
    exit 1
}

foreach ($oldTaskName in $taskNamesToDelete) {
    $oldTask = Get-ScheduledTask -TaskName $oldTaskName -ErrorAction SilentlyContinue
    if ($null -ne $oldTask) {
        Unregister-ScheduledTask -TaskName $oldTaskName -Confirm:$false
    }
}

for ($hour = 0; $hour -lt 24; $hour++) {
    $time = "{0:D2}:00" -f $hour
    $taskName = "{0}-Hourly-{1}" -f $taskPrefix, ($time -replace ':', '')
    schtasks /Create /TN $taskName /TR "`"$batchPath`"" /SC DAILY /ST $time /F | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed to create scheduled task $taskName"
        exit 1
    }
}

Write-Host "Hourly backup schedule installed successfully."
Write-Host "Times: every hour from 00:00 to 23:00"
