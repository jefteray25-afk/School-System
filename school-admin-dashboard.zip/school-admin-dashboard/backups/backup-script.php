<?php
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Forbidden');
}

require 'C:/xampp/htdocs/school-admin-dashboard/config/database.php';
require 'C:/xampp/htdocs/school-admin-dashboard/modules/settings/settings-security.php';
require 'C:/xampp/htdocs/school-admin-dashboard/modules/settings/backup-settings-helper.php';

$db_host = $db_host ?? 'localhost';
$db_user = $db_user ?? 'root';
$db_pass = $db_pass ?? '';
$db_name = $db_name ?? 'school_admin';
$mysqldump_path = 'C:/xampp/mysql/bin/mysqldump.exe';
backup_settings_ensure_table($conn);
$backupSettings = backup_settings_get($conn);
$backup_dir = backup_settings_resolved_dir($backupSettings);
if (!is_dir($backup_dir)) {
    mkdir($backup_dir, 0775, true);
}

if (empty($backupSettings['enabled'])) {
    backup_settings_record_run($conn, 'Skipped', 'Automatic backups are disabled in Backup Schedule Settings.', '');
    echo 'Backup skipped: automatic backups are disabled.' . PHP_EOL;
    $conn->close();
    exit(0);
}

function get_next_backup_filename(string $dir, string $base_name): string
{
    $i = 1;
    $file = $base_name . '.sql';
    while (file_exists($dir . '/' . $file)) {
        $file = $base_name . '(' . $i . ').sql';
        $i++;
    }
    return $file;
}

function backup_filename_prefix(string $db_name): string
{
    $prefix = strtolower(trim($db_name));
    $prefix = preg_replace('/[^a-z0-9]+/', '_', $prefix);
    $prefix = trim((string) $prefix, '_');

    return $prefix !== '' ? $prefix : 'school_admin';
}

$file_base = backup_filename_prefix($db_name) . '_auto_' . date('Y-m-d_H-i-s');
$backup_file = get_next_backup_filename($backup_dir, $file_base);
$backup_path = $backup_dir . '/' . $backup_file;

$command = escapeshellarg($mysqldump_path)
    . ' --host=' . escapeshellarg($db_host)
    . ' --user=' . escapeshellarg($db_user);

if ($db_pass !== '') {
    $command .= ' --password=' . escapeshellarg($db_pass);
}

$command .= ' ' . escapeshellarg($db_name) . ' > ' . escapeshellarg($backup_path);
shell_exec($command);

if (file_exists($backup_path) && filesize($backup_path) > 100) {
    $deletedFiles = backup_settings_prune_old_files($backup_dir, (int) ($backupSettings['retention_count'] ?? 122));
    $message = 'Backup successful';
    if (!empty($deletedFiles)) {
        $message .= ' | Pruned old files: ' . implode(', ', $deletedFiles);
    }
    backup_settings_record_run($conn, 'Success', $message, $backup_file);
    echo 'Backup successful: ' . $backup_file . PHP_EOL;
} else {
    if (file_exists($backup_path)) {
        unlink($backup_path);
    }
    backup_settings_record_run($conn, 'Failed', 'Backup failed. No valid file was stored.', '');
    echo 'Backup failed.' . PHP_EOL;
}

$conn->close();
