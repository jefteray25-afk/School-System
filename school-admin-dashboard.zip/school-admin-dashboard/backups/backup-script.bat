@echo off
setlocal

set "PHP_EXE=C:\xampp\php\php.exe"
set "BACKUP_SCRIPT=C:\xampp\htdocs\school-admin-dashboard\backups\backup-script.php"
set "LOG_DIR=C:\xampp\htdocs\school-admin-dashboard\backups\logs"
set "LOG_FILE=%LOG_DIR%\backup-run.log"

if not exist "%LOG_DIR%" (
    mkdir "%LOG_DIR%"
)

echo [%date% %time%] Running automatic backup >> "%LOG_FILE%"
"%PHP_EXE%" "%BACKUP_SCRIPT%" >> "%LOG_FILE%" 2>&1
echo. >> "%LOG_FILE%"

endlocal
