<?php

/**
 * Read-only Wave 4 readiness check for Bulk Photo Attachment.
 * Usage:
 *   php tools/photo-bulk-preflight.php
 *   php tools/photo-bulk-preflight.php "SY 2026-2027" "Junior Kindergarten" "A"
 */

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('CLI only.');
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../modules/settings/upload-storage-helper.php';
require_once __DIR__ . '/../modules/settings/school-year-helper.php';
require_once __DIR__ . '/../modules/students/student-photo-bulk-helper.php';

function photo_bulk_preflight_result(string $label, bool $ok, string $detail = ''): void
{
    echo sprintf('[%s] %s%s', $ok ? 'PASS' : 'FAIL', $label, $detail !== '' ? ' - ' . $detail : '') . PHP_EOL;
}

$settings = upload_storage_get($conn);
$ok = true;

echo "Bulk Photo Attachment Wave 4 Preflight" . PHP_EOL;
echo "====================================" . PHP_EOL;

$schemaReady = upload_storage_bulk_photo_schema_ready($conn) && student_photo_bulk_tables_ready($conn);
photo_bulk_preflight_result('Bulk photo schema', $schemaReady, $schemaReady ? 'Settings columns and batch tables are ready.' : 'Run php tools/migrate.php first.');
$ok = $ok && $schemaReady;

foreach ([
    'Final student photos' => $settings['student_photo_dir'],
    'Bulk inbox' => $settings['bulk_photo_inbox_dir'],
    'Bulk staging' => $settings['bulk_photo_staging_dir'],
    'Bulk quarantine' => $settings['bulk_photo_quarantine_dir'],
] as $label => $directory) {
    $ready = is_dir($directory) && is_readable($directory) && is_writable($directory);
    photo_bulk_preflight_result($label . ' directory', $ready, (string) $directory);
    $ok = $ok && $ready;
}

photo_bulk_preflight_result('Bulk file size limit', (int) $settings['bulk_photo_source_max_mb'] > 0, (int) $settings['bulk_photo_source_max_mb'] . ' MB');
photo_bulk_preflight_result('Bulk resolution limit', (int) $settings['bulk_photo_source_max_width'] > 0 && (int) $settings['bulk_photo_source_max_height'] > 0, (int) $settings['bulk_photo_source_max_width'] . ' × ' . (int) $settings['bulk_photo_source_max_height'] . ' px');

if ($argc === 4) {
    [, $schoolYear, $grade, $section] = $argv;
    $defaultYear = school_year_default_label();
    $isUnassignedScope = $section === '__unassigned__';
    $studentSql = "SELECT id, lastname, firstname, middlename, lrn, grade, section, school_year_label, photo FROM students WHERE COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ? AND grade = ?";
    $studentSql .= $isUnassignedScope ? " AND TRIM(COALESCE(section, '')) = ''" : ' AND section = ?';
    $studentSql .= ' ORDER BY lastname ASC, firstname ASC';
    $stmt = $conn->prepare($studentSql);
    $students = [];
    if ($stmt) {
        if ($isUnassignedScope) {
            $stmt->bind_param('sss', $defaultYear, $schoolYear, $grade);
        } else {
            $stmt->bind_param('ssss', $defaultYear, $schoolYear, $grade, $section);
        }
        $stmt->execute();
        $students = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    }
    $scan = student_photo_bulk_scan_scope($settings, $schoolYear, $grade, $section);
    $preview = student_photo_bulk_preview($students, $scan['files'], $grade);
    $matched = $missing = $replacements = 0;
    foreach ($preview['rows'] as $row) {
        if ($row['status'] === 'matched') { $matched++; }
        if ($row['status'] === 'missing') { $missing++; }
        if ($row['status'] === 'replacement_candidate') { $replacements++; }
    }
    echo PHP_EOL . 'Selected scope (read-only)' . PHP_EOL;
    echo '--------------------------' . PHP_EOL;
    echo 'Students: ' . count($students) . PHP_EOL;
    echo 'Inbox files: ' . count($scan['files']) . PHP_EOL;
    echo 'Matched: ' . $matched . PHP_EOL;
    echo 'Missing: ' . $missing . PHP_EOL;
    echo 'Replacement candidates: ' . $replacements . PHP_EOL;
    if ($scan['error'] !== '') {
        photo_bulk_preflight_result('Selected inbox folder', false, $scan['error'] . ' Expected: ' . $scan['directory']);
        $ok = false;
    } else {
        photo_bulk_preflight_result('Selected inbox folder', true, $scan['directory']);
    }
}

$conn->close();
echo PHP_EOL . ($ok ? 'Preflight passed.' : 'Preflight needs attention.') . PHP_EOL;
exit($ok ? 0 : 1);
