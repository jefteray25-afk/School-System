# Bulk Photo Attachment — Wave 4 Test Checklist

Run this on a copy of the school database first, or during a controlled low-traffic period.

## Preflight

1. Deploy the Wave 1–3 files.
2. Run `php tools/migrate.php` once.
3. Configure private final, inbox, staging, and quarantine directories in Settings → Upload Storage.
4. Run `php tools/photo-bulk-preflight.php`.
5. For a selected scope, run `php tools/photo-bulk-preflight.php "SY 2026-2027" "Junior Kindergarten" "A"`.

## Required test sequence

1. Choose a two-student test section with no attached photos; scan two correctly named files; apply both.
2. Scan a section with 20 students and only 17 valid photos; apply the 17 matched photos; verify 3 remain Missing.
3. Return with only the missing three files; apply them; verify the original 17 remain unchanged.
4. Re-scan the same files; verify the system does not attach duplicates.
5. Scan a new exact-LRN file for a student with a photo; verify Replacement Candidate is shown and nothing changes until both confirmations are selected.
6. Confirm one replacement; verify only that student receives a new active photo.
7. Test a `1111` filename, then later a filename with the actual 12-digit LRN for the same student.
8. Test an unknown filename, two files for one student, a non-image file, and an oversized file.
9. Verify new photos on Student List, Student Profile, Accounts, and Reports.
10. Verify the original inbox files still exist after apply.

## Pass criteria

- Only selected Matched items update `students.photo`.
- No student photo is replaced without explicit replacement confirmation.
- Existing photos not selected in the batch remain unchanged.
- Inbox files remain untouched; final files are copied to private storage.
- Batch status becomes `applied` or `partial`; a previously applied batch cannot apply again.
- Audit log records the bulk apply action.
