<?php
require __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/app-env.php';

if (!function_exists('smoke_result')) {
    function smoke_result(string $label, bool $ok, string $details = ''): array
    {
        return ['label' => $label, 'ok' => $ok, 'details' => $details];
    }
}

if (!function_exists('table_exists')) {
    function table_exists(mysqli $conn, string $tableName): bool
    {
        $stmt = $conn->prepare("
            SELECT 1
            FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = ?
            LIMIT 1
        ");
        if (!$stmt) {
            return false;
        }
        $stmt->bind_param('s', $tableName);
        $stmt->execute();
        $exists = $stmt->get_result()->num_rows > 0;
        $stmt->close();
        return $exists;
    }
}

if (!function_exists('column_exists')) {
    function column_exists(mysqli $conn, string $tableName, string $columnName): bool
    {
        $stmt = $conn->prepare("
            SELECT 1
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = ?
              AND COLUMN_NAME = ?
            LIMIT 1
        ");
        if (!$stmt) {
            return false;
        }
        $stmt->bind_param('ss', $tableName, $columnName);
        $stmt->execute();
        $exists = $stmt->get_result()->num_rows > 0;
        $stmt->close();
        return $exists;
    }
}

if (!function_exists('school_admin_smoke_checks')) {
    function smoke_ensure_day_close_tables(mysqli $conn): void
    {
        $conn->query("CREATE TABLE IF NOT EXISTS logbook_day_close (
            id INT AUTO_INCREMENT PRIMARY KEY,
            log_date DATE NOT NULL UNIQUE,
            deposit_total DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            turnover_total DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            retained_cash DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            reviewed_by VARCHAR(100) DEFAULT NULL,
            closing_note TEXT DEFAULT NULL,
            is_closed TINYINT(1) NOT NULL DEFAULT 0,
            closed_by VARCHAR(100) DEFAULT NULL,
            closed_at DATETIME DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

        $conn->query("CREATE TABLE IF NOT EXISTS logbook_day_close_audit (
            id INT AUTO_INCREMENT PRIMARY KEY,
            log_date DATE NOT NULL,
            action_type VARCHAR(40) NOT NULL,
            action_details TEXT DEFAULT NULL,
            changed_by VARCHAR(100) DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_day_close_audit (log_date, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
    }

    function school_admin_smoke_checks(mysqli $conn): array
    {
        smoke_ensure_day_close_tables($conn);
        $checks = [];
        $checks[] = smoke_result('Database connection', true, 'Connected successfully.');
        $checks[] = smoke_result('Application environment', true, app_env_label());
        $checks[] = smoke_result('students table', table_exists($conn, 'students'));
        $checks[] = smoke_result('accounts table', table_exists($conn, 'accounts'));
        $checks[] = smoke_result('payments table', table_exists($conn, 'payments'));
        $checks[] = smoke_result('old_student_payments table', table_exists($conn, 'old_student_payments'));
        $checks[] = smoke_result('student_registration_pending table', table_exists($conn, 'student_registration_pending'));
        $checks[] = smoke_result('receipts_registry table', table_exists($conn, 'receipts_registry'));
        $checks[] = smoke_result('logbook_shift_notes table', table_exists($conn, 'logbook_shift_notes'));
        $checks[] = smoke_result('logbook_day_close table', table_exists($conn, 'logbook_day_close'));
        $checks[] = smoke_result('backup_schedule_settings table', table_exists($conn, 'backup_schedule_settings'));
        $checks[] = smoke_result('old_student_payments.paid_at_datetime', column_exists($conn, 'old_student_payments', 'paid_at_datetime'));
        $checks[] = smoke_result('logbook_shift_notes.actual_cash_on_hand', column_exists($conn, 'logbook_shift_notes', 'actual_cash_on_hand'));
        $checks[] = smoke_result('student_registration_pending.source_channel', column_exists($conn, 'student_registration_pending', 'source_channel'));

        return $checks;
    }
}

if (!function_exists('school_admin_smoke_failed_checks')) {
    function school_admin_smoke_failed_checks(array $checks): array
    {
        return array_values(array_filter($checks, static fn(array $check): bool => !$check['ok']));
    }
}

if (!function_exists('school_admin_smoke_report_text')) {
    function school_admin_smoke_report_text(array $checks): string
    {
        $failed = school_admin_smoke_failed_checks($checks);
        $lines = [
            'School Admin Smoke Check',
            '========================',
        ];

        foreach ($checks as $check) {
            $lines[] = sprintf(
                '[%s] %s%s',
                $check['ok'] ? 'PASS' : 'FAIL',
                $check['label'],
                $check['details'] !== '' ? ' - ' . $check['details'] : ''
            );
        }

        $lines[] = '';
        $lines[] = 'Summary: ' . (count($checks) - count($failed)) . '/' . count($checks) . ' passed.';

        return implode(PHP_EOL, $lines) . PHP_EOL;
    }
}

$checks = school_admin_smoke_checks($conn);
$failed = school_admin_smoke_failed_checks($checks);
$report = school_admin_smoke_report_text($checks);

if (PHP_SAPI === 'cli') {
    echo $report;
    exit(count($failed) === 0 ? 0 : 1);
}

if (basename((string) ($_SERVER['SCRIPT_FILENAME'] ?? '')) === basename(__FILE__)) {
    header('Content-Type: text/plain; charset=utf-8');
    echo $report;
}
