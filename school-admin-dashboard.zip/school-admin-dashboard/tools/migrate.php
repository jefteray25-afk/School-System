<?php

/**
 * Schema migration runner (Phase 3).
 *
 * Run from CLI:
 *   php tools/migrate.php
 *
 * This enables SCHOOL_SCHEMA_MIGRATION_MODE so helper "ensure_*" functions
 * can safely CREATE/ALTER tables and columns once, outside normal page loads.
 */

declare(strict_types=1);

define('SCHOOL_SCHEMA_MIGRATION_MODE', true);

if (PHP_SAPI === 'cli') {
    $migrationSessionPath = sys_get_temp_dir();
    if (is_dir($migrationSessionPath) && is_writable($migrationSessionPath)) {
        ini_set('session.save_path', $migrationSessionPath);
    }
}

// Some legacy modules start sessions / emit headers. Buffer any accidental output so
// CLI migrations can run without "headers already sent" warnings.
ob_start();

require_once __DIR__ . '/../includes/schema-migration.php';
require_once __DIR__ . '/../config/database.php';

// Settings / backup / uploads
require_once __DIR__ . '/../modules/settings/backup-settings-helper.php';
require_once __DIR__ . '/../modules/settings/upload-storage-helper.php';
require_once __DIR__ . '/../modules/settings/school-year-helper.php';
require_once __DIR__ . '/../modules/settings/fee-grade-settings-helper.php';
require_once __DIR__ . '/../modules/settings/section-management-helper.php';
require_once __DIR__ . '/../modules/settings/section-location-helper.php';

// Audit
require_once __DIR__ . '/../modules/audit/audit-helper.php';
require_once __DIR__ . '/../modules/audit/audit-retention-helper.php';

// Students
require_once __DIR__ . '/../modules/students/student-registration-helper.php';
require_once __DIR__ . '/../modules/students/student-requirements-helper.php';
require_once __DIR__ . '/../modules/students/student-photo-bulk-helper.php';

// Finance / receipts / lock scope
require_once __DIR__ . '/../includes/includes-receipt-helper.php';
require_once __DIR__ . '/../includes/receipt-payment-method-helper.php';
require_once __DIR__ . '/../modules/financial/fee-lock-helper.php';
require_once __DIR__ . '/../modules/accounts/account-fee-exceptions-helper.php';
require_once __DIR__ . '/../modules/accounts/finance-adjustment-helper.php';
require_once __DIR__ . '/../modules/accounts/account-followup-helper.php';
require_once __DIR__ . '/../modules/settings/school-info-helper.php';
require_once __DIR__ . '/../modules/financial/fee-behavior-helper.php';

require_once __DIR__ . '/../modules/logbook/logbook-schema-helper.php';

require_once __DIR__ . '/../modules/old accounts/old-account-followup-helper.php';
require_once __DIR__ . '/../modules/old accounts/old-payments-schema-helper.php';
require_once __DIR__ . '/../modules/rollover/year-end-rollover-helper.php';
require_once __DIR__ . '/../modules/invoice/invoice-total-helper.php';
require_once __DIR__ . '/../modules/invoice/receipt-turnover-bulletin-helper.php';

// Run schema ensure functions (idempotent).
while (ob_get_level() > 0) {
    ob_end_clean();
}
fwrite(STDOUT, "== School Admin Dashboard schema migration ==\n");
fwrite(STDOUT, "Running schema ensure functions...\n");

backup_settings_ensure_table($conn);
upload_storage_ensure_table($conn);
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
fee_grade_settings_ensure_table($conn);
section_management_ensure_table($conn);
section_location_ensure_table($conn);
ensure_school_information_table($conn);

registration_ensure_pending_table($conn);
registration_ensure_student_strand_column($conn);
registration_ensure_rate_limit_table($conn);

student_requirements_ensure_table($conn);
student_requirement_documents_ensure_table($conn);
student_photo_bulk_ensure_tables($conn);

ensure_receipt_history_table($conn);
ensure_receipt_booklet_registry($conn);
ensure_payments_void_archive_table($conn);
ensure_payments_prepared_by_column($conn);
ensure_payments_reference_note_columns($conn);
ensure_receipt_payment_methods_table($conn);

fee_lock_ensure_table($conn);
student_fee_exceptions_ensure_table($conn);
finance_adjustment_ensure_tables($conn);
account_followup_ensure_tables($conn);
fee_behavior_ensure_column($conn);

audit_logs_ensure_archive_table($conn);
audit_retention_ensure_table($conn);

ensure_logbook_notes_table($conn);
ensure_logbook_audit_table($conn);
ensure_logbook_day_close_table($conn);
ensure_logbook_day_close_audit($conn);

ensure_old_student_followup_columns($conn);
year_end_rollover_ensure_table($conn);
ensure_old_student_payments_reference_note_columns($conn);
ensure_old_student_payments_prepared_by_column($conn);
invoice_total_ensure_old_payment_datetime_column($conn);
receipt_turnover_bulletin_ensure_table($conn);

fwrite(STDOUT, "Done.\n");




