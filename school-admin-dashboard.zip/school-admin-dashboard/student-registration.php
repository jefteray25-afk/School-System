﻿<?php
session_start();
include __DIR__ . '/config/database.php';
include __DIR__ . '/modules/students/student-registration-helper.php';
include __DIR__ . '/modules/settings/section-management-helper.php';
include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');

registration_ensure_pending_table($conn);
registration_ensure_student_strand_column($conn);
section_management_ensure_table($conn);
$activeSchoolYear = school_year_get_active($conn);
$activeSchoolYearLabel = $activeSchoolYear['label'] ?? school_year_default_label();
$managedSectionsByGrade = section_management_get_sections_by_grade($conn, $activeSchoolYearLabel, true);
$isEnrollmentOpen = !empty($activeSchoolYear['enrollment_open']);
$requestIp = registration_client_ip();
$allowlistConfig = registration_allowlist_config();
$allowlistSummary = registration_allowlist_summary($allowlistConfig);
$allowlistDisplay = $allowlistSummary !== '' ? ($allowlistSummary . ' + localhost') : 'localhost only';
$isLrnCheckRequest = isset($_GET['check_lrn']);
$isOfflineSyncRequest = $_SERVER['REQUEST_METHOD'] === 'POST' && (($_POST['submission_mode'] ?? '') === 'offline_import');
// BEGIN IP ALLOWLIST
// Registration is public, but restricted to campus LAN only.
// Allowed IPv4 range comes from registration_allowlist_config(). Localhost stays allowed for kiosk testing.
$ipAllowed = registration_ip_allowed($requestIp, $allowlistConfig);

if (!$ipAllowed) {
    $blockedMessage = (string) ($allowlistConfig['blocked_message'] ?? 'Access denied.');
    $entryPoint = $isLrnCheckRequest ? 'lrn_check' : ($isOfflineSyncRequest ? 'offline_import' : 'public_form');
    registration_record_blocked_allowlist_attempt($conn, $requestIp, $entryPoint);
    http_response_code(403);
    if ($isLrnCheckRequest) {
        header('Content-Type: application/json');
        echo json_encode([
            'duplicate' => false,
            'rate_limited' => false,
            'message' => $blockedMessage,
        ]);
    } elseif ($isOfflineSyncRequest) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => $blockedMessage,
        ]);
    } else {
        echo $blockedMessage;
    }
    $conn->close();
    exit;
}
// END IP ALLOWLIST


if (isset($_GET['check_lrn'])) {
    header('Content-Type: application/json');
    $rateStatus = registration_rate_limit_status($conn, 'check_lrn', $requestIp);
    if (!$rateStatus['allowed']) {
        echo json_encode([
            'duplicate' => false,
            'rate_limited' => true,
            'message' => $rateStatus['message'],
        ]);
        $conn->close();
        exit;
    }
    registration_rate_limit_record($conn, 'check_lrn', $requestIp);
    $duplicate = registration_find_duplicate($conn, trim($_GET['check_lrn']), null, $activeSchoolYearLabel);
    echo json_encode([
        'duplicate' => $duplicate['has_duplicate'],
        'message' => $duplicate['message'] ?: 'LRN is available.',
    ]);
    $conn->close();
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (($_POST['submission_mode'] ?? '') === 'offline_import')) {
    header('Content-Type: application/json');
    if (!registration_verify_csrf($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid request token.']);
        $conn->close();
        exit;
    }
    $syncRateStatus = registration_rate_limit_status($conn, 'offline_import', $requestIp);
    if (!$syncRateStatus['allowed']) {
        echo json_encode(['success' => false, 'message' => $syncRateStatus['message']]);
        $conn->close();
        exit;
    }
    registration_rate_limit_record($conn, 'offline_import', $requestIp);
    $payload = json_decode($_POST['payload'] ?? '', true);
    if (!is_array($payload)) {
        echo json_encode(['success' => false, 'message' => 'Invalid offline payload.']);
        $conn->close();
        exit;
    }

    $payload['source_channel'] = trim((string) ($payload['source_channel'] ?? 'offline_sync')) ?: 'offline_sync';
    $result = registration_insert_pending($conn, $payload);
    audit_log(
        $conn,
        'public-registration',
        $result['success'] ? 'Synced offline registration' : 'Failed offline registration sync',
        'Students',
        'LRN: ' . (($payload['lrn'] ?? '') ?: 'N/A') . ' | IP: ' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown') . ' | Station: ' . (($payload['source_station'] ?? '') ?: 'unknown') . ' | Result: ' . ($result['success'] ? 'success' : ($result['message'] ?? 'failed')),
        $result['success'] ? 'INFO' : 'WARNING'
    );
    echo json_encode($result);
    $conn->close();
    exit;
}

$grades = registration_get_grades();
$strandOptions = registration_get_strand_options();
$lastname = $firstname = $middlename = $lrn = $birthday = $age = $gender = $address = $contact = $grade = $strand = $section = $date_enrolled = '';
$guardian_name = $guardian_contact = '';
$error = '';
$success = '';
$successReference = '';
$csrfToken = registration_csrf_token();
$sourceStation = trim((string) ($_POST['source_station'] ?? ''));
$sourceDetails = trim((string) ($_POST['source_details'] ?? ''));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!registration_verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request token. Please refresh the page and try again.';
    }

    $lastname = trim($_POST['lastname'] ?? '');
    $firstname = trim($_POST['firstname'] ?? '');
    $middlename = trim($_POST['middlename'] ?? '');
    $lrn = trim($_POST['lrn'] ?? '');
    $birthday = trim($_POST['birthday'] ?? '');
    $age = trim($_POST['age'] ?? '');
    $gender = trim($_POST['gender'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $contact = trim($_POST['contact'] ?? '');
    $grade = trim($_POST['grade'] ?? '');
    $strand = trim($_POST['strand'] ?? '');
    $section = trim($_POST['section'] ?? '');
    $date_enrolled = trim($_POST['date_enrolled'] ?? '');
    $guardian_name = trim($_POST['guardian_name'] ?? '');
    $guardian_contact = trim($_POST['guardian_contact'] ?? '');
    $sourceStation = trim($_POST['source_station'] ?? '');
    $sourceDetails = trim($_POST['source_details'] ?? '');
    $honeypotWebsite = trim((string) ($_POST['website'] ?? ''));

    $normalized = registration_normalize_submission($_POST);
    $allowedSections = section_management_get_section_names($conn, $activeSchoolYearLabel, $grade, true);
    if ($error === '' && !$isEnrollmentOpen) {
        $error = 'Public registration is currently closed for the active school year.';
    }
    if ($error === '' && $honeypotWebsite !== '') {
        audit_log($conn, 'public-registration', 'Blocked suspected bot registration', 'Students', 'IP: ' . $requestIp . ' | Station: ' . ($sourceStation ?: 'unknown'), 'WARNING');
        $success = 'Registration submitted successfully. Your request is now pending admin approval.';
        $lastname = $firstname = $middlename = $lrn = $birthday = $age = $gender = $address = $contact = $grade = $strand = $section = $date_enrolled = '';
        $guardian_name = $guardian_contact = '';
    }
    if ($error === '' && $success === '') {
        $submitRateKey = (!empty($_SESSION['loggedin']) && !empty($_SESSION['role'])) ? 'operator_submit' : 'public_submit';
        $submitRateStatus = registration_rate_limit_status($conn, $submitRateKey, $requestIp);
        if (!$submitRateStatus['allowed']) {
            $error = $submitRateStatus['message'];
        } else {
            registration_rate_limit_record($conn, $submitRateKey, $requestIp);
        }
    }
    if ($error === '' && $success === '') {
        if ($section !== '' && !in_array($section, $allowedSections, true)) {
            $error = 'Selected section is not active for the chosen grade level. Please leave it blank or choose an available section.';
        }
    }
    if ($error === '' && $success === '') {
        $error = registration_validate_submission($normalized);
    }

    $photo = '';
    if ($error === '' && $success === '' && isset($_FILES['photo'])) {
        $photoUpload = registration_upload_photo($_FILES['photo'], $grade, $lastname, $firstname);
        $photo = $photoUpload['path'];
        if ($photoUpload['error'] !== '') {
            $error = $photoUpload['error'];
        }
    }

    if ($error === '' && $success === '') {
        $normalized['photo'] = $photo;
        $normalized['source_channel'] = 'public_online';
        $normalized['source_station'] = $sourceStation;
        $normalized['source_details'] = $sourceDetails;
        $normalized['school_year_label'] = $activeSchoolYearLabel;
        $insertResult = registration_insert_pending($conn, $normalized);
        if ($insertResult['success']) {
            audit_log($conn, 'public-registration', 'Submitted public registration', 'Students', 'LRN: ' . ($normalized['lrn'] ?? 'N/A') . ' | IP: ' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown') . ' | Station: ' . ($sourceStation ?: 'unknown'));
            $success = 'Registration submitted successfully. Your request is now pending admin approval.';
            $successReference = 'REG-' . str_pad((string) ((int) ($insertResult['id'] ?? 0)), 6, '0', STR_PAD_LEFT);
            $lastname = $firstname = $middlename = $lrn = $birthday = $age = $gender = $address = $contact = $grade = $strand = $section = $date_enrolled = '';
            $guardian_name = $guardian_contact = '';
        } else {
            audit_log($conn, 'public-registration', 'Failed public registration attempt', 'Students', 'LRN: ' . ($normalized['lrn'] ?? 'N/A') . ' | IP: ' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown') . ' | Station: ' . ($sourceStation ?: 'unknown') . ' | Reason: ' . $insertResult['message'], 'WARNING');
            $error = $insertResult['message'];
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && $success === '') {
        audit_log($conn, 'public-registration', 'Failed public registration attempt', 'Students', 'LRN: ' . ($normalized['lrn'] ?? 'N/A') . ' | IP: ' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown') . ' | Station: ' . ($sourceStation ?: 'unknown') . ' | Reason: ' . $error, 'WARNING');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Student Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body {
            background: var(--main-bg);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        }
        .navbar {
            background: var(--navbar-bg) !important;
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.05em;
        }
        .navbar-brand {
            font-weight: 700;
            letter-spacing: 1px;
        }
        .dashboard-header {
            text-align: center;
            margin-top: 36px;
            margin-bottom: 18px;
        }
        .dashboard-header img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            margin-bottom: 6px;
        }
        .dashboard-header h1 {
            font-size: 1.3rem;
            color: var(--brand-dark);
            font-weight: 700;
            margin-bottom: 0;
        }
        .registration-card {
            border-radius: 1rem;
            box-shadow: 0 2px 12px rgba(33,57,93,0.10);
            background: var(--card-bg);
            max-width: 980px;
            margin: 0 auto 30px auto;
        }
        .registration-note {
            background: #eaf4ff;
            border: 1px solid #cfe5fb;
            color: var(--brand-dark);
            border-radius: 12px;
            padding: 12px 14px;
            margin-bottom: 18px;
        }
        #lrnStatus {
            min-height: 24px;
        }
        .offline-card {
            background: #f7fbff;
            border: 1px solid #d6e9fb;
            border-radius: 12px;
            padding: 14px;
            margin-bottom: 18px;
        }
        .workflow-card {
            background: #fffdf5;
            border: 1px solid #f1dfaa;
            border-radius: 12px;
            padding: 14px;
            margin-bottom: 18px;
        }
        .queue-preview {
            margin-top: 14px;
            border-top: 1px solid #d6e9fb;
            padding-top: 12px;
        }
        .queue-item {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            align-items: flex-start;
            border-bottom: 1px solid #edf4fc;
            padding: 10px 0;
        }
        .queue-item:last-child {
            border-bottom: none;
        }
        .queue-item-title {
            font-weight: 600;
            color: var(--brand-dark);
        }
        .queue-item-meta {
            font-size: 0.82rem;
            color: #6c757d;
        }
        @media (max-width: 576px) {
            .dashboard-header {
                margin-top: 18px;
            }
            .dashboard-header img {
                width: 42px;
                height: 42px;
            }
        }
    </style>
</head>
<body>
<div class="dashboard-header">
    <img src="/school-admin-dashboard/uploads/logo1.png" alt="School Logo" class="mb-2 rounded shadow-sm">
    <h1>The Lord's Wisdom Academy Of Caloocan Inc.</h1>
</div>

<div class="container mt-4">
    <div class="registration-card card">
        <div class="card-header bg-primary text-light">
            <i class="fas fa-user-plus"></i> Public Student Registration
        </div>
        <div class="card-body">
            <div class="registration-note">
                <i class="fas fa-circle-info me-2"></i>
                Submitted registrations go to the admin approval queue first. They are not added to the student master list until approved.
                <div class="small mt-2">
                    Active School Year: <strong><?= htmlspecialchars($activeSchoolYearLabel) ?></strong> |
                    Enrollment is currently <strong><?= $isEnrollmentOpen ? 'open' : 'closed' ?></strong>.
                </div>
            </div>
            <?php if (!$isEnrollmentOpen): ?>
                <div class="alert alert-warning">Public registration is currently closed for the active school year.</div>
            <?php endif; ?>
            <div class="offline-card">
                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
                    <div>
                        <strong><i class="fas fa-wifi me-2"></i>Offline Backup Queue</strong>
                        <div class="small text-muted" id="offlineStatusText">Checking connection...</div>
                    </div>
                    <div class="text-end">
                        <div class="small text-muted">Saved offline registrations</div>
                        <div class="fw-bold fs-5" id="offlineCount">0</div>
                    </div>
                </div>
                <div class="small text-muted mt-2">Offline save/export does not include photo uploads. If the station loses connection, save the form offline, export the JSON file, then import it from the admin pending page on the main server.</div>
                <div class="d-flex flex-wrap gap-2 mt-3">
                    <button type="button" class="btn btn-outline-secondary btn-sm" id="saveOfflineBtn"><i class="fas fa-download"></i> Save Offline</button>
                    <button type="button" class="btn btn-outline-dark btn-sm" id="downloadTemplateBtn"><i class="fas fa-file-arrow-down"></i> Download JSON Template</button>
                    <button type="button" class="btn btn-outline-primary btn-sm" id="exportOfflineBtn"><i class="fas fa-file-export"></i> Export Offline Queue</button>
                    <label class="btn btn-outline-info btn-sm mb-0" for="importOfflineFile"><i class="fas fa-file-import"></i> Import Offline File</label>
                    <input type="file" id="importOfflineFile" accept=".json,application/json" class="d-none">
                    <button type="button" class="btn btn-outline-success btn-sm" id="syncOfflineBtn"><i class="fas fa-arrows-rotate"></i> Sync Offline Queue</button>
                    <button type="button" class="btn btn-outline-danger btn-sm" id="clearOfflineBtn"><i class="fas fa-trash"></i> Clear Queue</button>
                </div>
                <div class="queue-preview">
                    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                        <strong class="small text-uppercase text-muted">Offline Queue Preview</strong>
                        <span class="badge text-bg-light">Latest 5 saved records</span>
                    </div>
                    <div id="offlineQueuePreview" class="small text-muted">No offline records saved yet.</div>
                </div>
            </div>

            <div class="workflow-card">
                <strong><i class="fas fa-route me-2"></i>Registration Workflow</strong>
                <div class="small text-muted mt-2">
                    1. Submit online if connected. 2. Save offline if the station loses connection. 3. Export JSON from the offline queue. 4. Import or sync the records back to the main server pending queue.
                </div>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <div><?= htmlspecialchars($success) ?></div>
                    <?php if ($successReference !== ''): ?>
                        <div class="small mt-2">Reference No: <strong><?= htmlspecialchars($successReference) ?></strong></div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <form method="post" action="" autocomplete="off" enctype="multipart/form-data" id="registrationForm">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                <input type="hidden" name="source_station" id="sourceStationField" value="<?= htmlspecialchars($sourceStation) ?>">
                <input type="hidden" name="source_details" id="sourceDetailsField" value="<?= htmlspecialchars($sourceDetails) ?>">
                <div class="d-none" aria-hidden="true">
                    <label for="websiteField">Website</label>
                    <input type="text" class="form-control" name="website" id="websiteField" tabindex="-1" autocomplete="off">
                </div>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Last Name:</label>
                        <input type="text" class="form-control" name="lastname" value="<?= htmlspecialchars($lastname) ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">First Name:</label>
                        <input type="text" class="form-control" name="firstname" value="<?= htmlspecialchars($firstname) ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Middle Name <span class="text-muted">(optional)</span>:</label>
                        <input type="text" class="form-control" name="middlename" value="<?= htmlspecialchars($middlename) ?>">
                    </div>
                </div>
                <div class="row mb-1">
                    <div class="col-md-4">
                        <label class="form-label">LRN <span class="text-muted">(optional, 12 digits if available)</span>:</label>
                        <input type="text" class="form-control" name="lrn" id="lrnField" value="<?= htmlspecialchars($lrn) ?>" maxlength="12">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Birthday:</label>
                        <input type="date" class="form-control" name="birthday" id="birthday" value="<?= htmlspecialchars($birthday) ?>" required onchange="calcAge()">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Age:</label>
                        <input type="text" class="form-control" name="age" id="age" value="<?= htmlspecialchars($age) ?>" readonly required>
                    </div>
                </div>
                <div id="lrnStatus" class="small mb-3"></div>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Gender:</label>
                        <select class="form-select" name="gender" required>
                            <option value="">Select</option>
                            <option value="Male" <?= $gender === 'Male' ? 'selected' : '' ?>>Male</option>
                            <option value="Female" <?= $gender === 'Female' ? 'selected' : '' ?>>Female</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Address:</label>
                        <input type="text" class="form-control" name="address" value="<?= htmlspecialchars($address) ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Grade Section <span class="text-muted">(optional)</span>:</label>
                        <select class="form-select" name="section" id="sectionField" data-current-section="<?= htmlspecialchars($section) ?>">
                            <option value="">No section yet</option>
                        </select>
                        <small class="text-muted" id="sectionHelpText">You may leave this blank if section assignment is not final yet.</small>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Contact Number <span class="text-muted">(09xx-xxx-xxxx)</span>:</label>
                        <input type="text" class="form-control" name="contact" id="contactField" value="<?= htmlspecialchars($contact) ?>" placeholder="e.g. 0917-345-6789" maxlength="13" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Grade Level:</label>
                        <select class="form-select" name="grade" id="gradeField" required>
                            <option value="">Select Grade</option>
                            <?php foreach ($grades as $g): ?>
                                <option value="<?= htmlspecialchars($g) ?>" <?= $grade === $g ? 'selected' : '' ?>><?= htmlspecialchars($g) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Strand:</label>
                        <select class="form-select" name="strand" id="strandField" data-current-strand="<?= htmlspecialchars($strand) ?>">
                            <option value="">Select Strand</option>
                            <?php foreach ($strandOptions as $option): ?>
                                <option value="<?= htmlspecialchars($option) ?>" <?= $strand === $option ? 'selected' : '' ?>><?= htmlspecialchars($option) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <small class="text-muted" id="strandHelpText">Required for Grade 11 or Grade 12 only.</small>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Preferred Date Enrolled:</label>
                        <input type="date" class="form-control" name="date_enrolled" value="<?= htmlspecialchars($date_enrolled) ?>" required>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Guardian Name:</label>
                        <input type="text" class="form-control" name="guardian_name" value="<?= htmlspecialchars($guardian_name) ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Guardian Contact <span class="text-muted">(optional)</span>:</label>
                        <input type="text" class="form-control" name="guardian_contact" id="guardianContactField" value="<?= htmlspecialchars($guardian_contact) ?>" placeholder="e.g. 0917-345-6789" maxlength="13">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Photo (max 2MB):</label>
                    <input type="file" class="form-control" name="photo" accept="image/*">
                </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-primary" <?= !$isEnrollmentOpen ? 'disabled' : '' ?>><i class="fas fa-paper-plane"></i> Submit Registration</button>
                    <a href="/school-admin-dashboard/school.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
                </div>
            </form>
        </div>
    </div>
</div>

<footer class="text-center py-4 text-muted small">
    &copy; <?= date('Y') ?> The Lord's Wisdom Academy Of Caloocan Inc. | School Admin Dashboard
</footer>

<script>
const managedSectionsByGrade = <?= json_encode($managedSectionsByGrade, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;

function calcAge() {
    const birthdayInput = document.getElementById('birthday');
    const ageInput = document.getElementById('age');
    if (!birthdayInput.value) {
        ageInput.value = '';
        return;
    }

    const birth = new Date(birthdayInput.value);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
        age--;
    }
    ageInput.value = age >= 0 ? age : '';
}

function bindPhoneMask(fieldId) {
    const input = document.getElementById(fieldId);
    if (!input) {
        return;
    }

    input.addEventListener('input', function() {
        let digits = input.value.replace(/\D/g, '');
        if (digits.length > 11) {
            digits = digits.slice(0, 11);
        }

        let formatted = digits.substring(0, 4);
        if (digits.length > 4) {
            formatted += '-' + digits.substring(4, 7);
        }
        if (digits.length > 7) {
            formatted += '-' + digits.substring(7, 11);
        }
        input.value = formatted;
    });
}

document.addEventListener('DOMContentLoaded', function() {
    calcAge();
    bindPhoneMask('contactField');
    bindPhoneMask('guardianContactField');

    const storageKey = 'school_admin_offline_registrations_v1';
    const stationKey = 'school_admin_registration_station_id_v1';
    const registrationForm = document.getElementById('registrationForm');
    const lrnField = document.getElementById('lrnField');
    const lrnStatus = document.getElementById('lrnStatus');
    const offlineCount = document.getElementById('offlineCount');
    const offlineStatusText = document.getElementById('offlineStatusText');
    const saveOfflineBtn = document.getElementById('saveOfflineBtn');
    const downloadTemplateBtn = document.getElementById('downloadTemplateBtn');
    const exportOfflineBtn = document.getElementById('exportOfflineBtn');
    const importOfflineFile = document.getElementById('importOfflineFile');
    const syncOfflineBtn = document.getElementById('syncOfflineBtn');
    const clearOfflineBtn = document.getElementById('clearOfflineBtn');
    const offlineQueuePreview = document.getElementById('offlineQueuePreview');
    const gradeField = document.getElementById('gradeField');
    const sectionField = document.getElementById('sectionField');
    const sectionHelpText = document.getElementById('sectionHelpText');
    const strandField = document.getElementById('strandField');
    const strandHelpText = document.getElementById('strandHelpText');
    const sourceStationField = document.getElementById('sourceStationField');
    const sourceDetailsField = document.getElementById('sourceDetailsField');

    function renderSectionOptions() {
        const selectedGrade = gradeField ? gradeField.value : '';
        const currentSection = sectionField ? (sectionField.dataset.currentSection || '') : '';
        const options = managedSectionsByGrade[selectedGrade] || [];

        if (!sectionField) {
            return;
        }

        sectionField.innerHTML = '';
        const emptyOption = document.createElement('option');
        emptyOption.value = '';
        emptyOption.textContent = 'No section yet';
        sectionField.appendChild(emptyOption);

        options.forEach((sectionName) => {
            const option = document.createElement('option');
            option.value = sectionName;
            option.textContent = sectionName;
            sectionField.appendChild(option);
        });

        if (currentSection && !options.includes(currentSection)) {
            const legacyOption = document.createElement('option');
            legacyOption.value = currentSection;
            legacyOption.textContent = currentSection + ' (saved value)';
            sectionField.appendChild(legacyOption);
        }

        sectionField.value = currentSection;
        if (sectionHelpText) {
            sectionHelpText.textContent = options.length > 0
                ? 'Available sections are filtered by the selected grade level. You may still leave this blank.'
                : 'No managed sections yet for this grade level. Leave this blank if section assignment is not final yet.';
        }
    }

    function updateStrandState() {
        if (!strandField) return;
        const isSeniorHigh = ['Grade 11', 'Grade 12'].includes(gradeField ? gradeField.value : '');
        strandField.disabled = !isSeniorHigh;
        strandField.required = isSeniorHigh;
        if (isSeniorHigh) {
            if (strandField.dataset.currentStrand) strandField.value = strandField.dataset.currentStrand;
            if (strandHelpText) strandHelpText.textContent = 'Select the strand for Grade 11 or Grade 12.';
        } else {
            strandField.value = '';
            if (strandHelpText) strandHelpText.textContent = 'Strand is only required for Grade 11 or Grade 12.';
        }
    }

    function getStationId() {
        let stationId = localStorage.getItem(stationKey);
        if (!stationId) {
            stationId = 'REG-' + Math.random().toString(36).slice(2, 8).toUpperCase();
            localStorage.setItem(stationKey, stationId);
        }
        return stationId;
    }

    function loadQueue() {
        try {
            return JSON.parse(localStorage.getItem(storageKey) || '[]');
        } catch (error) {
            return [];
        }
    }

    function saveQueue(queue) {
        localStorage.setItem(storageKey, JSON.stringify(queue));
        renderOfflineCount();
        renderOfflinePreview();
    }

    function renderOfflineCount() {
        offlineCount.textContent = loadQueue().length;
    }

    function queueKey(record) {
        const lrn = (record.lrn || '').toString().trim();
        if (lrn !== '') {
            return 'lrn:' + lrn;
        }

        return [
            (record.lastname || '').toString().trim().toLowerCase(),
            (record.firstname || '').toString().trim().toLowerCase(),
            (record.birthday || '').toString().trim(),
            (record.grade || '').toString().trim().toLowerCase()
        ].join('|');
    }

    function renderOfflinePreview() {
        const queue = loadQueue();
        if (queue.length === 0) {
            offlineQueuePreview.className = 'small text-muted';
            offlineQueuePreview.textContent = 'No offline records saved yet.';
            return;
        }

        const latestItems = queue.slice(-5).reverse();
        offlineQueuePreview.className = '';
        offlineQueuePreview.innerHTML = latestItems.map((record) => {
            const fullName = [record.lastname, record.firstname].filter(Boolean).join(', ') || 'Unnamed record';
            const grade = record.grade || 'No grade';
            const savedAt = record.saved_offline_at ? new Date(record.saved_offline_at).toLocaleString() : 'Unknown time';
            const ref = record.lrn ? `LRN ${record.lrn}` : 'No LRN';

            return `
                <div class="queue-item">
                    <div>
                        <div class="queue-item-title">${fullName}</div>
                        <div class="queue-item-meta">${grade} &bull; ${ref}</div>
                    </div>
                    <div class="queue-item-meta text-end">${savedAt}</div>
                </div>
            `;
        }).join('');
    }

    function renderConnectionState() {
        offlineStatusText.textContent = navigator.onLine
            ? 'Online. Direct submissions will go to the server pending queue.'
            : 'Offline detected. Form submissions can be saved locally and exported.';
    }

    function collectFormData() {
        const formData = new FormData(registrationForm);
        return {
            lastname: (formData.get('lastname') || '').toString().trim(),
            firstname: (formData.get('firstname') || '').toString().trim(),
            middlename: (formData.get('middlename') || '').toString().trim(),
            lrn: (formData.get('lrn') || '').toString().replace(/\D/g, '').trim(),
            birthday: (formData.get('birthday') || '').toString().trim(),
            age: (formData.get('age') || '').toString().trim(),
            gender: (formData.get('gender') || '').toString().trim(),
            address: (formData.get('address') || '').toString().trim(),
            contact: (formData.get('contact') || '').toString().trim(),
            grade: (formData.get('grade') || '').toString().trim(),
            strand: (formData.get('strand') || '').toString().trim(),
            section: (formData.get('section') || '').toString().trim(),
            date_enrolled: (formData.get('date_enrolled') || '').toString().trim(),
            guardian_name: (formData.get('guardian_name') || '').toString().trim(),
            guardian_contact: (formData.get('guardian_contact') || '').toString().trim(),
            photo: '',
            source_channel: 'offline_saved',
            source_station: getStationId(),
            source_details: 'Saved offline from browser station',
            saved_offline_at: new Date().toISOString()
        };
    }

    function validateOfflineRecord(record) {
        if (!record.lastname || !record.firstname || !record.birthday || !record.age || !record.gender ||
            !record.address || !record.contact || !record.grade || !record.date_enrolled || !record.guardian_name) {
            return 'Complete the required fields first before saving offline.';
        }
        if (record.lrn && record.lrn.length !== 12) {
            return 'LRN must be exactly 12 digits.';
        }
        if (['Grade 11', 'Grade 12'].includes(record.grade) && !record.strand) {
            return 'Select a strand for Grade 11 or Grade 12 before saving offline.';
        }
        return '';
    }

    function saveCurrentFormOffline() {
        const record = collectFormData();
        const validationMessage = validateOfflineRecord(record);
        if (validationMessage) {
            alert(validationMessage);
            return;
        }

        const queue = loadQueue();
        if (record.lrn && queue.some(item => item.lrn === record.lrn)) {
            alert('This LRN is already saved in the offline queue.');
            return;
        }
        if (queue.some(item => queueKey(item) === queueKey(record))) {
            alert('This registration is already saved in the offline queue.');
            return;
        }

        queue.push(record);
        saveQueue(queue);
        alert('Registration saved to the offline queue.');
    }

    async function syncOfflineQueue() {
        const queue = loadQueue();
        if (queue.length === 0) {
            alert('Offline queue is empty.');
            return;
        }
        if (!navigator.onLine) {
            alert('This PC is still offline. Reconnect to the main server before syncing.');
            return;
        }

        const remaining = [];
        let imported = 0;

        for (const record of queue) {
            const body = new URLSearchParams();
            body.set('submission_mode', 'offline_import');
            body.set('csrf_token', <?= json_encode($csrfToken) ?>);
            record.source_channel = 'offline_sync';
            body.set('payload', JSON.stringify(record));

            try {
                const response = await fetch('/school-admin-dashboard/student-registration.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: body.toString()
                });
                const result = await response.json();
                if (result.success) {
                    imported++;
                } else {
                    remaining.push(record);
                }
            } catch (error) {
                remaining.push(record);
            }
        }

        saveQueue(remaining);
        alert(imported + ' offline registration(s) synced. Remaining queue: ' + remaining.length + '.');
    }

    async function checkLrn() {
        const lrn = lrnField.value.replace(/\D/g, '').slice(0, 12);
        lrnField.value = lrn;

        if (lrn.length === 0) {
            lrnStatus.className = 'small mb-3 text-muted';
            lrnStatus.textContent = 'LRN is optional. Leave blank if it is still pending, or enter 12 digits to check duplicates.';
            return;
        }

        if (lrn.length < 12) {
            lrnStatus.className = 'small mb-3 text-muted';
            lrnStatus.textContent = 'Enter the full 12-digit LRN to run the duplicate check.';
            return;
        }

        try {
            const response = await fetch('/school-admin-dashboard/student-registration.php?check_lrn=' + encodeURIComponent(lrn));
            const result = await response.json();
            if (result.rate_limited) {
                lrnStatus.className = 'small mb-3 text-warning';
            } else {
                lrnStatus.className = result.duplicate ? 'small mb-3 text-danger' : 'small mb-3 text-success';
            }
            lrnStatus.textContent = result.message;
        } catch (error) {
            lrnStatus.className = 'small mb-3 text-muted';
            lrnStatus.textContent = 'Duplicate check is temporarily unavailable.';
        }
    }

    registrationForm.addEventListener('submit', function(event) {
        if (!navigator.onLine) {
            event.preventDefault();
            saveCurrentFormOffline();
        }
    });
    saveOfflineBtn.addEventListener('click', saveCurrentFormOffline);
    exportOfflineBtn.addEventListener('click', function() {
        const queue = loadQueue();
        if (queue.length === 0) {
            alert('Offline queue is empty.');
            return;
        }
        const blob = new Blob([JSON.stringify(queue, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'student-registration-offline-' + new Date().toISOString().slice(0, 10) + '.json';
        link.click();
        URL.revokeObjectURL(url);
    });
    downloadTemplateBtn.addEventListener('click', function() {
        const template = {
            source_channel: 'offline_saved',
            source_station: getStationId(),
            source_details: 'Offline registration template',
            records: [
                {
                    lastname: 'Dela Cruz',
                    firstname: 'Juan',
                    middlename: 'Santos',
                    lrn: '',
                    birthday: '2018-06-15',
                    age: '7',
                    gender: 'Male',
                    address: 'Sample Address',
                    contact: '0917-345-6789',
                    grade: 'Grade 1',
                    strand: '',
                    section: '',
                    date_enrolled: '<?= htmlspecialchars(date('Y-m-d'), ENT_QUOTES) ?>',
                    guardian_name: 'Maria Dela Cruz',
                    guardian_contact: '0918-123-4567',
                    photo: ''
                }
            ]
        };
        const blob = new Blob([JSON.stringify(template, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'offline_registration_template.json';
        link.click();
        URL.revokeObjectURL(url);
    });
    importOfflineFile.addEventListener('change', async function() {
        const file = importOfflineFile.files[0];
        if (!file) {
            return;
        }
        try {
            const text = await file.text();
            const parsed = JSON.parse(text);
            const records = Array.isArray(parsed) ? parsed : (Array.isArray(parsed.records) ? parsed.records : []);
            if (!records.length) {
                alert('No registration records found in the selected JSON file.');
                return;
            }
            const queue = loadQueue();
            const existingKeys = new Set(queue.map(item => queueKey(item)));
            let importedCount = 0;
            let skippedCount = 0;
            records.forEach((record) => {
                const normalizedRecord = {
                    ...record,
                    source_channel: record.source_channel || 'offline_saved',
                    source_station: record.source_station || getStationId(),
                    source_details: record.source_details || 'Imported offline JSON',
                    saved_offline_at: record.saved_offline_at || new Date().toISOString()
                };
                const uniqueKey = queueKey(normalizedRecord);
                if (existingKeys.has(uniqueKey)) {
                    skippedCount++;
                    return;
                }
                existingKeys.add(uniqueKey);
                queue.push(normalizedRecord);
                importedCount++;
            });
            saveQueue(queue);
            alert(`${importedCount} offline registration record(s) imported into the local queue. ${skippedCount > 0 ? skippedCount + ' duplicate record(s) skipped.' : ''}`);
        } catch (error) {
            alert('Could not import the selected JSON file.');
        } finally {
            importOfflineFile.value = '';
        }
    });
    syncOfflineBtn.addEventListener('click', syncOfflineQueue);
    clearOfflineBtn.addEventListener('click', function() {
        if (!confirm('Clear all saved offline registrations from this browser queue?')) {
            return;
        }
        saveQueue([]);
    });
    lrnField.addEventListener('input', checkLrn);
    lrnField.addEventListener('blur', checkLrn);
    sourceStationField.value = getStationId();
    sourceDetailsField.value = navigator.userAgent;
    renderOfflineCount();
    renderOfflinePreview();
    renderConnectionState();
    renderSectionOptions();
    updateStrandState();
    if (gradeField) {
        gradeField.addEventListener('change', function() {
            if (sectionField) {
                sectionField.dataset.currentSection = '';
            }
            renderSectionOptions();
            updateStrandState();
        });
    }
    window.addEventListener('online', renderConnectionState);
    window.addEventListener('offline', renderConnectionState);
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <div class="text-center small text-muted mt-4 mb-3">
        Detected IP: <strong><?= htmlspecialchars($requestIp) ?></strong> | Allowed: <strong><?= htmlspecialchars($allowlistDisplay) ?></strong>
    </div>

<script>
(function () {
  // Kiosk-friendly idle timeout: if no interaction happens, go back to the portal.
  // Adjust safely here.
  const IDLE_REDIRECT_MS = 30 * 1000;
  const WARNING_MS = 5 * 1000;
  const TARGET_URL = 'school.php';

  let lastActivity = Date.now();
  let warned = false;

  function touch() {
    lastActivity = Date.now();
    warned = false;
    const el = document.getElementById('idleWarning');
    if (el) el.remove();
  }

  function showWarning(seconds) {
    if (document.getElementById('idleWarning')) return;
    const wrap = document.createElement('div');
    wrap.id = 'idleWarning';
    wrap.style.position = 'fixed';
    wrap.style.left = '14px';
    wrap.style.right = '14px';
    wrap.style.bottom = '14px';
    wrap.style.zIndex = '9999';
    wrap.style.background = 'rgba(15, 23, 42, 0.86)';
    wrap.style.color = '#fff';
    wrap.style.border = '1px solid rgba(255,255,255,0.18)';
    wrap.style.borderRadius = '14px';
    wrap.style.padding = '12px 14px';
    wrap.style.boxShadow = '0 18px 40px rgba(0,0,0,0.24)';
    wrap.style.backdropFilter = 'blur(10px)';

    wrap.innerHTML =
      '<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">' +
      '  <div style="display:flex;align-items:center;gap:10px;">' +
      '    <i class="fa-solid fa-hourglass-half"></i>' +
      '    <div>' +
      '      <div style="font-weight:800;letter-spacing:0.02em;">Returning to portal</div>' +
      '      <div style="opacity:0.85;font-size:0.92rem;">No activity detected. Redirecting in <span id="idleCountdown">' + seconds + '</span>s.</div>' +
      '    </div>' +
      '  </div>' +
      '  <button id="idleStayBtn" type="button" class="btn btn-sm btn-light">Continue</button>' +
      '</div>';

    document.body.appendChild(wrap);
    const btn = document.getElementById('idleStayBtn');
    if (btn) btn.addEventListener('click', touch);
  }

  const events = ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll', 'input', 'click'];
  events.forEach((evt) => window.addEventListener(evt, touch, { passive: true }));

  setInterval(function () {
    const idleFor = Date.now() - lastActivity;
    const remaining = IDLE_REDIRECT_MS - idleFor;

    if (!warned && remaining <= WARNING_MS && remaining > 0) {
      warned = true;
      showWarning(Math.ceil(remaining / 1000));
    }

    const countdown = document.getElementById('idleCountdown');
    if (countdown && remaining > 0) {
      countdown.textContent = String(Math.ceil(remaining / 1000));
    }

    if (remaining <= 0) {
      window.location.href = TARGET_URL;
    }
  }, 500);
})();
</script>
</body>
</html>
<?php $conn->close(); ?>




