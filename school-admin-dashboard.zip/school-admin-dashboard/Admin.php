<?php
require __DIR__ . '/includes/admin-session.php';
admin_session_start();
include __DIR__ . '/config/database.php';
include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');
require_once __DIR__ . '/modules/settings/school-info-helper.php';
require_once __DIR__ . '/includes/schema-migration.php';

$adminAccessConfig = file_exists(__DIR__ . '/config/admin-access.php')
    ? require __DIR__ . '/config/admin-access.php'
    : ['allowed_ips' => ['127.0.0.1', '::1'], 'allowed_subnets' => []];

function admin_login_security_config(): array {
    return [
        'max_attempts' => 5,
        'window_seconds' => 15 * 60,
        'lockout_seconds' => 15 * 60,
    ];
}

function ensure_admin_login_attempts_table(mysqli $conn): void {
    if (!schema_migration_mode_enabled()) {
        return;
    }

    schema_migration_attempt($conn, "
        CREATE TABLE IF NOT EXISTS admin_login_attempts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(100) NOT NULL,
            ip_address VARCHAR(64) NOT NULL,
            user_agent VARCHAR(255) NULL,
            successful TINYINT(1) NOT NULL DEFAULT 0,
            locked_until DATETIME NULL,
            attempt_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_admin_login_attempts_user_ip_time (username, ip_address, attempt_time),
            INDEX idx_admin_login_attempts_lock (locked_until)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
}

function admin_login_attempt_status(mysqli $conn, string $username, string $ip): array {
    $config = admin_login_security_config();
    $windowStart = date('Y-m-d H:i:s', time() - $config['window_seconds']);

    $stmt = $conn->prepare("
        SELECT
            COUNT(*) AS failed_count,
            MAX(locked_until) AS locked_until
        FROM admin_login_attempts
        WHERE username = ?
          AND ip_address = ?
          AND successful = 0
          AND attempt_time >= ?
    ");
    $stmt->bind_param('sss', $username, $ip, $windowStart);
    $stmt->execute();
    $stmt->bind_result($failedCount, $lockedUntil);
    $stmt->fetch();
    $stmt->close();

    $lockedUntilTs = $lockedUntil ? strtotime((string) $lockedUntil) : false;
    $isLocked = $lockedUntilTs !== false && $lockedUntilTs > time();

    return [
        'failed_count' => (int) $failedCount,
        'locked_until' => $lockedUntil ?: null,
        'is_locked' => $isLocked,
    ];
}

function admin_login_record_attempt(mysqli $conn, string $username, string $ip, bool $successful): array {
    $config = admin_login_security_config();
    $status = admin_login_attempt_status($conn, $username, $ip);
    $failedCountAfterThisAttempt = $successful ? 0 : ($status['failed_count'] + 1);
    $lockUntil = null;

    if (!$successful && $failedCountAfterThisAttempt >= $config['max_attempts']) {
        $lockUntil = date('Y-m-d H:i:s', time() + $config['lockout_seconds']);
    }

    $userAgent = substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255);
    $successValue = $successful ? 1 : 0;
    $stmt = $conn->prepare("
        INSERT INTO admin_login_attempts (username, ip_address, user_agent, successful, locked_until)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->bind_param('sssis', $username, $ip, $userAgent, $successValue, $lockUntil);
    $stmt->execute();
    $stmt->close();

    return [
        'failed_count' => $failedCountAfterThisAttempt,
        'locked_until' => $lockUntil,
        'is_locked' => $lockUntil !== null,
    ];
}

function admin_login_clear_failed_attempts(mysqli $conn, string $username, string $ip): void {
    $stmt = $conn->prepare("
        DELETE FROM admin_login_attempts
        WHERE username = ?
          AND ip_address = ?
          AND successful = 0
    ");
    $stmt->bind_param('ss', $username, $ip);
    $stmt->execute();
    $stmt->close();
}

function admin_login_lock_message(?string $lockedUntil): string {
    if (!$lockedUntil) {
        return 'Too many failed sign-in attempts. Please wait before trying again.';
    }

    $secondsRemaining = max(1, strtotime($lockedUntil) - time());
    $minutesRemaining = (int) ceil($secondsRemaining / 60);

    return 'Too many failed sign-in attempts. Please wait about ' . $minutesRemaining . ' minute(s) before trying again.';
}

function ip_in_cidr($ip, $cidr) {
    if (strpos($cidr, '/') === false) {
        return $ip === $cidr;
    }
    [$subnet, $maskBits] = explode('/', $cidr, 2);
    $ipLong = ip2long($ip);
    $subnetLong = ip2long($subnet);
    if ($ipLong === false || $subnetLong === false) {
        return false;
    }
    $mask = -1 << (32 - (int) $maskBits);
    $subnetLong &= $mask;
    return ($ipLong & $mask) === $subnetLong;
}

function admin_ip_allowed($ip, array $config) {
    if (in_array($ip, $config['allowed_ips'] ?? [], true)) {
        return true;
    }
    foreach (($config['allowed_subnets'] ?? []) as $subnet) {
        if (ip_in_cidr($ip, $subnet)) {
            return true;
        }
    }
    return false;
}

$error = "";
$remoteIp = $_SERVER['REMOTE_ADDR'] ?? '';
$reason = $_GET['reason'] ?? '';
$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$schoolContactLine = school_info_contact_line($schoolInfo);
$securityNote = 'Admin access is limited to authorized devices and trusted school network locations.';
$sessionNote = 'For security, admin sessions expire automatically after inactivity.';
ensure_admin_login_attempts_table($conn);
$reasonMessage = '';
$reasonType = 'warning';

if ($reason === 'idle_timeout') {
    $reasonMessage = 'Your session expired due to inactivity. Please sign in again.';
} elseif ($reason === 'absolute_timeout') {
    $reasonMessage = 'Your session reached the maximum allowed duration. Please sign in again.';
} elseif ($reason === 'login_required') {
    $reasonMessage = 'Please sign in to continue.';
    $reasonType = 'info';
}

if (!admin_ip_allowed($remoteIp, $adminAccessConfig)) {
    audit_log($conn, 'blocked-ip', 'Blocked admin login access', 'Authentication', 'IP: ' . $remoteIp, 'SECURITY');
    http_response_code(403);
    die('Admin login is restricted to the main server or trusted LAN IPs.');
}

if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $attemptStatus = admin_login_attempt_status($conn, $username, $remoteIp);

    if ($attemptStatus['is_locked']) {
        $error = admin_login_lock_message($attemptStatus['locked_until']);
        audit_log(
            $conn,
            $username,
            'Blocked login',
            'Authentication',
            'Reason: temporary lockout active, IP: ' . $remoteIp . ', Locked until: ' . ($attemptStatus['locked_until'] ?? 'unknown'),
            'SECURITY'
        );
    } else {
        $stmt = $conn->prepare("SELECT id, password, role FROM admins WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->bind_result($adminId, $hash, $role);
        $found = $stmt->fetch(); // save result in variable
        $stmt->close(); // CLOSE the statement BEFORE audit_log

        if ($found) {
            if (password_verify($password, $hash)) {
                admin_login_record_attempt($conn, $username, $remoteIp, true);
                admin_login_clear_failed_attempts($conn, $username, $remoteIp);
                session_regenerate_id(true); // Prevent session fixation
                admin_session_init_login();
                $_SESSION['user_id'] = (int) $adminId;
                $_SESSION['username'] = $username;
                $_SESSION['role'] = $role;
                
                // AUDIT LOG: Successful login
                $action = "Logged in";
                $module = "Authentication";
                $details = "Admin ID: " . (int) $adminId . ", Role: $role, IP: " . $remoteIp;
                audit_log($conn, $username, $action, $module, $details);

                header('Location: Dashboard.php');
                exit();
            } else {
                $attemptResult = admin_login_record_attempt($conn, $username, $remoteIp, false);
                $error = $attemptResult['is_locked']
                    ? admin_login_lock_message($attemptResult['locked_until'])
                    : "Invalid credentials.";
                
                // AUDIT LOG: Failed login (invalid password)
                $action = $attemptResult['is_locked'] ? "Login locked" : "Failed login";
                $module = "Authentication";
                $details = "Reason: invalid password, IP: " . $remoteIp
                    . ", Failed attempts: " . (int) $attemptResult['failed_count']
                    . ($attemptResult['locked_until'] ? ", Locked until: " . $attemptResult['locked_until'] : '');
                audit_log($conn, $username, $action, $module, $details, $attemptResult['is_locked'] ? 'SECURITY' : null);
            }
        } else {
            $attemptResult = admin_login_record_attempt($conn, $username, $remoteIp, false);
            $error = $attemptResult['is_locked']
                ? admin_login_lock_message($attemptResult['locked_until'])
                : "Invalid credentials.";
            
            // AUDIT LOG: Failed login (username not found)
            $action = $attemptResult['is_locked'] ? "Login locked" : "Failed login";
            $module = "Authentication";
            $details = "Reason: username not found, IP: " . $remoteIp
                . ", Failed attempts: " . (int) $attemptResult['failed_count']
                . ($attemptResult['locked_until'] ? ", Locked until: " . $attemptResult['locked_until'] : '');
            audit_log($conn, $username, $action, $module, $details, $attemptResult['is_locked'] ? 'SECURITY' : null);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --page-bg: #eef3f8;
            --panel-bg: #ffffff;
            --brand-dark: #16283f;
            --brand-mid: #315f86;
            --brand-accent: #4b86b8;
            --brand-soft: #edf6ff;
            --ink: #16283f;
            --muted: #65778b;
            --line-soft: #d7e3ef;
            --success-soft: #eaf8f1;
            --success: #19764d;
        }
        body {
            background:
                linear-gradient(180deg, #f8fbff 0%, var(--page-bg) 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            padding: 24px 0;
            color: var(--ink);
        }
        .login-shell {
            max-width: 1040px;
            margin: 0 auto;
        }
        .login-frame {
            background: rgba(255,255,255,0.72);
            border: 1px solid rgba(215,227,239,0.92);
            border-radius: 28px;
            box-shadow: 0 24px 60px rgba(22,40,63,0.12);
            padding: 10px;
        }
        .brand-panel {
            background:
                linear-gradient(165deg, #15263d 0%, #23486c 58%, #2f668f 100%);
            color: #fff;
            border-radius: 22px;
            padding: 34px 32px;
            height: 100%;
            position: relative;
            overflow: hidden;
            min-height: 490px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .brand-panel::after {
            content: "";
            position: absolute;
            inset: auto -40px -80px auto;
            width: 240px;
            height: 240px;
            border-radius: 50%;
            border: 42px solid rgba(255,255,255,0.055);
            pointer-events: none;
        }
        .brand-logo {
            width: 88px;
            height: 88px;
            object-fit: contain;
            border-radius: 20px;
            background: rgba(255,255,255,0.96);
            padding: 10px;
            margin-bottom: 20px;
            box-shadow: 0 14px 32px rgba(0,0,0,0.12);
        }
        .brand-eyebrow {
            font-size: 0.82rem;
            letter-spacing: 0.12em;
            text-transform: uppercase;
            color: #cfe3f7;
            margin-bottom: 10px;
            font-weight: 700;
        }
        .brand-title {
            font-size: 2rem;
            line-height: 1.15;
            font-weight: 800;
            margin-bottom: 10px;
            letter-spacing: 0;
        }
        .brand-subtitle {
            font-size: 1rem;
            color: #dceaf7;
            margin-bottom: 20px;
            max-width: 42ch;
            line-height: 1.55;
        }
        .brand-badges {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
        }
        .brand-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 11px;
            border-radius: 999px;
            border: 1px solid rgba(255,255,255,0.18);
            background: rgba(255,255,255,0.10);
            font-size: 0.92rem;
            color: #f3f8fd;
        }
        .brand-notes {
            display: grid;
            gap: 12px;
            margin-top: 12px;
            position: relative;
            z-index: 1;
        }
        .brand-note {
            border: 1px solid rgba(255,255,255,0.14);
            border-radius: 14px;
            background: rgba(255,255,255,0.075);
            padding: 12px 13px;
            font-size: 0.95rem;
            color: #e5f0fb;
            line-height: 1.42;
        }
        .login-card {
            background: var(--panel-bg);
            border-radius: 22px;
            border: 1px solid rgba(215,227,239,0.96);
            height: 100%;
            min-height: 490px;
            display: flex;
            align-items: center;
        }
        .login-title {
            font-size: 1.6rem;
            font-weight: 800;
            color: var(--brand-dark);
            margin-bottom: 4px;
        }
        .login-subtitle {
            color: var(--muted);
            font-size: 0.98rem;
            margin-bottom: 20px;
        }
        .login-body {
            padding: 34px 32px;
            width: 100%;
        }
        .login-system-pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            border-radius: 999px;
            padding: 8px 12px;
            background: var(--brand-soft);
            color: var(--brand-mid);
            border: 1px solid #d7eafe;
            font-weight: 700;
            font-size: 0.88rem;
            margin-bottom: 18px;
        }
        .security-strip {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 8px;
            margin-bottom: 20px;
        }
        .security-strip-item {
            border: 1px solid var(--line-soft);
            border-radius: 14px;
            padding: 10px 8px;
            background: #fbfdff;
            text-align: center;
            color: var(--muted);
            font-size: 0.82rem;
            line-height: 1.2;
        }
        .security-strip-item i {
            display: block;
            color: var(--success);
            font-size: 1rem;
            margin-bottom: 5px;
        }
        .form-label {
            font-weight: 700;
            color: #33475b;
            margin-bottom: 8px;
        }
        .input-icon-group {
            position: relative;
        }
        .input-icon-group .form-control {
            padding-left: 46px;
        }
        .input-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #8aa0b4;
            z-index: 4;
        }
        .form-control {
            border-radius: 12px;
            border: 1px solid var(--line-soft);
            padding: 13px 15px;
            font-size: 1rem;
            box-shadow: none;
            background: #fbfdff;
        }
        .form-control:focus {
            border-color: var(--brand-accent);
            box-shadow: 0 0 0 0.2rem rgba(94,148,200,0.18);
            background: #fff;
        }
        .input-group .btn {
            border-radius: 0 12px 12px 0;
            border-color: var(--line-soft);
            min-width: 54px;
            background: #fbfdff;
            color: #5f7184;
        }
        .login-btn {
            border-radius: 12px;
            padding: 14px 18px;
            font-weight: 700;
            font-size: 1rem;
            background: linear-gradient(135deg, var(--brand-mid), var(--brand-dark));
            border: none;
            box-shadow: 0 10px 18px rgba(62,106,149,0.18);
        }
        .login-btn:hover {
            background: linear-gradient(135deg, var(--brand-dark), #182b45);
        }
        .login-footer-note {
            font-size: 0.92rem;
            color: var(--muted);
            margin-top: 16px;
            line-height: 1.5;
            background: #f6f9fc;
            border: 1px solid var(--line-soft);
            border-radius: 14px;
            padding: 12px 13px;
        }
        .alert {
            border-radius: 14px;
            border: none;
        }
        .system-footer {
            text-align: center;
            margin-top: 18px;
            color: #6b7d90;
            font-size: 0.92rem;
        }
        @media (max-width: 767px) {
            body {
                display: block;
                padding: 16px 0 24px;
            }
            .login-frame {
                padding: 0;
                border: 0;
                box-shadow: none;
                background: transparent;
            }
            .brand-panel,
            .login-card {
                border-radius: 20px;
                min-height: auto;
            }
            .brand-panel {
                padding: 24px 22px;
                margin-bottom: 16px;
            }
            .login-body {
                padding: 22px 18px;
            }
            .security-strip {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
<div class="container login-shell">
    <div class="login-frame">
        <div class="row g-3 align-items-stretch">
            <div class="col-lg-6">
                <div class="brand-panel">
                    <div>
                        <img src="<?= htmlspecialchars($schoolLogo) ?>" alt="School Logo" class="brand-logo">
                        <div class="brand-eyebrow">Secure Admin Portal</div>
                        <div class="brand-title"><?= htmlspecialchars($schoolName) ?></div>
                        <div class="brand-subtitle">Authorized administrative access for student records, school-year setup, finance operations, audit logs, and backup controls.</div>
                        <div class="brand-badges">
                            <span class="brand-badge"><i class="fas fa-shield-halved"></i> Trusted devices only</span>
                            <span class="brand-badge"><i class="fas fa-clock"></i> Auto session timeout</span>
                            <span class="brand-badge"><i class="fas fa-network-wired"></i> LAN-restricted access</span>
                        </div>
                    </div>
                    <div class="brand-notes">
                        <div class="brand-note"><?= htmlspecialchars($securityNote) ?></div>
                        <div class="brand-note"><?= htmlspecialchars($sessionNote) ?></div>
                        <?php if ($schoolContactLine !== ''): ?>
                            <div class="brand-note"><?= htmlspecialchars($schoolContactLine) ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="login-card">
                    <div class="login-body">
                        <div class="mb-4">
                            <div class="login-system-pill"><i class="fa-solid fa-lock"></i> School Admin and Finance Management System</div>
                            <div class="login-title"><i class="fa-solid fa-user-shield me-2"></i>Admin Sign In</div>
                            <div class="login-subtitle">Enter your admin account to continue to the dashboard.</div>
                        </div>
                        <div class="security-strip">
                            <div class="security-strip-item"><i class="fa-solid fa-fingerprint"></i>Verified Access</div>
                            <div class="security-strip-item"><i class="fa-solid fa-clock-rotate-left"></i>Session Guard</div>
                            <div class="security-strip-item"><i class="fa-solid fa-list-check"></i>Audit Logged</div>
                        </div>
                        <?php if (!empty($error)): ?>
                            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                        <?php endif; ?>
                        <?php if ($reasonMessage !== ''): ?>
                            <div class="alert alert-<?= htmlspecialchars($reasonType) ?>"><?= htmlspecialchars($reasonMessage) ?></div>
                        <?php endif; ?>
                        <form method="post" action="">
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <div class="input-icon-group">
                                    <i class="fa-solid fa-user input-icon"></i>
                                    <input type="text" name="username" id="username" class="form-control" required autofocus autocomplete="username" placeholder="Enter admin username">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <div class="input-group">
                                    <span class="input-icon-group flex-grow-1">
                                        <i class="fa-solid fa-key input-icon"></i>
                                        <input type="password" name="password" id="password" class="form-control rounded-end-0" required autocomplete="current-password" placeholder="Enter password">
                                    </span>
                                    <button type="button" class="btn btn-outline-secondary" id="togglePassword" aria-label="Show password">
                                        <i class="fa-solid fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <button type="submit" class="btn login-btn text-white w-100">
                                <i class="fa-solid fa-right-to-bracket me-2"></i>Sign In
                            </button>
                        </form>
                        <div class="login-footer-note">
                            If you were redirected here from another page, your admin session may have expired or that page required a fresh sign-in.
                        </div>
                    </div>
                </div>
                <div class="system-footer">&copy; <?= date('Y') ?> School Admin and Finance Management System</div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const passwordInput = document.getElementById('password');
    const togglePasswordBtn = document.getElementById('togglePassword');
    if (passwordInput && togglePasswordBtn) {
        togglePasswordBtn.addEventListener('click', function () {
            const isPassword = passwordInput.getAttribute('type') === 'password';
            passwordInput.setAttribute('type', isPassword ? 'text' : 'password');
            this.innerHTML = isPassword
                ? '<i class="fa-solid fa-eye-slash"></i>'
                : '<i class="fa-solid fa-eye"></i>';
        });
    }
</script>
</body>
</html>
