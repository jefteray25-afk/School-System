<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
include '../../config/database.php';
include '../../modules/settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/../settings/fee-grade-settings-helper.php';
require_once __DIR__ . '/fee-behavior-helper.php';
require_once __DIR__ . '/fee-lock-helper.php';
require_once __DIR__ . '/../settings/settings-security.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

// Centralized permission check for viewing fees
if (!hasPermission($_SESSION['role'], 'account_mgmt', 'view')) {
    admin_session_forbidden();
}

$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$isLimitedAdminOperator = is_limited_admin_operator_role($role);
$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";
$added_notice = isset($_GET['added']) && $_GET['added'] === '1';
$auto_accounts_added = max(0, (int) ($_GET['auto_accounts'] ?? 0));
admin_csrf_token();
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
fee_behavior_ensure_column($conn);
fee_lock_ensure_table($conn);
$school_year_options = school_year_finance_options($conn, 'fee');
$active_school_year_label = school_year_get_active_label($conn);
$grade_names = fee_grade_label_map($conn);
$all_grades = array_keys($grade_names);
$fee_lock_notice = '';
$fee_lock_notice_type = 'info';

if (isset($_POST['lock_fee_scope']) || isset($_POST['unlock_fee_scope'])) {
    $isLockAction = isset($_POST['lock_fee_scope']);
    $postedToken = (string) ($_POST['csrf_token'] ?? '');
    $scopeSchoolYear = trim((string) ($_POST['scope_school_year'] ?? ''));
    $scopeGradeLevel = (int) ($_POST['scope_grade_level'] ?? 0);
    $scopeReason = trim((string) ($_POST['scope_reason'] ?? ''));

    if (!admin_csrf_validate($postedToken)) {
        $fee_lock_notice = 'Security check failed. Please refresh the page and try again.';
        $fee_lock_notice_type = 'danger';
    } elseif (!is_super_admin_role($role)) {
        $fee_lock_notice = 'Only the Super Administrator can manage finalized fee locks.';
        $fee_lock_notice_type = 'danger';
    } elseif ($scopeSchoolYear === '' || $scopeGradeLevel <= 0) {
        $fee_lock_notice = 'Choose a specific school year and grade level before locking fees.';
        $fee_lock_notice_type = 'warning';
    } elseif (!$isLockAction && $scopeReason === '') {
        $fee_lock_notice = 'Unlock reason is required before reopening a finalized fee scope.';
        $fee_lock_notice_type = 'warning';
    } else {
        $actionOk = $isLockAction
            ? fee_lock_scope($conn, $scopeSchoolYear, $scopeGradeLevel, $username !== '' ? $username : 'System', $scopeReason)
            : fee_unlock_scope($conn, $scopeSchoolYear, $scopeGradeLevel, $username !== '' ? $username : 'System', $scopeReason);

        if ($actionOk) {
            $scopeLabel = isset($grade_names[$scopeGradeLevel]) ? $grade_names[$scopeGradeLevel] : ('Grade ' . $scopeGradeLevel);
            $fee_lock_notice = $isLockAction
                ? 'Fee scope locked for ' . $scopeLabel . ' under ' . $scopeSchoolYear . '.'
                : 'Fee scope unlocked for ' . $scopeLabel . ' under ' . $scopeSchoolYear . '.';
            $fee_lock_notice_type = 'success';
            $auditDetails = "Role: " . ($role !== '' ? $role : 'unknown')
                . " | Scope: {$scopeLabel} / {$scopeSchoolYear}"
                . " | Action: " . ($isLockAction ? 'Lock' : 'Unlock')
                . " | Reason: " . ($scopeReason !== '' ? $scopeReason : 'None');
            audit_log($conn, $username !== '' ? $username : 'unknown', $isLockAction ? 'Locked fee scope' : 'Unlocked fee scope', 'Fees', $auditDetails);
        } else {
            $fee_lock_notice = 'Unable to update the fee lock right now. Please try again.';
            $fee_lock_notice_type = 'danger';
        }
    }
}

// Handle lock/unlock actions
if (isset($_POST['lock_filter'])) {
    if (!admin_csrf_validate($_POST['csrf_token'] ?? '')) {
        $fee_lock_notice = 'Security check failed. Please refresh the page and try again.';
        $fee_lock_notice_type = 'danger';
    } else {
    $lock_school_year = array_key_exists('school_year', $_GET) ? (string) ($_GET['school_year'] ?? '') : $active_school_year_label;
    $_SESSION['fee_filter_locked'] = [
        'grade_level' => $_GET['grade_level'] ?? '0',
        'fee_type_id' => $_GET['fee_type_id'] ?? '0',
        'school_year' => $lock_school_year,
        'keyword' => trim((string) ($_GET['keyword'] ?? ''))
    ];
    header("Location: fee-list.php?grade_level={$_SESSION['fee_filter_locked']['grade_level']}&fee_type_id={$_SESSION['fee_filter_locked']['fee_type_id']}&school_year=" . urlencode($_SESSION['fee_filter_locked']['school_year']) . "&keyword=" . urlencode($_SESSION['fee_filter_locked']['keyword']));
    exit;
    }
}
if (isset($_POST['unlock_filter'])) {
    if (!admin_csrf_validate($_POST['csrf_token'] ?? '')) {
        $fee_lock_notice = 'Security check failed. Please refresh the page and try again.';
        $fee_lock_notice_type = 'danger';
    } else {
        unset($_SESSION['fee_filter_locked']);
        header("Location: fee-list.php");
        exit;
    }
}
$fee_lock_map = fee_lock_fetch_map($conn);

// Fee types for filter
$types_res = $conn->query("SELECT id, name FROM account_types ORDER BY priority ASC, name ASC");
$types = [];
while ($row = $types_res->fetch_assoc()) $types[] = $row;

// If filter is locked, override with locked values
$is_locked = isset($_SESSION['fee_filter_locked']);
if ($is_locked) {
    $filter_grade = $_SESSION['fee_filter_locked']['grade_level'];
    $filter_type = $_SESSION['fee_filter_locked']['fee_type_id'];
    $filter_school_year = $_SESSION['fee_filter_locked']['school_year'] ?? '';
    $filter_keyword = trim((string) ($_SESSION['fee_filter_locked']['keyword'] ?? ''));
} else {
    $has_school_year_param = array_key_exists('school_year', $_GET);
    $filter_grade = isset($_GET['grade_level']) ? intval($_GET['grade_level']) : 0;
    $filter_type = isset($_GET['fee_type_id']) ? intval($_GET['fee_type_id']) : 0;
    $filter_school_year = trim($_GET['school_year'] ?? '');
    $filter_keyword = trim($_GET['keyword'] ?? '');
    if (!$has_school_year_param) {
        $filter_school_year = $active_school_year_label;
    }
}

// Build WHERE clause for filtering
$where = [];
if ($filter_type) $where[] = "f.fee_type_id = $filter_type";
if ($filter_grade) $where[] = "f.grade_level = $filter_grade";
if ($filter_keyword !== '') {
    $safe_keyword = $conn->real_escape_string($filter_keyword);
    $where[] = "(at.name LIKE '%{$safe_keyword}%' OR f.notes LIKE '%{$safe_keyword}%')";
}
if ($filter_school_year !== '') {
    $safe_school_year = $conn->real_escape_string($filter_school_year);
    $where[] = "f.school_year_label = '{$safe_school_year}'";
}
$sql = "SELECT f.id, at.name AS fee_type, f.grade_level, f.amount, f.notes, f.school_year_label, f.application_mode
        FROM fee f
        JOIN account_types at ON f.fee_type_id = at.id";
if ($where) $sql .= " WHERE " . implode(' AND ', $where);
$sql .= " ORDER BY f.grade_level, at.priority ASC, at.name ASC";
$res = $conn->query($sql);

$summary_where_sql = $where ? (' WHERE ' . implode(' AND ', $where)) : '';
$summary_sql = "SELECT
        COUNT(*) AS total_fees,
        COALESCE(SUM(f.amount), 0) AS total_amount,
        COUNT(DISTINCT f.grade_level) AS total_grades,
        COUNT(DISTINCT f.fee_type_id) AS total_fee_types
    FROM fee f
    JOIN account_types at ON f.fee_type_id = at.id" . $summary_where_sql;
$summary_result = $conn->query($summary_sql);
$summary = $summary_result ? $summary_result->fetch_assoc() : ['total_fees' => 0, 'total_amount' => 0, 'total_grades' => 0, 'total_fee_types' => 0];
$summary_total_fees = (int) ($summary['total_fees'] ?? 0);
$summary_total_amount = (float) ($summary['total_amount'] ?? 0);
$summary_total_grades = (int) ($summary['total_grades'] ?? 0);
$summary_total_fee_types = (int) ($summary['total_fee_types'] ?? 0);
$sync_scope_school_year = $filter_school_year !== '' ? $filter_school_year : '';
$filter_chips = [];
if ($filter_school_year !== '') {
    $filter_chips[] = ['icon' => 'fa-calendar-alt', 'label' => $filter_school_year];
}
if ($filter_grade && isset($grade_names[$filter_grade])) {
    $filter_chips[] = ['icon' => 'fa-layer-group', 'label' => $grade_names[$filter_grade]];
}
if ($filter_type) {
    foreach ($types as $typeRow) {
        if ((int) $typeRow['id'] === (int) $filter_type) {
            $filter_chips[] = ['icon' => 'fa-tag', 'label' => $typeRow['name']];
            break;
        }
    }
}
if ($filter_keyword !== '') {
    $filter_chips[] = ['icon' => 'fa-search', 'label' => $filter_keyword];
}
$fee_scope_can_manage = $filter_school_year !== '' && $filter_grade > 0;
$current_fee_scope_lock = $fee_scope_can_manage ? fee_lock_scope_row($fee_lock_map, $filter_school_year, (int) $filter_grade) : null;
$current_fee_scope_locked = $fee_scope_can_manage ? fee_lock_scope_is_locked($fee_lock_map, $filter_school_year, (int) $filter_grade) : false;
$current_fee_scope_grade_label = $fee_scope_can_manage
    ? (isset($grade_names[$filter_grade]) ? $grade_names[$filter_grade] : ('Grade ' . $filter_grade))
    : 'Choose a grade';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Fee List | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body {
            background: var(--main-bg);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        }
        body.dark-mode {
            --main-bg: #1b232d;
            --card-bg: #23395d;
            --navbar-bg: #161b22;
            color: #e6edf3;
        }
        .navbar {
            background: var(--navbar-bg) !important;
            box-shadow: 0 2px 12px rgba(33,57,93,0.08);
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.08em;
        }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .theme-toggle-btn {
            background: none;
            border: none;
            color: #fff;
            font-size: 1.45em;
            margin-left: 12px;
            cursor: pointer;
        }
        .dashboard-header {
            text-align: center;
            margin-top: 36px;
            margin-bottom: 18px;
        }
        .dashboard-header img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            margin-bottom: 6px;
        }
        .dashboard-header h1 {
            font-size: 1.3rem;
            color: var(--brand-dark);
            font-weight: 700;
            margin-bottom: 0;
            letter-spacing: 0.02em;
        }
        .main-card {
            background: var(--card-bg);
            border-radius: 1rem;
            box-shadow: 0 4px 18px rgba(33,57,93,0.09), 0 1.5px 3px rgba(33,57,93,0.07);
            margin: 0 auto;
            margin-top: 18px;
            margin-bottom: 32px;
            padding: 2.2rem 2.5rem 2.3rem 2.5rem;
            max-width: 1480px;
        }
        .section-title {
            font-size: 1.23rem;
            font-weight: 700;
            color: #23395d;
            margin-bottom: 1.1rem;
            letter-spacing: 0.04em;
        }
        .card-header {
            font-weight: 500;
            font-size: 1.05em;
        }
        .btn-primary {
            background: #517fa4;
            border-color: #517fa4;
            font-weight: 500;
            border-radius: 7px;
        }
        .btn-primary:hover, .btn-primary:focus {
            background: #23395d;
            border-color: #23395d;
        }
        .btn-light {
            background: #e7f0fd;
            color: #23395d;
            border: 1px solid #bcdfff;
            font-weight: 500;
            border-radius: 7px;
        }
        .btn-light:hover, .btn-light:focus {
            background: #517fa4;
            color: #fff;
            border-color: #517fa4;
        }
        .dashboard-btn-bottom {
            position: fixed;
            left: 28px;
            bottom: 28px;
            z-index: 1060;
            background: #e7f0fd;
            color: #517fa4;
            border: 2px solid #bcdfff;
            box-shadow: 0 5px 16px rgba(33,57,93,0.13);
            border-radius: 50%;
            width: 58px;
            height: 58px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.55em;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
            text-decoration: none;
        }
        .dashboard-btn-bottom:hover, .dashboard-btn-bottom:focus {
            background: #fff2b3;
            color: #517fa4;
            border-color: #ffe599;
        }
        .stat-card {
            border: 1px solid #d9e6f5;
            border-radius: 14px;
            background: #f9fbfe;
            padding: 1rem 1.1rem;
            height: 100%;
        }
        .stat-label {
            font-size: 0.83rem;
            color: #61738a;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .stat-value {
            font-size: 1.45rem;
            font-weight: 700;
            color: #23395d;
        }
        .sync-panel {
            border: 1px solid #d9e6f5;
            border-radius: 14px;
            background: linear-gradient(135deg, #eef5fd 0%, #f9fbfe 100%);
            padding: 1rem 1.1rem;
        }
        .sync-panel .sync-title {
            font-size: 1.02rem;
            font-weight: 700;
            color: #23395d;
        }
        .sync-toast {
            display: none;
            position: fixed;
            right: 20px;
            bottom: 20px;
            z-index: 1080;
            align-items: center;
            gap: 10px;
            border-radius: 12px;
            padding: 0.9rem 1rem;
            color: #fff;
            box-shadow: 0 10px 26px rgba(33,57,93,0.18);
            max-width: 380px;
        }
        .sync-toast.success { background: #198754; }
        .sync-toast.error { background: #c0392b; }
        @media (max-width: 900px) {
            .main-card { padding: 1.1rem 0.7rem; max-width: 99vw;}
        }
        @media (max-width: 600px) {
            .dashboard-header h1 { font-size: 1rem; }
            .main-card { margin-top: 7px; margin-bottom: 14px; padding: 0.7rem 0.4rem;}
        }
        /* View Wave 1 + 2: shared list view system */
        :root {
            --vw-page-bg: #eef3f9;
            --vw-card-bg: #ffffff;
            --vw-card-border: #d9e3ef;
            --vw-brand-dark: #23395d;
            --vw-brand-mid: #517fa4;
            --vw-brand-soft: #edf4fb;
            --vw-text-soft: #5f7186;
        }
        body {
            background:
                radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 30%),
                linear-gradient(180deg, #f8fbff 0%, var(--vw-page-bg) 100%);
            color: var(--vw-brand-dark);
        }
        .dashboard-header img {
            width: 72px;
            height: 72px;
            border-radius: 18px;
            background: #fff;
            padding: 6px;
            box-shadow: 0 10px 25px rgba(35,57,93,0.12);
        }
        .dashboard-header h1 {
            font-weight: 800;
        }
        .main-card {
            background: var(--vw-card-bg);
            border: 1px solid var(--vw-card-border);
            border-radius: 20px;
            box-shadow: 0 14px 32px rgba(35,57,93,0.07);
        }
        .section-title {
            font-weight: 800;
        }
        .view-kicker {
            font-size: 0.78rem;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: var(--vw-text-soft);
            font-weight: 800;
            margin-bottom: 0.3rem;
        }
        .view-subtitle {
            color: var(--vw-text-soft);
            margin-bottom: 0;
        }
        .stat-card,
        .sync-panel {
            border: 1px solid var(--vw-card-border);
            border-radius: 18px;
            box-shadow: 0 10px 24px rgba(35,57,93,0.06);
        }
        .stat-card {
            background: #fff;
        }
        .sync-panel {
            background: #f8fbff;
        }
        .section-shell {
            border: 1px solid var(--vw-card-border);
            border-radius: 18px;
            background: #fff;
            box-shadow: 0 10px 24px rgba(35,57,93,0.06);
            overflow: hidden;
        }
        .section-shell .section-shell-header {
            padding: 1rem 1.15rem;
            border-bottom: 1px solid #e6edf6;
            background: linear-gradient(180deg, #fbfdff 0%, #f4f8fd 100%);
        }
        .section-shell .section-shell-body {
            padding: 1rem 1.15rem 1.15rem;
        }
        .collapse-toggle-btn {
            border-radius: 10px;
            font-weight: 700;
            border: 1px solid #d7e1ed;
            background: #fff;
            color: var(--vw-brand-dark);
        }
        .collapse-toggle-btn:hover,
        .collapse-toggle-btn:focus {
            background: #edf4fb;
            color: var(--vw-brand-dark);
        }
        .control-button-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 0.65rem;
            justify-content: flex-end;
        }
        .control-button-grid .btn {
            min-width: 180px;
            justify-content: center;
            display: inline-flex;
            align-items: center;
        }
        .filter-toolbar {
            border: 1px solid var(--vw-card-border);
            border-radius: 18px;
            background: #fff;
            padding: 1rem 1.1rem;
            box-shadow: 0 10px 24px rgba(35,57,93,0.05);
        }
        .filter-help {
            font-size: 0.82rem;
            color: var(--vw-text-soft);
        }
        .fee-lock-guide {
            border: 1px dashed #c9d8eb;
            background: #fff;
            border-radius: 12px;
            padding: 0.75rem 0.85rem;
            font-size: 0.85rem;
            color: #52637a;
        }
        .fee-lock-warning {
            border-radius: 12px;
            border: 1px solid #f3d5a5;
            background: #fff8e8;
            color: #8a6116;
            padding: 0.7rem 0.85rem;
            font-size: 0.84rem;
            font-weight: 600;
        }
        .scope-summary-title {
            font-size: 0.78rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            font-weight: 800;
            color: var(--vw-text-soft);
        }
        .scope-summary-value {
            font-size: 1rem;
            font-weight: 800;
            color: var(--vw-brand-dark);
        }
        .fee-table-scroll {
            max-height: 860px;
            overflow: auto;
        }
        .fee-table-scroll thead th {
            position: sticky;
            top: 0;
            z-index: 2;
        }
        .fee-table-note {
            font-size: 0.82rem;
            color: var(--vw-text-soft);
        }
        .stat-label { color: var(--vw-text-soft); }
        .stat-value,
        .sync-panel .sync-title { color: var(--vw-brand-dark); }
        .main-card form.row {
            background: #f8fbff;
            border: 1px solid var(--vw-card-border);
            border-radius: 16px;
            padding: 14px 12px;
            margin-bottom: 1rem !important;
        }
        .fee-action-strip {
            border: 1px solid var(--vw-card-border);
            border-radius: 18px;
            background: #f8fbff;
            padding: 1rem 1.1rem;
            box-shadow: 0 10px 24px rgba(35,57,93,0.05);
        }
        .fee-action-strip .btn {
            border-radius: 12px;
            font-weight: 700;
        }
        .filter-chip {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 0.45rem 0.78rem;
            border-radius: 999px;
            background: #fff;
            border: 1px solid var(--vw-card-border);
            color: var(--vw-brand-dark);
            font-weight: 700;
            font-size: 0.88rem;
            margin: 0.2rem 0.35rem 0.2rem 0;
        }
        .main-card .form-select,
        .main-card .form-control {
            border-color: #d7e1ed;
            min-height: 44px;
            box-shadow: none;
        }
        .main-card .btn-primary {
            background: var(--vw-brand-dark);
            border-color: var(--vw-brand-dark);
            font-weight: 600;
        }
        .main-card .btn-light,
        .main-card .btn-outline-secondary {
            background: #eef3f8;
            border-color: #d7e1ed;
            color: var(--vw-brand-dark);
            font-weight: 600;
        }
        .main-card .card {
            border: 1px solid var(--vw-card-border);
            border-radius: 18px;
            overflow: hidden;
        }
        .fee-table-card {
            box-shadow: 0 14px 32px rgba(35,57,93,0.07);
        }
        .main-card .card-header {
            background: linear-gradient(135deg, var(--vw-brand-dark), var(--vw-brand-mid));
            color: #fff;
            border: 0;
            font-weight: 700;
        }
        .fee-name-cell {
            min-width: 220px;
        }
        .fee-name-main {
            font-weight: 700;
            color: var(--vw-brand-dark);
        }
        .fee-name-sub {
            color: var(--vw-text-soft);
            font-size: 0.84rem;
        }
        .fee-grade-badge,
        .fee-year-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border-radius: 999px;
            font-weight: 700;
            padding: 0.4rem 0.7rem;
            font-size: 0.84rem;
        }
        .fee-grade-badge {
            background: #edf4fb;
            color: var(--vw-brand-dark);
            border: 1px solid #d7e1ed;
        }
        .fee-year-badge {
            background: #f5f7fb;
            color: #546779;
            border: 1px solid #dfe7f1;
        }
        .fee-amount {
            color: #1f7a3d;
            font-weight: 800;
            white-space: nowrap;
        }
        .fee-note {
            max-width: 220px;
            color: var(--vw-text-soft);
            font-size: 0.88rem;
        }
        .behavior-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border-radius: 999px;
            font-weight: 700;
            padding: 0.4rem 0.7rem;
            font-size: 0.82rem;
            border: 1px solid #d7e1ed;
            background: #fff;
            color: var(--vw-brand-dark);
        }
        .behavior-badge.optional {
            background: #fff4db;
            color: #9a6700;
            border-color: #f5deb3;
        }
        .behavior-badge.conditional {
            background: #eef4ff;
            color: #1d4f91;
            border-color: #cfe0fb;
        }
        .empty-state {
            padding: 2.2rem 1rem;
            color: var(--vw-text-soft);
        }
        .main-card .table thead th {
            background: var(--vw-brand-soft);
            color: var(--vw-brand-dark);
            border-bottom: 1px solid var(--vw-card-border);
            font-weight: 700;
        }
        .main-card .table tbody tr:hover {
            background: transparent;
        }
        .main-card .badge.bg-light,
        .main-card .badge.bg-success {
            border-radius: 999px;
            padding: 0.5rem 0.8rem;
            font-weight: 700;
        }
        .main-card .badge.bg-light {
            background: #edf4fb !important;
            color: var(--vw-brand-dark) !important;
            border: 1px solid var(--vw-card-border) !important;
        }
        .main-card .table .btn.btn-sm {
            border-radius: 10px;
            min-height: 36px;
            font-weight: 700;
            box-shadow: none;
        }
        .main-card .table .btn.btn-info {
            background: #edf4fb;
            border-color: #d7e1ed;
            color: var(--vw-brand-dark);
        }
        .main-card .table .btn.btn-danger {
            background: #fdecec;
            border-color: #f2c9c9;
            color: #b42318;
        }
        .main-card .table .btn.btn-info:hover,
        .main-card .table .btn.btn-danger:hover {
            filter: brightness(0.98);
        }
        .fee-lock-panel {
            border: 1px solid #dce7f5;
            border-radius: 16px;
            background: linear-gradient(180deg, #f7fbff 0%, #eef5ff 100%);
            padding: 1.15rem 1.2rem;
            box-shadow: 0 10px 24px rgba(35,57,93,0.06);
        }
        .fee-lock-title {
            font-weight: 800;
            color: var(--vw-brand-dark);
            font-size: 1rem;
        }
        .fee-lock-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            border-radius: 999px;
            padding: 0.4rem 0.8rem;
            font-size: 0.82rem;
            font-weight: 700;
        }
        .fee-lock-badge.locked {
            background: #fdecec;
            color: #b42318;
            border: 1px solid #f2c9c9;
        }
        .fee-lock-badge.unlocked {
            background: #edf7f1;
            color: #166534;
            border: 1px solid #cde8d5;
        }
        .fee-lock-meta {
            font-size: 0.82rem;
            color: #52637a;
        }
        .fee-scope-note {
            border-radius: 12px;
            padding: 0.65rem 0.85rem;
            background: #fff;
            border: 1px dashed #c9d8eb;
        }
        .fee-row-lock-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            margin-left: 0.45rem;
            padding: 0.18rem 0.5rem;
            border-radius: 999px;
            background: #fff3cd;
            color: #8a6116;
            border: 1px solid #f1dc95;
            font-size: 0.72rem;
            font-weight: 700;
        }
        @media (max-width: 992px) {
            .control-button-grid {
                justify-content: stretch;
            }
            .control-button-grid .btn {
                min-width: 0;
                width: 100%;
            }
        }
    </style>
</head>
<body>
<!-- Navbar -->
<?php render_admin_nav('fees', true); ?>
<!-- Dashboard Header -->
<?php render_school_page_header($schoolName); ?>
<!-- Main Card -->
<div class="container-fluid main-card px-3 px-xl-4">
    <?php if ($fee_lock_notice !== ''): ?>
        <div class="alert alert-<?= htmlspecialchars($fee_lock_notice_type) ?> mb-4">
            <?= htmlspecialchars($fee_lock_notice) ?>
        </div>
    <?php endif; ?>
    <?php if ($added_notice): ?>
        <div class="alert alert-success">
            Fee setup added successfully.
            <?php if ($auto_accounts_added > 0): ?>
                Auto-created <?= number_format($auto_accounts_added) ?> matching student account(s) for the selected school year.
            <?php else: ?>
                No matching student accounts needed to be created for the selected school year.
            <?php endif; ?>
        </div>
    <?php endif; ?>
    <?php if (!$isLimitedAdminOperator): ?>
    <div class="fee-action-strip mb-4 section-shell">
        <div class="section-shell-body">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">
            <div>
                <div class="fw-bold" style="color: var(--vw-brand-dark);">Fee Module Controls</div>
                <div class="text-muted small mt-1">
                    Keep template rows, grade settings, and school-year copy work separated so the fee module stays readable even with large volume.
                </div>
            </div>
            <div class="control-button-grid">
                <?php if (hasPermission($_SESSION['role'], 'account_mgmt', 'add') && !$current_fee_scope_locked): ?>
                    <a href="fee-add.php" class="btn btn-primary"><i class="fas fa-plus me-2"></i>Add Fee</a>
                <?php elseif (hasPermission($_SESSION['role'], 'account_mgmt', 'add')): ?>
                    <button type="button" class="btn btn-secondary" disabled><i class="fas fa-lock me-2"></i>Add Fee Locked</button>
                <?php endif; ?>
                <a href="fee-copy-school-year.php" class="btn btn-light"><i class="fas fa-copy me-2"></i>Copy School Year</a>
                <a href="fee-exception-review.php" class="btn btn-light"><i class="fas fa-clipboard-list me-2"></i>Exception Review</a>
                <a href="../settings/settings-fee-grades.php" class="btn btn-light"><i class="fas fa-layer-group me-2"></i>Grade Settings</a>
                <a href="/school-admin-dashboard/modules/accounts/account-manage-types.php" class="btn btn-light"><i class="fas fa-list me-2"></i>Fee Types</a>
            </div>
        </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-3">
        <div>
            <div class="view-kicker">Fee Setup</div>
            <div class="section-title mb-1"><i class="fas fa-money-bill-wave"></i> Per-Grade Fees</div>
            <p class="view-subtitle">Manage school-year fee definitions, copy prior setups, and keep fee accounts aligned safely.</p>
        </div>
        <div class="text-muted small">
            Large fee catalogs work best when filtered by school year, grade, and fee type before editing.
        </div>
    </div>
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="stat-card">
                <div class="stat-label">School Year View</div>
                <div class="stat-value" style="font-size:1.05rem;"><?= htmlspecialchars($filter_school_year !== '' ? $filter_school_year : 'All School Years') ?></div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <div class="stat-label">Fee Setups</div>
                <div class="stat-value"><?= number_format($summary_total_fees) ?></div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <div class="stat-label">Grade Coverage</div>
                <div class="stat-value"><?= number_format($summary_total_grades) ?></div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <div class="stat-label">Fee Types</div>
                <div class="stat-value"><?= number_format($summary_total_fee_types) ?></div>
            </div>
        </div>
    </div>
    <div class="mb-4">
        <div class="fw-bold mb-2" style="color: var(--vw-brand-dark);">Current View</div>
        <?php if ($filter_chips): ?>
            <?php foreach ($filter_chips as $chip): ?>
                <span class="filter-chip"><i class="fas <?= htmlspecialchars($chip['icon']) ?>"></i><?= htmlspecialchars($chip['label']) ?></span>
            <?php endforeach; ?>
        <?php else: ?>
            <span class="filter-chip"><i class="fas fa-globe"></i>All Fee Rows</span>
        <?php endif; ?>
    </div>
    <?php if (!$isLimitedAdminOperator): ?>
    <div class="section-shell mb-4">
        <div class="section-shell-header d-flex justify-content-between align-items-center flex-wrap gap-2">
            <div class="sync-title mb-0"><i class="fas fa-shield-alt me-2"></i>Sync Fee Accounts Safely</div>
            <button class="btn collapse-toggle-btn btn-sm" type="button" data-bs-toggle="collapse" data-bs-target="#syncFeeCollapse" aria-expanded="true" aria-controls="syncFeeCollapse">
                <i class="fas fa-chevron-down me-2"></i>Toggle
            </button>
        </div>
        <div class="collapse show" id="syncFeeCollapse">
            <div class="section-shell-body">
                <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">
                    <div>
                        <div class="text-muted small mt-1">
                            Preview first, then sync only the selected school year so account balances stay aligned with the fee setup. Preview now also flags partial and fully paid accounts that may need manual fee adjustment review.
                        </div>
                        <div class="mt-2">
                            <span class="badge bg-light text-dark border">Active Year: <?= htmlspecialchars($active_school_year_label) ?></span>
                            <span class="badge bg-light text-dark border">Current View: <?= htmlspecialchars($filter_school_year !== '' ? $filter_school_year : 'All School Years') ?></span>
                            <span class="badge bg-light text-dark border">Filtered Total: PHP <?= number_format($summary_total_amount, 2) ?></span>
                        </div>
                    </div>
                    <div class="d-flex gap-2 align-items-center">
                        <?php if ($sync_scope_school_year !== '' && hasPermission($_SESSION['role'], 'account_mgmt', 'add')): ?>
                            <button type="button" class="btn btn-primary" id="syncPreviewBtn" data-school-year="<?= htmlspecialchars($sync_scope_school_year) ?>">
                                <i class="fas fa-sync-alt"></i> Preview Sync
                            </button>
                        <?php else: ?>
                            <span class="text-muted small">Choose a specific school year to preview and run sync.</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="section-shell mb-4">
        <div class="section-shell-header d-flex justify-content-between align-items-center flex-wrap gap-2">
            <div class="fee-lock-title"><i class="fas fa-lock me-2"></i>Fee Lock Scope</div>
            <div class="d-flex align-items-center gap-2 flex-wrap">
                <span class="fee-lock-badge <?= $current_fee_scope_locked ? 'locked' : 'unlocked' ?>">
                    <i class="fas <?= $current_fee_scope_locked ? 'fa-lock' : 'fa-lock-open' ?>"></i>
                    <?= $current_fee_scope_locked ? 'Locked Scope' : 'Unlocked Scope' ?>
                </span>
                <button class="btn collapse-toggle-btn btn-sm" type="button" data-bs-toggle="collapse" data-bs-target="#feeLockCollapse" aria-expanded="true" aria-controls="feeLockCollapse">
                    <i class="fas fa-chevron-down me-2"></i>Toggle
                </button>
            </div>
        </div>
        <div class="collapse show" id="feeLockCollapse">
            <div class="section-shell-body">
                <div class="fee-lock-guide mb-3">
                    <strong>How to use:</strong> Select a specific <strong>School Year</strong> and <strong>Grade Level</strong>, click <strong>Apply</strong>, then manage the fee lock for that exact scope. The status badge is view-only; the action button on the right does the actual lock or unlock.
                </div>
                <?php if (!$fee_scope_can_manage): ?>
                    <div class="fee-lock-warning mb-3">
                        <i class="fas fa-circle-info me-2"></i>Fee Lock works one grade at a time. Choose a specific grade first, then click <strong>Apply</strong>.
                    </div>
                <?php endif; ?>
                <div class="row g-3 align-items-start mt-1">
                    <div class="col-lg-8">
                        <div class="fee-scope-note">
                            <div class="scope-summary-title">Active Fee Lock Scope</div>
                            <div class="scope-summary-value mb-2"><?= htmlspecialchars($filter_school_year !== '' ? $filter_school_year : 'Choose a school year') ?> / <?= htmlspecialchars($current_fee_scope_grade_label) ?></div>
                            <div class="d-flex flex-wrap gap-2 mb-2">
                                <span class="badge bg-light text-dark border">School Year: <?= htmlspecialchars($filter_school_year !== '' ? $filter_school_year : 'Choose one') ?></span>
                                <span class="badge bg-light text-dark border">Grade: <?= htmlspecialchars($current_fee_scope_grade_label) ?></span>
                            </div>
                            <div class="fee-lock-meta mb-2">Status only: use the button on the right to lock or unlock this selected scope.</div>
                            <?php if ($fee_scope_can_manage && $current_fee_scope_lock): ?>
                                <div class="fee-lock-meta">
                                    <?php if ($current_fee_scope_locked): ?>
                                        Locked by <?= htmlspecialchars((string) ($current_fee_scope_lock['locked_by'] ?? 'System')) ?>
                                        on <?= htmlspecialchars((string) ($current_fee_scope_lock['locked_at'] ?? '')) ?>
                                        <?php if (!empty($current_fee_scope_lock['lock_reason'])): ?>
                                            <br>Reason: <?= htmlspecialchars((string) $current_fee_scope_lock['lock_reason']) ?>
                                        <?php endif; ?>
                                    <?php elseif (!empty($current_fee_scope_lock['unlocked_at'])): ?>
                                        Last unlocked by <?= htmlspecialchars((string) ($current_fee_scope_lock['unlocked_by'] ?? 'System')) ?>
                                        on <?= htmlspecialchars((string) ($current_fee_scope_lock['unlocked_at'] ?? '')) ?>
                                        <?php if (!empty($current_fee_scope_lock['unlock_reason'])): ?>
                                            <br>Reason: <?= htmlspecialchars((string) $current_fee_scope_lock['unlock_reason']) ?>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        This scope is open for fee maintenance.
                                    <?php endif; ?>
                                </div>
                            <?php elseif ($fee_scope_can_manage): ?>
                                <div class="fee-lock-meta">This scope is open for fee maintenance.</div>
                            <?php else: ?>
                                <div class="fee-lock-meta">No lock scope selected yet. Apply a specific grade to activate this panel.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <?php if (is_super_admin_role($role)): ?>
                            <form method="post" class="d-grid gap-2">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(admin_csrf_token()) ?>">
                                <input type="hidden" name="scope_school_year" value="<?= htmlspecialchars($filter_school_year) ?>">
                                <input type="hidden" name="scope_grade_level" value="<?= (int) $filter_grade ?>">
                                <textarea name="scope_reason" class="form-control" rows="2" placeholder="<?= $current_fee_scope_locked ? 'Reason for unlock is required' : 'Optional lock note for this finalized scope' ?>"><?= htmlspecialchars((string) ($_POST['scope_reason'] ?? '')) ?></textarea>
                                <?php if ($current_fee_scope_locked): ?>
                                    <button type="submit" name="unlock_fee_scope" class="btn btn-outline-danger" <?= $fee_scope_can_manage ? '' : 'disabled title="Select a specific grade and apply first"' ?>>
                                        <i class="fas fa-unlock me-2"></i>Unlock Fee Scope
                                    </button>
                                <?php else: ?>
                                    <button type="submit" name="lock_fee_scope" class="btn btn-danger" <?= $fee_scope_can_manage ? '' : 'disabled title="Select a specific grade and apply first"' ?>>
                                        <i class="fas fa-lock me-2"></i>Lock Fee Scope
                                    </button>
                                <?php endif; ?>
                            </form>
                        <?php else: ?>
                            <div class="small text-muted">Only the Super Administrator can manage fee locks. Other admins can view the lock status here.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Filter Bar -->
    <form class="row g-2 mb-3 filter-toolbar" method="get" action="" <?php if($is_locked) echo 'style="pointer-events:none;opacity:0.7;"'; ?>>
        <div class="col-12">
            <div class="filter-help">The selected <strong>School Year</strong> and <strong>Grade</strong> determine which fee scope you can lock. Click <strong>Apply</strong> after changing the filters.</div>
        </div>
        <div class="col-md-3">
            <input type="text" name="keyword" class="form-control" placeholder="Search fee name or note" value="<?= htmlspecialchars($filter_keyword) ?>" <?= $is_locked ? 'disabled' : '' ?>>
        </div>
        <div class="col-md-3">
            <select name="grade_level" class="form-select" <?= $is_locked ? 'disabled' : '' ?>>
                <option value="0">All Grades</option>
                <?php foreach ($all_grades as $g): ?>
                    <option value="<?= $g ?>" <?= ($filter_grade == $g) ? 'selected' : '' ?>>
                        <?= isset($grade_names[$g]) ? $grade_names[$g] : "Grade $g" ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3">
            <select name="fee_type_id" class="form-select" <?= $is_locked ? 'disabled' : '' ?>>
                <option value="0">All Types</option>
                <?php foreach ($types as $t): ?>
                    <option value="<?= $t['id'] ?>" <?= ($filter_type == $t['id']) ? 'selected' : '' ?>><?= htmlspecialchars($t['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3">
            <select name="school_year" class="form-select" <?= $is_locked ? 'disabled' : '' ?>>
                <option value="">All School Years</option>
                <?php foreach ($school_year_options as $school_year_option): ?>
                    <option value="<?= htmlspecialchars($school_year_option) ?>" <?= $filter_school_year === $school_year_option ? 'selected' : '' ?>>
                        <?= htmlspecialchars($school_year_option) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3 d-flex gap-2">
            <button type="submit" class="btn btn-secondary w-100">Apply</button>
            <a href="fee-list.php" class="btn btn-outline-secondary w-100">Reset</a>
        </div>
    </form>
    <!-- Lock/Unlock Button -->
    <form method="post" class="mb-3">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(admin_csrf_token()) ?>">
        <?php if ($is_locked): ?>
            <button type="submit" name="unlock_filter" class="btn btn-danger">
                <i class="fas fa-thumbtack"></i> Unpin View
            </button>
            <span class="badge bg-success ms-2">
                <i class="fas fa-thumbtack"></i> View Pinned
            </span>
        <?php else: ?>
            <button type="submit" name="lock_filter" class="btn btn-success">
                <i class="fas fa-thumbtack"></i> Pin View
            </button>
            <span class="text-muted ms-2">Pin the current filters if you want this view to stay fixed while reviewing fee rows.</span>
        <?php endif; ?>
    </form>
    <div class="card fee-table-card">
        <div class="card-header bg-secondary text-light">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                <div>
                    <i class="fas fa-list"></i> Fee Templates
                    <span class="badge bg-light text-dark ms-2"><?= htmlspecialchars($filter_school_year !== '' ? $filter_school_year : 'All School Years') ?></span>
                </div>
                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <div class="small opacity-75">
                        Rows: <?= number_format($summary_total_fees) ?> | Grades: <?= number_format($summary_total_grades) ?> | Types: <?= number_format($summary_total_fee_types) ?>
                    </div>
                    <button class="btn btn-light btn-sm" type="button" data-bs-toggle="collapse" data-bs-target="#feeTemplatesCollapse" aria-expanded="true" aria-controls="feeTemplatesCollapse">
                        <i class="fas fa-chevron-down me-2"></i>Toggle
                    </button>
                </div>
            </div>
        </div>
        <div class="collapse show" id="feeTemplatesCollapse">
        <div class="card-body p-0">
            <div class="px-3 py-2 border-bottom fee-table-note">
                Fee Templates stays expanded by default. Once the list grows beyond roughly 20 rows on screen, this section becomes scrollable so the page stays compact.
            </div>
            <div class="fee-table-scroll">
            <table class="table table-striped mb-0 align-middle">
                <thead>
                    <tr>
                        <th><i class="fas fa-receipt"></i> Fee Name</th>
                        <th><i class="fas fa-layer-group"></i> Grade</th>
                        <th><i class="fas fa-toggle-on"></i> Mode</th>
                        <th><i class="fas fa-calendar-alt"></i> School Year</th>
                        <th><i class="fas fa-money-bill"></i> Amount</th>
                        <th><i class="fas fa-note-sticky"></i> Notes</th>
                        <?php if ((hasPermission($_SESSION['role'], 'account_mgmt', 'edit') || hasPermission($_SESSION['role'], 'account_mgmt', 'delete')) && !$is_locked): ?>
                            <th><i class="fas fa-tools"></i> Actions</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($res->num_rows > 0): ?>
                        <?php while ($row = $res->fetch_assoc()): ?>
                        <?php
                            $rowSchoolYear = (string) ($row['school_year_label'] ?: $active_school_year_label);
                            $rowGradeLevel = (int) ($row['grade_level'] ?? 0);
                            $rowFeeLocked = fee_lock_scope_is_locked($fee_lock_map, $rowSchoolYear, $rowGradeLevel);
                        ?>
                        <tr>
                            <td class="fee-name-cell">
                                <div class="fee-name-main">
                                    <?= htmlspecialchars($row['fee_type']) ?>
                                    <?php if ($rowFeeLocked): ?>
                                        <span class="fee-row-lock-chip"><i class="fas fa-lock"></i>Locked</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td><span class="fee-grade-badge"><i class="fas fa-layer-group"></i><?= isset($grade_names[$row['grade_level']]) ? $grade_names[$row['grade_level']] : "Grade ".htmlspecialchars($row['grade_level']) ?></span></td>
                            <td><span class="behavior-badge <?= htmlspecialchars((string) ($row['application_mode'] ?? 'required')) ?>"><?= htmlspecialchars(fee_behavior_label((string) ($row['application_mode'] ?? 'required'))) ?></span></td>
                            <td><span class="fee-year-badge"><i class="fas fa-calendar-alt"></i><?= htmlspecialchars($row['school_year_label'] ?: $active_school_year_label) ?></span></td>
                            <td><span class="fee-amount">PHP <?= number_format($row['amount'], 2) ?></span></td>
                            <td class="fee-note"><?= htmlspecialchars($row['notes'] !== '' ? $row['notes'] : 'No notes') ?></td>
                            <?php if ((hasPermission($_SESSION['role'], 'account_mgmt', 'edit') || hasPermission($_SESSION['role'], 'account_mgmt', 'delete')) && !$is_locked): ?>
                            <td>
                                <?php if ($rowFeeLocked): ?>
                                    <span class="badge bg-secondary-subtle text-secondary-emphasis border">
                                        <i class="fas fa-lock me-1"></i>Locked
                                    </span>
                                <?php else: ?>
                                <div class="btn-group" role="group">
                                    <?php if (hasPermission($_SESSION['role'], 'account_mgmt', 'edit')): ?>
                                        <a href="fee-edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-info" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    <?php endif; ?>
                                    <?php if (hasPermission($_SESSION['role'], 'account_mgmt', 'delete')): ?>
                                        <a href="fee-delete.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" title="Delete" onclick="return confirm('Delete this fee?');">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="<?= ((hasPermission($_SESSION['role'], 'account_mgmt', 'edit') || hasPermission($_SESSION['role'], 'account_mgmt', 'delete')) && !$is_locked) ? 7 : 6 ?>" class="text-center empty-state">No fee templates matched the current filters.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
            </div>
        </div>
        </div>
    </div>
</div>
<footer class="text-center py-4 text-muted small">
    &copy; <?= date("Y") ?> <?= $schoolName ?> | School Admin Dashboard
</footer>
<div class="sync-toast" id="syncToast">
    <span id="syncToastMsg"></span>
</div>
<a href="/school-admin-dashboard/dashboard.php" class="dashboard-btn-bottom" title="Go to Dashboard">
    <i class="fas fa-tachometer-alt"></i>
</a>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Theme toggle
    document.getElementById('themeToggleBtn').addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        this.querySelector('i').classList.toggle('fa-moon');
        this.querySelector('i').classList.toggle('fa-sun');
    });

    const syncPreviewBtn = document.getElementById('syncPreviewBtn');
    const syncToast = document.getElementById('syncToast');
    const syncToastMsg = document.getElementById('syncToastMsg');
    let syncTimeout;

    function showSyncToast(message, ok) {
        syncToast.className = 'sync-toast ' + (ok ? 'success' : 'error');
        syncToastMsg.innerHTML = message;
        syncToast.style.display = 'flex';
        clearTimeout(syncTimeout);
        syncTimeout = setTimeout(() => { syncToast.style.display = 'none'; }, 4500);
    }

    if (syncPreviewBtn) {
        syncPreviewBtn.addEventListener('click', function() {
            const schoolYear = this.dataset.schoolYear || '';
            if (!schoolYear) {
                showSyncToast('Please choose a specific school year first.', false);
                return;
            }

            syncPreviewBtn.disabled = true;
            syncPreviewBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Previewing';

            const csrfToken = <?= json_encode(admin_csrf_token()) ?>;
            const previewPayload = new URLSearchParams({
                preview: '1',
                school_year: schoolYear,
                csrf_token: csrfToken
            });
            fetch('/school-admin-dashboard/modules/accounts/account-sync-fees.php', {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                },
                body: previewPayload.toString()
            })
            .then(response => response.json())
            .then(data => {
                syncPreviewBtn.disabled = false;
                syncPreviewBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Preview Sync';

                if (!data || !data.success) {
                    showSyncToast('Sync preview failed: ' + (data && data.message ? data.message : 'Unknown error'), false);
                    return;
                }

                const previewMessage =
                    'School Year: ' + (data.scope_school_year || schoolYear) + '\n' +
                    'Sync Mode: ' + (data.sync_mode || 'Lock-aware missing-first sync') + '\n' +
                    'Students Checked: ' + (data.students_checked || 0) + '\n' +
                    'Fee Rows Considered: ' + (data.fee_rows_considered || 0) + '\n' +
                    'Existing Accounts Reviewed: ' + (data.existing_accounts_reviewed || 0) + '\n' +
                    'Existing Accounts Already Aligned: ' + (data.existing_accounts_already_aligned || 0) + '\n' +
                    'Existing Paid Accounts Reviewed: ' + (data.existing_paid_accounts_reviewed || 0) + '\n' +
                    'Locked Scope Students: ' + (data.locked_scope_students || 0) + '\n' +
                    'Missing Accounts (Preview): ' + (data.missing_accounts || 0) + '\n' +
                    'Accounts to Add: ' + (data.accounts_added || 0) + '\n' +
                    'Accounts to Update: ' + (data.accounts_updated || 0) + '\n' +
                    'Accounts to Remove: ' + (data.accounts_removed || 0) + '\n' +
                    'Locked Existing Accounts Skipped: ' + (data.locked_existing_accounts_skipped || 0) + '\n' +
                    'Locked Adjustment Rows Skipped: ' + (data.locked_adjustment_rows_skipped || 0) + '\n' +
                    'Adjustment Review Needed: ' + (data.adjustment_candidates || 0) + '\n' +
                    'Partial Accounts Affected: ' + (data.partial_adjustment_candidates || 0) + '\n' +
                    'Fully Paid Accounts Affected: ' + (data.fully_paid_adjustment_candidates || 0) + '\n' +
                    'Adjustment Rows to Add: ' + (data.adjustment_rows_added || 0) + '\n' +
                    'Adjustment Rows to Update: ' + (data.adjustment_rows_updated || 0) + '\n' +
                    'Adjustment Rows to Remove: ' + (data.adjustment_rows_removed || 0) + '\n' +
                    'Paid Adjustment Rows Preserved: ' + (data.adjustment_rows_preserved || 0) + '\n\n' +
                    'Proceed with sync for this school year?';

                if (!window.confirm(previewMessage)) {
                    showSyncToast('Sync cancelled. No changes were made.', false);
                    return;
                }

                syncPreviewBtn.disabled = true;
                syncPreviewBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Syncing';

                const syncPayload = new URLSearchParams({
                    school_year: schoolYear,
                    csrf_token: csrfToken
                });
                fetch('/school-admin-dashboard/modules/accounts/account-sync-fees.php', {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    },
                    body: syncPayload.toString()
                })
                .then(response => response.json())
                .then(syncData => {
                    syncPreviewBtn.disabled = false;
                    syncPreviewBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Preview Sync';
                    if (syncData && syncData.success) {
                        showSyncToast(
                            'Sync completed for ' + schoolYear +
                            '. Added: ' + (syncData.accounts_added || 0) +
                            ', Updated: ' + (syncData.accounts_updated || 0) +
                            ', Removed: ' + (syncData.accounts_removed || 0) + '.',
                            true
                        );
                    } else {
                        showSyncToast('Sync failed: ' + (syncData && syncData.message ? syncData.message : 'Unknown error'), false);
                    }
                })
                .catch(err => {
                    syncPreviewBtn.disabled = false;
                    syncPreviewBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Preview Sync';
                    showSyncToast('Sync failed: ' + err, false);
                });
            })
            .catch(err => {
                syncPreviewBtn.disabled = false;
                syncPreviewBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Preview Sync';
                showSyncToast('Sync preview failed: ' + err, false);
            });
        });
    }
</script>
</body>
</html>
<?php $conn->close(); ?>
