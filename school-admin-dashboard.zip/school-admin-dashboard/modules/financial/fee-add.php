<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
include '../../config/database.php';
include '../../modules/settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/../settings/settings-security.php';
require_once __DIR__ . '/../settings/fee-grade-settings-helper.php';
require_once __DIR__ . '/../accounts/account-fee-exceptions-helper.php';
require_once __DIR__ . '/fee-behavior-helper.php';
require_once __DIR__ . '/fee-lock-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

// Centralized permission check for "add fee"
if (!hasPermission($_SESSION['role'], 'account_mgmt', 'add')) {
    admin_session_forbidden();
}

// Fetch FEE TYPES from account_types (single master for fee types)
$fee_types = [];
$res = $conn->query("SELECT id, name FROM account_types ORDER BY priority ASC, name ASC");
while ($row = $res->fetch_assoc()) $fee_types[] = $row;

$grades = fee_grade_label_map($conn);

$error = $success = "";
$type_id = $grade_level = $amount = $notes = $school_year_label = "";
$application_mode = 'required';
ensure_csrf_token();
$debug_mode = isset($_GET['debug']) && $_GET['debug'] === '1';

$fee_table = "fee";
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
fee_behavior_ensure_column($conn);
fee_lock_ensure_table($conn);
$school_year_options = school_year_finance_options($conn, 'fee');
$active_school_year_label = school_year_get_active_label($conn);
$school_year_label = $active_school_year_label;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_require_post_csrf();
    $type_id = intval($_POST['type_id'] ?? 0);
    $grade_level = intval($_POST['grade_level'] ?? 0);
    $amount = floatval($_POST['amount'] ?? 0);
    $notes = trim($_POST['notes'] ?? '');
    $school_year_label = school_year_normalize_label((string) ($_POST['school_year_label'] ?? $active_school_year_label));
    $application_mode = fee_behavior_normalize((string) ($_POST['application_mode'] ?? 'required'));
    $feeLockMap = fee_lock_fetch_map($conn);

    if ($type_id && $grade_level && $amount > 0 && $school_year_label !== '') {
        if (fee_lock_scope_is_locked($feeLockMap, $school_year_label, $grade_level)) {
            $gradeLabel = $grades[$grade_level] ?? ('Grade ' . $grade_level);
            $error = "Fees for {$gradeLabel} under {$school_year_label} are locked. Unlock the fee scope first before adding a new fee row.";
        } else {
        // Reliable duplicate check
        $check = $conn->prepare("SELECT COUNT(*) FROM $fee_table WHERE fee_type_id=? AND grade_level=? AND school_year_label=?");
        $check->bind_param("iis", $type_id, $grade_level, $school_year_label);
        $check->execute();
        $check->bind_result($exists);
        $check->fetch();
        $check->close();

        if ($exists > 0) {
            $error = "Fee type already exists for this grade level and school year.";
        } else {
            $fee_type_name = '';
            foreach ($fee_types as $ft) {
                if ((int) $ft['id'] === $type_id) {
                    $fee_type_name = $ft['name'];
                    break;
                }
            }
            if ($fee_type_name === '') {
                $error = "Selected fee type could not be resolved.";
            } else {
                $grade_name = fee_grade_student_value_for_code($conn, $grade_level);
                $autoAddedAccounts = 0;
                $conn->begin_transaction();
                try {
                    $stmt = $conn->prepare("INSERT INTO $fee_table (fee_type_id, grade_level, amount, notes, school_year_label, application_mode) VALUES (?, ?, ?, ?, ?, ?)");
                    if (!$stmt) {
                        throw new RuntimeException('Could not prepare fee insert.');
                    }
                    $stmt->bind_param("iidsss", $type_id, $grade_level, $amount, $notes, $school_year_label, $application_mode);
                    if (!$stmt->execute()) {
                        throw new RuntimeException('Failed to save fee setup.');
                    }
                    $stmt->close();

                    $students_res = $conn->prepare("SELECT id FROM students WHERE grade=? AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?");
                    if (!$students_res) {
                        throw new RuntimeException('Could not prepare student account auto-add query.');
                    }
                    $students_res->bind_param("sss", $grade_name, $school_year_label, $school_year_label);
                    $students_res->execute();
                    $students_res->store_result();
                    $students_res->bind_result($student_id);

                    while ($students_res->fetch()) {
                        $exceptionMap = student_fee_exception_map($conn, (int) $student_id, $school_year_label);
                        $effectiveRow = student_fee_exception_effective_row([
                            'fee_type_name' => $fee_type_name,
                            'default_amount' => (float) $amount,
                            'application_mode' => $application_mode,
                        ], $exceptionMap[$fee_type_name] ?? null);
                        if (empty($effectiveRow['should_apply'])) {
                            continue;
                        }
                        $targetAmount = (float) $effectiveRow['effective_amount'];

                        $hasAccountTypeCol = school_year_column_exists($conn, 'accounts', 'type');
                        $hasAccountSchoolYear = school_year_column_exists($conn, 'accounts', 'school_year_label');
                        $accountTypeColumn = $hasAccountTypeCol ? '`type`' : 'name';
                        if ($hasAccountSchoolYear) {
                            $dupSql = "SELECT id FROM accounts WHERE student_id=? AND {$accountTypeColumn}=? AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?";
                        } else {
                            $dupSql = "SELECT id FROM accounts WHERE student_id=? AND {$accountTypeColumn}=?";
                        }
                        $check_acc = $conn->prepare($dupSql);
                        if (!$check_acc) {
                            $dbErr = $conn->error;
                            error_log("fee-add duplicate check prepare failed: {$dbErr} | SQL: {$dupSql}");
                            throw new RuntimeException($debug_mode ? ('Could not prepare account duplicate check. ' . $dbErr) : 'Could not prepare account duplicate check.');
                        }
                        if ($hasAccountSchoolYear) {
                            $check_acc->bind_param("isss", $student_id, $fee_type_name, $school_year_label, $school_year_label);
                        } else {
                            $check_acc->bind_param("is", $student_id, $fee_type_name);
                        }
                        $check_acc->execute();
                        $check_acc->store_result();
                        $existsAccount = $check_acc->num_rows > 0;
                        $check_acc->close();

                        if (!$existsAccount) {
                            if ($hasAccountSchoolYear) {
                                $insertSql = "INSERT INTO accounts (student_id, name, {$accountTypeColumn}, balance, notes, school_year_label) VALUES (?, ?, ?, ?, ?, ?)";
                            } else {
                                $insertSql = "INSERT INTO accounts (student_id, name, {$accountTypeColumn}, balance, notes) VALUES (?, ?, ?, ?, ?)";
                            }
                            $insert_acc = $conn->prepare($insertSql);
                            if (!$insert_acc) {
                                $dbErr = $conn->error;
                                error_log("fee-add account insert prepare failed: {$dbErr} | SQL: {$insertSql}");
                                throw new RuntimeException($debug_mode ? ('Could not prepare account insert. ' . $dbErr) : 'Could not prepare account insert.');
                            }
                            if ($hasAccountSchoolYear) {
                                $insert_acc->bind_param("issdss", $student_id, $fee_type_name, $fee_type_name, $targetAmount, $notes, $school_year_label);
                            } else {
                                $insert_acc->bind_param("issds", $student_id, $fee_type_name, $fee_type_name, $targetAmount, $notes);
                            }
                            if (!$insert_acc->execute()) {
                                throw new RuntimeException('Failed to auto-create one or more student accounts.');
                            }
                            $autoAddedAccounts++;
                            $insert_acc->close();
                        }
                    }
                    $students_res->close();

                    $conn->commit();
                    $user = $_SESSION['username'] ?? 'unknown';
                    $details = "Role: " . ($_SESSION['role'] ?? 'unknown')
                        . " | FeeType: " . $fee_type_name
                        . " | Grade: " . $grade_name
                        . " | SchoolYear: " . $school_year_label
                        . " | Amount: " . number_format((float) $amount, 2, '.', '')
                        . " | Mode: " . fee_behavior_label($application_mode)
                        . " | Note: " . ($notes !== '' ? $notes : 'None')
                        . " | AutoAccountsAdded: " . $autoAddedAccounts;
                    audit_log($conn, $user, 'Added fee template', 'Fees', $details);
                    header("Location: fee-list.php?added=1&auto_accounts=" . $autoAddedAccounts);
                    exit;
                } catch (Throwable $e) {
                    $conn->rollback();
                    $error = $e->getMessage();
                }
            }
        }
        }
    } else {
        $error = "Please fill all required fields and enter a valid amount.";
    }
}
$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New Fee | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body {
            background: var(--main-bg);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        }
        body.dark-mode {
            --main-bg: #1b232d;
            --card-bg: #23395d;
            --navbar-bg: #161b22;
            color: #e6edf3;
        }
        .navbar {
            background: var(--navbar-bg) !important;
            box-shadow: 0 2px 12px rgba(33,57,93,0.08);
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.08em;
        }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .theme-toggle-btn {
            background: none;
            border: none;
            color: #fff;
            font-size: 1.45em;
            margin-left: 12px;
            cursor: pointer;
        }
        .dashboard-header {
            text-align: center;
            margin-top: 36px;
            margin-bottom: 18px;
        }
        .dashboard-header img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            margin-bottom: 6px;
        }
        .dashboard-header h1 {
            font-size: 1.3rem;
            color: var(--brand-dark);
            font-weight: 700;
            margin-bottom: 0;
            letter-spacing: 0.02em;
        }
        .main-card {
            background: var(--card-bg);
            border-radius: 1rem;
            box-shadow: 0 4px 18px rgba(33,57,93,0.09), 0 1.5px 3px rgba(33,57,93,0.07);
            margin: 0 auto;
            margin-top: 18px;
            margin-bottom: 32px;
            padding: 2.2rem 2.5rem 2.3rem 2.5rem;
            max-width: 700px;
        }
        .card-header {
            font-weight: 500;
            font-size: 1.05em;
        }
        .btn-success {
            background: #51a46e;
            border-color: #51a46e;
            font-weight: 500;
            border-radius: 7px;
        }
        .btn-success:hover, .btn-success:focus {
            background: #23395d;
            border-color: #23395d;
        }
        .btn-outline-secondary {
            border-radius: 7px;
            font-weight: 500;
        }
        .dashboard-btn-bottom {
            position: fixed;
            left: 28px;
            bottom: 28px;
            z-index: 1060;
            background: #e7f0fd;
            color: #517fa4;
            border: 2px solid #bcdfff;
            box-shadow: 0 5px 16px rgba(33,57,93,0.13);
            border-radius: 50%;
            width: 58px;
            height: 58px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.55em;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
            text-decoration: none;
        }
        .dashboard-btn-bottom:hover, .dashboard-btn-bottom:focus {
            background: #fff2b3;
            color: #517fa4;
            border-color: #ffe599;
        }
        @media (max-width: 900px) {
            .main-card { padding: 1.1rem 0.7rem; max-width: 99vw;}
        }
        @media (max-width: 600px) {
            .dashboard-header h1 { font-size: 1rem; }
            .main-card { margin-top: 7px; margin-bottom: 14px; padding: 0.7rem 0.4rem;}
        }
        /* View Wave 5: detail view alignment */
        :root {
            --vw-page-bg:#eef3f9;
            --vw-card-bg:#ffffff;
            --vw-card-border:#d9e3ef;
            --vw-brand-dark:#23395d;
            --vw-brand-mid:#517fa4;
            --vw-brand-soft:#edf4fb;
            --vw-text-soft:#5f7186;
        }
        body {
            background:
                radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 30%),
                linear-gradient(180deg, #f8fbff 0%, var(--vw-page-bg) 100%);
            color: var(--vw-brand-dark);
        }
        .dashboard-header img {
            width:72px;
            height:72px;
            border-radius:18px;
            background:#fff;
            padding:6px;
            box-shadow:0 10px 25px rgba(35,57,93,0.12);
        }
        .dashboard-header h1 { font-weight:800; }
        .main-card {
            background:var(--vw-card-bg);
            border:1px solid var(--vw-card-border);
            border-radius:20px;
            box-shadow:0 14px 32px rgba(35,57,93,0.07);
        }
        .main-card .card {
            border:1px solid var(--vw-card-border);
            border-radius:18px;
            overflow:hidden;
        }
        .main-card .card-header {
            background:linear-gradient(135deg, var(--vw-brand-dark), var(--vw-brand-mid)) !important;
            border:0;
            font-weight:700;
        }
        .main-card .card-body {
            background:#fbfdff;
        }
        .main-card .form-control,
        .main-card .form-select {
            border-color:#d7e1ed;
            min-height:44px;
            box-shadow:none;
        }
        .main-card .btn-success {
            background:var(--vw-brand-dark);
            border-color:var(--vw-brand-dark);
        }
        .main-card .btn-outline-secondary {
            background:#eef3f8;
            border-color:#d7e1ed;
            color:var(--vw-brand-dark);
        }
    </style>
</head>
<body>
<?php render_admin_nav('fees', true); ?>
<!-- Dashboard Header -->
<div class="dashboard-header">
    <img src="/school-admin-dashboard/uploads/logo1.png" alt="School Logo" class="mb-2 rounded shadow-sm">
    <h1><?= $schoolName ?></h1>
</div>
<!-- Main Card -->
<div class="container main-card px-3">
    <div class="text-uppercase small fw-bold mb-2" style="letter-spacing:.08em; color: var(--vw-text-soft);">Fee Setup Detail</div>
    <div class="card">
        <div class="card-header bg-success text-light">
            <h4 class="mb-0"><i class="fa-solid fa-plus"></i> Add New Fee Setup</h4>
        </div>
        <div class="card-body">
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="post">
                <?= csrf_input() ?>
                <div class="mb-3">
                    <label for="type_id" class="form-label">Fee Type</label>
                    <select name="type_id" id="type_id" class="form-select" required>
                        <option value="">Select Fee Type</option>
                        <?php foreach ($fee_types as $ft): ?>
                            <option value="<?= $ft['id'] ?>" <?= $type_id==$ft['id']?'selected':'' ?>>
                                <?= htmlspecialchars($ft['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <a href="/school-admin-dashboard/modules/accounts/account-manage-types.php" class="link-secondary ms-2">Manage Fee Types</a>
                </div>
                <div class="mb-3">
                    <label for="grade_level" class="form-label">Grade Level</label>
                    <select name="grade_level" id="grade_level" class="form-select" required>
                        <option value="">Select Grade Level</option>
                        <?php foreach ($grades as $num => $name): ?>
                            <option value="<?= $num ?>" <?= $grade_level==$num?'selected':'' ?>><?= htmlspecialchars($name) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="school_year_label" class="form-label">School Year</label>
                    <select name="school_year_label" id="school_year_label" class="form-select" required>
                        <?php foreach ($school_year_options as $option): ?>
                            <option value="<?= htmlspecialchars($option) ?>" <?= $school_year_label === $option ? 'selected' : '' ?>>
                                <?= htmlspecialchars($option) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-text">Fees are now scoped per school year so billing stays separate across enrollment cycles.</div>
                </div>
                <div class="mb-3">
                    <label for="application_mode" class="form-label">Application Mode</label>
                    <select name="application_mode" id="application_mode" class="form-select" required>
                        <?php foreach (fee_behavior_modes() as $modeValue => $modeLabel): ?>
                            <option value="<?= htmlspecialchars($modeValue) ?>" <?= $application_mode === $modeValue ? 'selected' : '' ?>><?= htmlspecialchars($modeLabel) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-text">Required fees apply automatically. Optional and conditional fees are only applied when included or overridden per student.</div>
                </div>
                <div class="mb-3">
                    <label for="amount" class="form-label">Amount</label>
                    <input type="number" name="amount" step="0.01" min="0" class="form-control" value="<?= htmlspecialchars($amount) ?>" required>
                </div>
                <div class="mb-3">
                    <label for="notes" class="form-label">Notes</label>
                    <input type="text" name="notes" id="notes" class="form-control" value="<?= htmlspecialchars($notes) ?>">
                </div>
                <button type="submit" class="btn btn-success"><i class="fa-solid fa-save"></i> Add Fee</button>
                <a href="/school-admin-dashboard/modules/financial/fee-list.php" class="btn btn-outline-secondary ms-1">Cancel</a>
            </form>
            <div class="mt-3 text-muted small">
                When you add a new fee type for a grade, all currently registered students in that grade will automatically have this fee added to their accounts.<br>
                No need for manual editing. Future students will get all fees for their grade when registered.
            </div>
        </div>
    </div>
</div>
<footer class="text-center py-4 text-muted small">
    &copy; <?= date("Y") ?> <?= $schoolName ?> | School Admin Dashboard
</footer>
<a href="/school-admin-dashboard/dashboard.php" class="dashboard-btn-bottom" title="Go to Dashboard">
    <i class="fas fa-tachometer-alt"></i>
</a>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Theme toggle
    document.getElementById('themeToggleBtn').addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        this.querySelector('i').classList.toggle('fa-moon');
        this.querySelector('i').classList.toggle('fa-sun');
    });
</script>
</body>
</html>
<?php $conn->close(); ?>
