<?php

function fee_lock_ensure_table(mysqli $conn): void
{
    require_once __DIR__ . '/../../includes/schema-migration.php';
    if (!schema_migration_mode_enabled()) {
        return;
    }

    schema_migration_attempt($conn, "
        CREATE TABLE IF NOT EXISTS fee_lock_scope (
            id INT AUTO_INCREMENT PRIMARY KEY,
            school_year_label VARCHAR(30) NOT NULL,
            grade_level INT NOT NULL,
            is_locked TINYINT(1) NOT NULL DEFAULT 1,
            locked_at DATETIME NULL,
            locked_by VARCHAR(100) NULL,
            lock_reason VARCHAR(255) NULL,
            unlocked_at DATETIME NULL,
            unlocked_by VARCHAR(100) NULL,
            unlock_reason VARCHAR(255) NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_fee_lock_scope (school_year_label, grade_level)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $res = $conn->query("SHOW COLUMNS FROM fee_lock_scope");
    $columns = [];
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $columns[(string) ($row['Field'] ?? '')] = true;
        }
        $res->close();
    }

    if (!isset($columns['lock_reason'])) {
        schema_migration_attempt($conn, "ALTER TABLE fee_lock_scope ADD COLUMN lock_reason VARCHAR(255) NULL AFTER locked_by");
    }
    if (!isset($columns['unlock_reason'])) {
        schema_migration_attempt($conn, "ALTER TABLE fee_lock_scope ADD COLUMN unlock_reason VARCHAR(255) NULL AFTER unlocked_by");
    }
}

function fee_lock_fetch_map(mysqli $conn): array
{
    $map = [];
    $result = $conn->query("
        SELECT school_year_label, grade_level, is_locked, locked_at, locked_by, lock_reason, unlocked_at, unlocked_by, unlock_reason
        FROM fee_lock_scope
    ");
    if (!$result) {
        return $map;
    }

    while ($row = $result->fetch_assoc()) {
        $schoolYear = (string) ($row['school_year_label'] ?? '');
        $gradeLevel = (int) ($row['grade_level'] ?? 0);
        if ($schoolYear === '' || $gradeLevel <= 0) {
            continue;
        }
        if (!isset($map[$schoolYear])) {
            $map[$schoolYear] = [];
        }
        $map[$schoolYear][$gradeLevel] = $row;
    }

    return $map;
}

function fee_lock_scope_row(array $lockMap, string $schoolYearLabel, int $gradeLevel): ?array
{
    return $lockMap[$schoolYearLabel][$gradeLevel] ?? null;
}

function fee_lock_scope_is_locked(array $lockMap, string $schoolYearLabel, int $gradeLevel): bool
{
    $row = fee_lock_scope_row($lockMap, $schoolYearLabel, $gradeLevel);
    return (bool) ($row && (int) ($row['is_locked'] ?? 0) === 1);
}

function fee_lock_scope(mysqli $conn, string $schoolYearLabel, int $gradeLevel, string $actor, string $reason = ''): bool
{
    $stmt = $conn->prepare("
        INSERT INTO fee_lock_scope (school_year_label, grade_level, is_locked, locked_at, locked_by, lock_reason, unlocked_at, unlocked_by, unlock_reason)
        VALUES (?, ?, 1, NOW(), ?, ?, NULL, NULL, NULL)
        ON DUPLICATE KEY UPDATE
            is_locked = 1,
            locked_at = NOW(),
            locked_by = VALUES(locked_by),
            lock_reason = VALUES(lock_reason),
            unlocked_at = NULL,
            unlocked_by = NULL,
            unlock_reason = NULL
    ");
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('siss', $schoolYearLabel, $gradeLevel, $actor, $reason);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function fee_unlock_scope(mysqli $conn, string $schoolYearLabel, int $gradeLevel, string $actor, string $reason): bool
{
    $stmt = $conn->prepare("
        INSERT INTO fee_lock_scope (school_year_label, grade_level, is_locked, unlocked_at, unlocked_by, unlock_reason)
        VALUES (?, ?, 0, NOW(), ?, ?)
        ON DUPLICATE KEY UPDATE
            is_locked = 0,
            unlocked_at = NOW(),
            unlocked_by = VALUES(unlocked_by),
            unlock_reason = VALUES(unlock_reason)
    ");
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('siss', $schoolYearLabel, $gradeLevel, $actor, $reason);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}
