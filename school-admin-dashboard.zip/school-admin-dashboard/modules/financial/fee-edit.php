<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
include '../../config/database.php';
include '../../modules/settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/../settings/fee-grade-settings-helper.php';
require_once __DIR__ . '/../settings/settings-security.php';
require_once __DIR__ . '/fee-behavior-helper.php';
require_once __DIR__ . '/fee-lock-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

// Centralized permission check for editing fees
if (!hasPermission($_SESSION['role'], 'account_mgmt', 'edit')) {
    admin_session_forbidden();
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = $success = "";
$fee_type_id = $grade_level = $amount = $notes = $school_year_label = "";
$application_mode = 'required';
ensure_csrf_token();
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
fee_behavior_ensure_column($conn);
fee_lock_ensure_table($conn);
$school_year_options = school_year_finance_options($conn, 'fee');
$grades = fee_grade_label_map($conn, true);

if ($id) {
    $stmt = $conn->prepare("SELECT fee_type_id, grade_level, amount, notes, school_year_label, application_mode FROM fee WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($fee_type_id, $grade_level, $amount, $notes, $school_year_label, $application_mode);
    if (!$stmt->fetch()) $error = "Fee not found.";
    $stmt->close();
} else {
    $error = "Invalid fee ID.";
}

$feeLockMap = fee_lock_fetch_map($conn);
$currentFeeScopeLocked = !$error && $school_year_label !== '' && $grade_level > 0
    ? fee_lock_scope_is_locked($feeLockMap, (string) $school_year_label, (int) $grade_level)
    : false;
$currentFeeScopeLabel = isset($grades[(int) $grade_level]) ? $grades[(int) $grade_level] : ('Grade ' . (int) $grade_level);
if ($currentFeeScopeLocked && $error === '') {
    $error = "This fee scope is locked for {$currentFeeScopeLabel} under {$school_year_label}. Unlock the fee scope first before editing this fee.";
}

$types = [];
$res = $conn->query("SELECT id, name FROM account_types ORDER BY name ASC");
while ($row = $res->fetch_assoc()) $types[] = $row;

$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$error) {
    admin_require_post_csrf();
    $old_fee_type_id = $fee_type_id;
    $old_grade_level = $grade_level;
    $old_amount = $amount;
    $old_notes = $notes;
    $old_school_year_label = $school_year_label;
    $old_application_mode = $application_mode;
    $new_fee_type_id = intval($_POST['fee_type_id'] ?? 0);
    $new_grade_level = intval($_POST['grade_level'] ?? 0);
    $new_amount = floatval($_POST['amount'] ?? 0);
    $new_notes = trim($_POST['notes'] ?? '');
    $new_school_year_label = school_year_normalize_label((string) ($_POST['school_year_label'] ?? ''));
    $new_application_mode = fee_behavior_normalize((string) ($_POST['application_mode'] ?? 'required'));
    if ($new_fee_type_id && $new_grade_level && $new_amount > 0 && $new_school_year_label !== '') {
        if (fee_lock_scope_is_locked($feeLockMap, $new_school_year_label, $new_grade_level)
            || fee_lock_scope_is_locked($feeLockMap, (string) $old_school_year_label, (int) $old_grade_level)) {
            $lockedGradeName = $grades[$new_grade_level] ?? ('Grade ' . $new_grade_level);
            $error = "This fee scope is locked for {$lockedGradeName} under {$new_school_year_label}. Unlock the fee scope first before editing this fee.";
        } else {
        $duplicateStmt = $conn->prepare("SELECT id FROM fee WHERE fee_type_id = ? AND grade_level = ? AND school_year_label = ? AND id <> ? LIMIT 1");
        if (!$duplicateStmt) {
            $error = "Could not validate duplicate fee setup.";
        } else {
            $duplicateStmt->bind_param("iisi", $new_fee_type_id, $new_grade_level, $new_school_year_label, $id);
            $duplicateStmt->execute();
            $hasDuplicate = $duplicateStmt->get_result()->num_rows > 0;
            $duplicateStmt->close();

            if ($hasDuplicate) {
                $error = "Another fee already exists for this fee type, grade level, and school year.";
            } else {
                $stmt = $conn->prepare("UPDATE fee SET fee_type_id=?, grade_level=?, amount=?, notes=?, school_year_label=?, application_mode=? WHERE id=?");
                $stmt->bind_param("iidsssi", $new_fee_type_id, $new_grade_level, $new_amount, $new_notes, $new_school_year_label, $new_application_mode, $id);
                if ($stmt->execute()) {
                    $success = "Fee updated. Run Sync Fees if you want existing student account balances for this school year to match the new fee setup.";
                    $oldFeeTypeName = '';
                    $newFeeTypeName = '';
                    foreach ($types as $typeRow) {
                        if ((int) $typeRow['id'] === (int) $old_fee_type_id) {
                            $oldFeeTypeName = (string) $typeRow['name'];
                        }
                        if ((int) $typeRow['id'] === (int) $new_fee_type_id) {
                            $newFeeTypeName = (string) $typeRow['name'];
                        }
                    }
                    $oldGradeName = $grades[$old_grade_level] ?? ('Grade ' . $old_grade_level);
                    $newGradeName = $grades[$new_grade_level] ?? ('Grade ' . $new_grade_level);
                    $user = $_SESSION['username'] ?? 'unknown';
                    $details = "Role: " . ($_SESSION['role'] ?? 'unknown')
                        . " | Old: {$oldFeeTypeName} / {$oldGradeName} / {$old_school_year_label} / " . number_format((float) $old_amount, 2, '.', '') . " / " . fee_behavior_label((string) $old_application_mode)
                        . " | New: {$newFeeTypeName} / {$newGradeName} / {$new_school_year_label} / " . number_format((float) $new_amount, 2, '.', '') . " / " . fee_behavior_label($new_application_mode)
                        . " | Old Note: " . ($old_notes !== '' ? $old_notes : 'None')
                        . " | New Note: " . ($new_notes !== '' ? $new_notes : 'None');
                    audit_log($conn, $user, 'Updated fee template', 'Fees', $details);
                    $fee_type_id = $new_fee_type_id;
                    $grade_level = $new_grade_level;
                    $amount = $new_amount;
                    $notes = $new_notes;
                    $school_year_label = $new_school_year_label;
                    $application_mode = $new_application_mode;
                } else {
                    $error = "Failed to update fee.";
                }
                $stmt->close();
            }
        }
        }
    } else {
        $error = "Please fill all required fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Fee | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body {
            background: var(--main-bg);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        }
        body.dark-mode {
            --main-bg: #1b232d;
            --card-bg: #23395d;
            --navbar-bg: #161b22;
            color: #e6edf3;
        }
        .navbar {
            background: var(--navbar-bg) !important;
            box-shadow: 0 2px 12px rgba(33,57,93,0.08);
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.08em;
        }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .theme-toggle-btn {
            background: none;
            border: none;
            color: #fff;
            font-size: 1.45em;
            margin-left: 12px;
            cursor: pointer;
        }
        .dashboard-header {
            text-align: center;
            margin-top: 36px;
            margin-bottom: 18px;
        }
        .dashboard-header img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            margin-bottom: 6px;
        }
        .dashboard-header h1 {
            font-size: 1.3rem;
            color: var(--brand-dark);
            font-weight: 700;
            margin-bottom: 0;
            letter-spacing: 0.02em;
        }
        .main-card {
            background: var(--card-bg);
            border-radius: 1rem;
            box-shadow: 0 4px 18px rgba(33,57,93,0.09), 0 1.5px 3px rgba(33,57,93,0.07);
            margin: 0 auto;
            margin-top: 18px;
            margin-bottom: 32px;
            padding: 2.2rem 2.5rem 2.3rem 2.5rem;
            max-width: 700px;
        }
        .card-header.bg-primary {
            font-weight: 500;
            font-size: 1.05em;
            background: #517fa4 !important;
            color: #fff !important;
        }
        .btn-primary {
            background: #517fa4;
            border-color: #517fa4;
            font-weight: 500;
            border-radius: 7px;
        }
        .btn-primary:hover, .btn-primary:focus {
            background: #23395d;
            border-color: #23395d;
        }
        .btn-outline-secondary {
            border-radius: 7px;
            font-weight: 500;
        }
        .dashboard-btn-bottom {
            position: fixed;
            left: 28px;
            bottom: 28px;
            z-index: 1060;
            background: #e7f0fd;
            color: #517fa4;
            border: 2px solid #bcdfff;
            box-shadow: 0 5px 16px rgba(33,57,93,0.13);
            border-radius: 50%;
            width: 58px;
            height: 58px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.55em;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
            text-decoration: none;
        }
        .dashboard-btn-bottom:hover, .dashboard-btn-bottom:focus {
            background: #fff2b3;
            color: #517fa4;
            border-color: #ffe599;
        }
        @media (max-width: 900px) {
            .main-card { padding: 1.1rem 0.7rem; max-width: 99vw;}
        }
        @media (max-width: 600px) {
            .dashboard-header h1 { font-size: 1rem; }
            .main-card { margin-top: 7px; margin-bottom: 14px; padding: 0.7rem 0.4rem;}
        }
        /* View Wave 6: legacy detail polish */
        :root {
            --vw-page-bg:#eef3f9;
            --vw-card-bg:#ffffff;
            --vw-card-border:#d9e3ef;
            --vw-brand-dark:#23395d;
            --vw-brand-mid:#517fa4;
        }
        body {
            background:
                radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 30%),
                linear-gradient(180deg, #f8fbff 0%, var(--vw-page-bg) 100%);
            color: var(--vw-brand-dark);
        }
        .dashboard-header img {
            width:72px;
            height:72px;
            border-radius:18px;
            background:#fff;
            padding:6px;
            box-shadow:0 10px 25px rgba(35,57,93,0.12);
        }
        .dashboard-header h1 { font-weight:800; }
        .main-card {
            border:1px solid var(--vw-card-border);
            border-radius:20px;
            box-shadow:0 14px 32px rgba(35,57,93,0.07);
        }
        .main-card .card {
            border:1px solid var(--vw-card-border);
            border-radius:18px;
            overflow:hidden;
        }
        .card-header.bg-primary {
            background:linear-gradient(135deg, var(--vw-brand-dark), var(--vw-brand-mid)) !important;
            border:0;
            font-weight:700;
        }
        .form-control, .form-select {
            border-color:#d7e1ed;
            min-height:44px;
            box-shadow:none;
        }
    </style>
</head>
<body>
<!-- Navbar -->
<?php render_admin_nav('fees', true); ?>
<!-- Dashboard Header -->
<?php render_school_page_header($schoolName); ?>
<!-- Main Card -->
<div class="container main-card px-3">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-light">
            <h4 class="mb-0"><i class="fa-solid fa-pen-to-square"></i> Edit Fee</h4>
        </div>
        <div class="card-body">
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
                <a href="/school-admin-dashboard/modules/financial/fee-list.php" class="btn btn-outline-secondary mt-2"><i class="fa-solid fa-arrow-left"></i> Back to Fees</a>
            <?php elseif (!$error): ?>
            <form method="post">
                <?= csrf_input() ?>
                <div class="mb-3">
                    <label for="fee_type_id" class="form-label">Fee Type</label>
                    <select name="fee_type_id" id="fee_type_id" class="form-select" required>
                        <option value="">Select Fee Type</option>
                        <?php foreach ($types as $t): ?>
                            <option value="<?= $t['id'] ?>" <?= ($t['id'] == $fee_type_id) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($t['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="grade_level" class="form-label">Grade Level</label>
                    <select name="grade_level" id="grade_level" class="form-select" required>
                        <option value="">Select Grade Level</option>
                        <?php foreach ($grades as $num => $name): ?>
                            <option value="<?= $num ?>" <?= (string) $grade_level === (string) $num ? 'selected' : '' ?>><?= htmlspecialchars($name) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="school_year_label" class="form-label">School Year</label>
                    <select name="school_year_label" id="school_year_label" class="form-select" required>
                        <?php foreach ($school_year_options as $option): ?>
                            <option value="<?= htmlspecialchars($option) ?>" <?= $school_year_label === $option ? 'selected' : '' ?>>
                                <?= htmlspecialchars($option) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="application_mode" class="form-label">Application Mode</label>
                    <select name="application_mode" id="application_mode" class="form-select" required>
                        <?php foreach (fee_behavior_modes() as $modeValue => $modeLabel): ?>
                            <option value="<?= htmlspecialchars($modeValue) ?>" <?= $application_mode === $modeValue ? 'selected' : '' ?>><?= htmlspecialchars($modeLabel) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-text">Required fees apply automatically. Optional and conditional fees only apply when specifically included or overridden per student.</div>
                </div>
                <div class="mb-3">
                    <label for="amount" class="form-label">Amount</label>
                    <input type="number" step="0.01" name="amount" id="amount" class="form-control" value="<?= htmlspecialchars($amount) ?>" required>
                </div>
                <div class="mb-3">
                    <label for="notes" class="form-label">Notes</label>
                    <input type="text" name="notes" id="notes" class="form-control" value="<?= htmlspecialchars($notes) ?>">
                </div>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-save"></i> Save Changes</button>
                <a href="/school-admin-dashboard/modules/financial/fee-list.php" class="btn btn-outline-secondary ms-1">Cancel</a>
            </form>
            <?php else: ?>
                <a href="/school-admin-dashboard/modules/financial/fee-list.php" class="btn btn-outline-secondary mt-2"><i class="fa-solid fa-arrow-left"></i> Back to Fees</a>
            <?php endif; ?>
        </div>
    </div>
</div>
<footer class="text-center py-4 text-muted small">
    &copy; <?= date("Y") ?> <?= $schoolName ?> | School Admin Dashboard
</footer>
<a href="/school-admin-dashboard/dashboard.php" class="dashboard-btn-bottom" title="Go to Dashboard">
    <i class="fas fa-tachometer-alt"></i>
</a>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Theme toggle
    document.getElementById('themeToggleBtn').addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        this.querySelector('i').classList.toggle('fa-moon');
        this.querySelector('i').classList.toggle('fa-sun');
    });
</script>
</body>
</html>
<?php $conn->close(); ?>
