<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
include '../../config/database.php';
include '../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/../accounts/account-fee-exceptions-helper.php';
require_once __DIR__ . '/fee-behavior-helper.php';

if (!hasPermission($_SESSION['role'], 'account_mgmt', 'view')) {
    admin_session_forbidden();
}

school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
student_fee_exceptions_ensure_table($conn);
fee_behavior_ensure_column($conn);

$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";
$schoolYearOptions = school_year_finance_options($conn, 'fee');
$activeSchoolYearLabel = school_year_get_active_label($conn);

$filterSchoolYear = trim($_GET['school_year'] ?? $activeSchoolYearLabel);
$filterMode = trim($_GET['mode'] ?? '');
$filterFeeType = trim($_GET['fee_type_name'] ?? '');
$filterKeyword = trim($_GET['keyword'] ?? '');

$where = ["sfe.mode IN ('include', 'exclude', 'override')"];
$params = [];
$types = '';

if ($filterSchoolYear !== '') {
    $where[] = "sfe.school_year_label = ?";
    $params[] = $filterSchoolYear;
    $types .= 's';
}
if ($filterMode !== '' && in_array($filterMode, ['include', 'exclude', 'override'], true)) {
    $where[] = "sfe.mode = ?";
    $params[] = $filterMode;
    $types .= 's';
}
if ($filterFeeType !== '') {
    $where[] = "sfe.fee_type_name = ?";
    $params[] = $filterFeeType;
    $types .= 's';
}
if ($filterKeyword !== '') {
    $where[] = "(CONCAT(s.lastname, ', ', s.firstname, ' ', s.middlename) LIKE ? OR sfe.note LIKE ? OR sfe.updated_by LIKE ?)";
    $keywordLike = '%' . $filterKeyword . '%';
    $params[] = $keywordLike;
    $params[] = $keywordLike;
    $params[] = $keywordLike;
    $types .= 'sss';
}

$sql = "SELECT
    sfe.student_id,
    sfe.fee_type_name,
    sfe.school_year_label,
    sfe.mode,
    sfe.override_amount,
    sfe.note,
    sfe.updated_by,
    sfe.updated_at,
    s.grade,
    CONCAT(s.lastname, ', ', s.firstname, ' ', s.middlename) AS student_name
    FROM student_fee_exceptions sfe
    INNER JOIN students s ON s.id = sfe.student_id
    WHERE " . implode(' AND ', $where) . "
    ORDER BY sfe.updated_at DESC, student_name ASC, sfe.fee_type_name ASC";
$stmt = $conn->prepare($sql);
$rows = [];
if ($stmt) {
    if ($params) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $templateRows = student_fee_template_rows($conn, (string) ($row['grade'] ?? ''), (string) ($row['school_year_label'] ?? ''));
        $applicationMode = 'required';
        foreach ($templateRows as $templateRow) {
            if ((string) ($templateRow['fee_type_name'] ?? '') === (string) ($row['fee_type_name'] ?? '')) {
                $applicationMode = (string) ($templateRow['application_mode'] ?? 'required');
                break;
            }
        }
        $row['application_mode'] = $applicationMode;
        $rows[] = $row;
    }
    $stmt->close();
}

$feeTypeOptions = [];
$typeResult = $conn->query("SELECT DISTINCT fee_type_name FROM student_fee_exceptions WHERE mode IN ('exclude', 'override') ORDER BY fee_type_name ASC");
if ($typeResult) {
    while ($row = $typeResult->fetch_assoc()) {
        $feeTypeOptions[] = (string) ($row['fee_type_name'] ?? '');
    }
    $typeResult->close();
}

$summary = student_fee_exception_review_summary($conn, $filterSchoolYear, $filterMode, $filterFeeType);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Fee Exception Review</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --vw-page-bg:#eef3f9;
            --vw-card-bg:#ffffff;
            --vw-card-border:#d9e3ef;
            --vw-brand-dark:#23395d;
            --vw-brand-mid:#517fa4;
            --vw-brand-soft:#edf4fb;
            --vw-text-soft:#5f7186;
        }
        body {
            font-family:'Segoe UI','Roboto','Arial',sans-serif;
            background:
                radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 30%),
                linear-gradient(180deg, #f8fbff 0%, var(--vw-page-bg) 100%);
            color:var(--vw-brand-dark);
        }
        .dashboard-header {
            text-align:center;
            padding:32px 0 14px;
        }
        .dashboard-header img {
            width:72px;
            height:72px;
            border-radius:18px;
            background:#fff;
            padding:6px;
            box-shadow:0 10px 25px rgba(35,57,93,0.12);
        }
        .dashboard-header h1 {
            font-weight:800;
            color:var(--vw-brand-dark);
            font-size:1.35rem;
        }
        .main-card {
            max-width:1220px;
            margin:0 auto 36px;
            background:var(--vw-card-bg);
            border:1px solid var(--vw-card-border);
            border-radius:22px;
            box-shadow:0 16px 36px rgba(35,57,93,0.08);
            padding:1.5rem;
        }
        .summary-card, .filter-shell {
            border:1px solid var(--vw-card-border);
            border-radius:18px;
            background:#fff;
            box-shadow:0 10px 24px rgba(35,57,93,0.05);
        }
        .summary-card {
            padding:1rem 1.1rem;
            height:100%;
        }
        .summary-label {
            font-size:0.82rem;
            text-transform:uppercase;
            color:var(--vw-text-soft);
            letter-spacing:.05em;
        }
        .summary-value {
            font-size:1.45rem;
            font-weight:800;
            color:var(--vw-brand-dark);
        }
        .filter-shell {
            padding:1rem;
        }
        .form-select, .form-control {
            border-radius:12px;
            border-color:#d7e1ed;
            min-height:44px;
        }
        .review-table-card {
            border:1px solid var(--vw-card-border);
            border-radius:20px;
            overflow:hidden;
            box-shadow:0 14px 32px rgba(35,57,93,0.07);
        }
        .review-table-card .card-header {
            background:linear-gradient(135deg, var(--vw-brand-dark), var(--vw-brand-mid));
            color:#fff;
            border:0;
            font-weight:700;
            padding:1rem 1.15rem;
        }
        .table thead th {
            background:var(--vw-brand-soft);
            color:var(--vw-brand-dark);
            border-bottom:1px solid var(--vw-card-border);
            font-weight:700;
        }
        .table tbody td {
            vertical-align:middle;
            background:#fbfdff;
        }
        .mode-badge {
            display:inline-flex;
            align-items:center;
            gap:6px;
            padding:.42rem .72rem;
            border-radius:999px;
            font-weight:700;
        }
        .mode-badge.exclude {
            background:#fdecec;
            color:#b42318;
            border:1px solid #f2c9c9;
        }
        .mode-badge.override {
            background:#fff4db;
            color:#9a6700;
            border:1px solid #f5deb3;
        }
        .empty-state {
            padding:2.4rem 1rem;
            color:var(--vw-text-soft);
        }
    </style>
</head>
<body>
<div class="dashboard-header">
    <img src="/school-admin-dashboard/uploads/logo1.png" alt="School Logo" class="mb-2 rounded shadow-sm">
    <h1><?= htmlspecialchars($schoolName) ?></h1>
</div>
<div class="container">
    <div class="main-card">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-4">
            <div>
                <div class="text-uppercase small fw-bold" style="letter-spacing:.08em; color:var(--vw-text-soft);">Fee Grade Wave 5</div>
                <div class="h3 mb-1"><i class="fas fa-clipboard-list me-2"></i>Fee Exception Review</div>
                <div class="text-muted">Central view for excluded and overridden student fee rows.</div>
            </div>
            <div class="d-flex flex-wrap gap-2">
                <a href="fee-list.php" class="btn btn-outline-secondary fw-bold"><i class="fas fa-arrow-left me-2"></i>Back to Fees</a>
            </div>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="summary-card">
                    <div class="summary-label">Exception Rows</div>
                    <div class="summary-value"><?= number_format($summary['total_exceptions']) ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="summary-card">
                    <div class="summary-label">Affected Students</div>
                    <div class="summary-value"><?= number_format($summary['affected_students']) ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="summary-card">
                    <div class="summary-label">Included Rows</div>
                    <div class="summary-value"><?= number_format($summary['included_rows']) ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="summary-card">
                    <div class="summary-label">Excluded Rows</div>
                    <div class="summary-value"><?= number_format($summary['excluded_rows']) ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="summary-card">
                    <div class="summary-label">Override Rows</div>
                    <div class="summary-value"><?= number_format($summary['override_rows']) ?></div>
                </div>
            </div>
        </div>

        <form method="get" class="filter-shell mb-4">
            <div class="row g-2">
                <div class="col-md-3">
                    <input type="text" name="keyword" class="form-control" placeholder="Search student, note, or admin" value="<?= htmlspecialchars($filterKeyword) ?>">
                </div>
                <div class="col-md-3">
                    <select name="school_year" class="form-select">
                        <option value="">All School Years</option>
                        <?php foreach ($schoolYearOptions as $schoolYearOption): ?>
                            <option value="<?= htmlspecialchars($schoolYearOption) ?>" <?= $filterSchoolYear === $schoolYearOption ? 'selected' : '' ?>><?= htmlspecialchars($schoolYearOption) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="mode" class="form-select">
                        <option value="">All Modes</option>
                        <option value="include" <?= $filterMode === 'include' ? 'selected' : '' ?>>Included</option>
                        <option value="exclude" <?= $filterMode === 'exclude' ? 'selected' : '' ?>>Excluded</option>
                        <option value="override" <?= $filterMode === 'override' ? 'selected' : '' ?>>Override</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="fee_type_name" class="form-select">
                        <option value="">All Fee Types</option>
                        <?php foreach ($feeTypeOptions as $feeTypeOption): ?>
                            <option value="<?= htmlspecialchars($feeTypeOption) ?>" <?= $filterFeeType === $feeTypeOption ? 'selected' : '' ?>><?= htmlspecialchars($feeTypeOption) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2 d-flex gap-2">
                    <button type="submit" class="btn btn-secondary w-100">Apply</button>
                    <a href="fee-exception-review.php" class="btn btn-outline-secondary w-100">Reset</a>
                </div>
            </div>
        </form>

        <div class="card review-table-card">
            <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
                <div><i class="fas fa-table me-2"></i>Exception Rows</div>
                <div class="small opacity-75">School Year: <?= htmlspecialchars($filterSchoolYear !== '' ? $filterSchoolYear : 'All School Years') ?></div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped mb-0 align-middle">
                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Grade</th>
                                <th>Fee Type</th>
                                <th>Behavior</th>
                                <th>Mode</th>
                                <th>Override Amount</th>
                                <th>School Year</th>
                                <th>Note</th>
                                <th>Last Touch</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($rows): ?>
                                <?php foreach ($rows as $row): ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold"><?= htmlspecialchars((string) ($row['student_name'] ?? '')) ?></div>
                                            <div class="small text-muted">Student ID: <?= (int) ($row['student_id'] ?? 0) ?></div>
                                        </td>
                                        <td><?= htmlspecialchars((string) ($row['grade'] ?? '')) ?></td>
                                        <td><?= htmlspecialchars((string) ($row['fee_type_name'] ?? '')) ?></td>
                                        <td><?= htmlspecialchars(fee_behavior_label((string) ($row['application_mode'] ?? 'required'))) ?></td>
                                        <td>
                                            <span class="mode-badge <?= htmlspecialchars((string) ($row['mode'] ?? '')) ?>">
                                                <i class="fas <?= ($row['mode'] ?? '') === 'exclude' ? 'fa-ban' : (($row['mode'] ?? '') === 'include' ? 'fa-check-circle' : 'fa-sliders-h') ?>"></i>
                                                <?= ucfirst((string) ($row['mode'] ?? '')) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if (($row['mode'] ?? '') === 'override' && $row['override_amount'] !== null): ?>
                                                <span class="fw-bold">PHP <?= number_format((float) $row['override_amount'], 2) ?></span>
                                            <?php else: ?>
                                                <span class="text-muted">N/A</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= htmlspecialchars((string) ($row['school_year_label'] ?? '')) ?></td>
                                        <td><?= htmlspecialchars((string) (($row['note'] ?? '') !== '' ? $row['note'] : 'No note')) ?></td>
                                        <td>
                                            <div class="fw-bold"><?= htmlspecialchars((string) (($row['updated_by'] ?? '') !== '' ? $row['updated_by'] : 'System')) ?></div>
                                            <div class="small text-muted"><?= htmlspecialchars((string) ($row['updated_at'] ?? '')) ?></div>
                                        </td>
                                        <td>
                                            <a href="../accounts/account-fee-exceptions.php?student_id=<?= (int) $row['student_id'] ?>&school_year=<?= urlencode((string) ($row['school_year_label'] ?? '')) ?>" class="btn btn-sm btn-outline-primary fw-bold">
                                                <i class="fas fa-pen-to-square"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="10" class="text-center empty-state">No fee exception rows matched the current filters.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php $conn->close(); ?>
