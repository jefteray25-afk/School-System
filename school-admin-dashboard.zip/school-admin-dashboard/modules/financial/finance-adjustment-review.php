<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require '../../config/database.php';
include '../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/school-info-helper.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/../accounts/finance-adjustment-helper.php';

if (!hasPermission($_SESSION['role'] ?? '', 'account_mgmt', 'view')) {
    admin_session_forbidden();
}

finance_adjustment_ensure_tables($conn);
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$schoolYearOptions = school_year_finance_options($conn, 'fee');
$activeSchoolYearLabel = school_year_get_active_label($conn);

$filterSchoolYear = trim((string) ($_GET['school_year'] ?? $activeSchoolYearLabel));
$filterStatus = trim((string) ($_GET['status'] ?? ''));
$filterType = trim((string) ($_GET['adjustment_type'] ?? ''));
$filterKeyword = trim((string) ($_GET['keyword'] ?? ''));

$tablesReady = finance_adjustment_tables_ready($conn);
$rows = $tablesReady ? finance_adjustment_review_rows($conn, $filterSchoolYear, $filterStatus, $filterType, $filterKeyword) : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance Adjustment Review</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --vw-page-bg:#eef3f9; --vw-card-bg:#fff; --vw-card-border:#d9e3ef; --vw-brand-dark:#23395d; --vw-brand-mid:#517fa4; }
        body { font-family:'Segoe UI','Roboto','Arial',sans-serif; background:linear-gradient(180deg,#f8fbff 0%,var(--vw-page-bg) 100%); color:var(--vw-brand-dark); }
        .navbar { background:var(--vw-brand-dark) !important; box-shadow:0 2px 12px rgba(33,57,93,.08); }
        .navbar-brand, .navbar-nav .nav-link { color:#fff !important; }
        .main-card { background:var(--vw-card-bg); border:1px solid var(--vw-card-border); border-radius:20px; box-shadow:0 14px 34px rgba(35,57,93,.08); padding:1.25rem; margin-bottom:2rem; }
        .filter-shell { background:#fff; border:1px solid var(--vw-card-border); border-radius:16px; padding:1rem; }
        .table thead th { background:#edf4fb; color:var(--vw-brand-dark); }
        .status-pill { border-radius:999px; font-weight:800; }
    </style>
</head>
<body>
<?php render_admin_nav('financial'); ?>
<?php render_school_page_header($schoolName, $schoolLogo); ?>
<div class="container pb-5">
    <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-4">
        <div>
            <h2 class="fw-bold mb-1"><i class="fas fa-tags me-2"></i>Finance Adjustment Review</h2>
            <p class="text-muted mb-0">Review voucher, subsidy, discount, and grant shortcuts applied through Manage Finance Exceptions.</p>
        </div>
        <div class="d-flex gap-2 flex-wrap">
            <a href="../settings/settings-finance-adjustments.php" class="btn btn-outline-primary"><i class="fas fa-gear me-1"></i>Template Settings</a>
            <a href="fee-list.php" class="btn btn-outline-secondary"><i class="fas fa-arrow-left me-1"></i>Back to Fees</a>
        </div>
    </div>

    <?php if (!$tablesReady): ?>
        <div class="alert alert-warning">Finance adjustment schema is not ready. Run the migration tool first.</div>
    <?php else: ?>
        <form method="get" class="filter-shell mb-4">
            <div class="row g-2">
                <div class="col-md-3">
                    <input type="text" name="keyword" class="form-control" placeholder="Search student, template, user" value="<?= htmlspecialchars($filterKeyword) ?>">
                </div>
                <div class="col-md-3">
                    <select name="school_year" class="form-select">
                        <option value="">All School Years</option>
                        <?php foreach ($schoolYearOptions as $schoolYear): ?>
                            <option value="<?= htmlspecialchars($schoolYear) ?>" <?= $filterSchoolYear === $schoolYear ? 'selected' : '' ?>><?= htmlspecialchars($schoolYear) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="adjustment_type" class="form-select">
                        <option value="">All Types</option>
                        <?php foreach (finance_adjustment_types() as $value => $label): ?>
                            <option value="<?= htmlspecialchars($value) ?>" <?= $filterType === $value ? 'selected' : '' ?>><?= htmlspecialchars($label) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="status" class="form-select">
                        <option value="">All Status</option>
                        <option value="applied" <?= $filterStatus === 'applied' ? 'selected' : '' ?>>Applied</option>
                        <option value="reverted" <?= $filterStatus === 'reverted' ? 'selected' : '' ?>>Reverted</option>
                    </select>
                </div>
                <div class="col-md-2 d-flex gap-2">
                    <button class="btn btn-primary w-100" type="submit">Apply</button>
                    <a href="finance-adjustment-review.php" class="btn btn-outline-secondary w-100">Reset</a>
                </div>
            </div>
        </form>

        <div class="main-card">
            <div class="table-responsive">
                <table class="table table-striped align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Grade</th>
                            <th>Template</th>
                            <th>Type</th>
                            <th>Status</th>
                            <th>Effect</th>
                            <th>School Year</th>
                            <th>Applied</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$rows): ?>
                            <tr><td colspan="9" class="text-center text-muted py-4">No finance adjustment records matched the current filters.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($rows as $row): ?>
                            <tr>
                                <td>
                                    <div class="fw-bold"><?= htmlspecialchars((string) ($row['student_name'] ?? '')) ?></div>
                                    <div class="small text-muted">Student ID: <?= (int) ($row['student_id'] ?? 0) ?></div>
                                </td>
                                <td><?= htmlspecialchars((string) ($row['grade'] ?? '')) ?></td>
                                <td><?= htmlspecialchars((string) ($row['name'] ?? 'Finance Adjustment')) ?></td>
                                <td><?= htmlspecialchars(finance_adjustment_types()[(string) ($row['adjustment_type'] ?? '')] ?? 'Adjustment') ?></td>
                                <td>
                                    <span class="badge <?= ($row['status'] ?? '') === 'applied' ? 'text-bg-success' : 'text-bg-secondary' ?> status-pill">
                                        <?= htmlspecialchars(ucfirst((string) ($row['status'] ?? ''))) ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="fw-bold">PHP <?= number_format((float) ($row['total_effect'] ?? 0), 2) ?></div>
                                    <div class="small text-muted"><?= number_format((int) ($row['affected_count'] ?? 0)) ?> fee row(s)</div>
                                </td>
                                <td><?= htmlspecialchars((string) ($row['school_year_label'] ?? '')) ?></td>
                                <td>
                                    <div class="fw-bold"><?= htmlspecialchars((string) ($row['applied_by'] ?? '')) ?></div>
                                    <div class="small text-muted"><?= !empty($row['applied_at']) ? htmlspecialchars(date('M j, Y g:i A', strtotime((string) $row['applied_at']))) : '' ?></div>
                                </td>
                                <td>
                                    <a href="../accounts/account-fee-exceptions.php?student_id=<?= (int) ($row['student_id'] ?? 0) ?>&school_year=<?= urlencode((string) ($row['school_year_label'] ?? '')) ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-arrow-up-right-from-square"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
