<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
include '../../config/database.php';
include '../../modules/settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');

if (!hasPermission($_SESSION['role'] ?? '', 'account_mgmt', 'add')) {
    admin_session_forbidden();
}

$username = $_SESSION['username'] ?? 'unknown';
$role = $_SESSION['role'] ?? '';
$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";

school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);

$school_year_options = school_year_filter_options($conn);
$active_school_year_label = school_year_get_active_label($conn);
$source_school_year = trim($_POST['source_school_year'] ?? '');
$target_school_year = trim($_POST['target_school_year'] ?? $active_school_year_label);
$preview = null;
$result = null;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!school_year_verify_csrf($_POST['csrf_token'] ?? null)) {
        $error = 'Invalid request token. Please refresh the page and try again.';
    } else {
        $action_type = $_POST['action_type'] ?? 'preview';

        if ($action_type === 'preview') {
            $preview = school_year_fee_copy_preview($conn, $source_school_year, $target_school_year);
            if (!($preview['success'] ?? false)) {
                $error = $preview['message'] ?? 'Unable to preview fee copy.';
            }
        } elseif ($action_type === 'copy') {
            $preview = school_year_fee_copy_preview($conn, $source_school_year, $target_school_year);
            if (!($preview['success'] ?? false)) {
                $error = $preview['message'] ?? 'Unable to prepare fee copy.';
            } else {
                $result = school_year_copy_fee_setup($conn, $source_school_year, $target_school_year);
                if (!($result['success'] ?? false)) {
                    $error = $result['message'] ?? 'Fee copy failed.';
                } else {
                    $details = 'Role: ' . ($role ?: 'unknown')
                        . ' | Source School Year: ' . $source_school_year
                        . ' | Target School Year: ' . $target_school_year
                        . ' | Source Rows: ' . (int) ($preview['source_count'] ?? 0)
                        . ' | Copied: ' . (int) ($result['copied_count'] ?? 0)
                        . ' | Skipped: ' . (int) ($result['skipped_count'] ?? 0);
                    audit_log($conn, $username, 'Copied fee setup between school years', 'Fees', $details);
                }
            }
        }
    }
}

$csrf_token = school_year_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Copy School Year Fees | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body {
            background: var(--main-bg);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        }
        .navbar {
            background: var(--navbar-bg) !important;
            box-shadow: 0 2px 12px rgba(33,57,93,0.08);
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.08em;
        }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .theme-toggle-btn {
            background: none;
            border: none;
            color: #fff;
            font-size: 1.45em;
            margin-left: 12px;
            cursor: pointer;
        }
        .dashboard-header {
            text-align: center;
            margin-top: 36px;
            margin-bottom: 18px;
        }
        .dashboard-header img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            margin-bottom: 6px;
        }
        .dashboard-header h1 {
            font-size: 1.3rem;
            color: var(--brand-dark);
            font-weight: 700;
            margin-bottom: 0;
            letter-spacing: 0.02em;
        }
        .main-card {
            background: var(--card-bg);
            border-radius: 1rem;
            box-shadow: 0 4px 18px rgba(33,57,93,0.09), 0 1.5px 3px rgba(33,57,93,0.07);
            margin: 0 auto 32px;
            padding: 2.2rem 2.5rem 2.3rem;
            max-width: 980px;
        }
        .section-title {
            font-size: 1.23rem;
            font-weight: 700;
            color: #23395d;
            margin-bottom: 1.1rem;
            letter-spacing: 0.04em;
        }
        .stat-card {
            border: 1px solid #d9e6f5;
            border-radius: 14px;
            background: #f9fbfe;
            padding: 1rem 1.1rem;
            height: 100%;
        }
        .stat-label {
            font-size: 0.86rem;
            color: #61738a;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .stat-value {
            font-size: 1.55rem;
            font-weight: 700;
            color: #23395d;
        }
        .helper-note {
            border-left: 4px solid #517fa4;
            background: #eef5fd;
            padding: 0.9rem 1rem;
            border-radius: 10px;
            color: #32465e;
        }
        .btn-primary {
            background: #517fa4;
            border-color: #517fa4;
            font-weight: 500;
            border-radius: 7px;
        }
        .btn-primary:hover, .btn-primary:focus {
            background: #23395d;
            border-color: #23395d;
        }
        .btn-light {
            background: #e7f0fd;
            color: #23395d;
            border: 1px solid #bcdfff;
            font-weight: 500;
            border-radius: 7px;
        }
        .btn-light:hover, .btn-light:focus {
            background: #517fa4;
            color: #fff;
            border-color: #517fa4;
        }
        /* View Wave 6: legacy detail polish */
        :root {
            --vw-page-bg:#eef3f9;
            --vw-card-bg:#ffffff;
            --vw-card-border:#d9e3ef;
            --vw-brand-dark:#23395d;
            --vw-brand-mid:#517fa4;
            --vw-brand-soft:#edf4fb;
            --vw-text-soft:#5f7186;
        }
        body {
            background:
                radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 30%),
                linear-gradient(180deg, #f8fbff 0%, var(--vw-page-bg) 100%);
            color: var(--vw-brand-dark);
        }
        .dashboard-header img {
            width:72px;
            height:72px;
            border-radius:18px;
            background:#fff;
            padding:6px;
            box-shadow:0 10px 25px rgba(35,57,93,0.12);
        }
        .dashboard-header h1 { font-weight:800; }
        .main-card {
            background:var(--vw-card-bg);
            border:1px solid var(--vw-card-border);
            border-radius:20px;
            box-shadow:0 14px 32px rgba(35,57,93,0.07);
        }
        .section-title { font-weight:800; }
        .stat-card, .helper-note {
            border:1px solid var(--vw-card-border);
            border-radius:18px;
            box-shadow:0 10px 24px rgba(35,57,93,0.06);
        }
        .stat-card { background:#fff; }
        .helper-note {
            border-left:none;
            background:#f8fbff;
            color:var(--vw-text-soft);
        }
        .form-control, .form-select {
            border-color:#d7e1ed;
            min-height:44px;
            box-shadow:none;
        }
    </style>
</head>
<body>
<?php render_admin_nav('fees', true); ?>

<div class="dashboard-header">
    <img src="/school-admin-dashboard/uploads/logo1.png" alt="School Logo" class="mb-2 rounded shadow-sm">
    <h1><?= htmlspecialchars($schoolName) ?></h1>
</div>

<div class="container main-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
        <div class="section-title mb-0">
            <i class="fas fa-copy"></i> Copy Previous School Year Fees
        </div>
        <a href="/school-admin-dashboard/modules/financial/fee-list.php" class="btn btn-light">
            <i class="fas fa-arrow-left"></i> Back to Fees
        </a>
    </div>

    <div class="helper-note mb-4">
        Use this when a new school year mostly follows the previous fee setup. The copy keeps the same fee type, grade, amount, and notes, then saves them under the target school year. Existing target duplicates are skipped safely.
    </div>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($result && ($result['success'] ?? false)): ?>
        <div class="alert alert-success">
            Fee copy completed. Copied <?= number_format((int) ($result['copied_count'] ?? 0)) ?> fee setup(s) and skipped
            <?= number_format((int) ($result['skipped_count'] ?? 0)) ?> existing duplicate(s).
        </div>
    <?php endif; ?>

    <form method="post" class="row g-3 align-items-end mb-4">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
        <div class="col-md-5">
            <label for="source_school_year" class="form-label fw-semibold">Source School Year</label>
            <select name="source_school_year" id="source_school_year" class="form-select" required>
                <option value="">Select source year</option>
                <?php foreach ($school_year_options as $option): ?>
                    <option value="<?= htmlspecialchars($option) ?>" <?= $source_school_year === $option ? 'selected' : '' ?>>
                        <?= htmlspecialchars($option) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-5">
            <label for="target_school_year" class="form-label fw-semibold">Target School Year</label>
            <select name="target_school_year" id="target_school_year" class="form-select" required>
                <option value="">Select target year</option>
                <?php foreach ($school_year_options as $option): ?>
                    <option value="<?= htmlspecialchars($option) ?>" <?= $target_school_year === $option ? 'selected' : '' ?>>
                        <?= htmlspecialchars($option) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-2 d-grid">
            <button type="submit" name="action_type" value="preview" class="btn btn-light">
                <i class="fas fa-eye"></i> Preview
            </button>
        </div>
        <?php if ($preview && ($preview['success'] ?? false)): ?>
            <div class="col-12 d-grid d-md-flex justify-content-md-end">
                <button type="submit" name="action_type" value="copy" class="btn btn-primary" onclick="return confirm('Copy the fee setup to the selected school year?');">
                    <i class="fas fa-copy"></i> Copy Fee Setup
                </button>
            </div>
        <?php endif; ?>
    </form>

    <div class="row g-3">
        <div class="col-md-3">
            <div class="stat-card">
                <div class="stat-label">Active Year</div>
                <div class="stat-value" style="font-size:1.05rem;"><?= htmlspecialchars($active_school_year_label) ?></div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <div class="stat-label">Source Fees</div>
                <div class="stat-value"><?= number_format((int) ($preview['source_count'] ?? 0)) ?></div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <div class="stat-label">Already in Target</div>
                <div class="stat-value"><?= number_format((int) ($preview['duplicate_count'] ?? 0)) ?></div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <div class="stat-label">Ready to Copy</div>
                <div class="stat-value"><?= number_format((int) ($preview['copyable_count'] ?? 0)) ?></div>
            </div>
        </div>
    </div>

    <?php if ($preview && ($preview['success'] ?? false)): ?>
        <div class="card mt-4">
            <div class="card-header bg-secondary text-light">
                <i class="fas fa-circle-info"></i> Preview Summary
            </div>
            <div class="card-body">
                <p class="mb-2"><strong>From:</strong> <?= htmlspecialchars($source_school_year) ?></p>
                <p class="mb-2"><strong>To:</strong> <?= htmlspecialchars($target_school_year) ?></p>
                <p class="mb-2"><strong>Source fee rows:</strong> <?= number_format((int) ($preview['source_count'] ?? 0)) ?></p>
                <p class="mb-2"><strong>Existing target duplicates:</strong> <?= number_format((int) ($preview['duplicate_count'] ?? 0)) ?></p>
                <p class="mb-0"><strong>Copyable rows:</strong> <?= number_format((int) ($preview['copyable_count'] ?? 0)) ?></p>
            </div>
        </div>
    <?php endif; ?>
</div>

<footer class="text-center py-4 text-muted small">
    &copy; <?= date("Y") ?> <?= htmlspecialchars($schoolName) ?> | School Admin Dashboard
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('themeToggleBtn').addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        this.querySelector('i').classList.toggle('fa-moon');
        this.querySelector('i').classList.toggle('fa-sun');
    });
</script>
</body>
</html>
<?php $conn->close(); ?>
