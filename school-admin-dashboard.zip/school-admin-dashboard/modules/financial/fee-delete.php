<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
include '../../config/database.php';
include '../../modules/settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/settings-security.php';
require_once __DIR__ . '/../settings/fee-grade-settings-helper.php';
require_once __DIR__ . '/fee-behavior-helper.php';
require_once __DIR__ . '/fee-lock-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

if (!hasPermission($_SESSION['role'], 'account_mgmt', 'delete')) {
    admin_session_forbidden();
}

fee_behavior_ensure_column($conn);
fee_lock_ensure_table($conn);
$gradeNames = fee_grade_label_map($conn, true);
ensure_csrf_token();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';
$fee = null;

if ($id <= 0) {
    header("Location: fee-list.php");
    exit();
}

$feeStmt = $conn->prepare("
    SELECT
        f.id,
        at.name AS fee_type,
        f.grade_level,
        f.amount,
        f.notes,
        f.school_year_label,
        f.application_mode
    FROM fee f
    INNER JOIN account_types at ON f.fee_type_id = at.id
    WHERE f.id = ?
    LIMIT 1
");
$feeStmt->bind_param("i", $id);
$feeStmt->execute();
$result = $feeStmt->get_result();
$fee = $result ? $result->fetch_assoc() : null;
$feeStmt->close();

if (!$fee) {
    header("Location: fee-list.php?error=notfound");
    exit();
}

$feeSchoolYearLabel = (string) (($fee['school_year_label'] ?? '') !== '' ? $fee['school_year_label'] : '');
$feeGradeLevel = (int) ($fee['grade_level'] ?? 0);
$feeScopeLocked = $feeSchoolYearLabel !== '' && $feeGradeLevel > 0
    ? fee_lock_scope_is_locked(fee_lock_fetch_map($conn), $feeSchoolYearLabel, $feeGradeLevel)
    : false;
if ($feeScopeLocked) {
    $lockedGradeName = $gradeNames[$feeGradeLevel] ?? ('Grade ' . $feeGradeLevel);
    $error = "This fee scope is locked for {$lockedGradeName} under {$feeSchoolYearLabel}. Unlock the fee scope first before deleting this fee.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$feeScopeLocked) {
    admin_require_post_csrf();
    $postedId = (int) ($_POST['id'] ?? 0);

    if ($postedId !== (int) $fee['id']) {
        $error = 'Invalid delete request.';
    } elseif (!isset($_POST['confirm_delete'])) {
        header("Location: fee-list.php");
        exit();
    } else {
        $stmt = $conn->prepare("DELETE FROM fee WHERE id=?");
        $stmt->bind_param("i", $fee['id']);
        $stmt->execute();
        $deletedRows = $stmt->affected_rows;
        $stmt->close();

        if ($deletedRows > 0) {
            $user = $_SESSION['username'] ?? 'unknown';
            $gradeLevel = (int) ($fee['grade_level'] ?? 0);
            $gradeName = $gradeNames[$gradeLevel] ?? ('Grade ' . $gradeLevel);
            $details = "Role: " . ($_SESSION['role'] ?? 'unknown')
                . " | FeeType: " . ($fee['fee_type'] !== '' ? $fee['fee_type'] : 'Unknown')
                . " | Grade: " . $gradeName
                . " | SchoolYear: " . (($fee['school_year_label'] ?? '') !== '' ? $fee['school_year_label'] : 'Unassigned')
                . " | Amount: " . number_format((float) ($fee['amount'] ?? 0), 2, '.', '')
                . " | Mode: " . fee_behavior_label((string) ($fee['application_mode'] ?? 'required'))
                . " | Note: " . (($fee['notes'] ?? '') !== '' ? $fee['notes'] : 'None');
            audit_log($conn, $user, 'Deleted fee template', 'Fees', $details);
        }

        header("Location: fee-list.php?deleted=1");
        exit();
    }
}

$gradeLevel = (int) ($fee['grade_level'] ?? 0);
$gradeName = $gradeNames[$gradeLevel] ?? ('Grade ' . $gradeLevel);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Fee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="mt-5 mb-3">
        <h3><i class="fas fa-trash"></i> Delete Fee Template</h3>
        <hr>
        <?php if ($error !== ''): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <div class="alert alert-danger">
            <strong>Warning:</strong> This action is irreversible and will permanently delete this fee template.
            <br><br>
            Fee Type: <strong><?= htmlspecialchars((string) $fee['fee_type']) ?></strong><br>
            Grade: <strong><?= htmlspecialchars($gradeName) ?></strong><br>
            School Year: <strong><?= htmlspecialchars((string) (($fee['school_year_label'] ?? '') !== '' ? $fee['school_year_label'] : 'Unassigned')) ?></strong><br>
            Amount: <strong>PHP <?= htmlspecialchars(number_format((float) ($fee['amount'] ?? 0), 2)) ?></strong><br>
            Mode: <strong><?= htmlspecialchars(fee_behavior_label((string) ($fee['application_mode'] ?? 'required'))) ?></strong>
        </div>
        <?php if ($feeScopeLocked): ?>
            <a href="fee-list.php" class="btn btn-secondary">Back to Fees</a>
        <?php else: ?>
            <form method="post">
                <?= csrf_input() ?>
                <input type="hidden" name="id" value="<?= (int) $fee['id'] ?>">
                <button type="submit" name="confirm_delete" class="btn btn-danger">
                    <i class="fas fa-trash"></i> Yes, Delete Permanently
                </button>
                <a href="fee-list.php" class="btn btn-secondary ms-2">Cancel</a>
            </form>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
