<?php

require_once __DIR__ . '/../../includes/schema-migration.php';

function fee_behavior_modes(): array
{
    return [
        'required' => 'Required',
        'optional' => 'Optional',
        'conditional' => 'Conditional',
    ];
}

function fee_behavior_ensure_column(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }
    $result = $conn->query("SHOW COLUMNS FROM fee LIKE 'application_mode'");
    $exists = $result && $result->num_rows > 0;
    if ($result) {
        $result->close();
    }

    if (!$exists) {
        schema_migration_attempt($conn, "ALTER TABLE fee ADD COLUMN application_mode ENUM('required','optional','conditional') NOT NULL DEFAULT 'required' AFTER school_year_label");
    }
}

function fee_behavior_normalize(string $mode): string
{
    $mode = trim($mode);
    return array_key_exists($mode, fee_behavior_modes()) ? $mode : 'required';
}

function fee_behavior_label(string $mode): string
{
    $mode = fee_behavior_normalize($mode);
    return fee_behavior_modes()[$mode];
}

