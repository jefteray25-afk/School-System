<?php
require __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/student-search-helper.php';

header('Content-Type: application/json; charset=UTF-8');
student_search_portal_security_headers(true);

if (!student_search_portal_allow_request('search', 60, 60)) {
    http_response_code(429);
    echo json_encode(['success' => false, 'message' => 'Please wait a moment before searching again.']);
    exit;
}

$query = trim((string) ($_GET['q'] ?? ''));
$schoolYear = student_search_portal_active_year($conn);

try {
    echo json_encode([
        'success' => true,
        'school_year' => $schoolYear,
        'results' => student_search_portal_search($conn, $query, $schoolYear),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'The search service is temporarily unavailable.']);
}
