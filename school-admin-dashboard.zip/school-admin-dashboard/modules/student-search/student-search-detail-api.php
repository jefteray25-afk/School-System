<?php
require __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/student-search-helper.php';

header('Content-Type: application/json; charset=UTF-8');
student_search_portal_security_headers(true);

if (!student_search_portal_allow_request('detail', 90, 60)) {
    http_response_code(429);
    echo json_encode(['success' => false, 'message' => 'Please wait a moment before opening another record.']);
    exit;
}

$studentId = (int) ($_GET['id'] ?? 0);
$schoolYear = student_search_portal_active_year($conn);

try {
    $student = student_search_portal_student($conn, $studentId, $schoolYear);
    if ($student === null) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Student record was not found in the active school year.']);
        exit;
    }

    echo json_encode(['success' => true, 'student' => $student], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'The student record could not be loaded.']);
}
