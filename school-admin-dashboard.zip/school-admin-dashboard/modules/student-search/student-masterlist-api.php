<?php
require __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/student-search-helper.php';

header('Content-Type: application/json; charset=UTF-8');
student_search_portal_security_headers(true);

if (!student_search_portal_allow_request('masterlist', 60, 60)) {
    http_response_code(429);
    echo json_encode(['success' => false, 'message' => 'Please wait a moment before browsing again.']);
    exit;
}

$mode = (string) ($_GET['mode'] ?? '');
$level = trim((string) ($_GET['level'] ?? ''));
$grade = trim((string) ($_GET['grade'] ?? ''));
$section = trim((string) ($_GET['section'] ?? ''));
$schoolYear = student_search_portal_active_year($conn);

try {
    $payload = ['success' => true, 'school_year' => $schoolYear];
    if ($mode === 'grades' && in_array($level, ['Junior', 'Elementary', 'Junior High', 'Senior High'], true)) {
        $payload['items'] = student_search_portal_masterlist_grades($conn, $schoolYear, $level);
    } elseif ($mode === 'sections' && $grade !== '') {
        $payload['items'] = student_search_portal_masterlist_sections($conn, $schoolYear, $grade);
    } elseif ($mode === 'students' && $grade !== '' && $section !== '') {
        $payload['items'] = student_search_portal_masterlist_students($conn, $schoolYear, $grade, $section);
    } else {
        http_response_code(400);
        $payload = ['success' => false, 'message' => 'Invalid masterlist request.'];
    }
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'The masterlist service is temporarily unavailable.']);
}
