<?php
/**
 * Public, read-only photo response for the Student Search Portal.
 * It deliberately resolves a photo only through an active-school-year student ID;
 * unlike the Registrar endpoint, it never accepts a caller-supplied filesystem path.
 */

require __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/student-search-helper.php';

student_search_portal_security_headers(true);

$studentId = (int) ($_GET['id'] ?? 0);
$schoolYear = student_search_portal_active_year($conn);
if ($studentId <= 0 || $schoolYear === '') {
    http_response_code(404);
    exit;
}

$stmt = $conn->prepare("SELECT photo FROM students WHERE id = ? AND school_year_label = ? AND TRIM(COALESCE(photo, '')) <> '' LIMIT 1");
if (!$stmt) {
    http_response_code(404);
    exit;
}
$stmt->bind_param('is', $studentId, $schoolYear);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc() ?: null;
$stmt->close();

$absolutePath = student_photo_absolute_path($conn, (string) ($row['photo'] ?? ''));
if ($absolutePath === '' || !is_file($absolutePath)) {
    http_response_code(404);
    exit;
}

$extension = strtolower((string) pathinfo($absolutePath, PATHINFO_EXTENSION));
$mime = match ($extension) {
    'jpg', 'jpeg' => 'image/jpeg',
    'png' => 'image/png',
    'gif' => 'image/gif',
    default => '',
};
if ($mime === '') {
    http_response_code(404);
    exit;
}

header('Content-Type: ' . $mime);
header('Content-Length: ' . (string) filesize($absolutePath));
header('Content-Disposition: inline; filename="student-photo.' . $extension . '"');
header('Cache-Control: no-store, private, max-age=0');
readfile($absolutePath);
exit;
