<?php
/**
 * Read-only data access for the public/kiosk Student Search Portal.
 * This module intentionally never creates, edits, or deletes student records.
 */

require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/../settings/upload-storage-helper.php';
require_once __DIR__ . '/../settings/section-location-helper.php';

function student_search_portal_text(string $value): string
{
    return trim((string) preg_replace('/\s+/', ' ', $value));
}

function student_search_portal_security_headers(bool $isApi = false): void
{
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: same-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()');
    header('Cache-Control: no-store, private, max-age=0');

    if (!$isApi) {
        header("Content-Security-Policy: default-src 'self'; connect-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; font-src 'self' data: https://cdnjs.cloudflare.com; script-src 'self' 'unsafe-inline'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'");
    }
}

function student_search_portal_allow_request(string $bucket, int $maximum = 60, int $windowSeconds = 60): bool
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_name('tlwaci_search_kiosk');
        session_start();
    }

    $key = 'student_search_rate_' . preg_replace('/[^a-z0-9_]/i', '', $bucket);
    $now = time();
    $entries = $_SESSION[$key] ?? [];
    if (!is_array($entries)) {
        $entries = [];
    }
    $entries = array_values(array_filter($entries, static fn($timestamp): bool => is_int($timestamp) && $timestamp > ($now - $windowSeconds)));
    if (count($entries) >= $maximum) {
        $_SESSION[$key] = $entries;
        return false;
    }
    $entries[] = $now;
    $_SESSION[$key] = $entries;
    return true;
}

function student_search_portal_active_year(mysqli $conn): string
{
    return school_year_get_active_label($conn);
}

function student_search_portal_display_name(array $student): string
{
    $parts = [
        trim((string) ($student['firstname'] ?? '')),
        trim((string) ($student['middlename'] ?? '')),
        trim((string) ($student['lastname'] ?? '')),
    ];

    return trim(implode(' ', array_filter($parts, static fn(string $part): bool => $part !== '')));
}

function student_search_portal_public_photo(int $studentId, ?string $relativePath): string
{
    $path = trim((string) $relativePath);
    if ($studentId <= 0 || $path === '') {
        return '';
    }

    return '/school-admin-dashboard/modules/student-search/student-search-photo.php?id=' . $studentId;
}

function student_search_portal_search(mysqli $conn, string $query, string $schoolYear, int $limit = 12): array
{
    $query = student_search_portal_text($query);
    $limit = max(1, min(20, $limit));
    if (mb_strlen($query) < 2 || $schoolYear === '') {
        return [];
    }

    $sql = "SELECT id, lastname, firstname, middlename, grade, strand, section, school_year_label, photo
        FROM students
        WHERE school_year_label = ?";
    $types = 's';
    $params = [$schoolYear];

    $digits = preg_replace('/\D+/', '', $query);
    if ($digits !== '' && $digits === $query) {
        // LRN and the current system's internal student ID are exact-only lookups.
        $sql .= " AND (lrn = ? OR CAST(id AS CHAR) = ?)";
        $types .= 'ss';
        $params[] = $digits;
        $params[] = $digits;
    } else {
        $like = '%' . $query . '%';
        $sql .= " AND (CONCAT_WS(' ', firstname, middlename, lastname) LIKE ?
                    OR CONCAT_WS(' ', lastname, firstname, middlename) LIKE ?)";
        $types .= 'ss';
        $params[] = $like;
        $params[] = $like;
    }

    $sql .= ' ORDER BY lastname ASC, firstname ASC, middlename ASC LIMIT ' . $limit;
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return [];
    }
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = [
            'id' => (int) ($row['id'] ?? 0),
            'name' => student_search_portal_display_name($row),
            'grade' => (string) ($row['grade'] ?? ''),
            'section' => (string) ($row['section'] ?? ''),
            'photo_url' => student_search_portal_public_photo((int) ($row['id'] ?? 0), $row['photo'] ?? ''),
        ];
    }
    $stmt->close();
    return $rows;
}

function student_search_portal_student(mysqli $conn, int $studentId, string $schoolYear): ?array
{
    if ($studentId <= 0 || $schoolYear === '') {
        return null;
    }

    $stmt = $conn->prepare("SELECT id, lastname, firstname, middlename, grade, strand, section, school_year_label, photo
        FROM students
        WHERE id = ? AND school_year_label = ?
        LIMIT 1");
    if (!$stmt) {
        return null;
    }
    $stmt->bind_param('is', $studentId, $schoolYear);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();
    if (!$row) {
        return null;
    }

    $assignment = section_location_get($conn, $schoolYear, (string) ($row['grade'] ?? ''), (string) ($row['section'] ?? ''));
    $locationParts = [];
    foreach (['building_name', 'floor_name', 'room_name'] as $field) {
        $value = trim((string) ($assignment[$field] ?? ''));
        if ($value !== '') {
            $locationParts[] = $value;
        }
    }
    return [
        'id' => (int) $row['id'],
        'name' => student_search_portal_display_name($row),
        'grade' => (string) ($row['grade'] ?? ''),
        'strand' => (string) ($row['strand'] ?? ''),
        'section' => (string) ($row['section'] ?? ''),
        'school_year' => (string) ($row['school_year_label'] ?? ''),
        'photo_url' => student_search_portal_public_photo((int) ($row['id'] ?? 0), $row['photo'] ?? ''),
        'status_label' => 'Current school year record',
        'adviser_name' => trim((string) ($assignment['adviser_name'] ?? '')),
        'location_label' => $locationParts ? implode(' · ', $locationParts) : 'Location details are not configured yet.',
    ];
}

function student_search_portal_level_for_grade(string $grade): string
{
    $grade = trim($grade);
    if (in_array($grade, ['Junior Kindergarten', 'Senior Kindergarten'], true)) {
        return 'Junior';
    }
    if (preg_match('/^Grade ([1-6])$/', $grade)) {
        return 'Elementary';
    }
    if (preg_match('/^Grade (?:[7-9]|10)$/', $grade)) {
        return 'Junior High';
    }
    if (preg_match('/^Grade (?:11|12)$/', $grade)) {
        return 'Senior High';
    }
    return '';
}

function student_search_portal_masterlist_grades(mysqli $conn, string $schoolYear, string $level): array
{
    $stmt = $conn->prepare("SELECT grade, COUNT(*) AS student_count FROM students
        WHERE school_year_label = ? AND TRIM(COALESCE(grade, '')) <> ''
        GROUP BY grade ORDER BY grade ASC");
    if (!$stmt) {
        return [];
    }
    $stmt->bind_param('s', $schoolYear);
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $grade = (string) ($row['grade'] ?? '');
        if (student_search_portal_level_for_grade($grade) === $level) {
            $rows[] = ['grade' => $grade, 'count' => (int) ($row['student_count'] ?? 0)];
        }
    }
    $stmt->close();
    usort($rows, static function (array $a, array $b): int {
        $order = ['Junior Kindergarten' => 1, 'Senior Kindergarten' => 2];
        $aValue = $order[$a['grade']] ?? (100 + (int) preg_replace('/\D+/', '', $a['grade']));
        $bValue = $order[$b['grade']] ?? (100 + (int) preg_replace('/\D+/', '', $b['grade']));
        return $aValue <=> $bValue;
    });
    return $rows;
}

function student_search_portal_masterlist_sections(mysqli $conn, string $schoolYear, string $grade): array
{
    $stmt = $conn->prepare("SELECT TRIM(COALESCE(section, '')) AS section_name, COUNT(*) AS student_count
        FROM students WHERE school_year_label = ? AND grade = ?
        GROUP BY TRIM(COALESCE(section, '')) ORDER BY section_name ASC");
    if (!$stmt) {
        return [];
    }
    $stmt->bind_param('ss', $schoolYear, $grade);
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $section = (string) ($row['section_name'] ?? '');
        $rows[] = [
            'section' => $section !== '' ? $section : 'Unassigned / No Section',
            'value' => $section !== '' ? $section : '__unassigned__',
            'count' => (int) ($row['student_count'] ?? 0),
        ];
    }
    $stmt->close();
    return $rows;
}

function student_search_portal_masterlist_students(mysqli $conn, string $schoolYear, string $grade, string $section): array
{
    $isUnassigned = $section === '__unassigned__';
    $sql = "SELECT id, lastname, firstname, middlename, grade, section, photo FROM students
        WHERE school_year_label = ? AND grade = ?";
    if ($isUnassigned) {
        $sql .= " AND TRIM(COALESCE(section, '')) = ''";
    } else {
        $sql .= ' AND section = ?';
    }
    $sql .= ' ORDER BY lastname ASC, firstname ASC, middlename ASC LIMIT 250';
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return [];
    }
    if ($isUnassigned) {
        $stmt->bind_param('ss', $schoolYear, $grade);
    } else {
        $stmt->bind_param('sss', $schoolYear, $grade, $section);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = [
            'id' => (int) ($row['id'] ?? 0),
            'name' => student_search_portal_display_name($row),
            'grade' => (string) ($row['grade'] ?? ''),
            'section' => (string) ($row['section'] ?? ''),
            'photo_url' => student_search_portal_public_photo((int) ($row['id'] ?? 0), $row['photo'] ?? ''),
        ];
    }
    $stmt->close();
    return $rows;
}
