# Audit Log Scope

## Authentication
- User login
- User logout
- Failed login attempts
- Password change

## Data Changes
- Add new student, teacher, staff, or user
- Edit student, teacher, staff, or user information
- Delete student, teacher, staff, or user
- Add, edit, delete payment records
- Add, edit, delete grades or academic records
- Bulk data import/export

## Role & Permission Management
- Add, edit, delete roles
- Assign or change user roles
- Update user permissions

## Access to Sensitive Modules
- Viewing or exporting confidential records (grades, payments, personal info)
- Accessing system settings or configuration pages

## System Changes
- Update system configuration (school year, grading policy, etc.)
- Database backup/restore
- System maintenance actions

## File Operations
- Upload/download files (receipts, reports, data imports, etc.)

## Other Security Events
- Multiple failed logins (possible brute force)
- Suspicious activity (e.g., mass deletes)

---

**How to use this scope:**
- Any time one of the above actions occurs, record it in the `audit_logs` table.
- The log entry should include: **who**, **what**, and **when**.
- Optionally, expand your log table to include: **module** and **details**.

---

**Next Step:**  
Standardize log messages for these actions and implement logging in your PHP modules.