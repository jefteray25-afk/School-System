<?php
/**
 * Audit Log Helper Functions
 * 
 * Usage:
 * - Use audit_log for generic logging with standardized message templates.
 * - Use specialized functions for common events (students, payments, exports, downloads, etc.).
 * - Supports log levels: INFO, WARNING, ERROR, SECURITY.
 * 
 * Table Structure (audit_logs):
 *   id INT AUTO_INCREMENT PRIMARY KEY
 *   user VARCHAR(64)
 *   action VARCHAR(255)
 *   module VARCHAR(64)
 *   details TEXT
 *   level VARCHAR(16) DEFAULT 'INFO'
 *   log_date DATETIME DEFAULT CURRENT_TIMESTAMP
 */

function audit_log($conn, $user, $action, $module = null, $details = null, $level = "INFO") {
    $sql = "INSERT INTO audit_logs (user, action";
    $params = "ss";
    $values = [$user, $action];

    if ($module !== null) {
        $sql .= ", module";
        $params .= "s";
        $values[] = $module;
    }
    if ($details !== null) {
        $sql .= ", details";
        $params .= "s";
        $values[] = $details;
    }
    $sql .= ", level, log_date) VALUES (" . implode(',', array_fill(0, count($values), '?')) . ", ?, NOW())";
    $params .= "s";
    $values[] = $level;

    $stmt = $conn->prepare($sql);
    if ($stmt === false) return false;

    $stmt->bind_param($params, ...$values);
    $success = $stmt->execute();
    $stmt->close();
    return $success;
}

// Student actions
function format_student_action_details($studentName, $actionType, $adminName) {
    $actionType = strtolower($actionType);
    if ($actionType === "added") {
        return "Student {$studentName} was added by {$adminName}";
    } elseif ($actionType === "edited") {
        return "{$studentName} was edited by {$adminName}";
    } elseif ($actionType === "deleted") {
        return "{$studentName} was deleted by {$adminName}";
    }
    return "{$studentName} was updated by {$adminName}";
}

function log_student_add($conn, $user, $studentName, $studentId = null) {
    $details = $studentId ? "Student ID: $studentId" : "";
    audit_log($conn, $user, "Added student: $studentName", "Students", $details, "INFO");
}

function log_student_edit($conn, $user, $studentName, $studentId = null) {
    $details = $studentId ? "Student ID: $studentId" : "";
    audit_log($conn, $user, "Edited student: $studentName", "Students", $details, "INFO");
}

// Payment actions (current accounts)
function log_payment_add($conn, $user, $studentName, $paymentId = null) {
    $details = $paymentId ? "Payment ID: $paymentId" : "";
    audit_log($conn, $user, "Added payment for $studentName", "Payments", $details, "INFO");
}

function log_payment_delete($conn, $user, $studentName, $paymentId = null) {
    $details = $paymentId ? "Payment ID: $paymentId" : "";
    audit_log($conn, $user, "Deleted payment for $studentName", "Payments", $details, "WARNING");
}

function log_payment_edit($conn, $user, $studentName, $paymentId = null) {
    $details = $paymentId ? "Payment ID: $paymentId" : "";
    audit_log($conn, $user, "Edited payment for $studentName", "Payments", $details, "INFO");
}

function log_payment_view($conn, $user, $studentName, $paymentId = null) {
    $details = $paymentId ? "Payment ID: $paymentId" : "";
    audit_log($conn, $user, "Viewed payment for $studentName", "Payments", $details, "INFO");
}

function log_payment_update($conn, $user, $studentName, $paymentId = null) {
    $details = $paymentId ? "Payment ID: $paymentId" : "";
    audit_log($conn, $user, "Updated payment for $studentName", "Payments", $details, "INFO");
}

// Payment history views (current accounts)
function log_payment_history_view($conn, $user, $studentName, $studentId = null) {
    $details = $studentId ? "Student ID: $studentId" : "";
    audit_log($conn, $user, "Viewed payment history for $studentName", "Payments", $details, "INFO");
}

// Old student payment actions
function log_old_payment_add($conn, $user, $studentName, $paymentId = null) {
    $details = $paymentId ? "Old Payment ID: $paymentId" : "";
    audit_log($conn, $user, "Added payment for old student $studentName", "Old Student Payments", $details, "INFO");
}

function log_old_payment_delete($conn, $user, $studentName, $paymentId = null) {
    $details = $paymentId ? "Old Payment ID: $paymentId" : "";
    audit_log($conn, $user, "Deleted payment for old student $studentName", "Old Student Payments", $details, "WARNING");
}

function log_old_payment_edit($conn, $user, $studentName, $paymentId = null) {
    $details = $paymentId ? "Old Payment ID: $paymentId" : "";
    audit_log($conn, $user, "Edited payment for old student $studentName", "Old Student Payments", $details, "INFO");
}

function log_old_payment_view($conn, $user, $studentName, $paymentId = null) {
    $details = $paymentId ? "Old Payment ID: $paymentId" : "";
    audit_log($conn, $user, "Viewed payment for old student $studentName", "Old Student Payments", $details, "INFO");
}

function log_old_payment_update($conn, $user, $studentName, $paymentId = null) {
    $details = $paymentId ? "Old Payment ID: $paymentId" : "";
    audit_log($conn, $user, "Updated payment for old student $studentName", "Old Student Payments", $details, "INFO");
}

// Old student payment history view
function log_old_payment_history_view($conn, $user, $studentName, $studentId = null) {
    $details = $studentId ? "Old Student ID: $studentId" : "";
    audit_log($conn, $user, "Viewed payment history for old student $studentName", "Old Student Payments", $details, "INFO");
}

// Failed login
function log_failed_login($conn, $username) {
    audit_log($conn, $username, "User failed to log in", "Authentication", "", "SECURITY");
}

// System config changes
function log_system_config_change($conn, $user, $setting, $oldValue, $newValue) {
    $details = "$setting ($oldValue → $newValue)";
    audit_log($conn, $user, "Updated system configuration: $details", "System Changes", $details, "INFO");
}

// Export actions
function log_data_export($conn, $user, $exportType, $fileName = null) {
    $details = $fileName ? "File: $fileName" : "";
    audit_log($conn, $user, "Exported data: $exportType", "Export", $details, "INFO");
}

// SQL backup exports
function log_sql_backup_export($conn, $user, $backupFileName) {
    $details = "Backup file: $backupFileName";
    audit_log($conn, $user, "Exported SQL backup", "Backup/Restore", $details, "INFO");
}

// Export downloads (NEW)
function log_export_download($conn, $user, $fileName, $exportType = null) {
    $details = "Downloaded file: $fileName";
    if ($exportType) {
        $details .= " | Type: $exportType";
    }
    audit_log($conn, $user, "Downloaded export file", "Export", $details, "INFO");
}

function audit_logs_index_exists(mysqli $conn, string $tableName, string $indexName): bool {
    $safeTable = $conn->real_escape_string($tableName);
    $safeIndex = $conn->real_escape_string($indexName);
    $sql = "SHOW INDEX FROM `{$safeTable}` WHERE Key_name = '{$safeIndex}'";
    $result = $conn->query($sql);
    if (!$result) {
        return false;
    }

    $exists = $result->num_rows > 0;
    $result->close();
    return $exists;
}

function audit_logs_ensure_performance_indexes(mysqli $conn): array {
    $expectedIndexes = [
        'idx_log_date' => 'CREATE INDEX idx_log_date ON audit_logs (log_date)',
        'idx_user' => 'CREATE INDEX idx_user ON audit_logs (user)',
        'idx_module' => 'CREATE INDEX idx_module ON audit_logs (module)',
        'idx_level' => 'CREATE INDEX idx_level ON audit_logs (level)',
    ];

    $created = [];
    $existing = [];
    $errors = [];

    foreach ($expectedIndexes as $indexName => $sql) {
        if (audit_logs_index_exists($conn, 'audit_logs', $indexName)) {
            $existing[] = $indexName;
            continue;
        }

        if ($conn->query($sql) === true) {
            $created[] = $indexName;
        } else {
            $errors[$indexName] = $conn->error;
        }
    }

    return [
        'expected' => array_keys($expectedIndexes),
        'existing' => $existing,
        'created' => $created,
        'errors' => $errors,
    ];
}

function audit_logs_performance_status(mysqli $conn): array {
    $requiredIndexes = ['idx_log_date', 'idx_user', 'idx_module', 'idx_level'];
    $installed = [];
    $missing = [];

    foreach ($requiredIndexes as $indexName) {
        if (audit_logs_index_exists($conn, 'audit_logs', $indexName)) {
            $installed[] = $indexName;
        } else {
            $missing[] = $indexName;
        }
    }

    $summary = [
        'total_logs' => 0,
        'oldest_log_at' => null,
        'latest_log_at' => null,
    ];

    $result = $conn->query("SELECT COUNT(*) AS total_logs, MIN(log_date) AS oldest_log_at, MAX(log_date) AS latest_log_at FROM audit_logs");
    if ($result) {
        $row = $result->fetch_assoc();
        if ($row) {
            $summary['total_logs'] = (int) ($row['total_logs'] ?? 0);
            $summary['oldest_log_at'] = $row['oldest_log_at'] ?? null;
            $summary['latest_log_at'] = $row['latest_log_at'] ?? null;
        }
        $result->close();
    }

    return [
        'installed' => $installed,
        'missing' => $missing,
        'installed_count' => count($installed),
        'required_count' => count($requiredIndexes),
        'is_ready' => empty($missing),
        'total_logs' => $summary['total_logs'],
        'oldest_log_at' => $summary['oldest_log_at'],
        'latest_log_at' => $summary['latest_log_at'],
    ];
}

function audit_archive_csrf_token(): string
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    if (empty($_SESSION['audit_archive_csrf_token'])) {
        $_SESSION['audit_archive_csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['audit_archive_csrf_token'];
}

function audit_archive_verify_csrf(?string $token): bool
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    $sessionToken = $_SESSION['audit_archive_csrf_token'] ?? '';
    return is_string($token) && $sessionToken !== '' && hash_equals($sessionToken, $token);
}

function audit_logs_ensure_archive_table(mysqli $conn): bool
{
    require_once __DIR__ . '/../../includes/schema-migration.php';
    if (!schema_migration_mode_enabled()) {
        return true;
    }

    $sql = "CREATE TABLE IF NOT EXISTS audit_logs_archive (
        id INT AUTO_INCREMENT PRIMARY KEY,
        source_log_id INT NOT NULL,
        user VARCHAR(64) DEFAULT NULL,
        action VARCHAR(255) NOT NULL,
        module VARCHAR(64) DEFAULT NULL,
        details TEXT DEFAULT NULL,
        level VARCHAR(16) NOT NULL DEFAULT 'INFO',
        log_date DATETIME NOT NULL,
        archived_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        archived_by VARCHAR(64) DEFAULT NULL,
        UNIQUE KEY uniq_source_log_id (source_log_id),
        KEY idx_archive_log_date (log_date),
        KEY idx_archive_archived_at (archived_at),
        KEY idx_archive_user (user),
        KEY idx_archive_module (module),
        KEY idx_archive_level (level)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    if (!schema_migration_attempt($conn, $sql)) {
        return false;
    }

    $columns = [];
    $result = $conn->query("SHOW COLUMNS FROM audit_logs_archive");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $columns[(string) ($row['Field'] ?? '')] = true;
        }
        $result->close();
    }

    if (!isset($columns['source_log_id'])) {
        if (!schema_migration_attempt($conn, "ALTER TABLE audit_logs_archive ADD COLUMN source_log_id INT NULL AFTER id")) {
            return false;
        }
        schema_migration_attempt($conn, "UPDATE audit_logs_archive SET source_log_id = id WHERE source_log_id IS NULL");
        if (!schema_migration_attempt($conn, "ALTER TABLE audit_logs_archive MODIFY COLUMN source_log_id INT NOT NULL")) {
            return false;
        }
    }

    if (!isset($columns['archived_at'])) {
        if (!schema_migration_attempt($conn, "ALTER TABLE audit_logs_archive ADD COLUMN archived_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER log_date")) {
            return false;
        }
    }

    if (!isset($columns['archived_by'])) {
        if (!schema_migration_attempt($conn, "ALTER TABLE audit_logs_archive ADD COLUMN archived_by VARCHAR(64) DEFAULT NULL AFTER archived_at")) {
            return false;
        }
    }

    $requiredIndexes = [
        'uniq_source_log_id' => 'ALTER TABLE audit_logs_archive ADD UNIQUE KEY uniq_source_log_id (source_log_id)',
        'idx_archive_log_date' => 'CREATE INDEX idx_archive_log_date ON audit_logs_archive (log_date)',
        'idx_archive_archived_at' => 'CREATE INDEX idx_archive_archived_at ON audit_logs_archive (archived_at)',
        'idx_archive_user' => 'CREATE INDEX idx_archive_user ON audit_logs_archive (user)',
        'idx_archive_module' => 'CREATE INDEX idx_archive_module ON audit_logs_archive (module)',
        'idx_archive_level' => 'CREATE INDEX idx_archive_level ON audit_logs_archive (level)',
    ];

    foreach ($requiredIndexes as $indexName => $indexSql) {
        if (!audit_logs_index_exists($conn, 'audit_logs_archive', $indexName)) {
            if (!schema_migration_attempt($conn, $indexSql)) {
                return false;
            }
        }
    }

    return true;
}

function audit_logs_archive_status(mysqli $conn, string $cutoffDate): array
{
    audit_logs_ensure_archive_table($conn);

    $status = [
        'main_total' => 0,
        'archive_total' => 0,
        'eligible_total' => 0,
        'eligible_oldest' => null,
        'eligible_latest' => null,
        'archive_latest' => null,
        'cutoff_date' => $cutoffDate,
    ];

    $mainResult = $conn->query("SELECT COUNT(*) AS total FROM audit_logs");
    if ($mainResult) {
        $status['main_total'] = (int) (($mainResult->fetch_assoc()['total'] ?? 0));
        $mainResult->close();
    }

    $archiveResult = $conn->query("SELECT COUNT(*) AS total, MAX(archived_at) AS archive_latest FROM audit_logs_archive");
    if ($archiveResult) {
        $row = $archiveResult->fetch_assoc();
        $status['archive_total'] = (int) (($row['total'] ?? 0));
        $status['archive_latest'] = $row['archive_latest'] ?? null;
        $archiveResult->close();
    }

    $stmt = $conn->prepare("SELECT COUNT(*) AS total, MIN(log_date) AS oldest_log, MAX(log_date) AS latest_log FROM audit_logs WHERE DATE(log_date) < ?");
    if ($stmt) {
        $stmt->bind_param('s', $cutoffDate);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result) {
            $row = $result->fetch_assoc();
            $status['eligible_total'] = (int) (($row['total'] ?? 0));
            $status['eligible_oldest'] = $row['oldest_log'] ?? null;
            $status['eligible_latest'] = $row['latest_log'] ?? null;
        }
        $stmt->close();
    }

    return $status;
}

function audit_logs_archive_before_date(mysqli $conn, string $cutoffDate, string $archivedBy): array
{
    $result = [
        'success' => false,
        'archived_rows' => 0,
        'deleted_rows' => 0,
        'message' => '',
    ];

    if (!audit_logs_ensure_archive_table($conn)) {
        $result['message'] = 'Unable to prepare audit archive table.';
        return $result;
    }

    $conn->begin_transaction();

    try {
        $insertSql = "INSERT IGNORE INTO audit_logs_archive
            (source_log_id, user, action, module, details, level, log_date, archived_at, archived_by)
            SELECT id, user, action, module, details, level, log_date, NOW(), ?
            FROM audit_logs
            WHERE DATE(log_date) < ?";
        $insertStmt = $conn->prepare($insertSql);
        if (!$insertStmt) {
            throw new RuntimeException('Unable to prepare audit archive insert.');
        }
        $insertStmt->bind_param('ss', $archivedBy, $cutoffDate);
        $insertStmt->execute();
        $result['archived_rows'] = $insertStmt->affected_rows;
        $insertStmt->close();

        $deleteSql = "DELETE a
            FROM audit_logs a
            INNER JOIN audit_logs_archive ar ON ar.source_log_id = a.id
            WHERE DATE(a.log_date) < ?";
        $deleteStmt = $conn->prepare($deleteSql);
        if (!$deleteStmt) {
            throw new RuntimeException('Unable to prepare audit archive delete.');
        }
        $deleteStmt->bind_param('s', $cutoffDate);
        $deleteStmt->execute();
        $result['deleted_rows'] = $deleteStmt->affected_rows;
        $deleteStmt->close();

        $conn->commit();
        $result['success'] = true;
        $result['message'] = "Archived {$result['deleted_rows']} audit log rows before {$cutoffDate}.";
        return $result;
    } catch (Throwable $e) {
        $conn->rollback();
        $result['message'] = $e->getMessage();
        return $result;
    }
}
