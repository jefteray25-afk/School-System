<?php

require_once __DIR__ . '/../../includes/schema-migration.php';

function audit_retention_default_values(): array
{
    return [
        'live_retention_months' => 12,
        'review_frequency' => 'Monthly',
        'archive_enabled' => 1,
        'archive_deletion_policy' => 'Keep Archive',
        'notes' => '',
    ];
}

function audit_retention_ensure_table(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }
    $sql = "CREATE TABLE IF NOT EXISTS audit_retention_settings (
        id TINYINT NOT NULL PRIMARY KEY,
        live_retention_months INT NOT NULL DEFAULT 12,
        review_frequency VARCHAR(32) NOT NULL DEFAULT 'Monthly',
        archive_enabled TINYINT(1) NOT NULL DEFAULT 1,
        archive_deletion_policy VARCHAR(32) NOT NULL DEFAULT 'Keep Archive',
        notes TEXT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    schema_migration_attempt($conn, $sql);

    $countResult = $conn->query("SELECT COUNT(*) AS total FROM audit_retention_settings");
    $count = $countResult ? (int) (($countResult->fetch_assoc()['total'] ?? 0)) : 0;
    if ($countResult) {
        $countResult->close();
    }

    if ($count === 0) {
        $defaults = audit_retention_default_values();
        $stmt = $conn->prepare(
            "INSERT INTO audit_retention_settings
            (id, live_retention_months, review_frequency, archive_enabled, archive_deletion_policy, notes)
            VALUES (1, ?, ?, ?, ?, ?)"
        );
        if ($stmt) {
            $stmt->bind_param(
                'isiss',
                $defaults['live_retention_months'],
                $defaults['review_frequency'],
                $defaults['archive_enabled'],
                $defaults['archive_deletion_policy'],
                $defaults['notes']
            );
            $stmt->execute();
            $stmt->close();
        }
    }
}

function audit_retention_get(mysqli $conn): array
{
    audit_retention_ensure_table($conn);
    $defaults = audit_retention_default_values();
    $result = $conn->query("SELECT * FROM audit_retention_settings WHERE id = 1 LIMIT 1");
    if ($result && $row = $result->fetch_assoc()) {
        $result->close();
        return [
            'live_retention_months' => max(1, min(60, (int) ($row['live_retention_months'] ?? $defaults['live_retention_months']))),
            'review_frequency' => (string) ($row['review_frequency'] ?? $defaults['review_frequency']),
            'archive_enabled' => (int) ($row['archive_enabled'] ?? $defaults['archive_enabled']),
            'archive_deletion_policy' => (string) ($row['archive_deletion_policy'] ?? $defaults['archive_deletion_policy']),
            'notes' => (string) ($row['notes'] ?? $defaults['notes']),
        ];
    }

    return $defaults;
}

function audit_retention_save(mysqli $conn, array $payload): bool
{
    audit_retention_ensure_table($conn);
    $months = max(1, min(60, (int) ($payload['live_retention_months'] ?? 12)));
    $reviewFrequency = trim((string) ($payload['review_frequency'] ?? 'Monthly'));
    if ($reviewFrequency === '') {
        $reviewFrequency = 'Monthly';
    }
    $archiveEnabled = !empty($payload['archive_enabled']) ? 1 : 0;
    $archiveDeletionPolicy = trim((string) ($payload['archive_deletion_policy'] ?? 'Keep Archive'));
    if ($archiveDeletionPolicy === '') {
        $archiveDeletionPolicy = 'Keep Archive';
    }
    $notes = trim((string) ($payload['notes'] ?? ''));

    $stmt = $conn->prepare(
        "UPDATE audit_retention_settings
         SET live_retention_months = ?, review_frequency = ?, archive_enabled = ?, archive_deletion_policy = ?, notes = ?
         WHERE id = 1"
    );
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('isiss', $months, $reviewFrequency, $archiveEnabled, $archiveDeletionPolicy, $notes);
    $success = $stmt->execute();
    $stmt->close();
    return $success;
}

function audit_retention_default_cutoff_date(mysqli $conn): string
{
    $settings = audit_retention_get($conn);
    $months = max(1, (int) ($settings['live_retention_months'] ?? 12));
    return date('Y-m-d', strtotime('-' . $months . ' months'));
}

function audit_retention_status(mysqli $conn): array
{
    $settings = audit_retention_get($conn);
    $cutoffDate = audit_retention_default_cutoff_date($conn);
    $status = [
        'cutoff_date' => $cutoffDate,
        'eligible_total' => 0,
        'oldest_live_log' => null,
        'latest_live_log' => null,
    ];

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM audit_logs WHERE DATE(log_date) < ?");
    if ($stmt) {
        $stmt->bind_param('s', $cutoffDate);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result) {
            $status['eligible_total'] = (int) (($result->fetch_assoc()['total'] ?? 0));
        }
        $stmt->close();
    }

    $result = $conn->query("SELECT MIN(log_date) AS oldest_live_log, MAX(log_date) AS latest_live_log FROM audit_logs");
    if ($result) {
        $row = $result->fetch_assoc();
        $status['oldest_live_log'] = $row['oldest_live_log'] ?? null;
        $status['latest_live_log'] = $row['latest_live_log'] ?? null;
        $result->close();
    }

    return array_merge($settings, $status);
}
