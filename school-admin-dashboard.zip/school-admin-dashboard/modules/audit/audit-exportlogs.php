<?php
require_once __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require '../../config/database.php';
include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');

$currentRole = $_SESSION['role'] ?? '';
if (!hasPermission($currentRole, 'audit_logs', 'view')) {
    admin_session_forbidden();
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    die('Unable to load audit export connection.');
}

$user = $_SESSION['username'] ?? 'unknown';
$filters = [
    'keyword' => trim((string) ($_GET['keyword'] ?? '')),
    'level' => trim((string) ($_GET['level'] ?? '')),
    'module' => trim((string) ($_GET['module'] ?? '')),
    'user' => trim((string) ($_GET['user'] ?? '')),
    'date_from' => trim((string) ($_GET['date_from'] ?? '')),
    'date_to' => trim((string) ($_GET['date_to'] ?? '')),
];

$whereClauses = [];
$params = [];
$types = '';

if ($filters['keyword'] !== '') {
    $keyword = '%' . $filters['keyword'] . '%';
    $whereClauses[] = '(action LIKE ? OR module LIKE ? OR details LIKE ? OR user LIKE ?)';
    $params[] = $keyword;
    $params[] = $keyword;
    $params[] = $keyword;
    $params[] = $keyword;
    $types .= 'ssss';
}

if ($filters['level'] !== '') {
    $whereClauses[] = 'level = ?';
    $params[] = $filters['level'];
    $types .= 's';
}

if ($filters['module'] !== '') {
    $whereClauses[] = 'module = ?';
    $params[] = $filters['module'];
    $types .= 's';
}

if ($filters['user'] !== '') {
    $whereClauses[] = 'user = ?';
    $params[] = $filters['user'];
    $types .= 's';
}

if ($filters['date_from'] !== '') {
    $whereClauses[] = 'DATE(log_date) >= ?';
    $params[] = $filters['date_from'];
    $types .= 's';
}

if ($filters['date_to'] !== '') {
    $whereClauses[] = 'DATE(log_date) <= ?';
    $params[] = $filters['date_to'];
    $types .= 's';
}

$whereSql = $whereClauses ? (' WHERE ' . implode(' AND ', $whereClauses)) : '';

// --- EXPORT AUDIT LOGS ---
$filename = "auditlogs_" . date("Ymd_His") . ".csv";
header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename=' . $filename);

$output = fopen('php://output', 'w');

// Write header row
fputcsv($output, array('ID', 'User', 'Action', 'Module', 'Details', 'Level', 'Date'));

// Query audit logs
$sql = "SELECT id, user, action, module, details, level, log_date
    FROM audit_logs{$whereSql}
    ORDER BY log_date DESC";
$stmt = $conn->prepare($sql);
if ($stmt) {
    if ($types !== '') {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $stmt->bind_result($id, $rowUser, $action, $module, $details, $level, $logDate);
    $auditLogs = [];
    $studentIdsToFetch = [];
    while ($stmt->fetch()) {
        $studentId = null;
        if (
            preg_match('/Accessed edit student page|Edited student/i', (string) $action) &&
            preg_match('/Student ID: (\d+)/', (string) $details, $matches)
        ) {
            $studentId = (int) $matches[1];
            $studentIdsToFetch[$studentId] = true;
        }

        if ($currentRole === 'Administrator') {
            $details = str_replace('Super Administrator', 'Administrator', (string) $details);
        }

        $auditLogs[] = [
            'id' => $id,
            'user' => $rowUser,
            'action' => $action,
            'module' => $module,
            'details' => $details,
            'level' => $level,
            'log_date' => $logDate,
            'student_id' => $studentId,
        ];
    }
    $stmt->close();

    $studentNames = [];
    if (!empty($studentIdsToFetch)) {
        $ids = array_values(array_unique(array_map('intval', array_keys($studentIdsToFetch))));
        foreach (array_chunk($ids, 500) as $chunk) {
            $placeholders = implode(',', array_fill(0, count($chunk), '?'));
            $types = str_repeat('i', count($chunk));
            $lookupSql = "SELECT id, lastname, firstname FROM students WHERE id IN ({$placeholders})";
            $lookupStmt = $conn->prepare($lookupSql);
            if (!$lookupStmt) {
                continue;
            }
            $lookupStmt->bind_param($types, ...$chunk);
            $lookupStmt->execute();
            $lookupResult = $lookupStmt->get_result();
            while ($row = $lookupResult->fetch_assoc()) {
                $studentNames[(int) $row['id']] = (string) $row['lastname'] . ', ' . (string) $row['firstname'];
            }
            $lookupStmt->close();
        }
    }

    foreach ($auditLogs as &$log) {
        if ($log['student_id'] && isset($studentNames[$log['student_id']])) {
            $log['details'] = preg_replace(
                '/Student ID: ' . $log['student_id'] . '/',
                'Student: ' . $studentNames[$log['student_id']],
                (string) $log['details']
            );
        }

        fputcsv($output, [
            $log['id'],
            $log['user'],
            $log['action'],
            $log['module'],
            $log['details'],
            $log['level'],
            $log['log_date'],
        ]);
    }
    unset($log);
}

// --- AUDIT LOGGING ---
// Log the export event (who exported what)
log_data_export($conn, $user, "Audit Logs", $filename);
// Log the download event (who downloaded the export file)
log_export_download($conn, $user, $filename, "Audit Logs");

fclose($output);
exit;
?>
