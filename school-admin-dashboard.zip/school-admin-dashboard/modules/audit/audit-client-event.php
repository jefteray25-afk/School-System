<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();

require __DIR__ . '/../../config/database.php';
require __DIR__ . '/../settings/settings-security.php';
require_once __DIR__ . '/audit-helper.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'message' => 'Method not allowed']);
    exit;
}

admin_require_post_csrf();

$user = $_SESSION['username'] ?? 'unknown';
$actionKind = trim((string) ($_POST['action_kind'] ?? ''));
$label = trim((string) ($_POST['label'] ?? ''));
$fileName = trim((string) ($_POST['file_name'] ?? ''));
$details = trim((string) ($_POST['details'] ?? ''));

switch ($actionKind) {
    case 'export_download':
        $exportLabel = $label !== '' ? $label : 'Client Export';
        log_data_export($conn, $user, $exportLabel, $fileName !== '' ? $fileName : null);
        log_export_download($conn, $user, $fileName !== '' ? $fileName : ($exportLabel . '.xlsx'), $exportLabel);
        break;

    case 'receipt_image_download':
        audit_log(
            $conn,
            $user,
            'Downloaded receipt image',
            'Receipts',
            $details !== '' ? $details : $label,
            'INFO'
        );
        break;

    case 'receipt_print':
        audit_log(
            $conn,
            $user,
            'Opened print dialog for receipt',
            'Receipts',
            $details !== '' ? $details : $label,
            'INFO'
        );
        break;

    default:
        http_response_code(400);
        echo json_encode(['ok' => false, 'message' => 'Unsupported audit action']);
        exit;
}

echo json_encode(['ok' => true]);
