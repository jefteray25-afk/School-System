<div class="card mb-4 shadow-sm border-0">
    <div class="card-header bg-info text-white">
        <h4 class="mb-0"><i class="fas fa-search me-2"></i>Audit Scope</h4>
    </div>
    <div class="card-body">
        <div class="row g-3 mb-3">
            <div class="col-12 col-md-6 col-xl-3">
                <div class="border rounded-3 p-3 h-100 bg-light">
                    <div class="text-uppercase small text-muted fw-semibold">What We Log</div>
                    <div class="fw-bold text-dark mt-1">System-changing actions</div>
                    <div class="small text-muted mt-2">Create, update, delete, approve, reject, archive, export, restore, and security events.</div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-xl-3">
                <div class="border rounded-3 p-3 h-100 bg-light">
                    <div class="text-uppercase small text-muted fw-semibold">What We Avoid</div>
                    <div class="fw-bold text-dark mt-1">Passive page visits</div>
                    <div class="small text-muted mt-2">Simple opens, tab switches, and non-saving clicks are excluded to keep audit logs usable.</div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-xl-3">
                <div class="border rounded-3 p-3 h-100 bg-light">
                    <div class="text-uppercase small text-muted fw-semibold">Live Table Rule</div>
                    <div class="fw-bold text-dark mt-1">Keep recent history fast</div>
                    <div class="small text-muted mt-2">Recent logs stay in <code>audit_logs</code> so filters, paging, and summaries remain responsive.</div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-xl-3">
                <div class="border rounded-3 p-3 h-100 bg-light">
                    <div class="text-uppercase small text-muted fw-semibold">Archive Rule</div>
                    <div class="fw-bold text-dark mt-1">Move older logs safely</div>
                    <div class="small text-muted mt-2">Older rows move into <code>audit_logs_archive</code> and remain searchable in the archive viewer.</div>
                </div>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-12 col-lg-6">
                <div class="card h-100 border-0 bg-light-subtle">
                    <div class="card-body">
                        <div class="text-uppercase small text-muted fw-semibold mb-2">Included In Audit Logging</div>
                        <ul class="mb-0">
                            <li>Login success, failed login, logout, and permission-sensitive security events</li>
                            <li>Student add, edit, delete, bulk delete, and registration approval or rejection</li>
                            <li>Student requirement updates that save changes</li>
                            <li>Current account payments, other payments, old-account payments, and payment deletions</li>
                            <li>Fee copy, fee sync, school year changes, duplicate cleanup, receipt registry actions, and backups or exports</li>
                            <li>Manual audit archive actions and related audit maintenance steps</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div class="card h-100 border-0 bg-light-subtle">
                    <div class="card-body">
                        <div class="text-uppercase small text-muted fw-semibold mb-2">Excluded From Audit Logging</div>
                        <ul class="mb-0">
                            <li>Simple list-page opens that do not change data</li>
                            <li>Student, account, and old-account viewing only</li>
                            <li>Receipt preview or non-saving inspection actions</li>
                            <li>Filter changes, table navigation, and passive UI clicks</li>
                            <li>Other no-save actions that would add noise without accountability value</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mt-3 border-0 bg-white shadow-sm">
            <div class="card-body">
                <div class="text-uppercase small text-muted fw-semibold mb-2">Current Audit Policy</div>
                <div class="small text-muted mb-2">The system uses a practical audit standard:</div>
                <ol class="mb-0">
                    <li>Log actions that change records, permissions, receipts, finance state, or exported files.</li>
                    <li>Do not flood the log with passive navigation events.</li>
                    <li>Keep the live audit table optimized with indexes and archive older data when needed.</li>
                    <li>Use the archive viewer for historical checks instead of keeping everything in the live table.</li>
                </ol>
            </div>
        </div>
    </div>
</div>
