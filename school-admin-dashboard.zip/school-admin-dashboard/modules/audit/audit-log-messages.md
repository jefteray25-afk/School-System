# Audit Log Message Standards

## Authentication
- User logged in
- User logged out
- User failed to log in
- User changed password

## Data Changes
- Added student: [Student Name or ID]
- Edited student: [Student Name or ID]
- Deleted student: [Student Name or ID]
- Added payment for student: [Student Name or ID] (amount: [₱Amount])
- Edited payment for student: [Student Name or ID] (amount: [₱Amount])
- Deleted payment for student: [Student Name or ID]
- Imported student data (file: [filename])
- Exported payment records

## Role & Permission Management
- Added role: [Role Name]
- Edited role: [Role Name]
- Deleted role: [Role Name]
- Assigned role [Role Name] to user: [Username]
- Updated permissions for user: [Username]

## Access to Sensitive Modules
- Viewed confidential record: [Type/ID]
- Accessed system settings
- Exported grades for class: [Class/Section]

## System Changes
- Updated system configuration: [Setting Name] ([Old Value] → [New Value])
- Performed database backup
- Restored database from backup

## File Operations
- Uploaded file: [filename] for [purpose/module]
- Downloaded file: [filename]

## Other Security Events
- Detected suspicious activity: [details]
- Multiple failed login attempts for user: [Username]

---

## Example Log Entries

- `User logged in`
- `Added student: Juan Dela Cruz`
- `Edited payment for student: Maria Santos (amount: ₱3,500)`
- `Assigned role Admin to user: jefteray24`
- `Exported grades for class: Grade 10 - Section A`
- `Updated system configuration: academic_year (2024-2025 → 2025-2026)`
- `Uploaded file: receipt_203.pdf for payment`
- `Detected suspicious activity: 10 deletes in 1 minute by user: admin`

---

**How to use:**  
- When you log an action, fill in the relevant details (student name, file name, etc).
- Use these templates across all modules for consistency.
- Optionally, add more details if needed for troubleshooting or compliance.

---

**Next Step:**  
Implement a helper function to log actions in your PHP modules using these standardized messages.