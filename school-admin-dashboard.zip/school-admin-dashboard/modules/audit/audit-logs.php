<?php
require_once __DIR__ . '/../../includes/admin-session.php';
if (!defined('AUDIT_LOGS_EMBEDDED')) {
    admin_session_require_login();
} else {
    admin_session_start();
}
require '../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');
require_once __DIR__ . '/audit-retention-helper.php';

$currentRole = $_SESSION['role'] ?? '';
if (!hasPermission($currentRole, 'audit_logs', 'view')) {
    admin_session_forbidden();
}

$auditIndexProvisioning = audit_logs_ensure_performance_indexes($conn);
$auditPerformanceStatus = audit_logs_performance_status($conn);
$auditRetention = audit_retention_status($conn);
$archiveCutoffDate = trim((string) ($_POST['archive_cutoff_date'] ?? $_GET['archive_cutoff_date'] ?? $auditRetention['cutoff_date']));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $archiveCutoffDate)) {
    $archiveCutoffDate = $auditRetention['cutoff_date'];
}
$archiveCsrfToken = audit_archive_csrf_token();
$archiveMessage = '';
$archiveMessageType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['audit_archive_action'] ?? '') === 'archive_before_cutoff') {
    if (!audit_archive_verify_csrf($_POST['audit_archive_csrf_token'] ?? null)) {
        $archiveMessage = 'Invalid audit archive request token.';
        $archiveMessageType = 'danger';
    } else {
        $archiveResult = audit_logs_archive_before_date($conn, $archiveCutoffDate, (string) ($_SESSION['username'] ?? 'unknown'));
        $archiveMessage = $archiveResult['message'];
        $archiveMessageType = $archiveResult['success'] ? 'success' : 'danger';
        if ($archiveResult['success']) {
            audit_log(
                $conn,
                (string) ($_SESSION['username'] ?? 'unknown'),
                'Archived audit logs',
                'Audit',
                "Cutoff: {$archiveCutoffDate} | Archived rows: {$archiveResult['archived_rows']} | Deleted rows: {$archiveResult['deleted_rows']}",
                'INFO'
            );
        }
    }
}

$auditArchiveStatus = audit_logs_archive_status($conn, $archiveCutoffDate);

function audit_logs_trim_filter(?string $value): string {
    return trim((string) $value);
}

function audit_logs_query_value(array $filters, string $key): string {
    return isset($filters[$key]) ? (string) $filters[$key] : '';
}

function audit_logs_build_query(array $overrides = []): string {
    $params = $_GET;
    foreach ($overrides as $key => $value) {
        if ($value === null || $value === '') {
            unset($params[$key]);
        } else {
            $params[$key] = $value;
        }
    }

    $query = http_build_query($params);
    return $query === '' ? '' : '?' . $query;
}

function audit_logs_filter_options(mysqli $conn, string $column): array {
    $allowed = ['user', 'module', 'level'];
    if (!in_array($column, $allowed, true)) {
        return [];
    }

    $options = [];
    $sql = "SELECT DISTINCT {$column} AS option_value
        FROM audit_logs
        WHERE {$column} IS NOT NULL AND TRIM({$column}) <> ''
        ORDER BY {$column} ASC";
    if ($result = $conn->query($sql)) {
        while ($row = $result->fetch_assoc()) {
            $options[] = (string) $row['option_value'];
        }
        $result->close();
    }

    return $options;
}

function audit_logs_lookup_student_names(mysqli $conn, array $studentIds): array {
    $ids = array_values(array_unique(array_map('intval', $studentIds)));
    $names = [];
    if (!$ids) {
        return $names;
    }

    foreach (array_chunk($ids, 500) as $chunk) {
        $placeholders = implode(',', array_fill(0, count($chunk), '?'));
        $types = str_repeat('i', count($chunk));
        $sql = "SELECT id, lastname, firstname FROM students WHERE id IN ({$placeholders})";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            continue;
        }
        $stmt->bind_param($types, ...$chunk);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $names[(int) $row['id']] = (string) $row['lastname'] . ', ' . (string) $row['firstname'];
        }
        $stmt->close();
    }

    return $names;
}

function audit_logs_format_date($datetime): string {
    if (!$datetime) {
        return '';
    }
    $ts = strtotime($datetime);
    return date('m-d-Y h:i A', $ts);
}

function audit_logs_level_badge(?string $level): string {
    $upper = strtoupper(trim((string) $level));
    if ($upper === '') {
        return '<span class="badge bg-secondary">INFO</span>';
    }
    switch ($upper) {
        case 'ERROR':
            return '<span class="badge bg-danger">ERROR</span>';
        case 'SECURITY':
            return '<span class="badge bg-warning text-dark">SECURITY</span>';
        case 'WARNING':
            return '<span class="badge bg-warning text-dark">WARNING</span>';
        default:
            return '<span class="badge bg-secondary">' . htmlspecialchars($upper) . '</span>';
    }
}

$filters = [
    'keyword' => audit_logs_trim_filter($_GET['keyword'] ?? ''),
    'level' => audit_logs_trim_filter($_GET['level'] ?? ''),
    'module' => audit_logs_trim_filter($_GET['module'] ?? ''),
    'user' => audit_logs_trim_filter($_GET['user'] ?? ''),
    'date_from' => audit_logs_trim_filter($_GET['date_from'] ?? ''),
    'date_to' => audit_logs_trim_filter($_GET['date_to'] ?? ''),
];

$limit = 30;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $limit;
$whereClauses = [];
$params = [];
$types = '';

if ($filters['keyword'] !== '') {
    $keyword = '%' . $filters['keyword'] . '%';
    $whereClauses[] = '(action LIKE ? OR module LIKE ? OR details LIKE ? OR user LIKE ?)';
    $params[] = $keyword;
    $params[] = $keyword;
    $params[] = $keyword;
    $params[] = $keyword;
    $types .= 'ssss';
}

if ($filters['level'] !== '') {
    $whereClauses[] = 'level = ?';
    $params[] = $filters['level'];
    $types .= 's';
}

if ($filters['module'] !== '') {
    $whereClauses[] = 'module = ?';
    $params[] = $filters['module'];
    $types .= 's';
}

if ($filters['user'] !== '') {
    $whereClauses[] = 'user = ?';
    $params[] = $filters['user'];
    $types .= 's';
}

if ($filters['date_from'] !== '') {
    $whereClauses[] = 'DATE(log_date) >= ?';
    $params[] = $filters['date_from'];
    $types .= 's';
}

if ($filters['date_to'] !== '') {
    $whereClauses[] = 'DATE(log_date) <= ?';
    $params[] = $filters['date_to'];
    $types .= 's';
}

$whereSql = $whereClauses ? (' WHERE ' . implode(' AND ', $whereClauses)) : '';

$summarySql = "SELECT
    COUNT(*) AS total_logs,
    SUM(CASE WHEN DATE(log_date) = CURDATE() THEN 1 ELSE 0 END) AS logs_today,
    SUM(CASE WHEN level = 'SECURITY' THEN 1 ELSE 0 END) AS security_logs,
    SUM(CASE WHEN module = 'Students' AND action LIKE '%registration%' THEN 1 ELSE 0 END) AS registration_logs,
    SUM(CASE WHEN module = 'Export' OR action LIKE 'Exported%' OR action LIKE 'Downloaded export%' THEN 1 ELSE 0 END) AS export_logs,
    MAX(log_date) AS last_log_at
    FROM audit_logs{$whereSql}";
$summaryStmt = $conn->prepare($summarySql);
if ($summaryStmt === false) {
    die('Unable to load audit summaries.');
}
if ($types !== '') {
    $summaryStmt->bind_param($types, ...$params);
}
$summaryStmt->execute();
$summaryResult = $summaryStmt->get_result();
$summary = $summaryResult ? $summaryResult->fetch_assoc() : [];
$summaryStmt->close();

$moduleSummarySql = "SELECT module, COUNT(*) AS total
    FROM audit_logs{$whereSql}
    GROUP BY module
    ORDER BY total DESC, module ASC
    LIMIT 5";
$moduleSummaryStmt = $conn->prepare($moduleSummarySql);
if ($moduleSummaryStmt === false) {
    die('Unable to load audit module summary.');
}
if ($types !== '') {
    $moduleSummaryStmt->bind_param($types, ...$params);
}
$moduleSummaryStmt->execute();
$moduleSummaryResult = $moduleSummaryStmt->get_result();
$topModules = $moduleSummaryResult ? $moduleSummaryResult->fetch_all(MYSQLI_ASSOC) : [];
$moduleSummaryStmt->close();

$userSummarySql = "SELECT user, COUNT(*) AS total
    FROM audit_logs{$whereSql}
    GROUP BY user
    ORDER BY total DESC, user ASC
    LIMIT 5";
$userSummaryStmt = $conn->prepare($userSummarySql);
if ($userSummaryStmt === false) {
    die('Unable to load audit user summary.');
}
if ($types !== '') {
    $userSummaryStmt->bind_param($types, ...$params);
}
$userSummaryStmt->execute();
$userSummaryResult = $userSummaryStmt->get_result();
$topUsers = $userSummaryResult ? $userSummaryResult->fetch_all(MYSQLI_ASSOC) : [];
$userSummaryStmt->close();

$levelSummarySql = "SELECT level, COUNT(*) AS total
    FROM audit_logs{$whereSql}
    GROUP BY level
    ORDER BY total DESC, level ASC";
$levelSummaryStmt = $conn->prepare($levelSummarySql);
if ($levelSummaryStmt === false) {
    die('Unable to load audit level summary.');
}
if ($types !== '') {
    $levelSummaryStmt->bind_param($types, ...$params);
}
$levelSummaryStmt->execute();
$levelSummaryResult = $levelSummaryStmt->get_result();
$levelBreakdown = $levelSummaryResult ? $levelSummaryResult->fetch_all(MYSQLI_ASSOC) : [];
$levelSummaryStmt->close();

$dailySummarySql = "SELECT DATE(log_date) AS log_day, COUNT(*) AS total
    FROM audit_logs{$whereSql}
    GROUP BY DATE(log_date)
    ORDER BY log_day DESC
    LIMIT 7";
$dailySummaryStmt = $conn->prepare($dailySummarySql);
if ($dailySummaryStmt === false) {
    die('Unable to load audit daily summary.');
}
if ($types !== '') {
    $dailySummaryStmt->bind_param($types, ...$params);
}
$dailySummaryStmt->execute();
$dailySummaryResult = $dailySummaryStmt->get_result();
$recentDays = $dailySummaryResult ? $dailySummaryResult->fetch_all(MYSQLI_ASSOC) : [];
$dailySummaryStmt->close();

$countSql = "SELECT COUNT(*) AS total FROM audit_logs{$whereSql}";
$countStmt = $conn->prepare($countSql);
if ($countStmt === false) {
    die('Unable to load audit logs.');
}
if ($types !== '') {
    $countStmt->bind_param($types, ...$params);
}
$countStmt->execute();
$countResult = $countStmt->get_result();
$row = $countResult ? $countResult->fetch_assoc() : ['total' => 0];
$totalRows = (int) ($row['total'] ?? 0);
$countStmt->close();

$totalPages = max(1, (int) ceil($totalRows / $limit));
if ($page > $totalPages) {
    $page = $totalPages;
    $offset = ($page - 1) * $limit;
}

$sql = "SELECT id, user, action, module, details, level, log_date
    FROM audit_logs{$whereSql}
    ORDER BY log_date DESC
    LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die('Unable to load audit logs.');
}

$queryParams = $params;
$queryTypes = $types . 'ii';
$queryParams[] = $limit;
$queryParams[] = $offset;
$stmt->bind_param($queryTypes, ...$queryParams);
$stmt->execute();
$stmt->bind_result($id, $user, $action, $module, $details, $level, $log_date);

$auditLogs = [];
$studentIdsToFetch = [];
while ($stmt->fetch()) {
    $studentId = null;
    if (
        preg_match('/Accessed edit student page|Edited student/i', $action) &&
        preg_match('/Student ID: (\d+)/', $details, $matches)
    ) {
        $studentId = (int) $matches[1];
        $studentIdsToFetch[$studentId] = true;
    }

    if ($currentRole === 'Administrator') {
        $details = str_replace('Super Administrator', 'Administrator', $details);
    }

    $auditLogs[] = [
        'user' => $user,
        'action' => $action,
        'module' => $module,
        'details' => $details,
        'level' => $level,
        'log_date' => $log_date,
        'student_id' => $studentId,
    ];
}
$stmt->close();

$studentNames = [];
if (!empty($studentIdsToFetch)) {
    $studentNames = audit_logs_lookup_student_names($conn, array_keys($studentIdsToFetch));
}

foreach ($auditLogs as &$log) {
    if ($log['student_id'] && isset($studentNames[$log['student_id']])) {
        $log['details'] = preg_replace(
            '/Student ID: ' . $log['student_id'] . '/',
            'Student: ' . $studentNames[$log['student_id']],
            $log['details']
        );
    }
}
unset($log);

$userOptions = audit_logs_filter_options($conn, 'user');
$moduleOptions = audit_logs_filter_options($conn, 'module');
$levelOptions = audit_logs_filter_options($conn, 'level');
$hasActiveFilters = implode('', $filters) !== '';
$isEmbedded = basename($_SERVER['PHP_SELF'] ?? '') !== 'audit-logs.php';

if (!$isEmbedded):
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Audit Logs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
<?php endif; ?>

<div class="container-fluid px-0">
    <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-3 mb-3">
        <div>
            <h2 class="mb-1">Audit Logs</h2>
            <p class="text-muted mb-0">Track admin activity, security events, and registration workflow changes.</p>
        </div>
        <div class="d-flex gap-2">
            <?php if ($isEmbedded): ?>
                <a class="btn btn-outline-secondary" href="audit-logs.php">Open Full Page</a>
            <?php endif; ?>
            <a class="btn btn-outline-primary" href="audit-exportlogs.php<?= htmlspecialchars(audit_logs_build_query(['page' => null])) ?>">Export Filtered CSV</a>
        </div>
    </div>

    <div class="row g-3 mb-3">
        <div class="col-12 col-md-6 col-xl">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="text-uppercase small text-muted fw-semibold">Total Logs</div>
                    <div class="fs-3 fw-bold text-dark"><?= (int) ($summary['total_logs'] ?? 0) ?></div>
                    <div class="small text-muted"><?= $hasActiveFilters ? 'Current filter set' : 'All available logs' ?></div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6 col-xl">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="text-uppercase small text-muted fw-semibold">Today</div>
                    <div class="fs-3 fw-bold text-primary"><?= (int) ($summary['logs_today'] ?? 0) ?></div>
                    <div class="small text-muted">Logs recorded today</div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6 col-xl">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="text-uppercase small text-muted fw-semibold">Security</div>
                    <div class="fs-3 fw-bold text-warning"><?= (int) ($summary['security_logs'] ?? 0) ?></div>
                    <div class="small text-muted">Security-related events</div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6 col-xl">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="text-uppercase small text-muted fw-semibold">Registrations</div>
                    <div class="fs-3 fw-bold text-success"><?= (int) ($summary['registration_logs'] ?? 0) ?></div>
                    <div class="small text-muted">Student registration actions</div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6 col-xl">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="text-uppercase small text-muted fw-semibold">Exports</div>
                    <div class="fs-3 fw-bold text-info"><?= (int) ($summary['export_logs'] ?? 0) ?></div>
                    <div class="small text-muted">Export and download actions</div>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm border-0 mb-3">
        <div class="card-body d-flex flex-column flex-lg-row justify-content-between gap-3">
            <div>
                <div class="text-uppercase small text-muted fw-semibold mb-2">Top Modules</div>
                <?php if ($topModules): ?>
                    <div class="d-flex flex-wrap gap-2">
                        <?php foreach ($topModules as $moduleRow): ?>
                            <span class="badge text-bg-light border px-3 py-2">
                                <?= htmlspecialchars($moduleRow['module'] !== '' ? $moduleRow['module'] : 'Uncategorized') ?>: <?= (int) $moduleRow['total'] ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="small text-muted">No module activity found for this view.</div>
                <?php endif; ?>
            </div>
            <div class="text-lg-end">
                <div class="text-uppercase small text-muted fw-semibold mb-2">Last Log</div>
                <div class="fw-semibold"><?= htmlspecialchars(audit_logs_format_date((string) ($summary['last_log_at'] ?? ''))) ?></div>
                <div class="small text-muted">Latest timestamp in this view</div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm border-0 mb-3">
        <div class="card-body">
            <div class="d-flex flex-column flex-lg-row justify-content-between gap-3 mb-3">
                <div>
                    <div class="text-uppercase small text-muted fw-semibold">Audit Archive Wave 1</div>
                    <div class="fs-5 fw-bold text-dark">Performance Foundation</div>
                    <div class="small text-muted">Core audit indexes are checked and provisioned here so the main log page stays stable as volume grows.</div>
                </div>
                <div class="text-lg-end">
                    <span class="badge <?= $auditPerformanceStatus['is_ready'] ? 'bg-success' : 'bg-warning text-dark' ?>">
                        <?= $auditPerformanceStatus['is_ready'] ? 'Foundation Ready' : 'Needs Review' ?>
                    </span>
                </div>
            </div>
            <div class="row g-3 mb-3">
                <div class="col-12 col-md-6 col-xl-3">
                    <div class="border rounded-3 p-3 bg-light h-100">
                        <div class="text-uppercase small text-muted fw-semibold">Indexes Installed</div>
                        <div class="fs-4 fw-bold text-primary"><?= (int) $auditPerformanceStatus['installed_count'] ?>/<?= (int) $auditPerformanceStatus['required_count'] ?></div>
                        <div class="small text-muted">Required: log date, user, module, and level</div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-xl-3">
                    <div class="border rounded-3 p-3 bg-light h-100">
                        <div class="text-uppercase small text-muted fw-semibold">Audit Rows</div>
                        <div class="fs-4 fw-bold text-dark"><?= number_format((int) $auditPerformanceStatus['total_logs']) ?></div>
                        <div class="small text-muted">Current live audit log volume</div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-xl-3">
                    <div class="border rounded-3 p-3 bg-light h-100">
                        <div class="text-uppercase small text-muted fw-semibold">Oldest Log</div>
                        <div class="fw-bold text-dark"><?= htmlspecialchars(audit_logs_format_date((string) ($auditPerformanceStatus['oldest_log_at'] ?? ''))) ?></div>
                        <div class="small text-muted">Helps decide archive cutoff later</div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-xl-3">
                    <div class="border rounded-3 p-3 bg-light h-100">
                        <div class="text-uppercase small text-muted fw-semibold">Latest Log</div>
                        <div class="fw-bold text-dark"><?= htmlspecialchars(audit_logs_format_date((string) ($auditPerformanceStatus['latest_log_at'] ?? ''))) ?></div>
                        <div class="small text-muted">Most recent audit activity</div>
                    </div>
                </div>
            </div>
            <div class="row g-3">
                <div class="col-12 col-lg-6">
                    <div class="border rounded-3 p-3 h-100">
                        <div class="text-uppercase small text-muted fw-semibold mb-2">Index Coverage</div>
                        <div class="d-flex flex-wrap gap-2">
                            <?php foreach ($auditPerformanceStatus['installed'] as $indexName): ?>
                                <span class="badge bg-success-subtle text-success-emphasis border border-success-subtle px-3 py-2"><?= htmlspecialchars($indexName) ?></span>
                            <?php endforeach; ?>
                            <?php foreach ($auditPerformanceStatus['missing'] as $indexName): ?>
                                <span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle px-3 py-2"><?= htmlspecialchars($indexName) ?></span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-6">
                    <div class="border rounded-3 p-3 h-100">
                        <div class="text-uppercase small text-muted fw-semibold mb-2">Provisioning Result</div>
                        <?php if (!empty($auditIndexProvisioning['created'])): ?>
                            <div class="small text-success mb-2">Created this load: <?= htmlspecialchars(implode(', ', $auditIndexProvisioning['created'])) ?></div>
                        <?php endif; ?>
                        <?php if (!empty($auditIndexProvisioning['errors'])): ?>
                            <div class="small text-danger mb-2">Index creation issues detected. Review before proceeding to archive waves.</div>
                        <?php else: ?>
                            <div class="small text-muted mb-2">No index creation errors detected.</div>
                        <?php endif; ?>
                        <div class="small text-muted">Wave 2 will use this foundation to move older logs into an archive table without slowing the live audit page.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm border-0 mb-3">
        <div class="card-body">
            <div class="d-flex flex-column flex-lg-row justify-content-between gap-3 mb-3">
                <div>
                    <div class="text-uppercase small text-muted fw-semibold">Audit Archive Wave 2</div>
                    <div class="fs-5 fw-bold text-dark">Manual Archive Tool</div>
                    <div class="small text-muted">Move older audit rows into the archive table by cutoff date. This keeps the live audit table lighter without losing history.</div>
                </div>
                <div class="text-lg-end">
                    <span class="badge bg-primary">Archive Table Ready</span>
                </div>
            </div>

            <?php if ($archiveMessage !== ''): ?>
                <div class="alert alert-<?= htmlspecialchars($archiveMessageType) ?> py-2"><?= htmlspecialchars($archiveMessage) ?></div>
            <?php endif; ?>

            <div class="row g-3 mb-3">
                <div class="col-12 col-md-6 col-xl-3">
                    <div class="border rounded-3 p-3 bg-light h-100">
                        <div class="text-uppercase small text-muted fw-semibold">Main Audit Rows</div>
                        <div class="fs-4 fw-bold text-dark"><?= number_format((int) $auditArchiveStatus['main_total']) ?></div>
                        <div class="small text-muted">Current live table volume</div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-xl-3">
                    <div class="border rounded-3 p-3 bg-light h-100">
                        <div class="text-uppercase small text-muted fw-semibold">Archive Rows</div>
                        <div class="fs-4 fw-bold text-primary"><?= number_format((int) $auditArchiveStatus['archive_total']) ?></div>
                        <div class="small text-muted">Rows already preserved in archive</div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-xl-3">
                    <div class="border rounded-3 p-3 bg-light h-100">
                        <div class="text-uppercase small text-muted fw-semibold">Eligible to Archive</div>
                        <div class="fs-4 fw-bold text-warning"><?= number_format((int) $auditArchiveStatus['eligible_total']) ?></div>
                        <div class="small text-muted">Rows older than the selected cutoff</div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-xl-3">
                    <div class="border rounded-3 p-3 bg-light h-100">
                        <div class="text-uppercase small text-muted fw-semibold">Latest Archive Run</div>
                        <div class="fw-bold text-dark"><?= htmlspecialchars(audit_logs_format_date((string) ($auditArchiveStatus['archive_latest'] ?? ''))) ?></div>
                        <div class="small text-muted">Most recent archive timestamp</div>
                    </div>
                </div>
            </div>

            <div class="row g-3">
                <div class="col-12 col-lg-7">
                    <form method="post" class="border rounded-3 p-3 h-100" onsubmit="return confirm('Archive all audit logs older than the selected cutoff date?');">
                        <input type="hidden" name="audit_archive_action" value="archive_before_cutoff">
                        <input type="hidden" name="audit_archive_csrf_token" value="<?= htmlspecialchars($archiveCsrfToken) ?>">
                        <div class="text-uppercase small text-muted fw-semibold mb-2">Archive Action</div>
                        <div class="row g-3 align-items-end">
                            <div class="col-md-5">
                                <label for="archive_cutoff_date" class="form-label">Archive logs before</label>
                                <input type="date" class="form-control" id="archive_cutoff_date" name="archive_cutoff_date" value="<?= htmlspecialchars($archiveCutoffDate) ?>">
                            </div>
                            <div class="col-md-7">
                                <button type="submit" class="btn btn-primary">Archive Eligible Logs</button>
                            </div>
                        </div>
                        <div class="small text-muted mt-3">Retention policy default: keep the last <?= (int) ($auditRetention['live_retention_months'] ?? 12) ?> months in the live audit table and move older records into archive.</div>
                    </form>
                </div>
                <div class="col-12 col-lg-5">
                    <div class="border rounded-3 p-3 h-100">
                        <div class="text-uppercase small text-muted fw-semibold mb-2">Cutoff Preview</div>
                        <div class="small text-muted mb-2">Selected cutoff: <span class="fw-semibold text-dark"><?= htmlspecialchars($archiveCutoffDate) ?></span></div>
                        <div class="small text-muted mb-2">Retention review: <span class="fw-semibold text-dark"><?= htmlspecialchars((string) ($auditRetention['review_frequency'] ?? 'Monthly')) ?></span></div>
                        <div class="small text-muted mb-1">Oldest eligible log: <span class="fw-semibold text-dark"><?= htmlspecialchars(audit_logs_format_date((string) ($auditArchiveStatus['eligible_oldest'] ?? ''))) ?></span></div>
                        <div class="small text-muted">Latest eligible log: <span class="fw-semibold text-dark"><?= htmlspecialchars(audit_logs_format_date((string) ($auditArchiveStatus['eligible_latest'] ?? ''))) ?></span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-3">
        <div class="col-12 col-xl-4">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="text-uppercase small text-muted fw-semibold mb-3">Most Active Users</div>
                    <?php if ($topUsers): ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($topUsers as $index => $userRow): ?>
                                <div class="list-group-item px-0 d-flex justify-content-between align-items-center border-0 border-bottom">
                                    <div>
                                        <div class="fw-semibold"><?= ($index + 1) ?>. <?= htmlspecialchars($userRow['user'] !== '' ? $userRow['user'] : 'Unknown') ?></div>
                                        <div class="small text-muted">Logged actions in this view</div>
                                    </div>
                                    <span class="badge bg-primary rounded-pill"><?= (int) $userRow['total'] ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="small text-muted">No user activity found for this view.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-12 col-xl-4">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="text-uppercase small text-muted fw-semibold mb-3">Level Breakdown</div>
                    <?php if ($levelBreakdown): ?>
                        <?php foreach ($levelBreakdown as $levelRow): ?>
                            <?php
                            $levelName = $levelRow['level'] !== '' ? $levelRow['level'] : 'Uncategorized';
                            $levelTotal = (int) $levelRow['total'];
                            $percent = ($summary['total_logs'] ?? 0) > 0 ? round(($levelTotal / (int) $summary['total_logs']) * 100) : 0;
                            ?>
                            <div class="mb-3">
                                <div class="d-flex justify-content-between small mb-1">
                                    <span class="fw-semibold"><?= htmlspecialchars($levelName) ?></span>
                                    <span class="text-muted"><?= $levelTotal ?> (<?= $percent ?>%)</span>
                                </div>
                                <div class="progress" style="height: 10px;">
                                    <div class="progress-bar <?= $levelName === 'SECURITY' ? 'bg-warning' : ($levelName === 'ERROR' ? 'bg-danger' : ($levelName === 'WARNING' ? 'bg-info' : 'bg-secondary')) ?>" role="progressbar" style="width: <?= $percent ?>%;" aria-valuenow="<?= $percent ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="small text-muted">No level data found for this view.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-12 col-xl-4">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="text-uppercase small text-muted fw-semibold mb-3">Recent Daily Activity</div>
                    <?php if ($recentDays): ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($recentDays as $dayRow): ?>
                                <div class="list-group-item px-0 d-flex justify-content-between align-items-center border-0 border-bottom">
                                    <div>
                                        <div class="fw-semibold"><?= htmlspecialchars(date('F j, Y', strtotime((string) $dayRow['log_day']))) ?></div>
                                        <div class="small text-muted">Recorded log entries</div>
                                    </div>
                                    <span class="badge bg-dark rounded-pill"><?= (int) $dayRow['total'] ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="small text-muted">No daily activity found for this view.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <form class="card shadow-sm border-0 mb-3" method="get" action="">
        <div class="card-body">
            <div class="row g-3">
                <div class="col-lg-3">
                    <label for="audit-keyword" class="form-label">Keyword</label>
                    <input type="text" class="form-control" id="audit-keyword" name="keyword" value="<?= htmlspecialchars(audit_logs_query_value($filters, 'keyword')) ?>" placeholder="Search action, details, user">
                </div>
                <div class="col-lg-2">
                    <label for="audit-level" class="form-label">Level</label>
                    <select class="form-select" id="audit-level" name="level">
                        <option value="">All levels</option>
                        <?php foreach ($levelOptions as $option): ?>
                            <option value="<?= htmlspecialchars($option) ?>" <?= $filters['level'] === $option ? 'selected' : '' ?>><?= htmlspecialchars($option) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-lg-2">
                    <label for="audit-module" class="form-label">Module</label>
                    <select class="form-select" id="audit-module" name="module">
                        <option value="">All modules</option>
                        <?php foreach ($moduleOptions as $option): ?>
                            <option value="<?= htmlspecialchars($option) ?>" <?= $filters['module'] === $option ? 'selected' : '' ?>><?= htmlspecialchars($option) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-lg-2">
                    <label for="audit-user" class="form-label">User</label>
                    <select class="form-select" id="audit-user" name="user">
                        <option value="">All users</option>
                        <?php foreach ($userOptions as $option): ?>
                            <option value="<?= htmlspecialchars($option) ?>" <?= $filters['user'] === $option ? 'selected' : '' ?>><?= htmlspecialchars($option) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-lg-1">
                    <label for="audit-date-from" class="form-label">From</label>
                    <input type="date" class="form-control" id="audit-date-from" name="date_from" value="<?= htmlspecialchars(audit_logs_query_value($filters, 'date_from')) ?>">
                </div>
                <div class="col-lg-1">
                    <label for="audit-date-to" class="form-label">To</label>
                    <input type="date" class="form-control" id="audit-date-to" name="date_to" value="<?= htmlspecialchars(audit_logs_query_value($filters, 'date_to')) ?>">
                </div>
                <div class="col-lg-1 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">Apply</button>
                </div>
            </div>
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-3">
                <div class="text-muted small">
                    <?= $totalRows ?> result<?= $totalRows === 1 ? '' : 's' ?> found<?= $hasActiveFilters ? ' for the current filter set' : '' ?>
                </div>
                <?php if ($hasActiveFilters): ?>
                    <a class="btn btn-sm btn-outline-secondary" href="audit-logs.php">Clear Filters</a>
                <?php endif; ?>
            </div>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle bg-white">
            <thead class="table-dark">
                <tr>
                    <th>User</th>
                    <th>Action</th>
                    <th>Module</th>
                    <th>Details</th>
                    <th>Level</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$auditLogs): ?>
                <tr>
                    <td colspan="6" class="text-center text-muted py-4">No audit logs found for the selected filters.</td>
                </tr>
            <?php endif; ?>
            <?php foreach ($auditLogs as $log): ?>
                <tr>
                    <td><?= htmlspecialchars($log['user']) ?></td>
                    <td>
                        <?php if (preg_match('/(deleted|edited|added)/i', strtolower($log['action']))): ?>
                            <a href="#" class="action-detail-link" data-details="<?= htmlspecialchars($log['details']) ?>">
                                <?= htmlspecialchars($log['action']) ?>
                            </a>
                        <?php else: ?>
                            <?= htmlspecialchars($log['action']) ?>
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($log['module']) ?></td>
                    <td><?= htmlspecialchars($log['details']) ?></td>
                    <td><?= audit_logs_level_badge($log['level']) ?></td>
                    <td><?= htmlspecialchars(audit_logs_format_date($log['log_date'])) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <nav aria-label="Audit logs pagination">
        <ul class="pagination justify-content-center">
            <?php if ($page > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="<?= htmlspecialchars(audit_logs_build_query(['page' => $page - 1])) ?>">Previous</a>
                </li>
            <?php endif; ?>
            <?php
            $start = max(1, $page - 2);
            $end = min($totalPages, $page + 2);
            if ($start > 1) {
                echo '<li class="page-item"><a class="page-link" href="' . htmlspecialchars(audit_logs_build_query(['page' => 1])) . '">1</a></li>';
                if ($start > 2) {
                    echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                }
            }
            for ($p = $start; $p <= $end; $p++):
            ?>
                <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                    <a class="page-link" href="<?= htmlspecialchars(audit_logs_build_query(['page' => $p])) ?>"><?= $p ?></a>
                </li>
            <?php endfor;
            if ($end < $totalPages) {
                if ($end < $totalPages - 1) {
                    echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                }
                echo '<li class="page-item"><a class="page-link" href="' . htmlspecialchars(audit_logs_build_query(['page' => $totalPages])) . '">' . $totalPages . '</a></li>';
            }
            ?>
            <?php if ($page < $totalPages): ?>
                <li class="page-item">
                    <a class="page-link" href="<?= htmlspecialchars(audit_logs_build_query(['page' => $page + 1])) ?>">Next</a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
</div>

<div class="modal fade" id="detailsModal" tabindex="-1" aria-labelledby="detailsModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="detailsModalLabel">Action Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="detailsModalBody"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.action-detail-link').forEach(function(link) {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            document.getElementById('detailsModalBody').textContent = this.getAttribute('data-details');
            var modal = new bootstrap.Modal(document.getElementById('detailsModal'));
            modal.show();
        });
    });
});
</script>

<?php if (!$isEmbedded): ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<?= admin_session_warning_script() ?>
</body>
</html>
<?php endif; ?>
<?php $conn->close(); ?>
