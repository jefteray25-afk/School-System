<?php
require_once __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
if (!is_super_admin_role($role)) {
    admin_session_forbidden();
}
$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";
$activeAuditTab = $_GET['audit_tab'] ?? 'logs';
if (!in_array($activeAuditTab, ['logs', 'archive', 'scope', 'common'], true)) {
    $activeAuditTab = 'logs';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Settings - Audit & Security</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f5f8fc; font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif; }
        .navbar { background: #23395d !important; }
        .navbar-brand, .navbar-nav .nav-link { color: #fff !important; }
        .dashboard-header { text-align: center; margin-top: 36px; margin-bottom: 18px; }
        .dashboard-header img { width: 48px; height: 48px; object-fit: contain; margin-bottom: 6px; }
        .dashboard-header h1 { font-size: 1.13rem; color: #23395d; font-weight: 700; margin-bottom: 0; }
        .audit-btn-row { display: flex; justify-content: center; gap: 32px; margin-top: 38px; margin-bottom: 32px; flex-wrap: wrap; }
        .audit-btn {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background: #fff;
            border-radius: 18px;
            border: 2px solid #517fa4;
            box-shadow: 0 2px 12px rgba(33,57,93,0.08);
            width: 170px;
            height: 170px;
            cursor: pointer;
            transition: box-shadow 0.18s, border-color 0.18s, background 0.18s;
            font-size: 1.12rem;
            font-weight: 600;
            color: #23395d;
            text-align: center;
            outline: none;
            user-select: none;
        }
        .audit-btn:hover, .audit-btn.active {
            box-shadow: 0 0 18px #517fa478;
            border-color: #23395d;
            background: #eaf4ff;
        }
        .audit-btn i {
            font-size: 3.1rem;
            color: #517fa4;
            margin-bottom: 12px;
        }
        .audit-section {
            background: none;
            border-radius: 14px;
            padding: 0;
            margin-bottom: 24px;
            min-height: 180px;
            animation: fadeIn 0.4s;
            width: 100%;
            display: none;
        }
        .audit-section.active {
            display: block;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(22px);}
            to { opacity: 1; transform: translateY(0);}
        }
        @media (max-width: 900px) {
            .audit-btn-row { gap: 18px; }
            .audit-btn { width: 130px; height: 130px; font-size: 0.92rem;}
            .audit-btn i { font-size: 2.1rem;}
        }
        @media (max-width: 600px) {
            .audit-btn-row { flex-direction: column; align-items: center; gap: 15px;}
            .dashboard-header img { width: 32px; height: 32px; }
            .dashboard-header h1 { font-size: 0.9rem;}
        }
        /* Floating Archive Reminder Button and Note */
        .archive-reminder-btn {
            position: fixed;
            right: 26px;
            bottom: 28px;
            z-index: 9999;
            width: 62px;
            height: 62px;
            background: #517fa4;
            color: #fff;
            border-radius: 50%;
            box-shadow: 0 3px 16px rgba(81,127,164,0.13);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 2.4rem;
            transition: background 0.18s, box-shadow 0.18s;
        }
        .archive-reminder-btn:hover {
            background: #23395d;
            box-shadow: 0 6px 22px #517fa466;
        }
        .archive-reminder-note {
            display: none;
            position: fixed;
            right: 36px;
            bottom: 100px;
            z-index: 10000;
            width: 320px;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 4px 24px rgba(33,57,93,0.13);
            padding: 18px 18px 12px 18px;
            border: 2px solid #517fa4;
            animation: fadeIn 0.35s;
        }
        .archive-reminder-note .note-content h6 {
            margin-top: 0;
            margin-bottom: 8px;
            color: #517fa4;
            font-weight: 700;
        }
        .archive-reminder-note .note-content p {
            margin-bottom: 6px;
        }
        .archive-reminder-note .close-btn {
            position: absolute;
            top: 8px;
            right: 14px;
            font-size: 1.3em;
            cursor: pointer;
            color: #517fa4;
        }
    </style>
</head>
<body>
<?php render_admin_nav('settings', true); ?>
<div class="dashboard-header">
    <img src="/school-admin-dashboard/uploads/logo1.png" alt="School Logo" class="mb-2 rounded shadow-sm">
    <h1><?= $schoolName ?></h1>
</div>
<div class="container">
    <!-- Button Row -->
    <div class="audit-btn-row">
        <a href="?audit_tab=logs" class="audit-btn <?= $activeAuditTab === 'logs' ? 'active' : '' ?>" id="btnLogs" onclick="showAuditSection('logs'); return false;">
            <i class="fas fa-file-alt"></i>
            Audit Logs
        </a>
        <a href="?audit_tab=archive" class="audit-btn <?= $activeAuditTab === 'archive' ? 'active' : '' ?>" id="btnArchive" onclick="showAuditSection('archive'); return false;">
            <i class="fas fa-box-archive"></i>
            Audit Archive
        </a>
        <a href="?audit_tab=scope" class="audit-btn <?= $activeAuditTab === 'scope' ? 'active' : '' ?>" id="btnScope" onclick="showAuditSection('scope'); return false;">
            <i class="fas fa-search"></i>
            Audit Scope
        </a>
        <a href="?audit_tab=common" class="audit-btn <?= $activeAuditTab === 'common' ? 'active' : '' ?>" id="btnCommon" onclick="showAuditSection('common'); return false;">
            <i class="fas fa-wrench"></i>
            Audit Maintenance
        </a>
    </div>
    <!-- Section Content -->
    <div id="auditSectionLogs" class="audit-section <?= $activeAuditTab === 'logs' ? 'active' : '' ?>">
        <?php define('AUDIT_LOGS_EMBEDDED', true); ?>
        <?php include(__DIR__.'/audit-logs.php'); ?>
    </div>
    <div id="auditSectionArchive" class="audit-section <?= $activeAuditTab === 'archive' ? 'active' : '' ?>">
        <?php define('AUDIT_ARCHIVE_EMBEDDED', true); ?>
        <?php include(__DIR__.'/audit-archive.php'); ?>
    </div>
    <div id="auditSectionScope" class="audit-section <?= $activeAuditTab === 'scope' ? 'active' : '' ?>">
        <?php include(__DIR__.'/audit-scope.php'); ?>
    </div>
    <div id="auditSectionCommon" class="audit-section <?= $activeAuditTab === 'common' ? 'active' : '' ?>">
        <?php include(__DIR__.'/audit-common.php'); ?>
    </div>
</div>
<!-- Floating Archive Reminder Button -->
<div id="archiveReminderBtn" class="archive-reminder-btn" title="Audit Log Archive Reminder">
    <i class="fab fa-facebook-messenger"></i>
</div>
<!-- Archive Reminder Note Popup -->
<div id="archiveReminderNote" class="archive-reminder-note">
    <div class="note-content">
        <span class="close-btn" id="closeNoteBtn">&times;</span>
        <h6><i class="fas fa-database me-1"></i> Audit Log Archive Reminder</h6>
        <p>
            <strong>Reminder:</strong> At the <b>end of every month</b>, please manually backup and transfer your audit logs from <code>audit_logs</code> to <code>audit_logs_archive</code>.<br>
            <br>
            <span class="text-muted small">This helps keep your system fast and ensures compliance with school data policies. You can use phpMyAdmin or run the recommended SQL commands below:</span>
        </p>
        <pre style="font-size: 0.92em; background: #f8fafc; border-radius: 8px; padding: 8px; margin-top: 8px;">
INSERT INTO audit_logs_archive SELECT * FROM audit_logs WHERE log_date &lt; DATE_SUB(NOW(), INTERVAL 1 YEAR);
DELETE FROM audit_logs WHERE log_date &lt; DATE_SUB(NOW(), INTERVAL 1 YEAR);
        </pre>
    </div>
</div>
<footer class="text-center py-4 text-muted small">
    &copy; <?= date("Y") ?> <?= $schoolName ?> | Audit & Security
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<?= admin_session_warning_script() ?>
<script>
function showAuditSection(section) {
    document.getElementById('btnLogs').classList.remove('active');
    document.getElementById('btnArchive').classList.remove('active');
    document.getElementById('btnScope').classList.remove('active');
    document.getElementById('btnCommon').classList.remove('active');
    document.getElementById('auditSectionLogs').classList.remove('active');
    document.getElementById('auditSectionArchive').classList.remove('active');
    document.getElementById('auditSectionScope').classList.remove('active');
    document.getElementById('auditSectionCommon').classList.remove('active');
    if(section === 'logs') {
        document.getElementById('auditSectionLogs').classList.add('active');
        document.getElementById('btnLogs').classList.add('active');
    } else if(section === 'archive') {
        document.getElementById('auditSectionArchive').classList.add('active');
        document.getElementById('btnArchive').classList.add('active');
    } else if(section === 'scope') {
        document.getElementById('auditSectionScope').classList.add('active');
        document.getElementById('btnScope').classList.add('active');
    } else if(section === 'common') {
        document.getElementById('auditSectionCommon').classList.add('active');
        document.getElementById('btnCommon').classList.add('active');
    }
}
// Archive Reminder Button and Note Logic
document.getElementById('archiveReminderBtn').onclick = function() {
    document.getElementById('archiveReminderNote').style.display = 'block';
};
document.getElementById('closeNoteBtn').onclick = function() {
    document.getElementById('archiveReminderNote').style.display = 'none';
};
// Optional: close note if clicked outside popup
document.addEventListener('mousedown', function(event) {
    var note = document.getElementById('archiveReminderNote');
    var btn = document.getElementById('archiveReminderBtn');
    if (note.style.display === 'block' && !note.contains(event.target) && event.target !== btn) {
        note.style.display = 'none';
    }
});
</script>
</body>
</html>
