<div class="card mb-4 shadow-sm border-0">
    <div class="card-header bg-secondary text-white">
        <h4 class="mb-0"><i class="fas fa-wrench me-2"></i>Audit Maintenance</h4>
    </div>
    <div class="card-body">
        <div class="row g-3 mb-3">
            <div class="col-12 col-md-6 col-xl-3">
                <div class="border rounded-3 p-3 h-100 bg-light">
                    <div class="text-uppercase small text-muted fw-semibold">Monthly Review</div>
                    <div class="fw-bold text-dark mt-1">Check log volume</div>
                    <div class="small text-muted mt-2">Review the live audit row count and decide whether old rows should be archived.</div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-xl-3">
                <div class="border rounded-3 p-3 h-100 bg-light">
                    <div class="text-uppercase small text-muted fw-semibold">Archive Work</div>
                    <div class="fw-bold text-dark mt-1">Move older logs</div>
                    <div class="small text-muted mt-2">Use the manual archive tool to move older entries into <code>audit_logs_archive</code>.</div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-xl-3">
                <div class="border rounded-3 p-3 h-100 bg-light">
                    <div class="text-uppercase small text-muted fw-semibold">Export Review</div>
                    <div class="fw-bold text-dark mt-1">Export filtered logs if needed</div>
                    <div class="small text-muted mt-2">For reporting or compliance checks, export only the filtered rows you actually need.</div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-xl-3">
                <div class="border rounded-3 p-3 h-100 bg-light">
                    <div class="text-uppercase small text-muted fw-semibold">Archive Viewer</div>
                    <div class="fw-bold text-dark mt-1">Verify historical access</div>
                    <div class="small text-muted mt-2">After archiving, confirm older logs are visible in the archive section before considering cleanup.</div>
                </div>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-12 col-lg-6">
                <div class="card h-100 border-0 bg-light-subtle">
                    <div class="card-body">
                        <div class="text-uppercase small text-muted fw-semibold mb-2">Recommended Maintenance Flow</div>
                        <ol class="mb-0">
                            <li>Open <strong>Audit Logs</strong> and review current row volume.</li>
                            <li>Use the archive cutoff tool only after checking the eligible row count.</li>
                            <li>Open <strong>Audit Archive</strong> and confirm archived rows are searchable.</li>
                            <li>Export a filtered archive view only when a report or handoff requires it.</li>
                        </ol>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div class="card h-100 border-0 bg-light-subtle">
                    <div class="card-body">
                        <div class="text-uppercase small text-muted fw-semibold mb-2">Operational Notes</div>
                        <ul class="mb-0">
                            <li>Do not delete live audit rows first. Archive them first.</li>
                            <li>Use a clear cutoff date, typically older than 12 months.</li>
                            <li>Keep the audit page focused on signal, not passive click noise.</li>
                            <li>When reviewing incidents, check both live and archive views before concluding history is missing.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
