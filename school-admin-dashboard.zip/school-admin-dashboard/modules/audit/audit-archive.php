<?php
require_once __DIR__ . '/../../includes/admin-session.php';
if (!defined('AUDIT_ARCHIVE_EMBEDDED')) {
    admin_session_require_login();
} else {
    admin_session_start();
}
require '../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');

$currentRole = $_SESSION['role'] ?? '';
if (!hasPermission($currentRole, 'audit_logs', 'view')) {
    admin_session_forbidden();
}

if (!audit_logs_ensure_archive_table($conn)) {
    die('Unable to load audit archive.');
}

function audit_archive_trim_filter(?string $value): string {
    return trim((string) $value);
}

function audit_archive_query_value(array $filters, string $key): string {
    return isset($filters[$key]) ? (string) $filters[$key] : '';
}

function audit_archive_build_query(array $overrides = []): string {
    $params = $_GET;
    foreach ($overrides as $key => $value) {
        if ($value === null || $value === '') {
            unset($params[$key]);
        } else {
            $params[$key] = $value;
        }
    }

    $query = http_build_query($params);
    return $query === '' ? '' : '?' . $query;
}

function audit_archive_filter_options(mysqli $conn, string $column): array {
    $allowed = ['user', 'module', 'level', 'archived_by'];
    if (!in_array($column, $allowed, true)) {
        return [];
    }

    $options = [];
    $sql = "SELECT DISTINCT {$column} AS option_value
        FROM audit_logs_archive
        WHERE {$column} IS NOT NULL AND TRIM({$column}) <> ''
        ORDER BY {$column} ASC";
    if ($result = $conn->query($sql)) {
        while ($row = $result->fetch_assoc()) {
            $options[] = (string) $row['option_value'];
        }
        $result->close();
    }

    return $options;
}

function audit_archive_lookup_student_names(mysqli $conn, array $studentIds): array {
    $ids = array_values(array_unique(array_map('intval', $studentIds)));
    $names = [];
    if (!$ids) {
        return $names;
    }

    foreach (array_chunk($ids, 500) as $chunk) {
        $placeholders = implode(',', array_fill(0, count($chunk), '?'));
        $types = str_repeat('i', count($chunk));
        $sql = "SELECT id, lastname, firstname FROM students WHERE id IN ({$placeholders})";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            continue;
        }
        $stmt->bind_param($types, ...$chunk);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $names[(int) $row['id']] = (string) $row['lastname'] . ', ' . (string) $row['firstname'];
        }
        $stmt->close();
    }

    return $names;
}

function audit_archive_format_date($datetime): string {
    if (!$datetime) {
        return '';
    }
    $ts = strtotime((string) $datetime);
    return $ts ? date('m-d-Y h:i A', $ts) : '';
}

function audit_archive_level_badge(?string $level): string {
    $upper = strtoupper(trim((string) $level));
    if ($upper === '') {
        return '<span class="badge bg-secondary">INFO</span>';
    }
    switch ($upper) {
        case 'ERROR':
            return '<span class="badge bg-danger">ERROR</span>';
        case 'SECURITY':
            return '<span class="badge bg-warning text-dark">SECURITY</span>';
        case 'WARNING':
            return '<span class="badge bg-warning text-dark">WARNING</span>';
        default:
            return '<span class="badge bg-secondary">' . htmlspecialchars($upper) . '</span>';
    }
}

$filters = [
    'keyword' => audit_archive_trim_filter($_GET['keyword'] ?? ''),
    'level' => audit_archive_trim_filter($_GET['level'] ?? ''),
    'module' => audit_archive_trim_filter($_GET['module'] ?? ''),
    'user' => audit_archive_trim_filter($_GET['user'] ?? ''),
    'archived_by' => audit_archive_trim_filter($_GET['archived_by'] ?? ''),
    'date_from' => audit_archive_trim_filter($_GET['date_from'] ?? ''),
    'date_to' => audit_archive_trim_filter($_GET['date_to'] ?? ''),
];

$limit = 30;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $limit;
$whereClauses = [];
$params = [];
$types = '';

if ($filters['keyword'] !== '') {
    $keyword = '%' . $filters['keyword'] . '%';
    $whereClauses[] = '(action LIKE ? OR module LIKE ? OR details LIKE ? OR user LIKE ? OR archived_by LIKE ?)';
    $params[] = $keyword;
    $params[] = $keyword;
    $params[] = $keyword;
    $params[] = $keyword;
    $params[] = $keyword;
    $types .= 'sssss';
}

if ($filters['level'] !== '') {
    $whereClauses[] = 'level = ?';
    $params[] = $filters['level'];
    $types .= 's';
}

if ($filters['module'] !== '') {
    $whereClauses[] = 'module = ?';
    $params[] = $filters['module'];
    $types .= 's';
}

if ($filters['user'] !== '') {
    $whereClauses[] = 'user = ?';
    $params[] = $filters['user'];
    $types .= 's';
}

if ($filters['archived_by'] !== '') {
    $whereClauses[] = 'archived_by = ?';
    $params[] = $filters['archived_by'];
    $types .= 's';
}

if ($filters['date_from'] !== '') {
    $whereClauses[] = 'DATE(log_date) >= ?';
    $params[] = $filters['date_from'];
    $types .= 's';
}

if ($filters['date_to'] !== '') {
    $whereClauses[] = 'DATE(log_date) <= ?';
    $params[] = $filters['date_to'];
    $types .= 's';
}

$whereSql = $whereClauses ? (' WHERE ' . implode(' AND ', $whereClauses)) : '';

$summarySql = "SELECT
    COUNT(*) AS total_logs,
    SUM(CASE WHEN DATE(archived_at) = CURDATE() THEN 1 ELSE 0 END) AS archived_today,
    SUM(CASE WHEN level = 'SECURITY' THEN 1 ELSE 0 END) AS security_logs,
    MAX(log_date) AS latest_original_log,
    MAX(archived_at) AS latest_archive_run
    FROM audit_logs_archive{$whereSql}";
$summaryStmt = $conn->prepare($summarySql);
if ($summaryStmt === false) {
    die('Unable to load audit archive summaries.');
}
if ($types !== '') {
    $summaryStmt->bind_param($types, ...$params);
}
$summaryStmt->execute();
$summaryResult = $summaryStmt->get_result();
$summary = $summaryResult ? $summaryResult->fetch_assoc() : [];
$summaryStmt->close();

$countSql = "SELECT COUNT(*) AS total FROM audit_logs_archive{$whereSql}";
$countStmt = $conn->prepare($countSql);
if ($countStmt === false) {
    die('Unable to load audit archive.');
}
if ($types !== '') {
    $countStmt->bind_param($types, ...$params);
}
$countStmt->execute();
$countResult = $countStmt->get_result();
$row = $countResult ? $countResult->fetch_assoc() : ['total' => 0];
$totalRows = (int) ($row['total'] ?? 0);
$countStmt->close();

$totalPages = max(1, (int) ceil($totalRows / $limit));
if ($page > $totalPages) {
    $page = $totalPages;
    $offset = ($page - 1) * $limit;
}

$sql = "SELECT id, source_log_id, user, action, module, details, level, log_date, archived_at, archived_by
    FROM audit_logs_archive{$whereSql}
    ORDER BY archived_at DESC, log_date DESC
    LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die('Unable to load audit archive rows.');
}
$queryParams = $params;
$queryTypes = $types . 'ii';
$queryParams[] = $limit;
$queryParams[] = $offset;
$stmt->bind_param($queryTypes, ...$queryParams);
$stmt->execute();
$stmt->bind_result($id, $sourceLogId, $rowUser, $action, $module, $details, $level, $logDate, $archivedAt, $archivedBy);

$archiveLogs = [];
$studentIdsToFetch = [];
while ($stmt->fetch()) {
    $studentId = null;
    if (
        preg_match('/Accessed edit student page|Edited student/i', (string) $action) &&
        preg_match('/Student ID: (\d+)/', (string) $details, $matches)
    ) {
        $studentId = (int) $matches[1];
        $studentIdsToFetch[$studentId] = true;
    }

    if ($currentRole === 'Administrator') {
        $details = str_replace('Super Administrator', 'Administrator', (string) $details);
    }

    $archiveLogs[] = [
        'id' => $id,
        'source_log_id' => $sourceLogId,
        'user' => $rowUser,
        'action' => $action,
        'module' => $module,
        'details' => $details,
        'level' => $level,
        'log_date' => $logDate,
        'archived_at' => $archivedAt,
        'archived_by' => $archivedBy,
        'student_id' => $studentId,
    ];
}
$stmt->close();

$studentNames = [];
if (!empty($studentIdsToFetch)) {
    $studentNames = audit_archive_lookup_student_names($conn, array_keys($studentIdsToFetch));
}

foreach ($archiveLogs as &$log) {
    if ($log['student_id'] && isset($studentNames[$log['student_id']])) {
        $log['details'] = preg_replace(
            '/Student ID: ' . $log['student_id'] . '/',
            'Student: ' . $studentNames[$log['student_id']],
            (string) $log['details']
        );
    }
}
unset($log);

$userOptions = audit_archive_filter_options($conn, 'user');
$moduleOptions = audit_archive_filter_options($conn, 'module');
$levelOptions = audit_archive_filter_options($conn, 'level');
$archivedByOptions = audit_archive_filter_options($conn, 'archived_by');
$hasActiveFilters = implode('', $filters) !== '';
$isEmbedded = basename($_SERVER['PHP_SELF'] ?? '') !== 'audit-archive.php';
?>
<?php if (!$isEmbedded): ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Audit Archive</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
<?php endif; ?>

<div class="container-fluid px-0">
    <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-3 mb-3">
        <div>
            <h2 class="mb-1">Audit Archive</h2>
            <p class="text-muted mb-0">Search historical audit logs that were already moved out of the live audit table.</p>
        </div>
        <?php if ($isEmbedded): ?>
            <a class="btn btn-outline-secondary" href="audit-archive.php">Open Full Page</a>
        <?php endif; ?>
    </div>

    <div class="row g-3 mb-3">
        <div class="col-12 col-md-6 col-xl-3">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="text-uppercase small text-muted fw-semibold">Archived Logs</div>
                    <div class="fs-3 fw-bold text-dark"><?= (int) ($summary['total_logs'] ?? 0) ?></div>
                    <div class="small text-muted">Rows in the archive view</div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6 col-xl-3">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="text-uppercase small text-muted fw-semibold">Archived Today</div>
                    <div class="fs-3 fw-bold text-primary"><?= (int) ($summary['archived_today'] ?? 0) ?></div>
                    <div class="small text-muted">Rows moved today</div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6 col-xl-3">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="text-uppercase small text-muted fw-semibold">Security Logs</div>
                    <div class="fs-3 fw-bold text-warning"><?= (int) ($summary['security_logs'] ?? 0) ?></div>
                    <div class="small text-muted">Archived security events</div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6 col-xl-3">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="text-uppercase small text-muted fw-semibold">Latest Archive Run</div>
                    <div class="fw-bold text-dark"><?= htmlspecialchars(audit_archive_format_date((string) ($summary['latest_archive_run'] ?? ''))) ?></div>
                    <div class="small text-muted">Last archive timestamp</div>
                </div>
            </div>
        </div>
    </div>

    <form class="card shadow-sm border-0 mb-3" method="get" action="">
        <div class="card-body">
            <div class="row g-3">
                <div class="col-lg-3">
                    <label for="archive-keyword" class="form-label">Keyword</label>
                    <input type="text" class="form-control" id="archive-keyword" name="keyword" value="<?= htmlspecialchars(audit_archive_query_value($filters, 'keyword')) ?>" placeholder="Search action, details, user">
                </div>
                <div class="col-lg-2">
                    <label for="archive-level" class="form-label">Level</label>
                    <select class="form-select" id="archive-level" name="level">
                        <option value="">All levels</option>
                        <?php foreach ($levelOptions as $option): ?>
                            <option value="<?= htmlspecialchars($option) ?>" <?= $filters['level'] === $option ? 'selected' : '' ?>><?= htmlspecialchars($option) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-lg-2">
                    <label for="archive-module" class="form-label">Module</label>
                    <select class="form-select" id="archive-module" name="module">
                        <option value="">All modules</option>
                        <?php foreach ($moduleOptions as $option): ?>
                            <option value="<?= htmlspecialchars($option) ?>" <?= $filters['module'] === $option ? 'selected' : '' ?>><?= htmlspecialchars($option) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-lg-2">
                    <label for="archive-user" class="form-label">User</label>
                    <select class="form-select" id="archive-user" name="user">
                        <option value="">All users</option>
                        <?php foreach ($userOptions as $option): ?>
                            <option value="<?= htmlspecialchars($option) ?>" <?= $filters['user'] === $option ? 'selected' : '' ?>><?= htmlspecialchars($option) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-lg-2">
                    <label for="archive-archived-by" class="form-label">Archived By</label>
                    <select class="form-select" id="archive-archived-by" name="archived_by">
                        <option value="">All archive users</option>
                        <?php foreach ($archivedByOptions as $option): ?>
                            <option value="<?= htmlspecialchars($option) ?>" <?= $filters['archived_by'] === $option ? 'selected' : '' ?>><?= htmlspecialchars($option) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-lg-1">
                    <label for="archive-date-from" class="form-label">From</label>
                    <input type="date" class="form-control" id="archive-date-from" name="date_from" value="<?= htmlspecialchars(audit_archive_query_value($filters, 'date_from')) ?>">
                </div>
                <div class="col-lg-1">
                    <label for="archive-date-to" class="form-label">To</label>
                    <input type="date" class="form-control" id="archive-date-to" name="date_to" value="<?= htmlspecialchars(audit_archive_query_value($filters, 'date_to')) ?>">
                </div>
                <div class="col-lg-1 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">Apply</button>
                </div>
            </div>
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-3">
                <div class="text-muted small">
                    <?= $totalRows ?> archived result<?= $totalRows === 1 ? '' : 's' ?> found<?= $hasActiveFilters ? ' for the current filter set' : '' ?>
                </div>
                <?php if ($hasActiveFilters): ?>
                    <a class="btn btn-sm btn-outline-secondary" href="audit-archive.php">Clear Filters</a>
                <?php endif; ?>
            </div>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle bg-white">
            <thead class="table-dark">
                <tr>
                    <th>User</th>
                    <th>Action</th>
                    <th>Module</th>
                    <th>Details</th>
                    <th>Level</th>
                    <th>Original Date</th>
                    <th>Archived</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$archiveLogs): ?>
                <tr>
                    <td colspan="7" class="text-center text-muted py-4">No archived audit logs found for the selected filters.</td>
                </tr>
            <?php endif; ?>
            <?php foreach ($archiveLogs as $log): ?>
                <tr>
                    <td><?= htmlspecialchars((string) $log['user']) ?></td>
                    <td><?= htmlspecialchars((string) $log['action']) ?></td>
                    <td><?= htmlspecialchars((string) $log['module']) ?></td>
                    <td><?= htmlspecialchars((string) $log['details']) ?></td>
                    <td><?= audit_archive_level_badge((string) $log['level']) ?></td>
                    <td><?= htmlspecialchars(audit_archive_format_date((string) $log['log_date'])) ?></td>
                    <td>
                        <div class="fw-semibold"><?= htmlspecialchars(audit_archive_format_date((string) $log['archived_at'])) ?></div>
                        <div class="small text-muted"><?= htmlspecialchars((string) ($log['archived_by'] ?: 'System')) ?></div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <nav aria-label="Audit archive pagination">
        <ul class="pagination justify-content-center">
            <?php if ($page > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="<?= htmlspecialchars(audit_archive_build_query(['page' => $page - 1])) ?>">Previous</a>
                </li>
            <?php endif; ?>
            <?php
            $start = max(1, $page - 2);
            $end = min($totalPages, $page + 2);
            if ($start > 1) {
                echo '<li class="page-item"><a class="page-link" href="' . htmlspecialchars(audit_archive_build_query(['page' => 1])) . '">1</a></li>';
                if ($start > 2) {
                    echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                }
            }
            for ($p = $start; $p <= $end; $p++):
            ?>
                <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                    <a class="page-link" href="<?= htmlspecialchars(audit_archive_build_query(['page' => $p])) ?>"><?= $p ?></a>
                </li>
            <?php endfor;
            if ($end < $totalPages) {
                if ($end < $totalPages - 1) {
                    echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                }
                echo '<li class="page-item"><a class="page-link" href="' . htmlspecialchars(audit_archive_build_query(['page' => $totalPages])) . '">' . $totalPages . '</a></li>';
            }
            ?>
            <?php if ($page < $totalPages): ?>
                <li class="page-item">
                    <a class="page-link" href="<?= htmlspecialchars(audit_archive_build_query(['page' => $page + 1])) ?>">Next</a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
</div>

<?php if (!$isEmbedded): ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<?= admin_session_warning_script() ?>
</body>
</html>
<?php endif; ?>
<?php $conn->close(); ?>
