<?php

require_once __DIR__ . '/../../includes/schema-migration.php';
require_once __DIR__ . '/../settings/fee-grade-settings-helper.php';
require_once __DIR__ . '/account-fee-exceptions-helper.php';

function finance_adjustment_types(): array
{
    return [
        'voucher' => 'Voucher',
        'subsidy' => 'Subsidy',
        'discount' => 'Discount',
        'grant' => 'Special Grant',
    ];
}

function finance_adjustment_rule_types(): array
{
    return [
        'per_fee_amount' => 'Per Fee Amount',
        'fixed_amount' => 'Fixed Amount',
        'percentage' => 'Percentage',
        'cover_full' => 'Cover Selected Fees Fully',
    ];
}

function finance_adjustment_ensure_tables(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }

    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS finance_adjustment_templates (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(140) NOT NULL,
        adjustment_type VARCHAR(30) NOT NULL DEFAULT 'voucher',
        school_year_label VARCHAR(120) NOT NULL DEFAULT '',
        grade_codes TEXT NOT NULL,
        covered_fee_types TEXT NOT NULL,
        fee_amounts MEDIUMTEXT NULL,
        rule_type VARCHAR(30) NOT NULL DEFAULT 'fixed_amount',
        amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        is_enabled TINYINT(1) NOT NULL DEFAULT 1,
        sort_order INT NOT NULL DEFAULT 0,
        notes TEXT NULL,
        created_by VARCHAR(120) NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_by VARCHAR(120) NULL,
        updated_at DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
        KEY idx_finance_adjustment_school_year (school_year_label),
        KEY idx_finance_adjustment_type (adjustment_type),
        KEY idx_finance_adjustment_enabled (is_enabled)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS student_finance_adjustments (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        template_id INT NOT NULL,
        school_year_label VARCHAR(120) NOT NULL,
        status VARCHAR(30) NOT NULL DEFAULT 'applied',
        applied_snapshot MEDIUMTEXT NULL,
        applied_by VARCHAR(120) NULL,
        applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        reverted_by VARCHAR(120) NULL,
        reverted_at DATETIME NULL,
        KEY idx_student_finance_adjustment_student (student_id, school_year_label),
        KEY idx_student_finance_adjustment_template (template_id),
        KEY idx_student_finance_adjustment_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $templateExtraColumns = [
        'fee_amounts' => "ALTER TABLE finance_adjustment_templates ADD COLUMN fee_amounts MEDIUMTEXT NULL AFTER covered_fee_types",
    ];
    foreach ($templateExtraColumns as $column => $sql) {
        $columnInfo = $conn->query("SHOW COLUMNS FROM finance_adjustment_templates LIKE '" . $conn->real_escape_string($column) . "'");
        $exists = $columnInfo && $columnInfo->num_rows > 0;
        if ($columnInfo) {
            $columnInfo->close();
        }
        if (!$exists) {
            schema_migration_attempt($conn, $sql);
        }
    }

    $extraColumns = [
        'reverted_by' => "ALTER TABLE student_finance_adjustments ADD COLUMN reverted_by VARCHAR(120) NULL AFTER applied_at",
        'reverted_at' => "ALTER TABLE student_finance_adjustments ADD COLUMN reverted_at DATETIME NULL AFTER reverted_by",
    ];
    foreach ($extraColumns as $column => $sql) {
        $columnInfo = $conn->query("SHOW COLUMNS FROM student_finance_adjustments LIKE '" . $conn->real_escape_string($column) . "'");
        $exists = $columnInfo && $columnInfo->num_rows > 0;
        if ($columnInfo) {
            $columnInfo->close();
        }
        if (!$exists) {
            schema_migration_attempt($conn, $sql);
        }
    }
}

function finance_adjustment_tables_ready(mysqli $conn): bool
{
    foreach (['finance_adjustment_templates', 'student_finance_adjustments'] as $tableName) {
        $result = $conn->query("SHOW TABLES LIKE '" . $conn->real_escape_string($tableName) . "'");
        $ready = $result && $result->num_rows > 0;
        if ($result) {
            $result->close();
        }
        if (!$ready) {
            return false;
        }
    }

    $feeAmountsColumn = $conn->query("SHOW COLUMNS FROM finance_adjustment_templates LIKE 'fee_amounts'");
    $hasFeeAmountsColumn = $feeAmountsColumn && $feeAmountsColumn->num_rows > 0;
    if ($feeAmountsColumn) {
        $feeAmountsColumn->close();
    }
    if (!$hasFeeAmountsColumn) {
        return false;
    }

    return true;
}

function finance_adjustment_encode_list(array $values): string
{
    $clean = [];
    foreach ($values as $value) {
        $value = trim((string) $value);
        if ($value !== '' && !in_array($value, $clean, true)) {
            $clean[] = $value;
        }
    }

    return json_encode(array_values($clean));
}

function finance_adjustment_decode_list(?string $value): array
{
    $decoded = json_decode((string) $value, true);
    if (!is_array($decoded)) {
        return [];
    }

    $clean = [];
    foreach ($decoded as $item) {
        $item = trim((string) $item);
        if ($item !== '' && !in_array($item, $clean, true)) {
            $clean[] = $item;
        }
    }

    return $clean;
}

function finance_adjustment_encode_amount_map(array $values): string
{
    $clean = [];
    foreach ($values as $feeTypeName => $amount) {
        $feeTypeName = trim((string) $feeTypeName);
        if ($feeTypeName === '') {
            continue;
        }
        $amountValue = (float) str_replace(',', '', (string) $amount);
        if ($amountValue <= 0) {
            continue;
        }
        $clean[$feeTypeName] = round($amountValue, 2);
    }

    return json_encode($clean);
}

function finance_adjustment_decode_amount_map(?string $value): array
{
    $decoded = json_decode((string) $value, true);
    if (!is_array($decoded)) {
        return [];
    }

    $clean = [];
    foreach ($decoded as $feeTypeName => $amount) {
        $feeTypeName = trim((string) $feeTypeName);
        $amountValue = (float) $amount;
        if ($feeTypeName !== '' && $amountValue > 0) {
            $clean[$feeTypeName] = round($amountValue, 2);
        }
    }

    return $clean;
}

function finance_adjustment_account_type_options(mysqli $conn): array
{
    $rows = [];
    $result = $conn->query("SELECT name FROM account_types ORDER BY priority ASC, name ASC");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $name = trim((string) ($row['name'] ?? ''));
            if ($name !== '') {
                $rows[] = $name;
            }
        }
        $result->close();
    }

    return $rows;
}

function finance_adjustment_template_from_row(array $row): array
{
    $row['id'] = (int) ($row['id'] ?? 0);
    $row['amount'] = (float) ($row['amount'] ?? 0);
    $row['is_enabled'] = (int) ($row['is_enabled'] ?? 0);
    $row['sort_order'] = (int) ($row['sort_order'] ?? 0);
    $row['grade_codes_list'] = finance_adjustment_decode_list($row['grade_codes'] ?? '[]');
    $row['covered_fee_types_list'] = finance_adjustment_decode_list($row['covered_fee_types'] ?? '[]');
    $row['fee_amounts_map'] = finance_adjustment_decode_amount_map($row['fee_amounts'] ?? '{}');

    return $row;
}

function finance_adjustment_templates(mysqli $conn, bool $activeOnly = false): array
{
    if (!finance_adjustment_tables_ready($conn)) {
        return [];
    }

    $sql = "SELECT * FROM finance_adjustment_templates";
    if ($activeOnly) {
        $sql .= " WHERE is_enabled = 1";
    }
    $sql .= " ORDER BY sort_order ASC, name ASC";

    $rows = [];
    $result = $conn->query($sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $rows[] = finance_adjustment_template_from_row($row);
        }
        $result->close();
    }

    return $rows;
}

function finance_adjustment_save_template(mysqli $conn, array $data, string $username): bool
{
    if (!finance_adjustment_tables_ready($conn)) {
        return false;
    }

    $id = (int) ($data['id'] ?? 0);
    $name = trim((string) ($data['name'] ?? ''));
    $type = trim((string) ($data['adjustment_type'] ?? 'voucher'));
    $schoolYear = trim((string) ($data['school_year_label'] ?? ''));
    $ruleType = 'per_fee_amount';
    $feeAmountMap = finance_adjustment_decode_amount_map(finance_adjustment_encode_amount_map($data['fee_amounts'] ?? []));
    $amount = array_sum($feeAmountMap);
    $isEnabled = !empty($data['is_enabled']) ? 1 : 0;
    $sortOrder = (int) ($data['sort_order'] ?? 0);
    $notes = trim((string) ($data['notes'] ?? ''));
    $gradeCodes = finance_adjustment_encode_list($data['grade_codes'] ?? []);
    $coveredFeeTypes = finance_adjustment_encode_list(array_keys($feeAmountMap));
    $feeAmounts = finance_adjustment_encode_amount_map($feeAmountMap);

    if ($name === '' || $schoolYear === '' || !array_key_exists($type, finance_adjustment_types())) {
        return false;
    }
    if (finance_adjustment_decode_list($gradeCodes) === [] || $feeAmountMap === []) {
        return false;
    }

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE finance_adjustment_templates
            SET name = ?, adjustment_type = ?, school_year_label = ?, grade_codes = ?, covered_fee_types = ?, fee_amounts = ?, rule_type = ?, amount = ?, is_enabled = ?, sort_order = ?, notes = ?, updated_by = ?
            WHERE id = ?");
        if (!$stmt) {
            return false;
        }
        $stmt->bind_param('sssssssdiissi', $name, $type, $schoolYear, $gradeCodes, $coveredFeeTypes, $feeAmounts, $ruleType, $amount, $isEnabled, $sortOrder, $notes, $username, $id);
    } else {
        $stmt = $conn->prepare("INSERT INTO finance_adjustment_templates
            (name, adjustment_type, school_year_label, grade_codes, covered_fee_types, fee_amounts, rule_type, amount, is_enabled, sort_order, notes, created_by, updated_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        if (!$stmt) {
            return false;
        }
        $stmt->bind_param('sssssssdiisss', $name, $type, $schoolYear, $gradeCodes, $coveredFeeTypes, $feeAmounts, $ruleType, $amount, $isEnabled, $sortOrder, $notes, $username, $username);
    }

    $success = $stmt->execute();
    $stmt->close();

    return $success;
}

function finance_adjustment_disable_template(mysqli $conn, int $id, string $username): bool
{
    if (!finance_adjustment_tables_ready($conn) || $id <= 0) {
        return false;
    }

    $stmt = $conn->prepare("UPDATE finance_adjustment_templates SET is_enabled = 0, updated_by = ? WHERE id = ?");
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('si', $username, $id);
    $success = $stmt->execute();
    $stmt->close();

    return $success;
}

function finance_adjustment_applicable_templates(mysqli $conn, string $studentGrade, string $schoolYearLabel): array
{
    $gradeCode = student_fee_grade_code_for_grade($conn, $studentGrade);
    if ($gradeCode === 0 || trim($schoolYearLabel) === '') {
        return [];
    }

    $rows = [];
    foreach (finance_adjustment_templates($conn, true) as $template) {
        if ((string) ($template['school_year_label'] ?? '') !== $schoolYearLabel) {
            continue;
        }
        if (!in_array((string) $gradeCode, $template['grade_codes_list'], true)) {
            continue;
        }
        $rows[] = $template;
    }

    return $rows;
}

function finance_adjustment_applied_map(mysqli $conn, int $studentId, string $schoolYearLabel): array
{
    if (!finance_adjustment_tables_ready($conn)) {
        return [];
    }

    $rows = [];
    $stmt = $conn->prepare("SELECT id, template_id, status, applied_by, applied_at FROM student_finance_adjustments WHERE student_id = ? AND school_year_label = ? AND status = 'applied'");
    if (!$stmt) {
        return [];
    }
    $stmt->bind_param('is', $studentId, $schoolYearLabel);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $rows[(int) ($row['template_id'] ?? 0)] = $row;
    }
    $stmt->close();

    return $rows;
}

function finance_adjustment_applied_rows(mysqli $conn, int $studentId, string $schoolYearLabel): array
{
    if (!finance_adjustment_tables_ready($conn)) {
        return [];
    }

    $rows = [];
    $stmt = $conn->prepare("SELECT sfa.*, fat.name, fat.adjustment_type, fat.rule_type, fat.amount
        FROM student_finance_adjustments sfa
        LEFT JOIN finance_adjustment_templates fat ON fat.id = sfa.template_id
        WHERE sfa.student_id = ? AND sfa.school_year_label = ?
        ORDER BY sfa.applied_at DESC, sfa.id DESC");
    if (!$stmt) {
        return [];
    }
    $stmt->bind_param('is', $studentId, $schoolYearLabel);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $row['id'] = (int) ($row['id'] ?? 0);
        $row['template_id'] = (int) ($row['template_id'] ?? 0);
        $row['amount'] = (float) ($row['amount'] ?? 0);
        $snapshot = json_decode((string) ($row['applied_snapshot'] ?? ''), true);
        $row['snapshot'] = is_array($snapshot) ? $snapshot : ['items' => []];
        $rows[] = $row;
    }
    $stmt->close();

    return $rows;
}

function finance_adjustment_preview(array $template, array $templateRows, array $accountStateMap, array $exceptionMap = []): array
{
    $templateMap = [];
    foreach ($templateRows as $row) {
        $templateMap[(string) ($row['fee_type_name'] ?? '')] = $row;
    }

    $feeAmountMap = $template['fee_amounts_map'] ?? [];
    if (!is_array($feeAmountMap)) {
        $feeAmountMap = [];
    }
    $remainingCredit = (float) ($template['amount'] ?? 0);
    $ruleType = (string) ($template['rule_type'] ?? 'fixed_amount');
    $items = [];
    $totalOriginal = 0.0;
    $totalTarget = 0.0;
    $totalApplied = 0.0;
    $skipped = 0;

    $coveredFees = $feeAmountMap !== [] ? array_keys($feeAmountMap) : ($template['covered_fee_types_list'] ?? []);
    foreach ($coveredFees as $feeTypeName) {
        $configuredAmount = (float) ($feeAmountMap[$feeTypeName] ?? 0);
        if (!isset($templateMap[$feeTypeName])) {
            $items[] = [
                'fee_type_name' => $feeTypeName,
                'status' => 'missing_template',
                'configured_amount' => $configuredAmount,
                'original_amount' => 0.0,
                'target_amount' => 0.0,
                'applied_amount' => 0.0,
                'payment_count' => 0,
            ];
            $skipped++;
            continue;
        }

        $original = (float) ($templateMap[$feeTypeName]['default_amount'] ?? 0);
        $paymentCount = (int) (($accountStateMap[$feeTypeName]['payment_count'] ?? 0));
        $existingException = $exceptionMap[$feeTypeName] ?? null;
        $target = $original;
        if ($feeAmountMap !== []) {
            $applied = min($original, max(0.0, $configuredAmount));
            $target = max(0.0, $original - $applied);
        } elseif ($ruleType === 'cover_full') {
            $target = 0.0;
        } elseif ($ruleType === 'percentage') {
            $percentage = max(0.0, min(100.0, (float) ($template['amount'] ?? 0)));
            $target = max(0.0, $original - ($original * ($percentage / 100)));
        } else {
            $applied = min($original, max(0.0, $remainingCredit));
            $target = max(0.0, $original - $applied);
            $remainingCredit -= $applied;
        }

        $appliedAmount = max(0.0, $original - $target);
        $status = $paymentCount > 0 ? 'locked_paid' : ($appliedAmount > 0.009 ? 'ready' : 'unchanged');
        if ($existingException && (string) ($existingException['mode'] ?? 'default') !== 'default') {
            $status = 'already_adjusted';
        }
        if ($status === 'locked_paid') {
            $skipped++;
        } elseif ($status === 'already_adjusted') {
            $skipped++;
        } else {
            $totalOriginal += $original;
            $totalTarget += $target;
            $totalApplied += $appliedAmount;
        }

        $items[] = [
            'fee_type_name' => $feeTypeName,
            'status' => $status,
            'configured_amount' => $configuredAmount,
            'original_amount' => $original,
            'target_amount' => $target,
            'applied_amount' => $appliedAmount,
            'payment_count' => $paymentCount,
            'existing_source_type' => $existingException ? (string) ($existingException['source_type'] ?? 'manual') : '',
            'existing_source_label' => $existingException ? (string) ($existingException['source_label'] ?? '') : '',
        ];
    }

    return [
        'items' => $items,
        'total_original' => $totalOriginal,
        'total_target' => $totalTarget,
        'total_applied' => $totalApplied,
        'skipped' => $skipped,
        'ready_count' => count(array_filter($items, static function ($item): bool {
            return ($item['status'] ?? '') === 'ready';
        })),
    ];
}

function finance_adjustment_apply_template(mysqli $conn, int $studentId, string $studentGrade, string $schoolYearLabel, int $templateId, string $username): array
{
    if (!finance_adjustment_tables_ready($conn)) {
        throw new RuntimeException('Finance adjustment schema is not ready.');
    }

    $template = null;
    foreach (finance_adjustment_applicable_templates($conn, $studentGrade, $schoolYearLabel) as $row) {
        if ((int) ($row['id'] ?? 0) === $templateId) {
            $template = $row;
            break;
        }
    }
    if (!$template) {
        throw new RuntimeException('That adjustment template is not applicable to this student.');
    }

    $templateRows = student_fee_template_rows($conn, $studentGrade, $schoolYearLabel);
    $templateMap = [];
    foreach ($templateRows as $templateRow) {
        $templateMap[(string) $templateRow['fee_type_name']] = $templateRow;
    }
    $accountStateMap = student_fee_account_state_map($conn, $studentId, $schoolYearLabel);
    $exceptionMap = student_fee_exception_map($conn, $studentId, $schoolYearLabel);
    $preview = finance_adjustment_preview($template, $templateRows, $accountStateMap, $exceptionMap);

    $initialSnapshotJson = json_encode([
        'template' => [
            'id' => (int) $template['id'],
            'name' => (string) $template['name'],
            'type' => (string) $template['adjustment_type'],
            'rule_type' => (string) $template['rule_type'],
            'amount' => (float) $template['amount'],
            'fee_amounts' => $template['fee_amounts_map'] ?? [],
        ],
        'items' => [],
    ]);
    $recordStmt = $conn->prepare("INSERT INTO student_finance_adjustments (student_id, template_id, school_year_label, status, applied_snapshot, applied_by) VALUES (?, ?, ?, 'applied', ?, ?)");
    if (!$recordStmt) {
        throw new RuntimeException('Could not record applied finance adjustment.');
    }
    $recordStmt->bind_param('iisss', $studentId, $templateId, $schoolYearLabel, $initialSnapshotJson, $username);
    if (!$recordStmt->execute()) {
        $recordStmt->close();
        throw new RuntimeException('Could not record applied finance adjustment.');
    }
    $appliedAdjustmentId = (int) $recordStmt->insert_id;
    $recordStmt->close();

    $changed = 0;
    $skipped = 0;
    $accountActions = ['added' => 0, 'updated' => 0, 'removed' => 0, 'unchanged' => 0, 'preserved_paid' => 0, 'skipped_missing' => 0];
    $snapshot = [
        'template' => [
            'id' => (int) $template['id'],
            'name' => (string) $template['name'],
            'type' => (string) $template['adjustment_type'],
            'rule_type' => (string) $template['rule_type'],
            'amount' => (float) $template['amount'],
            'fee_amounts' => $template['fee_amounts_map'] ?? [],
        ],
        'items' => [],
    ];

    foreach ($preview['items'] as $item) {
        $feeTypeName = (string) $item['fee_type_name'];
        if (($item['status'] ?? '') !== 'ready') {
            $skipped++;
            $snapshot['items'][] = $item;
            continue;
        }
        if (!isset($templateMap[$feeTypeName])) {
            $skipped++;
            $snapshot['items'][] = $item;
            continue;
        }

        $note = 'Applied by ' . (string) $template['name'] . ' shortcut | Original PHP '
            . number_format((float) $item['original_amount'], 2)
            . ' | Target PHP ' . number_format((float) $item['target_amount'], 2);
        student_fee_exception_upsert(
            $conn,
            $studentId,
            $schoolYearLabel,
            $feeTypeName,
            'override',
            (float) $item['target_amount'],
            $note,
            $username,
            'finance_adjustment',
            $appliedAdjustmentId,
            (string) $template['name']
        );
        $apply = student_fee_apply_effective_account_rule($conn, $studentId, $schoolYearLabel, $feeTypeName, (float) $item['target_amount'], false, 'Auto-added from finance adjustment shortcut');
        $status = (string) ($apply['status'] ?? 'unchanged');
        if (isset($accountActions[$status])) {
            $accountActions[$status]++;
        }
        $snapshot['items'][] = array_merge($item, ['account_action' => $status]);
        $changed++;
    }

    if ($changed === 0) {
        throw new RuntimeException('No remaining fee rows were changed. Existing adjustments, missing fee rows, and paid fee rows are skipped for safety.');
    }

    $snapshotJson = json_encode($snapshot);
    $stmt = $conn->prepare("UPDATE student_finance_adjustments SET applied_snapshot = ? WHERE id = ?");
    if (!$stmt) {
        throw new RuntimeException('Could not update applied finance adjustment snapshot.');
    }
    $stmt->bind_param('si', $snapshotJson, $appliedAdjustmentId);
    if (!$stmt->execute()) {
        $stmt->close();
        throw new RuntimeException('Could not update applied finance adjustment snapshot.');
    }
    $stmt->close();

    return [
        'changed' => $changed,
        'skipped' => $skipped,
        'total_applied' => (float) $preview['total_applied'],
        'account_actions' => $accountActions,
    ];
}

function finance_adjustment_revert(mysqli $conn, int $studentId, string $schoolYearLabel, int $studentAdjustmentId, string $username): array
{
    if (!finance_adjustment_tables_ready($conn)) {
        throw new RuntimeException('Finance adjustment schema is not ready.');
    }
    if (!student_fee_exception_source_columns_ready($conn)) {
        throw new RuntimeException('Fee exception source tracking is not ready. Run the migration tool first.');
    }

    $stmt = $conn->prepare("SELECT * FROM student_finance_adjustments WHERE id = ? AND student_id = ? AND school_year_label = ? AND status = 'applied' LIMIT 1");
    if (!$stmt) {
        throw new RuntimeException('Could not load applied adjustment.');
    }
    $stmt->bind_param('iis', $studentAdjustmentId, $studentId, $schoolYearLabel);
    $stmt->execute();
    $record = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$record) {
        throw new RuntimeException('Applied adjustment was not found or is already reverted.');
    }

    $snapshot = json_decode((string) ($record['applied_snapshot'] ?? ''), true);
    $items = is_array($snapshot) ? ($snapshot['items'] ?? []) : [];
    $accountStateMap = student_fee_account_state_map($conn, $studentId, $schoolYearLabel);
    foreach ($items as $item) {
        $feeTypeName = (string) ($item['fee_type_name'] ?? '');
        if ($feeTypeName === '' || ($item['account_action'] ?? '') === '') {
            continue;
        }
        if ((int) (($accountStateMap[$feeTypeName]['payment_count'] ?? 0)) > 0) {
            throw new RuntimeException('Revert is locked because at least one affected fee has payment activity. Use manual override instead.');
        }
    }

    $deleted = 0;
    foreach ($items as $item) {
        $feeTypeName = (string) ($item['fee_type_name'] ?? '');
        if ($feeTypeName === '' || ($item['account_action'] ?? '') === '') {
            continue;
        }
        $del = $conn->prepare("DELETE FROM student_fee_exceptions WHERE student_id = ? AND school_year_label = ? AND fee_type_name = ? AND source_type = 'finance_adjustment' AND source_ref_id = ?");
        if (!$del) {
            throw new RuntimeException('Could not prepare adjustment revert.');
        }
        $del->bind_param('issi', $studentId, $schoolYearLabel, $feeTypeName, $studentAdjustmentId);
        $del->execute();
        $deleted += max(0, (int) $del->affected_rows);
        $del->close();

        $accountAction = (string) ($item['account_action'] ?? '');
        if ($accountAction === 'added') {
            $removeAccount = $conn->prepare("DELETE FROM accounts WHERE student_id = ? AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ? AND type = ?");
            if (!$removeAccount) {
                throw new RuntimeException('Could not remove reverted adjustment account row.');
            }
            $removeAccount->bind_param('isss', $studentId, $schoolYearLabel, $schoolYearLabel, $feeTypeName);
            $removeAccount->execute();
            $removeAccount->close();
        } else {
            $originalAmount = (float) ($item['original_amount'] ?? 0);
            $restoreAccount = $conn->prepare("UPDATE accounts SET balance = ? WHERE student_id = ? AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ? AND type = ?");
            if (!$restoreAccount) {
                throw new RuntimeException('Could not restore reverted adjustment account balance.');
            }
            $restoreAccount->bind_param('disss', $originalAmount, $studentId, $schoolYearLabel, $schoolYearLabel, $feeTypeName);
            $restoreAccount->execute();
            $restoreAccount->close();
        }
    }

    $upd = $conn->prepare("UPDATE student_finance_adjustments SET status = 'reverted', reverted_by = ?, reverted_at = NOW() WHERE id = ?");
    if (!$upd) {
        throw new RuntimeException('Could not mark adjustment as reverted.');
    }
    $upd->bind_param('si', $username, $studentAdjustmentId);
    $upd->execute();
    $upd->close();

    return ['deleted_exceptions' => $deleted];
}

function finance_adjustment_review_rows(mysqli $conn, string $schoolYearLabel = '', string $status = '', string $adjustmentType = '', string $keyword = ''): array
{
    if (!finance_adjustment_tables_ready($conn)) {
        return [];
    }

    $where = ['1=1'];
    $params = [];
    $types = '';

    if (trim($schoolYearLabel) !== '') {
        $where[] = 'sfa.school_year_label = ?';
        $params[] = trim($schoolYearLabel);
        $types .= 's';
    }
    if (trim($status) !== '' && in_array($status, ['applied', 'reverted'], true)) {
        $where[] = 'sfa.status = ?';
        $params[] = trim($status);
        $types .= 's';
    }
    if (trim($adjustmentType) !== '' && array_key_exists($adjustmentType, finance_adjustment_types())) {
        $where[] = 'fat.adjustment_type = ?';
        $params[] = trim($adjustmentType);
        $types .= 's';
    }
    if (trim($keyword) !== '') {
        $where[] = "(CONCAT(s.lastname, ', ', s.firstname, ' ', s.middlename) LIKE ? OR fat.name LIKE ? OR sfa.applied_by LIKE ?)";
        $like = '%' . trim($keyword) . '%';
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
        $types .= 'sss';
    }

    $sql = "SELECT sfa.*, fat.name, fat.adjustment_type, fat.rule_type, fat.amount, s.grade,
            CONCAT(s.lastname, ', ', s.firstname, ' ', s.middlename) AS student_name
        FROM student_finance_adjustments sfa
        LEFT JOIN finance_adjustment_templates fat ON fat.id = sfa.template_id
        LEFT JOIN students s ON s.id = sfa.student_id
        WHERE " . implode(' AND ', $where) . "
        ORDER BY sfa.applied_at DESC, sfa.id DESC";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return [];
    }
    if ($params) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $snapshot = json_decode((string) ($row['applied_snapshot'] ?? ''), true);
        $items = is_array($snapshot) ? ($snapshot['items'] ?? []) : [];
        $effect = 0.0;
        $affected = 0;
        foreach ($items as $item) {
            if (($item['account_action'] ?? '') === '') {
                continue;
            }
            $affected++;
            $effect += (float) ($item['applied_amount'] ?? 0);
        }
        $row['affected_count'] = $affected;
        $row['total_effect'] = $effect;
        $rows[] = $row;
    }
    $stmt->close();

    return $rows;
}
