<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
include '../../config/database.php';
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require_once __DIR__ . '/../../includes/record-conflict-helper.php';
include __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/settings-security.php';
require_once __DIR__ . '/../settings/upload-storage-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php';

// Permissions: Only allow users with financial:view for viewing, and financial:edit for inline editing
$currentRole = $_SESSION['role'] ?? '';
$can_view = hasPermission($currentRole, 'financial', 'view');
$can_edit = hasPermission($currentRole, 'financial', 'edit');

// Block access if user can't view accounts
if (!$can_view) {
    admin_session_forbidden();
}

// Get student_id from query string
$student_id = isset($_GET['student_id']) ? intval($_GET['student_id']) : 0;
$school_year_filter = trim($_GET['school_year'] ?? '');
$legacy_mode = isset($_GET['legacy']) && $_GET['legacy'] === '1';
$error = "";
$student = [];
$accounts = [];

// Phase down this legacy route in favor of the current account overview/edit pages.
if ($_SERVER['REQUEST_METHOD'] === 'GET' && !$legacy_mode) {
    if (isset($_GET['edit_id']) && (int) $_GET['edit_id'] > 0) {
        header('Location: account-edit.php?id=' . (int) $_GET['edit_id']);
        exit;
    }

    if ($student_id > 0) {
        $target = 'account-view.php?student_id=' . $student_id;
        if ($school_year_filter !== '') {
            $target .= '&school_year=' . urlencode($school_year_filter);
        }
        header('Location: ' . $target);
        exit;
    }
}

// Handle inline edit for account (balance/notes)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_account_id'])) {
    if (!$can_edit) {
        $error = "Access denied. You do not have permission to edit accounts.";
    } elseif (!csrf_validate($_POST['csrf_token'] ?? '')) {
        $error = "Invalid or expired form token. Please refresh and try again.";
    } else {
        $edit_account_id = intval($_POST['edit_account_id']);
        $edit_amount = floatval($_POST['edit_amount'] ?? 0);
        $edit_notes = trim($_POST['edit_notes'] ?? '');
        $submittedConflictToken = trim((string) ($_POST['record_conflict_token'] ?? ''));
        $conflictStmt = $conn->prepare("SELECT type, balance, notes, COALESCE(school_year_label, '') AS school_year_label FROM accounts WHERE id = ? LIMIT 1");
        $conflictStmt->bind_param("i", $edit_account_id);
        $conflictStmt->execute();
        $currentAccount = $conflictStmt->get_result()->fetch_assoc();
        $conflictStmt->close();

        if ($submittedConflictToken === '') {
            $error = "This account edit is missing conflict protection data. Please refresh and try again.";
        } elseif (!$currentAccount) {
            $error = "This account record no longer exists.";
        } elseif (!hash_equals(record_conflict_token(account_record_conflict_payload($currentAccount)), $submittedConflictToken)) {
            $error = "This account was changed by another user while you were editing it. Refresh the page first so you don't overwrite newer changes.";
        } else {
            $update_stmt = $conn->prepare("UPDATE accounts SET balance=?, notes=? WHERE id=?");
            $update_stmt->bind_param("dsi", $edit_amount, $edit_notes, $edit_account_id);
            $update_stmt->execute();
            $update_stmt->close();
            $accountLabel = trim((string) ($currentAccount['type'] ?? 'Account'));
            $auditDetails = 'Student ID: ' . (int) $student_id
                . ' | Account ID: ' . (int) $edit_account_id
                . ' | Account: ' . $accountLabel
                . ' | New Balance: ' . number_format($edit_amount, 2)
                . ' | Notes: ' . ($edit_notes !== '' ? $edit_notes : '[blank]');
            audit_log($conn, $_SESSION['username'] ?? 'unknown', 'Updated account summary via legacy route', 'Accounts', $auditDetails, 'INFO');
            // Redirect to avoid resubmission
            header("Location: account-student-summary.php?student_id=$student_id");
            exit;
        }
    }
}

if ($student_id) {
    // Get student details
    $stmt = $conn->prepare("SELECT lrn, lastname, firstname, middlename, birthday, age, gender, address, contact, grade, date_enrolled, photo FROM students WHERE id = ?");
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $stmt->bind_result($lrn, $lastname, $firstname, $middlename, $birthday, $age, $gender, $address, $contact, $grade, $date_enrolled, $photo);
    if ($stmt->fetch()) {
        $student = [
            'lrn' => $lrn,
            'lastname' => $lastname,
            'firstname' => $firstname,
            'middlename' => $middlename,
            'birthday' => $birthday,
            'age' => $age,
            'gender' => $gender,
            'address' => $address,
            'contact' => $contact,
            'grade' => $grade,
            'date_enrolled' => $date_enrolled,
            'photo' => $photo
        ];
    } else {
        $error = "Student not found.";
    }
    $stmt->close();

    // Get all accounts for this student
    $sql = "SELECT id, type, balance, notes, COALESCE(school_year_label, '') AS school_year_label FROM accounts WHERE student_id = ? ORDER BY type";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $accounts[] = $row;
    }
    $stmt->close();
} else {
    $error = "Invalid student ID.";
}

// Group accounts: fees/materials
function group_accounts($accounts, $group) {
    $result = [];
    foreach ($accounts as $a) {
        if ($group == 'fees' && stripos($a['type'], 'Fee') !== false) {
            $result[] = $a;
        }
        if ($group == 'materials' && stripos($a['type'], 'Fee') === false) {
            $result[] = $a;
        }
    }
    return $result;
}
$fees = group_accounts($accounts, 'fees');
$materials = group_accounts($accounts, 'materials');
ensure_csrf_token();

function get_paid_total($conn, $account_id) {
    $stmt = $conn->prepare("SELECT COALESCE(SUM(amount),0) FROM payments WHERE account_id=?");
    $stmt->bind_param("i", $account_id);
    $stmt->execute();
    $stmt->bind_result($paid);
    $stmt->fetch();
    $stmt->close();
    return $paid;
}
$editing_id = isset($_GET['edit_id']) ? intval($_GET['edit_id']) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Account Summary</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/school-admin-dashboard/assets/css/dashboard.css">
</head>
<body>
<?php render_admin_nav('accounts'); ?>
<div id="page-content-wrapper" class="w-100">
        <?php render_school_page_header("The Lord's Wisdom Academy Of Caloocan Inc."); ?>
        <div class="container mt-4">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php else: ?>
                <div class="card mb-4">
                    <div class="card-header bg-primary text-light">
                        <i class="fas fa-user-graduate"></i>
                        <?= htmlspecialchars($student['lastname'] . ', ' . $student['firstname'] . ' ' . $student['middlename']) ?>
                    </div>
                    <div class="card-body">
                        <div class="row mb-2">
                            <div class="col-md-3">
                                <?php if (!empty($student['photo'])): ?>
                                    <img src="<?= htmlspecialchars(student_photo_public_url((string) $student['photo'])) ?>" alt="Photo" class="img-thumbnail" style="max-width:100px;max-height:100px;">
                                <?php else: ?>
                                    <i>No photo</i>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-9">
                                <table class="table table-bordered table-sm">
                                    <tr><td><b>LRN:</b></td><td><?= htmlspecialchars($student['lrn']) ?></td></tr>
                                    <tr><td><b>Birthday:</b></td><td><?= htmlspecialchars($student['birthday']) ?></td></tr>
                                    <tr><td><b>Age:</b></td><td><?= htmlspecialchars($student['age']) ?></td></tr>
                                    <tr><td><b>Gender:</b></td><td><?= htmlspecialchars($student['gender']) ?></td></tr>
                                    <tr><td><b>Grade:</b></td><td><?= htmlspecialchars($student['grade']) ?></td></tr>
                                    <tr><td><b>Date Enrolled:</b></td>
                                        <td>
                                            <?php if (!empty($student['date_enrolled'])): ?>
                                                <?= htmlspecialchars(date('F j, Y', strtotime($student['date_enrolled']))) ?>
                                            <?php else: ?>
                                                <i>Not set</i>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr><td><b>Address:</b></td><td><?= htmlspecialchars($student['address']) ?></td></tr>
                                    <tr><td><b>Contact:</b></td><td><?= htmlspecialchars($student['contact']) ?></td></tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row gx-4">
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header bg-success text-light">
                                <i class="fas fa-file-invoice-dollar"></i> School Fees
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-bordered mb-0">
                                        <thead>
                                            <tr>
                                                <th>Type</th>
                                                <th>Amount</th>
                                                <th>Paid</th>
                                                <th>Notes</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $total_fee = 0; $total_paid = 0;
                                        foreach ($fees as $f):
                                            $paid = get_paid_total($conn, $f['id']);
                                            $total_fee += $f['balance'];
                                            $total_paid += $paid;
                                        ?>
                                        <tr>
                                            <?php if ($editing_id == $f['id'] && $can_edit): ?>
                                                <form method="post" action="account-student-summary.php?student_id=<?= $student_id ?>">
                                                    <?= csrf_input() ?>
                                                    <input type="hidden" name="record_conflict_token" value="<?= htmlspecialchars(record_conflict_token(account_record_conflict_payload($f))) ?>">
                                                    <td><?= htmlspecialchars($f['type']) ?></td>
                                                    <td><input type="number" step="0.01" class="form-control" name="edit_amount" value="<?= htmlspecialchars($f['balance']) ?>" required></td>
                                                    <td><?= number_format($paid,2) ?></td>
                                                    <td><input type="text" class="form-control" name="edit_notes" value="<?= htmlspecialchars($f['notes']) ?>"></td>
                                                    <td>
                                                        <input type="hidden" name="edit_account_id" value="<?= $f['id'] ?>">
                                                        <button type="submit" class="btn btn-info btn-sm"><i class="fas fa-save"></i> Save</button>
                                                        <a href="account-student-summary.php?student_id=<?= $student_id ?>" class="btn btn-secondary btn-sm"><i class="fas fa-times"></i> Cancel</a>
                                                    </td>
                                                </form>
                                            <?php else: ?>
                                                <td><?= htmlspecialchars($f['type']) ?></td>
                                                <td class="text-end">₱<?= number_format($f['balance'],2) ?></td>
                                                <td class="text-end">₱<?= number_format($paid,2) ?></td>
                                                <td><?= htmlspecialchars($f['notes']) ?></td>
                                                <td>
                                                    <?php if ($can_edit): ?>
                                                    <a href="account-student-summary.php?student_id=<?= $student_id ?>&edit_id=<?= $f['id'] ?>" class="btn btn-outline-primary btn-sm"><i class="fas fa-edit"></i> Edit</a>
                                                    <?php endif; ?>
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                        <?php endforeach; ?>
                                        <tr class="table-active">
                                            <td><b>Total</b></td>
                                            <td class="text-end"><b>₱<?= number_format($total_fee,2) ?></b></td>
                                            <td class="text-end"><b>₱<?= number_format($total_paid,2) ?></b></td>
                                            <td colspan="2"></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header bg-warning text-dark">
                                <i class="fas fa-book"></i> School Materials
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-bordered mb-0">
                                        <thead>
                                            <tr>
                                                <th>Type</th>
                                                <th>Amount</th>
                                                <th>Notes</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $total_mat = 0; foreach ($materials as $m): $total_mat += $m['balance']; ?>
                                        <tr>
                                            <?php if ($editing_id == $m['id'] && $can_edit): ?>
                                                <form method="post" action="account-student-summary.php?student_id=<?= $student_id ?>">
                                                    <?= csrf_input() ?>
                                                    <input type="hidden" name="record_conflict_token" value="<?= htmlspecialchars(record_conflict_token(account_record_conflict_payload($m))) ?>">
                                                    <td><?= htmlspecialchars($m['type']) ?></td>
                                                    <td><input type="number" step="0.01" class="form-control" name="edit_amount" value="<?= htmlspecialchars($m['balance']) ?>" required></td>
                                                    <td><input type="text" class="form-control" name="edit_notes" value="<?= htmlspecialchars($m['notes']) ?>"></td>
                                                    <td>
                                                        <input type="hidden" name="edit_account_id" value="<?= $m['id'] ?>">
                                                        <button type="submit" class="btn btn-info btn-sm"><i class="fas fa-save"></i> Save</button>
                                                        <a href="account-student-summary.php?student_id=<?= $student_id ?>" class="btn btn-secondary btn-sm"><i class="fas fa-times"></i> Cancel</a>
                                                    </td>
                                                </form>
                                            <?php else: ?>
                                                <td><?= htmlspecialchars($m['type']) ?></td>
                                                <td class="text-end">₱<?= number_format($m['balance'],2) ?></td>
                                                <td><?= htmlspecialchars($m['notes']) ?></td>
                                                <td>
                                                    <?php if ($can_edit): ?>
                                                    <a href="account-student-summary.php?student_id=<?= $student_id ?>&edit_id=<?= $m['id'] ?>" class="btn btn-outline-primary btn-sm"><i class="fas fa-edit"></i> Edit</a>
                                                    <?php endif; ?>
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                        <?php endforeach; ?>
                                        <tr class="table-active">
                                            <td><b>Total</b></td>
                                            <td class="text-end"><b>₱<?= number_format($total_mat,2) ?></b></td>
                                            <td colspan="2"></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <a href="../students/student-list.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Student List</a>
            <?php endif; ?>
        </div>
        <?php if (file_exists('../../includes/footer.php')) include '../../includes/footer.php'; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="/school-admin-dashboard/assets/js/dashboard.js"></script>
</body>
</html>
<?php
$conn->close();
?>
