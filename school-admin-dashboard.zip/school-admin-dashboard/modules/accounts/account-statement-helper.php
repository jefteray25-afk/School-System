<?php
require_once __DIR__ . '/../../includes/receipt-payment-method-helper.php';

function account_statement_load_data(mysqli $conn, int $studentId, string $schoolYearFilter, string $activeSchoolYearLabel): array
{
    $error = '';
    $accounts = [];
    $recentPayments = [];
    $student = null;
    $summary = [
        'assessed' => 0.0,
        'paid' => 0.0,
        'balance' => 0.0,
        'payment_count' => 0,
    ];
    $exceptionCount = 0;

    if ($studentId <= 0) {
        return [
            'error' => 'Invalid student ID.',
            'student' => null,
            'accounts' => [],
            'recent_payments' => [],
            'summary' => $summary,
            'exception_count' => 0,
            'selected_school_year' => $schoolYearFilter !== '' ? $schoolYearFilter : $activeSchoolYearLabel,
        ];
    }

    $studentStmt = $conn->prepare("SELECT id, lrn, lastname, firstname, middlename, grade, contact, photo, school_year_label FROM students WHERE id = ? LIMIT 1");
    $studentStmt->bind_param('i', $studentId);
    $studentStmt->execute();
    $studentResult = $studentStmt->get_result();
    $student = $studentResult ? $studentResult->fetch_assoc() : null;
    $studentStmt->close();

    if (!$student) {
        return [
            'error' => 'Student not found.',
            'student' => null,
            'accounts' => [],
            'recent_payments' => [],
            'summary' => $summary,
            'exception_count' => 0,
            'selected_school_year' => $schoolYearFilter !== '' ? $schoolYearFilter : $activeSchoolYearLabel,
        ];
    }

    $selectedSchoolYear = $schoolYearFilter !== '' ? $schoolYearFilter : (($student['school_year_label'] ?? '') ?: $activeSchoolYearLabel);

    $accountSql = "
        SELECT
            a.id,
            a.type,
            a.balance,
            a.notes,
            COALESCE(SUM(
                CASE
                    WHEN (p.booklet_no IS NULL OR p.receipt_no IS NULL) THEN p.amount
                    WHEN rr.receipt_no IS NOT NULL THEN p.amount
                    ELSE 0
                END
            ), 0) AS total_paid
        FROM accounts a
        LEFT JOIN payments p
            ON p.account_id = a.id
           AND COALESCE(NULLIF(TRIM(p.school_year_label), ''), ?) = ?
        LEFT JOIN receipts_registry rr
            ON rr.receipt_no = p.receipt_no
           AND rr.booklet_no = p.booklet_no
           AND rr.voided = 0
           AND rr.used_by IN ('payments', 'other_payment')
        WHERE a.student_id = ?
          AND COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ?
        GROUP BY a.id, a.type, a.balance, a.notes
        ORDER BY a.type ASC
    ";
    $accountStmt = $conn->prepare($accountSql);
    $accountStmt->bind_param('ssiss', $selectedSchoolYear, $selectedSchoolYear, $studentId, $selectedSchoolYear, $selectedSchoolYear);
    $accountStmt->execute();
    $accountResult = $accountStmt->get_result();
    while ($row = $accountResult->fetch_assoc()) {
        $row['assessed_amount'] = (float) $row['balance'] + (float) $row['total_paid'];
        $summary['assessed'] += (float) $row['assessed_amount'];
        $summary['paid'] += (float) $row['total_paid'];
        $summary['balance'] += (float) $row['balance'];
        $accounts[] = $row;
    }
    $accountStmt->close();

    $paymentSql = "
        SELECT
            p.date_paid,
            p.amount,
            p.booklet_no,
            p.receipt_no,
            p.remarks,
            p.receipt_note,
            COALESCE(at.name, a.type, 'Uncategorized') AS fee_type
        FROM payments p
        LEFT JOIN accounts a ON p.account_id = a.id
        LEFT JOIN account_types at ON at.name = a.type
        LEFT JOIN receipts_registry rr
            ON rr.receipt_no = p.receipt_no
           AND rr.booklet_no = p.booklet_no
           AND rr.voided = 0
           AND rr.used_by IN ('payments', 'other_payment')
        WHERE a.student_id = ?
          AND COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ?
          AND COALESCE(NULLIF(TRIM(p.school_year_label), ''), ?) = ?
          AND (
                (p.booklet_no IS NULL OR p.receipt_no IS NULL)
                OR rr.receipt_no IS NOT NULL
          )
        ORDER BY p.date_paid DESC, p.id DESC
        LIMIT 30
    ";
    $paymentStmt = $conn->prepare($paymentSql);
    $paymentStmt->bind_param('issss', $studentId, $selectedSchoolYear, $selectedSchoolYear, $selectedSchoolYear, $selectedSchoolYear);
    $paymentStmt->execute();
    $paymentResult = $paymentStmt->get_result();
    $paymentRows = [];
    while ($row = $paymentResult->fetch_assoc()) {
        $paymentRows[] = $row;
    }
    $paymentStmt->close();

    $paymentGroups = [];
    foreach ($paymentRows as $row) {
        $booklet = $row['booklet_no'] ?? null;
        $receipt = $row['receipt_no'] ?? null;
        $dateKey = (string) ($row['date_paid'] ?? '');
        $groupKey = $dateKey . '|' . (string) $booklet . '|' . (string) $receipt;
        if (!isset($paymentGroups[$groupKey])) {
            $methodBreakdown = receipt_payment_methods_for_display(
                $conn,
                (int) ($booklet ?: 0),
                (int) ($receipt ?: 0),
                null,
                (string) ($row['receipt_note'] ?? '')
            );
            $paymentGroups[$groupKey] = [
                'date_paid' => $row['date_paid'],
                'booklet_no' => $booklet,
                'receipt_no' => $receipt,
                'remarks' => $row['remarks'] ?? '',
                'receipt_note' => $row['receipt_note'] ?? '',
                'payment_method_display' => receipt_payment_methods_display_label($methodBreakdown, (string) ($row['receipt_note'] ?? '')),
                'payment_method_breakdown' => receipt_payment_methods_summary_text($methodBreakdown),
                'fee_type' => $row['fee_type'] ?? 'Uncategorized',
                'amount' => 0.0,
                'items' => [],
            ];
        }
        $paymentGroups[$groupKey]['amount'] += (float) ($row['amount'] ?? 0);
        $paymentGroups[$groupKey]['items'][] = [
            'fee_type' => $row['fee_type'] ?? 'Uncategorized',
            'amount' => (float) ($row['amount'] ?? 0),
        ];
    }

    foreach ($paymentGroups as $group) {
        if (count($group['items']) > 1) {
            $group['fee_type'] = 'Multiple (' . count($group['items']) . ' items)';
        }
        $recentPayments[] = $group;
    }

    $paymentCountSql = "
        SELECT COUNT(*) AS payment_count
        FROM payments p
        INNER JOIN accounts a ON p.account_id = a.id
        LEFT JOIN receipts_registry rr
            ON rr.receipt_no = p.receipt_no
           AND rr.booklet_no = p.booklet_no
           AND rr.voided = 0
           AND rr.used_by IN ('payments', 'other_payment')
        WHERE a.student_id = ?
          AND COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ?
          AND COALESCE(NULLIF(TRIM(p.school_year_label), ''), ?) = ?
          AND (
                (p.booklet_no IS NULL OR p.receipt_no IS NULL)
                OR rr.receipt_no IS NOT NULL
          )
    ";
    $countStmt = $conn->prepare($paymentCountSql);
    $countStmt->bind_param('issss', $studentId, $selectedSchoolYear, $selectedSchoolYear, $selectedSchoolYear, $selectedSchoolYear);
    $countStmt->execute();
    $countStmt->bind_result($paymentCount);
    if ($countStmt->fetch()) {
        $summary['payment_count'] = (int) $paymentCount;
    }
    $countStmt->close();

    $exceptionStmt = $conn->prepare("SELECT COUNT(*) FROM student_fee_exceptions WHERE student_id = ? AND school_year_label = ?");
    if ($exceptionStmt) {
        $exceptionStmt->bind_param('is', $studentId, $selectedSchoolYear);
        $exceptionStmt->execute();
        $exceptionStmt->bind_result($exceptionCount);
        $exceptionStmt->fetch();
        $exceptionStmt->close();
    }

    return [
        'error' => $error,
        'student' => $student,
        'accounts' => $accounts,
        'recent_payments' => $recentPayments,
        'summary' => $summary,
        'exception_count' => $exceptionCount,
        'selected_school_year' => $selectedSchoolYear,
    ];
}
