<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
include '../../config/database.php';
include __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/settings-security.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/../settings/fee-grade-settings-helper.php';
require_once __DIR__ . '/account-fee-exceptions-helper.php';
require_once __DIR__ . '/../financial/fee-behavior-helper.php';
require_once __DIR__ . '/../financial/fee-lock-helper.php';
include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');

// Permission check: Only users with account_mgmt:add permission (e.g. admin, accountant) can sync fees
$currentRole = $_SESSION['role'] ?? '';
if (!hasPermission($currentRole, 'account_mgmt', 'add')) {
    $response = ['success' => false, 'message' => 'Access denied.'];
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method.'
    ]);
    exit;
}

$csrfToken = $_POST['csrf_token'] ?? '';
if (!admin_csrf_validate($csrfToken)) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Invalid CSRF token.'
    ]);
    exit;
}

$updated = 0;
$error = '';

function account_sync_fee_adjustment_type(string $feeTypeName): string
{
    $suffix = ' Adj';
    $maxBaseLength = 20 - strlen($suffix);
    $base = trim($feeTypeName);
    if (strlen($base) > $maxBaseLength) {
        $base = rtrim(substr($base, 0, $maxBaseLength));
    }

    return $base . $suffix;
}

function account_sync_fee_adjustment_note(string $feeTypeName): string
{
    return 'Fee adjustment for: ' . trim($feeTypeName);
}

function account_sync_fee_run(mysqli $conn, string $activeSchoolYearLabel, ?string $requestedSchoolYear, bool $applyChanges): array
{
    student_fee_exceptions_ensure_table($conn);
    fee_behavior_ensure_column($conn);
    fee_lock_ensure_table($conn);
    $feeLockMap = fee_lock_fetch_map($conn);
    $grade_map = [];
    foreach (fee_grade_catalog_rows($conn, true) as $gradeRow) {
        $studentGradeValue = trim((string) ($gradeRow['student_grade_value'] ?? ''));
        if ($studentGradeValue === '') {
            continue;
        }
        $grade_map[$studentGradeValue] = (int) ($gradeRow['grade_code'] ?? 0);
    }

    $scopeSchoolYear = $requestedSchoolYear !== null && trim($requestedSchoolYear) !== '' ? trim($requestedSchoolYear) : null;
    $managedFeeTypes = [];
    $managedTypesResult = $conn->query("SELECT DISTINCT at.name FROM fee f INNER JOIN account_types at ON f.fee_type_id = at.id");
    if ($managedTypesResult) {
        while ($managedTypeRow = $managedTypesResult->fetch_assoc()) {
            $managedFeeTypes[] = $managedTypeRow['name'];
        }
        $managedTypesResult->close();
    }

    $summary = [
        'scope_school_year' => $scopeSchoolYear ?? 'All School Years',
        'sync_mode' => 'Lock-aware missing-first sync',
        'students_checked' => 0,
        'fee_rows_considered' => 0,
        'existing_accounts_reviewed' => 0,
        'existing_accounts_already_aligned' => 0,
        'existing_paid_accounts_reviewed' => 0,
        'accounts_added' => 0,
        'accounts_updated' => 0,
        'accounts_removed' => 0,
        'missing_accounts' => 0,
        'missing_accounts_sample' => [],
        'locked_scope_students' => 0,
        'locked_existing_accounts_skipped' => 0,
        'locked_adjustment_rows_skipped' => 0,
        'adjustment_candidates' => 0,
        'partial_adjustment_candidates' => 0,
        'fully_paid_adjustment_candidates' => 0,
        'adjustment_rows_added' => 0,
        'adjustment_rows_updated' => 0,
        'adjustment_rows_removed' => 0,
        'adjustment_rows_preserved' => 0,
    ];

    $stud_res = $conn->query("SELECT id, grade, school_year_label, lastname, firstname, middlename FROM students");
    while ($stud = $stud_res->fetch_assoc()) {
        $student_id = (int) $stud['id'];
        $grade_name = $stud['grade'];
        $studentName = trim(implode(' ', array_filter([
            trim((string) ($stud['lastname'] ?? '')),
            trim((string) ($stud['firstname'] ?? '')),
            trim((string) ($stud['middlename'] ?? '')),
        ])));
        $studentSchoolYear = trim((string) ($stud['school_year_label'] ?? ''));
        if ($studentSchoolYear === '') {
            $studentSchoolYear = $activeSchoolYearLabel;
        }
        if ($scopeSchoolYear !== null && $studentSchoolYear !== $scopeSchoolYear) {
            continue;
        }

        $grade_num = isset($grade_map[$grade_name]) ? $grade_map[$grade_name] : 0;
        if ($grade_num === 0) {
            continue;
        }

        $summary['students_checked']++;
        $scopeLocked = fee_lock_scope_is_locked($feeLockMap, $studentSchoolYear, $grade_num);
        if ($scopeLocked) {
            $summary['locked_scope_students']++;
        }

        $fee_sql = "SELECT at.name, f.amount, f.school_year_label, f.application_mode
                    FROM fee f
                    JOIN account_types at ON f.fee_type_id = at.id
                    WHERE f.grade_level = ?
                      AND (
                            f.school_year_label = ?
                            OR f.school_year_label IS NULL
                            OR TRIM(f.school_year_label) = ''
                      )
                    ORDER BY CASE WHEN f.school_year_label = ? THEN 0 ELSE 1 END, at.priority ASC, at.name ASC";
        $fee_stmt = $conn->prepare($fee_sql);
        $fee_stmt->bind_param("iss", $grade_num, $studentSchoolYear, $studentSchoolYear);
        $fee_stmt->execute();
        $fee_stmt->store_result();
        $fee_stmt->bind_result($fee_name, $fee_amount, $feeSchoolYear, $applicationMode);

        $fees = [];
        while ($fee_stmt->fetch()) {
            if (!isset($fees[$fee_name])) {
                $fees[$fee_name] = [
                    'name' => $fee_name,
                    'amount' => (float) $fee_amount,
                    'school_year_label' => trim((string) $feeSchoolYear) !== '' ? trim((string) $feeSchoolYear) : $studentSchoolYear,
                    'application_mode' => fee_behavior_normalize((string) $applicationMode),
                ];
            }
        }
        $fee_stmt->close();
        $exceptionMap = student_fee_exception_map($conn, $student_id, $studentSchoolYear);
        $effectiveFees = [];
        foreach (array_values($fees) as $feeRow) {
            $effectiveRow = student_fee_exception_effective_row($feeRow, $exceptionMap[$feeRow['name']] ?? null);
            if (empty($effectiveRow['should_apply'])) {
                continue;
            }
            $effectiveFees[] = [
                'name' => (string) $effectiveRow['name'],
                'amount' => (float) $effectiveRow['effective_amount'],
                'school_year_label' => (string) $effectiveRow['school_year_label'],
            ];
        }
        $fees = $effectiveFees;
        $summary['fee_rows_considered'] += count($fees);

        $acct_sql = "SELECT a.id, a.type, a.balance, a.notes,
                COALESCE(COUNT(p.id), 0) AS payment_count,
                COALESCE(SUM(p.amount), 0) AS paid_total
            FROM accounts a
            LEFT JOIN payments p ON p.account_id = a.id
            WHERE a.student_id = ? AND COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ?
            GROUP BY a.id, a.type, a.balance, a.notes";
        $acct_stmt = $conn->prepare($acct_sql);
        $acct_stmt->bind_param("iss", $student_id, $studentSchoolYear, $studentSchoolYear);
        $acct_stmt->execute();
        $acct_res = $acct_stmt->get_result();
        $existing_types = [];
        $adjustment_rows = [];
        while ($row = $acct_res->fetch_assoc()) {
            $rowData = [
                'id' => (int) $row['id'],
                'type' => (string) $row['type'],
                'balance' => (float) $row['balance'],
                'notes' => (string) ($row['notes'] ?? ''),
                'payment_count' => (int) ($row['payment_count'] ?? 0),
                'paid_total' => (float) ($row['paid_total'] ?? 0),
            ];
            $existing_types[$row['type']] = $rowData;
            $note = trim((string) ($row['notes'] ?? ''));
            if (str_starts_with($note, 'Fee adjustment for: ')) {
                $baseFeeType = trim(substr($note, strlen('Fee adjustment for: ')));
                if ($baseFeeType !== '') {
                    $adjustment_rows[$baseFeeType] = $rowData;
                }
            }
        }
        $acct_stmt->close();

        $fee_type_names = array_column($fees, 'name');
        foreach ($existing_types as $type => $data) {
            if (in_array($type, $managedFeeTypes, true) && !in_array($type, $fee_type_names, true)) {
                if ($scopeLocked) {
                    $summary['locked_existing_accounts_skipped']++;
                    continue;
                }
                if ((int) ($data['payment_count'] ?? 0) > 0) {
                    continue;
                }
                $summary['accounts_removed']++;
                if ($applyChanges) {
                    $del_stmt = $conn->prepare("DELETE FROM accounts WHERE id = ?");
                    $del_stmt->bind_param("i", $data['id']);
                    $del_stmt->execute();
                    $del_stmt->close();
                }
            }
        }

        foreach ($fees as $fee) {
            if (!isset($existing_types[$fee['name']])) {
                $summary['missing_accounts']++;
                if (!$applyChanges && count($summary['missing_accounts_sample']) < 8) {
                    $summary['missing_accounts_sample'][] = [
                        'student_id' => $student_id,
                        'student_name' => $studentName,
                        'grade' => $grade_name,
                        'school_year' => $studentSchoolYear,
                        'fee_type' => $fee['name'],
                    ];
                }
                if ($applyChanges) {
                    $notes = "Auto-added from sync";
                    $acc_stmt = $conn->prepare("INSERT INTO accounts (student_id, name, type, balance, notes, school_year_label) VALUES (?, ?, ?, ?, ?, ?)");
                    if (!$acc_stmt) {
                        throw new RuntimeException('Could not prepare fee account insert.');
                    }
                    $acc_stmt->bind_param("issdss", $student_id, $studentName, $fee['name'], $fee['amount'], $notes, $studentSchoolYear);
                    if (!$acc_stmt->execute()) {
                        $message = $acc_stmt->error ?: 'Unknown fee account insert error.';
                        $acc_stmt->close();
                        throw new RuntimeException('Could not add fee account: ' . $message);
                    }
                    $acc_stmt->close();
                }
                $summary['accounts_added']++;
            } else {
                $acct_id = $existing_types[$fee['name']]['id'];
                $current_balance = $existing_types[$fee['name']]['balance'];
                $payment_count = (int) ($existing_types[$fee['name']]['payment_count'] ?? 0);
                $paid_total = (float) ($existing_types[$fee['name']]['paid_total'] ?? 0);
                $expected_remaining = max(0, (float) $fee['amount'] - $paid_total);
                $summary['existing_accounts_reviewed']++;
                if ($payment_count > 0) {
                    $summary['existing_paid_accounts_reviewed']++;
                }
                if ($scopeLocked) {
                    $summary['locked_existing_accounts_skipped']++;
                    if ($payment_count > 0) {
                        $summary['locked_adjustment_rows_skipped']++;
                    }
                    continue;
                }
                if ($payment_count > 0) {
                    $needsAdjustment = abs($current_balance - $expected_remaining) > 0.009;
                    $isPartialAccount = $current_balance > 0.009;
                    $adjustmentRow = $adjustment_rows[$fee['name']] ?? null;
                    if ($needsAdjustment) {
                        $summary['adjustment_candidates']++;
                        if ($isPartialAccount) {
                            $summary['partial_adjustment_candidates']++;
                        } elseif ($paid_total + 0.009 < (float) $fee['amount']) {
                            $summary['fully_paid_adjustment_candidates']++;
                        }
                    }
                    if ($applyChanges) {
                        if ($needsAdjustment && $isPartialAccount) {
                            $summary['accounts_updated']++;
                            $upd_stmt = $conn->prepare("UPDATE accounts SET balance = ?, school_year_label = ? WHERE id = ?");
                            $upd_stmt->bind_param("dsi", $expected_remaining, $studentSchoolYear, $acct_id);
                            $upd_stmt->execute();
                            $upd_stmt->close();
                        } elseif (!$isPartialAccount) {
                            if ($expected_remaining > 0.009) {
                                $adjustmentType = account_sync_fee_adjustment_type($fee['name']);
                                $adjustmentNote = account_sync_fee_adjustment_note($fee['name']);
                                if ($adjustmentRow) {
                                    if ((int) ($adjustmentRow['payment_count'] ?? 0) > 0) {
                                        $summary['adjustment_rows_preserved']++;
                                    } elseif (abs((float) ($adjustmentRow['balance'] ?? 0) - $expected_remaining) > 0.009) {
                                        $summary['adjustment_rows_updated']++;
                                        $adj_stmt = $conn->prepare("UPDATE accounts SET balance = ?, school_year_label = ?, notes = ? WHERE id = ?");
                                        $adjustmentRowId = (int) $adjustmentRow['id'];
                                        $adj_stmt->bind_param("dssi", $expected_remaining, $studentSchoolYear, $adjustmentNote, $adjustmentRowId);
                                        $adj_stmt->execute();
                                        $adj_stmt->close();
                                    }
                                } else {
                                    $summary['adjustment_rows_added']++;
                                    $insertNote = $adjustmentNote;
                                    $adj_stmt = $conn->prepare("INSERT INTO accounts (student_id, name, type, balance, notes, school_year_label) VALUES (?, ?, ?, ?, ?, ?)");
                                    $adj_stmt->bind_param("issdss", $student_id, $studentName, $adjustmentType, $expected_remaining, $insertNote, $studentSchoolYear);
                                    $adj_stmt->execute();
                                    $adj_stmt->close();
                                }
                            } elseif ($adjustmentRow && (int) ($adjustmentRow['payment_count'] ?? 0) === 0) {
                                $summary['adjustment_rows_removed']++;
                                $del_stmt = $conn->prepare("DELETE FROM accounts WHERE id = ?");
                                $adjustmentRowId = (int) $adjustmentRow['id'];
                                $del_stmt->bind_param("i", $adjustmentRowId);
                                $del_stmt->execute();
                                $del_stmt->close();
                            }

                            $upd_stmt = $conn->prepare("UPDATE accounts SET school_year_label = ? WHERE id = ? AND (school_year_label IS NULL OR TRIM(school_year_label) = '')");
                            $upd_stmt->bind_param("si", $studentSchoolYear, $acct_id);
                            $upd_stmt->execute();
                            $upd_stmt->close();
                        } else {
                            $upd_stmt = $conn->prepare("UPDATE accounts SET school_year_label = ? WHERE id = ? AND (school_year_label IS NULL OR TRIM(school_year_label) = '')");
                            $upd_stmt->bind_param("si", $studentSchoolYear, $acct_id);
                            $upd_stmt->execute();
                            $upd_stmt->close();
                        }
                    }
                    continue;
                }
                if ($current_balance != $fee['amount']) {
                    $summary['accounts_updated']++;
                    if ($applyChanges) {
                        $upd_stmt = $conn->prepare("UPDATE accounts SET balance = ?, school_year_label = ? WHERE id = ?");
                        $upd_stmt->bind_param("dsi", $fee['amount'], $studentSchoolYear, $acct_id);
                        $upd_stmt->execute();
                        $upd_stmt->close();
                    }
                } else {
                    $summary['existing_accounts_already_aligned']++;
                    if ($applyChanges) {
                        $upd_stmt = $conn->prepare("UPDATE accounts SET school_year_label = ? WHERE id = ? AND (school_year_label IS NULL OR TRIM(school_year_label) = '')");
                        $upd_stmt->bind_param("si", $studentSchoolYear, $acct_id);
                        $upd_stmt->execute();
                        $upd_stmt->close();
                    }
                }
            }
        }
    }

    return $summary;
}

try {
    school_year_ensure_table($conn);
    school_year_ensure_finance_columns($conn);
    $activeSchoolYearLabel = school_year_get_active_label($conn);
    $requestedSchoolYear = trim($_POST['school_year'] ?? '');
    $scopeSchoolYear = $requestedSchoolYear !== '' ? $requestedSchoolYear : null;
    $previewOnly = isset($_POST['preview']) && (string) $_POST['preview'] === '1';

    $summary = account_sync_fee_run($conn, $activeSchoolYearLabel, $scopeSchoolYear, !$previewOnly);
    $updated = (int) $summary['accounts_added'] + (int) $summary['accounts_updated'] + (int) $summary['accounts_removed'];

    if (!$previewOnly) {
        $user = $_SESSION['username'] ?? 'unknown';
        $details = "Role: " . ($_SESSION['role'] ?? 'unknown')
            . " | Scope: " . $summary['scope_school_year']
            . " | Mode: " . $summary['sync_mode']
            . " | Students Checked: " . $summary['students_checked']
            . " | Fee Rows Considered: " . $summary['fee_rows_considered']
            . " | Existing Accounts Reviewed: " . $summary['existing_accounts_reviewed']
            . " | Existing Accounts Already Aligned: " . $summary['existing_accounts_already_aligned']
            . " | Existing Paid Accounts Reviewed: " . $summary['existing_paid_accounts_reviewed']
            . " | Accounts Added: " . $summary['accounts_added']
            . " | Accounts Updated: " . $summary['accounts_updated']
            . " | Accounts Removed: " . $summary['accounts_removed']
            . " | Locked Scope Students: " . $summary['locked_scope_students']
            . " | Locked Existing Accounts Skipped: " . $summary['locked_existing_accounts_skipped']
            . " | Locked Adjustment Rows Skipped: " . $summary['locked_adjustment_rows_skipped']
            . " | Adjustment Review Needed: " . $summary['adjustment_candidates']
            . " | Partial Accounts Affected: " . $summary['partial_adjustment_candidates']
            . " | Fully Paid Accounts Affected: " . $summary['fully_paid_adjustment_candidates']
            . " | Adjustment Rows Added: " . $summary['adjustment_rows_added']
            . " | Adjustment Rows Updated: " . $summary['adjustment_rows_updated']
            . " | Adjustment Rows Removed: " . $summary['adjustment_rows_removed']
            . " | Paid Adjustment Rows Preserved: " . $summary['adjustment_rows_preserved'];
        audit_log($conn, $user, "Synced fee accounts", "Fees", $details);
    }

    $conn->close();

    // If called via AJAX/JS
    if (
        isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
        strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest'
    ) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'message' => $previewOnly
                ? "Sync preview ready."
                : "Sync completed! Updated $updated account(s).",
            'preview' => $previewOnly,
            'scope_school_year' => $summary['scope_school_year'],
            'sync_mode' => $summary['sync_mode'],
            'students_checked' => $summary['students_checked'],
            'fee_rows_considered' => $summary['fee_rows_considered'],
            'existing_accounts_reviewed' => $summary['existing_accounts_reviewed'],
            'existing_accounts_already_aligned' => $summary['existing_accounts_already_aligned'],
            'existing_paid_accounts_reviewed' => $summary['existing_paid_accounts_reviewed'],
            'accounts_added' => $summary['accounts_added'],
            'accounts_updated' => $summary['accounts_updated'],
            'accounts_removed' => $summary['accounts_removed'],
            'missing_accounts' => $summary['missing_accounts'],
            'missing_accounts_sample' => $summary['missing_accounts_sample'],
            'locked_scope_students' => $summary['locked_scope_students'],
            'locked_existing_accounts_skipped' => $summary['locked_existing_accounts_skipped'],
            'locked_adjustment_rows_skipped' => $summary['locked_adjustment_rows_skipped'],
            'adjustment_candidates' => $summary['adjustment_candidates'],
            'partial_adjustment_candidates' => $summary['partial_adjustment_candidates'],
            'fully_paid_adjustment_candidates' => $summary['fully_paid_adjustment_candidates'],
            'adjustment_rows_added' => $summary['adjustment_rows_added'],
            'adjustment_rows_updated' => $summary['adjustment_rows_updated'],
            'adjustment_rows_removed' => $summary['adjustment_rows_removed'],
            'adjustment_rows_preserved' => $summary['adjustment_rows_preserved'],
            'updated_total' => $updated
        ]);
        exit;
    }

    // If called via GET (normal browser), redirect as before
    $redirect = "account-list.php?synced=1&updated=$updated";
    if ($scopeSchoolYear !== null) {
        $redirect .= "&school_year=" . urlencode($scopeSchoolYear);
    }
    header("Location: " . $redirect);
    exit();

} catch (Exception $e) {
    audit_log(
        $conn,
        $_SESSION['username'] ?? 'unknown',
        'Fee sync failed',
        'Fees',
        'Role: ' . ($_SESSION['role'] ?? 'unknown') . ' | Error: ' . $e->getMessage(),
        'ERROR'
    );
    $conn->close();
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Sync failed: ' . $e->getMessage()
    ]);
    exit;
}
?>
