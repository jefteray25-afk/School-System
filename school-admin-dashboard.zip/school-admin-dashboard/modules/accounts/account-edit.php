<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
include '../../config/database.php';
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require_once __DIR__ . '/../../includes/ui.php';
require_once __DIR__ . '/../../includes/record-conflict-helper.php';
include __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/settings-security.php';

// Permission check: Only users with financial:edit permission (e.g. admin, teacher, cashier, etc.)
$currentRole = $_SESSION['role'] ?? '';

// Ownership-aware permission logic: allow edit_own if user is owner
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = "";
$success = "";

$type_options = [];
$student_id = 0;
$is_own = false;
$type = '';
$balance = 0.00;
$notes = '';
$account_conflict_token = '';
ensure_csrf_token();

if ($id > 0) {
    $sql = "SELECT student_id, type, balance, notes, COALESCE(school_year_label, '') AS school_year_label FROM accounts WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $accountRow = $stmt->get_result()->fetch_assoc();
    if (!$accountRow) {
        $error = "Account not found.";
    } else {
        $student_id = (int) ($accountRow['student_id'] ?? 0);
        $type = (string) ($accountRow['type'] ?? '');
        $balance = (float) ($accountRow['balance'] ?? 0);
        $notes = (string) ($accountRow['notes'] ?? '');
        $account_conflict_token = record_conflict_token(account_record_conflict_payload($accountRow));
    }
    $stmt->close();

    // Ownership check: does this user "own" this account? (for example, match on user id)
    if (in_array($currentRole, ['Administrator 1', 'Administrator 2']) && isset($_SESSION['user_id'])) {
        $is_own = ($_SESSION['user_id'] == $student_id);
    }

    $types_res = $conn->query("SELECT name FROM account_types ORDER BY name ASC");
    while ($row = $types_res->fetch_assoc()) {
        $type_options[] = $row['name'];
    }
} else {
    $error = "Invalid account ID.";
}

// Permission check: allow edit if
// - hasPermission(financial, edit)
// - OR (hasPermission(financial, edit_own) && is_own)
if (
    !hasPermission($currentRole, 'financial', 'edit') &&
    !(hasPermission($currentRole, 'financial', 'edit_own') && $is_own)
) {
    admin_session_forbidden();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$error) {
    admin_require_post_csrf();
    $new_type = $_POST['type'] ?? '';
    $other_type = trim($_POST['other_type'] ?? '');
    $new_balance = floatval($_POST['balance'] ?? 0);
    $new_notes = trim($_POST['notes'] ?? '');
    $submittedConflictToken = trim((string) ($_POST['record_conflict_token'] ?? ''));

    if ($new_type === "Other" && $other_type) {
        $new_type = $other_type;
    }

    if ($submittedConflictToken === '') {
        $error = "This account edit is missing conflict protection data. Please refresh and try again.";
    } else {
        $conflictStmt = $conn->prepare("SELECT type, balance, notes, COALESCE(school_year_label, '') AS school_year_label FROM accounts WHERE id = ? LIMIT 1");
        $conflictStmt->bind_param("i", $id);
        $conflictStmt->execute();
        $currentRow = $conflictStmt->get_result()->fetch_assoc();
        $conflictStmt->close();
        if (!$currentRow) {
            $error = "Account no longer exists.";
        } elseif (!hash_equals(record_conflict_token(account_record_conflict_payload($currentRow)), $submittedConflictToken)) {
            $error = "This account was updated by another user while you were editing. Refresh the page first so you don't overwrite newer changes.";
        }
    }

    if ($new_type && !$error) {
        $sql = "UPDATE accounts SET type = ?, balance = ?, notes = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sdsi", $new_type, $new_balance, $new_notes, $id);
        if ($stmt->execute()) {
            $success = "Account updated.";
            $type = $new_type;
            $balance = $new_balance;
            $notes = $new_notes;

            // ---------- AUDIT LOGGING: Edit Account ----------
            include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');
            $user = $_SESSION['username'] ?? 'unknown';
            $action = "Edited account";
            $module = "Accounts";
            $details = "Role: " . ($_SESSION['role'] ?? 'unknown') .
                       " | Account ID: " . $id .
                       " | Account Type: " . $type .
                       " | Account Balance: " . $balance .
                       " | Student ID: " . $student_id .
                       " | Edited by: " . $user;
            audit_log($conn, $user, $action, $module, $details);

        } else {
            $error = "Failed to update account.";
        }
        $stmt->close();
    } else {
        $error = "Please fill all required fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Finance Item | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <?php ui_css_link(); ?>
    <link rel="stylesheet" href="/school-admin-dashboard/assets/css/dashboard.css">
</head>
<body>
<?php render_admin_nav('accounts'); ?>
<div id="page-content-wrapper" class="w-100">
    <?php render_school_page_header("The Lord's Wisdom Academy Of Caloocan Inc."); ?>
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-7 col-lg-6">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-light">
                        <h4 class="mb-0"><i class="fas fa-edit"></i> Edit Finance Item</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                        <?php endif; ?>
                        <?php if ($success): ?>
                            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
                            <a href="account-view.php?student_id=<?= $student_id ?>" class="btn btn-outline-secondary mt-2"><i class="fas fa-arrow-left"></i> Back to Finance Profile</a>
                        <?php elseif (!$error): ?>
                        <form method="post">
                            <?= csrf_input() ?>
                            <input type="hidden" name="record_conflict_token" value="<?= htmlspecialchars($account_conflict_token) ?>">
                            <div class="mb-3">
                                <label for="type" class="form-label">Finance Type</label>
                                <select name="type" id="type" class="form-select" required onchange="toggleOtherType(this)">
                                    <?php foreach ($type_options as $opt): ?>
                                        <option value="<?= htmlspecialchars($opt) ?>" <?= $type==$opt?'selected':'' ?>>
                                            <?= htmlspecialchars($opt) ?>
                                        </option>
                                    <?php endforeach; ?>
                                    <option value="Other" <?= $type=='Other'?'selected':'' ?>>Other</option>
                                </select>
                                <input type="text" name="other_type" id="other_type" class="form-control mt-2" placeholder="Specify other type" style="display:none;">
                            </div>
                            <div class="mb-3">
                                <label for="balance" class="form-label">Balance</label>
                                <input type="number" name="balance" step="0.01" id="balance" class="form-control" value="<?= htmlspecialchars($balance) ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="notes" class="form-label">Notes</label>
                                <input type="text" name="notes" id="notes" class="form-control" value="<?= htmlspecialchars($notes) ?>">
                            </div>
                            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
                            <a href="account-view.php?student_id=<?= $student_id ?>" class="btn btn-outline-secondary ms-1">Cancel</a>
                        </form>
                        <script>
                        function toggleOtherType(sel) {
                            document.getElementById('other_type').style.display = sel.value === 'Other' ? 'block' : 'none';
                        }
                        document.addEventListener('DOMContentLoaded', function() {
                            var sel = document.getElementById('type');
                            toggleOtherType(sel);
                        });
                        </script>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if (file_exists('../../includes/footer.php')) include '../../includes/footer.php'; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="/school-admin-dashboard/assets/js/dashboard.js"></script>
</body>
</html>
<?php $conn->close(); ?>
