<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
include '../../config/database.php';
include __DIR__ . '/../settings/settings-permissions-roles.php';

$currentRole = $_SESSION['role'] ?? '';
if (!hasPermission($currentRole, 'financial', 'delete')) {
    admin_session_forbidden();
}

admin_csrf_token();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';
$account = null;

if ($id <= 0) {
    header("Location: account-list.php");
    exit();
}

$getStmt = $conn->prepare("SELECT id, student_id, type, balance FROM accounts WHERE id = ?");
$getStmt->bind_param("i", $id);
$getStmt->execute();
$result = $getStmt->get_result();
$account = $result->fetch_assoc();
$getStmt->close();

if (!$account) {
    header("Location: account-list.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_require_post_csrf();
    $submittedId = isset($_POST['id']) ? intval($_POST['id']) : 0;

    if ($submittedId !== (int) $account['id']) {
        $error = "Invalid deletion request.";
    } elseif (!isset($_POST['confirm_delete'])) {
        if ((int) $account['student_id'] > 0) {
            header("Location: account-view.php?student_id=" . (int) $account['student_id']);
        } else {
            header("Location: account-list.php");
        }
        exit();
    } else {
        $deleteStmt = $conn->prepare("DELETE FROM accounts WHERE id = ?");
        $deleteStmt->bind_param("i", $account['id']);
        $deleteStmt->execute();
        $deleteStmt->close();

        include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');
        $user = $_SESSION['username'] ?? 'unknown';
        $action = "Deleted account";
        $module = "Accounts";
        $details = "Role: " . ($_SESSION['role'] ?? 'unknown') .
                   " | Account ID: " . $account['id'] .
                   " | Account Type: " . $account['type'] .
                   " | Account Balance: " . $account['balance'] .
                   " | Student ID: " . $account['student_id'] .
                   " | Deleted by: " . $user;
        audit_log($conn, $user, $action, $module, $details);

        if ((int) $account['student_id'] > 0) {
            header("Location: account-view.php?student_id=" . (int) $account['student_id'] . "&deleted=1");
        } else {
            header("Location: account-list.php?deleted=1");
        }
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Finance Item | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="mt-5 mb-3">
        <h3><i class="fas fa-trash"></i> Delete Finance Item</h3>
        <hr>
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <div class="alert alert-danger">
            <strong>Warning:</strong> This action is irreversible and will permanently delete this finance item.
            <br>
            Finance Type: <strong><?= htmlspecialchars($account['type']) ?></strong>
            <br>
            Balance: <strong><?= htmlspecialchars(number_format((float) $account['balance'], 2)) ?></strong>
        </div>
        <form method="post">
            <input type="hidden" name="id" value="<?= (int) $account['id'] ?>">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(admin_csrf_token()) ?>">
            <button type="submit" name="confirm_delete" class="btn btn-danger">
                <i class="fas fa-trash"></i> Yes, Delete Permanently
            </button>
            <?php if ((int) $account['student_id'] > 0): ?>
                <a href="account-view.php?student_id=<?= (int) $account['student_id'] ?>" class="btn btn-secondary ms-2">Cancel</a>
            <?php else: ?>
                <a href="account-list.php" class="btn btn-secondary ms-2">Cancel</a>
            <?php endif; ?>
        </form>
    </div>
</div>
</body>
</html>
