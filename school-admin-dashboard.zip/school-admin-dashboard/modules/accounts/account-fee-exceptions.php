<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
include '../../config/database.php';
include __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/settings-security.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/account-fee-exceptions-helper.php';
require_once __DIR__ . '/finance-adjustment-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

$currentRole = $_SESSION['role'] ?? '';
if (!hasPermission($currentRole, 'account_mgmt', 'edit')) {
    admin_session_forbidden();
}

school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
student_fee_exceptions_ensure_table($conn);
finance_adjustment_ensure_tables($conn);

$studentId = isset($_GET['student_id']) ? (int) $_GET['student_id'] : 0;
$requestedSchoolYear = trim($_GET['school_year'] ?? '');
$activeSchoolYearLabel = school_year_get_active_label($conn);

$error = '';
$success = '';
$studentName = '';
$studentGrade = '';
$studentSchoolYear = '';
$selectedSchoolYear = '';

if ($studentId <= 0) {
    $error = 'Invalid student ID.';
} else {
    $stmt = $conn->prepare("SELECT CONCAT(lastname, ', ', firstname, ' ', middlename) AS student_name, grade, school_year_label FROM students WHERE id = ?");
    $stmt->bind_param('i', $studentId);
    $stmt->execute();
    $stmt->bind_result($studentName, $studentGrade, $studentSchoolYear);
    if (!$stmt->fetch()) {
        $error = 'Student not found.';
    }
    $stmt->close();
}

if ($error === '') {
    $selectedSchoolYear = $requestedSchoolYear !== '' ? $requestedSchoolYear : (trim((string) $studentSchoolYear) !== '' ? trim((string) $studentSchoolYear) : $activeSchoolYearLabel);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $error === '') {
    admin_require_post_csrf();
    $selectedSchoolYear = school_year_normalize_label((string) ($_POST['school_year_label'] ?? $selectedSchoolYear));
    $updatedBy = $_SESSION['username'] ?? 'unknown';
    $financeAdjustmentAction = (string) ($_POST['finance_adjustment_action'] ?? '');

    if ($financeAdjustmentAction === 'apply_template') {
        $templateId = (int) ($_POST['template_id'] ?? 0);
        $conn->begin_transaction();
        try {
            $result = finance_adjustment_apply_template($conn, $studentId, $studentGrade, $selectedSchoolYear, $templateId, $updatedBy);
            $conn->commit();
            $success = 'Finance adjustment applied. Updated ' . number_format((int) $result['changed']) . ' fee row(s).';
            if ((int) ($result['skipped'] ?? 0) > 0) {
                $success .= ' Skipped ' . number_format((int) $result['skipped']) . ' covered item(s) due to existing adjustments, missing fee rows, or payment activity.';
            }
            audit_log(
                $conn,
                $updatedBy,
                'Applied finance adjustment shortcut',
                'Fees',
                'Role: ' . ($_SESSION['role'] ?? 'unknown')
                    . " | Student ID: {$studentId}"
                    . " | Student Name: {$studentName}"
                    . " | SchoolYear: {$selectedSchoolYear}"
                    . " | Template ID: {$templateId}"
                    . ' | Changed: ' . (int) $result['changed']
                    . ' | Skipped: ' . (int) ($result['skipped'] ?? 0),
                'INFO'
            );
        } catch (Throwable $e) {
            $conn->rollback();
            $error = $e->getMessage();
        }
    } elseif ($financeAdjustmentAction === 'revert_adjustment') {
        $studentAdjustmentId = (int) ($_POST['student_adjustment_id'] ?? 0);
        $conn->begin_transaction();
        try {
            $result = finance_adjustment_revert($conn, $studentId, $selectedSchoolYear, $studentAdjustmentId, $updatedBy);
            $conn->commit();
            $success = 'Finance adjustment reverted. Removed ' . number_format((int) $result['deleted_exceptions']) . ' generated exception row(s).';
            audit_log(
                $conn,
                $updatedBy,
                'Reverted finance adjustment shortcut',
                'Fees',
                'Role: ' . ($_SESSION['role'] ?? 'unknown')
                    . " | Student ID: {$studentId}"
                    . " | Student Name: {$studentName}"
                    . " | SchoolYear: {$selectedSchoolYear}"
                    . " | Student Adjustment ID: {$studentAdjustmentId}",
                'WARNING'
            );
        } catch (Throwable $e) {
            $conn->rollback();
            $error = $e->getMessage();
        }
    } else {
        $rows = $_POST['rows'] ?? [];
        $changeCount = 0;
        $accountActions = [
            'added' => 0,
            'updated' => 0,
            'removed' => 0,
            'preserved_paid' => 0,
        ];

        $templateRows = student_fee_template_rows($conn, $studentGrade, $selectedSchoolYear);
        $templateMap = [];
        $currentMap = student_fee_exception_map($conn, $studentId, $selectedSchoolYear);
        foreach ($templateRows as $templateRow) {
            $templateMap[(string) $templateRow['fee_type_name']] = $templateRow;
        }

        $conn->begin_transaction();
        try {
            foreach ($rows as $feeTypeName => $row) {
                $feeTypeName = trim((string) $feeTypeName);
                if ($feeTypeName === '' || !isset($templateMap[$feeTypeName])) {
                    continue;
                }

                $mode = (string) ($row['mode'] ?? 'default');
                $note = trim((string) ($row['note'] ?? ''));
                $overrideAmount = null;
                if ($mode === 'override') {
                    $overrideAmount = isset($row['override_amount']) && $row['override_amount'] !== ''
                        ? (float) str_replace(',', '', (string) $row['override_amount'])
                        : null;
                    if ($overrideAmount === null || $overrideAmount < 0) {
                        throw new RuntimeException("Override amount is required for {$feeTypeName}.");
                    }
                }

                $current = $currentMap[$feeTypeName] ?? null;
                $currentMode = $current['mode'] ?? 'default';
                $currentOverride = $current['override_amount'] ?? null;
                $currentNote = trim((string) ($current['note'] ?? ''));
                if ($currentMode === $mode && (float) ($currentOverride ?? -1) === (float) ($overrideAmount ?? -1) && $currentNote === $note) {
                    continue;
                }

                student_fee_exception_upsert($conn, $studentId, $selectedSchoolYear, $feeTypeName, $mode, $overrideAmount, $note, $updatedBy);
                if ($mode === 'default') {
                    unset($currentMap[$feeTypeName]);
                } else {
                    $currentMap[$feeTypeName] = [
                        'mode' => $mode,
                        'override_amount' => $overrideAmount,
                        'note' => $note,
                        'updated_by' => $updatedBy,
                        'updated_at' => date('Y-m-d H:i:s'),
                    ];
                }
                $changeCount++;

                $effectiveRow = student_fee_exception_effective_row($templateMap[$feeTypeName], [
                    'mode' => $mode,
                    'override_amount' => $overrideAmount,
                    'note' => $note,
                    'updated_by' => $updatedBy,
                    'updated_at' => date('Y-m-d H:i:s'),
                ]);
                $apply = student_fee_apply_effective_account_rule(
                    $conn,
                    $studentId,
                    $selectedSchoolYear,
                    $feeTypeName,
                    (float) $effectiveRow['effective_amount'],
                    !empty($effectiveRow['is_excluded'])
                );
                if (isset($accountActions[$apply['status']])) {
                    $accountActions[$apply['status']]++;
                }
            }

            $conn->commit();
            if ($changeCount > 0) {
                $details = "Role: " . ($_SESSION['role'] ?? 'unknown')
                    . " | Student ID: {$studentId}"
                    . " | Student Name: {$studentName}"
                    . " | SchoolYear: {$selectedSchoolYear}"
                    . " | Exception Rows Changed: {$changeCount}"
                    . " | Accounts Added: {$accountActions['added']}"
                    . " | Accounts Updated: {$accountActions['updated']}"
                    . " | Accounts Removed: {$accountActions['removed']}"
                    . " | Paid Accounts Preserved: {$accountActions['preserved_paid']}";
                audit_log($conn, $updatedBy, 'Updated student fee exceptions', 'Fees', $details);
                $success = "Fee exceptions saved. Changed {$changeCount} row(s).";
            } else {
                $success = 'No fee exception changes were detected.';
            }
        } catch (Throwable $e) {
            $conn->rollback();
            $error = $e->getMessage();
        }
    }
}

$templateRows = $error === '' ? student_fee_template_rows($conn, $studentGrade, $selectedSchoolYear) : [];
$exceptionMap = $error === '' ? student_fee_exception_map($conn, $studentId, $selectedSchoolYear) : [];
$accountStateMap = $error === '' ? student_fee_account_state_map($conn, $studentId, $selectedSchoolYear) : [];
$financeAdjustmentTablesReady = $error === '' ? finance_adjustment_tables_ready($conn) : false;
$financeAdjustmentTemplates = $financeAdjustmentTablesReady ? finance_adjustment_applicable_templates($conn, $studentGrade, $selectedSchoolYear) : [];
$financeAdjustmentAppliedMap = $financeAdjustmentTablesReady ? finance_adjustment_applied_map($conn, $studentId, $selectedSchoolYear) : [];
$financeAdjustmentAppliedRows = $financeAdjustmentTablesReady ? finance_adjustment_applied_rows($conn, $studentId, $selectedSchoolYear) : [];
$financeAdjustmentPreviews = [];
foreach ($financeAdjustmentTemplates as $adjustmentTemplate) {
    $financeAdjustmentPreviews[(int) $adjustmentTemplate['id']] = finance_adjustment_preview($adjustmentTemplate, $templateRows, $accountStateMap, $exceptionMap);
}
$effectiveRows = [];
foreach ($templateRows as $templateRow) {
    $feeTypeName = (string) $templateRow['fee_type_name'];
    $effectiveRows[] = student_fee_exception_effective_row($templateRow, $exceptionMap[$feeTypeName] ?? null);
}

$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";
$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Fee Exceptions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --vw-page-bg:#eef3f9;
            --vw-card-bg:#ffffff;
            --vw-card-border:#d9e3ef;
            --vw-brand-dark:#23395d;
            --vw-brand-mid:#517fa4;
            --vw-brand-soft:#edf4fb;
            --vw-text-soft:#5f7186;
        }
        body {
            font-family:'Segoe UI','Roboto','Arial',sans-serif;
            background:
                radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 30%),
                linear-gradient(180deg, #f8fbff 0%, var(--vw-page-bg) 100%);
            color: var(--vw-brand-dark);
        }
        .dashboard-header {
            text-align:center;
            padding:32px 0 14px;
        }
        .dashboard-header img {
            width:72px;
            height:72px;
            border-radius:18px;
            background:#fff;
            padding:6px;
            box-shadow:0 10px 25px rgba(35,57,93,0.12);
        }
        .dashboard-header h1 {
            font-weight:800;
            color:var(--vw-brand-dark);
            font-size:1.35rem;
        }
        .main-card {
            max-width:min(1680px, calc(100vw - 32px));
            margin:0 auto 36px;
            background:var(--vw-card-bg);
            border:1px solid var(--vw-card-border);
            border-radius:22px;
            box-shadow:0 16px 36px rgba(35,57,93,0.08);
            overflow:hidden;
        }
        .main-card .card-header {
            background:linear-gradient(135deg, var(--vw-brand-dark), var(--vw-brand-mid));
            color:#fff;
            border:0;
            padding:18px 24px;
        }
        .meta-strip {
            background:var(--vw-brand-soft);
            border:1px solid var(--vw-card-border);
            border-radius:18px;
            padding:14px 18px;
        }
        .meta-chip {
            display:inline-flex;
            align-items:center;
            gap:8px;
            padding:8px 12px;
            border-radius:999px;
            background:#fff;
            border:1px solid var(--vw-card-border);
            font-weight:700;
            color:var(--vw-brand-dark);
            margin:4px 8px 4px 0;
        }
        .table thead th {
            background:var(--vw-brand-soft);
            color:var(--vw-brand-dark);
            border-bottom:1px solid var(--vw-card-border);
            vertical-align:middle;
        }
        .table tbody td {
            vertical-align:middle;
            background:#fbfdff;
        }
        .form-select, .form-control {
            border-radius:12px;
            border-color:#d7e1ed;
        }
        .status-note {
            font-size:.86rem;
            color:var(--vw-text-soft);
        }
        .safe-badge {
            border-radius:999px;
            font-weight:700;
            padding:.45rem .7rem;
        }
        .shortcut-grid {
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(min(420px,100%),1fr));
            gap:1rem;
        }
        .shortcut-card {
            border:1px solid #dce6f1;
            border-radius:16px;
            background:#ffffff;
            padding:1rem;
            height:100%;
            box-shadow:0 10px 26px rgba(35,57,93,0.055);
        }
        .shortcut-title {
            font-weight:800;
            color:var(--vw-brand-dark);
        }
        .shortcut-meta {
            font-size:.84rem;
            color:var(--vw-text-soft);
        }
        .shortcut-breakdown {
            border:1px solid #e4ebf4;
            border-radius:14px;
            background:#f6f9fc;
            padding:.7rem;
            display:grid;
            gap:.6rem;
        }
        .shortcut-breakdown-title {
            display:flex;
            justify-content:space-between;
            align-items:center;
            gap:.75rem;
            flex-wrap:wrap;
            padding:.25rem .15rem .45rem;
            color:#34465b;
            font-weight:900;
        }
        .shortcut-breakdown-title .small {
            font-weight:700;
            color:var(--vw-text-soft);
        }
        .shortcut-summary {
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(130px,1fr));
            gap:.65rem;
            margin:.85rem 0;
        }
        .shortcut-summary-item {
            border:1px solid #e4ebf4;
            border-radius:12px;
            background:linear-gradient(180deg,#ffffff 0%,#fbfdff 100%);
            padding:.7rem .8rem;
            box-shadow:0 4px 12px rgba(35,57,93,0.035);
        }
        .shortcut-summary-label {
            color:var(--vw-text-soft);
            font-size:.76rem;
            font-weight:800;
            text-transform:uppercase;
        }
        .shortcut-summary-value {
            color:var(--vw-brand-dark);
            font-weight:900;
            font-size:.98rem;
            margin-top:.15rem;
        }
        .shortcut-details-toggle {
            border-radius:10px;
            font-weight:800;
            border-color:#9bb7d4;
            color:#25476d;
            background:#f8fbff;
        }
        .breakdown-actions {
            display:flex;
            justify-content:space-between;
            align-items:center;
            gap:.75rem;
            flex-wrap:wrap;
            margin:.35rem 0 .85rem;
        }
        .shortcut-row {
            display:grid;
            grid-template-columns:minmax(220px,1.25fr) repeat(3,minmax(120px,.7fr)) minmax(120px,.5fr);
            gap:.85rem;
            padding:.9rem 1rem;
            border:1px solid #e7eef7;
            border-radius:12px;
            font-size:.9rem;
            align-items:center;
            background:#fff;
            box-shadow:0 4px 12px rgba(35,57,93,0.025);
        }
        .shortcut-row:hover {
            border-color:#cbd8e6;
            box-shadow:0 6px 16px rgba(35,57,93,0.055);
        }
        .shortcut-row > div {
            min-width:0;
        }
        .shortcut-row .fw-semibold,
        .shortcut-row .small {
            overflow-wrap:anywhere;
        }
        .breakdown-label {
            display:block;
            color:var(--vw-text-soft);
            font-size:.7rem;
            font-weight:800;
            text-transform:uppercase;
            letter-spacing:0;
        }
        .breakdown-value {
            display:block;
            font-weight:800;
            color:var(--vw-brand-dark);
        }
        .shortcut-row.locked { background:#fffaf3; border-color:#fed7aa; color:#8a4b12; }
        .shortcut-row.missing { background:#fafbfc; border-color:#e2e8f0; color:#566579; }
        .shortcut-row.adjusted { background:#f3fbfc; border-color:#ccecf2; color:#245b66; }
        .shortcut-row.ready { background:#f5fbf7; border-color:#cfead7; }
        .breakdown-help-row {
            font-size:.82rem;
            padding:.62rem .85rem;
            box-shadow:none;
            grid-template-columns:1fr;
        }
        .shortcut-badge {
            border-radius:999px;
            font-size:.75rem;
            font-weight:800;
            padding:.4rem .6rem;
        }
        .shortcut-row .badge {
            border-radius:999px;
            border:1px solid transparent;
            font-weight:800;
            padding:.38rem .55rem;
        }
        .shortcut-row .text-bg-info {
            background:#dff7fb !important;
            color:#155e75 !important;
            border-color:#a7e3ee;
        }
        .shortcut-row .text-bg-secondary {
            background:#eef2f7 !important;
            color:#475569 !important;
            border-color:#d7dee8;
        }
        .shortcut-row .text-bg-warning {
            background:#fff4d6 !important;
            color:#8a4b12 !important;
            border-color:#f4d38b;
        }
        .shortcut-row .text-bg-light {
            background:#ffffff !important;
            color:#23395d !important;
            border-color:#dbe7f3 !important;
        }
        .shortcut-empty {
            border:1px dashed #cbd8e6;
            border-radius:16px;
            background:#f8fbff;
            padding:1rem 1.1rem;
            color:var(--vw-brand-dark);
        }
        .shortcut-empty .empty-title {
            font-weight:800;
            margin-bottom:.25rem;
        }
        .shortcut-empty ul {
            margin:.5rem 0 0;
            padding-left:1.15rem;
            color:var(--vw-text-soft);
        }
        .history-card {
            border:1px solid #e2eaf5;
            border-radius:16px;
            background:#fff;
            padding:.9rem 1rem;
            margin-bottom:.75rem;
        }
        .adjustment-record-panel {
            border:1px solid #d9e3ef;
            border-radius:16px;
            background:#fff;
            overflow:hidden;
        }
        .adjustment-record-head {
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            gap:1rem;
            flex-wrap:wrap;
            padding:1rem;
            background:#fbfdff;
            border-bottom:1px solid #e7eef7;
        }
        .adjustment-record-metrics {
            display:flex;
            gap:.5rem;
            flex-wrap:wrap;
        }
        .record-metric {
            border:1px solid #dbe7f3;
            border-radius:999px;
            padding:.4rem .65rem;
            background:#fff;
            font-size:.82rem;
            font-weight:800;
            color:var(--vw-brand-dark);
        }
        .adjustment-record-table th {
            white-space:nowrap;
        }
        .adjustment-record-table td {
            vertical-align:middle;
        }
        .record-breakdown-table {
            margin:0;
            background:#fff;
        }
        .record-breakdown-table th {
            font-size:.76rem;
            color:var(--vw-text-soft);
            text-transform:uppercase;
        }
        .source-badge {
            display:inline-flex;
            align-items:center;
            gap:5px;
            border-radius:999px;
            font-size:.72rem;
            font-weight:800;
            padding:.35rem .55rem;
            margin-top:.4rem;
        }
        .source-badge.manual { background:#eef2ff; color:#3730a3; border:1px solid #c7d2fe; }
        .source-badge.finance_adjustment { background:#ecfdf3; color:#067647; border:1px solid #abefc6; }
        .source-badge.default { background:#f8fafc; color:#64748b; border:1px solid #e2e8f0; }
        .collapse:not(.show) {
            display:none;
        }
        .fee-exception-table {
            table-layout:auto;
        }
        .fee-exception-table th,
        .fee-exception-table td {
            white-space:normal;
        }
        .fee-exception-table .form-control,
        .fee-exception-table .form-select {
            min-width:0;
        }
        @media (max-width: 992px) {
            .main-card {
                max-width:calc(100vw - 18px);
            }
            .main-card .card-body {
                padding:1rem !important;
            }
            .shortcut-grid {
                grid-template-columns:1fr;
            }
            .shortcut-summary {
                grid-template-columns:1fr 1fr;
            }
            .shortcut-row {
                grid-template-columns:1fr;
            }
            .shortcut-row .text-end {
                text-align:left !important;
            }
        }
    </style>
</head>
<body>
<div class="dashboard-header">
    <img src="/school-admin-dashboard/uploads/logo1.png" alt="School Logo" class="mb-2 rounded shadow-sm">
    <h1><?= htmlspecialchars($schoolName) ?></h1>
</div>
<div class="container-fluid px-3 px-xl-4">
    <?php if ($error !== ''): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success !== ''): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <?php if ($error === ''): ?>
        <div class="main-card card">
            <div class="card-header">
                <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
                    <div>
                        <div class="h4 mb-0"><i class="fas fa-sliders-h me-2"></i>Student Fee Exceptions</div>
                    </div>
                    <a href="account-view.php?student_id=<?= $studentId ?>&school_year=<?= urlencode($selectedSchoolYear) ?>" class="btn btn-light fw-bold">
                        <i class="fas fa-arrow-left me-2"></i>Back to Account Overview
                    </a>
                </div>
            </div>
            <div class="card-body p-4">
                <div class="meta-strip mb-4">
                    <div class="meta-chip"><i class="fas fa-user-graduate"></i><?= htmlspecialchars($studentName) ?></div>
                    <div class="meta-chip"><i class="fas fa-layer-group"></i><?= htmlspecialchars($studentGrade) ?></div>
                    <div class="meta-chip"><i class="fas fa-calendar-alt"></i><?= htmlspecialchars($selectedSchoolYear) ?></div>
                </div>
                <div class="alert alert-info">
                    Use this page only for student-specific fee differences. Required fees apply by default. Optional and conditional fees only apply when included or overridden here. Paid accounts are preserved for safety.
                </div>

                <div class="section-card p-3 mb-4">
                    <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
                        <div>
                            <h5 class="mb-1"><i class="fas fa-tags me-2"></i>Finance Adjustment Shortcuts</h5>
                            <div class="text-muted">Voucher, subsidy, discount, and grant shortcuts only create finance exceptions. They do not create payments or receipts.</div>
                        </div>
                    </div>
                    <?php if (!$financeAdjustmentTablesReady): ?>
                        <div class="alert alert-warning mb-0">Finance adjustment shortcut schema is not ready. Run the migration tool first.</div>
                    <?php elseif (!$financeAdjustmentTemplates): ?>
                        <div class="shortcut-empty">
                            <div class="empty-title"><i class="fas fa-circle-info me-2"></i>No matching active shortcut yet</div>
                            <div>No active voucher, subsidy, discount, or grant template matches this student's grade and school year.</div>
                            <ul>
                                <li>Check the template school year: <?= htmlspecialchars($selectedSchoolYear) ?></li>
                                <li>Check the applicable grade: <?= htmlspecialchars($studentGrade) ?></li>
                                <li>Make sure the template is active and has covered fee types selected.</li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <div class="shortcut-grid">
                            <?php foreach ($financeAdjustmentTemplates as $adjustmentTemplate): ?>
                                <?php
                                $adjustmentId = (int) $adjustmentTemplate['id'];
                                $preview = $financeAdjustmentPreviews[$adjustmentId] ?? ['items' => [], 'total_applied' => 0, 'skipped' => 0, 'ready_count' => 0];
                                $isApplied = isset($financeAdjustmentAppliedMap[$adjustmentId]);
                                $hasRemainingRows = (int) ($preview['ready_count'] ?? 0) > 0;
                                $typeLabel = finance_adjustment_types()[(string) $adjustmentTemplate['adjustment_type']] ?? 'Adjustment';
                                $configuredFeeCount = count($adjustmentTemplate['fee_amounts_map'] ?? []);
                                $summaryCurrentTotal = 0.0;
                                $summaryVoucherTotal = 0.0;
                                $summarySkippedCount = 0;
                                $summaryAdjustedCount = 0;
                                foreach (($preview['items'] ?? []) as $summaryItem) {
                                    $summaryStatus = (string) ($summaryItem['status'] ?? '');
                                    if ($summaryStatus === 'missing_template') {
                                        $summarySkippedCount++;
                                        continue;
                                    }
                                    $summaryCurrentTotal += (float) ($summaryItem['original_amount'] ?? 0);
                                    $summaryVoucherTotal += (float) ($summaryItem['applied_amount'] ?? 0);
                                    if ($summaryStatus === 'locked_paid') {
                                        $summarySkippedCount++;
                                    } elseif ($summaryStatus === 'already_adjusted') {
                                        $summaryAdjustedCount++;
                                    }
                                }
                                $summaryResultTotal = max(0.0, $summaryCurrentTotal - $summaryVoucherTotal);
                                $collapseId = 'shortcutBreakdown' . $adjustmentId;
                                ?>
                                <div class="shortcut-card">
                                    <div class="d-flex justify-content-between align-items-start gap-2 mb-2">
                                        <div>
                                            <div class="shortcut-title"><?= htmlspecialchars((string) $adjustmentTemplate['name']) ?></div>
                                            <div class="shortcut-meta"><?= htmlspecialchars($typeLabel) ?> | <?= number_format($configuredFeeCount) ?> configured fee type(s)</div>
                                        </div>
                                        <span class="badge <?= $isApplied ? ($hasRemainingRows ? 'text-bg-warning' : 'text-bg-success') : 'text-bg-primary' ?> shortcut-badge">
                                            <?= $isApplied ? ($hasRemainingRows ? 'Has remaining' : 'Applied') : 'Available' ?>
                                        </span>
                                    </div>
                                    <?php if (trim((string) ($adjustmentTemplate['notes'] ?? '')) !== ''): ?>
                                        <div class="small text-muted mb-2"><?= htmlspecialchars((string) $adjustmentTemplate['notes']) ?></div>
                                    <?php endif; ?>
                                    <div class="shortcut-summary">
                                        <div class="shortcut-summary-item">
                                            <div class="shortcut-summary-label">Current</div>
                                            <div class="shortcut-summary-value">PHP <?= number_format($summaryCurrentTotal, 2) ?></div>
                                        </div>
                                        <div class="shortcut-summary-item">
                                            <div class="shortcut-summary-label">Voucher</div>
                                            <div class="shortcut-summary-value">-PHP <?= number_format($summaryVoucherTotal, 2) ?></div>
                                        </div>
                                        <div class="shortcut-summary-item">
                                            <div class="shortcut-summary-label">Result</div>
                                            <div class="shortcut-summary-value">PHP <?= number_format($summaryResultTotal, 2) ?></div>
                                        </div>
                                        <div class="shortcut-summary-item">
                                            <div class="shortcut-summary-label">Ready / Skipped</div>
                                            <div class="shortcut-summary-value"><?= number_format((int) ($preview['ready_count'] ?? 0)) ?> / <?= number_format($summarySkippedCount) ?></div>
                                        </div>
                                        <div class="shortcut-summary-item">
                                            <div class="shortcut-summary-label">Already Adjusted</div>
                                            <div class="shortcut-summary-value"><?= number_format($summaryAdjustedCount) ?></div>
                                        </div>
                                    </div>
                                    <div class="breakdown-actions">
                                        <button class="btn btn-outline-primary btn-sm shortcut-details-toggle" type="button" data-bs-toggle="collapse" data-bs-target="#<?= htmlspecialchars($collapseId) ?>" aria-expanded="false" aria-controls="<?= htmlspecialchars($collapseId) ?>">
                                            <i class="fas fa-list-ul me-1"></i>View Breakdown
                                        </button>
                                        <div class="small text-muted">
                                            Preview only. No changes happen until Apply is clicked.
                                        </div>
                                    </div>
                                    <div class="collapse" id="<?= htmlspecialchars($collapseId) ?>">
                                    <div class="shortcut-breakdown mb-3">
                                        <div class="shortcut-breakdown-title">
                                            <span><i class="fas fa-receipt me-1"></i>Prospective Breakdown</span>
                                            <span class="small">Current minus <?= htmlspecialchars(strtolower($typeLabel)) ?> equals result</span>
                                        </div>
                                        <?php foreach (($preview['items'] ?? []) as $item): ?>
                                            <?php
                                            $rowStatus = (string) ($item['status'] ?? '');
                                            $rowClass = $rowStatus === 'locked_paid'
                                                ? 'locked'
                                                : ($rowStatus === 'missing_template'
                                                    ? 'missing'
                                                    : ($rowStatus === 'already_adjusted' ? 'adjusted' : ($rowStatus === 'ready' ? 'ready' : '')));
                                            ?>
                                            <div class="shortcut-row <?= htmlspecialchars($rowClass) ?>">
                                                <div>
                                                    <div class="fw-semibold"><?= htmlspecialchars((string) ($item['fee_type_name'] ?? '')) ?></div>
                                                </div>
                                                <div>
                                                    <span class="breakdown-label">Current</span>
                                                    <span class="breakdown-value">PHP <?= number_format((float) ($item['original_amount'] ?? 0), 2) ?></span>
                                                </div>
                                                <div>
                                                    <span class="breakdown-label"><?= htmlspecialchars($typeLabel) ?></span>
                                                    <span class="breakdown-value">-PHP <?= number_format((float) ($item['applied_amount'] ?? 0), 2) ?></span>
                                                    <?php if ((float) ($item['configured_amount'] ?? 0) > (float) ($item['applied_amount'] ?? 0)): ?>
                                                        <span class="small text-muted">Template: PHP <?= number_format((float) $item['configured_amount'], 2) ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <div>
                                                    <span class="breakdown-label">Result</span>
                                                    <span class="breakdown-value">PHP <?= number_format((float) ($item['target_amount'] ?? 0), 2) ?></span>
                                                </div>
                                                <div class="text-end">
                                                    <?php if ($rowStatus === 'locked_paid'): ?>
                                                        <span class="badge text-bg-warning">Has payment</span>
                                                    <?php elseif ($rowStatus === 'missing_template'): ?>
                                                        <span class="badge text-bg-secondary">Skipped</span>
                                                    <?php elseif ($rowStatus === 'already_adjusted'): ?>
                                                        <span class="badge text-bg-info">Already adjusted</span>
                                                    <?php else: ?>
                                                        <span class="badge text-bg-light text-dark border">-PHP <?= number_format((float) ($item['applied_amount'] ?? 0), 2) ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <?php if ($rowStatus === 'missing_template'): ?>
                                                <div class="shortcut-row missing breakdown-help-row">
                                                    <div class="small">
                                                        This fee type is not in <?= htmlspecialchars($studentGrade) ?> for <?= htmlspecialchars($selectedSchoolYear) ?>, so it will not be applied or created.
                                                    </div>
                                                    <div></div><div></div><div></div><div></div>
                                                </div>
                                            <?php endif; ?>
                                            <?php if ($rowStatus === 'already_adjusted'): ?>
                                                <div class="shortcut-row adjusted breakdown-help-row">
                                                    <div class="small">
                                                        This fee already has an exception<?= trim((string) ($item['existing_source_label'] ?? '')) !== '' ? ' from ' . htmlspecialchars((string) $item['existing_source_label']) : '' ?>, so it will be skipped and kept as-is.
                                                    </div>
                                                    <div></div><div></div><div></div><div></div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </div>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center gap-2">
                                        <div class="small text-muted">
                                            Shortcut effect: <strong>PHP <?= number_format($summaryVoucherTotal, 2) ?></strong>
                                            <br><?= number_format((int) ($preview['ready_count'] ?? 0)) ?> remaining fee row(s) ready.
                                            <?php if ($summarySkippedCount > 0): ?>
                                                <br><?= number_format($summarySkippedCount) ?> item(s) will be skipped.
                                            <?php endif; ?>
                                            <?php if ($summaryAdjustedCount > 0): ?>
                                                <br><?= number_format($summaryAdjustedCount) ?> already adjusted item(s) will stay as-is.
                                            <?php endif; ?>
                                        </div>
                                        <form method="post" onsubmit="return confirm('Apply this finance adjustment shortcut to this student? This creates finance exceptions only, not payments.');">
                                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(admin_csrf_token()) ?>">
                                            <input type="hidden" name="school_year_label" value="<?= htmlspecialchars($selectedSchoolYear) ?>">
                                            <input type="hidden" name="finance_adjustment_action" value="apply_template">
                                            <input type="hidden" name="template_id" value="<?= $adjustmentId ?>">
                                            <button type="submit" class="btn btn-primary btn-sm" <?= !$hasRemainingRows ? 'disabled' : '' ?>>
                                                <i class="fas fa-check me-1"></i><?= $isApplied ? 'Apply Remaining' : 'Apply' ?>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if (false && $financeAdjustmentTablesReady && $financeAdjustmentAppliedRows): ?>
                <?php
                $recordAppliedCount = 0;
                $recordRevertedCount = 0;
                $recordVoucherTotal = 0.0;
                foreach ($financeAdjustmentAppliedRows as $recordSummaryRow) {
                    if ((string) ($recordSummaryRow['status'] ?? '') === 'applied') {
                        $recordAppliedCount++;
                    } else {
                        $recordRevertedCount++;
                    }
                    foreach (($recordSummaryRow['snapshot']['items'] ?? []) as $recordSummaryItem) {
                        if (($recordSummaryItem['account_action'] ?? '') !== '') {
                            $recordVoucherTotal += (float) ($recordSummaryItem['applied_amount'] ?? 0);
                        }
                    }
                }
                ?>
                <div class="section-card p-3 mb-4">
                    <div class="adjustment-record-panel">
                        <div class="adjustment-record-head">
                            <div>
                                <h5 class="mb-1"><i class="fas fa-file-invoice-dollar me-2"></i>Applied Voucher / Adjustment Records</h5>
                                <div class="text-muted">Student-specific voucher, subsidy, discount, and grant records. Default minimized for cleaner viewing.</div>
                            </div>
                            <div class="d-flex align-items-start gap-2 flex-wrap justify-content-end">
                                <div class="adjustment-record-metrics">
                                    <span class="record-metric"><?= number_format($recordAppliedCount) ?> Applied</span>
                                    <span class="record-metric"><?= number_format($recordRevertedCount) ?> Reverted</span>
                                    <span class="record-metric">Voucher PHP <?= number_format($recordVoucherTotal, 2) ?></span>
                                </div>
                                <button class="btn btn-outline-primary btn-sm fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#appliedAdjustmentRecordsBody" aria-expanded="false" aria-controls="appliedAdjustmentRecordsBody">
                                    <i class="fas fa-table me-1"></i>View Records
                                </button>
                            </div>
                        </div>
                        <div class="collapse" id="appliedAdjustmentRecordsBody">
                            <div class="table-responsive">
                                <table class="table table-striped align-middle mb-0 adjustment-record-table">
                                    <thead>
                                        <tr>
                                            <th>Template</th>
                                            <th>Type</th>
                                            <th>Current</th>
                                            <th>Voucher</th>
                                            <th>Result</th>
                                            <th>Fees</th>
                                            <th>Status</th>
                                            <th>Applied</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($financeAdjustmentAppliedRows as $appliedRow): ?>
                                            <?php
                                            $snapshotItems = $appliedRow['snapshot']['items'] ?? [];
                                            $revertLocked = false;
                                            $affectedCount = 0;
                                            $skippedCount = 0;
                                            $currentTotal = 0.0;
                                            $voucherTotal = 0.0;
                                            $resultTotal = 0.0;
                                            foreach ($snapshotItems as $snapshotItem) {
                                                $feeTypeName = (string) ($snapshotItem['fee_type_name'] ?? '');
                                                if ($feeTypeName === '') {
                                                    continue;
                                                }
                                                if (($snapshotItem['account_action'] ?? '') === '') {
                                                    $skippedCount++;
                                                    continue;
                                                }
                                                $affectedCount++;
                                                $currentTotal += (float) ($snapshotItem['original_amount'] ?? 0);
                                                $voucherTotal += (float) ($snapshotItem['applied_amount'] ?? 0);
                                                $resultTotal += (float) ($snapshotItem['target_amount'] ?? 0);
                                                if ((int) (($accountStateMap[$feeTypeName]['payment_count'] ?? 0)) > 0) {
                                                    $revertLocked = true;
                                                }
                                            }
                                            $isAppliedStatus = (string) ($appliedRow['status'] ?? '') === 'applied';
                                            $recordCollapseId = 'appliedAdjustmentRecord' . (int) ($appliedRow['id'] ?? 0);
                                            ?>
                                            <tr>
                                                <td>
                                                    <div class="fw-bold"><?= htmlspecialchars((string) ($appliedRow['name'] ?? 'Finance Adjustment')) ?></div>
                                                    <div class="small text-muted">Record #<?= (int) ($appliedRow['id'] ?? 0) ?></div>
                                                </td>
                                                <td><?= htmlspecialchars(finance_adjustment_types()[(string) ($appliedRow['adjustment_type'] ?? '')] ?? 'Adjustment') ?></td>
                                                <td class="fw-bold">PHP <?= number_format($currentTotal, 2) ?></td>
                                                <td class="fw-bold">-PHP <?= number_format($voucherTotal, 2) ?></td>
                                                <td class="fw-bold">PHP <?= number_format($resultTotal, 2) ?></td>
                                                <td>
                                                    <?= number_format($affectedCount) ?> affected
                                                    <?php if ($skippedCount > 0): ?>
                                                        <div class="small text-muted"><?= number_format($skippedCount) ?> skipped</div>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <span class="badge <?= $isAppliedStatus ? 'text-bg-success' : 'text-bg-secondary' ?>">
                                                        <?= $isAppliedStatus ? 'Applied' : 'Reverted' ?>
                                                    </span>
                                                    <?php if ($isAppliedStatus && $revertLocked): ?>
                                                        <div class="small text-warning fw-bold mt-1">Revert locked</div>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div class="fw-bold"><?= htmlspecialchars((string) ($appliedRow['applied_by'] ?? 'System')) ?></div>
                                                    <div class="small text-muted"><?= !empty($appliedRow['applied_at']) ? htmlspecialchars(date('M j, Y g:i A', strtotime((string) $appliedRow['applied_at']))) : '' ?></div>
                                                </td>
                                                <td>
                                                    <div class="d-flex gap-2 flex-wrap">
                                                        <button class="btn btn-outline-primary btn-sm" type="button" data-bs-toggle="collapse" data-bs-target="#<?= htmlspecialchars($recordCollapseId) ?>">
                                                            <i class="fas fa-list-ul"></i>
                                                        </button>
                                                        <?php if ($isAppliedStatus): ?>
                                                            <form method="post" onsubmit="return confirm('Revert this applied shortcut? This restores affected fee balances only if no payment activity exists.');">
                                                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(admin_csrf_token()) ?>">
                                                                <input type="hidden" name="school_year_label" value="<?= htmlspecialchars($selectedSchoolYear) ?>">
                                                                <input type="hidden" name="finance_adjustment_action" value="revert_adjustment">
                                                                <input type="hidden" name="student_adjustment_id" value="<?= (int) $appliedRow['id'] ?>">
                                                                <button type="submit" class="btn btn-outline-danger btn-sm" <?= $revertLocked ? 'disabled' : '' ?>>
                                                                    <i class="fas fa-rotate-left"></i>
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr class="collapse" id="<?= htmlspecialchars($recordCollapseId) ?>">
                                                <td colspan="9" class="p-0">
                                                    <table class="table table-sm record-breakdown-table">
                                                        <thead>
                                                            <tr>
                                                                <th>Fee Type</th>
                                                                <th>Current</th>
                                                                <th>Voucher</th>
                                                                <th>Result</th>
                                                                <th>Status</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php foreach ($snapshotItems as $snapshotItem): ?>
                                                                <?php
                                                                $itemAction = (string) ($snapshotItem['account_action'] ?? '');
                                                                $itemStatus = $itemAction !== '' ? 'Applied' : 'Skipped';
                                                                ?>
                                                                <tr>
                                                                    <td><?= htmlspecialchars((string) ($snapshotItem['fee_type_name'] ?? '')) ?></td>
                                                                    <td>PHP <?= number_format((float) ($snapshotItem['original_amount'] ?? 0), 2) ?></td>
                                                                    <td>-PHP <?= number_format((float) ($snapshotItem['applied_amount'] ?? 0), 2) ?></td>
                                                                    <td>PHP <?= number_format((float) ($snapshotItem['target_amount'] ?? 0), 2) ?></td>
                                                                    <td><span class="badge <?= $itemAction !== '' ? 'text-bg-success' : 'text-bg-secondary' ?>"><?= htmlspecialchars($itemStatus) ?></span></td>
                                                                </tr>
                                                            <?php endforeach; ?>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <form method="post">
                    <?= csrf_input() ?>
                    <input type="hidden" name="school_year_label" value="<?= htmlspecialchars($selectedSchoolYear) ?>">
                    <div class="table-responsive">
                        <table class="table table-bordered align-middle fee-exception-table">
                            <thead>
                                <tr>
                                    <th style="width:18%;">Fee Type</th>
                                    <th style="width:11%;">Default Amount</th>
                                    <th style="width:18%;">Student Rule</th>
                                    <th style="width:12%;">Override Amount</th>
                                    <th style="width:19%;">Note</th>
                                    <th style="width:13%;">Current Account State</th>
                                    <th style="width:9%;">Last Touch</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!$effectiveRows): ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted py-4">No grade-based fee template rows were found for this student and school year.</td>
                                    </tr>
                                <?php endif; ?>
                                <?php foreach ($effectiveRows as $row): ?>
                                    <?php
                                    $feeTypeName = (string) $row['fee_type_name'];
                                    $accountState = $accountStateMap[$feeTypeName] ?? null;
                                    $paymentCount = (int) ($accountState['payment_count'] ?? 0);
                                    $sourceType = (string) ($row['source_type'] ?? 'default');
                                    $sourceLabel = trim((string) ($row['source_label'] ?? ''));
                                    $sourceText = 'Default Fee';
                                    $sourceIcon = 'fa-layer-group';
                                    if ($sourceType === 'finance_adjustment') {
                                        $sourceText = $sourceLabel !== '' ? ('Applied by ' . $sourceLabel) : 'Applied by Shortcut';
                                        $sourceIcon = 'fa-tags';
                                    } elseif ($sourceType === 'manual') {
                                        $sourceText = 'Manual Override';
                                        $sourceIcon = 'fa-pen-to-square';
                                    }
                                    ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold"><?= htmlspecialchars($feeTypeName) ?></div>
                                            <div class="small text-muted mb-2">Behavior: <?= htmlspecialchars(fee_behavior_label((string) ($row['application_mode'] ?? 'required'))) ?></div>
                                            <?php if (!empty($row['is_excluded'])): ?>
                                                <span class="badge text-bg-danger safe-badge mt-2">Excluded</span>
                                            <?php elseif ($row['mode'] === 'include'): ?>
                                                <span class="badge text-bg-success safe-badge mt-2">Included</span>
                                            <?php elseif ($row['mode'] === 'override'): ?>
                                                <span class="badge text-bg-warning safe-badge mt-2">Override</span>
                                            <?php elseif (empty($row['should_apply'])): ?>
                                                <span class="badge text-bg-secondary safe-badge mt-2">Not Applied</span>
                                            <?php else: ?>
                                                <span class="badge text-bg-secondary safe-badge mt-2">Default</span>
                                            <?php endif; ?>
                                            <div>
                                                <span class="source-badge <?= htmlspecialchars($sourceType) ?>">
                                                    <i class="fas <?= htmlspecialchars($sourceIcon) ?>"></i><?= htmlspecialchars($sourceText) ?>
                                                </span>
                                            </div>
                                        </td>
                                        <td class="fw-bold">PHP <?= number_format((float) $row['default_amount'], 2) ?></td>
                                        <td>
                                            <select name="rows[<?= htmlspecialchars($feeTypeName) ?>][mode]" class="form-select fee-mode-field">
                                                <?php if (($row['application_mode'] ?? 'required') === 'required'): ?>
                                                    <option value="default" <?= $row['mode'] === 'default' ? 'selected' : '' ?>>Default Template</option>
                                                    <option value="exclude" <?= $row['mode'] === 'exclude' ? 'selected' : '' ?>>Exclude For Student</option>
                                                <?php else: ?>
                                                    <option value="default" <?= $row['mode'] === 'default' ? 'selected' : '' ?>>Not Applied</option>
                                                    <option value="include" <?= $row['mode'] === 'include' ? 'selected' : '' ?>>Include Standard Amount</option>
                                                <?php endif; ?>
                                                <option value="override" <?= $row['mode'] === 'override' ? 'selected' : '' ?>>Override Amount</option>
                                            </select>
                                        </td>
                                        <td>
                                            <input
                                                type="number"
                                                step="0.01"
                                                min="0"
                                                class="form-control"
                                                name="rows[<?= htmlspecialchars($feeTypeName) ?>][override_amount]"
                                                value="<?= $row['override_amount'] !== null ? htmlspecialchars((string) $row['override_amount']) : '' ?>"
                                                placeholder="0.00"
                                            >
                                        </td>
                                        <td>
                                            <input
                                                type="text"
                                                class="form-control"
                                                maxlength="200"
                                                name="rows[<?= htmlspecialchars($feeTypeName) ?>][note]"
                                                value="<?= htmlspecialchars((string) $row['note']) ?>"
                                                placeholder="Reason or note"
                                            >
                                        </td>
                                        <td>
                                            <?php if ($accountState): ?>
                                                <div class="fw-bold">Balance: PHP <?= number_format((float) $accountState['balance'], 2) ?></div>
                                                <div class="status-note">Payments linked: <?= $paymentCount ?></div>
                                                <?php if ($paymentCount > 0): ?>
                                                    <span class="badge text-bg-warning mt-2">Paid Account Preserved</span>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span class="text-muted">No current account row</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($row['updated_by'] !== '' || $row['updated_at'] !== ''): ?>
                                                <div class="fw-bold"><?= htmlspecialchars($row['updated_by'] !== '' ? $row['updated_by'] : 'System') ?></div>
                                                <div class="status-note"><?= htmlspecialchars($row['updated_at']) ?></div>
                                            <?php else: ?>
                                                <span class="text-muted">No exception yet</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-end gap-2 mt-3">
                        <a href="account-view.php?student_id=<?= $studentId ?>&school_year=<?= urlencode($selectedSchoolYear) ?>" class="btn btn-outline-secondary fw-bold">Cancel</a>
                        <button type="submit" class="btn btn-primary fw-bold" onclick="return confirm('Save these student fee exception updates?');">
                            <i class="fas fa-save me-2"></i>Save Fee Exceptions
                        </button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    if (window.bootstrap && window.bootstrap.Collapse) {
        return;
    }
    document.querySelectorAll('[data-bs-toggle="collapse"][data-bs-target]').forEach(function(button) {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            var selector = button.getAttribute('data-bs-target');
            if (!selector) {
                return;
            }
            var target = document.querySelector(selector);
            if (!target) {
                return;
            }
            var willShow = !target.classList.contains('show');
            target.classList.toggle('show', willShow);
            target.style.display = willShow
                ? (target.tagName.toLowerCase() === 'tr' ? 'table-row' : 'block')
                : 'none';
            button.setAttribute('aria-expanded', willShow ? 'true' : 'false');
        });
    });
});
</script>
</body>
</html>
<?php $conn->close(); ?>
