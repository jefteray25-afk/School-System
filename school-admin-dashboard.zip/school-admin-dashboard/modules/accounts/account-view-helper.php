<?php

function account_view_load_data(mysqli $conn, int $studentId, string $schoolYearFilter, string $activeSchoolYearLabel): array
{
    $error = '';
    $studentName = '';
    $studentGrade = '';
    $studentPhoto = '';
    $studentSchoolYear = '';
    $accounts = [];
    $exceptionCount = 0;

    if ($studentId <= 0) {
        return [
            'error' => 'Invalid student ID.',
            'student_name' => '',
            'student_grade' => '',
            'student_photo' => '',
            'student_school_year' => '',
            'accounts' => [],
            'exception_count' => 0,
            'selected_school_year' => $schoolYearFilter !== '' ? $schoolYearFilter : $activeSchoolYearLabel,
        ];
    }

    $studStmt = $conn->prepare("SELECT CONCAT(lastname, ', ', firstname, ' ', middlename) AS student_name, grade, photo, school_year_label FROM students WHERE id = ?");
    $studStmt->bind_param("i", $studentId);
    $studStmt->execute();
    $studStmt->bind_result($studentName, $studentGrade, $studentPhoto, $studentSchoolYear);
    if (!$studStmt->fetch()) {
        $error = 'Student not found.';
    }
    $studStmt->close();

    $selectedSchoolYear = $schoolYearFilter !== '' ? $schoolYearFilter : ($studentSchoolYear ?: $activeSchoolYearLabel);

    if ($error === '') {
        $acctStmt = $conn->prepare("SELECT id, type, balance, notes FROM accounts WHERE student_id = ? AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ? ORDER BY type ASC");
        $acctStmt->bind_param("iss", $studentId, $selectedSchoolYear, $selectedSchoolYear);
        $acctStmt->execute();
        $acctRes = $acctStmt->get_result();
        while ($row = $acctRes->fetch_assoc()) {
            $accounts[] = $row;
        }
        $acctStmt->close();

        $exceptionStmt = $conn->prepare("SELECT COUNT(*) FROM student_fee_exceptions WHERE student_id = ? AND school_year_label = ?");
        if ($exceptionStmt) {
            $exceptionStmt->bind_param("is", $studentId, $selectedSchoolYear);
            $exceptionStmt->execute();
            $exceptionStmt->bind_result($exceptionCount);
            $exceptionStmt->fetch();
            $exceptionStmt->close();
        }
    }

    return [
        'error' => $error,
        'student_name' => $studentName,
        'student_grade' => $studentGrade,
        'student_photo' => $studentPhoto,
        'student_school_year' => $studentSchoolYear,
        'accounts' => $accounts,
        'exception_count' => $exceptionCount,
        'selected_school_year' => $selectedSchoolYear,
    ];
}
