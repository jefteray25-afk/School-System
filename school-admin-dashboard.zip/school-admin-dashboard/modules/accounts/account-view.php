<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require_once __DIR__ . '/../../includes/ui.php';
include '../../config/database.php';
include __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/../settings/upload-storage-helper.php';
require_once __DIR__ . '/account-fee-exceptions-helper.php';
require_once __DIR__ . '/account-view-helper.php';
require_once __DIR__ . '/finance-adjustment-helper.php';
require_once __DIR__ . '/../old accounts/old-account-followup-helper.php';

// Permission: Only users with account_mgmt:view or account_mgmt:view_own can view student account overview
$currentRole = $_SESSION['role'] ?? '';
$is_own = false;

// Ownership-aware permission logic (optional, for view_own)
if (in_array($currentRole, ['Administrator 1', 'Administrator 2'])) {
    $is_own = true;
}

if (
    !hasPermission($currentRole, 'account_mgmt', 'view') &&
    !(hasPermission($currentRole, 'account_mgmt', 'view_own') && $is_own)
) {
    include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';
    $blockedUser = $_SESSION['username'] ?? 'unknown';
    audit_log(
        $conn,
        $blockedUser,
        'Blocked account view access',
        'Accounts',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing account_mgmt:view permission',
        'SECURITY'
    );
    admin_session_forbidden();
}

$student_id = isset($_GET['student_id']) ? intval($_GET['student_id']) : 0;
$school_year_filter = trim($_GET['school_year'] ?? '');
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
student_fee_exceptions_ensure_table($conn);
$active_school_year_label = school_year_get_active_label($conn);
$accountViewData = account_view_load_data($conn, $student_id, $school_year_filter, $active_school_year_label);
$error = (string) ($accountViewData['error'] ?? '');
$student_name = (string) ($accountViewData['student_name'] ?? '');
$student_grade = (string) ($accountViewData['student_grade'] ?? '');
$student_photo = (string) ($accountViewData['student_photo'] ?? '');
$student_school_year = (string) ($accountViewData['student_school_year'] ?? '');
$accounts = $accountViewData['accounts'] ?? [];
$exception_count = (int) ($accountViewData['exception_count'] ?? 0);
$selected_school_year = (string) ($accountViewData['selected_school_year'] ?? $active_school_year_label);
$financeAdjustmentRows = finance_adjustment_applied_rows($conn, $student_id, $selected_school_year);
$activeFinanceAdjustments = array_values(array_filter($financeAdjustmentRows, static function ($row): bool {
    return (string) ($row['status'] ?? '') === 'applied';
}));
$activeFinanceAdjustmentCount = count($activeFinanceAdjustments);
$activeFinanceAdjustmentTotal = 0.0;
$activeFinanceAdjustmentLabels = [];
foreach ($activeFinanceAdjustments as $adjustmentRow) {
    $label = trim((string) ($adjustmentRow['name'] ?? 'Finance adjustment'));
    if ($label !== '' && !in_array($label, $activeFinanceAdjustmentLabels, true)) {
        $activeFinanceAdjustmentLabels[] = $label;
    }
    $snapshot = $adjustmentRow['snapshot'] ?? [];
    $items = is_array($snapshot) ? ($snapshot['items'] ?? []) : [];
    if (!is_array($items)) {
        continue;
    }
    foreach ($items as $item) {
        if (!is_array($item)) {
            continue;
        }
        if (($item['status'] ?? '') === 'ready' || ($item['account_action'] ?? '') !== '') {
            $activeFinanceAdjustmentTotal += (float) ($item['applied_amount'] ?? 0);
        }
    }
}
$return_to = trim((string) ($_GET['return_to'] ?? ''));
$safe_return_to = '';
if ($return_to !== '' && str_starts_with($return_to, '/school-admin-dashboard/modules/reports/reports-finance.php')) {
    $safe_return_to = $return_to;
}

// Photo logic: use the shared upload storage helper so photo paths can move to another drive safely.
$photo_filename = trim($student_photo);
$photo_url = ($photo_filename !== '' && file_exists(student_photo_absolute_path($conn, $photo_filename)))
    ? student_photo_public_url($photo_filename)
    : "/school-admin-dashboard/assets/img/default-profile.png";

// For dashboard header
$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';
$role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
$isLimitedAdminOperator = is_limited_admin_operator_role($currentRole);
$canViewStatement = hasPermission($currentRole, 'financial', 'view')
    || hasPermission($currentRole, 'account_mgmt', 'view')
    || (hasPermission($currentRole, 'account_mgmt', 'view_own') && $is_own);
$oldAccountSummary = old_account_linked_records_for_student($conn, $student_id);
$linkedOldAccountCount = (int) ($oldAccountSummary['count'] ?? 0);
$linkedOldAccountTotal = (float) ($oldAccountSummary['total_balance'] ?? 0);
$linkedOldAccountRecords = $oldAccountSummary['records'] ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Finance Profile | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <?php ui_css_link(); ?>
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body {
            background: var(--main-bg);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
            transition: background 0.6s;
        }
        body.dark-mode {
            --main-bg: #1b232d;
            --card-bg: #23395d;
            --navbar-bg: #161b22;
            color: #e6edf3;
        }
        .navbar {
            background: var(--navbar-bg) !important;
            transition: background 0.6s;
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.08em;
        }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .nav-link.active { border-bottom: 2px solid #517fa4; }
        .theme-toggle-btn {
            background: none;
            border: none;
            color: #fff;
            font-size: 1.45em;
            margin-left: 12px;
            cursor: pointer;
            transition: color 0.3s;
        }
        .dashboard-header {
            background: var(--navbar-bg);
            color: #fff;
            padding: 30px 0 16px 0;
            border-bottom: 2px solid var(--brand-blue);
            box-shadow: 0 4px 18px rgba(33,57,93,0.10);
            text-align: center;
            margin-bottom: 0;
        }
        .dashboard-header img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            margin-bottom: 8px;
            border: 2px solid #fff;
            box-shadow: 0 2px 8px rgba(33,57,93,0.10);
            background: #fff;
        }
        .dashboard-header h1 {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 0;
            letter-spacing: 1px;
            transition: color 0.6s;
        }
        /* --- page specific --- */
        .student-name-display {
            font-size: 2rem;
            font-weight: bold;
            text-align: center;
            margin-bottom: 0.7rem;
        }
        .student-photo-box {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 1rem;
        }
        .student-photo-img {
            width: 280px;
            height: 280px;
            object-fit: cover;
            border-radius: 20px;
            border: 4px solid var(--brand-blue);
            background: #f8f9fa;
            box-shadow: 0 0 16px rgba(0,0,0,0.08);
        }
        .account-center-container {
            display: flex;
            justify-content: center;
        }
        .account-card-wrapper {
            width: 100%;
            max-width: 700px;
        }
        .table-centered th, .table-centered td {
            text-align: center;
            vertical-align: middle;
        }
        .crown-paid {
            font-size: 1.4em;
            color: #FFD700;
            vertical-align: middle;
        }
        .row-paid {
            background-color: #fffbe6;
        }
        @media (max-width: 576px) {
            .dashboard-header h1 { font-size: 1.01rem;}
            .dashboard-header img { width: 34px; height: 34px;}
            .dashboard-header { padding: 12px 0 10px 0;}
        }
        /* View Wave 5: detail view alignment */
        :root {
            --vw-page-bg: #eef3f9;
            --vw-card-bg: #ffffff;
            --vw-card-border: #d9e3ef;
            --vw-brand-dark: #23395d;
            --vw-brand-mid: #517fa4;
            --vw-brand-soft: #edf4fb;
            --vw-text-soft: #5f7186;
        }
        body {
            background:
                radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 30%),
                linear-gradient(180deg, #f8fbff 0%, var(--vw-page-bg) 100%);
            color: var(--vw-brand-dark);
        }
        .dashboard-header {
            background: transparent;
            color: var(--vw-brand-dark);
            border-bottom: 0;
            box-shadow: none;
            padding: 32px 0 12px 0;
        }
        .dashboard-header img {
            width: 72px;
            height: 72px;
            border-radius: 18px;
            background: #fff;
            padding: 6px;
            border: 0;
            box-shadow: 0 10px 25px rgba(35,57,93,0.12);
        }
        .dashboard-header h1 {
            font-weight: 800;
            color: var(--vw-brand-dark);
        }
        .account-card-wrapper .card {
            border: 1px solid var(--vw-card-border);
            border-radius: 20px;
            box-shadow: 0 14px 32px rgba(35,57,93,0.07);
            overflow: hidden;
        }
        .account-card-wrapper .card-header {
            background: linear-gradient(135deg, var(--vw-brand-dark), var(--vw-brand-mid)) !important;
            border: 0;
            font-weight: 700;
        }
        .student-name-display {
            font-weight: 800;
            color: var(--vw-brand-dark);
        }
        .student-photo-img {
            border-color: var(--vw-card-border);
            box-shadow: 0 10px 25px rgba(35,57,93,0.10);
        }
        .table-centered th {
            background: var(--vw-brand-soft);
            color: var(--vw-brand-dark);
            border-bottom: 1px solid var(--vw-card-border);
        }
        .table-centered td {
            background: #fbfdff;
        }
        .mb-3.text-center .btn {
            border-radius: 12px;
            font-weight: 700;
            background: #edf4fb;
            border-color: #d7e1ed;
            color: var(--vw-brand-dark);
        }
        .action-bar {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 12px;
        }
        .action-btn {
            border-radius: 999px;
            padding: 0.6rem 1.2rem;
            font-weight: 700;
            box-shadow: 0 10px 22px rgba(35,57,93,0.12);
        }
        .action-panel {
            background: #fff;
            border: 1px solid var(--vw-card-border);
            border-radius: 20px;
            box-shadow: 0 14px 30px rgba(35,57,93,0.08);
            padding: 18px 20px;
            max-width: 860px;
            margin: 0 auto;
        }
        .action-title {
            font-weight: 800;
            color: var(--vw-brand-dark);
            text-align: center;
            margin-bottom: 12px;
        }
        .action-caption {
            color: var(--vw-text-soft);
            text-align: center;
            margin-bottom: 14px;
        }
        .finance-status-note {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            background: #f7fbff;
            border: 1px solid #dbe8f5;
            border-radius: 14px;
            padding: 12px 14px;
            margin: 0 auto 16px;
            max-width: 760px;
            text-align: left;
        }
        .finance-status-note.has-adjustment {
            background: #eefcf6;
            border-color: #b8ead3;
        }
        .finance-status-main {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            min-width: 0;
        }
        .finance-status-icon {
            width: 34px;
            height: 34px;
            border-radius: 999px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: #e6eef7;
            color: var(--vw-brand-dark);
            flex: 0 0 auto;
        }
        .finance-status-note.has-adjustment .finance-status-icon {
            background: #d7f8e7;
            color: #13784c;
        }
        .finance-status-title {
            font-weight: 800;
            color: var(--vw-brand-dark);
            line-height: 1.25;
        }
        .finance-status-sub {
            color: var(--vw-text-soft);
            font-size: 0.92rem;
            line-height: 1.35;
            margin-top: 2px;
        }
        .finance-status-amount {
            flex: 0 0 auto;
            border-radius: 999px;
            padding: 0.45rem 0.75rem;
            background: #fff;
            border: 1px solid #dbe8f5;
            font-weight: 800;
            color: var(--vw-brand-dark);
            white-space: nowrap;
        }
        .finance-status-note.has-adjustment .finance-status-amount {
            border-color: #a7e3c8;
            color: #13784c;
        }
        @media (max-width: 576px) {
            .finance-status-note {
                align-items: stretch;
                flex-direction: column;
            }
            .finance-status-amount {
                text-align: center;
            }
        }
        .old-account-alert {
            background: linear-gradient(135deg, #fff8e7, #fffdf8);
            border: 1px solid #f0d98b;
            border-radius: 18px;
            box-shadow: 0 12px 28px rgba(122, 92, 0, 0.08);
            padding: 18px 20px;
            max-width: 860px;
            margin: 0 auto 18px;
        }
        .old-account-alert-title {
            font-weight: 800;
            color: #7a5c00;
            margin-bottom: 6px;
        }
        .old-account-alert-note {
            color: #7a5c00;
            margin-bottom: 12px;
        }
        .old-account-alert-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
            gap: 10px;
            margin-bottom: 12px;
        }
        .old-account-alert-item {
            background: rgba(255,255,255,0.88);
            border: 1px solid #f5e6b3;
            border-radius: 14px;
            padding: 12px 14px;
        }
        .old-account-alert-label {
            font-size: 0.74rem;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #8a6400;
            font-weight: 800;
        }
        .old-account-alert-value {
            font-size: 1rem;
            font-weight: 800;
            color: #7a5c00;
            margin-top: 4px;
        }
        .old-account-alert-list {
            margin: 0;
            padding-left: 1rem;
            color: #7a5c00;
        }
        .old-account-alert-list li + li {
            margin-top: 0.35rem;
        }
    </style>
</head>
<body>
<!-- Navbar (Dashboard Top Bar) like student-list/student-view/account-list -->
<?php render_admin_nav('accounts'); ?>
<!-- Dashboard Header -->
<?php render_school_page_header($schoolName); ?>
<!-- Removed button group (List, Types, Back, Logout) as per image2 and your request -->
<div id="page-content-wrapper" class="w-100">
    <div class="container mt-2">
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php else: ?>
            <div class="text-center text-uppercase small fw-bold mb-2" style="letter-spacing:.08em; color: var(--vw-text-soft);">Student Finance Profile</div>
            <div class="student-photo-box">
                <img src="<?= htmlspecialchars($photo_url) ?>" alt="Student Photo" class="student-photo-img" loading="lazy"
                     onerror="this.onerror=null;this.src='/school-admin-dashboard/assets/img/default-profile.png'">
            </div>
            <div class="student-name-display">
                <i class="fas fa-user-graduate"></i> <?= htmlspecialchars($student_name) ?>
            </div>
            <div class="text-center mb-3">
                <span class="badge bg-info fs-5"><i class="fas fa-layer-group"></i> Grade: <?= htmlspecialchars($student_grade) ?></span>
                <span class="badge bg-secondary fs-6 ms-2"><i class="fas fa-calendar-alt"></i> <?= htmlspecialchars($selected_school_year) ?></span>
                <?php if ($exception_count > 0): ?>
                    <span class="badge bg-warning text-dark fs-6 ms-2"><i class="fas fa-sliders-h"></i> Fee Exceptions: <?= (int) $exception_count ?></span>
                <?php endif; ?>
            </div>
            <?php if ($linkedOldAccountCount > 0): ?>
            <div class="old-account-alert">
                <div class="old-account-alert-title"><i class="fas fa-clock-rotate-left me-1"></i>Linked Old Account Alert</div>
                <div class="old-account-alert-note">This current student has linked old-account records. Review them before posting or reconciling payments so previous school-year balances are not missed.</div>
                <div class="old-account-alert-grid">
                    <div class="old-account-alert-item">
                        <div class="old-account-alert-label">Linked Records</div>
                        <div class="old-account-alert-value"><?= number_format($linkedOldAccountCount) ?></div>
                    </div>
                    <div class="old-account-alert-item">
                        <div class="old-account-alert-label">Total Old Balance</div>
                        <div class="old-account-alert-value">PHP <?= number_format($linkedOldAccountTotal, 2) ?></div>
                    </div>
                </div>
                <ul class="old-account-alert-list">
                    <?php foreach ($linkedOldAccountRecords as $oldRecord): ?>
                        <li>
                            <strong><?= htmlspecialchars((string) ($oldRecord['school_year'] ?? 'No School Year')) ?></strong>
                            - PHP <?= number_format((float) ($oldRecord['total_balance'] ?? 0), 2) ?>
                            (<?= htmlspecialchars((string) ucfirst((string) ($oldRecord['status'] ?? 'record'))) ?>)
                            <a href="/school-admin-dashboard/modules/old accounts/student-old-payment-history.php?id=<?= (int) $oldRecord['id'] ?>" class="ms-1">Open old account</a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php $show_finance_items = false; ?>
            <?php if ($show_finance_items): ?>
            <div class="account-center-container">
                <div class="account-card-wrapper">
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-light text-center">
                            <i class="fas fa-wallet"></i> Finance Items for Student
                        </div>
                        <div class="card-body">
                            <?php if (count($accounts)): ?>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-centered align-middle mx-auto w-100" style="max-width:520px;">
                                        <thead>
                                            <tr>
                                                <th>Finance Type</th>
                                                <th>Balance</th>
                                                <th>Notes</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach ($accounts as $acct): 
                                            $is_paid = (floatval($acct['balance']) === 0.0);
                                            ?>
                                            <tr<?= $is_paid ? ' class="row-paid"' : '' ?>>
                                                <td>
                                                    <?= htmlspecialchars($acct['type']) ?>
                                                </td>
                                                <td>
                                                    ₱<?= number_format($acct['balance'], 2) ?>
                                                </td>
                                                <td>
                                                    <?php
                                                    if ($is_paid) {
                                                        echo '<span class="crown-paid" title="Fully Paid"><i class="fa-solid fa-crown"></i></span>';
                                                    } else {
                                                        echo '';
                                                    }
                                                    ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <i>No finance items found for this student.</i>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <div class="action-panel">
                <div class="action-title">Finance Actions</div>
                <div class="finance-status-note <?= $activeFinanceAdjustmentCount > 0 ? 'has-adjustment' : '' ?>">
                    <div class="finance-status-main">
                        <div class="finance-status-icon">
                            <i class="fas <?= $activeFinanceAdjustmentCount > 0 ? 'fa-certificate' : 'fa-circle-info' ?>"></i>
                        </div>
                        <div>
                            <div class="finance-status-title">
                                <?= $activeFinanceAdjustmentCount > 0 ? 'Voucher / adjustment applied' : 'No voucher or adjustment applied yet' ?>
                            </div>
                            <div class="finance-status-sub">
                                <?php if ($activeFinanceAdjustmentCount > 0): ?>
                                    <?= htmlspecialchars(implode(', ', array_slice($activeFinanceAdjustmentLabels, 0, 3))) ?><?= count($activeFinanceAdjustmentLabels) > 3 ? ' +' . (count($activeFinanceAdjustmentLabels) - 3) . ' more' : '' ?>
                                    for <?= htmlspecialchars($selected_school_year) ?>. Open Payment Desk to view the breakdown table.
                                <?php else: ?>
                                    This student has no applied finance shortcut for <?= htmlspecialchars($selected_school_year) ?>.
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php if ($activeFinanceAdjustmentCount > 0): ?>
                    <div class="finance-status-amount">
                        PHP <?= number_format($activeFinanceAdjustmentTotal, 2) ?>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="mb-3 text-center action-bar">
                <?php if ($safe_return_to !== ''): ?>
                <a href="<?= htmlspecialchars($safe_return_to) ?>" class="btn btn-outline-secondary action-btn">
                    <i class="fas fa-arrow-left"></i> Back to Finance Reports
                </a>
                <?php endif; ?>
                <a href="accounts table/account-payment-history.php?student_id=<?= $student_id ?>&school_year=<?= urlencode($selected_school_year) ?>" class="btn btn-info action-btn">
                    <i class="fas fa-history"></i> Open Payment Desk
                </a>
                <?php if ($canViewStatement): ?>
                <a href="account-statement-of-account.php?student_id=<?= $student_id ?>&school_year=<?= urlencode($selected_school_year) ?>" class="btn btn-dark action-btn">
                    <i class="fas fa-file-invoice-dollar"></i> View Statement of Account
                </a>
                <?php endif; ?>
                <?php if (hasPermission($currentRole, 'account_mgmt', 'edit')): ?>
                    <a href="account-fee-exceptions.php?student_id=<?= $student_id ?>&school_year=<?= urlencode($selected_school_year) ?>" class="btn btn-warning action-btn">
                        <i class="fas fa-sliders-h"></i> Manage Finance Exceptions
                    </a>
                <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <?php if (file_exists('../../includes/footer.php')) include '../../includes/footer.php'; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
$conn->close();
?>
