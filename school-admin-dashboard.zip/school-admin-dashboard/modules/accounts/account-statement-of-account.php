<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../vendor/autoload.php';
include '../../config/database.php';
include __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/upload-storage-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/settings/school-info-helper.php';
include_once __DIR__ . '/account-fee-exceptions-helper.php';
require_once __DIR__ . '/account-statement-helper.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/includes-receipt-helper.php';
require_once __DIR__ . '/../audit/audit-helper.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Cell\DataType;

function soa_money(float $amount): string
{
    return 'PHP ' . number_format($amount, 2);
}

$currentRole = $_SESSION['role'] ?? '';
$isOwn = in_array($currentRole, ['Administrator 1', 'Administrator 2'], true);
$canViewSoa =
    hasPermission($currentRole, 'financial', 'view') ||
    hasPermission($currentRole, 'account_mgmt', 'view') ||
    (hasPermission($currentRole, 'account_mgmt', 'view_own') && $isOwn);

if (!$canViewSoa) {
    admin_session_forbidden();
}

$studentId = isset($_GET['student_id']) ? (int) $_GET['student_id'] : 0;
$schoolYearFilter = trim($_GET['school_year'] ?? '');

school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
student_fee_exceptions_ensure_table($conn);
$schoolYearOptions = school_year_finance_options($conn, 'accounts');
$activeSchoolYearLabel = school_year_get_active_label($conn);
$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$downloadFormat = trim((string) ($_GET['download'] ?? ''));
$statementData = account_statement_load_data($conn, $studentId, $schoolYearFilter, $activeSchoolYearLabel);
$error = (string) ($statementData['error'] ?? '');
$student = $statementData['student'] ?? null;
$accounts = $statementData['accounts'] ?? [];
$recentPayments = $statementData['recent_payments'] ?? [];
$summary = $statementData['summary'] ?? [
    'assessed' => 0.0,
    'paid' => 0.0,
    'balance' => 0.0,
    'payment_count' => 0,
];
$exceptionCount = (int) ($statementData['exception_count'] ?? 0);
$selectedSchoolYear = (string) ($statementData['selected_school_year'] ?? $activeSchoolYearLabel);

$studentName = $student ? trim(($student['lastname'] ?? '') . ', ' . ($student['firstname'] ?? '') . ' ' . ($student['middlename'] ?? '')) : '';
$photoFilename = trim((string) ($student['photo'] ?? ''));
$photoUrl = ($photoFilename !== '' && file_exists(student_photo_absolute_path($conn, $photoFilename)))
    ? student_photo_public_url($photoFilename)
    : "/school-admin-dashboard/assets/img/default-profile.png";

if ($error === '' && $downloadFormat === 'excel') {
    // Prevent any prior output from corrupting the XLSX stream.
    if (ob_get_length()) {
        ob_end_clean();
    }
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();
    $sheet->setTitle('Statement of Account');

    $sheet->setCellValue('A1', $schoolName);
    $sheet->mergeCells('A1:F1');
    $sheet->setCellValue('A2', 'Statement of Account');
    $sheet->mergeCells('A2:F2');
    $sheet->setCellValue('A3', 'Student');
    $sheet->setCellValue('B3', $studentName);
    $sheet->setCellValue('D3', 'School Year');
    $sheet->setCellValue('E3', $selectedSchoolYear);
    $sheet->setCellValue('A4', 'Grade');
    $sheet->setCellValue('B4', (string) ($student['grade'] ?? '-'));
    $sheet->setCellValue('D4', 'LRN');
    $sheet->setCellValueExplicit('E4', (string) ($student['lrn'] ?? ''), DataType::TYPE_STRING);
    $sheet->setCellValue('A5', 'Prepared By');
    $sheet->setCellValue('B5', $username !== '' ? $username : 'System User');
    $sheet->setCellValue('D5', 'Generated On');
    $sheet->setCellValue('E5', date('F j, Y g:i A'));

    $sheet->setCellValue('A7', 'Summary');
    $sheet->mergeCells('A7:D7');
    $sheet->setCellValue('A8', 'Total Assessed');
    $sheet->setCellValue('B8', (float) $summary['assessed']);
    $sheet->setCellValue('C8', 'Total Paid');
    $sheet->setCellValue('D8', (float) $summary['paid']);
    $sheet->setCellValue('E8', 'Remaining Balance');
    $sheet->setCellValue('F8', (float) $summary['balance']);
    $sheet->setCellValue('G8', 'Recorded Payments');
    $sheet->setCellValue('H8', (int) $summary['payment_count']);

    $sheet->setCellValue('A10', 'Account Breakdown');
    $sheet->mergeCells('A10:F10');
    $headers = ['Account Type', 'Assessed', 'Paid', 'Balance', 'Status', 'Notes'];
    foreach ($headers as $index => $header) {
        $sheet->setCellValue(chr(65 + $index) . '11', $header);
    }

    $row = 12;
    foreach ($accounts as $account) {
        $isPaid = (float) $account['balance'] <= 0.009;
        $sheet->setCellValue("A$row", (string) $account['type']);
        $sheet->setCellValue("B$row", (float) $account['assessed_amount']);
        $sheet->setCellValue("C$row", (float) $account['total_paid']);
        $sheet->setCellValue("D$row", (float) $account['balance']);
        $sheet->setCellValue("E$row", $isPaid ? 'Fully Paid' : 'With Balance');
        $sheet->setCellValue("F$row", trim((string) ($account['notes'] ?? '')));
        $row++;
    }
    if (!$accounts) {
        $sheet->setCellValue("A$row", 'No account rows found for this student and school year.');
        $sheet->mergeCells("A$row:F$row");
        $row++;
    }

    $paymentsHeaderRow = $row + 1;
    $sheet->setCellValue("A$paymentsHeaderRow", 'Recent Payments');
    $sheet->mergeCells("A$paymentsHeaderRow:F$paymentsHeaderRow");
    $paymentsTableHeaderRow = $paymentsHeaderRow + 1;
    $paymentHeaders = ['Date', 'Account Type', 'Booklet No', 'Receipt No', 'Mode / Note', 'Amount'];
    foreach ($paymentHeaders as $index => $header) {
        $sheet->setCellValue(chr(65 + $index) . $paymentsTableHeaderRow, $header);
    }

    $paymentRow = $paymentsTableHeaderRow + 1;
    foreach ($recentPayments as $payment) {
        $sheet->setCellValue("A$paymentRow", date('n/j/Y g:i A', strtotime((string) $payment['date_paid'])));
        $sheet->setCellValue("B$paymentRow", (string) ($payment['fee_type'] ?? 'Uncategorized'));
        $sheet->setCellValueExplicit("C$paymentRow", !empty($payment['booklet_no']) ? booklet_label_from_stored((int) $payment['booklet_no']) : '', DataType::TYPE_STRING);
        $sheet->setCellValueExplicit("D$paymentRow", (string) ($payment['receipt_no'] ?? ''), DataType::TYPE_STRING);
        $sheet->setCellValue("E$paymentRow", trim((string) (($payment['payment_method_display'] ?? '') !== '' ? $payment['payment_method_display'] : (($payment['receipt_note'] ?? '') !== '' ? $payment['receipt_note'] : ($payment['remarks'] ?? '')))));
        $sheet->setCellValue("F$paymentRow", (float) $payment['amount']);
        $paymentRow++;

        if (!empty($payment['items']) && count($payment['items']) > 1) {
            foreach ($payment['items'] as $item) {
                $sheet->setCellValue("A$paymentRow", '');
                $sheet->setCellValue("B$paymentRow", ' - ' . (string) ($item['fee_type'] ?? 'Uncategorized'));
                $sheet->setCellValue("C$paymentRow", '');
                $sheet->setCellValue("D$paymentRow", '');
                $sheet->setCellValue("E$paymentRow", 'Breakdown');
                $sheet->setCellValue("F$paymentRow", (float) ($item['amount'] ?? 0));
                $paymentRow++;
            }
        }
    }
    if (!$recentPayments) {
        $sheet->setCellValue("A$paymentRow", 'No payments recorded yet for this student and school year.');
        $sheet->mergeCells("A$paymentRow:F$paymentRow");
        $paymentRow++;
    }

    $sheet->getStyle('A1:H2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
    $sheet->getStyle('A1:H2')->getFont()->setBold(true);
    $sheet->getStyle('A1:F1')->getFont()->setSize(18);
    $sheet->getStyle('A2:F2')->getFont()->setSize(14);
    $sheet->getStyle('A7:H7')->applyFromArray([
        'font' => ['bold' => true, 'size' => 12],
        'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'D9EAF7']],
    ]);
    $sheet->getStyle('A10:F10')->applyFromArray([
        'font' => ['bold' => true, 'size' => 12],
        'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'D9EAF7']],
    ]);
    $sheet->getStyle("A11:F11")->applyFromArray([
        'font' => ['bold' => true],
        'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'EAF4FF']],
        'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
    ]);
    $sheet->getStyle("A{$paymentsHeaderRow}:F{$paymentsHeaderRow}")->applyFromArray([
        'font' => ['bold' => true, 'size' => 12],
        'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'D9EAF7']],
    ]);
    $sheet->getStyle("A{$paymentsTableHeaderRow}:F{$paymentsTableHeaderRow}")->applyFromArray([
        'font' => ['bold' => true],
        'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'EAF4FF']],
        'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
    ]);

    $lastRow = max($paymentRow - 1, 12);
    $sheet->getStyle("B8:F8")->getNumberFormat()->setFormatCode('"PHP" #,##0.00');
    if ($row > 12) {
        $sheet->getStyle('B12:D' . ($row - 1))->getNumberFormat()->setFormatCode('"PHP" #,##0.00');
    }
    if ($paymentRow > ($paymentsTableHeaderRow + 1)) {
        $sheet->getStyle('F' . ($paymentsTableHeaderRow + 1) . ':F' . ($paymentRow - 1))->getNumberFormat()->setFormatCode('"PHP" #,##0.00');
    }
    $sheet->getStyle("A11:F$lastRow")->applyFromArray([
        'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => '333333']]],
    ]);
    $sheet->getStyle("A3:H5")->getFont()->setBold(true);
    $sheet->getStyle("A3:H5")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_LEFT);
    $sheet->getStyle("A11:F$lastRow")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
    $sheet->getStyle("A12:A$lastRow")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_LEFT);
    $sheet->getStyle("F12:F$lastRow")->getAlignment()->setWrapText(true);

    foreach (range('A', 'H') as $column) {
        $sheet->getColumnDimension($column)->setAutoSize(true);
    }
    $sheet->getColumnDimension('A')->setWidth(26);
    $sheet->getColumnDimension('F')->setWidth(30);
    $sheet->freezePane('A11');

    $safeStudentName = preg_replace('/[^A-Za-z0-9_-]+/', '_', $studentName !== '' ? $studentName : 'student');
    $fileName = 'statement_of_account_' . $safeStudentName . '_' . preg_replace('/[^A-Za-z0-9_-]+/', '_', $selectedSchoolYear) . '.xlsx';
    log_data_export($conn, $username !== '' ? $username : 'System User', 'Statement of Account Excel', $fileName);
    log_export_download($conn, $username !== '' ? $username : 'System User', $fileName, 'Statement of Account Excel');
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="' . $fileName . '"');
    header('Cache-Control: max-age=0');
    header('Pragma: public');

    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    $conn->close();
    exit;
}
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Statement of Account | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --page-bg:#eef3f9; --card-bg:#ffffff; --card-border:#d9e3ef; --brand-dark:#23395d; --brand-mid:#517fa4; --brand-soft:#edf4fb; --text-soft:#5f7186; --green-soft:#e8f7ef; --gold-soft:#fff6db; --red-soft:#fdecec; }
        body { background: radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 30%), linear-gradient(180deg, #f8fbff 0%, var(--page-bg) 100%); font-family:'Segoe UI','Roboto','Arial',sans-serif; color:var(--brand-dark); }
        .navbar { background:var(--brand-dark)!important; }
        .navbar-brand,.navbar-nav .nav-link { color:#fff!important; }
        .dashboard-header { text-align:center; margin-top:34px; margin-bottom:18px; }
        .dashboard-header img { width:72px; height:72px; object-fit:contain; border-radius:18px; background:#fff; padding:6px; box-shadow:0 10px 25px rgba(35,57,93,0.12); }
        .dashboard-header h1 { font-size:1.35rem; font-weight:800; color:var(--brand-dark); margin-top:.5rem; }
        .page-card, .summary-card, .table-card { background:var(--card-bg); border:1px solid var(--card-border); border-radius:20px; box-shadow:0 14px 32px rgba(35,57,93,0.07); }
        .page-card { padding:1.5rem; }
        .student-strip { display:flex; align-items:center; justify-content:space-between; gap:1rem; flex-wrap:wrap; margin-bottom:1rem; }
        .student-meta { display:flex; gap:.6rem; flex-wrap:wrap; margin-top:.65rem; }
        .meta-chip { display:inline-flex; align-items:center; gap:.45rem; border-radius:999px; padding:.5rem .9rem; background:#fff; border:1px solid var(--card-border); color:var(--brand-dark); font-weight:600; }
        .student-photo { width:96px; height:96px; object-fit:cover; border-radius:22px; border:1px solid var(--card-border); box-shadow:0 10px 25px rgba(35,57,93,0.10); }
        .student-name { font-size:1.75rem; font-weight:800; margin-bottom:.2rem; }
        .student-subtext { color:var(--text-soft); }
        .summary-card { padding:1rem 1.15rem; height:100%; }
        .summary-label { font-size:.8rem; text-transform:uppercase; letter-spacing:.05em; color:var(--text-soft); }
        .summary-value { font-size:1.45rem; font-weight:800; color:var(--brand-dark); }
        .summary-card.assessed { background:var(--brand-soft); }
        .summary-card.paid { background:var(--green-soft); }
        .summary-card.balance { background:var(--gold-soft); }
        .summary-card.count { background:var(--red-soft); }
        .section-title { font-size:1.08rem; font-weight:800; color:var(--brand-dark); margin-bottom:1rem; }
        .toolbar-card { background:#f8fbff; border:1px solid var(--card-border); border-radius:16px; padding:1rem; margin-bottom:1rem; }
        .print-meta-card { background:#f8fbff; border:1px solid var(--card-border); border-radius:16px; padding:1rem; margin-bottom:1rem; }
        .print-meta-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:.85rem; }
        .print-meta-item { display:flex; flex-direction:column; gap:.2rem; }
        .print-meta-item span { font-size:.74rem; text-transform:uppercase; letter-spacing:.05em; color:var(--text-soft); font-weight:700; }
        .table-card .table thead th { background:var(--brand-soft); color:var(--brand-dark); border-bottom:1px solid var(--card-border); font-weight:700; }
        .table-card .table tbody tr:hover { background:transparent; }
        .status-pill { display:inline-flex; align-items:center; gap:.4rem; border-radius:999px; padding:.35rem .7rem; font-size:.82rem; font-weight:700; }
        .status-paid { background:rgba(25,135,84,.12); color:#198754; }
        .status-balance { background:rgba(255,193,7,.18); color:#8a6400; }
        .print-footer { margin-top:1.25rem; padding-top:.9rem; border-top:1px dashed rgba(81,127,164,.28); color:var(--text-soft); font-size:.9rem; display:flex; justify-content:space-between; gap:1rem; flex-wrap:wrap; }
        @media print { .navbar, .toolbar-card .btn, .toolbar-card .form-select, .toolbar-card label, .footer-note { display:none!important; } body { background:#fff; } .page-card, .summary-card, .table-card, .toolbar-card, .print-meta-card { box-shadow:none!important; } .print-meta-card { background:#fff!important; } }
    </style>
</head>
<body>
<?php render_admin_nav('accounts'); ?>

<?php render_school_page_header($schoolName, $schoolLogo, '', 'dashboard-header', ''); ?>

<div class="container pb-5">
    <div class="page-card">
        <?php if ($error !== ''): ?>
            <div class="alert alert-danger mb-0"><?= htmlspecialchars($error) ?></div>
        <?php else: ?>
            <div class="student-strip">
                <div class="d-flex align-items-center gap-3 flex-wrap">
                    <img src="<?= htmlspecialchars($photoUrl) ?>" alt="Student Photo" class="student-photo" onerror="this.onerror=null;this.src='/school-admin-dashboard/assets/img/default-profile.png'">
                    <div>
                        <div class="student-name"><i class="fas fa-file-invoice-dollar me-2"></i><?= htmlspecialchars($studentName) ?></div>
                        <div class="student-subtext">Printable finance summary for the selected school year.</div>
                        <div class="student-meta">
                            <span class="meta-chip"><i class="fas fa-layer-group"></i> <?= htmlspecialchars((string) ($student['grade'] ?? '-')) ?></span>
                            <span class="meta-chip"><i class="fas fa-id-card"></i> <?= htmlspecialchars((string) (($student['lrn'] ?? '') !== '' ? $student['lrn'] : 'No LRN')) ?></span>
                            <span class="meta-chip"><i class="fas fa-calendar-alt"></i> <?= htmlspecialchars($selectedSchoolYear) ?></span>
                            <?php if ($exceptionCount > 0): ?>
                                <span class="meta-chip"><i class="fas fa-sliders-h"></i> <?= (int) $exceptionCount ?> fee exception(s)</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="text-end">
                    <div class="small text-muted">Generated on</div>
                    <div class="fw-bold"><?= htmlspecialchars(date('F j, Y g:i A')) ?></div>
                </div>
            </div>

            <div class="toolbar-card">
                <form method="get" class="row g-3 align-items-end">
                    <input type="hidden" name="student_id" value="<?= (int) $studentId ?>">
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">School Year</label>
                        <select name="school_year" class="form-select" onchange="this.form.submit()">
                            <?php foreach ($schoolYearOptions as $option): ?>
                                <option value="<?= htmlspecialchars($option) ?>" <?= $selectedSchoolYear === $option ? 'selected' : '' ?>><?= htmlspecialchars($option) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-8 d-flex flex-wrap gap-2 justify-content-md-end">
                        <a href="/school-admin-dashboard/modules/accounts/account-view.php?student_id=<?= (int) $studentId ?>&school_year=<?= urlencode($selectedSchoolYear) ?>" class="btn btn-outline-secondary"><i class="fas fa-arrow-left me-1"></i> Back to Finance Profile</a>
                        <a href="/school-admin-dashboard/modules/accounts/accounts table/account-payment-history.php?student_id=<?= (int) $studentId ?>&school_year=<?= urlencode($selectedSchoolYear) ?>" class="btn btn-outline-primary"><i class="fas fa-history me-1"></i> Payment History</a>
                        <a href="/school-admin-dashboard/modules/accounts/account-statement-of-account.php?student_id=<?= (int) $studentId ?>&school_year=<?= urlencode($selectedSchoolYear) ?>&download=excel" class="btn btn-success"><i class="fas fa-file-excel me-1"></i> Download Excel</a>
                    </div>
                </form>
            </div>

            <div class="print-meta-card">
                <div class="print-meta-grid">
                    <div class="print-meta-item">
                        <span>Document</span>
                        <strong>Statement of Account</strong>
                    </div>
                    <div class="print-meta-item">
                        <span>School Year</span>
                        <strong><?= htmlspecialchars($selectedSchoolYear) ?></strong>
                    </div>
                    <div class="print-meta-item">
                        <span>Prepared By</span>
                        <strong><?= htmlspecialchars($username !== '' ? $username : 'System User') ?></strong>
                    </div>
                    <div class="print-meta-item">
                        <span>Generated On</span>
                        <strong><?= htmlspecialchars(date('F j, Y g:i A')) ?></strong>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-md-3"><div class="summary-card assessed"><div class="summary-label">Total Assessed</div><div class="summary-value"><?= htmlspecialchars(soa_money((float) $summary['assessed'])) ?></div></div></div>
                <div class="col-md-3"><div class="summary-card paid"><div class="summary-label">Total Paid</div><div class="summary-value"><?= htmlspecialchars(soa_money((float) $summary['paid'])) ?></div></div></div>
                <div class="col-md-3"><div class="summary-card balance"><div class="summary-label">Remaining Balance</div><div class="summary-value"><?= htmlspecialchars(soa_money((float) $summary['balance'])) ?></div></div></div>
                <div class="col-md-3"><div class="summary-card count"><div class="summary-label">Recorded Payments</div><div class="summary-value"><?= number_format((int) $summary['payment_count']) ?></div></div></div>
            </div>

            <div class="table-card mb-4">
                <div class="card-header border-0 bg-transparent px-4 pt-4"><div class="section-title mb-0"><i class="fas fa-table me-2"></i>Finance Breakdown</div></div>
                <div class="table-responsive px-4 pb-4">
                    <table class="table align-middle mb-0">
                        <thead>
                            <tr><th>Finance Type</th><th class="text-end">Assessed</th><th class="text-end">Paid</th><th class="text-end">Balance</th><th>Status</th><th>Notes</th></tr>
                        </thead>
                        <tbody>
                            <?php if ($accounts): ?>
                                <?php foreach ($accounts as $account): ?>
                                    <?php $isPaid = (float) $account['balance'] <= 0.009; ?>
                                    <tr>
                                        <td class="fw-semibold"><?= htmlspecialchars((string) $account['type']) ?></td>
                                        <td class="text-end"><?= htmlspecialchars(soa_money((float) $account['assessed_amount'])) ?></td>
                                        <td class="text-end"><?= htmlspecialchars(soa_money((float) $account['total_paid'])) ?></td>
                                        <td class="text-end"><?= htmlspecialchars(soa_money((float) $account['balance'])) ?></td>
                                        <td><span class="status-pill <?= $isPaid ? 'status-paid' : 'status-balance' ?>"><i class="fas <?= $isPaid ? 'fa-circle-check' : 'fa-hourglass-half' ?>"></i><?= $isPaid ? 'Fully Paid' : 'With Balance' ?></span></td>
                                        <td><?= trim((string) ($account['notes'] ?? '')) !== '' ? htmlspecialchars((string) $account['notes']) : '<span class="text-muted">-</span>' ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="6" class="text-center text-muted py-4">No finance rows found for this student and school year.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="table-card">
                <div class="card-header border-0 bg-transparent px-4 pt-4"><div class="section-title mb-0"><i class="fas fa-clock-rotate-left me-2"></i>Recent Payments</div></div>
                <div class="table-responsive px-4 pb-4">
                    <table class="table align-middle mb-0">
                        <thead>
                            <tr><th>Date</th><th>Finance Type</th><th>Receipt</th><th>Mode / Note</th><th class="text-end">Amount</th></tr>
                        </thead>
                        <tbody>
                            <?php if ($recentPayments): ?>
                                <?php $paymentIndex = 0; ?>
                                <?php foreach ($recentPayments as $payment): ?>
                                    <?php
                                        $paymentIndex++;
                                        $hasBreakdown = !empty($payment['items']) && count($payment['items']) > 1;
                                        $collapseId = 'soa-breakdown-' . $paymentIndex;
                                    ?>
                                    <tr>
                                        <td><?= htmlspecialchars(date('n/j/Y g:i A', strtotime((string) $payment['date_paid']))) ?></td>
                                        <td>
                                            <?php if ($hasBreakdown): ?>
                                                <div class="d-flex align-items-center justify-content-between gap-2">
                                                    <span><?= htmlspecialchars((string) ($payment['fee_type'] ?? 'Uncategorized')) ?></span>
                                                    <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="collapse" data-bs-target="#<?= htmlspecialchars($collapseId) ?>" aria-expanded="false" aria-controls="<?= htmlspecialchars($collapseId) ?>">
                                                        View breakdown
                                                    </button>
                                                </div>
                                            <?php else: ?>
                                                <?= htmlspecialchars((string) ($payment['fee_type'] ?? 'Uncategorized')) ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if (!empty($payment['receipt_no']) && !empty($payment['booklet_no'])): ?>
                                                <?= htmlspecialchars(booklet_label_from_stored((int) $payment['booklet_no'])) ?> / <?= htmlspecialchars((string) $payment['receipt_no']) ?>
                                            <?php else: ?>
                                                <span class="text-muted">No OR</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?= htmlspecialchars(trim((string) (($payment['payment_method_display'] ?? '') !== '' ? $payment['payment_method_display'] : (($payment['receipt_note'] ?? '') !== '' ? $payment['receipt_note'] : ($payment['remarks'] ?? ''))))) ?: '-' ?>
                                            <?php if (!empty($payment['payment_method_breakdown']) && ($payment['payment_method_display'] ?? '') === 'Split Payment'): ?>
                                                <div class="small text-muted mt-1"><?= htmlspecialchars((string) $payment['payment_method_breakdown']) ?></div>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end fw-semibold"><?= htmlspecialchars(soa_money((float) $payment['amount'])) ?></td>
                                    </tr>
                                    <?php if ($hasBreakdown): ?>
                                        <tr class="collapse" id="<?= htmlspecialchars($collapseId) ?>">
                                            <td colspan="5" class="bg-light">
                                                <div class="p-2">
                                                    <div class="fw-semibold mb-2">Receipt Breakdown</div>
                                                    <div class="table-responsive">
                                                        <table class="table table-sm mb-0">
                                                            <thead>
                                                                <tr><th>Fee Type</th><th class="text-end">Amount</th></tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php foreach ($payment['items'] as $item): ?>
                                                                    <tr>
                                                                        <td><?= htmlspecialchars((string) ($item['fee_type'] ?? 'Uncategorized')) ?></td>
                                                                        <td class="text-end"><?= htmlspecialchars(soa_money((float) ($item['amount'] ?? 0))) ?></td>
                                                                    </tr>
                                                                <?php endforeach; ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="5" class="text-center text-muted py-4">No payments recorded yet for this student and school year.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <?php if ($error === ''): ?>
        <div class="print-footer">
            <div>Prepared by: <strong><?= htmlspecialchars($username !== '' ? $username : 'System User') ?></strong><?= $role !== '' ? ' (' . htmlspecialchars($role) . ')' : '' ?></div>
            <div class="text-end">Statement reflects the selected school year and excludes voided receipt-linked payments.</div>
        </div>
    <?php endif; ?>
    <div class="footer-note text-center mt-4 small text-muted">Statement of Account reflects the selected school year and excludes voided receipt-linked payments.</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
