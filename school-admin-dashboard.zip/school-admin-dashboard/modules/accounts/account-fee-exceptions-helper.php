<?php

require_once __DIR__ . '/../settings/fee-grade-settings-helper.php';
require_once __DIR__ . '/../financial/fee-behavior-helper.php';
require_once __DIR__ . '/../../includes/schema-migration.php';

function student_fee_exceptions_ensure_table(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }
    $sql = "CREATE TABLE IF NOT EXISTS student_fee_exceptions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        fee_type_name VARCHAR(120) NOT NULL,
        school_year_label VARCHAR(120) NOT NULL,
        mode ENUM('default', 'include', 'exclude', 'override') NOT NULL DEFAULT 'default',
        override_amount DECIMAL(10,2) DEFAULT NULL,
        note TEXT DEFAULT NULL,
        updated_by VARCHAR(120) DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_student_fee_exception (student_id, fee_type_name, school_year_label),
        KEY idx_student_fee_exception_student_year (student_id, school_year_label),
        KEY idx_student_fee_exception_mode (mode)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    schema_migration_attempt($conn, $sql);

    $modeInfo = $conn->query("SHOW COLUMNS FROM student_fee_exceptions LIKE 'mode'");
    if ($modeInfo) {
        $row = $modeInfo->fetch_assoc();
        $modeType = (string) ($row['Type'] ?? '');
        $modeInfo->close();
        if (strpos($modeType, "'include'") === false) {
            schema_migration_attempt($conn, "ALTER TABLE student_fee_exceptions MODIFY COLUMN mode ENUM('default','include','exclude','override') NOT NULL DEFAULT 'default'");
        }
    }

    $sourceColumns = [
        'source_type' => "ALTER TABLE student_fee_exceptions ADD COLUMN source_type VARCHAR(40) NOT NULL DEFAULT 'manual' AFTER updated_by",
        'source_ref_id' => "ALTER TABLE student_fee_exceptions ADD COLUMN source_ref_id INT NULL AFTER source_type",
        'source_label' => "ALTER TABLE student_fee_exceptions ADD COLUMN source_label VARCHAR(160) NULL AFTER source_ref_id",
    ];
    foreach ($sourceColumns as $column => $sql) {
        $columnInfo = $conn->query("SHOW COLUMNS FROM student_fee_exceptions LIKE '" . $conn->real_escape_string($column) . "'");
        $exists = $columnInfo && $columnInfo->num_rows > 0;
        if ($columnInfo) {
            $columnInfo->close();
        }
        if (!$exists) {
            schema_migration_attempt($conn, $sql);
        }
    }
}

function student_fee_exception_source_columns_ready(mysqli $conn): bool
{
    foreach (['source_type', 'source_ref_id', 'source_label'] as $column) {
        $result = $conn->query("SHOW COLUMNS FROM student_fee_exceptions LIKE '" . $conn->real_escape_string($column) . "'");
        $ready = $result && $result->num_rows > 0;
        if ($result) {
            $result->close();
        }
        if (!$ready) {
            return false;
        }
    }

    return true;
}

function student_fee_grade_code_for_grade(mysqli $conn, string $studentGrade): int
{
    $studentGrade = trim($studentGrade);
    if ($studentGrade === '') {
        return 0;
    }

    foreach (fee_grade_catalog_rows($conn, true) as $row) {
        if (trim((string) ($row['student_grade_value'] ?? '')) === $studentGrade) {
            return (int) ($row['grade_code'] ?? 0);
        }
    }

    return 0;
}

function student_fee_template_rows(mysqli $conn, string $studentGrade, string $schoolYearLabel): array
{
    $gradeCode = student_fee_grade_code_for_grade($conn, $studentGrade);
    if ($gradeCode === 0 || trim($schoolYearLabel) === '') {
        return [];
    }

    $rows = [];
    fee_behavior_ensure_column($conn);
    $sql = "SELECT at.name, f.amount, f.application_mode
        FROM fee f
        INNER JOIN account_types at ON f.fee_type_id = at.id
        WHERE f.grade_level = ?
          AND (
                f.school_year_label = ?
                OR f.school_year_label IS NULL
                OR TRIM(f.school_year_label) = ''
          )
        ORDER BY CASE WHEN f.school_year_label = ? THEN 0 ELSE 1 END, at.priority ASC, at.name ASC";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return [];
    }
    $stmt->bind_param('iss', $gradeCode, $schoolYearLabel, $schoolYearLabel);
    $stmt->execute();
    $stmt->bind_result($feeName, $amount, $applicationMode);
    while ($stmt->fetch()) {
        if (!isset($rows[$feeName])) {
            $rows[$feeName] = [
                'fee_type_name' => (string) $feeName,
                'default_amount' => (float) $amount,
                'application_mode' => fee_behavior_normalize((string) $applicationMode),
            ];
        }
    }
    $stmt->close();

    return array_values($rows);
}

function student_fee_exception_map(mysqli $conn, int $studentId, string $schoolYearLabel): array
{
    student_fee_exceptions_ensure_table($conn);
    $map = [];
    $hasSourceColumns = student_fee_exception_source_columns_ready($conn);
    $sourceSelect = $hasSourceColumns ? ", source_type, source_ref_id, source_label" : "";
    $stmt = $conn->prepare(
        "SELECT fee_type_name, mode, override_amount, note, updated_by, updated_at{$sourceSelect}
         FROM student_fee_exceptions
         WHERE student_id = ? AND school_year_label = ?"
    );
    if (!$stmt) {
        return $map;
    }
    $stmt->bind_param('is', $studentId, $schoolYearLabel);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $feeTypeName = (string) ($row['fee_type_name'] ?? '');
        if ($feeTypeName === '') {
            continue;
        }
        $map[$feeTypeName] = [
            'mode' => (string) ($row['mode'] ?? 'default'),
            'override_amount' => $row['override_amount'] !== null ? (float) $row['override_amount'] : null,
            'note' => (string) ($row['note'] ?? ''),
            'updated_by' => (string) ($row['updated_by'] ?? ''),
            'updated_at' => (string) ($row['updated_at'] ?? ''),
            'source_type' => $hasSourceColumns ? (string) ($row['source_type'] ?? 'manual') : 'manual',
            'source_ref_id' => $hasSourceColumns ? (int) ($row['source_ref_id'] ?? 0) : 0,
            'source_label' => $hasSourceColumns ? (string) ($row['source_label'] ?? '') : '',
        ];
    }
    $stmt->close();

    return $map;
}

function student_fee_account_state_map(mysqli $conn, int $studentId, string $schoolYearLabel): array
{
    $rows = [];
    $sql = "SELECT a.type,
        a.id,
        a.balance,
        COALESCE(COUNT(p.id), 0) AS payment_count
        FROM accounts a
        LEFT JOIN payments p ON p.account_id = a.id
        WHERE a.student_id = ?
          AND COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ?
        GROUP BY a.id, a.type, a.balance";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return $rows;
    }
    $stmt->bind_param('iss', $studentId, $schoolYearLabel, $schoolYearLabel);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $rows[(string) $row['type']] = [
            'account_id' => (int) ($row['id'] ?? 0),
            'balance' => (float) ($row['balance'] ?? 0),
            'payment_count' => (int) ($row['payment_count'] ?? 0),
        ];
    }
    $stmt->close();

    return $rows;
}

function student_fee_exception_effective_row(array $templateRow, ?array $exceptionRow): array
{
    $effective = $templateRow;
    $baseAmount = array_key_exists('default_amount', $templateRow)
        ? (float) $templateRow['default_amount']
        : (float) ($templateRow['amount'] ?? 0);
    $effective['mode'] = 'default';
    $effective['application_mode'] = fee_behavior_normalize((string) ($templateRow['application_mode'] ?? 'required'));
    $effective['override_amount'] = null;
    $effective['note'] = '';
    $effective['updated_by'] = '';
    $effective['updated_at'] = '';
    $effective['source_type'] = 'default';
    $effective['source_ref_id'] = 0;
    $effective['source_label'] = '';
    $effective['is_excluded'] = false;
    $effective['effective_amount'] = $baseAmount;
    $effective['should_apply'] = $effective['application_mode'] === 'required';

    if (!$exceptionRow) {
        return $effective;
    }

    $mode = (string) ($exceptionRow['mode'] ?? 'default');
    $effective['mode'] = $mode;
    $effective['override_amount'] = $exceptionRow['override_amount'] ?? null;
    $effective['note'] = (string) ($exceptionRow['note'] ?? '');
    $effective['updated_by'] = (string) ($exceptionRow['updated_by'] ?? '');
    $effective['updated_at'] = (string) ($exceptionRow['updated_at'] ?? '');
    $effective['source_type'] = (string) ($exceptionRow['source_type'] ?? 'manual');
    $effective['source_ref_id'] = (int) ($exceptionRow['source_ref_id'] ?? 0);
    $effective['source_label'] = (string) ($exceptionRow['source_label'] ?? '');

    if ($mode === 'exclude') {
        $effective['is_excluded'] = true;
        $effective['effective_amount'] = 0.0;
        $effective['should_apply'] = false;
    } elseif ($mode === 'include') {
        $effective['should_apply'] = true;
    } elseif ($mode === 'override' && $exceptionRow['override_amount'] !== null) {
        $effective['effective_amount'] = (float) $exceptionRow['override_amount'];
        $effective['should_apply'] = true;
    } elseif ($effective['application_mode'] !== 'required') {
        $effective['should_apply'] = false;
    }

    return $effective;
}

function student_fee_exception_upsert(mysqli $conn, int $studentId, string $schoolYearLabel, string $feeTypeName, string $mode, ?float $overrideAmount, string $note, string $updatedBy, string $sourceType = 'manual', ?int $sourceRefId = null, string $sourceLabel = ''): void
{
    student_fee_exceptions_ensure_table($conn);
    $feeTypeName = trim($feeTypeName);
    $schoolYearLabel = trim($schoolYearLabel);
    $note = trim($note);
    $sourceType = trim($sourceType) !== '' ? trim($sourceType) : 'manual';
    $sourceLabel = trim($sourceLabel);
    if ($studentId <= 0 || $feeTypeName === '' || $schoolYearLabel === '') {
        return;
    }

    if (!in_array($mode, ['default', 'include', 'exclude', 'override'], true)) {
        $mode = 'default';
    }

    if ($mode === 'default') {
        $stmt = $conn->prepare("DELETE FROM student_fee_exceptions WHERE student_id = ? AND fee_type_name = ? AND school_year_label = ?");
        if ($stmt) {
            $stmt->bind_param('iss', $studentId, $feeTypeName, $schoolYearLabel);
            $stmt->execute();
            $stmt->close();
        }
        return;
    }

    if ($mode !== 'override') {
        $overrideAmount = null;
    }

    if (student_fee_exception_source_columns_ready($conn)) {
        $stmt = $conn->prepare(
            "INSERT INTO student_fee_exceptions (student_id, fee_type_name, school_year_label, mode, override_amount, note, updated_by, source_type, source_ref_id, source_label)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
                mode = VALUES(mode),
                override_amount = VALUES(override_amount),
                note = VALUES(note),
                updated_by = VALUES(updated_by),
                source_type = VALUES(source_type),
                source_ref_id = VALUES(source_ref_id),
                source_label = VALUES(source_label)"
        );
    } else {
        $stmt = $conn->prepare(
            "INSERT INTO student_fee_exceptions (student_id, fee_type_name, school_year_label, mode, override_amount, note, updated_by)
             VALUES (?, ?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
                mode = VALUES(mode),
                override_amount = VALUES(override_amount),
                note = VALUES(note),
                updated_by = VALUES(updated_by)"
        );
    }
    if (!$stmt) {
        throw new RuntimeException('Could not save fee exception.');
    }
    if (student_fee_exception_source_columns_ready($conn)) {
        $stmt->bind_param('isssdsssis', $studentId, $feeTypeName, $schoolYearLabel, $mode, $overrideAmount, $note, $updatedBy, $sourceType, $sourceRefId, $sourceLabel);
    } else {
        $stmt->bind_param('isssdss', $studentId, $feeTypeName, $schoolYearLabel, $mode, $overrideAmount, $note, $updatedBy);
    }
    if (!$stmt->execute()) {
        $stmt->close();
        throw new RuntimeException('Could not save fee exception.');
    }
    $stmt->close();
}

function student_fee_apply_effective_account_rule(
    mysqli $conn,
    int $studentId,
    string $schoolYearLabel,
    string $feeTypeName,
    float $targetAmount,
    bool $isExcluded,
    string $insertNote = 'Auto-added from fee exception'
): array {
    $accountStateMap = student_fee_account_state_map($conn, $studentId, $schoolYearLabel);
    $accountState = $accountStateMap[$feeTypeName] ?? null;
    $studentName = '';

    $studentStmt = $conn->prepare("SELECT CONCAT(lastname, ' ', firstname, ' ', middlename) AS student_name FROM students WHERE id = ? LIMIT 1");
    if ($studentStmt) {
        $studentStmt->bind_param('i', $studentId);
        $studentStmt->execute();
        $studentStmt->bind_result($studentName);
        $studentStmt->fetch();
        $studentStmt->close();
    }
    $studentName = trim((string) $studentName);

    if ($isExcluded) {
        if (!$accountState) {
            return ['status' => 'skipped_missing'];
        }
        if ((int) ($accountState['payment_count'] ?? 0) > 0) {
            return ['status' => 'preserved_paid', 'account_id' => (int) $accountState['account_id']];
        }
        $stmt = $conn->prepare("DELETE FROM accounts WHERE id = ?");
        if (!$stmt) {
            throw new RuntimeException('Could not remove excluded account.');
        }
        $accountId = (int) $accountState['account_id'];
        $stmt->bind_param('i', $accountId);
        $stmt->execute();
        $stmt->close();
        return ['status' => 'removed', 'account_id' => $accountId];
    }

    if (!$accountState) {
        $stmt = $conn->prepare("INSERT INTO accounts (student_id, name, type, balance, notes, school_year_label) VALUES (?, ?, ?, ?, ?, ?)");
        if (!$stmt) {
            throw new RuntimeException('Could not add fee account from exception.');
        }
        $stmt->bind_param('issdss', $studentId, $studentName, $feeTypeName, $targetAmount, $insertNote, $schoolYearLabel);
        if (!$stmt->execute()) {
            $message = $stmt->error ?: 'Unknown fee exception account insert error.';
            $stmt->close();
            throw new RuntimeException('Could not add fee account from exception: ' . $message);
        }
        $accountId = (int) $stmt->insert_id;
        $stmt->close();
        return ['status' => 'added', 'account_id' => $accountId];
    }

    if ((int) ($accountState['payment_count'] ?? 0) > 0) {
        return ['status' => 'preserved_paid', 'account_id' => (int) $accountState['account_id']];
    }

    if ((float) ($accountState['balance'] ?? 0) === $targetAmount) {
        return ['status' => 'unchanged', 'account_id' => (int) $accountState['account_id']];
    }

    $stmt = $conn->prepare("UPDATE accounts SET balance = ?, school_year_label = ? WHERE id = ?");
    if (!$stmt) {
        throw new RuntimeException('Could not update fee account from exception.');
    }
    $accountId = (int) $accountState['account_id'];
    $stmt->bind_param('dsi', $targetAmount, $schoolYearLabel, $accountId);
    $stmt->execute();
    $stmt->close();
    return ['status' => 'updated', 'account_id' => $accountId];
}

function student_fee_exception_review_summary(mysqli $conn, string $schoolYearLabel = '', string $mode = '', string $feeTypeName = ''): array
{
    student_fee_exceptions_ensure_table($conn);

    $where = ["sfe.mode IN ('include', 'exclude', 'override')"];
    $params = [];
    $types = '';

    if (trim($schoolYearLabel) !== '') {
        $where[] = "sfe.school_year_label = ?";
        $params[] = trim($schoolYearLabel);
        $types .= 's';
    }
    if (trim($mode) !== '' && in_array($mode, ['include', 'exclude', 'override'], true)) {
        $where[] = "sfe.mode = ?";
        $params[] = trim($mode);
        $types .= 's';
    }
    if (trim($feeTypeName) !== '') {
        $where[] = "sfe.fee_type_name = ?";
        $params[] = trim($feeTypeName);
        $types .= 's';
    }

    $sql = "SELECT
        COUNT(*) AS total_exceptions,
        SUM(CASE WHEN sfe.mode = 'include' THEN 1 ELSE 0 END) AS included_rows,
        SUM(CASE WHEN sfe.mode = 'exclude' THEN 1 ELSE 0 END) AS excluded_rows,
        SUM(CASE WHEN sfe.mode = 'override' THEN 1 ELSE 0 END) AS override_rows,
        COUNT(DISTINCT sfe.student_id) AS affected_students
        FROM student_fee_exceptions sfe
        WHERE " . implode(' AND ', $where);
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return ['total_exceptions' => 0, 'excluded_rows' => 0, 'override_rows' => 0, 'affected_students' => 0];
    }
    if ($params) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result ? $result->fetch_assoc() : null;
    $stmt->close();

    return [
        'total_exceptions' => (int) ($row['total_exceptions'] ?? 0),
        'included_rows' => (int) ($row['included_rows'] ?? 0),
        'excluded_rows' => (int) ($row['excluded_rows'] ?? 0),
        'override_rows' => (int) ($row['override_rows'] ?? 0),
        'affected_students' => (int) ($row['affected_students'] ?? 0),
    ];
}
