<?php

require_once __DIR__ . '/../../includes/schema-migration.php';

function account_followup_ensure_tables(mysqli $conn): void
{
    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS account_followup_templates (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(120) NOT NULL,
        content TEXT NOT NULL,
        is_enabled TINYINT(1) NOT NULL DEFAULT 1,
        sort_order INT NOT NULL DEFAULT 0,
        created_by VARCHAR(64) NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_by VARCHAR(64) NULL,
        updated_at DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS student_account_followups (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        category VARCHAR(60) NOT NULL DEFAULT 'General',
        contact_person VARCHAR(120) NOT NULL DEFAULT '',
        contact_role VARCHAR(40) NOT NULL DEFAULT '',
        follow_up_date DATE NULL,
        note TEXT NOT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'open',
        created_by VARCHAR(64) NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        resolved_by VARCHAR(64) NULL,
        resolved_at DATETIME NULL,
        INDEX idx_student_status_date (student_id, status, created_at),
        INDEX idx_follow_up_date (follow_up_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS student_account_followup_settings (
        student_id INT NOT NULL PRIMARY KEY,
        active_template_id INT NULL,
        created_by VARCHAR(64) NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_by VARCHAR(64) NULL,
        updated_at DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_active_template_id (active_template_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    if (schema_migration_mode_enabled()) {
        account_followup_seed_templates($conn);
    }
}

function account_followup_tables_ready(mysqli $conn): bool
{
    $result = $conn->query("SHOW TABLES LIKE 'account_followup_templates'");
    $templatesReady = $result && $result->num_rows > 0;
    if ($result) {
        $result->close();
    }

    $result = $conn->query("SHOW TABLES LIKE 'student_account_followups'");
    $notesReady = $result && $result->num_rows > 0;
    if ($result) {
        $result->close();
    }

    $result = $conn->query("SHOW TABLES LIKE 'student_account_followup_settings'");
    $settingsReady = $result && $result->num_rows > 0;
    if ($result) {
        $result->close();
    }

    return $templatesReady && $notesReady && $settingsReady;
}

function account_followup_seed_templates(mysqli $conn): void
{
    $countResult = $conn->query("SELECT COUNT(*) AS total FROM account_followup_templates");
    $count = $countResult ? (int) (($countResult->fetch_assoc()['total'] ?? 0)) : 0;
    if ($countResult) {
        $countResult->close();
    }
    if ($count > 0) {
        return;
    }

    $defaults = [
        ['Annual', "Review assessed annual balance.\nConfirm discounts or special instructions before accepting full payment.\nRemind staff to check receipt number and remaining balance after posting.", 10],
        ['Quarterly', "Check quarter coverage and previous unpaid months.\nConfirm if parent is paying current quarter only or catching up arrears.\nAdd follow-up note when parent promises a date for remaining balance.", 20],
        ['Cash', "Confirm if full cash settlement applies.\nCheck if any discount applies before payment posting.\nRecord any special release or promise as a follow-up note.", 30],
        ['Voucher', "For voucher-related accounts, confirm eligibility and submitted documents.\nCheck whether voucher should apply before advising parent.\nAdd note if voucher is pending, incomplete, or not applicable.", 40],
    ];

    $stmt = $conn->prepare("INSERT INTO account_followup_templates (title, content, sort_order, created_by) VALUES (?, ?, ?, 'System')");
    if (!$stmt) {
        return;
    }
    foreach ($defaults as $row) {
        [$title, $content, $sortOrder] = $row;
        $stmt->bind_param('ssi', $title, $content, $sortOrder);
        $stmt->execute();
    }
    $stmt->close();
}

function account_followup_templates(mysqli $conn, bool $activeOnly = true): array
{
    if (!account_followup_tables_ready($conn)) {
        return [];
    }

    $sql = "SELECT * FROM account_followup_templates";
    if ($activeOnly) {
        $sql .= " WHERE is_enabled = 1";
    }
    $sql .= " ORDER BY sort_order ASC, title ASC";

    $rows = [];
    $result = $conn->query($sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
        $result->close();
    }

    return $rows;
}

function account_followup_notes(mysqli $conn, int $studentId): array
{
    if (!account_followup_tables_ready($conn)) {
        return [];
    }

    $stmt = $conn->prepare("SELECT * FROM student_account_followups WHERE student_id = ? ORDER BY created_at DESC, id DESC");
    if (!$stmt) {
        return [];
    }
    $stmt->bind_param('i', $studentId);
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    $stmt->close();

    return $rows;
}

function account_followup_active_template(mysqli $conn, int $studentId): ?array
{
    if (!account_followup_tables_ready($conn)) {
        return null;
    }

    $stmt = $conn->prepare("SELECT s.active_template_id, s.updated_by, s.updated_at, t.title, t.content, t.is_enabled
        FROM student_account_followup_settings s
        LEFT JOIN account_followup_templates t ON t.id = s.active_template_id
        WHERE s.student_id = ?
        LIMIT 1");
    if (!$stmt) {
        return null;
    }
    $stmt->bind_param('i', $studentId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc() ?: null;
    $stmt->close();

    if (!$row || empty($row['active_template_id'])) {
        return null;
    }

    return $row;
}

function account_followup_set_active_template(mysqli $conn, int $studentId, ?int $templateId, string $username): bool
{
    if (!account_followup_tables_ready($conn)) {
        return false;
    }

    if ($templateId !== null && $templateId > 0) {
        $check = $conn->prepare("SELECT id FROM account_followup_templates WHERE id = ? AND is_enabled = 1 LIMIT 1");
        if (!$check) {
            return false;
        }
        $check->bind_param('i', $templateId);
        $check->execute();
        $exists = (bool) $check->get_result()->fetch_assoc();
        $check->close();
        if (!$exists) {
            return false;
        }
    } else {
        $templateId = null;
    }

    $stmt = $conn->prepare("INSERT INTO student_account_followup_settings
        (student_id, active_template_id, created_by, updated_by)
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE active_template_id = VALUES(active_template_id), updated_by = VALUES(updated_by)");
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('iiss', $studentId, $templateId, $username, $username);
    $success = $stmt->execute();
    $stmt->close();

    return $success;
}

function account_followup_add_note(mysqli $conn, int $studentId, array $data, string $username): bool
{
    if (!account_followup_tables_ready($conn)) {
        return false;
    }

    $category = trim((string) ($data['category'] ?? 'General'));
    $contactPerson = trim((string) ($data['contact_person'] ?? ''));
    $contactRole = trim((string) ($data['contact_role'] ?? ''));
    $followUpDate = trim((string) ($data['follow_up_date'] ?? ''));
    $note = trim((string) ($data['note'] ?? ''));
    if ($category === '') {
        $category = 'General';
    }
    if ($note === '') {
        return false;
    }
    $followUpDateValue = preg_match('/^\d{4}-\d{2}-\d{2}$/', $followUpDate) ? $followUpDate : null;

    $stmt = $conn->prepare("INSERT INTO student_account_followups
        (student_id, category, contact_person, contact_role, follow_up_date, note, status, created_by)
        VALUES (?, ?, ?, ?, ?, ?, 'open', ?)");
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('issssss', $studentId, $category, $contactPerson, $contactRole, $followUpDateValue, $note, $username);
    $success = $stmt->execute();
    $stmt->close();

    return $success;
}

function account_followup_resolve_note(mysqli $conn, int $noteId, int $studentId, string $username): bool
{
    if (!account_followup_tables_ready($conn)) {
        return false;
    }

    $stmt = $conn->prepare("UPDATE student_account_followups
        SET status = 'resolved', resolved_by = ?, resolved_at = NOW()
        WHERE id = ? AND student_id = ? AND status <> 'resolved'");
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('sii', $username, $noteId, $studentId);
    $success = $stmt->execute();
    $affected = $stmt->affected_rows;
    $stmt->close();

    return $success && $affected > 0;
}

function account_followup_save_template(mysqli $conn, array $data, string $username): bool
{
    if (!account_followup_tables_ready($conn)) {
        return false;
    }

    $id = (int) ($data['id'] ?? 0);
    $title = trim((string) ($data['title'] ?? ''));
    $content = trim((string) ($data['content'] ?? ''));
    $sortOrder = (int) ($data['sort_order'] ?? 0);
    $isEnabled = !empty($data['is_enabled']) ? 1 : 0;
    if ($title === '' || $content === '') {
        return false;
    }

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE account_followup_templates
            SET title = ?, content = ?, sort_order = ?, is_enabled = ?, updated_by = ?
            WHERE id = ?");
        if (!$stmt) {
            return false;
        }
        $stmt->bind_param('ssiisi', $title, $content, $sortOrder, $isEnabled, $username, $id);
    } else {
        $stmt = $conn->prepare("INSERT INTO account_followup_templates
            (title, content, sort_order, is_enabled, created_by, updated_by)
            VALUES (?, ?, ?, ?, ?, ?)");
        if (!$stmt) {
            return false;
        }
        $stmt->bind_param('ssiiss', $title, $content, $sortOrder, $isEnabled, $username, $username);
    }

    $success = $stmt->execute();
    $stmt->close();

    return $success;
}

function account_followup_delete_template(mysqli $conn, int $id, string $username): bool
{
    if (!account_followup_tables_ready($conn)) {
        return false;
    }

    $stmt = $conn->prepare("UPDATE account_followup_templates SET is_enabled = 0, updated_by = ? WHERE id = ?");
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('si', $username, $id);
    $success = $stmt->execute();
    $stmt->close();

    return $success;
}

function account_followup_status_counts(array $notes): array
{
    $open = 0;
    $resolved = 0;
    foreach ($notes as $note) {
        if (($note['status'] ?? '') === 'resolved') {
            $resolved++;
        } else {
            $open++;
        }
    }

    return ['open' => $open, 'resolved' => $resolved];
}
