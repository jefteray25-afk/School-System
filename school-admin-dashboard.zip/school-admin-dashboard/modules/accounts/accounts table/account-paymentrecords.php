<?php
require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();
include '../../../config/database.php';
include '../../settings/settings-permissions-roles.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/includes-receipt-helper.php';
require_once __DIR__ . '/../../../includes/receipt-payment-method-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/settings/school-info-helper.php';
require_once __DIR__ . '/../../settings/school-year-helper.php';
ensure_receipts_registry_schema($conn);

$student_id = isset($_GET['student_id']) ? intval($_GET['student_id']) : 0;
$school_year_filter = trim($_GET['school_year'] ?? '');
$error = '';

$currentRole = $_SESSION['role'] ?? '';
$can_view = hasPermission($currentRole, 'financial', 'view');
$can_add = hasPermission($currentRole, 'financial', 'add');
if (!$can_view) {
    admin_session_forbidden();
}

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
$active_school_year_label = school_year_get_active_label($conn);

$student_name = '';
$student_grade = '';
$student_school_year = '';
if ($student_id) {
    $stud_stmt = $conn->prepare("SELECT CONCAT(lastname, ', ', firstname, ' ', middlename) AS student_name, grade, school_year_label FROM students WHERE id = ?");
    $stud_stmt->bind_param('i', $student_id);
    $stud_stmt->execute();
    $stud_stmt->bind_result($student_name, $student_grade, $student_school_year);
    if (!$stud_stmt->fetch()) {
        $error = 'Student not found.';
    }
    $stud_stmt->close();
} else {
    $error = 'Invalid student ID.';
}
$selected_school_year = $school_year_filter !== '' ? $school_year_filter : ($student_school_year ?: $active_school_year_label);

$filter_date = $_GET['filter_date'] ?? '';

$payment_filter_sql = "a.student_id = ?";
$payment_filter_params = [$student_id];
$types = 'i';
if ($selected_school_year !== '') {
    $payment_filter_sql .= " AND COALESCE(NULLIF(TRIM(p.school_year_label), ''), ?) = ?";
    $payment_filter_params[] = $selected_school_year;
    $payment_filter_params[] = $selected_school_year;
    $types .= 'ss';
}
if ($filter_date) {
    $payment_filter_sql .= " AND DATE(p.date_paid) = ?";
    $payment_filter_params[] = $filter_date;
    $types .= 's';
}

$psql = "SELECT p.date_paid, p.amount, a.type AS fee_type, p.remarks, p.booklet_no, p.receipt_no, p.receipt_note, p.reference_number, p.payment_note, p.prepared_by
         FROM payments p
         LEFT JOIN accounts a ON p.account_id = a.id
         LEFT JOIN receipts_registry rr
            ON rr.receipt_no = p.receipt_no
            AND rr.booklet_no = p.booklet_no
            AND rr.voided = 0
            AND rr.used_by IN ('payments', 'other_payment')
         WHERE $payment_filter_sql
           AND (
                (p.booklet_no IS NULL OR p.receipt_no IS NULL)
                OR rr.receipt_no IS NOT NULL
           )
         ORDER BY p.date_paid DESC";
$pstmt = $conn->prepare($psql);
$pstmt->bind_param($types, ...$payment_filter_params);
$pstmt->execute();
$pres = $pstmt->get_result();

$groupedPayments = [];
if ($pres && $pres->num_rows > 0) {
    while ($prow = $pres->fetch_assoc()) {
        $bookletNo = $prow['booklet_no'] ?? '';
        $receiptNo = $prow['receipt_no'] ?? '';
        $groupKey = $bookletNo !== '' && $receiptNo !== '' ? ($bookletNo . '-' . $receiptNo) : ('noreceipt-' . $prow['date_paid'] . '-' . ($prow['fee_type'] ?? ''));
        if (!isset($groupedPayments[$groupKey])) {
            $methodBreakdown = receipt_payment_methods_for_display(
                $conn,
                (int) ($bookletNo ?: 0),
                (int) ($receiptNo ?: 0),
                null,
                (string) ($prow['receipt_note'] ?? ''),
                (string) ($prow['reference_number'] ?? ''),
                (string) ($prow['payment_note'] ?? '')
            );
            $legacyReferenceFallback = trim((string) ($prow['reference_number'] ?? ''));
            if ($legacyReferenceFallback === '') {
                $legacyReferenceFallback = receipt_payment_methods_extract_reference_from_text((string) ($prow['remarks'] ?? ''));
            }
            $referenceDisplay = receipt_payment_methods_reference_display($methodBreakdown);
            if ($referenceDisplay === '-' && $legacyReferenceFallback !== '') {
                $referenceDisplay = $legacyReferenceFallback;
            }
            $paymentNoteDisplay = receipt_payment_methods_note_display($methodBreakdown, (string) ($prow['payment_note'] ?? '-'));
            if (receipt_payment_methods_is_legacy_placeholder($methodBreakdown)
                && strcasecmp(trim((string) $paymentNoteDisplay), trim((string) ($prow['receipt_note'] ?? ''))) === 0) {
                $paymentNoteDisplay = '-';
            }
            $groupedPayments[$groupKey] = [
                'date_paid' => $prow['date_paid'],
                'remarks' => $prow['remarks'],
                'booklet_no' => $bookletNo,
                'receipt_no' => $receiptNo,
                'receipt_note' => $prow['receipt_note'] ?? '',
                'reference_number' => $prow['reference_number'] ?? '',
                'payment_note' => $prow['payment_note'] ?? '',
                'method_breakdown' => $methodBreakdown,
                'method_label' => receipt_payment_methods_display_label($methodBreakdown),
                'reference_display' => $referenceDisplay,
                'payment_note_display' => $paymentNoteDisplay,
                'method_breakdown_text' => receipt_payment_methods_summary_text($methodBreakdown),
                'method_breakdown_total' => receipt_payment_methods_total($methodBreakdown),
                'is_legacy_method_breakdown' => receipt_payment_methods_is_legacy_placeholder($methodBreakdown),
                'prepared_by' => $prow['prepared_by'] ?? '',
                'total' => 0.0,
                'items' => [],
            ];
        }
        $groupedPayments[$groupKey]['total'] += (float) $prow['amount'];
        $groupedPayments[$groupKey]['items'][] = [
            'fee_type' => $prow['fee_type'] ?? '',
            'amount' => (float) $prow['amount'],
            'remarks' => $prow['remarks'] ?? '',
        ];
    }
}
$groupedPayments = array_values($groupedPayments);
foreach ($groupedPayments as &$paymentGroup) {
    $distinctRemarks = [];
    $hasFullyPaid = false;
    $hasRemainingBalance = false;

    foreach (($paymentGroup['items'] ?? []) as $itemRow) {
        $itemRemarks = trim((string) ($itemRow['remarks'] ?? ''));
        if ($itemRemarks === '') {
            continue;
        }
        $distinctRemarks[$itemRemarks] = true;
        if (strcasecmp($itemRemarks, 'Fully Paid') === 0) {
            $hasFullyPaid = true;
        } elseif (strpos($itemRemarks, 'Remaining Balance:') === 0) {
            $hasRemainingBalance = true;
        }
    }

    $distinctRemarkList = array_keys($distinctRemarks);
    $statusLabel = trim((string) ($paymentGroup['remarks'] ?? ''));
    $statusVariant = 'plain';
    $statusHelpText = '';

    if ($hasFullyPaid && $hasRemainingBalance) {
        $statusLabel = 'Mixed Payment Status';
        $statusVariant = 'mixed';
        $statusHelpText = 'Some fee items are fully paid while others still have remaining balances.';
    } elseif ($hasRemainingBalance && !$hasFullyPaid) {
        $statusVariant = 'balance';
        if (count($distinctRemarkList) === 1) {
            $statusLabel = $distinctRemarkList[0];
        } else {
            $statusLabel = 'With Remaining Balance';
            $statusHelpText = 'This receipt covers multiple fee items with remaining balances.';
        }
    } elseif ($hasFullyPaid && !$hasRemainingBalance) {
        $statusLabel = 'Fully Paid';
        $statusVariant = 'paid';
    } elseif (count($distinctRemarkList) > 1) {
        $statusLabel = 'Multiple Payment Remarks';
        $statusVariant = 'mixed';
        $statusHelpText = implode(' | ', $distinctRemarkList);
    }

    $methodBreakdownTotal = (float) ($paymentGroup['method_breakdown_total'] ?? 0);
    if ($methodBreakdownTotal > 0 && abs((float) ($paymentGroup['total'] ?? 0) - $methodBreakdownTotal) > 0.009) {
        $statusLabel = 'Receipt Total Mismatch';
        $statusVariant = 'mixed';
        $statusHelpText = 'Posted fee rows total PHP ' . number_format((float) ($paymentGroup['total'] ?? 0), 2)
            . ' but payment method total is PHP ' . number_format($methodBreakdownTotal, 2)
            . '. Void and repost this receipt to correct the record.';
    }

    $paymentGroup['status_label'] = $statusLabel !== '' ? $statusLabel : '-';
    $paymentGroup['status_variant'] = $statusVariant;
    $paymentGroup['status_help_text'] = $statusHelpText;
    $paymentGroup['distinct_remarks'] = $distinctRemarkList;
}
unset($paymentGroup);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Desk | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --page-bg: #eef3f9;
            --card-bg: #ffffff;
            --card-border: #d9e3ef;
            --brand-dark: #23395d;
            --brand-mid: #517fa4;
            --brand-soft: #edf4fb;
            --text-soft: #5f7186;
            --success-soft: #e7f6ee;
            --warning-soft: #fff4d8;
        }
        body {
            background:
                radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 30%),
                linear-gradient(180deg, #f8fbff 0%, var(--page-bg) 100%);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
            color: var(--brand-dark);
        }
        .payment-desk-shell {
            width: min(1720px, calc(100vw - 16px));
            margin: 0 auto;
        }
        .toolbar-card,
        .panel-card {
            border: 1px solid var(--card-border);
            border-radius: 20px;
            background: var(--card-bg);
            box-shadow: 0 14px 32px rgba(35,57,93,0.07);
        }
        .toolbar-card {
            padding: 16px 18px;
            margin-bottom: 16px;
        }
        .payment-header-bar {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 12px;
            flex-wrap: wrap;
            margin-bottom: 1rem;
            text-align: center;
        }
        .payment-header-copy {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .section-title {
            margin: 0;
            font-size: 1.15rem;
            font-weight: 800;
            color: var(--brand-dark);
        }
        .toolbar-actions {
            display: flex;
            justify-content: center;
            gap: 10px;
            flex-wrap: wrap;
            width: 100%;
        }
        .filter-toolbar {
            justify-content: center;
            align-items: end;
            max-width: 560px;
            margin: 0 auto;
        }
        .filter-actions {
            display: flex;
            justify-content: center;
            gap: 10px;
            flex-wrap: wrap;
        }
        .section-caption {
            color: var(--text-soft);
            margin-top: 6px;
            margin-bottom: 0;
        }
        .btn-primary-soft {
            background: var(--brand-dark);
            border-color: var(--brand-dark);
            color: #fff;
            font-weight: 600;
        }
        .btn-primary-soft:hover {
            background: #1d2f4a;
            border-color: #1d2f4a;
            color: #fff;
        }
        .btn-secondary-soft {
            background: #eef3f8;
            border-color: #d7e1ed;
            color: var(--brand-dark);
            font-weight: 600;
        }
        .btn-secondary-soft:hover {
            background: #e1eaf4;
            border-color: #c8d5e4;
            color: var(--brand-dark);
        }
        .panel-card .card-header {
            background: linear-gradient(135deg, var(--brand-dark), var(--brand-mid));
            color: #fff;
            font-weight: 700;
            border: 0;
            padding: 14px 18px;
            border-radius: 20px 20px 0 0;
        }
        .table {
            margin-bottom: 0;
            min-width: 1180px;
        }
        .table thead th {
            background: var(--brand-soft);
            color: var(--brand-dark);
            border-bottom: 1px solid var(--card-border);
            font-size: 0.92rem;
            font-weight: 700;
            white-space: nowrap;
        }
        .table td, .table th {
            padding: 0.9rem 0.85rem;
            vertical-align: middle;
        }
        .table td {
            line-height: 1.45;
        }
        .col-date { min-width: 110px; }
        .col-time { min-width: 95px; }
        .col-amount { min-width: 120px; }
        .col-fee { min-width: 160px; }
        .col-receipt { min-width: 120px; }
        .col-method { min-width: 120px; }
        .col-reference { min-width: 170px; }
        .col-note { min-width: 280px; }
        .col-prepared { min-width: 110px; }
        .col-remarks { min-width: 150px; }
        .table tbody tr:hover {
            background: transparent;
        }
        .amount-chip {
            display: inline-flex;
            align-items: center;
            border-radius: 999px;
            padding: 6px 12px;
            background: var(--brand-soft);
            color: var(--brand-dark);
            font-weight: 700;
        }
        .remark-pill {
            display: inline-flex;
            align-items: center;
            border-radius: 999px;
            padding: 6px 10px;
            font-weight: 700;
            font-size: 0.88rem;
        }
        .remark-paid {
            background: var(--success-soft);
            color: #18794e;
        }
        .remark-balance {
            background: var(--warning-soft);
            color: #9a6a00;
        }
        .receipt-chip,
        .method-chip,
        .prep-chip {
            display: inline-flex;
            align-items: center;
            border-radius: 999px;
            padding: 6px 12px;
            font-weight: 700;
            font-size: 0.86rem;
        }
        .receipt-chip {
            background: var(--brand-soft);
            color: var(--brand-dark);
        }
        .method-chip {
            background: #eef6ff;
            color: #0b5ed7;
        }
        .prep-chip {
            background: #f5f3ff;
            color: #5b3dbb;
        }
        .receipt-meta,
        .detail-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }
        .table-summary-text {
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
            word-break: break-word;
        }
        .receipt-action {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            white-space: nowrap;
        }
        .receipt-action.btn {
            border-radius: 999px;
            padding-inline: 0.9rem;
            font-weight: 700;
            border-color: #bfd6ee;
            color: var(--brand-dark);
            background: #f8fbff;
        }
        .receipt-action.btn:hover {
            background: #eef5fd;
            border-color: #a8c8e6;
            color: var(--brand-dark);
        }
        .drilldown-modal .modal-content {
            border-radius: 28px;
            overflow: hidden;
            background:
                radial-gradient(circle at top right, rgba(81,127,164,0.12), transparent 24%),
                linear-gradient(180deg, #fbfdff 0%, #f4f8fc 100%);
        }
        .drilldown-modal .modal-header {
            padding: 0;
            border-bottom: 0;
            background: transparent;
        }
        .drilldown-modal .modal-body {
            padding: 1.5rem;
        }
        .drilldown-modal .modal-footer {
            border-top: 1px solid rgba(81,127,164,0.12);
            padding: 1rem 1.5rem 1.35rem;
            background: rgba(255,255,255,0.72);
            backdrop-filter: blur(10px);
        }
        .drilldown-hero {
            position: relative;
            padding: 1.4rem 1.45rem 1.2rem;
            background:
                linear-gradient(135deg, rgba(35,57,93,0.96), rgba(81,127,164,0.92)),
                linear-gradient(180deg, #20395d, #517fa4);
            color: #fff;
        }
        .drilldown-hero::after {
            content: "";
            position: absolute;
            inset: auto -20% -45% auto;
            width: 240px;
            height: 240px;
            background: radial-gradient(circle, rgba(255,255,255,0.16), transparent 62%);
            pointer-events: none;
        }
        .drilldown-hero-top {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 1rem;
            margin-bottom: 1rem;
        }
        .drilldown-kicker {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            padding: 0.38rem 0.78rem;
            border-radius: 999px;
            background: rgba(255,255,255,0.14);
            color: rgba(255,255,255,0.92);
            font-size: 0.76rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
        }
        .drilldown-title {
            margin: 0.8rem 0 0.28rem;
            font-size: 1.45rem;
            font-weight: 800;
            letter-spacing: -0.02em;
        }
        .drilldown-subtitle {
            margin: 0;
            max-width: 680px;
            color: rgba(255,255,255,0.82);
            line-height: 1.55;
        }
        .drilldown-close {
            flex-shrink: 0;
            border: 1px solid rgba(255,255,255,0.18);
            border-radius: 999px;
            background: rgba(255,255,255,0.1);
            color: #fff;
            width: 42px;
            height: 42px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        .drilldown-close:hover {
            background: rgba(255,255,255,0.18);
            color: #fff;
        }
        .drilldown-hero-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: 12px;
        }
        .hero-stat {
            padding: 0.9rem 1rem;
            border-radius: 18px;
            background: rgba(255,255,255,0.12);
            border: 1px solid rgba(255,255,255,0.12);
            backdrop-filter: blur(10px);
        }
        .hero-stat-label {
            display: block;
            font-size: 0.74rem;
            font-weight: 700;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: rgba(255,255,255,0.7);
            margin-bottom: 0.4rem;
        }
        .hero-stat-value {
            font-size: 1rem;
            font-weight: 800;
            color: #fff;
            word-break: break-word;
        }
        .drilldown-section {
            margin-top: 1rem;
        }
        .drilldown-section-heading {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 0.8rem;
            margin-bottom: 0.85rem;
        }
        .drilldown-section-heading h6 {
            margin: 0;
            font-size: 0.95rem;
            font-weight: 800;
            color: var(--brand-dark);
            letter-spacing: 0.01em;
        }
        .drilldown-section-heading span {
            font-size: 0.82rem;
            color: var(--text-soft);
        }
        .drilldown-meta-strip {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 1.1rem;
        }
        .meta-pill {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.72rem 0.95rem;
            border-radius: 999px;
            background: rgba(255,255,255,0.92);
            border: 1px solid rgba(81,127,164,0.14);
            box-shadow: 0 8px 18px rgba(35,57,93,0.05);
            color: var(--brand-dark);
            font-size: 0.88rem;
            font-weight: 700;
        }
        .meta-pill i {
            color: var(--brand-mid);
        }
        .modal-detail-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 14px;
        }
        .detail-card {
            border: 1px solid rgba(81,127,164,0.14);
            border-radius: 18px;
            background: linear-gradient(180deg, rgba(255,255,255,0.98), rgba(244,249,255,0.95));
            padding: 14px 15px;
            box-shadow: 0 10px 24px rgba(35,57,93,0.05);
        }
        .detail-card-label {
            display: block;
            font-size: 0.72rem;
            font-weight: 700;
            letter-spacing: 0.08em;
            color: var(--text-soft);
            text-transform: uppercase;
            margin-bottom: 6px;
        }
        .detail-card-value {
            color: var(--brand-dark);
            font-weight: 800;
            font-size: 1rem;
            word-break: break-word;
        }
        .detail-card-value.subtle {
            font-size: 0.94rem;
            font-weight: 700;
        }
        .breakdown-table td,
        .breakdown-table th {
            padding: 0.7rem 0.8rem;
        }
        .method-breakdown-list {
            display: grid;
            gap: 12px;
        }
        .method-breakdown-item {
            border: 1px solid rgba(81,127,164,0.14);
            border-radius: 18px;
            padding: 14px 15px;
            background: linear-gradient(180deg, #ffffff 0%, #f9fbfe 100%);
            box-shadow: 0 10px 22px rgba(35,57,93,0.05);
        }
        .method-breakdown-item strong {
            color: var(--brand-dark);
        }
        .method-breakdown-top {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 0.8rem;
            flex-wrap: wrap;
        }
        .method-name-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            border-radius: 999px;
            padding: 0.42rem 0.8rem;
            background: #edf5fe;
            color: #0d5fb8;
            font-weight: 800;
            font-size: 0.84rem;
        }
        .method-amount {
            color: var(--brand-dark);
            font-size: 1rem;
            font-weight: 800;
        }
        .method-breakdown-meta {
            display: grid;
            gap: 0.45rem;
            margin-top: 0.8rem;
        }
        .method-breakdown-meta-line {
            color: var(--text-soft);
            font-size: 0.88rem;
            line-height: 1.45;
            word-break: break-word;
        }
        .modal-note-block {
            border: 1px solid rgba(81,127,164,0.14);
            border-radius: 18px;
            background: linear-gradient(180deg, #ffffff 0%, #f9fbfe 100%);
            padding: 14px 15px;
            color: var(--brand-dark);
            white-space: pre-wrap;
            line-height: 1.6;
            box-shadow: 0 10px 22px rgba(35,57,93,0.05);
        }
        .context-stack {
            display: grid;
            gap: 12px;
        }
        .fee-table-shell {
            border: 1px solid rgba(81,127,164,0.14);
            border-radius: 18px;
            overflow: hidden;
            background: #fff;
            box-shadow: 0 10px 22px rgba(35,57,93,0.05);
        }
        .fee-table-shell .table {
            min-width: 0;
        }
        .fee-table-shell thead th {
            background: #edf5fe;
            border-bottom-color: rgba(81,127,164,0.14);
        }
        .fee-total-row td {
            background: #f7fbff;
            font-weight: 800;
            color: var(--brand-dark);
        }
        @media (max-width: 767.98px) {
            .drilldown-modal .modal-body,
            .drilldown-modal .modal-footer {
                padding-inline: 1rem;
            }
            .drilldown-hero {
                padding: 1.15rem 1rem 1rem;
            }
            .drilldown-title {
                font-size: 1.2rem;
            }
        }
        .empty-state {
            color: var(--text-soft);
            padding: 28px 12px;
            font-weight: 600;
        }
    </style>
</head>
<body>
<div id="page-content-wrapper" class="w-100">
    <div class="payment-desk-shell px-2 px-xl-3 mt-2">
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php else: ?>
            <div class="toolbar-card">
                <div class="payment-header-bar">
                    <div class="payment-header-copy">
                        <h3 class="section-title"><i class="fas fa-history me-2"></i>Payment Desk</h3>
                        <p class="section-caption">Review posted payments, receipt context, and who prepared each entry.</p>
                    </div>
                    <div class="toolbar-actions">
                        <a href="../account-view.php?student_id=<?= $student_id ?>&school_year=<?= urlencode($selected_school_year) ?>" class="btn btn-secondary-soft">
                            <i class="fas fa-arrow-left"></i> Back to Finance Profile
                        </a>
                        <?php if ($can_add): ?>
                            <a href="account-add-payment.php?student_id=<?= $student_id ?>&school_year=<?= urlencode($selected_school_year) ?>" class="btn btn-primary-soft">
                                <i class="fas fa-plus"></i> Post Payment
                            </a>
                            <a href="account-other.php?student_id=<?= $student_id ?>&school_year=<?= urlencode($selected_school_year) ?>" class="btn btn-secondary-soft">
                                <i class="fas fa-plus-circle"></i> Post Other Payment
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
                <form method="get" class="row g-2 filter-toolbar" id="paymentFilterForm" autocomplete="off">
                    <input type="hidden" name="student_id" value="<?= $student_id ?>">
                    <div class="col-12 col-sm-6 col-md-4">
                        <input type="date" name="filter_date" value="<?= htmlspecialchars($filter_date) ?>" class="form-control" placeholder="Filter Date">
                    </div>
                    <div class="col-12 col-sm-auto">
                        <div class="filter-actions">
                        <button type="submit" class="btn btn-primary-soft"><i class="fas fa-filter"></i> Filter</button>
                        <button type="button" class="btn btn-secondary-soft" id="resetPaymentBtn">Clear Filters</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="card panel-card mb-4" id="records">
                <div class="card-header">
                    <i class="fas fa-history"></i> Payment Records
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th class="col-date">Date Paid</th>
                                    <th class="col-time">Time Paid</th>
                                    <th class="col-amount">Amount</th>
                                    <th class="col-fee">Fee Type</th>
                                    <th class="col-receipt">Receipt</th>
                                    <th class="col-method">Payment Method</th>
                                    <th class="col-reference">Reference No.</th>
                                    <th class="col-note">Note</th>
                                    <th class="col-prepared">Prepared By</th>
                                    <th class="col-remarks">Remarks</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if (!empty($groupedPayments)): ?>
                                <?php $rowIndex = 0; $receiptModals = []; ?>
                                <?php foreach ($groupedPayments as $payment): ?>
                                    <?php
                                    $datetime = $payment['date_paid'];
                                    $date = '';
                                    $time = '';
                                    if ($datetime) {
                                        $dt = new DateTime($datetime);
                                        $date = $dt->format('Y-m-d');
                                        $time = $dt->format('h:i A');
                                    }
                                    $rowIndex++;
                                    $modalId = 'receipt-drilldown-' . $rowIndex;
                                    $itemsCount = count($payment['items'] ?? []);
                                    ?>
                                    <tr>
                                        <td><?= htmlspecialchars($date) ?></td>
                                        <td><?= htmlspecialchars($time) ?></td>
                                        <td><span class="amount-chip">&#8369;<?= number_format($payment['total'], 2) ?></span></td>
                                        <td>
                                            <div class="d-flex flex-column gap-2">
                                                <span><?= htmlspecialchars($itemsCount > 1 ? ($itemsCount . ' items') : ($payment['items'][0]['fee_type'] ?? '')) ?></span>
                                                <div>
                                                    <button type="button" class="btn btn-sm btn-outline-primary receipt-action" data-bs-toggle="modal" data-bs-target="#<?= $modalId ?>">
                                                        <i class="fas fa-receipt"></i> View details
                                                    </button>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if (!empty($payment['booklet_no']) && !empty($payment['receipt_no'])): ?>
                                                <div class="receipt-meta">
                                                    <span class="receipt-chip"><?= htmlspecialchars(booklet_label_from_stored((int) $payment['booklet_no'])) ?></span>
                                                    <span class="receipt-chip">OR <?= htmlspecialchars((string) $payment['receipt_no']) ?></span>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-muted">No OR</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><span class="method-chip"><?= htmlspecialchars((string) ($payment['method_label'] ?: 'Not Set')) ?></span></td>
                                        <td><div class="table-summary-text"><?= htmlspecialchars((string) ($payment['reference_display'] ?: '-')) ?></div></td>
                                        <td><div class="table-summary-text"><?= htmlspecialchars((string) ($payment['payment_note_display'] ?: '-')) ?></div></td>
                                        <td><span class="prep-chip"><?= htmlspecialchars((string) ($payment['prepared_by'] ?: 'Unknown')) ?></span></td>
                                        <td>
                                            <?php if (($payment['status_variant'] ?? '') === 'paid'): ?>
                                                <span class="remark-pill remark-paid"><?= htmlspecialchars((string) ($payment['status_label'] ?? 'Fully Paid')) ?></span>
                                            <?php elseif (($payment['status_variant'] ?? '') === 'balance'): ?>
                                                <span class="remark-pill remark-balance"><?= htmlspecialchars((string) ($payment['status_label'] ?? 'With Remaining Balance')) ?></span>
                                            <?php elseif (($payment['status_variant'] ?? '') === 'mixed'): ?>
                                                <span class="remark-pill remark-balance"><?= htmlspecialchars((string) ($payment['status_label'] ?? 'Mixed Payment Status')) ?></span>
                                            <?php else: ?>
                                                <?= htmlspecialchars((string) ($payment['status_label'] ?? '-')) ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php ob_start(); ?>
                                    <div class="modal fade drilldown-modal" id="<?= $modalId ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
                                            <div class="modal-content border-0 shadow-lg">
                                                <div class="modal-header">
                                                    <div class="drilldown-hero w-100">
                                                        <div class="drilldown-hero-top">
                                                            <div>
                                                                <span class="drilldown-kicker"><i class="fas fa-receipt"></i> Receipt Drilldown</span>
                                                                <h5 class="drilldown-title">Payment receipt overview</h5>
                                                                <p class="drilldown-subtitle">A cleaner view of the posted transaction, including official receipt context, method breakdown, fee coverage, and prepared-by details.</p>
                                                            </div>
                                                            <button type="button" class="btn drilldown-close" data-bs-dismiss="modal" aria-label="Close">
                                                                <i class="fas fa-times"></i>
                                                            </button>
                                                        </div>
                                                        <div class="drilldown-hero-grid">
                                                            <div class="hero-stat">
                                                                <span class="hero-stat-label">Official Receipt</span>
                                                                <div class="hero-stat-value">
                                                                    <?php if (!empty($payment['booklet_no']) && !empty($payment['receipt_no'])): ?>
                                                                        <?= htmlspecialchars(booklet_label_from_stored((int) $payment['booklet_no'])) ?> / OR <?= htmlspecialchars((string) $payment['receipt_no']) ?>
                                                                    <?php else: ?>
                                                                        No OR
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                            <div class="hero-stat">
                                                                <span class="hero-stat-label">Total Paid</span>
                                                                <div class="hero-stat-value">PHP <?= number_format($payment['total'], 2) ?></div>
                                                            </div>
                                                            <div class="hero-stat">
                                                                <span class="hero-stat-label">Payment Method</span>
                                                                <div class="hero-stat-value"><?= htmlspecialchars((string) ($payment['method_label'] ?: 'Not Set')) ?></div>
                                                            </div>
                                                            <div class="hero-stat">
                                                                <span class="hero-stat-label">Prepared By</span>
                                                                <div class="hero-stat-value"><?= htmlspecialchars((string) ($payment['prepared_by'] ?: 'Unknown')) ?></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="drilldown-meta-strip">
                                                        <span class="meta-pill"><i class="far fa-calendar-alt"></i> Date Paid: <?= htmlspecialchars($date ?: '-') ?></span>
                                                        <span class="meta-pill"><i class="far fa-clock"></i> Time Paid: <?= htmlspecialchars($time ?: '-') ?></span>
                                                        <span class="meta-pill"><i class="fas fa-layer-group"></i> <?= (int) $itemsCount ?> fee item<?= $itemsCount === 1 ? '' : 's' ?> covered</span>
                                                    </div>

                                                    <div class="row g-3 mb-3">
                                                        <div class="col-12 col-lg-6">
                                                            <div class="detail-card h-100">
                                                                <div class="drilldown-section-heading">
                                                                    <h6>Payment Method Breakdown</h6>
                                                                    <span><?= htmlspecialchars((string) ($payment['method_breakdown_text'] !== '' ? $payment['method_breakdown_text'] : (($payment['is_legacy_method_breakdown'] ?? false) ? 'Legacy receipt method captured' : 'No structured breakdown'))) ?></span>
                                                                </div>
                                                                <?php if (!empty($payment['method_breakdown'])): ?>
                                                                    <div class="method-breakdown-list">
                                                                        <?php foreach (($payment['method_breakdown'] ?? []) as $methodRow): ?>
                                                                            <div class="method-breakdown-item">
                                                                                <div class="method-breakdown-top">
                                                                                    <span class="method-name-chip"><i class="fas fa-wallet"></i> <?= htmlspecialchars((string) ($methodRow['method'] ?? '')) ?></span>
                                                                                    <span class="method-amount">
                                                                                        <?php if (($payment['is_legacy_method_breakdown'] ?? false) && (float) ($methodRow['amount'] ?? 0) <= 0): ?>
                                                                                            Legacy record
                                                                                        <?php else: ?>
                                                                                            PHP <?= number_format((float) ($methodRow['amount'] ?? 0), 2) ?>
                                                                                        <?php endif; ?>
                                                                                    </span>
                                                                                </div>
                                                                                <div class="method-breakdown-meta">
                                                                                    <?php if (!empty($methodRow['reference_number'])): ?>
                                                                                        <div class="method-breakdown-meta-line"><strong>Reference:</strong> <?= htmlspecialchars((string) $methodRow['reference_number']) ?></div>
                                                                                    <?php endif; ?>
                                                                                    <?php if (!empty($methodRow['note'])): ?>
                                                                                        <div class="method-breakdown-meta-line"><strong>Note:</strong> <?= htmlspecialchars((string) $methodRow['note']) ?></div>
                                                                                    <?php endif; ?>
                                                                                </div>
                                                                            </div>
                                                                        <?php endforeach; ?>
                                                                    </div>
                                                                <?php else: ?>
                                                                    <div class="detail-card-value">No payment method breakdown saved.</div>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="col-12 col-lg-6">
                                                            <div class="detail-card h-100">
                                                                <div class="drilldown-section-heading">
                                                                    <h6>Receipt Context</h6>
                                                                    <span>Reference and posting notes</span>
                                                                </div>
                                                                <div class="context-stack">
                                                                    <div class="modal-detail-grid">
                                                                        <div>
                                                                            <span class="detail-card-label">Reference No.</span>
                                                                            <div class="detail-card-value"><?= htmlspecialchars((string) ($payment['reference_display'] ?: '-')) ?></div>
                                                                        </div>
                                                                        <div>
                                                                            <span class="detail-card-label">Remarks</span>
                                                                            <div class="detail-card-value"><?= htmlspecialchars((string) (($payment['status_label'] ?? '') !== '' ? $payment['status_label'] : '-')) ?></div>
                                                                        </div>
                                                                    </div>
                                                                    <?php if (!empty($payment['status_help_text'])): ?>
                                                                        <div>
                                                                            <span class="detail-card-label">Status Note</span>
                                                                            <div class="modal-note-block"><?= htmlspecialchars((string) $payment['status_help_text']) ?></div>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                    <div>
                                                                        <span class="detail-card-label">Receipt Note</span>
                                                                        <div class="modal-note-block"><?= htmlspecialchars((string) ($payment['payment_note_display'] ?: '-')) ?></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="detail-card">
                                                        <div class="drilldown-section-heading">
                                                            <h6>Fee Items Covered</h6>
                                                            <span><?= (int) $itemsCount ?> item<?= $itemsCount === 1 ? '' : 's' ?> posted under this receipt</span>
                                                        </div>
                                                        <div class="table-responsive fee-table-shell">
                                                            <table class="table table-sm breakdown-table mb-0">
                                                                <thead>
                                                                    <tr>
                                                                        <th>Fee Type</th>
                                                                        <th class="text-end">Amount</th>
                                                                        <th>Status</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php foreach ($payment['items'] as $item): ?>
                                                                        <tr>
                                                                            <td><?= htmlspecialchars((string) ($item['fee_type'] ?? '')) ?></td>
                                                                            <td class="text-end">PHP <?= number_format((float) ($item['amount'] ?? 0), 2) ?></td>
                                                                            <td><?= htmlspecialchars((string) (($item['remarks'] ?? '') !== '' ? $item['remarks'] : '-')) ?></td>
                                                                        </tr>
                                                                    <?php endforeach; ?>
                                                                    <tr class="fee-total-row">
                                                                        <td>Total Receipt Amount</td>
                                                                        <td class="text-end">PHP <?= number_format($payment['total'], 2) ?></td>
                                                                        <td><?= htmlspecialchars((string) (($payment['status_label'] ?? '') !== '' ? $payment['status_label'] : '-')) ?></td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary-soft" data-bs-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php $receiptModals[] = ob_get_clean(); ?>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="10" class="text-center empty-state">No payment records matched the current filter.</td></tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php if (!empty($receiptModals)): ?>
                <?php foreach ($receiptModals as $modalMarkup): ?>
                    <?= $modalMarkup ?>
                <?php endforeach; ?>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <?php if (file_exists('../../includes/footer.php')) include '../../includes/footer.php'; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('resetPaymentBtn')?.addEventListener('click', function () {
    const url = new URL(window.location.href);
    url.searchParams.delete('filter_date');
    window.location.href = url.toString();
});
</script>
</body>
</html>
<?php
$pstmt->close();
$conn->close();
?>
