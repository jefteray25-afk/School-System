<?php
require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();
include '../../../config/database.php';
include '../../settings/settings-permissions-roles.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/settings/school-info-helper.php';
require_once __DIR__ . '/../../settings/school-year-helper.php';

$student_id = isset($_GET['student_id']) ? intval($_GET['student_id']) : 0;
$school_year_filter = trim($_GET['school_year'] ?? '');
$error = '';

$currentRole = $_SESSION['role'] ?? '';
$can_view = hasPermission($currentRole, 'financial', 'view');
if (!$can_view) {
    admin_session_forbidden();
}

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
$active_school_year_label = school_year_get_active_label($conn);

$student_name = '';
$student_grade = '';
$student_school_year = '';
if ($student_id) {
    $stud_stmt = $conn->prepare("SELECT CONCAT(lastname, ', ', firstname, ' ', middlename) AS student_name, grade, school_year_label FROM students WHERE id = ?");
    $stud_stmt->bind_param('i', $student_id);
    $stud_stmt->execute();
    $stud_stmt->bind_result($student_name, $student_grade, $student_school_year);
    if (!$stud_stmt->fetch()) {
        $error = 'Student not found.';
    }
    $stud_stmt->close();
} else {
    $error = 'Invalid student ID.';
}
$selected_school_year = $school_year_filter !== '' ? $school_year_filter : ($student_school_year ?: $active_school_year_label);

$fee_accounts = [];
if ($student_id) {
    $fa_stmt = $conn->prepare("SELECT type, balance FROM accounts WHERE student_id=? AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ? ORDER BY type ASC");
    $fa_stmt->bind_param('iss', $student_id, $selected_school_year, $selected_school_year);
    $fa_stmt->execute();
    $fa_res = $fa_stmt->get_result();
    while ($row = $fa_res->fetch_assoc()) {
        $fee_accounts[] = $row;
    }
    $fa_stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Fee Balances</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --page-bg: #eef3f9;
            --card-bg: #ffffff;
            --card-border: #d9e3ef;
            --brand-dark: #23395d;
            --brand-mid: #517fa4;
            --brand-soft: #edf4fb;
            --text-soft: #5f7186;
            --success-soft: #e7f6ee;
            --warning-soft: #fff4d8;
            --danger-soft: #fdecec;
        }
        body {
            background:
                radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 30%),
                linear-gradient(180deg, #f8fbff 0%, var(--page-bg) 100%);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
            color: var(--brand-dark);
        }
        .panel-card {
            border: 1px solid var(--card-border);
            border-radius: 20px;
            background: var(--card-bg);
            box-shadow: 0 14px 32px rgba(35,57,93,0.07);
        }
        .panel-card .card-header {
            background: linear-gradient(135deg, var(--brand-dark), var(--brand-mid));
            color: #fff;
            font-weight: 700;
            border: 0;
            padding: 14px 18px;
            border-radius: 20px 20px 0 0;
        }
        .table {
            margin-bottom: 0;
        }
        .table thead th {
            background: var(--brand-soft);
            color: var(--brand-dark);
            border-bottom: 1px solid var(--card-border);
            font-size: 0.92rem;
            font-weight: 700;
        }
        .table td, .table th {
            padding: 0.95rem 0.85rem;
            vertical-align: middle;
        }
        .table tbody tr:hover {
            background: transparent;
        }
        .balance-pill,
        .status-pill {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 999px;
            padding: 6px 12px;
            font-weight: 700;
            min-width: 110px;
        }
        .balance-paid,
        .status-paid {
            background: var(--success-soft);
            color: #18794e;
        }
        .balance-low,
        .status-low {
            background: var(--warning-soft);
            color: #9a6a00;
        }
        .balance-outstanding,
        .status-outstanding {
            background: var(--danger-soft);
            color: #b42318;
        }
        .empty-state {
            color: var(--text-soft);
            padding: 28px 12px;
            font-weight: 600;
        }
    </style>
</head>
<body>
<div id="page-content-wrapper" class="w-100">
    <div class="mt-2">
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php else: ?>
            <div class="card panel-card mb-4">
                <div class="card-header">
                    <i class="fas fa-coins"></i> Fee Balances
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Fee Type</th>
                                    <th class="text-center">Balance</th>
                                    <th class="text-center">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($fee_accounts)): ?>
                                    <?php foreach ($fee_accounts as $fa): ?>
                                        <?php
                                        $bal = (float) $fa['balance'];
                                        if ($bal == 0.0) {
                                            $balanceClass = 'balance-paid';
                                            $statusClass = 'status-paid';
                                            $statusText = 'Paid';
                                        } elseif ($bal < 500) {
                                            $balanceClass = 'balance-low';
                                            $statusClass = 'status-low';
                                            $statusText = 'Low Balance';
                                        } else {
                                            $balanceClass = 'balance-outstanding';
                                            $statusClass = 'status-outstanding';
                                            $statusText = 'Outstanding';
                                        }
                                        ?>
                                        <tr>
                                            <td><?= htmlspecialchars($fa['type']) ?></td>
                                            <td class="text-center">
                                                <span class="balance-pill <?= $balanceClass ?>">&#8369;<?= number_format($bal, 2) ?></span>
                                            </td>
                                            <td class="text-center">
                                                <span class="status-pill <?= $statusClass ?>"><?= htmlspecialchars($statusText) ?></span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="3" class="text-center empty-state">No fee balances found for this school year.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <?php if (file_exists('../../includes/footer.php')) include '../../includes/footer.php'; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
$conn->close();
?>
