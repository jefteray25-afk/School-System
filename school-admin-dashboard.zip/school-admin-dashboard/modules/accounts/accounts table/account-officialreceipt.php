<?php
require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();
include '../../../config/database.php';
include '../../settings/settings-permissions-roles.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/includes-receipt-helper.php';
require_once __DIR__ . '/../../../includes/receipt-payment-method-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/settings/school-info-helper.php';
require_once __DIR__ . '/../../settings/school-year-helper.php';
require_once __DIR__ . '/../../settings/settings-security.php';
ensure_receipts_registry_schema($conn);
ensure_payments_void_archive_table($conn);

$student_id = isset($_GET['student_id']) ? intval($_GET['student_id']) : 0;
$school_year_filter = trim($_GET['school_year'] ?? '');
$error = '';
$pageMessage = '';

$currentRole = $_SESSION['role'] ?? '';
$can_view = hasPermission($currentRole, 'financial', 'view');
$can_void = ($currentRole === 'Super Administrator');
if (!$can_view) {
    admin_session_forbidden();
}

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
$active_school_year_label = school_year_get_active_label($conn);

$student_name = '';
$student_grade = '';
$student_school_year = '';
if ($student_id) {
    $stud_stmt = $conn->prepare("SELECT CONCAT(lastname, ', ', firstname, ' ', middlename) AS student_name, grade, school_year_label FROM students WHERE id = ?");
    $stud_stmt->bind_param('i', $student_id);
    $stud_stmt->execute();
    $stud_stmt->bind_result($student_name, $student_grade, $student_school_year);
    if (!$stud_stmt->fetch()) {
        $error = 'Student not found.';
    }
    $stud_stmt->close();
} else {
    $error = 'Invalid student ID.';
}
$selected_school_year = $school_year_filter !== '' ? $school_year_filter : ($student_school_year ?: $active_school_year_label);
ensure_csrf_token();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['void_receipt_submit'])) {
    admin_require_post_csrf();
    if (!$can_void) {
        $error = 'Only Super Administrators can void finance receipts.';
    } else {
        $receiptNo = (int) ($_POST['receipt_no'] ?? 0);
        $bookletNo = (int) ($_POST['booklet_no'] ?? 0);
        $voidReason = trim((string) ($_POST['void_reason'] ?? ''));
        $confirmPhrase = trim((string) ($_POST['void_confirm_phrase'] ?? ''));
        $voidedBy = (int) ($_SESSION['user_id'] ?? 0);

        if ($receiptNo <= 0 || $bookletNo <= 0) {
            $error = 'Receipt number and booklet number are required.';
        } elseif ($voidReason === '') {
            $error = 'Void reason is required.';
        } elseif ($confirmPhrase !== 'VOID') {
            $error = 'Type VOID to confirm receipt correction.';
        } elseif (void_receipt($conn, $receiptNo, $voidReason, $voidedBy, $bookletNo)) {
            $pageMessage = 'Receipt ' . booklet_label_from_stored($bookletNo) . ' / ' . number_format($receiptNo) . ' was voided successfully. The payment was reversed and audit history was recorded.';
            include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';
            $user = $_SESSION['username'] ?? 'unknown';
            audit_log(
                $conn,
                $user,
                'Voided finance receipt',
                'Payments',
                'Role: ' . ($currentRole ?: 'unknown')
                . ' | Student ID: ' . $student_id
                . ' | Student Name: ' . ($student_name ?: 'Unknown')
                . ' | Booklet: ' . booklet_label_from_stored($bookletNo)
                . ' | Receipt No: ' . $receiptNo
                . ' | Reason: ' . $voidReason
            );
        } else {
            $error = 'Receipt could not be voided. It may already be voided or no longer be available for correction.';
        }
    }
}

$or_filter_date = $_GET['or_filter_date'] ?? '';
$or_filter_booklet = isset($_GET['or_filter_booklet']) ? intval($_GET['or_filter_booklet']) : 0;
$or_filter_receipt = isset($_GET['or_filter_receipt']) ? intval($_GET['or_filter_receipt']) : 0;
$or_sort = $_GET['or_sort'] ?? '';
$or_sort_sql = 'ORDER BY p.date_paid DESC';
$voided_sort_sql = 'ORDER BY pv.date_paid DESC';
if ($or_sort === 'receipt_asc') {
    $or_sort_sql = 'ORDER BY p.receipt_no ASC';
    $voided_sort_sql = 'ORDER BY pv.receipt_no ASC';
} elseif ($or_sort === 'receipt_desc') {
    $or_sort_sql = 'ORDER BY p.receipt_no DESC';
    $voided_sort_sql = 'ORDER BY pv.receipt_no DESC';
} elseif ($or_sort === 'fee_asc') {
    $or_sort_sql = 'ORDER BY a.type ASC';
    $voided_sort_sql = 'ORDER BY a.type ASC';
} elseif ($or_sort === 'fee_desc') {
    $or_sort_sql = 'ORDER BY a.type DESC';
    $voided_sort_sql = 'ORDER BY a.type DESC';
}

$or_filter_sql = "a.student_id = ? AND p.booklet_no IS NOT NULL AND p.receipt_no IS NOT NULL";
$or_filter_params = [$student_id];
$or_types = 'i';
if ($selected_school_year !== '') {
    $or_filter_sql .= " AND COALESCE(NULLIF(TRIM(p.school_year_label), ''), ?) = ?";
    $or_filter_params[] = $selected_school_year;
    $or_filter_params[] = $selected_school_year;
    $or_types .= 'ss';
}
if ($or_filter_date) {
    $or_filter_sql .= " AND DATE(p.date_paid) = ?";
    $or_filter_params[] = $or_filter_date;
    $or_types .= 's';
}
if ($or_filter_booklet) {
    $booklet_filter_values = booklet_filter_storage_values($or_filter_booklet);
    if (count($booklet_filter_values) === 2) {
        $or_filter_sql .= " AND p.booklet_no IN (?, ?)";
        $or_filter_params[] = $booklet_filter_values[0];
        $or_filter_params[] = $booklet_filter_values[1];
        $or_types .= 'ii';
    } else {
        $or_filter_sql .= " AND p.booklet_no = ?";
        $or_filter_params[] = $booklet_filter_values[0];
        $or_types .= 'i';
    }
}
if ($or_filter_receipt) {
    $or_filter_sql .= " AND p.receipt_no = ?";
    $or_filter_params[] = $or_filter_receipt;
    $or_types .= 'i';
}

$orsql = "SELECT p.date_paid, p.booklet_no, p.receipt_no, a.type AS fee_type, p.amount,
                 r.voided, r.void_reason, r.voided_at, p.receipt_note, 'active' AS receipt_state
          FROM payments p
          LEFT JOIN accounts a ON p.account_id = a.id
          INNER JOIN receipts_registry r
            ON r.receipt_no = p.receipt_no
            AND r.booklet_no = p.booklet_no
            AND r.voided = 0
            AND r.used_by IN ('payments', 'other_payment')
          WHERE $or_filter_sql
          $or_sort_sql";
$orstmt = $conn->prepare($orsql);
$orstmt->bind_param($or_types, ...$or_filter_params);
$orstmt->execute();
$orres = $orstmt->get_result();

$groupedReceipts = [];
if ($orres && $orres->num_rows > 0) {
    while ($orrow = $orres->fetch_assoc()) {
        $bookletNo = $orrow['booklet_no'] ?? '';
        $receiptNo = $orrow['receipt_no'] ?? '';
        $groupKey = $bookletNo . '-' . $receiptNo;
        if (!isset($groupedReceipts[$groupKey])) {
            $methodBreakdown = receipt_payment_methods_for_display(
                $conn,
                (int) ($bookletNo ?: 0),
                (int) ($receiptNo ?: 0),
                null,
                (string) ($orrow['receipt_note'] ?? '')
            );
            $groupedReceipts[$groupKey] = [
                'date_paid' => $orrow['date_paid'],
                'booklet_no' => $bookletNo,
                'receipt_no' => $receiptNo,
                'voided' => $orrow['voided'],
                'void_reason' => $orrow['void_reason'] ?? '',
                'voided_at' => $orrow['voided_at'] ?? '',
                'receipt_note' => $orrow['receipt_note'] ?? '',
                'method_label' => receipt_payment_methods_display_label($methodBreakdown, (string) ($orrow['receipt_note'] ?? '')),
                'method_breakdown_text' => receipt_payment_methods_summary_text($methodBreakdown),
                'receipt_state' => $orrow['receipt_state'] ?? 'active',
                'total' => 0.0,
                'items' => [],
            ];
        }
        $groupedReceipts[$groupKey]['total'] += (float) $orrow['amount'];
        $groupedReceipts[$groupKey]['items'][] = [
            'fee_type' => $orrow['fee_type'] ?? '',
            'amount' => (float) $orrow['amount'],
        ];
    }
}
$orstmt->close();

$voidedFilterSql = "a.student_id = ?";
$voidedFilterParams = [$student_id];
$voidedTypes = 'i';
if ($selected_school_year !== '') {
    $voidedFilterSql .= " AND COALESCE(NULLIF(TRIM(pv.school_year_label), ''), ?) = ?";
    $voidedFilterParams[] = $selected_school_year;
    $voidedFilterParams[] = $selected_school_year;
    $voidedTypes .= 'ss';
}
if ($or_filter_date) {
    $voidedFilterSql .= " AND DATE(pv.date_paid) = ?";
    $voidedFilterParams[] = $or_filter_date;
    $voidedTypes .= 's';
}
if ($or_filter_booklet) {
    $booklet_filter_values = booklet_filter_storage_values($or_filter_booklet);
    if (count($booklet_filter_values) === 2) {
        $voidedFilterSql .= " AND pv.booklet_no IN (?, ?)";
        $voidedFilterParams[] = $booklet_filter_values[0];
        $voidedFilterParams[] = $booklet_filter_values[1];
        $voidedTypes .= 'ii';
    } else {
        $voidedFilterSql .= " AND pv.booklet_no = ?";
        $voidedFilterParams[] = $booklet_filter_values[0];
        $voidedTypes .= 'i';
    }
}
if ($or_filter_receipt) {
    $voidedFilterSql .= " AND pv.receipt_no = ?";
    $voidedFilterParams[] = $or_filter_receipt;
    $voidedTypes .= 'i';
}

$voidedSql = "SELECT pv.date_paid, pv.booklet_no, pv.receipt_no, a.type AS fee_type, pv.amount,
                     1 AS voided, pv.void_reason, pv.voided_at, pv.receipt_note, 'voided' AS receipt_state
              FROM payments_voided pv
              LEFT JOIN accounts a ON pv.account_id = a.id
              WHERE {$voidedFilterSql}
              {$voided_sort_sql}";
$voidedStmt = $conn->prepare($voidedSql);
if ($voidedStmt) {
    $voidedStmt->bind_param($voidedTypes, ...$voidedFilterParams);
    $voidedStmt->execute();
    $voidedRes = $voidedStmt->get_result();
    while ($voidedRow = $voidedRes->fetch_assoc()) {
        $bookletNo = $voidedRow['booklet_no'] ?? '';
        $receiptNo = $voidedRow['receipt_no'] ?? '';
        $voidedAtKey = preg_replace('/[^0-9]/', '', (string) ($voidedRow['voided_at'] ?? ''));
        $groupKey = 'voided-' . $bookletNo . '-' . $receiptNo . '-' . $voidedAtKey . '-' . md5((string) ($voidedRow['void_reason'] ?? ''));
        if (!isset($groupedReceipts[$groupKey])) {
            $voidedReceiptNote = trim((string) ($voidedRow['receipt_note'] ?? ''));
            $groupedReceipts[$groupKey] = [
                'date_paid' => $voidedRow['date_paid'],
                'booklet_no' => $bookletNo,
                'receipt_no' => $receiptNo,
                'voided' => 1,
                'void_reason' => $voidedRow['void_reason'] ?? '',
                'voided_at' => $voidedRow['voided_at'] ?? '',
                'receipt_note' => $voidedReceiptNote,
                'method_label' => $voidedReceiptNote !== '' ? $voidedReceiptNote : 'Archived Payment',
                'method_breakdown_text' => '',
                'method_breakdown_total' => 0.0,
                'receipt_state' => 'voided',
                'total' => 0.0,
                'items' => [],
            ];
        }
        $groupedReceipts[$groupKey]['total'] += (float) ($voidedRow['amount'] ?? 0);
        $groupedReceipts[$groupKey]['items'][] = [
            'fee_type' => $voidedRow['fee_type'] ?? '',
            'amount' => (float) ($voidedRow['amount'] ?? 0),
        ];
    }
    $voidedStmt->close();
}
foreach ($groupedReceipts as &$receiptGroup) {
    if (!empty($receiptGroup['voided'])) {
        $receiptGroup['method_breakdown_total'] = (float) ($receiptGroup['total'] ?? 0);
        if (($receiptGroup['method_breakdown_text'] ?? '') === '') {
            $receiptGroup['method_breakdown_text'] = ($receiptGroup['method_label'] ?? 'Archived Payment')
                . ': PHP ' . number_format((float) ($receiptGroup['total'] ?? 0), 2);
        }
    }
    $methodBreakdownTotal = (float) ($receiptGroup['method_breakdown_total'] ?? 0);
    $receiptGroup['has_total_mismatch'] = $methodBreakdownTotal > 0
        && abs((float) ($receiptGroup['total'] ?? 0) - $methodBreakdownTotal) > 0.009;
}
unset($receiptGroup);
$groupedReceipts = array_values($groupedReceipts);
usort($groupedReceipts, static function (array $left, array $right): int {
    return strcmp((string) ($right['date_paid'] ?? ''), (string) ($left['date_paid'] ?? ''));
});
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Receipts Desk | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --page-bg: #eef3f9;
            --card-bg: #ffffff;
            --card-border: #d9e3ef;
            --brand-dark: #23395d;
            --brand-mid: #517fa4;
            --brand-soft: #edf4fb;
            --text-soft: #5f7186;
            --success-soft: #e7f6ee;
            --warning-soft: #fff4d8;
            --danger-soft: #fdecec;
        }
        body {
            background:
                radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 30%),
                linear-gradient(180deg, #f8fbff 0%, var(--page-bg) 100%);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
            color: var(--brand-dark);
        }
        .toolbar-card,
        .panel-card {
            border: 1px solid var(--card-border);
            border-radius: 20px;
            background: var(--card-bg);
            box-shadow: 0 14px 32px rgba(35,57,93,0.07);
        }
        .toolbar-card {
            padding: 16px 18px;
            margin-bottom: 16px;
        }
        .toolbar-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 12px;
            flex-wrap: wrap;
            margin-bottom: 1rem;
        }
        .toolbar-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .section-title {
            margin: 0;
            font-size: 1.15rem;
            font-weight: 800;
            color: var(--brand-dark);
        }
        .section-caption {
            color: var(--text-soft);
            margin-top: 6px;
            margin-bottom: 0;
        }
        .btn-primary-soft {
            background: var(--brand-dark);
            border-color: var(--brand-dark);
            color: #fff;
            font-weight: 600;
        }
        .btn-primary-soft:hover {
            background: #1d2f4a;
            border-color: #1d2f4a;
            color: #fff;
        }
        .btn-secondary-soft {
            background: #eef3f8;
            border-color: #d7e1ed;
            color: var(--brand-dark);
            font-weight: 600;
        }
        .btn-secondary-soft:hover {
            background: #e1eaf4;
            border-color: #c8d5e4;
            color: var(--brand-dark);
        }
        .panel-card .card-header {
            background: linear-gradient(135deg, var(--brand-dark), var(--brand-mid));
            color: #fff;
            font-weight: 700;
            border: 0;
            padding: 14px 18px;
            border-radius: 20px 20px 0 0;
        }
        .table {
            margin-bottom: 0;
        }
        .table thead th {
            background: var(--brand-soft);
            color: var(--brand-dark);
            border-bottom: 1px solid var(--card-border);
            font-size: 0.92rem;
            font-weight: 700;
        }
        .table td, .table th {
            padding: 0.9rem 0.85rem;
            vertical-align: middle;
        }
        .table tbody tr:hover {
            background: transparent;
        }
        .collapse .table-sm td,
        .collapse .table-sm th {
            padding: 0.4rem 0.6rem;
        }
        .receipt-chip,
        .amount-chip,
        .status-pill {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 999px;
            padding: 6px 12px;
            font-weight: 700;
        }
        .receipt-chip,
        .amount-chip {
            background: var(--brand-soft);
            color: var(--brand-dark);
        }
        .status-valid {
            background: var(--success-soft);
            color: #18794e;
        }
        .status-voided {
            background: var(--warning-soft);
            color: #9a6a00;
        }
        .voided-meta {
            display: block;
            font-size: 0.8rem;
            color: var(--text-soft);
            margin-top: 6px;
        }
        .empty-state {
            color: var(--text-soft);
            padding: 28px 12px;
            font-weight: 600;
        }
    </style>
</head>
<body>
<div id="page-content-wrapper" class="w-100">
    <div class="mt-2">
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php else: ?>
            <?php if ($pageMessage !== ''): ?><div class="alert alert-success"><?= htmlspecialchars($pageMessage) ?></div><?php endif; ?>
            <div class="toolbar-card">
                <div class="toolbar-row">
                    <div>
                        <h3 class="section-title"><i class="fas fa-file-invoice-dollar me-2"></i>Receipts Desk</h3>
                        <p class="section-caption">Review posted receipts, print active entries, and trace voided corrections.</p>
                    </div>
                    <div class="toolbar-actions">
                        <a href="../account-view.php?student_id=<?= $student_id ?>&school_year=<?= urlencode($selected_school_year) ?>" class="btn btn-secondary-soft">
                            <i class="fas fa-arrow-left"></i> Back to Finance Profile
                        </a>
                        <a href="account-paymentrecords.php?student_id=<?= $student_id ?>&school_year=<?= urlencode($selected_school_year) ?>" class="btn btn-secondary-soft">
                            <i class="fas fa-history"></i> Open Payment Desk
                        </a>
                    </div>
                </div>
                <form method="get" class="row g-2" id="receiptFilterForm" autocomplete="off">
                    <input type="hidden" name="student_id" value="<?= $student_id ?>">
                    <div class="col-sm-4 col-md-3">
                        <input type="date" name="or_filter_date" value="<?= htmlspecialchars($or_filter_date) ?>" class="form-control" placeholder="Filter Date">
                    </div>
                    <div class="col-sm-4 col-md-3">
                        <select name="or_filter_booklet" class="form-select">
                            <option value="">Booklet No</option>
                            <?php for ($b = SPECIAL_BOOKLET_MIN; $b <= SPECIAL_BOOKLET_MAX; $b++): ?>
                                <?php $stored_special = booklet_display_to_storage_number($b, true); ?>
                                <option value="<?= $stored_special ?>" <?= $or_filter_booklet == $stored_special ? 'selected' : '' ?>>S<?= $b ?></option>
                            <?php endfor; ?>
                            <?php for ($b = REGULAR_BOOKLET_MIN; $b <= REGULAR_BOOKLET_MAX; $b++): ?>
                                <option value="<?= $b ?>" <?= $or_filter_booklet == $b ? 'selected' : '' ?>><?= $b ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="col-sm-4 col-md-3">
                        <select name="or_sort" class="form-select">
                            <option value="">Sort by Receipt No</option>
                            <option value="receipt_asc" <?= $or_sort === 'receipt_asc' ? 'selected' : '' ?>>Receipt No Ascending</option>
                            <option value="receipt_desc" <?= $or_sort === 'receipt_desc' ? 'selected' : '' ?>>Receipt No Descending</option>
                        </select>
                    </div>
                    <div class="col-auto">
                        <button type="submit" class="btn btn-primary-soft"><i class="fas fa-filter"></i> Filter</button>
                        <button type="button" class="btn btn-secondary-soft" id="resetReceiptBtn">Clear Filters</button>
                    </div>
                </form>
            </div>
            <div class="card panel-card mb-4" id="receipts">
                <div class="card-header">
                    <i class="fas fa-file-invoice-dollar"></i> Receipt Records
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Booklet No</th>
                                    <th>Receipt No</th>
                                    <th>Fee Type</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Payment Method</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($groupedReceipts)): ?>
                                    <?php $rowIndex = 0; ?>
                                    <?php foreach ($groupedReceipts as $receipt): ?>
                                        <?php $date = $receipt['date_paid'] ? (new DateTime($receipt['date_paid']))->format('Y-m-d') : ''; ?>
                                        <?php
                                        $rowIndex++;
                                        $collapseId = 'receipt-breakdown-' . $rowIndex;
                                        $itemsCount = count($receipt['items'] ?? []);
                                        ?>
                                        <tr>
                                            <td><?= htmlspecialchars($date) ?></td>
                                            <td><span class="receipt-chip"><?= htmlspecialchars(booklet_label_from_stored((int) $receipt['booklet_no'])) ?></span></td>
                                            <td><span class="receipt-chip"><?= htmlspecialchars($receipt['receipt_no']) ?></span></td>
                                            <td>
                                                <?php if ($itemsCount > 1): ?>
                                                    <div class="d-flex align-items-center justify-content-between gap-2">
                                                        <span><?= $itemsCount ?> items</span>
                                                        <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="collapse" data-bs-target="#<?= $collapseId ?>" aria-expanded="false" aria-controls="<?= $collapseId ?>">
                                                            View breakdown
                                                        </button>
                                                    </div>
                                                <?php else: ?>
                                                    <?= htmlspecialchars($receipt['items'][0]['fee_type'] ?? '') ?>
                                                <?php endif; ?>
                                            </td>
                                            <td><span class="amount-chip">&#8369;<?= number_format($receipt['total'], 2) ?></span></td>
                                            <td>
                                                <?php if ($receipt['voided']): ?>
                                                    <span class="status-pill status-voided">Voided</span>
                                                    <small class="voided-meta">Reason: <?= htmlspecialchars($receipt['void_reason']) ?></small>
                                                    <small class="voided-meta">Date: <?= htmlspecialchars($receipt['voided_at']) ?></small>
                                                <?php else: ?>
                                                    <span class="status-pill status-valid">Valid</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?= htmlspecialchars((string) ($receipt['method_label'] ?? '')) ?>
                                                <?php if (!empty($receipt['method_breakdown_text']) && (($receipt['method_label'] ?? '') === 'Split Payment' || !empty($receipt['voided']))): ?>
                                                    <div class="small text-muted mt-1"><?= htmlspecialchars((string) $receipt['method_breakdown_text']) ?></div>
                                                <?php endif; ?>
                                                <?php if (!empty($receipt['has_total_mismatch'])): ?>
                                                    <div class="small text-danger fw-semibold mt-1">Mismatch: fee rows total PHP <?= number_format((float) $receipt['total'], 2) ?> but payment method total PHP <?= number_format((float) ($receipt['method_breakdown_total'] ?? 0), 2) ?>.</div>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if (!$receipt['voided']): ?>
                                                    <a href="account-print.php?receipt_no=<?= (int) $receipt['receipt_no'] ?>&booklet_no=<?= (int) $receipt['booklet_no'] ?>"
                                                       class="btn btn-secondary-soft btn-sm"
                                                       target="_blank"
                                                       title="Print Receipt">
                                                        <i class="fas fa-print"></i> Print Receipt
                                                    </a>
                                                    <a href="account-pdf.php?receipt_no=<?= (int) $receipt['receipt_no'] ?>&booklet_no=<?= (int) $receipt['booklet_no'] ?>"
                                                       class="btn btn-secondary-soft btn-sm"
                                                       title="Download Receipt Image">
                                                        <i class="fas fa-image"></i> Download Receipt Image
                                                    </a>
                                                <?php else: ?>
                                                    <span class="text-muted small fw-semibold">Voided receipt archived</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php if ($itemsCount > 1): ?>
                                            <tr class="collapse" id="<?= $collapseId ?>">
                                                <td colspan="8" class="bg-light">
                                                    <div class="p-2">
                                                        <div class="fw-semibold mb-2">Receipt Breakdown</div>
                                                        <div class="table-responsive">
                                                            <table class="table table-sm mb-0">
                                                                <thead>
                                                                    <tr><th>Fee Type</th><th class="text-end">Amount</th></tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php foreach ($receipt['items'] as $item): ?>
                                                                        <tr>
                                                                            <td><?= htmlspecialchars($item['fee_type']) ?></td>
                                                                            <td class="text-end">&#8369;<?= number_format($item['amount'], 2) ?></td>
                                                                        </tr>
                                                                    <?php endforeach; ?>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="8" class="text-center empty-state">No receipt records matched the current filters.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <?php if (file_exists('../../includes/footer.php')) include '../../includes/footer.php'; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('resetReceiptBtn')?.addEventListener('click', function () {
    const url = new URL(window.location.href);
    url.searchParams.delete('or_filter_date');
    url.searchParams.delete('or_filter_booklet');
    url.searchParams.delete('or_filter_receipt');
    url.searchParams.delete('or_sort');
    window.location.href = url.toString();
});
</script>
</body>
</html>
<?php
$conn->close();
?>
