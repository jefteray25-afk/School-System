<?php
require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../settings/settings-permissions-roles.php';

$role = $_SESSION['role'] ?? '';
if (!hasPermission($role, 'financial', 'view')) {
    admin_session_forbidden();
}

$receiptNo = isset($_GET['receipt_no']) ? (int) $_GET['receipt_no'] : 0;
$bookletNo = isset($_GET['booklet_no']) ? (int) $_GET['booklet_no'] : 0;

if ($receiptNo <= 0) {
    die('Invalid receipt number.');
}

$target = '/school-admin-dashboard/modules/accounts/accounts%20table/account-print.php?receipt_no=' . urlencode((string) $receiptNo);
if ($bookletNo > 0) {
    $target .= '&booklet_no=' . urlencode((string) $bookletNo);
}
$target .= '&download_image=1';

header('Location: ' . $target);
exit;
?>
