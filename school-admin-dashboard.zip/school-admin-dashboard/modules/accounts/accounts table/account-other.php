<?php
require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();
include '../../../config/database.php';
require_once __DIR__ . '/../../../includes/payment-collision-helper.php';
include '../../settings/settings-permissions-roles.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/includes-receipt-helper.php';
require_once __DIR__ . '/../../../includes/receipt-payment-method-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';
require_once __DIR__ . '/../../settings/school-year-helper.php';
require_once __DIR__ . '/../../settings/settings-security.php';

$conn->set_charset('utf8mb4');
ensure_payments_prepared_by_column($conn);
ensure_payments_reference_note_columns($conn);
ensure_receipt_payment_methods_table($conn);

function payments_has_reference_note_columns(mysqli $conn): bool
{
    $result = $conn->query("SHOW COLUMNS FROM payments LIKE 'reference_number'");
    $hasRef = $result && $result->num_rows > 0;
    if ($result) {
        $result->close();
    }
    $result2 = $conn->query("SHOW COLUMNS FROM payments LIKE 'payment_note'");
    $hasNote = $result2 && $result2->num_rows > 0;
    if ($result2) {
        $result2->close();
    }
    return $hasRef && $hasNote;
}
$currentRole = $_SESSION['role'] ?? '';
$can_add = hasPermission($currentRole, 'financial', 'add');
if (!$can_add) {
    $blockedUser = $_SESSION['username'] ?? 'unknown';
    audit_log(
        $conn,
        $blockedUser,
        'Blocked account other payment access',
        'Accounts',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing financial:add permission',
        'SECURITY'
    );
    admin_session_forbidden();
}

$student_id = isset($_GET['student_id']) ? intval($_GET['student_id']) : 0;
if (!$student_id) die('Invalid student ID.');
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
$requested_school_year = trim($_GET['school_year'] ?? '');
$active_school_year_label = school_year_get_active_label($conn);

$stmt = $conn->prepare("SELECT CONCAT(lastname, ', ', firstname, ' ', middlename) AS student_name, grade, school_year_label FROM students WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$stmt->bind_result($student_name, $student_grade, $student_school_year);
if (!$stmt->fetch()) die("Student not found.");
$stmt->close();
$selected_school_year = $requested_school_year !== '' ? $requested_school_year : (trim((string) $student_school_year) !== '' ? trim((string) $student_school_year) : $active_school_year_label);

// Special receipt booklets now read from the managed booklet registry.
$special_booklet_rows = receipt_booklet_registry_payment_rows($conn, 'special', true);
$special_booklet_map = [];
$special_booklet_usage = receipt_booklet_usage_map($conn, $special_booklet_rows);
$used_receipts_by_booklet = [];
$next_available_receipt_by_booklet = [];
foreach ($special_booklet_rows as $booklet_row) {
    $stored_booklet = (int) $booklet_row['storage_number'];
    $usage_row = $special_booklet_usage[$stored_booklet] ?? ['used' => [], 'next' => null];
    $used_receipts_by_booklet[$stored_booklet] = $usage_row['used'];
    $next_available_receipt_by_booklet[$stored_booklet] = $usage_row['next'];
    $special_booklet_map[$stored_booklet] = [
        'booklet_code' => (string) $booklet_row['booklet_code'],
        'range_start' => (int) $booklet_row['range_start'],
        'range_end' => (int) $booklet_row['range_end'],
    ];
}

$error = $success = "";
$payment_balance_snapshot_token = payment_collision_token(active_payment_balance_snapshot($conn, $student_id, $selected_school_year));
ensure_csrf_token();

// Payment handler for multiple "other" payments
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_require_post_csrf();
    $submittedBalanceToken = trim((string) ($_POST['payment_balance_snapshot_token'] ?? ''));
    $date_paid = $_POST['date_paid'] ?? date('Y-m-d');
    $time_paid = $_POST['time_paid'] ?? date('H:i');
    $booklet_no = intval($_POST['booklet_no'] ?? 0);
    $receipt_no = $_POST['receipt_no'] ?? '';
    $fees = $_POST['fees'] ?? [];
    $payment_note_input = trim((string) ($_POST['payment_note'] ?? ''));
    $payment_methods = receipt_payment_methods_normalize($_POST['payment_methods'] ?? []);
    $expected_payment_total = 0.0;
    foreach ($fees as $fee) {
        $expected_payment_total += (float) str_replace(',', '', (string) ($fee['amount'] ?? '0'));
    }
    $expected_payment_total = round($expected_payment_total, 2);
    $legacyMethodSummary = receipt_payment_methods_build_legacy_summary($payment_methods, $payment_note_input);
    $receipt_method_label = $legacyMethodSummary['method_label'];
    $reference_summary = $legacyMethodSummary['reference_summary'];
    $payment_note_summary = $legacyMethodSummary['note_summary'];

    [$display_booklet_no, $is_special_booklet] = booklet_storage_to_display_parts($booklet_no);
    $valid_booklet = $is_special_booklet && $display_booklet_no >= SPECIAL_BOOKLET_MIN && $display_booklet_no <= SPECIAL_BOOKLET_MAX;
    [$start_receipt, $end_receipt] = receipt_window_for_booklet($booklet_no);
    $valid_receipt = (is_numeric($receipt_no) && $receipt_no >= $start_receipt && $receipt_no <= $end_receipt);

    $receipt_entry = null;
    if ($valid_booklet && $valid_receipt) {
        $receipt_entry = get_receipt_registry_entry($conn, (int) $receipt_no, $booklet_no);
    }
    $receipt_used = $receipt_entry && (int) $receipt_entry['voided'] === 0;
    $receipt_reusable = $receipt_entry && (int) $receipt_entry['voided'] === 1;

    // Validate at least one fee entered
    $has_valid_fee = false;
    $error_fee = '';
    foreach ($fees as $fee) {
        if (
            isset($fee['amount']) && floatval($fee['amount']) > 0 &&
            isset($fee['note']) && trim($fee['note']) !== ''
        ) {
            $has_valid_fee = true;
        } else {
            $error_fee = "Each Other Payment row needs a purpose and amount greater than zero.";
            break;
        }
    }

    $max_special_receipt = receipt_window_for_booklet(booklet_display_to_storage_number(SPECIAL_BOOKLET_MAX, true))[1];
    if ($submittedBalanceToken === '') {
        $error = "This payment form is missing collision protection data. Please refresh and try again.";
    } elseif (!hash_equals(payment_collision_token(active_payment_balance_snapshot($conn, $student_id, $selected_school_year)), $submittedBalanceToken)) {
        $error = "This student's account balances changed while you were preparing the other payment. Refresh the page first so you don't save against stale account data.";
    } elseif ($receipt_no !== null && ($receipt_no < SPECIAL_RECEIPT_START || $receipt_no > $max_special_receipt)) {
        $error = "Receipt No. must be between " . SPECIAL_RECEIPT_START . " and " . $max_special_receipt . ".";
    } elseif ($receipt_used) {
        $error = "Receipt No. $receipt_no is already used.";
    } elseif (!receipt_payment_methods_validate($payment_methods, $expected_payment_total, $error)) {
        // Validation message populated by helper.
    } elseif (!$has_valid_fee) {
        $error = $error_fee ?: "Please enter at least one valid Other Payment.";
    } else {
        $conn->begin_transaction();
        $reserve = reserve_or_reuse_receipt(
            $conn,
            (int) $receipt_no,
            $booklet_no,
            'other_payment',
            $receipt_reusable ? 'Reused for corrected other payment entry' : null
        );
        if (!$reserve['success']) {
            $conn->rollback();
            $error = $reserve['message'] ?: 'Failed to reserve receipt.';
        }
        if (!$error && !receipt_payment_methods_replace_for_receipt($conn, $booklet_no, (int) $receipt_no, 'other_payment', $payment_methods)) {
            $conn->rollback();
            $error = receipt_payment_methods_last_error() !== ''
                ? receipt_payment_methods_last_error()
                : 'Failed to save payment method breakdown.';
        }

        $success_payments = 0;
        $first_payment_id = null;
        $other_payment_ids = [];
        // Find or create the "Other" account for this student
        $account_id = null;
        $account_stmt = $conn->prepare("SELECT id FROM accounts WHERE student_id = ? AND type = 'Other' AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ? LIMIT 1");
        $account_stmt->bind_param("iss", $student_id, $selected_school_year, $selected_school_year);
        $account_stmt->execute();
        $account_stmt->bind_result($account_id);
        $account_stmt->fetch();
        $account_stmt->close();
        if (!$account_id) {
            $create_stmt = $conn->prepare("INSERT INTO accounts (student_id, name, type, balance, school_year_label) VALUES (?, ?, 'Other', 0, ?)");
            $create_stmt->bind_param("iss", $student_id, $student_name, $selected_school_year);
            $create_stmt->execute();
            $account_id = $create_stmt->insert_id;
            $create_stmt->close();
        }
        foreach ($fees as $fee) {
            if (!empty($error)) {
                break;
            }
            $amount = floatval($fee['amount']);
            $note = trim($fee['note']);
            $remarks = "Other - " . $note;
            $prepared_by = trim((string) ($_SESSION['username'] ?? 'System'));
            $datetime_paid = $date_paid . ' ' . $time_paid . ':00';

            // 1. Insert into payments
            $hasStructuredNote = payments_has_reference_note_columns($conn);
            if ($hasStructuredNote) {
                $sql = "INSERT INTO payments (account_id, amount, date_paid, remarks, receipt_note, reference_number, payment_note, prepared_by, booklet_no, receipt_no, school_year_label)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                if (!$stmt) {
                    $error = "Failed to prepare other payment insert (structured).";
                    break;
                }
                $stmt->bind_param("idssssssiis", $account_id, $amount, $datetime_paid, $remarks, $receipt_method_label, $reference_summary, $payment_note_summary, $prepared_by, $booklet_no, $receipt_no, $selected_school_year);
            } else {
                $fallbackRemarks = $remarks;
                if ($payment_note_summary !== '') {
                    $fallbackRemarks .= " (Note: " . htmlspecialchars($payment_note_summary) . ")";
                }
                $sql = "INSERT INTO payments (account_id, amount, date_paid, remarks, receipt_note, prepared_by, booklet_no, receipt_no, school_year_label)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                if (!$stmt) {
                    $error = "Failed to prepare other payment insert (legacy).";
                    break;
                }
                $stmt->bind_param("idssssiis", $account_id, $amount, $datetime_paid, $fallbackRemarks, $receipt_method_label, $prepared_by, $booklet_no, $receipt_no, $selected_school_year);
            }

            if ($stmt->execute()) {
                $new_payment_id = $stmt->insert_id;

                // 2. Insert into other_payments
                $other_stmt = $conn->prepare("INSERT INTO other_payments (payment_id, student_id, note, amount, date_paid) VALUES (?, ?, ?, ?, ?)");
                $other_stmt->bind_param("iisds", $new_payment_id, $student_id, $note, $amount, $datetime_paid);
                $other_stmt->execute();
                $other_stmt->close();

                $other_payment_ids[] = $new_payment_id;
                if ($success_payments === 0) {
                    attach_receipt_to_payment($conn, (int) $receipt_no, $new_payment_id, $booklet_no);
                    $first_payment_id = $new_payment_id;
                }
                $success_payments++;
            } else {
                $error = "Failed to save other payment row: " . $stmt->error;
                break;
            }
            $stmt->close();
        }

        if ($success_payments > 0) {
            // Audit
            include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');
            $user = $_SESSION['username'] ?? 'unknown';
            $action = "Added other payment(s)";
            $module = "OtherPayments";
            $details = "Role: " . ($_SESSION['role'] ?? 'unknown') .
                " | Student ID: " . $student_id .
                " | Student Name: " . ($student_name ?? 'unknown') .
                " | SchoolYear: " . $selected_school_year .
                " | Booklet No: " . booklet_label_from_stored($booklet_no) .
                " | Receipt No: $receipt_no | Paid by: $user | DatePaid: $date_paid $time_paid" .
                " | PaymentType: " . $receipt_method_label .
                " | MethodBreakdown: " . receipt_payment_methods_summary_text($payment_methods) .
                ($payment_note_summary === '' ? '' : " | Note: " . $payment_note_summary) .
                " | Details: " . json_encode($fees);
            audit_log($conn, $user, $action, $module, $details);

            $conn->commit();
            $success = "Other payment(s) successfully added.";
            header("Location: account-payment-history.php?student_id=" . $student_id . "&school_year=" . urlencode($selected_school_year));
            exit;
        } else {
            $conn->rollback();
            if ($error === '') {
                $error = "Failed to add payment.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Desk - Other Payment | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script>
        var usedReceiptsByBooklet = <?= json_encode($used_receipts_by_booklet) ?>;
        var nextAvailableReceiptByBooklet = <?= json_encode($next_available_receipt_by_booklet) ?>;
        var bookletCatalogByStorage = <?= json_encode($special_booklet_map) ?>;
    </script>
    <style>
        body { background: #f5f8fc; font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif; }
        .main-card { background: #fff; border-radius: 1rem; box-shadow: 0 4px 18px rgba(33,57,93,0.09), 0 1.5px 3px rgba(33,57,93,0.07); margin: 0 auto; margin-top: 48px; padding:2.2rem 2.5rem 2.3rem; max-width:1030px; }
        .section-title { font-size: 1.23rem; font-weight: 700; color: #0d6efd; margin-bottom: 1.1rem; letter-spacing: 0.04em; }
        .form-label { font-weight: 500; }
        .student-details { font-size: 0.97rem; margin-bottom: .35rem; color: #555; }
        .total-payment-row { font-size: 1.1em; color: #0d6efd; text-align: right; margin-bottom: 1em; }
        .fee-row { margin-bottom: 10px; }
    </style>
</head>
<body>
<div class="container main-card px-3">
    <div class="section-title">
        <i class="fas fa-plus-circle"></i> Payment Desk - Other Payment
    </div>
    <div class="student-details mb-2">
        <strong>Student:</strong>
        <span><?= htmlspecialchars($student_name) ?></span><br>
        <strong>Grade:</strong> <?= htmlspecialchars($student_grade) ?>
    </div>
    <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

    <form method="post" id="addOtherPaymentForm" autocomplete="off">
      <?= csrf_input() ?>
      <input type="hidden" name="payment_balance_snapshot_token" value="<?= htmlspecialchars($payment_balance_snapshot_token) ?>">
      <div id="feeRows"></div>
        <button type="button" class="btn btn-outline-primary mb-3" onclick="addOtherFeeRow()">+ Add Another</button>
        <div class="total-payment-row">
            <strong>Total Payment:</strong> <span id="totalPayment">₱0.00</span>
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">Date Paid</label>
            <input type="date" name="date_paid" id="datePaidField" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">Time Paid</label>
            <input type="time" name="time_paid" id="timePaidField" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">Booklet No</label>
            <select name="booklet_no" id="bookletNoField" class="form-select" required>
                <option value="">Select Booklet No</option>
                <?php foreach ($special_booklet_rows as $booklet_row): ?>
                    <option value="<?= (int) $booklet_row['storage_number'] ?>"><?= htmlspecialchars((string) $booklet_row['booklet_code']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">Receipt No</label>
            <select name="receipt_no" id="receiptNoField" class="form-select" required>
                <option value="">Select Receipt No</option>
            </select>
            <div class="form-text" id="receiptNoRange"></div>
        </div>
        <div class="mb-3">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <label class="form-label fw-bold mb-0">Payment Method Breakdown</label>
                <button type="button" class="btn btn-outline-primary btn-sm" id="addPaymentMethodBtn">+ Add Method</button>
            </div>
            <div id="paymentMethodRows"></div>
            <div class="form-text">Use 1 to 3 methods. The total of all method rows must match the total other payment amount.</div>
            <div class="form-text" id="paymentMethodTotalText">Payment method total: PHP 0.00</div>
            <div class="mt-2">
                <label class="form-label">Payment Note (optional)</label>
                <input type="text" name="payment_note" id="paymentNoteField" class="form-control" maxlength="255" placeholder="Optional note for this receipt">
            </div>
        </div>
        <div class="d-flex justify-content-between mt-4">
            <button type="submit" class="btn btn-primary"><i class="fas fa-plus-circle"></i> Save Other Payment</button>
            <a href="account-payment-history.php?student_id=<?= $student_id ?>" class="btn btn-secondary"><i class="fas fa-times"></i> Back to Payment Desk</a>
        </div>
    </form>
</div>

<!-- Double Check Modal -->
<div class="modal fade" id="doubleCheckModal" tabindex="-1" aria-labelledby="doubleCheckModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form id="finalPaymentForm" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="doubleCheckModalLabel"><i class="fas fa-exclamation-triangle text-warning"></i> Please Double Check</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <ul id="doubleCheckList" style="font-size:1.02em;">
          <li><strong>Other Payments:</strong> <span id="dcPaymentSummary"></span></li>
          <li><strong>Date Paid:</strong> <span id="dcDatePaid"></span></li>
          <li><strong>Time Paid:</strong> <span id="dcTimePaid"></span></li>
          <li><strong>Booklet No:</strong> <span id="dcBookletNo"></span></li>
          <li><strong>Receipt No:</strong> <span id="dcReceiptNo"></span></li>
          <li><strong>Payment Methods:</strong> <span id="dcPaymentMethods"></span></li>
          <li><strong>Payment Note:</strong> <span id="dcPaymentNote"></span></li>
        </ul>
        <div class="form-check mt-3">
          <input type="checkbox" class="form-check-input" id="doubleCheckConfirm" required>
          <label class="form-check-label" for="doubleCheckConfirm">I have double-checked the above information</label>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" id="doubleCheckEditBtn" data-bs-dismiss="modal">No, Edit Info</button>
        <button type="submit" class="btn btn-success" id="doubleCheckProceedBtn" disabled>Yes, Proceed</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
let otherFeeIdx = 0;
const paymentMethodRowsDiv = document.getElementById('paymentMethodRows');
const supportedPaymentMethods = ['Cash', 'GCash', 'Bank Transfer'];
function addOtherFeeRow() {
    const idx = otherFeeIdx++;
    const row = document.createElement('div');
    row.className = 'row fee-row align-items-center mb-2';
    row.id = 'feeRow_' + idx;
    row.innerHTML = `
        <div class="col-5">
            <input type="text" class="form-control" value="Other" readonly>
        </div>
        <div class="col-4">
            <input type="text" class="form-control" name="fees[${idx}][note]" placeholder="Purpose (e.g. Field Trip)" required>
        </div>
        <div class="col-2">
            <input type="number" class="form-control" name="fees[${idx}][amount]" placeholder="Amount" min="0.01" step="0.01" required>
        </div>
        <div class="col-1 d-flex align-items-center">
            <button type="button" class="btn btn-outline-danger btn-sm" onclick="removeOtherFeeRow(${idx})"><i class="fas fa-times"></i></button>
        </div>
    `;
    document.getElementById('feeRows').appendChild(row);
    updateTotalPayment();
}
function removeOtherFeeRow(idx) {
    const row = document.getElementById('feeRow_' + idx);
    if (row) row.remove();
    updateTotalPayment();
}
function updateTotalPayment() {
    let total = 0;
    document.querySelectorAll('#feeRows input[type="number"]').forEach(input => {
        let val = parseFloat(input.value) || 0;
        total += val;
    });
    document.getElementById('totalPayment').textContent = 'PHP ' + total.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
    updatePaymentMethodTotal();
}
document.addEventListener('input', function(e) {
    if (e.target.matches('#feeRows input[type="number"]')) {
        updateTotalPayment();
    }
});
let paymentMethodRowIdx = 0;
function getSelectedPaymentMethods() {
    return Array.from(document.querySelectorAll('.payment-method-select'))
        .map(select => String(select.value || '').trim())
        .filter(Boolean);
}
function syncPaymentMethodOptions() {
    const selected = new Set(getSelectedPaymentMethods());
    document.querySelectorAll('.payment-method-select').forEach(function(selectElement) {
        const currentValue = String(selectElement.value || '').trim();
        selectElement.querySelectorAll('option').forEach(function(option) {
            if (!option.value) {
                option.disabled = false;
                return;
            }
            option.disabled = selected.has(option.value) && option.value !== currentValue;
        });
    });
}
function togglePaymentMethodReference(rowDiv) {
    if (!rowDiv) {
        return;
    }
    const methodSelect = rowDiv.querySelector('.payment-method-select');
    const refWrap = rowDiv.querySelector('.payment-method-ref-wrap');
    const refInput = rowDiv.querySelector('.payment-method-ref');
    const needsRef = methodSelect && (methodSelect.value === 'GCash' || methodSelect.value === 'Bank Transfer');
    if (refWrap) {
        refWrap.style.display = needsRef ? '' : 'none';
    }
    if (refInput) {
        refInput.required = !!needsRef;
        if (!needsRef) {
            refInput.value = '';
        }
    }
}
function makePaymentMethodRow(idx) {
    return `
        <div class="border rounded p-2 mb-2 payment-method-row" id="paymentMethodRow_${idx}">
            <div class="row g-2 align-items-end">
                <div class="col-md-4">
                    <label class="form-label mb-1">Method</label>
                    <select class="form-select payment-method-select" name="payment_methods[${idx}][method]" required>
                        <option value="">Select Method</option>
                        <option value="Cash">Cash</option>
                        <option value="GCash">GCash</option>
                        <option value="Bank Transfer">Bank Transfer</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label mb-1">Amount</label>
                    <input type="number" class="form-control payment-method-amount" name="payment_methods[${idx}][amount]" min="0.01" step="0.01" placeholder="Amount" required>
                </div>
                <div class="col-md-4 payment-method-ref-wrap" style="display:none;">
                    <label class="form-label mb-1">Reference No.</label>
                    <input type="text" class="form-control payment-method-ref" name="payment_methods[${idx}][reference_number]" maxlength="80" placeholder="Reference number">
                </div>
                <div class="col-md-1 d-flex align-items-end justify-content-end">
                    <button type="button" class="btn btn-outline-danger btn-sm removePaymentMethodBtn" data-row="${idx}"><i class="fas fa-times"></i></button>
                </div>
            </div>
        </div>
    `;
}
function addPaymentMethodRow() {
    if (document.querySelectorAll('.payment-method-row').length >= supportedPaymentMethods.length) {
        return;
    }
    paymentMethodRowsDiv.insertAdjacentHTML('beforeend', makePaymentMethodRow(paymentMethodRowIdx));
    togglePaymentMethodReference(document.getElementById('paymentMethodRow_' + paymentMethodRowIdx));
    paymentMethodRowIdx++;
    syncPaymentMethodOptions();
    updatePaymentMethodTotal();
}
function updatePaymentMethodTotal() {
    let total = 0;
    document.querySelectorAll('.payment-method-amount').forEach(function(input) {
        total += parseFloat(input.value) || 0;
    });
    document.getElementById('paymentMethodTotalText').textContent =
        'Payment method total: PHP ' + total.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
}
document.getElementById('addPaymentMethodBtn').addEventListener('click', addPaymentMethodRow);
paymentMethodRowsDiv.addEventListener('change', function(e) {
    if (e.target.classList.contains('payment-method-select')) {
        togglePaymentMethodReference(e.target.closest('.payment-method-row'));
        syncPaymentMethodOptions();
    }
});
paymentMethodRowsDiv.addEventListener('input', function(e) {
    if (e.target.classList.contains('payment-method-amount')) {
        updatePaymentMethodTotal();
    }
});
paymentMethodRowsDiv.addEventListener('click', function(e) {
    const removeButton = e.target.closest('.removePaymentMethodBtn');
    if (!removeButton) {
        return;
    }
    const rowDiv = document.getElementById('paymentMethodRow_' + removeButton.getAttribute('data-row'));
    if (rowDiv) {
        rowDiv.remove();
    }
    if (document.querySelectorAll('.payment-method-row').length === 0) {
        addPaymentMethodRow();
    } else {
        syncPaymentMethodOptions();
        updatePaymentMethodTotal();
    }
});
document.addEventListener('DOMContentLoaded', function() {
    addOtherFeeRow();
    addPaymentMethodRow();

    // Date/time autofill
    var dateField = document.getElementById('datePaidField');
    var timeField = document.getElementById('timePaidField');
    if (dateField) {
        var now = new Date();
        var yyyy = now.getFullYear();
        var mm = String(now.getMonth() + 1).padStart(2, '0');
        var dd = String(now.getDate()).padStart(2, '0');
        dateField.value = yyyy + '-' + mm + '-' + dd;
    }
    if (timeField) {
        var now = new Date();
        var hh = String(now.getHours()).padStart(2, '0');
        var min = String(now.getMinutes()).padStart(2, '0');
        timeField.value = hh + ':' + min;
    }
});

// --- Booklet/receipt dynamic ---
const bookletNoField = document.getElementById('bookletNoField');
const receiptNoField = document.getElementById('receiptNoField');
const receiptNoRange = document.getElementById('receiptNoRange');
function updateReceiptNos() {
    let bookletNo = parseInt(bookletNoField.value);
    receiptNoField.innerHTML = '<option value="">Select Receipt No</option>';
    let bookletMeta = bookletCatalogByStorage[bookletNo];
    if (!isNaN(bookletNo) && bookletMeta) {
        let start = parseInt(bookletMeta.range_start, 10);
        let end = parseInt(bookletMeta.range_end, 10);
        let usedReceipts = usedReceiptsByBooklet[bookletNo] || [];
        let nextAvailable = nextAvailableReceiptByBooklet[bookletNo] || "";
        let selectedSet = false;
        for (let i = start; i <= end; i++) {
            if (usedReceipts.includes(i)) {
                receiptNoField.innerHTML += `<option value="${i}" disabled>${i} (Used)</option>`;
            } else {
                let selected = '';
                if (!selectedSet && nextAvailable == i) {
                    selected = ' selected';
                    selectedSet = true;
                }
                receiptNoField.innerHTML += `<option value="${i}"${selected}>${i}</option>`;
            }
        }
        receiptNoRange.textContent = `Receipt numbers for booklet ${bookletMeta.booklet_code}: ${start} - ${end}. Next available: ${nextAvailable ? nextAvailable : 'None'}`;
    } else {
        receiptNoRange.textContent = '';
    }
}
if (bookletNoField) {
    bookletNoField.addEventListener('change', updateReceiptNos);
    bookletNoField.addEventListener('focus', updateReceiptNos);
    if (bookletNoField.value) updateReceiptNos();
}

// --------- Double Check Modal Logic ----------
const paymentForm = document.getElementById('addOtherPaymentForm');
const doubleCheckModalEl = document.getElementById('doubleCheckModal');
const doubleCheckModal = new bootstrap.Modal(doubleCheckModalEl);
const dcPaymentSummary = document.getElementById('dcPaymentSummary');
const dcDatePaid = document.getElementById('dcDatePaid');
const dcTimePaid = document.getElementById('dcTimePaid');
const dcBookletNo = document.getElementById('dcBookletNo');
const dcReceiptNo = document.getElementById('dcReceiptNo');
const dcPaymentMethods = document.getElementById('dcPaymentMethods');
const dcPaymentNote = document.getElementById('dcPaymentNote');
const doubleCheckConfirm = document.getElementById('doubleCheckConfirm');
const doubleCheckProceedBtn = document.getElementById('doubleCheckProceedBtn');

if (paymentForm) {
    paymentForm.addEventListener('submit', function(e) {
        e.preventDefault(); // Prevent actual submit
        // Gather summary info
        let payments = [];
        document.querySelectorAll('#feeRows .fee-row').forEach(row => {
            let note = row.querySelector('input[name^="fees"][name$="[note]"]');
            let amount = row.querySelector('input[name^="fees"][name$="[amount]"]');
            if (note && note.value && amount && amount.value) {
                let feeText = "Other - " + note.value + ': ₱' + parseFloat(amount.value).toLocaleString('en-US', {minimumFractionDigits:2});
                payments.push(feeText);
            }
        });
        dcPaymentSummary.textContent = payments.length ? payments.join(' | ') : 'No payment entered';
        dcDatePaid.textContent = document.getElementById('datePaidField').value;
        dcTimePaid.textContent = document.getElementById('timePaidField').value;
        let bookletValue = document.getElementById('bookletNoField').value;
        dcBookletNo.textContent = bookletValue ? ("S" + (parseInt(bookletValue, 10) - <?= SPECIAL_BOOKLET_STORAGE_OFFSET ?>)) : '';
        dcReceiptNo.textContent = document.getElementById('receiptNoField').value;
        let methodLines = [];
        document.querySelectorAll('.payment-method-row').forEach(function(row) {
            let method = row.querySelector('.payment-method-select')?.value || '';
            let amount = parseFloat(row.querySelector('.payment-method-amount')?.value || '0') || 0;
            let refNum = row.querySelector('.payment-method-ref')?.value.trim() || '';
            if (method && amount > 0) {
                let line = method + ': PHP ' + amount.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
                if (refNum) {
                    line += ' (Ref#: ' + refNum + ')';
                }
                methodLines.push(line);
            }
        });
        dcPaymentMethods.textContent = methodLines.length ? methodLines.join(' | ') : 'No payment method entered';
        dcPaymentNote.textContent = document.getElementById('paymentNoteField').value.trim() || '-';
        doubleCheckConfirm.checked = false;
        doubleCheckProceedBtn.disabled = true;
        doubleCheckModal.show();
    });
    // Enable Proceed only if confirmed
    doubleCheckConfirm.addEventListener('change', function() {
        doubleCheckProceedBtn.disabled = !this.checked;
    });
    // Final submit on modal
    document.getElementById('finalPaymentForm').addEventListener('submit', function(e) {
        e.preventDefault();
        doubleCheckModal.hide();
        paymentForm.submit(); // Actually submit the original form
    });
}
</script>
</body>
</html>
<?php $conn->close(); ?>
