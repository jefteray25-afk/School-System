<?php
require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../settings/settings-permissions-roles.php';

$role = $_SESSION['role'] ?? '';
// Keep this legacy stub protected. Only roles that can view finance should access it.
if (!hasPermission($role, 'financial', 'view')) {
    admin_session_forbidden();
}

// Example: Replace with actual data from your database
$receipt = [
    'id' => '12345',
    'date' => '2025-09-09',
    'amount' => '$50.00',
    'payer' => 'John Doe'
];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Account Receipt</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .receipt-container { border: 1px solid #ccc; padding: 20px; max-width: 400px; margin: auto; }
        .header { text-align: center; font-size: 24px; margin-bottom: 20px; }
        .field { margin-bottom: 10px; }
        .label { font-weight: bold; }
    </style>
</head>
<body>
    <div class="receipt-container">
        <div class="header">Account Receipt</div>
        <div class="field"><span class="label">Receipt ID:</span> <?php echo $receipt['id']; ?></div>
        <div class="field"><span class="label">Date:</span> <?php echo $receipt['date']; ?></div>
        <div class="field"><span class="label">Amount:</span> <?php echo $receipt['amount']; ?></div>
        <div class="field"><span class="label">Payer:</span> <?php echo $receipt['payer']; ?></div>
        <hr>
        <div style="text-align:center;font-size:12px;color:#555;">Thank you for your payment!</div>
    </div>
</body>
</html>
