﻿<?php
require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();
include '../../../config/database.php';
require_once __DIR__ . '/../../../includes/payment-collision-helper.php';
include '../../settings/settings-permissions-roles.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/includes-receipt-helper.php';
require_once __DIR__ . '/../../../includes/receipt-payment-method-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';
require_once __DIR__ . '/../../settings/school-year-helper.php';
require_once __DIR__ . '/../../settings/settings-security.php';

$conn->set_charset('utf8mb4');
ensure_payments_prepared_by_column($conn);
ensure_payments_reference_note_columns($conn);
ensure_receipt_payment_methods_table($conn);
$currentRole = $_SESSION['role'] ?? '';
$can_add = hasPermission($currentRole, 'financial', 'add');
if (!$can_add) {
    $blockedUser = $_SESSION['username'] ?? 'unknown';
    audit_log(
        $conn,
        $blockedUser,
        'Blocked account add payment access',
        'Accounts',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing financial:add permission',
        'SECURITY'
    );
    admin_session_forbidden();
}

$student_id = isset($_GET['student_id']) ? intval($_GET['student_id']) : 0;
if (!$student_id) die('Invalid student ID.');
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
$requested_school_year = trim($_GET['school_year'] ?? '');
$active_school_year_label = school_year_get_active_label($conn);

$stmt = $conn->prepare("SELECT CONCAT(lastname, ', ', firstname, ' ', middlename) AS student_name, grade, school_year_label FROM students WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$stmt->bind_result($student_name, $student_grade, $student_school_year);
if (!$stmt->fetch()) die("Student not found.");
$stmt->close();
$selected_school_year = $requested_school_year !== '' ? $requested_school_year : (trim((string) $student_school_year) !== '' ? trim((string) $student_school_year) : $active_school_year_label);

$fee_accounts = [];
$stmt = $conn->prepare("SELECT id, type, balance FROM accounts WHERE student_id=? AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ? ORDER BY type ASC");
$stmt->bind_param("iss", $student_id, $selected_school_year, $selected_school_year);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $fee_accounts[] = $row;
$stmt->close();
$payment_balance_snapshot_token = payment_collision_token(active_payment_balance_snapshot($conn, $student_id, $selected_school_year));

$regular_booklet_rows = receipt_booklet_registry_payment_rows($conn, 'regular', true);
$regular_booklet_map = [];
$regular_booklet_usage = receipt_booklet_usage_map($conn, $regular_booklet_rows);
$used_receipts_by_booklet = [];
$next_available_receipt_by_booklet = [];
foreach ($regular_booklet_rows as $booklet_row) {
    $storage_no = (int) $booklet_row['storage_number'];
    $usage_row = $regular_booklet_usage[$storage_no] ?? ['used' => [], 'next' => null];
    $used_receipts_by_booklet[$storage_no] = $usage_row['used'];
    $next_available_receipt_by_booklet[$storage_no] = $usage_row['next'];
    $regular_booklet_map[$storage_no] = [
        'booklet_code' => (string) $booklet_row['booklet_code'],
        'range_start' => (int) $booklet_row['range_start'],
        'range_end' => (int) $booklet_row['range_end'],
    ];
}

$next_receipt_no = get_next_regular_receipt_no($conn);
$error = $success = "";
ensure_csrf_token();

function payments_has_reference_note_columns(mysqli $conn): bool
{
    $result = $conn->query("SHOW COLUMNS FROM payments LIKE 'reference_number'");
    $hasRef = $result && $result->num_rows > 0;
    if ($result) {
        $result->close();
    }
    $result2 = $conn->query("SHOW COLUMNS FROM payments LIKE 'payment_note'");
    $hasNote = $result2 && $result2->num_rows > 0;
    if ($result2) {
        $result2->close();
    }
    return $hasRef && $hasNote;
}

// MULTI-FEE PAYMENT HANDLER
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['void_receipt_submit'])) {
    admin_require_post_csrf();
    $submittedBalanceToken = trim((string) ($_POST['payment_balance_snapshot_token'] ?? ''));
    $date_paid = $_POST['date_paid'] ?? date('Y-m-d');
    $time_paid = $_POST['time_paid'] ?? date('H:i');
    $booklet_no = intval($_POST['booklet_no'] ?? 0);
    $receipt_no = intval($_POST['receipt_no'] ?? 0);
    $payment_note = trim((string) ($_POST['payment_note'] ?? ''));
    $fees = $_POST['fees'] ?? [];
    $valid_fee_rows = [];
    $payment_methods = receipt_payment_methods_normalize($_POST['payment_methods'] ?? []);
    $prepared_by = trim((string) ($_SESSION['username'] ?? 'System'));
    $expected_payment_total = 0.0;
    foreach ($fees as $fee_item) {
        if (!is_array($fee_item)) {
            continue;
        }
        $fee_account_id = intval($fee_item['account_id'] ?? 0);
        $raw_amount = trim((string) ($fee_item['amount'] ?? ''));
        $amount = round((float) str_replace(',', '', $raw_amount), 2);
        if ($fee_account_id <= 0 && $raw_amount === '') {
            continue;
        }
        if ($fee_account_id <= 0 && $amount > 0) {
            $error = 'Every payment amount must be assigned to a fee type.';
            break;
        }
        if ($fee_account_id > 0 && $amount <= 0) {
            $error = 'Every selected fee type must have an amount greater than zero.';
            break;
        }
        $valid_fee_rows[] = [
            'account_id' => $fee_account_id,
            'amount' => $amount,
        ];
        $expected_payment_total += $amount;
    }
    $expected_payment_total = round($expected_payment_total, 2);
    $legacyMethodSummary = receipt_payment_methods_build_legacy_summary($payment_methods, $payment_note);
    $receipt_note = $legacyMethodSummary['method_label'];
    $reference_number = $legacyMethodSummary['reference_summary'];
    $payment_note = $legacyMethodSummary['note_summary'];

    $valid_booklet = is_regular_booklet_number($booklet_no);
    [$start_receipt, $end_receipt] = receipt_window_for_booklet($booklet_no);
    $valid_receipt = ($receipt_no >= $start_receipt && $receipt_no <= $end_receipt);

        $receipt_entry = null;
        if ($valid_booklet && $valid_receipt) {
            $receipt_entry = get_receipt_registry_entry($conn, $receipt_no, $booklet_no);
        }
    $receipt_used = $receipt_entry && (int) $receipt_entry['voided'] === 0;
    $receipt_reusable = $receipt_entry && (int) $receipt_entry['voided'] === 1;

    if ($error !== '') {
        // Validation message populated while normalizing fee rows.
    } elseif (!$valid_fee_rows) {
        $error = "No valid payments entered.";
    } elseif ($submittedBalanceToken === '') {
        $error = "This payment form is missing collision protection data. Please refresh and try again.";
    } elseif (!hash_equals(payment_collision_token(active_payment_balance_snapshot($conn, $student_id, $selected_school_year)), $submittedBalanceToken)) {
        $error = "This student's fee balances changed while you were preparing the payment. Refresh the page first so you don't save against stale balances.";
    } elseif (!$valid_booklet) {
        $error = "Booklet No. must be between " . REGULAR_BOOKLET_MIN . " and " . REGULAR_BOOKLET_MAX . ".";
    } elseif (!$valid_receipt) {
        $error = "Receipt No. for Booklet " . $booklet_no . " must be between " . $start_receipt . " and " . $end_receipt . ".";
    
    } elseif ($receipt_used) {
        $error = "Receipt No. $receipt_no is already used. Please use the suggested next receipt no: $next_receipt_no";
    } elseif (!receipt_payment_methods_validate($payment_methods, $expected_payment_total, $error)) {
        // Validation message populated by helper.
    } else {
        $datetime_paid = $date_paid . ' ' . $time_paid . ':00';
        $conn->begin_transaction();
        $reserve = reserve_or_reuse_receipt(
            $conn,
            $receipt_no,
            $booklet_no,
            'payments',
            $receipt_reusable ? 'Reused for corrected active payment entry' : null
        );
        if (!$reserve['success']) {
            $conn->rollback();
            $error = $reserve['message'] ?: 'Failed to reserve receipt.';
        }
        if (!$error && !receipt_payment_methods_replace_for_receipt($conn, $booklet_no, $receipt_no, 'payments', $payment_methods)) {
            $conn->rollback();
            $error = receipt_payment_methods_last_error() !== ''
                ? receipt_payment_methods_last_error()
                : 'Failed to save payment method breakdown.';
        }

        $success_payments = 0;
        $first_payment_id = null;
        $audit_fee_details = [];
        foreach ($valid_fee_rows as $fee_item) {
            if (!empty($error)) {
                break;
            }
            $fee_account_id = intval($fee_item['account_id']);
            $amount = floatval(str_replace(',', '', $fee_item['amount'] ?? '0'));
            if ($fee_account_id && $amount > 0) {
                $bal_stmt = $conn->prepare("SELECT balance, type FROM accounts WHERE id=?");
                $bal_stmt->bind_param("i", $fee_account_id);
                $bal_stmt->execute();
                $bal_stmt->bind_result($current_balance, $account_type);
                $bal_stmt->fetch();
                $bal_stmt->close();

                if ($amount > (float) $current_balance) {
                    $error = "Payment for {$account_type} cannot exceed the remaining balance of PHP " . number_format((float) $current_balance, 2) . ".";
                    break;
                }

                $new_balance = $current_balance - $amount;
                // Always use auto-generated remarks for payment records
                if ($new_balance <= 0) {
                    $fee_remarks = 'Fully Paid';
                    $new_balance = 0;
                } else {
                    $fee_remarks = 'Remaining Balance: PHP ' . number_format($new_balance, 2);
                }

                $hasStructuredNote = payments_has_reference_note_columns($conn);
                if ($hasStructuredNote) {
                    $sql = "INSERT INTO payments (account_id, amount, date_paid, remarks, receipt_note, reference_number, payment_note, prepared_by, booklet_no, receipt_no, school_year_label)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    $stmt = $conn->prepare($sql);
                    if (!$stmt) {
                        $error = "Failed to prepare payment insert (structured).";
                        break;
                    }
                    $stmt->bind_param(
                        "idssssssiis",
                        $fee_account_id,
                        $amount,
                        $datetime_paid,
                        $fee_remarks,
                        $receipt_note,
                        $reference_number,
                        $payment_note,
                        $prepared_by,
                        $booklet_no,
                        $receipt_no,
                        $selected_school_year
                    );
                } else {
                    // Backward compatible: older DB without reference_number/payment_note columns
                    $fallbackRemarks = $fee_remarks;
                    if ($reference_number !== '') {
                        $fallbackRemarks .= " (Ref#: " . htmlspecialchars($reference_number) . ")";
                    }
                    if ($payment_note !== '') {
                        $fallbackRemarks .= " (Note: " . htmlspecialchars($payment_note) . ")";
                    }
                    $sql = "INSERT INTO payments (account_id, amount, date_paid, remarks, receipt_note, prepared_by, booklet_no, receipt_no, school_year_label)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    $stmt = $conn->prepare($sql);
                    if (!$stmt) {
                        $error = "Failed to prepare payment insert (legacy).";
                        break;
                    }
                    $stmt->bind_param(
                        "idssssiis",
                        $fee_account_id,
                        $amount,
                        $datetime_paid,
                        $fallbackRemarks,
                        $receipt_note,
                        $prepared_by,
                        $booklet_no,
                        $receipt_no,
                        $selected_school_year
                    );
                }
                if ($stmt->execute()) {
                    $new_payment_id = $stmt->insert_id;
                    $update_stmt = $conn->prepare("UPDATE accounts SET balance = ? WHERE id = ?");
                    $update_stmt->bind_param("di", $new_balance, $fee_account_id);
                    $update_stmt->execute();
                    $update_stmt->close();

                    if ($success_payments === 0) {
                        attach_receipt_to_payment($conn, $receipt_no, $new_payment_id, $booklet_no);
                        $first_payment_id = $new_payment_id;
                    }
                    $success_payments++;
                    // Collect audit details for each fee
                    $audit_fee_details[] = "AccountID: $fee_account_id, Type: $account_type, Amount: $amount, NewBalance: $new_balance";
                } else {
                    $error = "Failed to save payment row for {$account_type}: " . $stmt->error;
                    break;
                }
                $stmt->close();
            }
        }

        if ($success_payments > 0) {
            $conn->commit();
            $success = "Payments successfully added.";

            // ---------- AUDIT LOGGING: Add Payment ----------
            include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');
            $user = $_SESSION['username'] ?? 'unknown';
            $action = "Added payment(s)";
            $module = "Payments";
            $details = "Role: " . ($_SESSION['role'] ?? 'unknown') .
                " | Student ID: " . $student_id .
                " | Student Name: " . ($student_name ?? 'unknown') .
                " | Accounts: [" . implode("; ", $audit_fee_details) . "]" .
                " | Booklet No: " . $booklet_no .
                " | Receipt No: " . $receipt_no .
                " | Paid by: " . $user .
                " | PaymentType: " . $receipt_note .
                " | MethodBreakdown: " . receipt_payment_methods_summary_text($payment_methods) .
                " | SchoolYear: " . $selected_school_year .
                ($reference_number === '' ? "" : " | Ref#: " . $reference_number) .
                ($payment_note === '' ? "" : " | Note: " . $payment_note) .
                " | DatePaid: " . $datetime_paid;
            audit_log($conn, $user, $action, $module, $details);

            header("Location: account-payment-history.php?student_id=" . $student_id . "&school_year=" . urlencode($selected_school_year));
            exit;
        } else {
            $conn->rollback();
            if ($error === '') {
                $error = "No valid payments entered.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Desk - Add Payment | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script>
        var feeAccounts = <?= json_encode($fee_accounts) ?>;
        var usedReceiptsByBooklet = <?= json_encode($used_receipts_by_booklet) ?>;
        var nextAvailableReceiptByBooklet = <?= json_encode($next_available_receipt_by_booklet) ?>;
        var bookletCatalogByStorage = <?= json_encode($regular_booklet_map) ?>;
    </script>
    <style>
        body { background: #f5f8fc; font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif; }
        .main-card { background: #fff; border-radius: 1rem; box-shadow: 0 4px 18px rgba(33,57,93,0.09), 0 1.5px 3px rgba(33,57,93,0.07); margin: 0 auto; margin-top: 48px; padding:2.2rem 2.5rem 2.3rem; max-width: 530px; }
        .section-title { font-size: 1.23rem; font-weight: 700; color: #198754; margin-bottom: 1.1rem; letter-spacing: 0.04em; }
        .form-label { font-weight: 500; }
        .student-details { font-size: 0.97rem; margin-bottom: .35rem; color: #555; }
        .fee-row { margin-bottom: 10px; }
        .total-payment-row { font-size: 1.1em; color: #198754; text-align: right; margin-bottom: 1em; }
    </style>
</head>
<body>
<div class="container main-card px-3">
    <div class="section-title">
        <i class="fas fa-plus"></i> Payment Desk - Add Payment
    </div>
    <div class="student-details mb-2">
        <strong>Student:</strong>
        <span><?= htmlspecialchars($student_name) ?></span><br>
        <strong>Grade:</strong> <?= htmlspecialchars($student_grade) ?><br>
        <strong>School Year:</strong> <?= htmlspecialchars($selected_school_year) ?>
    </div>
    <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

    <!-- Add Payment Form -->
    <form method="post" id="addPaymentForm" autocomplete="off">
      <?= csrf_input() ?>
      <input type="hidden" name="payment_balance_snapshot_token" value="<?= htmlspecialchars($payment_balance_snapshot_token) ?>">
      <div id="feeRows"></div>
        <div class="total-payment-row">
            <strong>Total Payment:</strong> <span id="totalPayment">PHP 0.00</span>
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">Date Paid</label>
            <input type="date" name="date_paid" id="datePaidField" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">Time Paid</label>
            <input type="time" name="time_paid" id="timePaidField" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">Booklet No</label>
            <select name="booklet_no" id="bookletNoField" class="form-select" required>
                <option value="">Select Booklet No</option>
                <?php foreach ($regular_booklet_rows as $booklet_row): ?>
                    <option value="<?= (int) $booklet_row['storage_number'] ?>"><?= htmlspecialchars((string) $booklet_row['booklet_code']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">Receipt No</label>
            <select name="receipt_no" id="receiptNoField" class="form-select" required>
                <option value="">Select Receipt No</option>
            </select>
            <div class="form-text" id="receiptNoRange"></div>
            <div class="form-text">
                Global next available receipt (suggestion): <strong><?= (int)$next_receipt_no ?></strong>
            </div>
        </div>
        <div class="mb-3">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <label class="form-label fw-bold mb-0">Payment Method Breakdown</label>
                <button type="button" class="btn btn-outline-primary btn-sm" id="addPaymentMethodBtn">+ Add Method</button>
            </div>
            <div id="paymentMethodRows"></div>
            <div class="form-text">Use 1 to 3 methods. The total of all method rows must match the total payment amount above.</div>
            <div class="form-text" id="paymentMethodTotalText">Payment method total: PHP 0.00</div>
            <div class="mt-2">
                <label class="form-label">Payment Note (optional)</label>
                <input type="text" name="payment_note" id="paymentNoteField" class="form-control" maxlength="255" placeholder="Optional note for this receipt">
            </div>
        </div>
        <div class="d-flex justify-content-between mt-4">
            <button type="submit" class="btn btn-success"><i class="fas fa-plus"></i> Save Payment</button>
            <a href="account-payment-history.php?student_id=<?= $student_id ?>&school_year=<?= urlencode($selected_school_year) ?>" class="btn btn-secondary"><i class="fas fa-times"></i> Back to Payment Desk</a>
        </div>
    </form>
</div>

<!-- Double Check Modal -->
<div class="modal fade" id="doubleCheckModal" tabindex="-1" aria-labelledby="doubleCheckModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form id="finalPaymentForm" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="doubleCheckModalLabel"><i class="fas fa-exclamation-triangle text-warning"></i> Please Double Check</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <ul id="doubleCheckList" style="font-size:1.02em;">
          <li><strong>Payment Amounts:</strong> <span id="dcPaymentSummary"></span></li>
          <li><strong>Date Paid:</strong> <span id="dcDatePaid"></span></li>
          <li><strong>Time Paid:</strong> <span id="dcTimePaid"></span></li>
          <li><strong>Booklet No:</strong> <span id="dcBookletNo"></span></li>
          <li><strong>Receipt No:</strong> <span id="dcReceiptNo"></span></li>
          <li><strong>Payment Methods:</strong> <span id="dcPaymentType"></span></li>
          <li><strong>Payment Note:</strong> <span id="dcPaymentNote"></span></li>
        </ul>
        <div class="form-check mt-3">
          <input type="checkbox" class="form-check-input" id="doubleCheckConfirm" required>
          <label class="form-check-label" for="doubleCheckConfirm">I have double-checked the above information</label>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" id="doubleCheckEditBtn" data-bs-dismiss="modal">No, Edit Info</button>
        <button type="submit" class="btn btn-success" id="doubleCheckProceedBtn" disabled>Yes, Proceed</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// --- Fee Row Logic ---
let feeRowIdx = 0;
let selectedFees = [];
const feeRowsDiv = document.getElementById('feeRows');
const paymentMethodRowsDiv = document.getElementById('paymentMethodRows');
const supportedPaymentMethods = ['Cash', 'GCash', 'Bank Transfer'];
function refreshSelectedFees() {
    selectedFees = Array.from(document.querySelectorAll('.fee-type-select'))
        .map(function(selectElement) {
            return String(selectElement.value || '').trim();
        })
        .filter(function(value) {
            return value !== '';
        });
}
function syncFeeSelectOptions() {
    refreshSelectedFees();
    const selectedSet = new Set(selectedFees);
    document.querySelectorAll('.fee-type-select').forEach(function(selectElement) {
        const currentValue = String(selectElement.value || '').trim();
        selectElement.querySelectorAll('option').forEach(function(option) {
            if (!option.value) {
                option.disabled = false;
                return;
            }
            option.disabled = selectedSet.has(option.value) && option.value !== currentValue;
        });
    });
}
function syncFeeRowValidation(rowDiv) {
    if (!rowDiv) {
        return;
    }

    const feeSelect = rowDiv.querySelector('.fee-type-select');
    const amountInput = rowDiv.querySelector('input[type="number"]');
    const hasSelectedFee = feeSelect && String(feeSelect.value || '').trim() !== '';

    if (feeSelect) {
        feeSelect.required = false;
    }

    if (amountInput) {
        amountInput.required = hasSelectedFee;
        if (!hasSelectedFee) {
            amountInput.value = '';
        }
    }
}
function syncAllFeeRowValidation() {
    document.querySelectorAll('.fee-row').forEach(function(rowDiv) {
        syncFeeRowValidation(rowDiv);
    });
}
function getAvailableFeeAccounts() {
    return feeAccounts.filter(function(fa) {
        // Only show if not picked
        return !selectedFees.includes(fa.id.toString());
    });
}
function makeFeeRow(idx) {
    let options = '<option value="">Select Fee Type</option>';
    let availableFeeAccounts = getAvailableFeeAccounts();
    for (let fa of availableFeeAccounts) {
        options += `<option value="${fa.id}">${fa.type} (Current: PHP ${parseFloat(fa.balance).toLocaleString()})</option>`;
    }
    return `
    <div class="row fee-row align-items-center" id="feeRow_${idx}">
        <div class="col-7">
            <select class="form-select fee-type-select" name="fees[${idx}][account_id]" data-row="${idx}" required>
                ${options}
            </select>
        </div>
        <div class="col-4">
            <input type="number" class="form-control" name="fees[${idx}][amount]" min="0" step="0.01" placeholder="Amount" required>
        </div>
        <div class="col-1 d-flex justify-content-end">
            <button type="button" class="btn btn-outline-danger removeFeeBtn" data-row="${idx}" aria-label="Remove Fee Row"><i class="fas fa-times"></i></button>
        </div>
    </div>
    `;
}
function addFeeRow() {
    let availableFeeAccounts = getAvailableFeeAccounts();
    if (availableFeeAccounts.length > 0) {
        feeRowsDiv.insertAdjacentHTML('beforeend', makeFeeRow(feeRowIdx));
        syncFeeRowValidation(document.getElementById('feeRow_' + feeRowIdx));
        feeRowIdx++;
        updateTotalPayment();
    }
}
// Add first row on page load
addFeeRow();
// Listen for fee type change and auto-add another row if not all added
feeRowsDiv.addEventListener('change', function(e) {
    if (e.target.classList.contains('fee-type-select')) {
        let val = e.target.value;
        syncFeeRowValidation(e.target.closest('.fee-row'));
        if (val) {
            syncFeeSelectOptions();
            if (getAvailableFeeAccounts().length > 0) {
                addFeeRow();
            }
        } else {
            syncFeeSelectOptions();
        }
    } else if (e.target.matches('#feeRows input[type="number"]')) {
        syncFeeRowValidation(e.target.closest('.fee-row'));
    }
});
// Remove fee row
feeRowsDiv.addEventListener('click', function(e) {
    const removeButton = e.target.closest('.removeFeeBtn');
    if (removeButton) {
        let idx = removeButton.getAttribute('data-row');
        let rowDiv = document.getElementById('feeRow_' + idx);
        if (rowDiv) {
            rowDiv.remove();
            syncFeeSelectOptions();
            if (document.querySelectorAll('.fee-row').length === 0) {
                addFeeRow();
            }
            syncAllFeeRowValidation();
            updateTotalPayment();
        }
    }
});

// --- Total Payment Calculation ---
function updateTotalPayment() {
    let total = 0;
    document.querySelectorAll('#feeRows input[type="number"]').forEach(input => {
        let val = parseFloat(input.value) || 0;
        total += val;
    });
    document.getElementById('totalPayment').textContent = 'PHP ' + total.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
    updatePaymentMethodTotal();
}
// Listen for input on any fee amount field
document.addEventListener('input', function(e) {
    if (e.target.matches('#feeRows input[type="number"]')) {
        updateTotalPayment();
    }
});

let paymentMethodRowIdx = 0;
function getSelectedPaymentMethods() {
    return Array.from(document.querySelectorAll('.payment-method-select'))
        .map(select => String(select.value || '').trim())
        .filter(Boolean);
}
function syncPaymentMethodOptions() {
    const selected = new Set(getSelectedPaymentMethods());
    document.querySelectorAll('.payment-method-select').forEach(function(selectElement) {
        const currentValue = String(selectElement.value || '').trim();
        selectElement.querySelectorAll('option').forEach(function(option) {
            if (!option.value) {
                option.disabled = false;
                return;
            }
            option.disabled = selected.has(option.value) && option.value !== currentValue;
        });
    });
}
function togglePaymentMethodReference(rowDiv) {
    if (!rowDiv) {
        return;
    }
    const methodSelect = rowDiv.querySelector('.payment-method-select');
    const refWrap = rowDiv.querySelector('.payment-method-ref-wrap');
    const refInput = rowDiv.querySelector('.payment-method-ref');
    const needsRef = methodSelect && (methodSelect.value === 'GCash' || methodSelect.value === 'Bank Transfer');
    if (refWrap) {
        refWrap.style.display = needsRef ? '' : 'none';
    }
    if (refInput) {
        refInput.required = !!needsRef;
        if (!needsRef) {
            refInput.value = '';
        }
    }
}
function makePaymentMethodRow(idx) {
    return `
    <div class="border rounded p-2 mb-2 payment-method-row" id="paymentMethodRow_${idx}">
        <div class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label mb-1">Method</label>
                <select class="form-select payment-method-select" name="payment_methods[${idx}][method]" required>
                    <option value="">Select Method</option>
                    <option value="Cash">Cash</option>
                    <option value="GCash">GCash</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label mb-1">Amount</label>
                <input type="number" class="form-control payment-method-amount" name="payment_methods[${idx}][amount]" min="0.01" step="0.01" placeholder="Amount" required>
            </div>
            <div class="col-md-4 payment-method-ref-wrap" style="display:none;">
                <label class="form-label mb-1">Reference No.</label>
                <input type="text" class="form-control payment-method-ref" name="payment_methods[${idx}][reference_number]" maxlength="80" placeholder="Reference number">
            </div>
            <div class="col-md-1 d-flex justify-content-end">
                <button type="button" class="btn btn-outline-danger removePaymentMethodBtn" data-row="${idx}" aria-label="Remove Payment Method"><i class="fas fa-times"></i></button>
            </div>
        </div>
    </div>`;
}
function addPaymentMethodRow() {
    if (document.querySelectorAll('.payment-method-row').length >= supportedPaymentMethods.length) {
        return;
    }
    paymentMethodRowsDiv.insertAdjacentHTML('beforeend', makePaymentMethodRow(paymentMethodRowIdx));
    togglePaymentMethodReference(document.getElementById('paymentMethodRow_' + paymentMethodRowIdx));
    paymentMethodRowIdx++;
    syncPaymentMethodOptions();
    updatePaymentMethodTotal();
}
function updatePaymentMethodTotal() {
    let total = 0;
    document.querySelectorAll('.payment-method-amount').forEach(function(input) {
        total += parseFloat(input.value) || 0;
    });
    document.getElementById('paymentMethodTotalText').textContent =
        'Payment method total: PHP ' + total.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
}
function formatCurrency(amount) {
    return 'PHP ' + amount.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
}
function validatePaymentTotalsBeforeConfirm() {
    let feeTotal = 0;
    let validFeeCount = 0;
    let validationMessage = '';

    document.querySelectorAll('#feeRows .fee-row').forEach(function(row) {
        if (validationMessage) {
            return;
        }
        const feeSelect = row.querySelector('.fee-type-select');
        const amountInput = row.querySelector('input[type="number"]');
        const hasFee = feeSelect && String(feeSelect.value || '').trim() !== '';
        const rawAmount = amountInput ? String(amountInput.value || '').trim() : '';
        const amount = parseFloat(rawAmount) || 0;

        if (!hasFee && rawAmount === '') {
            return;
        }
        if (!hasFee && amount > 0) {
            validationMessage = 'Select a fee type for every payment amount.';
            return;
        }
        if (hasFee && amount <= 0) {
            validationMessage = 'Enter an amount greater than zero for every selected fee type.';
            return;
        }

        feeTotal += amount;
        validFeeCount++;
    });

    if (validationMessage) {
        return validationMessage;
    }
    if (validFeeCount === 0) {
        return 'Add at least one fee payment before saving.';
    }

    let methodTotal = 0;
    document.querySelectorAll('.payment-method-amount').forEach(function(input) {
        methodTotal += parseFloat(input.value) || 0;
    });

    if (Math.abs(feeTotal - methodTotal) > 0.009) {
        return 'Payment method total (' + formatCurrency(methodTotal) + ') must match selected fee total (' + formatCurrency(feeTotal) + ').';
    }

    return '';
}
document.getElementById('addPaymentMethodBtn').addEventListener('click', addPaymentMethodRow);
paymentMethodRowsDiv.addEventListener('change', function(e) {
    if (e.target.classList.contains('payment-method-select')) {
        togglePaymentMethodReference(e.target.closest('.payment-method-row'));
        syncPaymentMethodOptions();
    }
});
paymentMethodRowsDiv.addEventListener('input', function(e) {
    if (e.target.classList.contains('payment-method-amount')) {
        updatePaymentMethodTotal();
    }
});
paymentMethodRowsDiv.addEventListener('click', function(e) {
    const removeButton = e.target.closest('.removePaymentMethodBtn');
    if (!removeButton) {
        return;
    }
    const rowDiv = document.getElementById('paymentMethodRow_' + removeButton.getAttribute('data-row'));
    if (rowDiv) {
        rowDiv.remove();
    }
    if (document.querySelectorAll('.payment-method-row').length === 0) {
        addPaymentMethodRow();
    } else {
        syncPaymentMethodOptions();
        updatePaymentMethodTotal();
    }
});

// --- Date/Time (auto fill) ---
document.addEventListener('DOMContentLoaded', function() {
    var dateField = document.getElementById('datePaidField');
    var timeField = document.getElementById('timePaidField');
    if (dateField) {
        var now = new Date();
        var yyyy = now.getFullYear();
        var mm = String(now.getMonth() + 1).padStart(2, '0');
        var dd = String(now.getDate()).padStart(2, '0');
        dateField.value = yyyy + '-' + mm + '-' + dd;
    }
    if (timeField) {
        var now = new Date();
        var hh = String(now.getHours()).padStart(2, '0');
        var min = String(now.getMinutes()).padStart(2, '0');
        timeField.value = hh + ':' + min;
    }
});

// --- Booklet/receipt dynamic ---
const bookletNoField = document.getElementById('bookletNoField');
const receiptNoField = document.getElementById('receiptNoField');
const receiptNoRange = document.getElementById('receiptNoRange');
function updateReceiptNos() {
    let bookletNo = parseInt(bookletNoField.value);
    receiptNoField.innerHTML = '<option value="">Select Receipt No</option>';
    let bookletMeta = bookletCatalogByStorage[bookletNo];
    if (!isNaN(bookletNo) && bookletMeta) {
        let start = parseInt(bookletMeta.range_start, 10);
        let end = parseInt(bookletMeta.range_end, 10);
        let usedReceipts = usedReceiptsByBooklet[bookletNo] || [];
        let nextAvailable = nextAvailableReceiptByBooklet[bookletNo] || "";
        let selectedSet = false;
        for (let i = start; i <= end; i++) {
            if (usedReceipts.includes(i)) {
                receiptNoField.innerHTML += `<option value="${i}" disabled>${i} (Used)</option>`;
            } else {
                let selected = '';
                if (!selectedSet && nextAvailable == i) {
                    selected = ' selected';
                    selectedSet = true;
                }
                receiptNoField.innerHTML += `<option value="${i}"${selected}>${i}</option>`;
            }
        }
        receiptNoRange.textContent = `Receipt numbers for booklet ${bookletMeta.booklet_code}: ${start} - ${end}. Next available: ${nextAvailable ? nextAvailable : 'None'}`;
    } else {
        receiptNoRange.textContent = '';
    }
}
if (bookletNoField) {
    bookletNoField.addEventListener('change', updateReceiptNos);
    bookletNoField.addEventListener('focus', updateReceiptNos);
    if (bookletNoField.value) updateReceiptNos();
}
addPaymentMethodRow();

// --- Double Check Modal Logic ---
const paymentForm = document.getElementById('addPaymentForm');
const doubleCheckModalEl = document.getElementById('doubleCheckModal');
const doubleCheckModal = new bootstrap.Modal(doubleCheckModalEl);
const dcPaymentSummary = document.getElementById('dcPaymentSummary');
const dcDatePaid = document.getElementById('dcDatePaid');
const dcTimePaid = document.getElementById('dcTimePaid');
const dcBookletNo = document.getElementById('dcBookletNo');
const dcReceiptNo = document.getElementById('dcReceiptNo');
const dcPaymentType = document.getElementById('dcPaymentType');
const dcPaymentNote = document.getElementById('dcPaymentNote');
const doubleCheckConfirm = document.getElementById('doubleCheckConfirm');
const doubleCheckProceedBtn = document.getElementById('doubleCheckProceedBtn');

if (paymentForm) {
    paymentForm.addEventListener('submit', function(e) {
        e.preventDefault(); // Prevent actual submit
        syncAllFeeRowValidation();
        const validationMessage = validatePaymentTotalsBeforeConfirm();
        if (validationMessage) {
            alert(validationMessage);
            return;
        }
        // Gather summary info
        let payments = [];
        document.querySelectorAll('#feeRows .fee-row').forEach(row => {
            let type = row.querySelector('.fee-type-select');
            let amount = row.querySelector('input[type="number"]');
            if (type && type.value && amount && amount.value) {
                let typeText = type.options[type.selectedIndex].text;
                payments.push(typeText + ': PHP ' + parseFloat(amount.value).toLocaleString('en-US', {minimumFractionDigits:2}));
            }
        });
        dcPaymentSummary.textContent = payments.length ? payments.join(', ') : 'No payment entered';
        dcDatePaid.textContent = document.getElementById('datePaidField').value;
        dcTimePaid.textContent = document.getElementById('timePaidField').value;
        dcBookletNo.textContent = document.getElementById('bookletNoField').value;
        dcReceiptNo.textContent = document.getElementById('receiptNoField').value;
        let paymentBreakdown = [];
        document.querySelectorAll('.payment-method-row').forEach(function(row) {
            let method = row.querySelector('.payment-method-select')?.value || '';
            let amount = parseFloat(row.querySelector('.payment-method-amount')?.value || '0') || 0;
            let refNum = row.querySelector('.payment-method-ref')?.value.trim() || '';
            if (method && amount > 0) {
                let line = method + ': PHP ' + amount.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
                if (refNum) {
                    line += ' (Ref#: ' + refNum + ')';
                }
                paymentBreakdown.push(line);
            }
        });
        dcPaymentType.textContent = paymentBreakdown.length ? paymentBreakdown.join(' | ') : '-';
        dcPaymentNote.textContent = (document.getElementById('paymentNoteField').value || '').trim() || '-';
        doubleCheckConfirm.checked = false;
        doubleCheckProceedBtn.disabled = true;
        doubleCheckModal.show();
    });
    // Enable Proceed only if confirmed
    doubleCheckConfirm.addEventListener('change', function() {
        doubleCheckProceedBtn.disabled = !this.checked;
    });
    // Final submit on modal
    document.getElementById('finalPaymentForm').addEventListener('submit', function(e) {
        e.preventDefault();
        doubleCheckModal.hide();
        syncAllFeeRowValidation();
        paymentForm.submit(); // Actually submit the original form
    });
}
</script>
</body>
</html>
<?php $conn->close(); ?>

