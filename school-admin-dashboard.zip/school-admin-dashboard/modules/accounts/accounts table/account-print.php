<?php
require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();
include '../../../config/database.php';
include '../../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../../settings/settings-security.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/includes-receipt-helper.php';
require_once __DIR__ . '/../../../includes/receipt-payment-method-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/settings/school-info-helper.php';
require_once __DIR__ . '/../../old accounts/old-payments-schema-helper.php';
ensure_receipts_registry_schema($conn);
ensure_payments_prepared_by_column($conn);

// Permission check
$currentRole = $_SESSION['role'] ?? '';
$can_view = hasPermission($currentRole, 'financial', 'view');
if (!$can_view) {
    admin_session_forbidden();
}

// Get receipt identity from query parameters
$receipt_no = isset($_GET['receipt_no']) ? intval($_GET['receipt_no']) : 0;
$booklet_no = isset($_GET['booklet_no']) ? intval($_GET['booklet_no']) : 0;
if (!$receipt_no) {
    die("Invalid receipt number.");
}

// Resolve the currently active receipt instance from the registry.
$registrySql = "SELECT receipt_no, booklet_no, used_id, used_by
                FROM receipts_registry
                WHERE receipt_no = ?"
                . ($booklet_no > 0 ? " AND booklet_no = ?" : "") . "
                  AND voided = 0
                  AND used_by IN ('payments', 'other_payment', 'old_student_payments')
                LIMIT 1";
$registryStmt = $conn->prepare($registrySql);
if ($booklet_no > 0) {
    $registryStmt->bind_param("ii", $receipt_no, $booklet_no);
} else {
    $registryStmt->bind_param("i", $receipt_no);
}
$registryStmt->execute();
$registryResult = $registryStmt->get_result();
$registryEntry = $registryResult->fetch_assoc();
$registryStmt->close();

if (!$registryEntry || empty($registryEntry['used_id'])) {
    die("Receipt not found.");
}

$isOldReceipt = ($registryEntry['used_by'] ?? '') === 'old_student_payments';

if ($isOldReceipt) {
    $oldHasStructuredPaymentFields = old_payments_schema_has_reference_note_columns($conn);
    $oldHasPreparedByColumn = old_payments_schema_has_prepared_by_column($conn);
    $anchorSql = "SELECT p.id,
                         COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) AS date_paid,
                         p.booklet_no,
                         p.receipt_no,
                         " . ($oldHasStructuredPaymentFields ? "p.payment_method" : "p.note") . " AS receipt_note,
                         " . ($oldHasStructuredPaymentFields ? "p.reference_number" : "''") . " AS reference_number,
                         " . ($oldHasStructuredPaymentFields ? "p.payment_note" : "''") . " AS payment_note,
                         " . ($oldHasPreparedByColumn ? "p.prepared_by" : "''") . " AS prepared_by,
                         s.id AS student_id,
                         s.firstname,
                         s.lastname,
                         s.middlename,
                         '' AS grade,
                         '' AS lrn
                  FROM old_student_payments p
                  JOIN old_students s ON p.old_student_id = s.id
                  WHERE p.id = ? LIMIT 1";
} else {
    $anchorSql = "SELECT p.id, p.date_paid, p.booklet_no, p.receipt_no, p.receipt_note, p.reference_number, p.payment_note, p.prepared_by,
                         a.student_id,
                         s.firstname, s.lastname, s.middlename, s.grade, s.lrn
                  FROM payments p
                  JOIN accounts a ON p.account_id = a.id
                  JOIN students s ON a.student_id = s.id
                  WHERE p.id = ? LIMIT 1";
}
$anchorStmt = $conn->prepare($anchorSql);
$anchorStmt->bind_param("i", $registryEntry['used_id']);
$anchorStmt->execute();
$anchorResult = $anchorStmt->get_result();
$first_payment = $anchorResult->fetch_assoc();
$anchorStmt->close();

if (!$first_payment) {
    die("Receipt anchor not found.");
}

$student_id = $first_payment['student_id'];
$date_paid = $first_payment['date_paid'];

// Fetch only the current active receipt instance.
if ($isOldReceipt) {
    $group_sql = "SELECT p.id,
                         p.receipt_no,
                         p.amount,
                         p.note AS remarks,
                         p.booklet_no,
                         " . ($oldHasStructuredPaymentFields ? "p.payment_method" : "p.note") . " AS receipt_note,
                         " . ($oldHasStructuredPaymentFields ? "p.reference_number" : "''") . " AS reference_number,
                         " . ($oldHasStructuredPaymentFields ? "p.payment_note" : "''") . " AS payment_note,
                         " . ($oldHasPreparedByColumn ? "p.prepared_by" : "''") . " AS prepared_by,
                         COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) AS date_paid,
                         p.fee_type AS account_type,
                         p.old_student_id AS account_id
                  FROM old_student_payments p
                  WHERE p.receipt_no = ?
                    AND p.booklet_no = ?
                    AND COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) = ?
                    AND (p.deleted_at IS NULL OR p.deleted_at = '')
                  ORDER BY p.fee_type ASC";
} else {
    $group_sql = "SELECT p.id, p.receipt_no, p.amount, p.remarks, p.booklet_no, p.receipt_note, p.prepared_by, p.date_paid,
                         a.type as account_type, a.id as account_id
                  FROM payments p
                  JOIN accounts a ON p.account_id = a.id
                  WHERE p.receipt_no = ?
                    AND p.booklet_no = ?
                    AND p.date_paid = ?
                  ORDER BY a.type ASC";
}

$group_stmt = $conn->prepare($group_sql);
$group_stmt->bind_param("iis", $receipt_no, $first_payment['booklet_no'], $first_payment['date_paid']);
$group_stmt->execute();
$group_result = $group_stmt->get_result();

$payments = [];
$total_amount = 0;
while ($row = $group_result->fetch_assoc()) {
    $payments[] = $row;
    $total_amount += floatval($row['amount']);
}
$group_stmt->close();

// Get current registry status for the receipt
$void_sql = "SELECT voided, void_reason, voided_at FROM receipts_registry WHERE receipt_no = ? AND booklet_no = ? LIMIT 1";
$void_stmt = $conn->prepare($void_sql);
$void_stmt->bind_param("ii", $receipt_no, $first_payment['booklet_no']);
$void_stmt->execute();
$void_result = $void_stmt->get_result();
$void_status = $void_result->fetch_assoc();
$void_stmt->close();

// Format data
$date_paid_formatted = date('F d, Y', strtotime($date_paid));
$time_paid = date('h:i A', strtotime($date_paid));
$student_name = htmlspecialchars($first_payment['lastname'] . ', ' . $first_payment['firstname'] . ' ' . $first_payment['middlename']);
$booklet_display = booklet_label_from_stored((int)$first_payment['booklet_no']);
$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$schoolContactLine = school_info_contact_line($schoolInfo);
$receiptFooterNote = school_info_receipt_footer($schoolInfo);

// Determine overall status
$all_fully_paid = true;
if (!$isOldReceipt) {
    foreach ($payments as $p) {
        if ($p['remarks'] !== 'Fully Paid') {
            $all_fully_paid = false;
            break;
        }
    }
}

function receipt_amount_to_words(int $number): string
{
    $ones = [
        0 => 'zero', 1 => 'one', 2 => 'two', 3 => 'three', 4 => 'four',
        5 => 'five', 6 => 'six', 7 => 'seven', 8 => 'eight', 9 => 'nine',
        10 => 'ten', 11 => 'eleven', 12 => 'twelve', 13 => 'thirteen', 14 => 'fourteen',
        15 => 'fifteen', 16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen', 19 => 'nineteen',
    ];
    $tens = [
        2 => 'twenty', 3 => 'thirty', 4 => 'forty', 5 => 'fifty',
        6 => 'sixty', 7 => 'seventy', 8 => 'eighty', 9 => 'ninety',
    ];

    if ($number < 20) {
        return $ones[$number];
    }
    if ($number < 100) {
        $ten = intdiv($number, 10);
        $rest = $number % 10;
        return $tens[$ten] . ($rest ? '-' . $ones[$rest] : '');
    }
    if ($number < 1000) {
        $hundreds = intdiv($number, 100);
        $rest = $number % 100;
        return $ones[$hundreds] . ' hundred' . ($rest ? ' ' . receipt_amount_to_words($rest) : '');
    }
    if ($number < 1000000) {
        $thousands = intdiv($number, 1000);
        $rest = $number % 1000;
        return receipt_amount_to_words($thousands) . ' thousand' . ($rest ? ' ' . receipt_amount_to_words($rest) : '');
    }

    $millions = intdiv($number, 1000000);
    $rest = $number % 1000000;
    return receipt_amount_to_words($millions) . ' million' . ($rest ? ' ' . receipt_amount_to_words($rest) : '');
}

$wholeAmount = (int) floor($total_amount);
$centAmount = (int) round(($total_amount - $wholeAmount) * 100);
$amountInWords = ucwords(receipt_amount_to_words($wholeAmount)) . ' Pesos';
if ($centAmount > 0) {
    $amountInWords .= ' and ' . str_pad((string) $centAmount, 2, '0', STR_PAD_LEFT) . '/100';
}
$amountInWords .= ' Only';
$isLongReceipt = true;
$preparedBy = trim((string) ($first_payment['prepared_by'] ?? ''));
if ($preparedBy === '' && $isOldReceipt) {
    $preparedBy = 'Not Captured in Old Record';
} elseif ($preparedBy === '') {
    $preparedBy = trim((string) ($_SESSION['username'] ?? 'System'));
}
$legacyReferenceFallback = trim((string) ($first_payment['reference_number'] ?? ''));
if ($legacyReferenceFallback === '') {
    foreach ($payments as $paymentRow) {
        $legacyReferenceFallback = receipt_payment_methods_extract_reference_from_text((string) ($paymentRow['remarks'] ?? ''));
        if ($legacyReferenceFallback !== '') {
            break;
        }
    }
}
$methodBreakdown = receipt_payment_methods_for_display(
    $conn,
    (int) ($first_payment['booklet_no'] ?? 0),
    (int) $receipt_no,
    $registryEntry['used_by'] ?? null,
    (string) ($first_payment['receipt_note'] ?? ''),
    $legacyReferenceFallback,
    (string) ($first_payment['payment_note'] ?? '')
);
$isLegacyMethodBreakdown = receipt_payment_methods_is_legacy_placeholder($methodBreakdown);
$paymentMethodDisplay = receipt_payment_methods_display_label($methodBreakdown, 'Not specified');
$paymentMethodBreakdownDisplay = receipt_payment_methods_summary_text($methodBreakdown);
$paymentReferenceDisplay = receipt_payment_methods_reference_display($methodBreakdown, 'Not specified');
$paymentReferenceDisplay = $paymentReferenceDisplay === 'Not specified' && $legacyReferenceFallback !== ''
    ? $legacyReferenceFallback
    : $paymentReferenceDisplay;
$paymentNoteDisplay = receipt_payment_methods_note_display(
    $methodBreakdown,
    trim((string) (($first_payment['payment_note'] ?? '') !== '' ? $first_payment['payment_note'] : ($first_payment['receipt_note'] ?? '')))
);
$paymentNoteDisplay = $isLegacyMethodBreakdown && strcasecmp(trim((string) $paymentNoteDisplay), trim((string) $paymentMethodDisplay)) === 0
    ? 'Not specified'
    : $paymentNoteDisplay;
$paymentNoteDisplay = $paymentNoteDisplay !== '' ? $paymentNoteDisplay : 'Not specified';
$paymentMethodCount = count($methodBreakdown);
$paymentBreakdownLength = strlen($paymentMethodBreakdownDisplay);
$paymentReferenceLength = $paymentReferenceDisplay !== 'Not specified' ? strlen($paymentReferenceDisplay) : 0;
$paymentNoteLength = $paymentNoteDisplay !== 'Not specified' ? strlen($paymentNoteDisplay) : 0;
$useTwoUpLayout = true;
$useDenseTwoUpLayout = true;
$useCompactSummaryLayout = true;
$autoPrint = isset($_GET['autoprint']) && $_GET['autoprint'] === '1';
$autoDownloadImage = isset($_GET['download_image']) && $_GET['download_image'] === '1';
$csrfToken = ensure_csrf_token();
$receiptAuditDetails = sprintf(
    'Receipt No: %s | Booklet: %s | Student: %s',
    (string) $receipt_no,
    (string) $booklet_display,
    html_entity_decode($student_name, ENT_QUOTES, 'UTF-8')
);

function render_receipt_copy(string $copyLabel): void
{
    global $schoolLogo, $schoolName, $schoolContactLine, $receipt_no, $date_paid_formatted, $time_paid,
           $booklet_display, $void_status, $student_name, $first_payment, $payments, $total_amount,
           $amountInWords, $paymentMethodDisplay, $paymentMethodBreakdownDisplay, $paymentReferenceDisplay,
           $paymentNoteDisplay, $preparedBy, $receiptFooterNote, $useCompactSummaryLayout, $useDenseTwoUpLayout,
           $paymentMethodCount, $isLegacyMethodBreakdown;

    $normalizedMethodLabel = strtolower(trim((string) $paymentMethodDisplay));
    $normalizedBreakdown = strtolower(trim((string) $paymentMethodBreakdownDisplay));
    $normalizedReference = strtolower(trim((string) $paymentReferenceDisplay));
    $normalizedNote = strtolower(trim((string) $paymentNoteDisplay));
    $isSplitPayment = $paymentMethodCount > 1 || $normalizedMethodLabel === 'split payment';
    $showPaymentMethod = $paymentMethodDisplay !== '' && (!$isSplitPayment || $normalizedMethodLabel !== 'split payment');
    $showMethodBreakdown = !$isSplitPayment
        && !$isLegacyMethodBreakdown
        && $paymentMethodBreakdownDisplay !== ''
        && (!$showPaymentMethod || $normalizedBreakdown !== $normalizedMethodLabel);
    $showReference = $paymentReferenceDisplay !== 'Not specified'
        && $normalizedReference !== ''
        && $normalizedReference !== $normalizedBreakdown
        && $normalizedReference !== $normalizedNote;
    $showPaymentNote = $paymentNoteDisplay !== 'Not specified'
        && $normalizedNote !== ''
        && $normalizedNote !== $normalizedBreakdown
        && $normalizedNote !== $normalizedMethodLabel
        && $normalizedNote !== $normalizedReference;
    ?>
    <div class="receipt-copy">
        <div class="receipt-header">
            <img src="<?= htmlspecialchars($schoolLogo) ?>" alt="School Logo" class="school-logo">
            <div class="school-name"><?= htmlspecialchars($schoolName) ?></div>
            <div class="school-address"><?= htmlspecialchars($schoolContactLine !== '' ? $schoolContactLine : 'School contact details not set') ?></div>
            <div class="receipt-title">PAYMENT RECEIPT</div>
            <div class="receipt-number">Receipt No: <?= htmlspecialchars($receipt_no) ?></div>
            <div class="copy-tag"><?= htmlspecialchars($copyLabel) ?></div>
        </div>

        <div class="receipt-meta-grid">
            <div class="meta-card">
                <div class="meta-label">Date Issued</div>
                <div class="meta-value"><?= htmlspecialchars($date_paid_formatted) ?></div>
            </div>
            <div class="meta-card">
                <div class="meta-label">Time</div>
                <div class="meta-value"><?= htmlspecialchars($time_paid) ?></div>
            </div>
            <div class="meta-card">
                <div class="meta-label">Booklet No.</div>
                <div class="meta-value"><?= htmlspecialchars($booklet_display) ?></div>
            </div>
            <div class="meta-card">
                <div class="meta-label">Status</div>
                <div class="meta-value"><?= $void_status && $void_status['voided'] ? 'Voided' : 'Valid' ?></div>
            </div>
        </div>

        <?php if ($void_status && $void_status['voided']): ?>
            <div class="void-notice">
                VOIDED RECEIPT
                <div class="void-reason">
                    Reason: <?= htmlspecialchars($void_status['void_reason']) ?><br>
                    Date Voided: <?= htmlspecialchars($void_status['voided_at']) ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="section">
            <div class="section-title">Student Information</div>
            <div class="info-row">
                <span class="info-label">Name:</span>
                <span class="info-value"><?= $student_name ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">LRN:</span>
                <span class="info-value"><?= htmlspecialchars($first_payment['lrn'] ?: 'To follow') ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Grade:</span>
                <span class="info-value"><?= htmlspecialchars($first_payment['grade']) ?></span>
            </div>
        </div>

        <div class="section">
            <div class="section-title">
                <?= count($payments) === 1 ? 'Payment Item' : 'Payment Items' ?>
            </div>
            <table class="payments-table">
                <thead>
                    <tr>
                        <th class="payment-index">#</th>
                        <th class="payment-description">Description</th>
                        <th class="payment-amount">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $item_count = 0; ?>
                    <?php foreach ($payments as $payment): ?>
                        <?php $item_count++; ?>
                        <tr>
                            <td class="payment-index"><?= $item_count ?></td>
                            <td class="payment-description"><?= htmlspecialchars($payment['account_type']) ?></td>
                            <td class="payment-amount">PHP <?= number_format($payment['amount'], 2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="total-section">
            <?php if (count($payments) > 1): ?>
                <div class="subtotal-row">
                    <span>Number of Items:</span>
                    <span><?= count($payments) ?></span>
                </div>
            <?php endif; ?>
            <div class="total-row">
                <span>TOTAL AMOUNT PAID:</span>
                <span>PHP <?= number_format($total_amount, 2) ?></span>
            </div>
        </div>

        <?php if ($useCompactSummaryLayout): ?>
            <div class="payment-summary-card">
                <div class="payment-summary-row">
                    <div class="payment-summary-label">Amount In Words</div>
                    <div class="payment-summary-value"><?= htmlspecialchars($amountInWords) ?></div>
                </div>
                <?php if ($showPaymentMethod): ?>
                    <div class="payment-summary-row">
                        <div class="payment-summary-label">Payment Method</div>
                        <div class="payment-summary-value"><?= htmlspecialchars($paymentMethodDisplay) ?></div>
                    </div>
                <?php endif; ?>
                <?php if ($showMethodBreakdown): ?>
                    <div class="payment-summary-row">
                        <div class="payment-summary-label"><?= $isSplitPayment ? 'Payment Breakdown' : 'Method Breakdown' ?></div>
                        <div class="payment-summary-value"><?= htmlspecialchars($paymentMethodBreakdownDisplay) ?></div>
                    </div>
                <?php endif; ?>
                <?php if ($showReference): ?>
                    <div class="payment-summary-row">
                        <div class="payment-summary-label">Reference</div>
                        <div class="payment-summary-value"><?= htmlspecialchars($paymentReferenceDisplay) ?></div>
                    </div>
                <?php endif; ?>
                <?php if ($showPaymentNote): ?>
                    <div class="payment-summary-row">
                        <div class="payment-summary-label">Payment Note</div>
                        <div class="payment-summary-value"><?= htmlspecialchars($paymentNoteDisplay) ?></div>
                    </div>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="amount-words">
                <div class="amount-words-label">Amount In Words</div>
                <div class="amount-words-value"><?= htmlspecialchars($amountInWords) ?></div>
            </div>

            <?php if ($showPaymentMethod): ?>
                <div class="amount-words">
                    <div class="amount-words-label">Payment Method</div>
                    <div class="amount-words-value"><?= htmlspecialchars($paymentMethodDisplay) ?></div>
                </div>
            <?php endif; ?>

            <?php if ($showMethodBreakdown): ?>
                <div class="amount-words">
                    <div class="amount-words-label"><?= $isSplitPayment ? 'Payment Breakdown' : 'Method Breakdown' ?></div>
                    <div class="amount-words-value"><?= htmlspecialchars($paymentMethodBreakdownDisplay) ?></div>
                </div>
            <?php endif; ?>

            <?php if ($showReference): ?>
                <div class="amount-words">
                    <div class="amount-words-label">Reference</div>
                    <div class="amount-words-value"><?= htmlspecialchars($paymentReferenceDisplay) ?></div>
                </div>
            <?php endif; ?>

            <?php if ($showPaymentNote): ?>
                <div class="amount-words">
                    <div class="amount-words-label">Payment Note</div>
                    <div class="amount-words-value"><?= htmlspecialchars($paymentNoteDisplay) ?></div>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <div class="acknowledgement-block<?= $useDenseTwoUpLayout ? ' compact-acknowledgement-block' : '' ?>">
            <div>
                <div class="ack-line-label">Received From</div>
                <div class="ack-line-value"><?= $student_name ?></div>
            </div>
            <div>
                <div class="ack-line-label">Prepared By</div>
                <div class="ack-line-value"><?= htmlspecialchars($preparedBy) ?></div>
            </div>
        </div>

        <div class="footer">
            <p>This is a system-generated receipt.</p>
            <p>This is NOT an Official Receipt.</p>
            <p>Not valid for claim of input taxes.</p>
            <?php if ($receiptFooterNote !== ''): ?>
                <p style="font-size: 8px;"><?= htmlspecialchars($receiptFooterNote) ?></p>
            <?php endif; ?>
        </div>
    </div>
    <?php
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Receipt - <?= $receipt_no ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Outfit:wght@600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            width: 100%;
            margin: 0;
            padding: 0;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            color: #1a1a1a;
            -webkit-font-smoothing: antialiased;
        }

        body {
            background: #fafbfc;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px 10px;
        }

        @page {
            size: letter landscape;
            margin: 0.28in 0.28in 0.28in 0.34in;
        }

        @media print {
            * {
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
                color-adjust: exact !important;
                -webkit-filter: none !important;
                filter: none !important;
            }

            html, body {
                margin: 0 !important;
                padding: 0 !important;
                width: 100%;
                height: auto !important;
                min-height: 0 !important;
                background: white !important;
                display: block;
                align-items: auto;
                position: relative;
            }

            body > * {
                display: none !important;
            }

            body > .print-container {
                display: block !important;
            }

            .action-buttons-container {
                display: none !important;
            }

            .no-print {
                display: none !important;
            }

            .page-number {
                display: none !important;
            }

            .page {
                page-break-after: auto;
                page-break-inside: auto;
                page-break-before: auto;
                break-before: auto;
                break-after: auto;
                border: none;
                margin: 0;
                padding: 0;
                width: 100%;
                height: auto;
                background: white !important;
                display: block;
            }

            .two-up-page {
                display: flex !important;
                align-items: flex-start;
                justify-content: center;
                gap: 0.16in;
                min-height: auto;
            }

            .receipt-copy {
                flex: 0 0 calc((100% - 0.16in) / 2);
                max-width: calc((100% - 0.16in) / 2);
                break-inside: avoid;
                page-break-inside: avoid;
            }

            .cut-guide {
                display: none !important;
            }

            .print-container {
                background: white !important;
                height: auto;
                width: 100%;
                max-width: none;
                margin: 0 !important;
                padding: 0;
                display: block;
                box-shadow: none !important;
                page-break-before: auto;
                break-before: auto;
                position: absolute;
                top: 0;
                left: 0;
            }

            .section,
            .payments-table,
            .payments-table tbody {
                break-inside: auto;
                page-break-inside: auto;
            }

            .payments-table thead {
                display: table-header-group;
            }

            .payments-table tr,
            .payments-table td,
            .payments-table th,
            .total-section,
            .amount-words,
            .acknowledgement-block,
            .footer {
                break-inside: avoid;
                page-break-inside: avoid;
            }

            /* Force background colors on print */
            .section-title {
                background: linear-gradient(135deg, #1f2937 0%, #111827 100%) !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            .payments-table th {
                background: linear-gradient(135deg, #1f2937 0%, #111827 100%) !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            .total-section {
                background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%) !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }
        }

        .print-container {
            width: 100%;
            max-width: 10.3in;
            height: auto;
            margin: 0 auto;
            padding: 0;
            background: white;
            font-size: 12px;
            line-height: 1.5;
            overflow: visible;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        /* Page Break Styles */
        .page {
            width: 100%;
            height: auto;
            page-break-after: auto;
            page-break-inside: auto;
            display: block;
            border: 1px solid #e5e7eb;
            padding: 0.14in 0.16in;
            margin-bottom: 8px;
            background: white;
            border-radius: 4px;
        }

        .page:first-child,
        .print-container:first-child {
            margin-top: 0;
        }

        .two-up-page {
            position: relative;
            display: flex;
            align-items: flex-start;
            justify-content: center;
            gap: 0.16in;
        }

        .receipt-copy {
            flex: 0 0 calc((100% - 0.16in) / 2);
            max-width: calc((100% - 0.16in) / 2);
            border: 1px solid #d7dee7;
            border-radius: 4px;
            padding: 0.14in 0.15in 0.12in;
            background: white;
            min-width: 0;
        }

        .single-receipt-page .receipt-copy {
            flex: none;
            width: 100%;
            max-width: 100%;
        }

        .single-receipt-page {
            max-width: 6.4in;
            margin-left: auto;
            margin-right: auto;
        }

        .dense-two-up .receipt-copy {
            padding: 0.11in 0.12in 0.1in;
        }

        .dense-two-up .receipt-header {
            padding-bottom: 0.05in;
            margin-bottom: 0.07in;
            padding-top: 0.06in;
        }

        .dense-two-up .school-logo {
            max-width: 0.42in;
            margin-bottom: 0.025in;
        }

        .dense-two-up .school-name {
            font-size: 11.5px;
            margin-bottom: 0.022in;
        }

        .dense-two-up .school-address {
            font-size: 6.7px;
            margin-bottom: 0.035in;
        }

        .dense-two-up .receipt-title {
            font-size: 13px;
            margin: 0.03in 0 0.015in;
        }

        .dense-two-up .receipt-number {
            font-size: 9.5px;
            margin-bottom: 0.02in;
        }

        .dense-two-up .copy-tag {
            margin-top: 0.025in;
            padding: 0.016in 0.07in;
            font-size: 7.6px;
        }

        .dense-two-up .receipt-meta-grid {
            gap: 0.025in;
            margin: 0.035in 0 0.05in;
        }

        .dense-two-up .meta-card {
            padding: 0.03in;
        }

        .dense-two-up .meta-label {
            font-size: 6.5px;
            margin-bottom: 0.012in;
        }

        .dense-two-up .meta-value {
            font-size: 8.1px;
        }

        .dense-two-up .section {
            margin-bottom: 0.055in;
        }

        .dense-two-up .section-title {
            font-size: 8.7px;
            padding-top: 0.032in;
            padding-bottom: 0.032in;
            margin-bottom: 0.025in;
        }

        .dense-two-up .info-row {
            padding-top: 0.022in;
            padding-bottom: 0.022in;
            font-size: 8.1px;
            line-height: 1.2;
        }

        .dense-two-up .info-label,
        .dense-two-up .info-value {
            font-size: 8px;
        }

        .cut-guide {
            position: absolute;
            top: 0;
            bottom: 0;
            left: calc(50% - 0.5px);
            width: 0;
            border-left: 1px dashed #9ca3af;
            pointer-events: none;
        }

        .page:last-child {
            page-break-after: auto;
            border: 1px solid #e5e7eb;
            margin-bottom: 0;
        }

        .receipt-header {
            text-align: center;
            border-bottom: 3px solid #1f2937;
            padding-bottom: 0.07in;
            margin-bottom: 0.1in;
            margin-left: -0.18in;
            margin-right: -0.18in;
            margin-top: -0.16in;
            padding-top: 0.08in;
            padding-left: 0.18in;
            padding-right: 0.18in;
            background: linear-gradient(180deg, #ffffff 0%, #f9fafb 100%);
        }

        .school-logo {
            max-width: 0.5in;
            height: auto;
            margin: 0 auto 0.04in;
            display: block;
            filter: drop-shadow(0 2px 4px rgba(0,0,0,0.08));
        }

        .school-name {
            font-size: 13px;
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 0.035in;
            letter-spacing: -0.15px;
            font-family: 'Outfit', sans-serif;
        }

        .school-address {
            font-size: 7.5px;
            color: #6b7280;
            margin-bottom: 0.055in;
            font-weight: 500;
        }

        .receipt-title {
            font-size: 15px;
            font-weight: 800;
            color: #1f2937;
            margin: 0.045in 0 0.025in;
            letter-spacing: 0.2px;
            font-family: 'Outfit', sans-serif;
        }

        .receipt-number {
            font-size: 10.5px;
            color: #374151;
            font-weight: 700;
            margin-bottom: 0.035in;
        }

        .copy-tag {
            display: inline-block;
            margin-top: 0.04in;
            padding: 0.022in 0.09in;
            border: 1px solid #94a3b8;
            border-radius: 999px;
            font-size: 8.5px;
            font-weight: 700;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            color: #1e293b;
            background: #f8fafc;
        }

        .receipt-meta-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 0.04in;
            margin: 0.05in 0 0.07in;
        }

        .meta-card {
            border: 1px solid #dbe2ea;
            background: #f8fafc;
            border-radius: 6px;
            padding: 0.045in;
        }

        .meta-label {
            font-size: 7.2px;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            color: #6b7280;
            font-weight: 700;
            margin-bottom: 0.02in;
        }

        .meta-value {
            font-size: 9.4px;
            color: #111827;
            font-weight: 700;
            word-break: break-word;
        }

        .section {
            margin-bottom: 0.08in;
        }

        .section-title {
            font-size: 10.2px;
            font-weight: 700;
            color: #ffffff !important;
            background: linear-gradient(135deg, #1f2937 0%, #111827 100%);
            padding: 0.045in 0.045in;
            margin-bottom: 0.04in;
            margin-left: -0.18in;
            margin-right: -0.18in;
            padding-left: 0.22in;
            padding-right: 0.22in;
            text-transform: uppercase;
            letter-spacing: 0.7px;
            border-radius: 4px 4px 0 0;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
            font-family: 'Outfit', sans-serif;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 0.032in 0.05in;
            border-bottom: 1px solid #f3f4f6;
            font-size: 9px;
            line-height: 1.35;
            background: #fafbfc;
        }

        .info-row:nth-child(even) {
            background: #ffffff;
        }

        .info-row:last-child {
            border-bottom: none;
        }

        .info-label {
            font-weight: 700;
            color: #374151;
            min-width: 1in;
            font-size: 9px;
        }

        .info-value {
            text-align: right;
            flex-grow: 1;
            padding-left: 0.1in;
            color: #111827;
            font-weight: 600;
        }

        .amount-words {
            margin-top: 0.05in;
            background: #fff;
            border: 1px dashed #9ca3af;
            border-radius: 6px;
            padding: 0.045in 0.06in;
        }

        .amount-words-label {
            font-size: 8.2px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #6b7280;
            margin-bottom: 0.025in;
        }

        .amount-words-value {
            font-size: 9.3px;
            font-weight: 700;
            color: #111827;
            line-height: 1.3;
        }

        .payment-summary-card {
            margin-top: 0.045in;
            border: 1px solid #d6dde6;
            border-radius: 6px;
            background: #fbfcfe;
            overflow: hidden;
        }

        .payment-summary-row {
            padding: 0.04in 0.06in;
            border-bottom: 1px solid #e5e7eb;
        }

        .payment-summary-row:last-child {
            border-bottom: none;
        }

        .payment-summary-label {
            font-size: 7.8px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #6b7280;
            margin-bottom: 0.015in;
        }

        .payment-summary-value {
            font-size: 9px;
            font-weight: 600;
            color: #111827;
            line-height: 1.25;
        }

        .acknowledgement-block {
            margin-top: 0.07in;
            border-top: 1px solid #d1d5db;
            padding-top: 0.06in;
            display: grid;
            grid-template-columns: 1.2fr 1fr;
            gap: 0.08in;
            align-items: end;
        }

        .ack-line-label {
            font-size: 8.2px;
            text-transform: uppercase;
            color: #6b7280;
            letter-spacing: 0.06em;
            margin-bottom: 0.02in;
            font-weight: 700;
        }

        .ack-line-value {
            font-size: 9.2px;
            color: #111827;
            min-height: 0.14in;
            border-bottom: 1px solid #9ca3af;
            padding-bottom: 0.02in;
            font-weight: 700;
        }

        .payments-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0.04in 0;
            background: white;
            border: 1px solid #e5e7eb;
            font-size: 9px;
            border-radius: 6px;
            overflow: visible;
        }

        .payments-table th {
            background: linear-gradient(135deg, #1f2937 0%, #111827 100%);
            color: #ffffff !important;
            padding: 0.045in 0.05in;
            text-align: left;
            font-size: 8.7px;
            font-weight: 700;
            border: 1px solid #1a2535;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
            letter-spacing: 0.03em;
        }

        .payments-table td {
            padding: 0.04in 0.05in;
            border-bottom: 1px solid #e5e7eb;
            font-size: 8.9px;
            border-right: 1px solid #e5e7eb;
        }

        .payments-table td:last-child {
            border-right: none;
        }

        .payments-table tr:nth-child(even) td {
            background-color: #f9fafb;
        }

        .payments-table tr:last-child td {
            border-bottom: none;
        }

        .dense-two-up .payments-table {
            margin: 0.025in 0;
        }

        .dense-two-up .payments-table th {
            padding-top: 0.028in;
            padding-bottom: 0.028in;
            font-size: 7.7px;
        }

        .dense-two-up .payments-table td {
            padding-top: 0.024in;
            padding-bottom: 0.024in;
            font-size: 7.8px;
        }

        .payment-index {
            font-weight: 700;
            color: #1f2937;
            width: 0.3in;
            text-align: center;
        }

        .dense-two-up .payment-index {
            width: 0.22in;
        }

        .payment-description {
            flex-grow: 1;
            font-weight: 500;
        }

        .payment-amount {
            text-align: right;
            font-weight: 700;
            color: #1f2937;
            min-width: 0.8in;
        }

        .dense-two-up .payment-amount {
            min-width: 0.68in;
        }

        .total-section {
            background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%);
            border: 2px solid #d1d5db;
            padding: 0.06in 0.05in;
            margin: 0.05in -0.18in;
            padding-left: 0.22in;
            padding-right: 0.22in;
            border-radius: 6px;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        .total-row {
            display: flex;
            justify-content: space-between;
            padding: 0.06in 0;
            font-size: 11px;
            font-weight: 800;
            color: #1f2937;
            border-top: 2px solid #9ca3af;
            padding-top: 0.05in;
            margin-top: 0.05in;
            font-family: 'Outfit', sans-serif;
            letter-spacing: 0.02em;
        }

        .subtotal-row {
            display: flex;
            justify-content: space-between;
            padding: 0.03in 0;
            font-size: 9px;
            color: #6b7280;
            margin-bottom: 0.03in;
            border-bottom: 1px solid #d1d5db;
            padding-bottom: 0.03in;
            font-weight: 500;
        }

        .dense-two-up .total-section {
            padding-top: 0.04in;
            padding-bottom: 0.04in;
            margin-top: 0.03in;
            margin-bottom: 0.03in;
        }

        .dense-two-up .subtotal-row {
            padding-top: 0.02in;
            padding-bottom: 0.02in;
            font-size: 7.6px;
            margin-bottom: 0.02in;
        }

        .dense-two-up .total-row {
            font-size: 9.6px;
            padding-top: 0.035in;
            padding-bottom: 0.035in;
            margin-top: 0.03in;
        }

        .dense-two-up .payment-summary-card {
            margin-top: 0.03in;
        }

        .dense-two-up .payment-summary-row {
            padding: 0.028in 0.045in;
        }

        .dense-two-up .payment-summary-label {
            font-size: 6.8px;
            margin-bottom: 0.01in;
        }

        .dense-two-up .payment-summary-value {
            font-size: 7.9px;
            line-height: 1.15;
        }

        .dense-two-up .compact-acknowledgement-block {
            margin-top: 0.04in;
            padding-top: 0.04in;
            gap: 0.05in;
        }

        .dense-two-up .ack-line-label {
            font-size: 7px;
            margin-bottom: 0.012in;
        }

        .dense-two-up .ack-line-value {
            font-size: 7.9px;
            min-height: 0.1in;
            padding-bottom: 0.012in;
        }

        .dense-two-up .footer {
            margin-top: 0.04in;
            padding-top: 0.03in;
            font-size: 7.1px;
            line-height: 1.22;
        }

        .footer {
            text-align: center;
            margin-top: 0.07in;
            padding-top: 0.05in;
            border-top: 1px solid #e5e7eb;
            font-size: 8.2px;
            color: #6b7280;
            line-height: 1.4;
        }

        .receipt-compact .payments-table th,
        .receipt-compact .payments-table td {
            padding-top: 0.035in;
            padding-bottom: 0.035in;
            font-size: 8px;
        }

        .receipt-compact .section {
            margin-bottom: 0.06in;
        }

        .receipt-compact .receipt-header {
            margin-bottom: 0.08in;
        }

        .receipt-compact .section-title {
            font-size: 9px;
            padding-top: 0.04in;
            padding-bottom: 0.04in;
        }

        .receipt-compact .info-row {
            padding-top: 0.03in;
            padding-bottom: 0.03in;
        }

        .receipt-compact .amount-words,
        .receipt-compact .acknowledgement-block,
        .receipt-compact .footer {
            margin-top: 0.045in;
        }

        .receipt-compact .payment-summary-card {
            margin-top: 0.04in;
        }

        .receipt-compact .payment-summary-row {
            padding-top: 0.032in;
            padding-bottom: 0.032in;
        }

        .receipt-compact .payment-summary-label {
            font-size: 7.2px;
        }

        .receipt-compact .payment-summary-value {
            font-size: 8.4px;
        }

        .footer p {
            margin: 0.025in 0;
        }

        .dense-two-up .footer p {
            margin: 0.015in 0;
        }

        .void-notice {
            background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
            border: 2px solid #fbbf24;
            padding: 0.1in;
            text-align: center;
            margin: 0.08in 0;
            font-weight: 600;
            color: #92400e;
            font-size: 11px;
            border-radius: 4px;
        }

        .void-reason {
            font-size: 9px;
            margin-top: 0.04in;
            color: #78350f;
        }

        /* Action Buttons Styles (no-print) */
        .action-buttons-container {
            display: flex;
            justify-content: center;
            gap: 12px;
            margin-top: 30px;
            margin-bottom: 30px;
            padding: 20px;
            flex-wrap: wrap;
            width: 100%;
        }

        .action-button {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            font-family: 'Inter', sans-serif;
        }

        .btn-print {
            background: #10b981;
            color: white;
            border: 2px solid #10b981;
        }

        .btn-print:hover {
            background: #059669;
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.25);
            transform: translateY(-1px);
        }

        .btn-download {
            background: #3b82f6;
            color: white;
            border: 2px solid #3b82f6;
        }

        .btn-download:hover {
            background: #2563eb;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.25);
            transform: translateY(-1px);
        }

        .btn-back {
            background: #6b7280;
            color: white;
            border: 2px solid #6b7280;
        }

        .btn-back:hover {
            background: #4b5563;
            box-shadow: 0 4px 12px rgba(107, 114, 128, 0.25);
            transform: translateY(-1px);
        }

        @media (max-width: 600px) {
            html, body {
                width: 100%;
                height: auto;
            }

            .print-container {
                width: 95vw;
                max-width: 100%;
            }

            .page {
                width: 95vw;
                max-width: 100%;
            }

            .two-up-page {
                grid-template-columns: 1fr;
            }

            .cut-guide {
                display: none;
            }

            .receipt-meta-grid,
            .acknowledgement-block {
                grid-template-columns: 1fr;
            }

            .action-buttons-container {
                flex-direction: column;
                gap: 10px;
            }

            .action-button {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
<div class="print-container<?= $isLongReceipt ? ' receipt-compact' : '' ?><?= $useDenseTwoUpLayout ? ' dense-two-up' : '' ?>">
    <div class="page two-up-page">
        <?php if ($useTwoUpLayout): ?>
            <div class="cut-guide" aria-hidden="true"></div>
            <?php render_receipt_copy('Student / Parent Copy'); ?>
            <?php render_receipt_copy('School Copy'); ?>
        <?php else: ?>
            <?php render_receipt_copy('Receipt Copy'); ?>
        <?php endif; ?>
<?php /*
        <div class="receipt-header">
            <img src="<?= htmlspecialchars($schoolLogo) ?>" alt="School Logo" class="school-logo">
            <div class="school-name"><?= htmlspecialchars($schoolName) ?></div>
            <div class="school-address"><?= htmlspecialchars($schoolContactLine !== '' ? $schoolContactLine : 'School contact details not set') ?></div>
            <div class="receipt-title">PAYMENT RECEIPT</div>
            <div class="receipt-number">Receipt No: <?= htmlspecialchars($receipt_no) ?></div>
        </div>

        <div class="receipt-meta-grid">
            <div class="meta-card">
                <div class="meta-label">Date Issued</div>
                <div class="meta-value"><?= htmlspecialchars($date_paid_formatted) ?></div>
            </div>
            <div class="meta-card">
                <div class="meta-label">Time</div>
                <div class="meta-value"><?= htmlspecialchars($time_paid) ?></div>
            </div>
            <div class="meta-card">
                <div class="meta-label">Booklet No.</div>
                <div class="meta-value"><?= htmlspecialchars($booklet_display) ?></div>
            </div>
            <div class="meta-card">
                <div class="meta-label">Status</div>
                <div class="meta-value"><?= $void_status && $void_status['voided'] ? 'Voided' : 'Valid' ?></div>
            </div>
        </div>

        <!-- Void Notice (if voided) -->
        <?php if ($void_status && $void_status['voided']): ?>
            <div class="void-notice">
                ⚠️ VOIDED RECEIPT
                <div class="void-reason">
                    Reason: <?= htmlspecialchars($void_status['void_reason']) ?><br>
                    Date Voided: <?= htmlspecialchars($void_status['voided_at']) ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Student Information -->
        <div class="section">
            <div class="section-title">Student Information</div>
            <div class="info-row">
                <span class="info-label">Name:</span>
                <span class="info-value"><?= $student_name ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">LRN:</span>
                <span class="info-value"><?= htmlspecialchars($first_payment['lrn'] ?: 'To follow') ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Grade:</span>
                <span class="info-value"><?= htmlspecialchars($first_payment['grade']) ?></span>
            </div>
        </div>

        <!-- Items List Table -->
        <div class="section">
            <div class="section-title">
                <?= count($payments) === 1 ? 'Payment Item' : 'Payment Items' ?>
            </div>
            <table class="payments-table">
                <thead>
                    <tr>
                        <th class="payment-index">#</th>
                        <th class="payment-description">Description</th>
                        <th class="payment-amount">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $item_count = 0;
                    foreach ($payments as $payment): 
                        $item_count++;
                    ?>
                    <tr>
                        <td class="payment-index"><?= $item_count ?></td>
                        <td class="payment-description"><?= htmlspecialchars($payment['account_type']) ?></td>
                        <td class="payment-amount">PHP <?= number_format($payment['amount'], 2) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Total Amount Section (LAST PART - NO STATUS BELOW) -->
        <div class="total-section">
            <?php if (count($payments) > 1): ?>
                <div class="subtotal-row">
                    <span>Number of Items:</span>
                    <span><?= count($payments) ?></span>
                </div>
            <?php endif; ?>
            <div class="total-row">
                <span>TOTAL AMOUNT PAID:</span>
                <span>PHP <?= number_format($total_amount, 2) ?></span>
            </div>
        </div>
        <div class="amount-words">
            <div class="amount-words-label">Amount In Words</div>
            <div class="amount-words-value"><?= htmlspecialchars($amountInWords) ?></div>
        </div>

        <div class="amount-words">
            <div class="amount-words-label">Payment Method</div>
            <div class="amount-words-value"><?= htmlspecialchars($paymentMethodDisplay) ?></div>
        </div>

        <?php if ($paymentMethodBreakdownDisplay !== ''): ?>
            <div class="amount-words">
                <div class="amount-words-label">Method Breakdown</div>
                <div class="amount-words-value"><?= htmlspecialchars($paymentMethodBreakdownDisplay) ?></div>
            </div>
        <?php endif; ?>

        <?php if ($paymentReferenceDisplay !== 'Not specified'): ?>
            <div class="amount-words">
                <div class="amount-words-label">Reference</div>
                <div class="amount-words-value"><?= htmlspecialchars($paymentReferenceDisplay) ?></div>
            </div>
        <?php endif; ?>

        <?php if ($paymentNoteDisplay !== 'Not specified'): ?>
            <div class="amount-words">
                <div class="amount-words-label">Payment Note</div>
                <div class="amount-words-value"><?= htmlspecialchars($paymentNoteDisplay) ?></div>
            </div>
        <?php endif; ?>

        <div class="acknowledgement-block">
            <div>
                <div class="ack-line-label">Received From</div>
                <div class="ack-line-value"><?= $student_name ?></div>
            </div>
            <div>
                <div class="ack-line-label">Prepared By</div>
                <div class="ack-line-value"><?= htmlspecialchars($preparedBy) ?></div>
            </div>
        </div>

        <div class="footer">
            <p>This is a system-generated receipt.</p>
            <p>This is NOT an Official Receipt.</p>
            <p>Not valid for claim of input taxes.</p>
            <?php if ($receiptFooterNote !== ''): ?>
                <p style="font-size: 8px;"><?= htmlspecialchars($receiptFooterNote) ?></p>
            <?php endif; ?>
        </div>
*/ ?>
    </div>

</div>

<!-- Action Buttons (no-print) -->
<div class="action-buttons-container no-print">
    <button class="action-button btn-print" type="button" onclick="logReceiptPrint()" title="Print this receipt">
        Print Receipt
    </button>
    <button class="action-button btn-download" type="button" onclick="downloadReceiptImage()" title="Download receipt as JPG">
        Download Receipt Image
    </button>
    <a href="account-payment-history.php?student_id=<?= htmlspecialchars($student_id) ?>" class="action-button btn-back" title="Back to Payment History">
        Back to History
    </a>
</div>

<script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>
<script>
function auditClientEvent(actionKind, label, fileName, details) {
    const formData = new FormData();
    formData.append('csrf_token', <?= json_encode($csrfToken) ?>);
    formData.append('action_kind', actionKind);
    formData.append('label', label || '');
    formData.append('file_name', fileName || '');
    formData.append('details', details || '');

    if (navigator.sendBeacon) {
        return navigator.sendBeacon('/school-admin-dashboard/modules/audit/audit-client-event.php', formData);
    }

    fetch('/school-admin-dashboard/modules/audit/audit-client-event.php', {
        method: 'POST',
        body: formData,
        credentials: 'same-origin',
        keepalive: true
    }).catch(function () {});

    return true;
}

function logReceiptPrint() {
    auditClientEvent('receipt_print', 'Receipt Print', '', <?= json_encode($receiptAuditDetails) ?>);
    window.print();
}

function downloadReceiptImage() {
    const receiptNode = document.querySelector('.print-container');
    if (!receiptNode || typeof html2canvas !== 'function') {
        alert('Receipt image download is not available right now.');
        return;
    }

    html2canvas(receiptNode, {
        backgroundColor: '#ffffff',
        scale: 2,
        useCORS: true,
        logging: false
    }).then(function (canvas) {
        auditClientEvent(
            'receipt_image_download',
            'Receipt Image Download',
            'receipt-<?= (int) $receipt_no ?>.jpg',
            <?= json_encode($receiptAuditDetails) ?>
        );
        const link = document.createElement('a');
        link.download = 'receipt-<?= (int) $receipt_no ?>.jpg';
        link.href = canvas.toDataURL('image/jpeg', 0.95);
        link.click();
    }).catch(function () {
        alert('Unable to generate receipt image.');
    });
}
</script>

<?php if ($autoPrint): ?>
<script>
window.addEventListener('load', function () {
    logReceiptPrint();
});
</script>
<?php endif; ?>

<?php if ($autoDownloadImage): ?>
<script>
window.addEventListener('load', function () {
    setTimeout(downloadReceiptImage, 150);
});
</script>
<?php endif; ?>

</body>
</html>
<?php
$conn->close();
?>

