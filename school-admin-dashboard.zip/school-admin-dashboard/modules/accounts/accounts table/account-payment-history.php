<?php
require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../../includes/admin-nav.php';
require_once __DIR__ . '/../../../includes/admin-page-header.php';
include '../../../config/database.php';
include '../../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../../settings/school-year-helper.php';
require_once __DIR__ . '/../account-followup-helper.php';
require_once __DIR__ . '/../finance-adjustment-helper.php';
include_once __DIR__ . '/../../audit/audit-helper.php';

$student_id = isset($_GET['student_id']) ? intval($_GET['student_id']) : 0;
$school_year_filter = trim($_GET['school_year'] ?? '');
$error = "";
$csrfToken = admin_csrf_token();
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
account_followup_ensure_tables($conn);
$active_school_year_label = school_year_get_active_label($conn);

$currentRole = $_SESSION['role'] ?? '';
$username = (string) ($_SESSION['username'] ?? 'System');
$can_view = hasPermission($currentRole, 'financial', 'view');
if (!$can_view) admin_session_forbidden();
$can_manage_followups = hasPermission($currentRole, 'financial', 'add')
    || hasPermission($currentRole, 'financial', 'edit')
    || hasPermission($currentRole, 'account_mgmt', 'add')
    || hasPermission($currentRole, 'account_mgmt', 'edit')
    || is_super_admin_role($currentRole)
    || is_administrator_role($currentRole);
$can_manage_active_guide = is_super_admin_role($currentRole) || is_administrator_role($currentRole);

$student_name = '';
$student_grade = '';
$student_school_year = '';
if ($student_id) {
    $stud_stmt = $conn->prepare("SELECT CONCAT(lastname, ', ', firstname, ' ', middlename) AS student_name, grade, school_year_label FROM students WHERE id = ?");
    $stud_stmt->bind_param("i", $student_id);
    $stud_stmt->execute();
    $stud_stmt->bind_result($student_name, $student_grade, $student_school_year);
    if (!$stud_stmt->fetch()) $error = "Student not found.";
    $stud_stmt->close();
} else {
    $error = "Invalid student ID.";
}
$selected_school_year = $school_year_filter !== '' ? $school_year_filter : ($student_school_year ?: $active_school_year_label);
$followup_message = '';
$followup_message_type = 'success';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $student_id > 0 && isset($_POST['account_followup_action'])) {
    if (!$can_manage_followups) {
        $followup_message = 'You do not have permission to update follow-up notes.';
        $followup_message_type = 'danger';
    } else {
        admin_require_post_csrf();
        $action = (string) ($_POST['account_followup_action'] ?? '');
        if ($action === 'add_note') {
            if (account_followup_add_note($conn, $student_id, $_POST, $username)) {
                $followup_message = 'Follow-up note added.';
                audit_log($conn, $username, 'Added account follow-up note', 'Accounts', 'Student ID: ' . $student_id . ' | Student: ' . $student_name, 'INFO');
            } else {
                $followup_message = 'Follow-up note could not be added. Enter note details and try again.';
                $followup_message_type = 'danger';
            }
        } elseif ($action === 'resolve_note') {
            $noteId = (int) ($_POST['note_id'] ?? 0);
            if ($noteId > 0 && account_followup_resolve_note($conn, $noteId, $student_id, $username)) {
                $followup_message = 'Follow-up note marked as resolved.';
                audit_log($conn, $username, 'Resolved account follow-up note', 'Accounts', 'Student ID: ' . $student_id . ' | Note ID: ' . $noteId, 'INFO');
            } else {
                $followup_message = 'Follow-up note could not be resolved.';
                $followup_message_type = 'danger';
            }
        } elseif ($action === 'set_active_template') {
            if (!$can_manage_active_guide) {
                $followup_message = 'Only Super Admin or Administrator can change the active account guide.';
                $followup_message_type = 'danger';
            } else {
                $templateId = trim((string) ($_POST['active_template_id'] ?? ''));
                $templateValue = $templateId !== '' ? (int) $templateId : null;
                if (account_followup_set_active_template($conn, $student_id, $templateValue, $username)) {
                    $followup_message = $templateValue ? 'Active account guide updated.' : 'Active account guide cleared.';
                    audit_log($conn, $username, 'Updated active account follow-up guide', 'Accounts', 'Student ID: ' . $student_id . ' | Template ID: ' . (string) ($templateValue ?? 'none'), 'INFO');
                } else {
                    $followup_message = 'Active account guide could not be updated.';
                    $followup_message_type = 'danger';
                }
            }
        }
    }
}
$followup_tables_ready = account_followup_tables_ready($conn);
$followup_templates = $followup_tables_ready ? account_followup_templates($conn, true) : [];
$active_followup_template = $followup_tables_ready && $student_id > 0 ? account_followup_active_template($conn, $student_id) : null;
$active_followup_template_id = $active_followup_template ? (int) $active_followup_template['active_template_id'] : 0;
$followup_notes = $followup_tables_ready && $student_id > 0 ? account_followup_notes($conn, $student_id) : [];
$followup_counts = account_followup_status_counts($followup_notes);
$finance_adjustment_tables_ready = finance_adjustment_tables_ready($conn);
$finance_adjustment_rows = $finance_adjustment_tables_ready && $student_id > 0 ? finance_adjustment_applied_rows($conn, $student_id, $selected_school_year) : [];
$finance_adjustment_applied_count = 0;
$finance_adjustment_reverted_count = 0;
$finance_adjustment_total_effect = 0.0;
foreach ($finance_adjustment_rows as $financeAdjustmentRow) {
    if ((string) ($financeAdjustmentRow['status'] ?? '') === 'applied') {
        $finance_adjustment_applied_count++;
    } else {
        $finance_adjustment_reverted_count++;
    }
    foreach (($financeAdjustmentRow['snapshot']['items'] ?? []) as $financeAdjustmentItem) {
        if (($financeAdjustmentItem['account_action'] ?? '') !== '') {
            $finance_adjustment_total_effect += (float) ($financeAdjustmentItem['applied_amount'] ?? 0);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Desk | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --navbar-bg: #23395d;
            --window-bg: #fff;
        }
        body {
            background: var(--main-bg);
        }
        .history-shell {
            width: min(1760px, calc(100vw - 16px));
            margin: 0 auto;
        }
        .navbar {
            background: var(--navbar-bg) !important;
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
        }
        .dashboard-header {
            text-align: center;
            margin-top: 32px;
            margin-bottom: 16px;
        }
        .dashboard-header img {
            width: 60px;
            height: 60px;
            object-fit: contain;
            margin-bottom: 6px;
        }
        .dashboard-header h1 {
            font-size: 1.1rem;
            color: #23395d;
            font-weight: 700;
            margin-bottom: 0;
        }
        .student-name-display {
            font-size: 1.5rem;
            font-weight: bold;
            text-align: center;
            margin-bottom: .6rem;
        }
        .tab-btn {
            min-width: 170px;
        }
        .tab-btn.active {
            font-weight: bold;
            border-bottom: 3px solid #198754;
        }
        .tab-window {
            background: var(--window-bg);
            border-radius: 12px;
            box-shadow: 0 2px 16px rgba(0,0,0,0.06);
            margin-bottom: 32px;
            padding: 18px 12px 18px 12px;
            min-height: 340px;
            border: 2px solid #c9d3e3;
        }
        .tabs-bar {
            display: flex;
            justify-content: center;
            gap: 24px;
            margin-bottom: 24px;
        }
        @media (max-width: 600px) {
            .tab-window { padding: 16px 6px; }
        }
        /* View Wave 6: legacy detail polish */
        :root {
            --vw-page-bg:#eef3f9;
            --vw-card-bg:#ffffff;
            --vw-card-border:#d9e3ef;
            --vw-brand-dark:#23395d;
            --vw-brand-mid:#517fa4;
            --vw-brand-soft:#edf4fb;
            --vw-text-soft:#5f7186;
        }
        body {
            background:
                radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 30%),
                linear-gradient(180deg, #f8fbff 0%, var(--vw-page-bg) 100%);
            color: var(--vw-brand-dark);
        }
        .dashboard-header img {
            width:72px;
            height:72px;
            border-radius:18px;
            background:#fff;
            padding:6px;
            box-shadow:0 10px 25px rgba(35,57,93,0.12);
        }
        .dashboard-header h1 { font-weight:800; color: var(--vw-brand-dark); }
        .student-name-display { color: var(--vw-brand-dark); font-weight:800; }
        .tabs-bar {
            background:#fff;
            border:1px solid var(--vw-card-border);
            border-radius:18px;
            padding:12px;
            box-shadow:0 10px 24px rgba(35,57,93,0.06);
        }
        .tab-btn {
            border-radius:12px;
            font-weight:700;
            border-color:#d7e1ed !important;
        }
        .tab-btn.active {
            background:var(--vw-brand-dark);
            color:#fff;
            border-bottom:none;
        }
        .tab-window {
            background: var(--vw-card-bg);
            border:1px solid var(--vw-card-border);
            border-radius:20px;
            box-shadow:0 14px 32px rgba(35,57,93,0.07);
            min-height:340px;
        }
        .followup-panel {
            background:#fff;
            border:1px solid var(--vw-card-border);
            border-radius:20px;
            box-shadow:0 14px 32px rgba(35,57,93,0.07);
            margin-bottom:36px;
            padding:18px;
        }
        .followup-template-tabs {
            display:flex;
            flex-wrap:wrap;
            gap:6px;
            padding:6px;
            background:#f6f8fb;
            border:1px solid #e3ebf5;
            border-radius:14px;
            margin-bottom:10px;
        }
        .followup-template-btn {
            border-radius:10px;
            font-weight:700;
            font-size:.9rem;
            padding:7px 11px;
            border:1px solid transparent !important;
            background:transparent;
            color:#3b5875;
        }
        .followup-template-btn.btn-primary,
        .followup-template-btn.active {
            background:#23395d;
            color:#fff;
            box-shadow:0 6px 14px rgba(35,57,93,.16);
        }
        .followup-template-btn.btn-outline-primary:hover {
            background:#eaf2fb;
            color:#23395d;
        }
        .followup-template-btn.locked {
            opacity:.42;
            cursor:not-allowed;
            box-shadow:none;
        }
        .active-guide-box {
            background:#fff;
            border:1px solid #e2eaf5;
            border-radius:16px;
            padding:14px;
            margin-bottom:12px;
            box-shadow:0 8px 18px rgba(35,57,93,.05);
        }
        .active-guide-label {
            font-size:.75rem;
            text-transform:uppercase;
            letter-spacing:.06em;
            color:#6a7d92;
            font-weight:800;
            margin-bottom:4px;
        }
        .active-guide-title {
            font-size:1.12rem;
            font-weight:800;
            color:#23395d;
        }
        .active-guide-pill {
            display:inline-flex;
            align-items:center;
            gap:6px;
            padding:5px 9px;
            border-radius:999px;
            background:#ecfdf3;
            border:1px solid #abefc6;
            color:#067647;
            font-size:.78rem;
            font-weight:800;
            margin-top:8px;
        }
        .active-guide-empty {
            background:#f8fafc;
            border-color:#e2e8f0;
            color:#64748b;
        }
        .active-guide-form {
            background:#f8fbff;
            border:1px solid #e2eaf5;
            border-radius:12px;
            padding:8px;
        }
        .followup-template-content {
            background:#fbfdff;
            border:1px solid #e2eaf5;
            border-left:4px solid #517fa4;
            border-radius:14px;
            padding:14px 15px;
            white-space:pre-line;
            color:#30465f;
            line-height:1.55;
        }
        .followup-note-card {
            border:1px solid #dbe7f4;
            border-radius:14px;
            background:#fff;
            margin-bottom:10px;
            overflow:hidden;
        }
        .followup-note-head {
            width:100%;
            border:0;
            background:#f9fbfe;
            padding:12px 14px;
            text-align:left;
        }
        .followup-status {
            display:inline-flex;
            align-items:center;
            gap:5px;
            border-radius:999px;
            padding:4px 9px;
            font-size:0.78rem;
            font-weight:800;
        }
        .followup-status.open {
            color:#b42318;
            background:#fff1f0;
            border:1px solid #ffccc7;
        }
        .followup-status.resolved {
            color:#067647;
            background:#ecfdf3;
            border:1px solid #abefc6;
        }
        .followup-note-body {
            padding:14px;
            border-top:1px solid #e8eef6;
        }
        .followup-note-text {
            white-space:pre-line;
            color:#263f5a;
        }
        .followup-panel-toggle {
            border-radius:999px;
            font-weight:700;
        }
        .voucher-record-table th,
        .voucher-record-table td {
            vertical-align:middle;
        }
        .voucher-record-table th {
            white-space:nowrap;
        }
        .voucher-record-breakdown {
            background:#fbfdff;
            margin:0;
        }
        .voucher-record-breakdown th {
            color:var(--vw-text-soft);
            font-size:.76rem;
            text-transform:uppercase;
        }
    </style>
</head>
<body>
<?php render_admin_nav('accounts'); ?>
<?php render_school_page_header("The Lord's Wisdom Academy Of Caloocan Inc."); ?>
<div class="history-shell px-2 px-xl-3">
    <div class="student-name-display mt-2">
        <i class="fas fa-user-graduate"></i>
        <?= htmlspecialchars($student_name) ?>
        <span class="badge bg-info ms-2"><i class="fas fa-layer-group"></i> Grade: <?= htmlspecialchars($student_grade) ?></span>
        <span class="badge bg-secondary ms-2"><i class="fas fa-calendar-alt"></i> <?= htmlspecialchars($selected_school_year) ?></span>
    </div>
    <?php if ($error): ?>
        <div class="alert alert-danger mt-3"><?= htmlspecialchars($error) ?></div>
    <?php else: ?>
        <div class="tabs-bar">
            <button class="btn btn-outline-success tab-btn active" data-tab="paymentrecords">
                <i class="fas fa-history"></i> Payment Desk
            </button>
            <button class="btn btn-outline-info tab-btn" data-tab="feebalances">
                <i class="fas fa-coins"></i> Balance Items
            </button>
            <button class="btn btn-outline-primary tab-btn" data-tab="officialreceipt">
                <i class="fas fa-file-invoice-dollar"></i> Receipts Desk
            </button>
        </div>
        <div id="tabContent" class="tab-window">
            <!-- Loaded via AJAX -->
        </div>
        <section class="followup-panel" id="accountVoucherRecords">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                    <h4 class="mb-1"><i class="fas fa-file-invoice-dollar me-2"></i>Applied Voucher / Adjustment Records</h4>
                    <div class="text-muted">Read-only voucher, subsidy, discount, and grant records for this student. This does not update balances or payments.</div>
                </div>
                <div class="d-flex gap-2 flex-wrap align-items-center">
                    <span class="followup-status resolved"><i class="fas fa-circle-check"></i><?= number_format($finance_adjustment_applied_count) ?> Applied</span>
                    <span class="followup-status resolved"><i class="fas fa-rotate-left"></i><?= number_format($finance_adjustment_reverted_count) ?> Reverted</span>
                    <span class="followup-status open"><i class="fas fa-tag"></i>PHP <?= number_format($finance_adjustment_total_effect, 2) ?></span>
                    <button class="btn btn-outline-primary btn-sm followup-panel-toggle" type="button" data-bs-toggle="collapse" data-bs-target="#accountVoucherRecordsBody" aria-expanded="false" aria-controls="accountVoucherRecordsBody">
                        <i class="fas fa-chevron-down me-1"></i>Show Vouchers
                    </button>
                </div>
            </div>
            <div id="accountVoucherRecordsBody" class="collapse mt-3">
                <?php if (!$finance_adjustment_tables_ready): ?>
                    <div class="alert alert-warning mb-0">Finance adjustment records are not ready. Run the migration tool first.</div>
                <?php elseif (!$finance_adjustment_rows): ?>
                    <div class="alert alert-secondary mb-0">No voucher, subsidy, discount, or grant records have been applied to this student yet.</div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped align-middle voucher-record-table">
                            <thead>
                                <tr>
                                    <th>Template</th>
                                    <th>Type</th>
                                    <th>Current</th>
                                    <th>Voucher</th>
                                    <th>Result</th>
                                    <th>Fees</th>
                                    <th>Status</th>
                                    <th>Applied</th>
                                    <th>Breakdown</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($finance_adjustment_rows as $adjustmentRow): ?>
                                    <?php
                                    $snapshotItems = $adjustmentRow['snapshot']['items'] ?? [];
                                    $currentTotal = 0.0;
                                    $voucherTotal = 0.0;
                                    $resultTotal = 0.0;
                                    $affectedCount = 0;
                                    $skippedCount = 0;
                                    foreach ($snapshotItems as $snapshotItem) {
                                        if (($snapshotItem['account_action'] ?? '') === '') {
                                            $skippedCount++;
                                            continue;
                                        }
                                        $affectedCount++;
                                        $currentTotal += (float) ($snapshotItem['original_amount'] ?? 0);
                                        $voucherTotal += (float) ($snapshotItem['applied_amount'] ?? 0);
                                        $resultTotal += (float) ($snapshotItem['target_amount'] ?? 0);
                                    }
                                    $recordId = (int) ($adjustmentRow['id'] ?? 0);
                                    $recordBreakdownId = 'paymentHistoryVoucherBreakdown' . $recordId;
                                    $recordStatus = (string) ($adjustmentRow['status'] ?? '');
                                    ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold"><?= htmlspecialchars((string) ($adjustmentRow['name'] ?? 'Finance Adjustment')) ?></div>
                                            <div class="small text-muted">Record #<?= $recordId ?></div>
                                        </td>
                                        <td><?= htmlspecialchars(finance_adjustment_types()[(string) ($adjustmentRow['adjustment_type'] ?? '')] ?? 'Adjustment') ?></td>
                                        <td class="fw-bold">PHP <?= number_format($currentTotal, 2) ?></td>
                                        <td class="fw-bold">-PHP <?= number_format($voucherTotal, 2) ?></td>
                                        <td class="fw-bold">PHP <?= number_format($resultTotal, 2) ?></td>
                                        <td>
                                            <?= number_format($affectedCount) ?> affected
                                            <?php if ($skippedCount > 0): ?>
                                                <div class="small text-muted"><?= number_format($skippedCount) ?> skipped</div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge <?= $recordStatus === 'applied' ? 'text-bg-success' : 'text-bg-secondary' ?>">
                                                <?= htmlspecialchars(ucfirst($recordStatus !== '' ? $recordStatus : 'recorded')) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="fw-bold"><?= htmlspecialchars((string) ($adjustmentRow['applied_by'] ?? 'System')) ?></div>
                                            <div class="small text-muted"><?= !empty($adjustmentRow['applied_at']) ? htmlspecialchars(date('M j, Y g:i A', strtotime((string) $adjustmentRow['applied_at']))) : '' ?></div>
                                        </td>
                                        <td>
                                            <button class="btn btn-outline-primary btn-sm" type="button" data-bs-toggle="collapse" data-bs-target="#<?= htmlspecialchars($recordBreakdownId) ?>">
                                                <i class="fas fa-list-ul"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="collapse" id="<?= htmlspecialchars($recordBreakdownId) ?>">
                                        <td colspan="9" class="p-0">
                                            <table class="table table-sm voucher-record-breakdown">
                                                <thead>
                                                    <tr>
                                                        <th>Fee Type</th>
                                                        <th>Current</th>
                                                        <th>Voucher</th>
                                                        <th>Result</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($snapshotItems as $snapshotItem): ?>
                                                        <?php $itemAction = (string) ($snapshotItem['account_action'] ?? ''); ?>
                                                        <tr>
                                                            <td><?= htmlspecialchars((string) ($snapshotItem['fee_type_name'] ?? '')) ?></td>
                                                            <td>PHP <?= number_format((float) ($snapshotItem['original_amount'] ?? 0), 2) ?></td>
                                                            <td>-PHP <?= number_format((float) ($snapshotItem['applied_amount'] ?? 0), 2) ?></td>
                                                            <td>PHP <?= number_format((float) ($snapshotItem['target_amount'] ?? 0), 2) ?></td>
                                                            <td><span class="badge <?= $itemAction !== '' ? 'text-bg-success' : 'text-bg-secondary' ?>"><?= $itemAction !== '' ? 'Applied' : 'Skipped' ?></span></td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </section>
        <section class="followup-panel" id="accountFollowupNotes">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                    <h4 class="mb-1"><i class="fas fa-clipboard-list me-2"></i>Account Follow-up Notes</h4>
                    <div class="text-muted">Reminder/checklist only. This does not update balances, receipts, invoices, or payments.</div>
                </div>
                <div class="d-flex gap-2 flex-wrap align-items-center">
                    <span class="followup-status open"><i class="fas fa-circle-exclamation"></i><?= number_format($followup_counts['open']) ?> Open</span>
                    <span class="followup-status resolved"><i class="fas fa-circle-check"></i><?= number_format($followup_counts['resolved']) ?> Resolved</span>
                    <button class="btn btn-outline-primary btn-sm followup-panel-toggle" type="button" data-bs-toggle="collapse" data-bs-target="#accountFollowupPanelBody" aria-expanded="false" aria-controls="accountFollowupPanelBody">
                        <i class="fas fa-chevron-down me-1"></i>Show Notes
                    </button>
                </div>
            </div>

            <div id="accountFollowupPanelBody" class="collapse mt-3">
                <?php if ($followup_message !== ''): ?>
                    <div class="alert alert-<?= htmlspecialchars($followup_message_type) ?>"><?= htmlspecialchars($followup_message) ?></div>
                <?php endif; ?>

                <?php if (!$followup_tables_ready): ?>
                    <div class="alert alert-warning mb-0">Account follow-up schema is not ready. Run the migration tool first.</div>
                <?php else: ?>
                    <div class="row g-3">
                        <div class="col-12 col-xl-5">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <div class="fw-bold">Checklist Templates</div>
                                <?php if ($active_followup_template_id > 0): ?>
                                    <span class="small text-muted"><i class="fas fa-lock me-1"></i>Student-specific</span>
                                <?php endif; ?>
                            </div>
                            <div class="active-guide-box">
                                <div class="active-guide-label">Active Account Guide</div>
                                <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                                    <div>
                                        <div class="active-guide-title">
                                            <?= $active_followup_template ? htmlspecialchars((string) $active_followup_template['title']) : 'Not Set' ?>
                                        </div>
                                        <div class="small text-muted">
                                            <?= $active_followup_template
                                                ? 'Only this guide is active for this student. Other templates are locked as reference.'
                                                : 'No active guide is assigned yet for this student.' ?>
                                        </div>
                                        <span class="active-guide-pill <?= $active_followup_template ? '' : 'active-guide-empty' ?>">
                                            <i class="fas <?= $active_followup_template ? 'fa-circle-check' : 'fa-circle-info' ?>"></i>
                                            <?= $active_followup_template ? 'Guide active' : 'Guide not set' ?>
                                        </span>
                                    </div>
                                    <?php if ($can_manage_active_guide): ?>
                                        <form method="post" class="active-guide-form d-flex gap-2 flex-wrap">
                                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                            <input type="hidden" name="account_followup_action" value="set_active_template">
                                            <select name="active_template_id" class="form-select form-select-sm" style="min-width:190px;">
                                                <option value="">No active guide</option>
                                                <?php foreach ($followup_templates as $templateOption): ?>
                                                    <option value="<?= (int) $templateOption['id'] ?>" <?= $active_followup_template_id === (int) $templateOption['id'] ? 'selected' : '' ?>>
                                                        <?= htmlspecialchars((string) $templateOption['title']) ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                            <button type="submit" class="btn btn-sm btn-primary"><i class="fas fa-save me-1"></i>Save</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php if ($followup_templates): ?>
                                <div class="followup-template-tabs" role="tablist">
                                    <?php foreach ($followup_templates as $index => $template): ?>
                                        <?php
                                        $templateId = (int) $template['id'];
                                        $isActiveGuide = $active_followup_template_id > 0 && $active_followup_template_id === $templateId;
                                        $isLockedGuide = $active_followup_template_id > 0 && !$isActiveGuide;
                                        $isDefaultTemplate = ($active_followup_template_id > 0 && $isActiveGuide) || ($active_followup_template_id === 0 && $index === 0);
                                        ?>
                                        <button
                                            type="button"
                                            class="btn <?= $isActiveGuide ? 'btn-primary' : 'btn-outline-primary' ?> followup-template-btn <?= $isDefaultTemplate ? 'active' : '' ?> <?= $isLockedGuide ? 'locked' : '' ?>"
                                            data-followup-template="<?= $templateId ?>"
                                            <?= $isLockedGuide ? 'disabled title="Locked because another guide is active for this student."' : '' ?>
                                        >
                                            <?= htmlspecialchars((string) $template['title']) ?>
                                            <?php if ($isActiveGuide): ?>
                                                <i class="fas fa-lock ms-1"></i>
                                            <?php endif; ?>
                                        </button>
                                    <?php endforeach; ?>
                                </div>
                                <?php foreach ($followup_templates as $index => $template): ?>
                                    <?php
                                    $templateId = (int) $template['id'];
                                    $isActiveGuide = $active_followup_template_id > 0 && $active_followup_template_id === $templateId;
                                    $isDefaultTemplate = ($active_followup_template_id > 0 && $isActiveGuide) || ($active_followup_template_id === 0 && $index === 0);
                                    ?>
                                    <div
                                        class="followup-template-content <?= $isDefaultTemplate ? '' : 'd-none' ?>"
                                        data-followup-template-panel="<?= $templateId ?>"
                                    ><?= htmlspecialchars((string) $template['content']) ?></div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="alert alert-info mb-0">No active checklist templates yet.</div>
                            <?php endif; ?>
                        </div>
                        <div class="col-12 col-xl-7">
                        <div class="fw-bold mb-2">Add Follow-up Note</div>
                        <?php if ($can_manage_followups): ?>
                            <form method="post" class="border rounded-4 p-3 bg-light-subtle mb-3">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                <input type="hidden" name="account_followup_action" value="add_note">
                                <div class="row g-2">
                                    <div class="col-md-3">
                                        <label class="form-label">Category</label>
                                        <input type="text" name="category" class="form-control" value="General" maxlength="60">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label">Contact Person</label>
                                        <input type="text" name="contact_person" class="form-control" placeholder="Parent / Guardian name" maxlength="120">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label">Contact Role</label>
                                        <select name="contact_role" class="form-select">
                                            <option value="">Not specified</option>
                                            <option value="Parent">Parent</option>
                                            <option value="Guardian">Guardian</option>
                                            <option value="Student">Student</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label">Follow-up Date</label>
                                        <input type="date" name="follow_up_date" class="form-control">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Note Details</label>
                                        <textarea name="note" class="form-control" rows="3" required placeholder="Example: Parent promised to pay remaining 1,000 for books on July 10."></textarea>
                                    </div>
                                </div>
                                <div class="text-end mt-2">
                                    <button type="submit" class="btn btn-primary"><i class="fas fa-plus me-1"></i>Add Note</button>
                                </div>
                            </form>
                        <?php else: ?>
                            <div class="alert alert-info">You can view follow-up notes, but your role cannot add or resolve notes.</div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mt-3 mb-2">
                    <div class="fw-bold">Follow-up Timeline</div>
                    <div class="btn-group btn-group-sm">
                        <button type="button" class="btn btn-outline-secondary" data-followup-expand="all">Expand All</button>
                        <button type="button" class="btn btn-outline-secondary" data-followup-expand="none">Collapse All</button>
                    </div>
                </div>
                <?php if ($followup_notes): ?>
                    <div class="accordion" id="followupAccordion">
                        <?php foreach ($followup_notes as $index => $note): ?>
                            <?php
                            $noteId = (int) $note['id'];
                            $isResolved = (string) ($note['status'] ?? '') === 'resolved';
                            $collapseId = 'followupNote' . $noteId;
                            ?>
                            <div class="followup-note-card">
                                <button class="followup-note-head" type="button" data-bs-toggle="collapse" data-bs-target="#<?= htmlspecialchars($collapseId) ?>" aria-expanded="<?= $index === 0 ? 'true' : 'false' ?>">
                                    <div class="d-flex justify-content-between align-items-start gap-2 flex-wrap">
                                        <div>
                                            <span class="followup-status <?= $isResolved ? 'resolved' : 'open' ?>">
                                                <i class="fas <?= $isResolved ? 'fa-circle-check' : 'fa-circle-exclamation' ?>"></i>
                                                <?= $isResolved ? 'Resolved' : 'Open' ?>
                                            </span>
                                            <span class="fw-bold ms-2"><?= htmlspecialchars((string) $note['category']) ?></span>
                                            <?php if (!empty($note['follow_up_date'])): ?>
                                                <span class="badge text-bg-warning ms-1">Follow-up: <?= htmlspecialchars(date('M j, Y', strtotime((string) $note['follow_up_date']))) ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="small text-muted">
                                            <?= htmlspecialchars((string) ($note['created_by'] ?: 'Unknown')) ?> | <?= htmlspecialchars(date('M j, Y g:i A', strtotime((string) $note['created_at']))) ?>
                                        </div>
                                    </div>
                                </button>
                                <div id="<?= htmlspecialchars($collapseId) ?>" class="collapse <?= $index === 0 ? 'show' : '' ?>" data-followup-collapse>
                                    <div class="followup-note-body">
                                        <div class="row g-2 mb-2 small text-muted">
                                            <div class="col-md-4"><strong>Contact:</strong> <?= htmlspecialchars((string) ($note['contact_person'] ?: '-')) ?></div>
                                            <div class="col-md-4"><strong>Role:</strong> <?= htmlspecialchars((string) ($note['contact_role'] ?: '-')) ?></div>
                                            <div class="col-md-4"><strong>Resolved:</strong>
                                                <?= $isResolved ? htmlspecialchars((string) ($note['resolved_by'] ?: 'Unknown') . ' | ' . date('M j, Y g:i A', strtotime((string) $note['resolved_at']))) : '-' ?>
                                            </div>
                                        </div>
                                        <div class="followup-note-text mb-3"><?= htmlspecialchars((string) $note['note']) ?></div>
                                        <?php if (!$isResolved && $can_manage_followups): ?>
                                            <form method="post" onsubmit="return confirm('Mark this follow-up note as resolved?');">
                                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                                <input type="hidden" name="account_followup_action" value="resolve_note">
                                                <input type="hidden" name="note_id" value="<?= $noteId ?>">
                                                <button type="submit" class="btn btn-sm btn-success"><i class="fas fa-check me-1"></i>Resolve / Done</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="alert alert-light border mb-0">No follow-up notes yet for this student.</div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>
</div>
<script>
function loadTab(tab, params = '') {
    const student_id = <?= json_encode($student_id) ?>;
    const school_year = <?= json_encode($selected_school_year) ?>;
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelector('.tab-btn[data-tab="' + tab + '"]').classList.add('active');
    document.getElementById('tabContent').innerHTML = '<div class="text-center my-5"><span class="spinner-border"></span> Loading...</div>';
    let url = tab === 'paymentrecords' ? 'account-paymentrecords.php?student_id=' + student_id + '&school_year=' + encodeURIComponent(school_year) :
              tab === 'feebalances' ? 'account-feebalances.php?student_id=' + student_id + '&school_year=' + encodeURIComponent(school_year) :
              tab === 'officialreceipt' ? 'account-officialreceipt.php?student_id=' + student_id + '&school_year=' + encodeURIComponent(school_year) : '';
    if (params) url += '&' + params;
    fetch(url)
        .then(resp => resp.text())
        .then(html => document.getElementById('tabContent').innerHTML = html);
}
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => loadTab(btn.getAttribute('data-tab')));
});
window.onload = () => loadTab('paymentrecords');

// Event delegation for filter and reset buttons inside the tab content
document.getElementById('tabContent').addEventListener('submit', function(e) {
    // Official Receipt Filter
    if (e.target && e.target.id === 'receiptFilterForm') {
        e.preventDefault();
        const formData = new FormData(e.target);
        const params = new URLSearchParams(formData).toString();
        loadTab('officialreceipt', params);
    }
    // Payment Records Filter
    if (e.target && e.target.id === 'paymentFilterForm') {
        e.preventDefault();
        const formData = new FormData(e.target);
        const params = new URLSearchParams(formData).toString();
        loadTab('paymentrecords', params);
    }
});
document.getElementById('tabContent').addEventListener('click', function(e) {
    // Official Receipt Reset
    if (e.target && e.target.id === 'resetReceiptBtn') {
        e.preventDefault();
        loadTab('officialreceipt');
    }
    // Payment Records Reset
    if (e.target && e.target.id === 'resetPaymentBtn') {
        e.preventDefault();
        loadTab('paymentrecords');
    }
});
document.querySelectorAll('[data-followup-template]').forEach(btn => {
    btn.addEventListener('click', function() {
        const id = this.getAttribute('data-followup-template');
        document.querySelectorAll('[data-followup-template]').forEach(item => item.classList.remove('active'));
        document.querySelectorAll('[data-followup-template-panel]').forEach(panel => panel.classList.add('d-none'));
        this.classList.add('active');
        const panel = document.querySelector('[data-followup-template-panel="' + id + '"]');
        if (panel) panel.classList.remove('d-none');
    });
});
document.querySelectorAll('[data-followup-expand]').forEach(btn => {
    btn.addEventListener('click', function() {
        const expand = this.getAttribute('data-followup-expand') === 'all';
        document.querySelectorAll('[data-followup-collapse]').forEach(item => {
            const instance = bootstrap.Collapse.getOrCreateInstance(item, {toggle: false});
            expand ? instance.show() : instance.hide();
        });
    });
});
const followupPanelBody = document.getElementById('accountFollowupPanelBody');
if (followupPanelBody) {
    followupPanelBody.addEventListener('shown.bs.collapse', function() {
        const btn = document.querySelector('[data-bs-target="#accountFollowupPanelBody"]');
        if (btn) btn.innerHTML = '<i class="fas fa-chevron-up me-1"></i>Hide Notes';
    });
    followupPanelBody.addEventListener('hidden.bs.collapse', function() {
        const btn = document.querySelector('[data-bs-target="#accountFollowupPanelBody"]');
        if (btn) btn.innerHTML = '<i class="fas fa-chevron-down me-1"></i>Show Notes';
    });
}
const voucherRecordsBody = document.getElementById('accountVoucherRecordsBody');
if (voucherRecordsBody) {
    voucherRecordsBody.addEventListener('shown.bs.collapse', function() {
        const btn = document.querySelector('[data-bs-target="#accountVoucherRecordsBody"]');
        if (btn) btn.innerHTML = '<i class="fas fa-chevron-up me-1"></i>Hide Vouchers';
    });
    voucherRecordsBody.addEventListener('hidden.bs.collapse', function() {
        const btn = document.querySelector('[data-bs-target="#accountVoucherRecordsBody"]');
        if (btn) btn.innerHTML = '<i class="fas fa-chevron-down me-1"></i>Show Vouchers';
    });
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    if (window.bootstrap && window.bootstrap.Collapse) {
        return;
    }
    document.querySelectorAll('[data-bs-toggle="collapse"][data-bs-target]').forEach(function(button) {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            var selector = button.getAttribute('data-bs-target');
            var target = selector ? document.querySelector(selector) : null;
            if (!target) {
                return;
            }
            var willShow = !target.classList.contains('show');
            target.classList.toggle('show', willShow);
            target.style.display = willShow
                ? (target.tagName.toLowerCase() === 'tr' ? 'table-row' : 'block')
                : 'none';
            button.setAttribute('aria-expanded', willShow ? 'true' : 'false');
            if (selector === '#accountVoucherRecordsBody') {
                button.innerHTML = willShow
                    ? '<i class="fas fa-chevron-up me-1"></i>Hide Vouchers'
                    : '<i class="fas fa-chevron-down me-1"></i>Show Vouchers';
            }
            if (selector === '#accountFollowupPanelBody') {
                button.innerHTML = willShow
                    ? '<i class="fas fa-chevron-up me-1"></i>Hide Notes'
                    : '<i class="fas fa-chevron-down me-1"></i>Show Notes';
            }
        });
    });
});
</script>
</body>
</html>
