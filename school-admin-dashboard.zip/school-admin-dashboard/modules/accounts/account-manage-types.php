<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
include '../../config/database.php';
include __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/settings-security.php';

// Permission check: Only users with account_mgmt:add, edit, delete can manage account types
$currentRole = $_SESSION['role'] ?? '';

// Check if user can view/manage account types
if (
    !hasPermission($currentRole, 'account_mgmt', 'add') &&
    !hasPermission($currentRole, 'account_mgmt', 'edit') &&
    !hasPermission($currentRole, 'account_mgmt', 'delete')
) {
    include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';
    $blockedUser = $_SESSION['username'] ?? 'unknown';
    audit_log(
        $conn,
        $blockedUser,
        'Blocked account type management access',
        'Accounts',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing account_mgmt:add/edit/delete permission',
        'SECURITY'
    );
    admin_session_forbidden('Access denied. You do not have permission to manage account types.');
}

$error = $error ?? "";
$success = "";
ensure_csrf_token();

// Handle Add
if (isset($_POST['add_type'])) {
    if (!hasPermission($currentRole, 'account_mgmt', 'add')) {
        $error = "Access denied. You do not have permission to add account types.";
    } else {
    admin_require_post_csrf();
        $new_type = trim($_POST['new_type']);
        $priority = intval($_POST['new_priority']);
        if ($new_type !== "") {
            // Check for duplicate before insert
            $dup_check = $conn->prepare("SELECT COUNT(*) FROM account_types WHERE name=?");
            $dup_check->bind_param("s", $new_type);
            $dup_check->execute();
            $dup_check->bind_result($exists);
            $dup_check->fetch();
            $dup_check->close();

            if ($exists > 0) {
                $error = "This account type name already exists. Please choose a different name.";
            } else {
                $stmt = $conn->prepare("INSERT INTO account_types (name, priority) VALUES (?, ?)");
                if ($stmt->bind_param("si", $new_type, $priority) && $stmt->execute()) {
                    $success = "Account type added.";
                } else {
                    $error = "Error adding account type.";
                }
                $stmt->close();
            }
        } else {
            $error = "Please enter a type name.";
        }
    }
}

// Handle Edit
if (isset($_POST['edit_type'])) {
    if (!hasPermission($currentRole, 'account_mgmt', 'edit')) {
        $error = "Access denied. You do not have permission to edit account types.";
    } else {
        admin_require_post_csrf();
        $id = intval($_POST['type_id']);
        $edited_type = trim($_POST['edited_type']);
        $edited_priority = intval($_POST['edited_priority']);
        if ($edited_type !== "") {
            // Check for duplicate name (excluding current id)
            $dup_check = $conn->prepare("SELECT COUNT(*) FROM account_types WHERE name=? AND id<>?");
            $dup_check->bind_param("si", $edited_type, $id);
            $dup_check->execute();
            $dup_check->bind_result($exists);
            $dup_check->fetch();
            $dup_check->close();

            if ($exists > 0) {
                $error = "This account type name already exists. Please choose a different name.";
            } else {
                $stmt = $conn->prepare("UPDATE account_types SET name=?, priority=? WHERE id=?");
                if ($stmt->bind_param("sii", $edited_type, $edited_priority, $id) && $stmt->execute()) {
                    $success = "Account type updated.";
                } else {
                    $error = "Error updating account type.";
                }
                $stmt->close();
            }
        } else {
            $error = "Please enter a type name.";
        }
    }
}

// Handle Delete
if (isset($_POST['delete_type'])) {
    if (!hasPermission($currentRole, 'account_mgmt', 'delete')) {
        $error = "Access denied. You do not have permission to delete account types.";
    } else {
        admin_require_post_csrf();
        $id = intval($_POST['type_id']);
        $stmt = $conn->prepare("DELETE FROM account_types WHERE id=?");
        if ($stmt->bind_param("i", $id) && $stmt->execute()) {
            $success = "Account type deleted.";
        } else {
            $error = "Error deleting account type.";
        }
        $stmt->close();
    }
}

// Fetch Types
$types = [];
$res = $conn->query("SELECT id, name, priority FROM account_types ORDER BY priority ASC, name ASC");
while ($row = $res->fetch_assoc()) $types[] = $row;

$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';
$role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Finance Controls | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body {
            background: var(--main-bg);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
            transition: background 0.6s;
        }
        body.dark-mode {
            --main-bg: #1b232d;
            --card-bg: #23395d;
            --navbar-bg: #161b22;
            color: #e6edf3;
        }
        .navbar {
            background: var(--navbar-bg) !important;
            transition: background 0.6s;
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.08em;
        }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .nav-link.active { border-bottom: 2px solid #517fa4; }
        .theme-toggle-btn {
            background: none;
            border: none;
            color: #fff;
            font-size: 1.45em;
            margin-left: 12px;
            cursor: pointer;
            transition: color 0.3s;
        }
        .dashboard-header {
            text-align: center;
            margin-top: 36px;
            margin-bottom: 18px;
        }
        .dashboard-header img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            margin-bottom: 6px;
        }
        .dashboard-header h1 {
            font-size: 1.3rem;
            color: var(--brand-dark);
            font-weight: 700;
            margin-bottom: 0;
            transition: color 0.6s;
        }
        .account-types-note {
            font-size: 1.25rem;
            font-weight: 600;
            color: #002d67;
            background: #e7f0fd;
            padding: 6px 16px;
            border-radius: 8px;
            box-shadow: 0 1px 4px rgba(0,0,0,0.07);
            letter-spacing: 0.02em;
            margin-left: auto;
            margin-bottom: 18px;
            width: fit-content;
        }
        @media (max-width: 700px) {
            .account-types-note { font-size: 1.05rem; margin-left: 0; }
        }
        @media (max-width: 600px) {
            .account-types-note { font-size: 0.98rem; padding: 5px 10px; }
        }
    </style>
</head>
<body>
<?php render_admin_nav('accounts'); ?>
<?php render_school_page_header($schoolName); ?>
<!-- Top note only (no button group, see image3) -->
<div class="container-fluid">
    <div class="account-types-note">
        <i class="fas fa-cogs"></i> Finance Controls
    </div>
</div>
<!-- Main Content -->
<div id="page-content-wrapper" class="w-100">
    <div class="container mt-2">
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <form method="post" class="mb-4 row g-2 align-items-center">
            <?= csrf_input() ?>
            <div class="col-auto">
                <label for="new_type" class="form-label fw-bold mb-0">Add New Finance Type:</label>
            </div>
            <div class="col-auto">
                <input type="text" class="form-control" name="new_type" id="new_type" required>
            </div>
            <div class="col-auto">
                <select name="new_priority" class="form-select" required>
                    <option value="1">Level 1 (Highest Priority)</option>
                    <option value="2">Level 2</option>
                    <option value="3">Level 3 (Lowest Priority)</option>
                </select>
            </div>
            <div class="col-auto">
                <button type="submit" name="add_type" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add
                </button>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-bordered align-middle">
                <thead class="table-light">
                    <tr>
                        <th style="width:30%">Type Name</th>
                        <th style="width:20%">Priority to Pay</th>
                        <th style="width:15%">Edit</th>
                        <th style="width:15%">Delete</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($types as $type): ?>
                    <tr>
                        <form method="post" class="d-flex align-items-center gap-2">
                            <?= csrf_input() ?>
                            <td>
                                <input type="text" class="form-control" name="edited_type" value="<?= htmlspecialchars($type['name']) ?>" required>
                                <input type="hidden" name="type_id" value="<?= $type['id'] ?>">
                            </td>
                            <td>
                                <select name="edited_priority" class="form-select" required>
                                    <option value="1" <?= $type['priority']==1 ? 'selected':'' ?>>Level 1 (Highest)</option>
                                    <option value="2" <?= $type['priority']==2 ? 'selected':'' ?>>Level 2</option>
                                    <option value="3" <?= $type['priority']==3 ? 'selected':'' ?>>Level 3 (Lowest)</option>
                                </select>
                            </td>
                            <td>
                                <button type="submit" name="edit_type" class="btn btn-info btn-sm">
                                    <i class="fas fa-save"></i> Save
                                </button>
                            </td>
                            <td>
                                <button type="submit" name="delete_type" class="btn btn-danger btn-sm" onclick="return confirm('Delete this account type?');">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                            </td>
                        </form>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if (file_exists('../../includes/footer.php')) include '../../includes/footer.php'; ?>
</div>
<footer class="text-center py-4 text-muted small">
    &copy; <?= date("Y") ?> <?= $schoolName ?> | School Admin Dashboard
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const themeToggleBtn = document.getElementById('themeToggleBtn');
    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');
            this.querySelector('i').classList.toggle('fa-moon');
            this.querySelector('i').classList.toggle('fa-sun');
        });
    }
</script>
</body>
</html>
<?php
$conn->close();
?>
