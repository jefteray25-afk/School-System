<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/ui.php';
include '../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/../settings/settings-security.php';
require_once __DIR__ . '/../old accounts/old-account-followup-helper.php';

$csrfToken = admin_csrf_token();

// Permission check: Only users with account_mgmt:view or account_mgmt:view_own permission can access the account list
$currentRole = $_SESSION['role'] ?? '';
$is_own = false;

// Ownership-aware permission logic (optional, for view_own)
if (in_array($currentRole, ['Administrator 1', 'Administrator 2'])) {
    $is_own = true;
}

if (
    !hasPermission($currentRole, 'account_mgmt', 'view') &&
    !(hasPermission($currentRole, 'account_mgmt', 'view_own') && $is_own)
) {
    include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';
    $blockedUser = $_SESSION['username'] ?? 'unknown';
    audit_log(
        $conn,
        $blockedUser,
        'Blocked account list access',
        'Accounts',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing account_mgmt:view permission',
        'SECURITY'
    );
    admin_session_forbidden();
}

// Filters
$grade_filter = $_GET['grade'] ?? '';
$has_school_year_param = array_key_exists('school_year', $_GET);
$school_year_filter = trim($_GET['school_year'] ?? '');
$name_filter = trim($_GET['name'] ?? '');
$lrn_filter = trim($_GET['lrn'] ?? '');
$sort_filter = $_GET['sort'] ?? 'asc';
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
$school_year_options = school_year_finance_options($conn, 'accounts');
$active_school_year_label = school_year_get_active_label($conn);
if (!$has_school_year_param) {
    $school_year_filter = $active_school_year_label;
}

// Fetch grade levels for dropdown
$grades = [];
$grade_res = $conn->query("SELECT DISTINCT grade FROM students ORDER BY grade ASC");
while ($row = $grade_res->fetch_assoc()) {
    $grades[] = $row['grade'];
}

$studentFilterSqlParts = [];
$studentFilterParams = [];
$studentFilterTypes = '';
if ($grade_filter) {
    $studentFilterSqlParts[] = "s.grade = ?";
    $studentFilterParams[] = $grade_filter;
    $studentFilterTypes .= 's';
}
if ($name_filter) {
    $studentFilterSqlParts[] = "(CONCAT(s.lastname, ' ', s.firstname, ' ', s.middlename) LIKE ?)";
    $studentFilterParams[] = "%" . $name_filter . "%";
    $studentFilterTypes .= 's';
}
if ($lrn_filter) {
    $studentFilterSqlParts[] = "s.lrn LIKE ?";
    $studentFilterParams[] = "%" . $lrn_filter . "%";
    $studentFilterTypes .= 's';
}
if ($school_year_filter !== '') {
    $studentFilterSqlParts[] = "COALESCE(NULLIF(TRIM(s.school_year_label), ''), ?) = ?";
    $studentFilterParams[] = $school_year_filter;
    $studentFilterParams[] = $school_year_filter;
    $studentFilterTypes .= 'ss';
}

$studentWhereSql = $studentFilterSqlParts ? ' WHERE ' . implode(' AND ', $studentFilterSqlParts) : '';
$summary = [
    'students' => 0,
    'unpaid_students' => 0,
    'outstanding_balance' => 0.0,
    'collections' => 0.0,
];

function finance_follow_up_label(float $balance, string $latestPaymentDate = ''): array
{
    if ($balance <= 0.009) {
        return ['label' => 'Paid', 'class' => 'followup-paid', 'detail' => 'No outstanding balance'];
    }

    if ($latestPaymentDate === '') {
        return ['label' => 'Needs Initial Follow-up', 'class' => 'followup-critical', 'detail' => 'No recorded payment yet'];
    }

    $timestamp = strtotime($latestPaymentDate);
    if ($timestamp !== false) {
        $daysSincePayment = (int) floor((time() - $timestamp) / 86400);
        if ($daysSincePayment >= 30) {
            return ['label' => 'Urgent Follow-up', 'class' => 'followup-critical', 'detail' => $daysSincePayment . ' day(s) since last payment'];
        }
        if ($daysSincePayment >= 14) {
            return ['label' => 'Follow-up Soon', 'class' => 'followup-warning', 'detail' => $daysSincePayment . ' day(s) since last payment'];
        }

        return ['label' => 'Active Balance', 'class' => 'followup-open', 'detail' => 'Last payment ' . $daysSincePayment . ' day(s) ago'];
    }

    return ['label' => 'Active Balance', 'class' => 'followup-open', 'detail' => 'Payment activity on record'];
}

$summarySql = "SELECT COUNT(DISTINCT s.id) AS total_students,
    COUNT(DISTINCT CASE WHEN a.balance > 0 THEN s.id END) AS unpaid_students,
    COALESCE(SUM(a.balance), 0) AS outstanding_balance
    FROM students s
    LEFT JOIN accounts a ON a.student_id = s.id";
if ($school_year_filter !== '') {
    $summarySql .= " AND COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ?";
}
$summarySql .= $studentWhereSql;
$summaryStmt = $conn->prepare($summarySql);
if ($summaryStmt) {
    $summaryParams = $studentFilterParams;
    $summaryTypes = $studentFilterTypes;
    if ($school_year_filter !== '') {
        array_unshift($summaryParams, $school_year_filter, $school_year_filter);
        $summaryTypes = 'ss' . $summaryTypes;
    }
    if ($summaryParams) {
        $summaryStmt->bind_param($summaryTypes, ...$summaryParams);
    }
    $summaryStmt->execute();
    $summaryResult = $summaryStmt->get_result();
    if ($summaryResult && $summaryRow = $summaryResult->fetch_assoc()) {
        $summary['students'] = (int) ($summaryRow['total_students'] ?? 0);
        $summary['unpaid_students'] = (int) ($summaryRow['unpaid_students'] ?? 0);
        $summary['outstanding_balance'] = (float) ($summaryRow['outstanding_balance'] ?? 0);
    }
    $summaryStmt->close();
}

$collectionsSql = "SELECT COALESCE(SUM(p.amount), 0) AS total_collections
    FROM students s
    INNER JOIN accounts a ON a.student_id = s.id
    INNER JOIN payments p ON p.account_id = a.id";
if ($school_year_filter !== '') {
    $collectionsSql .= " AND COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ? AND COALESCE(NULLIF(TRIM(p.school_year_label), ''), ?) = ?";
}
$collectionsSql .= $studentWhereSql;
$collectionsStmt = $conn->prepare($collectionsSql);
if ($collectionsStmt) {
    $collectionsParams = $studentFilterParams;
    $collectionsTypes = $studentFilterTypes;
    if ($school_year_filter !== '') {
        array_unshift($collectionsParams, $school_year_filter, $school_year_filter, $school_year_filter, $school_year_filter);
        $collectionsTypes = 'ssss' . $collectionsTypes;
    }
    if ($collectionsParams) {
        $collectionsStmt->bind_param($collectionsTypes, ...$collectionsParams);
    }
    $collectionsStmt->execute();
    $collectionsResult = $collectionsStmt->get_result();
    if ($collectionsResult && $collectionsRow = $collectionsResult->fetch_assoc()) {
        $summary['collections'] = (float) ($collectionsRow['total_collections'] ?? 0);
    }
    $collectionsStmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Balances | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <?php ui_css_link(); ?>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
    :root {
        --main-bg: #f5f8fc;
        --card-bg: #fff;
        --navbar-bg: #23395d;
        --brand-blue: #517fa4;
        --brand-dark: #23395d;
    }
    body {
        background: var(--main-bg);
        font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        transition: background 0.6s;
    }
    body.dark-mode {
        --main-bg: #1b232d;
        --card-bg: #23395d;
        --navbar-bg: #161b22;
        color: #e6edf3;
    }
    .navbar {
        background: var(--navbar-bg) !important;
        transition: background 0.6s;
    }
    .navbar-brand, .navbar-nav .nav-link {
        color: #fff !important;
        font-size: 1.08em;
    }
    .navbar-brand { font-weight: 700; letter-spacing: 1px; }
    .nav-link.active { border-bottom: 2px solid #517fa4; }
    .main-content-centered {
        min-height: 100vh;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }
    .center-card {
        width: 100%;
        max-width: 1660px;
        margin: 0 auto;
        box-shadow: 0 4px 24px rgba(33,57,93,0.10), 0 1.5px 3px rgba(33,57,93,0.07);
        border-radius: 1.1rem;
        overflow: hidden;
        background: var(--card-bg);
        margin-bottom: 40px;
        margin-top: 32px;
        transition: background 0.6s, color 0.6s;
    }
    .pagination .page-link { min-width: 2.5em; text-align: center; }
    .summary-grid .summary-card {
        border: none;
        border-radius: 1rem;
        box-shadow: 0 4px 18px rgba(33,57,93,0.09);
    }
    .summary-label {
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: #6c7a89;
    }
    .summary-value {
        font-size: 1.45rem;
        font-weight: 700;
        color: #23395d;
    }
    /* Floating action buttons lower right */
    .floating-action-btns {
        position: fixed;
        right: 28px;
        bottom: 28px;
        z-index: 1050;
        display: flex;
        flex-direction: column;
        gap: 15px;
        align-items: flex-end;
    }
    .floating-action-btns a,
    .floating-action-btns button {
        background: #fffbe6;
        color: #23395d;
        border: 1px solid #ffe599;
        box-shadow: 0 5px 16px rgba(33,57,93,0.13);
        border-radius: 50%;
        width: 58px;
        height: 58px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.45em;
        cursor: pointer;
        transition: background 0.2s, color 0.2s;
        text-decoration: none;
        outline: none;
        border-width: 1.5px;
    }
    .floating-action-btns a:hover, .floating-action-btns a:focus,
    .floating-action-btns button:hover, .floating-action-btns button:focus {
        background: #fff2b3;
        color: #517fa4;
        border-color: #ffe599;
    }
    .floating-action-btns a .fa-cogs,
    .floating-action-btns button .fa-sync-alt {
        margin: 0;
    }
    .floating-action-btns .sync-btn {
        background: #e7f0fd;
        color: #007bff;
        border: 1px solid #bcdfff;
    }
    .floating-action-btns .sync-btn:hover,
    .floating-action-btns .sync-btn:focus {
        background: #dbe9fa;
        color: #002d67;
        border-color: #bcdfff;
    }
    /* Notification styles */
    .sync-toast {
        position: fixed;
        bottom: 105px;
        right: 32px;
        z-index: 2000;
        min-width: 230px;
        max-width: 340px;
        background: #fff;
        color: #23395d;
        border-radius: 9px;
        box-shadow: 0 7px 20px rgba(33,57,93,0.18);
        border: 1.5px solid #bcdfff;
        padding: 18px 17px;
        font-size: 1.07em;
        display: none;
        align-items: center;
        gap: 11px;
        animation: fadeInTop 0.3s;
    }
    .sync-toast.success { border-color: #4ade80; background: #eafff3; color: #138a3a; }
    .sync-toast.error { border-color: #f87171; background: #fff2f2; color: #b91c1c; }
    .sync-toast i { font-size: 1.15em; margin-right: 7px; }
    @keyframes fadeInTop {
        from { transform: translateY(40px); opacity: 0; }
        to   { transform: translateY(0); opacity: 1; }
    }
    @media (max-width: 1400px) {
        .center-card { max-width: 99vw; }
    }
    @media (max-width: 576px) {
        .center-card { margin-bottom: 20px; margin-top: 10px; }
        .floating-action-btns { right: 12px; bottom: 12px; gap: 11px; }
        .floating-action-btns a, .floating-action-btns button { width: 45px; height: 45px; font-size: 1.13em;}
        .sync-toast { right: 16px; bottom: 78px; padding: 12px 7px; font-size: 0.97em;}
        .balances-table-wrap { padding-inline: 0.25rem; }
    }
    /* View Wave 1 + 2: shared list view system */
    :root {
        --vw-page-bg: #eef3f9;
        --vw-card-bg: #ffffff;
        --vw-card-border: #d9e3ef;
        --vw-brand-dark: #23395d;
        --vw-brand-mid: #517fa4;
        --vw-brand-soft: #edf4fb;
        --vw-text-soft: #5f7186;
    }
    body {
        background:
            radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 30%),
            linear-gradient(180deg, #f8fbff 0%, var(--vw-page-bg) 100%);
        color: var(--vw-brand-dark);
    }
    .center-card {
        background: var(--vw-card-bg);
        border: 1px solid var(--vw-card-border);
        border-radius: 20px;
        box-shadow: 0 14px 32px rgba(35,57,93,0.07);
    }
    .center-card h2 {
        font-weight: 800;
    }
    .view-intro {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 14px;
        flex-wrap: wrap;
        margin-bottom: 1rem;
    }
    .view-kicker {
        font-size: 0.78rem;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: var(--vw-text-soft);
        font-weight: 800;
        margin-bottom: 0.3rem;
    }
    .view-title {
        font-size: 1.35rem;
        font-weight: 800;
        color: var(--vw-brand-dark);
        margin-bottom: 0.35rem;
    }
    .view-subtitle {
        color: var(--vw-text-soft);
        margin-bottom: 0;
    }
    .center-card form.row {
        background: #f8fbff;
        border: 1px solid var(--vw-card-border);
        border-radius: 16px;
        padding: 14px 12px;
        margin-bottom: 1rem !important;
    }
    .center-card .form-select,
    .center-card .form-control {
        border-color: #d7e1ed;
        min-height: 44px;
        box-shadow: none;
    }
    .summary-grid .summary-card {
        border: 1px solid var(--vw-card-border);
        box-shadow: 0 10px 24px rgba(35,57,93,0.06);
        background: #fff;
    }
    .summary-label { color: var(--vw-text-soft); }
    .summary-value { color: var(--vw-brand-dark); }
    .center-card .card {
        border: 1px solid var(--vw-card-border);
        border-radius: 18px;
        overflow: hidden;
    }
    .center-card .card-header {
        background: linear-gradient(135deg, var(--vw-brand-dark), var(--vw-brand-mid));
        color: #fff;
        border: 0;
        font-weight: 700;
    }
    .center-card .table thead th {
        background: var(--vw-brand-soft);
        color: var(--vw-brand-dark);
        border-bottom: 1px solid var(--vw-card-border);
        font-weight: 700;
        white-space: nowrap;
        padding: 0.95rem 1rem;
    }
    .center-card .table tbody td {
        padding: 0.95rem 1rem;
        vertical-align: top;
    }
    .center-card .table tbody tr:hover {
        background: transparent;
    }
    .balances-table-wrap {
        padding-inline: 0.65rem;
    }
    .balances-table-wrap .table {
        min-width: 1180px;
    }
    .balances-table-wrap th:first-child,
    .balances-table-wrap td:first-child {
        padding-left: 1.35rem;
    }
    .balances-table-wrap th:last-child,
    .balances-table-wrap td:last-child {
        padding-right: 1.35rem;
    }
    .col-lrn {
        min-width: 160px;
    }
    .col-name {
        min-width: 260px;
    }
    .col-followup {
        min-width: 260px;
    }
    .center-card .btn-primary,
    .center-card .btn-success {
        background: var(--vw-brand-dark);
        border-color: var(--vw-brand-dark);
        font-weight: 600;
    }
    .center-card .btn-outline-secondary,
    .center-card .btn-outline-primary,
    .center-card .btn-outline-info,
    .center-card .btn-outline-warning {
        background: #eef3f8;
        border-color: #d7e1ed;
        color: var(--vw-brand-dark);
        font-weight: 600;
    }
    .center-card .btn-outline-secondary:hover,
    .center-card .btn-outline-primary:hover,
    .center-card .btn-outline-info:hover,
    .center-card .btn-outline-warning:hover {
        background: #e1eaf4;
        border-color: #c8d5e4;
        color: var(--vw-brand-dark);
    }
    .center-card .table .btn.btn-sm {
        border-radius: 10px;
        min-height: 36px;
        font-weight: 700;
        box-shadow: none;
    }
    .center-card .table .btn.btn-primary {
        background: #edf4fb;
        border-color: #d7e1ed;
        color: var(--vw-brand-dark);
    }
    .center-card .badge.bg-light {
        background: #edf4fb !important;
        color: var(--vw-brand-dark) !important;
        border: 1px solid var(--vw-card-border) !important;
        border-radius: 999px;
        padding: 0.45rem 0.75rem;
        font-weight: 700;
    }
    .center-card .table a.text-decoration-none {
        color: var(--vw-brand-dark);
        font-weight: 700;
    }
    .center-card .table a.text-decoration-none:hover {
        color: var(--vw-brand-mid);
    }
    .followup-chip {
        display: inline-flex;
        align-items: center;
        border-radius: 999px;
        padding: 0.42rem 0.72rem;
        font-size: 0.82rem;
        font-weight: 700;
        border: 1px solid transparent;
    }
    .followup-paid {
        background: #eaf7ef;
        color: #1c6a44;
        border-color: #cde9d8;
    }
    .followup-open {
        background: #edf4fb;
        color: #23395d;
        border-color: #d9e3ef;
    }
    .followup-warning {
        background: #fff4d8;
        color: #9a6a00;
        border-color: #f2dfa7;
    }
    .followup-critical {
        background: #fdecec;
        color: #b42318;
        border-color: #f4c9c9;
    }
    .followup-detail {
        display: block;
        margin-top: 0.35rem;
        font-size: 0.78rem;
        color: var(--vw-text-soft);
        line-height: 1.35;
    }
    .old-account-mini {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        margin-top: 0.45rem;
        padding: 0.3rem 0.65rem;
        border-radius: 999px;
        background: #fff7e0;
        border: 1px solid #f2d67c;
        color: #7a5c00;
        font-size: 0.78rem;
        font-weight: 800;
    }
    .old-account-mini-note {
        display: block;
        margin-top: 0.35rem;
        font-size: 0.82rem;
        color: #8a6400;
        line-height: 1.35;
    }
    .latest-payment-empty {
        color: var(--vw-text-soft);
        font-size: 0.82rem;
        font-style: italic;
    }
    </style>
</head>
<body>
<!-- Navbar -->
<?php render_admin_nav('accounts'); ?>
<div id="page-content-wrapper" class="w-100 main-content-centered">
    <div class="center-card">
        <div class="container-fluid px-4 px-xl-5 py-4">
            <div class="view-intro">
                <div>
                    <div class="view-kicker">Finance Workspace</div>
                    <div class="view-title"><i class="fas fa-users me-2"></i>Student Balances</div>
                    <p class="view-subtitle">Review student finance coverage, balances, and school-year aligned finance views.</p>
                </div>
            </div>
            <!-- Filter Bar -->
            <form class="row g-2 mb-3" method="get" action="">
                <div class="col-md-3">
                    <select name="grade" class="form-select" onchange="this.form.submit()">
                        <option value="">Filter by Grade Level</option>
                        <?php foreach ($grades as $g): ?>
                            <option value="<?= htmlspecialchars($g) ?>" <?= $grade_filter==$g?'selected':'' ?>>
                                <?= htmlspecialchars($g) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <input type="text" name="name" class="form-control" placeholder="Search by Name" value="<?= htmlspecialchars($name_filter) ?>">
                </div>
                <div class="col-md-2">
                    <select name="school_year" class="form-select" onchange="this.form.submit()">
                        <option value="">All School Years</option>
                        <?php foreach ($school_year_options as $school_year_option): ?>
                            <option value="<?= htmlspecialchars($school_year_option) ?>" <?= $school_year_filter === $school_year_option ? 'selected' : '' ?>>
                                <?= htmlspecialchars($school_year_option) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <input type="text" name="lrn" class="form-control" placeholder="Search by LRN" value="<?= htmlspecialchars($lrn_filter) ?>">
                </div>
                <div class="col-md-2">
                    <select name="sort" class="form-select" onchange="this.form.submit()">
                        <option value="asc" <?= $sort_filter=='asc'?'selected':'' ?>>Sort Name: A &rarr; Z</option>
                        <option value="desc" <?= $sort_filter=='desc'?'selected':'' ?>>Sort Name: Z &rarr; A</option>
                    </select>
                </div>
                <div class="col-md-1">
                    <button type="submit" class="btn btn-outline-secondary w-100">
                        <i class="fas fa-filter"></i> Filter/Search
                    </button>
                </div>
            </form>
            <div class="row g-3 mb-3 summary-grid">
                <div class="col-md-3 col-sm-6">
                    <div class="card summary-card">
                        <div class="card-body">
                            <div class="summary-label">Students In View</div>
                            <div class="summary-value"><?= number_format($summary['students']) ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="card summary-card">
                        <div class="card-body">
                            <div class="summary-label">Unpaid Students</div>
                            <div class="summary-value"><?= number_format($summary['unpaid_students']) ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="card summary-card">
                        <div class="card-body">
                            <div class="summary-label">Outstanding Balance</div>
                            <div class="summary-value">PHP <?= number_format((float) $summary['outstanding_balance'], 2) ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="card summary-card">
                        <div class="card-body">
                            <div class="summary-label">Collections</div>
                            <div class="summary-value">PHP <?= number_format((float) $summary['collections'], 2) ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header bg-secondary text-light">
                    <i class="fas fa-list"></i> Student Balances Table
                    <span class="badge bg-light text-dark ms-2"><?= htmlspecialchars($school_year_filter !== '' ? $school_year_filter : 'All School Years') ?></span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive balances-table-wrap">
                    <table class="table table-striped mb-0 align-middle">
                        <thead>
                            <tr>
                                <th scope="col" class="col-lrn"><i class="fas fa-id-card"></i> LRN</th>
                                <th scope="col" class="col-name"><i class="fas fa-user"></i> Name</th>
                                <th scope="col"><i class="fas fa-layer-group"></i> Grade Level</th>
                                <th scope="col"><i class="fas fa-calendar-alt"></i> School Year</th>
                                <th scope="col"><i class="fas fa-calendar-alt"></i> Latest Payment Date</th>
                                <th scope="col" class="col-followup"><i class="fas fa-bullseye"></i> Follow-up</th>
                                <th scope="col"><i class="fas fa-wallet"></i> Balance Items</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Build WHERE for filter/search
                            $where = [];
                            $params = [];
                            $types = '';

                            if ($grade_filter) {
                                $where[] = "grade = ?";
                                $params[] = $grade_filter;
                                $types .= 's';
                            }
                            if ($name_filter) {
                                $where[] = "(CONCAT(lastname, ' ', firstname, ' ', middlename) LIKE ?)";
                                $params[] = "%" . $name_filter . "%";
                                $types .= 's';
                            }
                            if ($lrn_filter) {
                                $where[] = "lrn LIKE ?";
                                $params[] = "%" . $lrn_filter . "%";
                                $types .= 's';
                            }
                            if ($school_year_filter !== '') {
                                $where[] = "COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?";
                                $params[] = $school_year_filter;
                                $params[] = $school_year_filter;
                                $types .= 'ss';
                            }

                            $sql_count = "SELECT COUNT(*) FROM students";
                            if ($where) {
                                $sql_count .= " WHERE " . implode(" AND ", $where);
                            }
                            $stmt_count = $conn->prepare($sql_count);
                            if ($params) {
                                $stmt_count->bind_param($types, ...$params);
                            }
                            $stmt_count->execute();
                            $stmt_count->bind_result($total_students);
                            $stmt_count->fetch();
                            $stmt_count->close();

                            $limit = 30;
                            $page = max(intval($_GET['page'] ?? '1'), 1);
                            $offset = ($page - 1) * $limit;
                            $total_pages = max(ceil($total_students / $limit), 1);

                            $sql = "SELECT id, lastname, firstname, middlename, lrn, grade, school_year_label FROM students";
                            if ($where) {
                                $sql .= " WHERE " . implode(" AND ", $where);
                            }
                            $sql .= " ORDER BY lastname " . ($sort_filter === 'asc' ? 'ASC' : 'DESC') . ", firstname " . ($sort_filter === 'asc' ? 'ASC' : 'DESC') . " LIMIT ? OFFSET ?";

                            $stmt = $conn->prepare($sql);
                            if ($params) {
                                $params[] = $limit;
                                $params[] = $offset;
                                $types .= 'ii';
                                $stmt->bind_param($types, ...$params);
                            } else {
                                $stmt->bind_param('ii', $limit, $offset);
                            }
                            $stmt->execute();
                            $result = $stmt->get_result();

                            if ($result && $result->num_rows > 0):
                                while($row = $result->fetch_assoc()):
                                    // Fetch latest payment date from payments table (not payment_history)
                                    $latest_payment_date = '';
                                    $student_balance_total = 0.0;
                                    $linked_old_account_summary = old_account_linked_records_for_student($conn, (int) $row['id']);
                                    $linked_old_account_count = (int) ($linked_old_account_summary['count'] ?? 0);
                                    $linked_old_account_total = (float) ($linked_old_account_summary['total_balance'] ?? 0);
                                    if ($school_year_filter !== '') {
                                        $pay_stmt = $conn->prepare("SELECT date_paid FROM payments WHERE account_id IN (SELECT id FROM accounts WHERE student_id = ? AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?) AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ? ORDER BY date_paid DESC LIMIT 1");
                                        $pay_stmt->bind_param("issss", $row['id'], $school_year_filter, $school_year_filter, $school_year_filter, $school_year_filter);
                                    } else {
                                        $pay_stmt = $conn->prepare("SELECT date_paid FROM payments WHERE account_id IN (SELECT id FROM accounts WHERE student_id = ?) ORDER BY date_paid DESC LIMIT 1");
                                        $pay_stmt->bind_param("i", $row['id']);
                                    }
                                    $pay_stmt->execute();
                                    $pay_stmt->bind_result($payment_date);
                                    if ($pay_stmt->fetch()) {
                                        $latest_payment_date = date('F j, Y', strtotime($payment_date));
                                    }
                                    $pay_stmt->close();

                                    $balance_school_year = $school_year_filter !== '' ? $school_year_filter : ($row['school_year_label'] ?: $active_school_year_label);
                                    $balance_stmt = $conn->prepare("SELECT COALESCE(SUM(balance), 0) FROM accounts WHERE student_id = ? AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?");
                                    $balance_stmt->bind_param("iss", $row['id'], $balance_school_year, $balance_school_year);
                                    $balance_stmt->execute();
                                    $balance_stmt->bind_result($student_balance_total);
                                    $balance_stmt->fetch();
                                    $balance_stmt->close();
                                    $followUp = finance_follow_up_label((float) $student_balance_total, $latest_payment_date);
                            ?>
                            <tr>
                                <td><?= htmlspecialchars($row['lrn']) ?></td>
                                <td>
                                    <a href="account-view.php?student_id=<?= $row['id'] ?>&school_year=<?= urlencode($school_year_filter !== '' ? $school_year_filter : ($row['school_year_label'] ?: $active_school_year_label)) ?>" class="text-decoration-none">
                                        <?= htmlspecialchars($row['lastname'] . ', ' . $row['firstname'] . ' ' . $row['middlename']) ?>
                                    </a>
                                    <?php if ($linked_old_account_count > 0): ?>
                                        <span class="old-account-mini">
                                            <i class="fas fa-clock-rotate-left"></i>
                                            <?= number_format($linked_old_account_count) ?> old account<?= $linked_old_account_count > 1 ? 's' : '' ?>
                                        </span>
                                        <span class="old-account-mini-note">Old balance: PHP <?= number_format($linked_old_account_total, 2) ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($row['grade']) ?></td>
                                <td><?= htmlspecialchars($row['school_year_label'] ?: $active_school_year_label) ?></td>
                                <td>
                                    <?php if ($latest_payment_date): ?>
                                        <?= htmlspecialchars($latest_payment_date) ?>
                                    <?php else: ?>
                                        <span class="latest-payment-empty">No payment yet</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="followup-chip <?= htmlspecialchars($followUp['class']) ?>"><?= htmlspecialchars($followUp['label']) ?></span>
                                    <span class="followup-detail">
                                        <?= htmlspecialchars($followUp['detail']) ?> | Outstanding: PHP <?= number_format((float) $student_balance_total, 2) ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="account-view.php?student_id=<?= $row['id'] ?>&school_year=<?= urlencode($school_year_filter !== '' ? $school_year_filter : ($row['school_year_label'] ?: $active_school_year_label)) ?>" class="btn btn-sm btn-primary" title="Open Finance Profile">
                                        <i class="fas fa-wallet"></i> Open
                                    </a>
                                </td>
                            </tr>
                            <?php
                                endwhile;
                            else:
                            ?>
                                <tr><td colspan="7" class="text-center">No students found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
            <!-- Pagination Controls -->
            <nav aria-label="Account list pagination" class="mt-3">
                <ul class="pagination justify-content-center">
                    <?php
                    $query_string = http_build_query(array_filter([
                        'grade' => $grade_filter,
                        'school_year' => $school_year_filter,
                        'name' => $name_filter,
                        'lrn' => $lrn_filter,
                        'sort' => $sort_filter,
                    ]));
                    $base_url = 'account-list.php' . ($query_string ? '?' . $query_string . '&' : '?');
                    ?>
                    <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                        <a class="page-link" href="<?= $base_url ?>page=<?= $page-1 ?>" aria-label="Previous">&laquo;</a>
                    </li>
                    <?php
                    $start = max(1, $page - 2);
                    $end = min($total_pages, $start + 4);
                    if ($end - $start < 4) $start = max(1, $end - 4);
                    for ($i = $start; $i <= $end; $i++):
                    ?>
                    <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                        <a class="page-link" href="<?= $base_url ?>page=<?= $i ?>"><?= $i ?></a>
                    </li>
                    <?php endfor; ?>
                    <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>">
                        <a class="page-link" href="<?= $base_url ?>page=<?= $page+1 ?>" aria-label="Next">&raquo;</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
    <?php if (file_exists('../../includes/footer.php')) include '../../includes/footer.php'; ?>
</div>
<!-- Sync notification popup -->
<div class="sync-toast" id="syncToast">
    <i class="fas fa-exclamation-circle"></i>
    <span id="syncToastMsg"></span>
</div>
<!-- Floating Action Buttons (lower right) -->
<div class="floating-action-btns">
    <a href="account-manage-types.php" class="floating-types-btn" title="Finance Controls">
        <i class="fas fa-cogs"></i>
    </a>
    <!-- Sync button as AJAX trigger -->
    <button type="button" class="sync-btn" id="syncBtn" title="Finance Controls - Sync Fees">
        <i class="fas fa-sync-alt"></i>
    </button>
</div>
<script>
    // Theme toggle
    document.addEventListener('DOMContentLoaded', function() {
        const btn = document.getElementById('themeToggleBtn');
        if (btn) {
            btn.addEventListener('click', function() {
                document.body.classList.toggle('dark-mode');
                this.querySelector('i').classList.toggle('fa-moon');
                this.querySelector('i').classList.toggle('fa-sun');
            });
        }

        // Sync button AJAX
        const syncBtn = document.getElementById('syncBtn');
        const syncToast = document.getElementById('syncToast');
        const syncToastMsg = document.getElementById('syncToastMsg');
        let syncTimeout;
        if (syncBtn) {
            syncBtn.addEventListener('click', function() {
                syncBtn.disabled = true;
                syncBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
                const payload = new URLSearchParams({
                    csrf_token: <?= json_encode($csrfToken) ?>
                });
                fetch('account-sync-fees.php', {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    },
                    body: payload.toString()
                })
                .then(response => response.json())
                .then(data => {
                    syncBtn.disabled = false;
                    syncBtn.innerHTML = '<i class="fas fa-sync-alt"></i>';
                    let msg = (data && data.success)
                        ? ('<i class="fas fa-check-circle"></i> Sync successful!')
                        : ('<i class="fas fa-times-circle"></i> Sync failed: ' + (data && data.message ? data.message : 'Unknown error'));
                    syncToast.className = 'sync-toast ' + (data && data.success ? 'success' : 'error');
                    syncToastMsg.innerHTML = msg;
                    syncToast.style.display = 'flex';
                    clearTimeout(syncTimeout);
                    syncTimeout = setTimeout(() => { syncToast.style.display = 'none'; }, 3500);
                })
                .catch(err => {
                    syncBtn.disabled = false;
                    syncBtn.innerHTML = '<i class="fas fa-sync-alt"></i>';
                    syncToast.className = 'sync-toast error';
                    syncToastMsg.innerHTML = '<i class="fas fa-times-circle"></i> Sync failed: ' + err;
                    syncToast.style.display = 'flex';
                    clearTimeout(syncTimeout);
                    syncTimeout = setTimeout(() => { syncToast.style.display = 'none'; }, 3500);
                });
            });
        }
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="/school-admin-dashboard/assets/js/dashboard.js"></script>
</body>
</html>
<?php $stmt->close(); $conn->close(); ?>
