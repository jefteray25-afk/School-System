<?php

require_once __DIR__ . '/../../includes/schema-migration.php';

function receipt_turnover_bulletin_ensure_table(mysqli $conn): bool
{
    schema_migration_attempt($conn, "
        CREATE TABLE IF NOT EXISTS receipt_turnover_bulletins (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(140) NOT NULL,
            receipt_channel VARCHAR(40) NOT NULL DEFAULT 'cash',
            receipt_scope VARCHAR(180) DEFAULT NULL,
            note_text TEXT NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            created_by VARCHAR(100) DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_by VARCHAR(100) DEFAULT NULL,
            updated_at DATETIME DEFAULT NULL,
            resolved_by VARCHAR(100) DEFAULT NULL,
            resolved_at DATETIME DEFAULT NULL,
            INDEX idx_receipt_turnover_status_created (status, created_at),
            INDEX idx_receipt_turnover_channel_status (receipt_channel, status),
            INDEX idx_receipt_turnover_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    if (!receipt_turnover_bulletin_has_channel_column($conn)) {
        schema_migration_attempt($conn, "ALTER TABLE receipt_turnover_bulletins ADD COLUMN receipt_channel VARCHAR(40) NOT NULL DEFAULT 'cash' AFTER title");
    }
    if (!receipt_turnover_bulletin_has_index($conn, 'idx_receipt_turnover_channel_status')) {
        schema_migration_attempt($conn, "CREATE INDEX idx_receipt_turnover_channel_status ON receipt_turnover_bulletins (receipt_channel, status)");
    }

    return receipt_turnover_bulletin_table_ready($conn);
}

function receipt_turnover_bulletin_table_ready(mysqli $conn): bool
{
    $result = $conn->query("SHOW TABLES LIKE 'receipt_turnover_bulletins'");
    return $result instanceof mysqli_result && $result->num_rows > 0;
}

function receipt_turnover_bulletin_has_channel_column(mysqli $conn): bool
{
    if (!receipt_turnover_bulletin_table_ready($conn)) {
        return false;
    }
    $result = $conn->query("SHOW COLUMNS FROM receipt_turnover_bulletins LIKE 'receipt_channel'");
    return $result instanceof mysqli_result && $result->num_rows > 0;
}

function receipt_turnover_bulletin_has_index(mysqli $conn, string $indexName): bool
{
    if (!receipt_turnover_bulletin_table_ready($conn)) {
        return false;
    }
    $safeIndex = $conn->real_escape_string($indexName);
    $result = $conn->query("SHOW INDEX FROM receipt_turnover_bulletins WHERE Key_name = '{$safeIndex}'");
    return $result instanceof mysqli_result && $result->num_rows > 0;
}

function receipt_turnover_bulletin_missing_message(): string
{
    return schema_migration_missing_schema_message('receipt turnover bulletin');
}

function receipt_turnover_bulletin_normalize_status(string $status): string
{
    $status = strtolower(trim($status));
    return $status === 'resolved' ? 'resolved' : 'active';
}

function receipt_turnover_bulletin_normalize_channel(string $channel): string
{
    $channel = strtolower(trim($channel));
    $channel = str_replace([' ', '-', '/'], '_', $channel);
    if (in_array($channel, ['bank', 'bank_transfer', 'gcash', 'bank_transfer_gcash', 'online'], true)) {
        return 'bank_gcash';
    }
    if ($channel === 'other') {
        return 'other';
    }
    return 'cash';
}

function receipt_turnover_bulletin_channel_label(string $channel): string
{
    $channel = receipt_turnover_bulletin_normalize_channel($channel);
    if ($channel === 'bank_gcash') {
        return 'Bank Transfer / GCash';
    }
    if ($channel === 'other') {
        return 'Other';
    }
    return 'Cash';
}

function receipt_turnover_bulletin_load(mysqli $conn, int $limit = 80): array
{
    if (!receipt_turnover_bulletin_table_ready($conn)) {
        return [];
    }

    $limit = max(1, min(200, $limit));
    $channelSelect = receipt_turnover_bulletin_has_channel_column($conn) ? 'receipt_channel' : "'cash' AS receipt_channel";
    $sql = "
        SELECT id, title, {$channelSelect}, receipt_scope, note_text, status, created_by, created_at, updated_by, updated_at, resolved_by, resolved_at
        FROM receipt_turnover_bulletins
        ORDER BY CASE WHEN status = 'active' THEN 0 ELSE 1 END ASC, created_at DESC, id DESC
        LIMIT ?
    ";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return [];
    }
    $stmt->bind_param('i', $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    $stmt->close();
    return $rows;
}

function receipt_turnover_bulletin_counts(array $rows): array
{
    $counts = ['active' => 0, 'resolved' => 0];
    foreach ($rows as $row) {
        $status = receipt_turnover_bulletin_normalize_status((string) ($row['status'] ?? 'active'));
        $counts[$status]++;
    }
    return $counts;
}

function receipt_turnover_bulletin_find(array $rows, int $id): ?array
{
    foreach ($rows as $row) {
        if ((int) ($row['id'] ?? 0) === $id) {
            return $row;
        }
    }
    return null;
}

function receipt_turnover_bulletin_create(mysqli $conn, string $channel, string $scope, string $note, string $username): bool
{
    $channel = receipt_turnover_bulletin_normalize_channel($channel);
    $title = receipt_turnover_bulletin_channel_label($channel);
    if (receipt_turnover_bulletin_has_channel_column($conn)) {
        $stmt = $conn->prepare("INSERT INTO receipt_turnover_bulletins (title, receipt_channel, receipt_scope, note_text, status, created_by) VALUES (?, ?, ?, ?, 'active', ?)");
        if (!$stmt) {
            return false;
        }
        $stmt->bind_param('sssss', $title, $channel, $scope, $note, $username);
    } else {
        $stmt = $conn->prepare("INSERT INTO receipt_turnover_bulletins (title, receipt_scope, note_text, status, created_by) VALUES (?, ?, ?, 'active', ?)");
        if (!$stmt) {
            return false;
        }
        $stmt->bind_param('ssss', $title, $scope, $note, $username);
    }
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function receipt_turnover_bulletin_update(mysqli $conn, int $id, string $channel, string $scope, string $note, string $status, string $username): bool
{
    $channel = receipt_turnover_bulletin_normalize_channel($channel);
    $title = receipt_turnover_bulletin_channel_label($channel);
    $status = receipt_turnover_bulletin_normalize_status($status);
    $channelSql = receipt_turnover_bulletin_has_channel_column($conn) ? 'receipt_channel = ?, ' : '';
    $resolvedBySql = $status === 'resolved' ? ', resolved_by = ?, resolved_at = COALESCE(resolved_at, NOW())' : ', resolved_by = NULL, resolved_at = NULL';
    $sql = "UPDATE receipt_turnover_bulletins SET title = ?, {$channelSql}receipt_scope = ?, note_text = ?, status = ?, updated_by = ?, updated_at = NOW(){$resolvedBySql} WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return false;
    }
    $hasChannel = receipt_turnover_bulletin_has_channel_column($conn);
    if ($status === 'resolved' && $hasChannel) {
        $stmt->bind_param('sssssssi', $title, $channel, $scope, $note, $status, $username, $username, $id);
    } elseif ($status === 'resolved') {
        $stmt->bind_param('ssssssi', $title, $scope, $note, $status, $username, $username, $id);
    } elseif ($hasChannel) {
        $stmt->bind_param('ssssssi', $title, $channel, $scope, $note, $status, $username, $id);
    } else {
        $stmt->bind_param('sssssi', $title, $scope, $note, $status, $username, $id);
    }
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function receipt_turnover_bulletin_set_status(mysqli $conn, int $id, string $status, string $username): bool
{
    $status = receipt_turnover_bulletin_normalize_status($status);
    if ($status === 'resolved') {
        $stmt = $conn->prepare("UPDATE receipt_turnover_bulletins SET status = 'resolved', updated_by = ?, updated_at = NOW(), resolved_by = ?, resolved_at = NOW() WHERE id = ?");
        if (!$stmt) {
            return false;
        }
        $stmt->bind_param('ssi', $username, $username, $id);
    } else {
        $stmt = $conn->prepare("UPDATE receipt_turnover_bulletins SET status = 'active', updated_by = ?, updated_at = NOW(), resolved_by = NULL, resolved_at = NULL WHERE id = ?");
        if (!$stmt) {
            return false;
        }
        $stmt->bind_param('si', $username, $id);
    }
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

function receipt_turnover_bulletin_delete(mysqli $conn, int $id): bool
{
    $stmt = $conn->prepare("DELETE FROM receipt_turnover_bulletins WHERE id = ?");
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('i', $id);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}