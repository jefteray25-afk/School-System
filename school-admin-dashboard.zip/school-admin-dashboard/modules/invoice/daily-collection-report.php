<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/includes-receipt-helper.php';
require_once __DIR__ . '/../../includes/receipt-payment-method-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/schema-migration.php';
require_once __DIR__ . '/../audit/audit-helper.php';

function ensure_old_payment_datetime_column(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }
    $columnName = 'paid_at_datetime';
    $check = $conn->prepare("
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'old_student_payments'
          AND COLUMN_NAME = ?
        LIMIT 1
    ");
    $check->bind_param('s', $columnName);
    $check->execute();
    $exists = $check->get_result()->num_rows > 0;
    $check->close();
    if (!$exists) {
        schema_migration_attempt($conn, "ALTER TABLE old_student_payments ADD COLUMN paid_at_datetime DATETIME NULL AFTER paid_at");
    }
}

function collection_detect_payment_mode(string $primary = '', string $secondary = ''): string
{
    $haystack = strtolower(trim($primary . ' ' . $secondary));
    if (strpos($haystack, 'bank transfer') !== false || strpos($haystack, 'banktransfer') !== false) {
        return 'Bank Transfer';
    }
    if (strpos($haystack, 'gcash') !== false) {
        return 'GCash';
    }
    if (preg_match('/\bcash\b/i', $haystack)) {
        return 'Cash';
    }
    return 'Cash';
}

function collection_extract_reference(string ...$parts): string
{
    $text = trim(implode(' ', $parts));
    if ($text === '') {
        return '-';
    }
    foreach ([
        '/Ref#:\s*([^\)\]\s,;]+)/i',
        '/Ref\s*#?\s*[:\-]?\s*([^\)\]\s,;]+)/i',
        '/Reference\s*(?:No\.?|Number)?\s*[:\-]?\s*([^\)\]\s,;]+)/i',
    ] as $pattern) {
        if (preg_match($pattern, $text, $matches)) {
            return trim($matches[1]);
        }
    }
    return '-';
}

function collection_money(float $amount): string
{
    return 'PHP ' . number_format($amount, 2);
}

function collection_h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function collection_normalize_date(string $value): string
{
    $value = trim($value);
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
        return '';
    }
    $timestamp = strtotime($value);
    if ($timestamp === false) {
        return '';
    }
    return date('Y-m-d', $timestamp);
}

function collection_resolve_range(string $rangeKey, string $startDate, string $endDate): array
{
    $today = date('Y-m-d');
    return match ($rangeKey) {
        'yesterday' => [
            'start' => date('Y-m-d', strtotime('-1 day')),
            'end' => date('Y-m-d', strtotime('-1 day')),
            'label' => 'Yesterday',
            'key' => 'yesterday',
        ],
        'this_week' => [
            'start' => date('Y-m-d', strtotime('monday this week')),
            'end' => $today,
            'label' => 'This Week',
            'key' => 'this_week',
        ],
        'custom' => [
            'start' => $startDate,
            'end' => $endDate,
            'label' => $startDate === $endDate ? $startDate : ($startDate . ' to ' . $endDate),
            'key' => 'custom',
        ],
        default => [
            'start' => $today,
            'end' => $today,
            'label' => 'Today',
            'key' => 'today',
        ],
    };
}

ensure_old_payment_datetime_column($conn);
ensure_receipts_registry_schema($conn);
if (function_exists('ensure_payments_prepared_by_column')) {
    ensure_payments_prepared_by_column($conn);
}
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);

$currentRole = $_SESSION['role'] ?? '';
if (!hasPermission($currentRole, 'financial', 'view')) {
    audit_log(
        $conn,
        $_SESSION['username'] ?? 'unknown',
        'Blocked daily collection report access',
        'Invoice',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing financial:view permission',
        'SECURITY'
    );
    header('Location: /school-admin-dashboard/dashboard.php?error=invoice_denied');
    exit();
}

$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$schoolName = 'The Lord\'s Wisdom Academy Of Caloocan Inc.';
$school_year_options = school_year_finance_options($conn, 'payments');
$active_school_year_label = school_year_get_active_label($conn);
$selected_school_year = trim($_GET['school_year'] ?? '');
if ($selected_school_year === '') {
    $selected_school_year = $active_school_year_label;
}
$selected_range = trim((string) ($_GET['range'] ?? 'today'));
$rangeStart = collection_normalize_date((string) ($_GET['start_date'] ?? ''));
$rangeEnd = collection_normalize_date((string) ($_GET['end_date'] ?? ''));
$legacyCollectionDate = collection_normalize_date((string) ($_GET['collection_date'] ?? ''));
if ($rangeStart !== '' || $rangeEnd !== '') {
    $selected_range = 'custom';
}
if ($selected_range === 'custom') {
    if ($rangeStart === '' && $legacyCollectionDate !== '') {
        $rangeStart = $legacyCollectionDate;
    }
    if ($rangeEnd === '' && $legacyCollectionDate !== '') {
        $rangeEnd = $legacyCollectionDate;
    }
}
if ($selected_range === '') {
    $selected_range = ($rangeStart !== '' || $rangeEnd !== '') ? 'custom' : 'today';
}
if ($selected_range !== 'custom' && $legacyCollectionDate !== '' && !isset($_GET['range'])) {
    $selected_range = 'custom';
    $rangeStart = $legacyCollectionDate;
    $rangeEnd = $legacyCollectionDate;
}
if ($selected_range === 'custom') {
    if ($rangeStart === '' && $rangeEnd !== '') {
        $rangeStart = $rangeEnd;
    }
    if ($rangeEnd === '' && $rangeStart !== '') {
        $rangeEnd = $rangeStart;
    }
    if ($rangeStart === '' || $rangeEnd === '') {
        $selected_range = 'today';
    }
}
$resolvedRange = collection_resolve_range($selected_range, $rangeStart, $rangeEnd);
$rangeStart = $resolvedRange['start'];
$rangeEnd = $resolvedRange['end'];
$selected_range = $resolvedRange['key'];
$rangeLabel = $resolvedRange['label'];
$rangeStartDateTime = $rangeStart . ' 00:00:00';
$rangeEndDateTime = $rangeEnd . ' 23:59:59';
$source_filter = trim($_GET['source'] ?? '');
$mode_filter = trim($_GET['mode'] ?? '');

$transactions = [];
$modeTotals = [
    'Cash' => ['amount' => 0.0, 'count' => 0],
    'GCash' => ['amount' => 0.0, 'count' => 0],
    'Bank Transfer' => ['amount' => 0.0, 'count' => 0],
];
$sourceTotals = [
    'Active' => ['amount' => 0.0, 'count' => 0],
    'Old' => ['amount' => 0.0, 'count' => 0],
];
$grandTotal = 0.0;

$activeSql = "
SELECT
    p.id,
    p.date_paid AS occurred_at,
    p.booklet_no,
    p.receipt_no,
    p.amount,
    p.receipt_note,
    p.remarks,
    COALESCE(NULLIF(TRIM(p.prepared_by), ''), 'System') AS processed_by,
    s.grade,
    s.lrn,
    CONCAT(s.lastname, ', ', s.firstname, CASE WHEN TRIM(COALESCE(s.middlename, '')) <> '' THEN CONCAT(' ', s.middlename) ELSE '' END) AS payee_name,
    COALESCE(at.name, a.type, 'Uncategorized') AS school_fee
FROM payments p
INNER JOIN receipts_registry rr
    ON rr.receipt_no = p.receipt_no
    AND rr.booklet_no = p.booklet_no
    AND rr.voided = 0
    AND rr.used_by IN ('payments', 'other_payment')
LEFT JOIN accounts a ON p.account_id = a.id
LEFT JOIN account_types at ON at.name = a.type
LEFT JOIN students s ON a.student_id = s.id
WHERE p.date_paid >= ?
  AND p.date_paid <= ?
  AND p.booklet_no IS NOT NULL
  AND p.receipt_no IS NOT NULL
  AND COALESCE(NULLIF(TRIM(p.school_year_label), ''), NULLIF(TRIM(a.school_year_label), ''), NULLIF(TRIM(s.school_year_label), '')) = ?
ORDER BY p.date_paid DESC, p.id DESC
";
$activeStmt = $conn->prepare($activeSql);
$activeStmt->bind_param('sss', $rangeStartDateTime, $rangeEndDateTime, $selected_school_year);
$activeStmt->execute();
$activeResult = $activeStmt->get_result();
while ($row = $activeResult->fetch_assoc()) {
    $methodBreakdown = receipt_payment_methods_for_display(
        $conn,
        (int) ($row['booklet_no'] ?? 0),
        (int) ($row['receipt_no'] ?? 0),
        null,
        (string) ($row['receipt_note'] ?? '')
    );
    $mode = receipt_payment_methods_display_label($methodBreakdown, collection_detect_payment_mode((string) ($row['receipt_note'] ?? ''), (string) ($row['remarks'] ?? '')));
    if ($mode_filter !== '' && $mode !== $mode_filter) {
        continue;
    }
    if ($source_filter !== '' && $source_filter !== 'Active') {
        continue;
    }

    $amount = (float) ($row['amount'] ?? 0);
    $transactions[] = [
        'source' => 'Active',
        'occurred_at' => (string) ($row['occurred_at'] ?? ''),
        'payee_name' => (string) ($row['payee_name'] ?? 'Unknown Student'),
        'grade' => (string) ($row['grade'] ?? '-'),
        'lrn' => (string) ($row['lrn'] ?? '-'),
        'booklet_label' => booklet_label_from_stored((int) ($row['booklet_no'] ?? 0)),
        'receipt_no' => (string) ($row['receipt_no'] ?? ''),
        'school_fee' => (string) ($row['school_fee'] ?? 'Uncategorized'),
        'mode' => $mode,
        'reference' => receipt_payment_methods_reference_display($methodBreakdown, collection_extract_reference((string) ($row['receipt_note'] ?? ''), (string) ($row['remarks'] ?? ''))),
        'processed_by' => (string) ($row['processed_by'] ?? 'System'),
        'amount' => $amount,
    ];
    $modeTotals[$mode]['amount'] += $amount;
    $modeTotals[$mode]['count']++;
    $sourceTotals['Active']['amount'] += $amount;
    $sourceTotals['Active']['count']++;
    $grandTotal += $amount;
}
$activeStmt->close();

$oldSql = "
SELECT
    p.id,
    COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) AS occurred_at,
    p.booklet_no,
    p.receipt_no,
    p.amount AS amount,
    p.note,
    p.fee_type AS school_fee,
    CONCAT(s.lastname, ', ', s.firstname, CASE WHEN TRIM(COALESCE(s.middlename, '')) <> '' THEN CONCAT(' ', s.middlename) ELSE '' END) AS payee_name,
    s.school_year,
    s.contact,
    s.status
FROM old_student_payments p
INNER JOIN receipts_registry rr
    ON rr.receipt_no = p.receipt_no
    AND rr.booklet_no = p.booklet_no
    AND rr.voided = 0
    AND rr.used_by = 'old_student_payments'
LEFT JOIN old_students s ON s.id = p.old_student_id
WHERE COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) >= ?
  AND COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) <= ?
  AND p.booklet_no IS NOT NULL
  AND p.receipt_no IS NOT NULL
  AND COALESCE(NULLIF(TRIM(s.school_year), ''), ?) = ?
  AND (p.deleted_at IS NULL OR p.deleted_at = '')
ORDER BY COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) DESC, p.id DESC
";
$oldStmt = $conn->prepare($oldSql);
$oldStmt->bind_param('ssss', $rangeStartDateTime, $rangeEndDateTime, $selected_school_year, $selected_school_year);
$oldStmt->execute();
$oldResult = $oldStmt->get_result();
while ($row = $oldResult->fetch_assoc()) {
    $methodBreakdown = receipt_payment_methods_for_display(
        $conn,
        (int) ($row['booklet_no'] ?? 0),
        (int) ($row['receipt_no'] ?? 0),
        'old_student_payments'
    );
    $mode = receipt_payment_methods_display_label($methodBreakdown, collection_detect_payment_mode((string) ($row['note'] ?? '')));
    if ($mode_filter !== '' && $mode !== $mode_filter) {
        continue;
    }
    if ($source_filter !== '' && $source_filter !== 'Old') {
        continue;
    }

    $amount = (float) ($row['amount'] ?? 0);
    $transactions[] = [
        'source' => 'Old',
        'occurred_at' => (string) ($row['occurred_at'] ?? ''),
        'payee_name' => (string) ($row['payee_name'] ?? 'Unknown Student'),
        'grade' => (string) ($row['status'] ?? '-'),
        'lrn' => '-',
        'booklet_label' => booklet_label_from_stored((int) ($row['booklet_no'] ?? 0)),
        'receipt_no' => (string) ($row['receipt_no'] ?? ''),
        'school_fee' => (string) ($row['school_fee'] ?? 'Old Payment'),
        'mode' => $mode,
        'reference' => receipt_payment_methods_reference_display($methodBreakdown, collection_extract_reference((string) ($row['note'] ?? ''))),
        'processed_by' => 'Old Account',
        'amount' => $amount,
    ];
    $modeTotals[$mode]['amount'] += $amount;
    $modeTotals[$mode]['count']++;
    $sourceTotals['Old']['amount'] += $amount;
    $sourceTotals['Old']['count']++;
    $grandTotal += $amount;
}
$oldStmt->close();

usort($transactions, static function (array $left, array $right): int {
    return strcmp((string) ($right['occurred_at'] ?? ''), (string) ($left['occurred_at'] ?? ''));
});

$groupedTransactions = [];
foreach ($transactions as $transaction) {
    $groupKey = ($transaction['source'] ?? '') . '|' . ($transaction['booklet_label'] ?? '') . '|' . ($transaction['receipt_no'] ?? '');
    if (!isset($groupedTransactions[$groupKey])) {
        $groupedTransactions[$groupKey] = $transaction;
        $groupedTransactions[$groupKey]['items'] = [];
        $groupedTransactions[$groupKey]['items_count'] = 0;
        $groupedTransactions[$groupKey]['total_amount'] = 0.0;
    }
    $groupedTransactions[$groupKey]['items'][] = [
        'fee' => (string) ($transaction['school_fee'] ?? 'Uncategorized'),
        'amount' => (float) ($transaction['amount'] ?? 0),
    ];
    $groupedTransactions[$groupKey]['items_count']++;
    $groupedTransactions[$groupKey]['total_amount'] += (float) ($transaction['amount'] ?? 0);
}
$transactions = array_values($groupedTransactions);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daily Collection Report | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --page-bg: #eef4fb;
            --surface: #ffffff;
            --surface-soft: #f7fafc;
            --line: #dbe6f0;
            --ink: #223248;
            --muted: #6d7c8c;
            --blue: #2463a6;
            --green: #2f7d5a;
            --cyan: #277f95;
            --amber: #9a6a19;
        }
        body {
            background: linear-gradient(180deg, #f8fbff 0%, var(--page-bg) 100%);
            color: var(--ink);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        }
        .navbar { background:#23395d !important; }
        .navbar-brand, .navbar-nav .nav-link { color:#fff !important; }
        .page-wrap {
            margin: 30px auto 34px;
            max-width: 1880px;
            padding: 0 14px;
            width: min(1880px, 100%);
        }
        .hero,
        .panel,
        .summary-card {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 8px;
            box-shadow: 0 14px 30px rgba(34,50,72,.07);
        }
        .hero {
            margin-bottom: 14px;
            padding: 22px;
        }
        .hero-kicker {
            color: var(--muted);
            font-size: .76rem;
            font-weight: 850;
            letter-spacing: .08em;
            text-transform: uppercase;
        }
        .hero-title {
            color: var(--ink);
            font-size: clamp(1.35rem, 2vw, 1.9rem);
            font-weight: 900;
            letter-spacing: 0;
            margin: 4px 0 3px;
        }
        .hero-copy,
        .hero-school {
            color: var(--muted);
        }
        .hero-copy {
            margin: 0;
        }
        .hero-school {
            font-size: .86rem;
            margin-top: 6px;
        }
        .toolbar-btn {
            align-items: center;
            border-radius: 8px;
            display: inline-flex;
            font-weight: 800;
            gap: 7px;
            min-height: 40px;
        }
        .panel {
            padding: 16px;
        }
        .filter-panel {
            margin-bottom: 14px;
        }
        .filter-panel .form-label {
            color: var(--ink);
            font-size: .79rem;
            font-weight: 850;
            margin-bottom: 5px;
        }
        .filter-panel .form-control,
        .filter-panel .form-select {
            border-color: var(--line);
            border-radius: 8px;
            min-height: 42px;
        }
        .filter-actions .btn {
            border-radius: 8px;
            font-weight: 800;
            min-height: 42px;
        }
        .range-shortcuts {
            align-items: center;
            display: flex;
            flex-wrap: wrap;
            gap: .5rem;
            margin-top: .2rem;
        }
        .range-shortcuts .btn {
            border-radius: 999px;
            font-weight: 800;
            padding: .35rem .72rem;
        }
        .range-label {
            background: var(--surface-soft);
            border: 1px solid var(--line);
            border-radius: 999px;
            color: var(--muted);
            font-size: .82rem;
            font-weight: 750;
            padding: .35rem .72rem;
        }
        .summary-grid {
            display: grid;
            gap: 12px;
            grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
            margin-bottom: 14px;
        }
        .summary-card {
            box-shadow: 0 10px 24px rgba(34,50,72,.055);
            overflow: hidden;
            padding: 15px 16px;
            position: relative;
        }
        .summary-card::before {
            background: var(--blue);
            content: "";
            height: 3px;
            left: 0;
            position: absolute;
            right: 0;
            top: 0;
        }
        .summary-card.total::before { background: var(--green); }
        .summary-card.old::before { background: var(--amber); }
        .summary-card.mode::before { background: var(--cyan); }
        .summary-label {
            color: var(--muted);
            font-size: .74rem;
            font-weight: 850;
            letter-spacing: .05em;
            text-transform: uppercase;
        }
        .summary-value {
            color: var(--ink);
            font-size: clamp(1.15rem, 1.5vw, 1.42rem);
            font-weight: 900;
            letter-spacing: 0;
            margin-top: 4px;
        }
        .table-panel {
            padding: 0;
            overflow: hidden;
        }
        .table-toolbar {
            align-items: center;
            border-bottom: 1px solid var(--line);
            display: flex;
            gap: 12px;
            justify-content: space-between;
            padding: 15px 16px;
        }
        .table-title {
            color: var(--ink);
            font-size: 1rem;
            font-weight: 900;
            margin: 0;
        }
        .table-context {
            background: var(--surface-soft);
            border: 1px solid var(--line);
            border-radius: 999px;
            color: var(--muted);
            font-size: .82rem;
            font-weight: 750;
            padding: .35rem .72rem;
        }
        .panel .table-responsive {
            overflow-x: auto;
        }
        .panel .table {
            margin: 0;
            min-width: 1320px;
            width: 100%;
        }
        .panel .table td,
        .panel .table th {
            border-color: #e7eef6;
            vertical-align: middle;
        }
        .table thead th {
            background: #f3f7fb;
            color: #526477;
            font-size: .74rem;
            font-weight: 900;
            letter-spacing: .04em;
            position: sticky;
            text-transform: uppercase;
            top: 0;
            white-space: nowrap;
            z-index: 1;
        }
        .table tbody tr:hover td {
            background: #fbfdff;
        }
        .source-badge {
            border-radius: 999px;
            font-weight: 800;
            padding: .38rem .55rem;
        }
        .mode-pill {
            background: #eef7f4;
            border: 1px solid #d4eadf;
            border-radius: 999px;
            color: #2f7d5a;
            display: inline-flex;
            font-size: .78rem;
            font-weight: 850;
            padding: .32rem .58rem;
        }
        .breakdown-btn {
            border-radius: 999px;
            font-size: .78rem;
            font-weight: 850;
            padding: .32rem .58rem;
            white-space: nowrap;
        }
        .breakdown-row td {
            background: #f8fbff !important;
        }
        .collection-col-datetime { min-width: 150px; white-space: nowrap; }
        .collection-col-source { min-width: 86px; white-space: nowrap; }
        .collection-col-payee { min-width: 230px; }
        .collection-col-grade { min-width: 122px; white-space: nowrap; }
        .collection-col-booklet { min-width: 96px; white-space: nowrap; }
        .collection-col-receipt { min-width: 100px; white-space: nowrap; }
        .collection-col-fee { min-width: 200px; }
        .collection-col-mode { min-width: 112px; white-space: nowrap; }
        .collection-col-processed { min-width: 126px; white-space: nowrap; }
        .collection-col-reference { min-width: 118px; white-space: nowrap; }
        .collection-col-amount { min-width: 124px; white-space: nowrap; }
        .payee-cell .fw-semibold {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        .payee-cell .small {
            white-space: nowrap;
        }
        .collapse .table-sm td,
        .collapse .table-sm th {
            padding: 0.42rem 0.62rem;
        }
        @media (max-width: 768px) {
            .page-wrap {
                padding: 0 10px;
            }
            .hero,
            .panel {
                padding: 14px;
            }
            .table-panel {
                padding: 0;
            }
            .panel .table {
                min-width: 1240px;
            }
            .table-toolbar {
                align-items: flex-start;
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
<?php render_admin_nav('invoice', true); ?>

<div class="page-wrap">
    <div class="hero">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
            <div>
                <div class="hero-kicker">Invoice Center</div>
                <h1 class="hero-title"><i class="fas fa-cash-register me-2"></i>Daily Collection Activity</h1>
                <p class="hero-copy">Combined active and old-account payment activity for the selected range and school year.</p>
                <div class="hero-school"><?= collection_h($schoolName) ?></div>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <a href="/school-admin-dashboard/modules/invoice/export-daily-collection-report.php?school_year=<?= rawurlencode($selected_school_year) ?>&range=<?= rawurlencode($selected_range) ?>&start_date=<?= rawurlencode($rangeStart) ?>&end_date=<?= rawurlencode($rangeEnd) ?>&source=<?= rawurlencode($source_filter) ?>&mode=<?= rawurlencode($mode_filter) ?>" class="btn btn-success toolbar-btn">
                    <i class="fas fa-file-excel me-1"></i>Download Excel
                </a>
                <button type="button" class="btn btn-outline-dark toolbar-btn" onclick="window.print()">
                    <i class="fas fa-print me-1"></i>Print
                </button>
            </div>
        </div>
    </div>

    <div class="panel filter-panel">
        <form method="get" class="row g-3 align-items-end" id="collectionFilterForm">
            <div class="col-12 col-md-3">
                <label class="form-label fw-semibold">School Year</label>
                <select name="school_year" class="form-select">
                    <?php foreach ($school_year_options as $option): ?>
                        <option value="<?= collection_h($option) ?>" <?= $selected_school_year === $option ? 'selected' : '' ?>>
                            <?= collection_h($option) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 col-md-2">
                <label class="form-label fw-semibold">Range</label>
                <select name="range" class="form-select">
                    <option value="today" <?= $selected_range === 'today' ? 'selected' : '' ?>>Today</option>
                    <option value="yesterday" <?= $selected_range === 'yesterday' ? 'selected' : '' ?>>Yesterday</option>
                    <option value="this_week" <?= $selected_range === 'this_week' ? 'selected' : '' ?>>This Week</option>
                    <option value="custom" <?= $selected_range === 'custom' ? 'selected' : '' ?>>Custom Range</option>
                </select>
            </div>
            <div class="col-12 col-md-2">
                <label class="form-label fw-semibold">Start Date</label>
                <input type="date" name="start_date" class="form-control" value="<?= collection_h($rangeStart) ?>">
            </div>
            <div class="col-12 col-md-2">
                <label class="form-label fw-semibold">End Date</label>
                <input type="date" name="end_date" class="form-control" value="<?= collection_h($rangeEnd) ?>">
            </div>
            <div class="col-12 col-md-1">
                <label class="form-label fw-semibold">Source</label>
                <select name="source" class="form-select">
                    <option value="">All</option>
                    <option value="Active" <?= $source_filter === 'Active' ? 'selected' : '' ?>>Active</option>
                    <option value="Old" <?= $source_filter === 'Old' ? 'selected' : '' ?>>Old</option>
                </select>
            </div>
            <div class="col-12 col-md-2">
                <label class="form-label fw-semibold">Mode</label>
                <select name="mode" class="form-select">
                    <option value="">All</option>
                    <?php foreach (array_keys($modeTotals) as $modeOption): ?>
                        <option value="<?= collection_h($modeOption) ?>" <?= $mode_filter === $modeOption ? 'selected' : '' ?>>
                            <?= collection_h($modeOption) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 col-md-2 d-grid filter-actions">
                <button type="submit" class="btn btn-primary"><i class="fas fa-filter me-1"></i>Apply</button>
            </div>
            <div class="col-12 col-md-2 d-grid filter-actions">
                <a href="/school-admin-dashboard/modules/invoice/daily-collection-report.php?school_year=<?= rawurlencode($selected_school_year) ?>&range=today" class="btn btn-outline-secondary">
                    <i class="fas fa-rotate-left me-1"></i>Clear
                </a>
            </div>
            <div class="col-12">
                <div class="range-shortcuts">
                    <a class="btn btn-sm <?= $selected_range === 'today' ? 'btn-primary' : 'btn-outline-primary' ?>" href="?school_year=<?= rawurlencode($selected_school_year) ?>&range=today&source=<?= rawurlencode($source_filter) ?>&mode=<?= rawurlencode($mode_filter) ?>">Today</a>
                    <a class="btn btn-sm <?= $selected_range === 'yesterday' ? 'btn-primary' : 'btn-outline-primary' ?>" href="?school_year=<?= rawurlencode($selected_school_year) ?>&range=yesterday&source=<?= rawurlencode($source_filter) ?>&mode=<?= rawurlencode($mode_filter) ?>">Yesterday</a>
                    <a class="btn btn-sm <?= $selected_range === 'this_week' ? 'btn-primary' : 'btn-outline-primary' ?>" href="?school_year=<?= rawurlencode($selected_school_year) ?>&range=this_week&source=<?= rawurlencode($source_filter) ?>&mode=<?= rawurlencode($mode_filter) ?>">This Week</a>
                    <span class="range-label">Current range: <?= collection_h($rangeLabel) ?></span>
                </div>
            </div>
        </form>
    </div>

    <div class="summary-grid">
        <div class="summary-card">
            <div class="summary-label">Transactions</div>
            <div class="summary-value"><?= number_format(count($transactions)) ?></div>
        </div>
        <div class="summary-card total">
            <div class="summary-label">Grand Total</div>
            <div class="summary-value"><?= collection_h(collection_money($grandTotal)) ?></div>
        </div>
        <div class="summary-card">
            <div class="summary-label">Active Collections</div>
            <div class="summary-value"><?= collection_h(collection_money($sourceTotals['Active']['amount'])) ?></div>
        </div>
        <div class="summary-card old">
            <div class="summary-label">Old Collections</div>
            <div class="summary-value"><?= collection_h(collection_money($sourceTotals['Old']['amount'])) ?></div>
        </div>
    </div>

    <div class="summary-grid">
        <?php foreach ($modeTotals as $modeName => $modeSummary): ?>
            <div class="summary-card mode">
                <div class="summary-label"><?= collection_h($modeName) ?></div>
                <div class="summary-value"><?= collection_h(collection_money($modeSummary['amount'])) ?></div>
                <div class="small text-muted mt-1"><?= number_format($modeSummary['count']) ?> transaction(s)</div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="panel table-panel">
        <div class="table-toolbar">
            <h2 class="table-title"><i class="fas fa-list-check me-2"></i>Payment Activity Transactions</h2>
            <div class="table-context"><?= collection_h($rangeLabel) ?> | <?= collection_h($selected_school_year) ?></div>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th class="collection-col-datetime">Date/Time</th>
                        <th class="collection-col-source">Source</th>
                        <th class="collection-col-payee">Payee</th>
                        <th class="collection-col-grade">Grade/Status</th>
                        <th class="collection-col-booklet">Booklet</th>
                        <th class="collection-col-receipt">Receipt No</th>
                        <th class="collection-col-fee">School Fee</th>
                        <th class="collection-col-mode">Mode</th>
                        <th class="collection-col-processed">Processed By</th>
                        <th class="collection-col-reference">Reference</th>
                        <th class="collection-col-amount text-end">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!$transactions): ?>
                        <tr>
                            <td colspan="11" class="text-center text-muted py-4">No collection records found for the selected filters.</td>
                        </tr>
                    <?php else: ?>
                        <?php $rowIndex = 0; ?>
                        <?php foreach ($transactions as $transaction): ?>
                            <?php
                                $rowIndex++;
                                $collapseId = 'daily-breakdown-' . $rowIndex;
                                $itemsCount = (int) ($transaction['items_count'] ?? 0);
                            ?>
                            <tr>
                                <td class="collection-col-datetime"><?= collection_h($transaction['occurred_at']) ?></td>
                                <td class="collection-col-source"><span class="badge source-badge <?= $transaction['source'] === 'Active' ? 'bg-primary' : 'bg-secondary' ?>"><?= collection_h($transaction['source']) ?></span></td>
                                <td class="collection-col-payee payee-cell">
                                    <div class="fw-semibold"><?= collection_h($transaction['payee_name']) ?></div>
                                    <div class="small text-muted"><?= collection_h($transaction['lrn']) ?></div>
                                </td>
                                <td class="collection-col-grade"><?= collection_h($transaction['grade']) ?></td>
                                <td class="collection-col-booklet"><?= collection_h($transaction['booklet_label']) ?></td>
                                <td class="collection-col-receipt"><?= collection_h($transaction['receipt_no']) ?></td>
                                <td class="collection-col-fee">
                                    <?php if ($itemsCount > 1): ?>
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <span><?= $itemsCount ?> items</span>
                                            <button type="button" class="btn btn-sm btn-outline-primary breakdown-btn" data-bs-toggle="collapse" data-bs-target="#<?= $collapseId ?>" aria-expanded="false" aria-controls="<?= $collapseId ?>">
                                                View breakdown
                                            </button>
                                        </div>
                                    <?php else: ?>
                                        <?= collection_h($transaction['school_fee']) ?>
                                    <?php endif; ?>
                                </td>
                                <td class="collection-col-mode"><span class="mode-pill"><?= collection_h($transaction['mode']) ?></span></td>
                                <td class="collection-col-processed"><?= collection_h($transaction['processed_by'] ?? '-') ?></td>
                                <td class="collection-col-reference"><?= collection_h($transaction['reference']) ?></td>
                                <td class="collection-col-amount text-end fw-semibold"><?= collection_h(collection_money((float) ($transaction['total_amount'] ?? 0))) ?></td>
                            </tr>
                            <?php if ($itemsCount > 1): ?>
                                <tr class="collapse breakdown-row" id="<?= $collapseId ?>">
                                    <td colspan="11">
                                        <div class="p-2">
                                            <div class="fw-semibold mb-2">Receipt Breakdown</div>
                                            <div class="table-responsive">
                                                <table class="table table-sm mb-0">
                                                    <thead>
                                                        <tr><th>Fee Type</th><th class="text-end">Amount</th></tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach (($transaction['items'] ?? []) as $item): ?>
                                                            <tr>
                                                                <td><?= collection_h($item['fee']) ?></td>
                                                                <td class="text-end"><?= collection_h(collection_money((float) $item['amount'])) ?></td>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var form = document.getElementById('collectionFilterForm');
    if (!form) {
        return;
    }

    var rangeSelect = form.querySelector('select[name="range"]');
    var startDateInput = form.querySelector('input[name="start_date"]');
    var endDateInput = form.querySelector('input[name="end_date"]');

    function syncCustomRange() {
        if (!rangeSelect || !startDateInput || !endDateInput) {
            return;
        }

        if (startDateInput.value || endDateInput.value) {
            rangeSelect.value = 'custom';
        }
    }

    if (startDateInput) {
        startDateInput.addEventListener('change', syncCustomRange);
    }

    if (endDateInput) {
        endDateInput.addEventListener('change', syncCustomRange);
    }

    form.addEventListener('submit', syncCustomRange);
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<?= admin_session_warning_script() ?>
</body>
</html>
