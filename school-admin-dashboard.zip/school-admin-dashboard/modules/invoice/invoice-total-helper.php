<?php
require_once __DIR__ . '/../../includes/receipt-payment-method-helper.php';

function invoice_total_ensure_old_payment_datetime_column(mysqli $conn): void
{
    require_once __DIR__ . '/../../includes/schema-migration.php';
    if (!schema_migration_mode_enabled()) {
        return;
    }
    $columnName = 'paid_at_datetime';
    $check = $conn->prepare("
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'old_student_payments'
          AND COLUMN_NAME = ?
        LIMIT 1
    ");
    $check->bind_param('s', $columnName);
    $check->execute();
    $exists = $check->get_result()->num_rows > 0;
    $check->close();
    if (!$exists) {
        schema_migration_attempt($conn, "ALTER TABLE old_student_payments ADD COLUMN paid_at_datetime DATETIME NULL AFTER paid_at");
    }
}

function invoice_total_add_unique_note(array &$notes, string $note): void
{
    $note = trim($note);
    if ($note !== '' && !in_array($note, $notes, true)) {
        $notes[] = $note;
    }
}

function invoice_total_load_receipts(mysqli $conn, string $selectedSchoolYear, string $startDate, string $endDate): array
{
    $statusNotesToHide = ['Outstanding', 'Fully Paid', 'Low Balance'];
    $combinedReceipts = [];
    $bookletOptions = [];
    $categoryOptions = [];

    $startDate = trim($startDate);
    $endDate = trim($endDate);
    $hasStartDate = $startDate !== '';
    $hasEndDate = $endDate !== '';
    $startDateTime = $hasStartDate ? ($startDate . ' 00:00:00') : '';
    $endDateTime = $hasEndDate ? ($endDate . ' 23:59:59') : '';

    $activeSql = "
SELECT
    p.id AS payment_id,
    p.date_paid,
    p.booklet_no,
    p.receipt_no,
    p.amount,
    p.receipt_note,
    s.lrn,
    s.grade,
    CONCAT(s.lastname, ', ', s.firstname, ' ', s.middlename) AS student_name,
    COALESCE(at.name, a.type, 'Uncategorized') AS category_name
FROM payments p
INNER JOIN receipts_registry rr
    ON rr.receipt_no = p.receipt_no
    AND rr.booklet_no = p.booklet_no
    AND rr.voided = 0
    AND rr.used_by IN ('payments', 'other_payment')
LEFT JOIN accounts a ON p.account_id = a.id
LEFT JOIN account_types at ON a.type = at.name
LEFT JOIN students s ON a.student_id = s.id
WHERE p.booklet_no IS NOT NULL
  AND p.receipt_no IS NOT NULL
";
    if ($hasStartDate) {
        $activeSql .= "\n  AND p.date_paid >= ?";
    }
    if ($hasEndDate) {
        $activeSql .= "\n  AND p.date_paid <= ?";
    }
    $activeSql .= "\n  AND COALESCE(NULLIF(TRIM(p.school_year_label), ''), NULLIF(TRIM(a.school_year_label), ''), NULLIF(TRIM(s.school_year_label), '')) = ?\nORDER BY p.date_paid DESC, p.id DESC\n";

    $activeStmt = $conn->prepare($activeSql);
    if ($activeStmt) {
        $activeTypes = '';
        $activeParams = [];
        if ($hasStartDate) {
            $activeTypes .= 's';
            $activeParams[] = $startDateTime;
        }
        if ($hasEndDate) {
            $activeTypes .= 's';
            $activeParams[] = $endDateTime;
        }
        $activeTypes .= 's';
        $activeParams[] = $selectedSchoolYear;
        $activeStmt->bind_param($activeTypes, ...$activeParams);
        $activeStmt->execute();
        $activeResult = $activeStmt->get_result();
        while ($row = $activeResult->fetch_assoc()) {
            $receiptKey = 'active-' . $row['booklet_no'] . '-' . $row['receipt_no'];
            $dateTime = $row['date_paid'] ?: null;
            $categoryName = trim((string) ($row['category_name'] ?? 'Uncategorized'));

            if (!isset($combinedReceipts[$receiptKey])) {
                $combinedReceipts[$receiptKey] = [
                    'source' => 'Active',
                    'sort_datetime' => $dateTime,
                    'date_display' => $dateTime ? date('n/j/Y', strtotime($dateTime)) : '',
                    'time_display' => $dateTime ? date('g:i A', strtotime($dateTime)) : 'No time',
                    'student_name' => $row['student_name'] ?: 'Unknown Student',
                    'grade' => $row['grade'] ?: '-',
                    'lrn' => $row['lrn'] ?: '-',
                    'booklet_no' => (string) $row['booklet_no'],
                    'booklet_label' => booklet_label_from_stored((int) $row['booklet_no']),
                    'receipt_no' => (string) $row['receipt_no'],
                    'categories' => [],
                    'notes' => [],
                    'total_amount' => 0.0,
                ];
            }

            if (!isset($combinedReceipts[$receiptKey]['categories'][$categoryName])) {
                $combinedReceipts[$receiptKey]['categories'][$categoryName] = 0.0;
            }

            $combinedReceipts[$receiptKey]['categories'][$categoryName] += (float) $row['amount'];
            $combinedReceipts[$receiptKey]['total_amount'] += (float) $row['amount'];

            $methodBreakdown = receipt_payment_methods_for_display(
                $conn,
                (int) ($row['booklet_no'] ?? 0),
                (int) ($row['receipt_no'] ?? 0),
                null,
                (string) ($row['receipt_note'] ?? '')
            );
            $methodLabel = receipt_payment_methods_display_label($methodBreakdown, (string) ($row['receipt_note'] ?? ''));
            if ($methodLabel !== '') {
                invoice_total_add_unique_note($combinedReceipts[$receiptKey]['notes'], 'Method: ' . $methodLabel);
            }

            $bookletOptions[booklet_label_from_stored((int) $row['booklet_no'])] = true;
            $categoryOptions[$categoryName] = true;
        }
        $activeStmt->close();
    }

    $oldSql = "
SELECT
    p.id AS payment_id,
    p.paid_at,
    p.paid_at_datetime,
    p.booklet_no,
    p.receipt_no,
    p.amount,
    p.fee_type,
    p.note,
    CONCAT(s.lastname, ', ', s.firstname, ' ', s.middlename) AS student_name
FROM old_student_payments p
INNER JOIN receipts_registry rr
    ON rr.receipt_no = p.receipt_no
    AND rr.booklet_no = p.booklet_no
    AND rr.voided = 0
    AND rr.used_by = 'old_student_payments'
LEFT JOIN old_students s ON p.old_student_id = s.id
WHERE p.booklet_no IS NOT NULL
  AND p.receipt_no IS NOT NULL
";
    if ($hasStartDate) {
        $oldSql .= "\n  AND COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) >= ?";
    }
    if ($hasEndDate) {
        $oldSql .= "\n  AND COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) <= ?";
    }
    $oldSql .= "\n  AND COALESCE(NULLIF(TRIM(s.school_year), ''), ?) = ?\n  AND (p.deleted_at IS NULL OR p.deleted_at = '')\nORDER BY COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) DESC, p.id DESC\n";

    $oldStmt = $conn->prepare($oldSql);
    if ($oldStmt) {
        $oldTypes = '';
        $oldParams = [];
        if ($hasStartDate) {
            $oldTypes .= 's';
            $oldParams[] = $startDateTime;
        }
        if ($hasEndDate) {
            $oldTypes .= 's';
            $oldParams[] = $endDateTime;
        }
        $oldTypes .= 'ss';
        $oldParams[] = $selectedSchoolYear;
        $oldParams[] = $selectedSchoolYear;
        $oldStmt->bind_param($oldTypes, ...$oldParams);
        $oldStmt->execute();
        $oldResult = $oldStmt->get_result();
        while ($row = $oldResult->fetch_assoc()) {
            $sortDateTime = !empty($row['paid_at_datetime']) ? $row['paid_at_datetime'] : (!empty($row['paid_at']) ? $row['paid_at'] . ' 00:00:00' : null);
            $receiptKey = 'old-' . $row['booklet_no'] . '-' . $row['receipt_no'];
            $categoryName = trim((string) ($row['fee_type'] ?? 'Uncategorized'));

            if (!isset($combinedReceipts[$receiptKey])) {
                $combinedReceipts[$receiptKey] = [
                    'source' => 'Old',
                    'sort_datetime' => $sortDateTime,
                    'date_display' => $sortDateTime ? date('n/j/Y', strtotime($sortDateTime)) : '',
                    'time_display' => !empty($row['paid_at_datetime']) ? date('g:i A', strtotime($row['paid_at_datetime'])) : 'No time',
                    'student_name' => $row['student_name'] ?: 'Unknown Student',
                    'grade' => '-',
                    'lrn' => '-',
                    'booklet_no' => (string) $row['booklet_no'],
                    'booklet_label' => booklet_label_from_stored((int) $row['booklet_no']),
                    'receipt_no' => (string) $row['receipt_no'],
                    'categories' => [],
                    'notes' => [],
                    'total_amount' => 0.0,
                ];
            }

            if (!isset($combinedReceipts[$receiptKey]['categories'][$categoryName])) {
                $combinedReceipts[$receiptKey]['categories'][$categoryName] = 0.0;
            }

            $combinedReceipts[$receiptKey]['categories'][$categoryName] += (float) $row['amount'];
            $combinedReceipts[$receiptKey]['total_amount'] += (float) $row['amount'];

            if (!empty($row['note']) && !in_array(trim($row['note']), $statusNotesToHide, true)) {
                invoice_total_add_unique_note($combinedReceipts[$receiptKey]['notes'], $row['note']);
            }

            $bookletOptions[booklet_label_from_stored((int) $row['booklet_no'])] = true;
            $categoryOptions[$categoryName] = true;
        }
        $oldStmt->close();
    }

    $receipts = array_values($combinedReceipts);
    usort($receipts, static function (array $a, array $b): int {
        $timeA = $a['sort_datetime'] ? strtotime($a['sort_datetime']) : 0;
        $timeB = $b['sort_datetime'] ? strtotime($b['sort_datetime']) : 0;

        if ($timeA === $timeB) {
            return strcmp($b['receipt_no'], $a['receipt_no']);
        }

        return $timeB <=> $timeA;
    });

    $totalReceipts = count($receipts);
    $grandTotal = 0.0;
    $activeTotal = 0.0;
    $oldTotal = 0.0;

    foreach ($receipts as $receipt) {
        $grandTotal += $receipt['total_amount'];
        if ($receipt['source'] === 'Active') {
            $activeTotal += $receipt['total_amount'];
        } else {
            $oldTotal += $receipt['total_amount'];
        }
    }

    $bookletValues = array_keys($bookletOptions);
    sort($bookletValues, SORT_NATURAL);
    $categoryValues = array_keys($categoryOptions);
    sort($categoryValues, SORT_NATURAL | SORT_FLAG_CASE);

    return [
        'receipts' => $receipts,
        'booklet_values' => $bookletValues,
        'category_values' => $categoryValues,
        'total_receipts' => $totalReceipts,
        'grand_total' => $grandTotal,
        'active_total' => $activeTotal,
        'old_total' => $oldTotal,
    ];
}
