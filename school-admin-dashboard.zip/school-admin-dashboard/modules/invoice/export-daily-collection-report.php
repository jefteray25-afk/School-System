<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();

require __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/includes-receipt-helper.php';
require_once __DIR__ . '/../../includes/receipt-payment-method-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/schema-migration.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Cell\DataType;

function export_daily_ensure_old_payment_datetime_column(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }
    $columnName = 'paid_at_datetime';
    $check = $conn->prepare("
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'old_student_payments'
          AND COLUMN_NAME = ?
        LIMIT 1
    ");
    $check->bind_param('s', $columnName);
    $check->execute();
    $exists = $check->get_result()->num_rows > 0;
    $check->close();
    if (!$exists) {
        schema_migration_attempt($conn, "ALTER TABLE old_student_payments ADD COLUMN paid_at_datetime DATETIME NULL AFTER paid_at");
    }
}

function export_daily_detect_payment_mode(string $primary = '', string $secondary = ''): string
{
    $haystack = strtolower(trim($primary . ' ' . $secondary));
    if (strpos($haystack, 'bank transfer') !== false || strpos($haystack, 'banktransfer') !== false) {
        return 'Bank Transfer';
    }
    if (strpos($haystack, 'gcash') !== false) {
        return 'GCash';
    }
    if (preg_match('/\bcash\b/i', $haystack)) {
        return 'Cash';
    }
    return 'Cash';
}

function export_daily_extract_reference(string ...$parts): string
{
    $text = trim(implode(' ', $parts));
    if ($text === '') {
        return '-';
    }
    foreach ([
        '/Ref#:\s*([^\)\]\s,;]+)/i',
        '/Ref\s*#?\s*[:\-]?\s*([^\)\]\s,;]+)/i',
        '/Reference\s*(?:No\.?|Number)?\s*[:\-]?\s*([^\)\]\s,;]+)/i',
    ] as $pattern) {
        if (preg_match($pattern, $text, $matches)) {
            return trim($matches[1]);
        }
    }
    return '-';
}

function export_daily_normalize_date(string $value): string
{
    $value = trim($value);
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
        return '';
    }
    $timestamp = strtotime($value);
    if ($timestamp === false) {
        return '';
    }
    return date('Y-m-d', $timestamp);
}

function export_daily_resolve_range(string $rangeKey, string $startDate, string $endDate): array
{
    $today = date('Y-m-d');
    return match ($rangeKey) {
        'yesterday' => [
            'start' => date('Y-m-d', strtotime('-1 day')),
            'end' => date('Y-m-d', strtotime('-1 day')),
            'label' => 'Yesterday',
            'key' => 'yesterday',
        ],
        'this_week' => [
            'start' => date('Y-m-d', strtotime('monday this week')),
            'end' => $today,
            'label' => 'This Week',
            'key' => 'this_week',
        ],
        'custom' => [
            'start' => $startDate,
            'end' => $endDate,
            'label' => $startDate === $endDate ? $startDate : ($startDate . ' to ' . $endDate),
            'key' => 'custom',
        ],
        default => [
            'start' => $today,
            'end' => $today,
            'label' => 'Today',
            'key' => 'today',
        ],
    };
}

function export_daily_base_style($sheet, string $endColumn, int $lastRow): void
{
    $sheet->getStyle("A1:{$endColumn}{$lastRow}")->getFont()->setName('Arial')->setSize(11);
    $sheet->getStyle("A1:{$endColumn}1")->getFont()->setBold(true)->setSize(14);
    $sheet->getStyle("A5:{$endColumn}5")->getFont()->setBold(true);
    $sheet->getStyle("A5:{$endColumn}5")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('DCEAF7');
    $sheet->getStyle("A5:{$endColumn}{$lastRow}")->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN)->getColor()->setRGB('C7D0D9');
    $sheet->getStyle("A1:{$endColumn}{$lastRow}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
    $sheet->getStyle("A1:{$endColumn}{$lastRow}")->getAlignment()->setWrapText(true);
}

function export_daily_breakdown_text(array $items): string
{
    $lines = [];
    foreach ($items as $item) {
        $fee = trim((string) ($item['fee'] ?? 'Uncategorized'));
        $amount = (float) ($item['amount'] ?? 0);
        $lines[] = $fee . ' - PHP ' . number_format($amount, 2);
    }
    return $lines ? implode("\n", $lines) : '-';
}

if (!hasPermission($_SESSION['role'] ?? '', 'financial', 'view')) {
    admin_session_forbidden();
}

export_daily_ensure_old_payment_datetime_column($conn);
ensure_receipts_registry_schema($conn);
if (function_exists('ensure_payments_prepared_by_column')) {
    ensure_payments_prepared_by_column($conn);
}
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);

$selectedSchoolYear = trim((string) ($_GET['school_year'] ?? school_year_get_active_label($conn)));
$selectedRange = trim((string) ($_GET['range'] ?? 'today'));
$rangeStart = export_daily_normalize_date((string) ($_GET['start_date'] ?? ''));
$rangeEnd = export_daily_normalize_date((string) ($_GET['end_date'] ?? ''));
$legacyCollectionDate = export_daily_normalize_date((string) ($_GET['collection_date'] ?? ''));
if ($rangeStart !== '' || $rangeEnd !== '') {
    $selectedRange = 'custom';
}
if ($selectedRange === 'custom') {
    if ($rangeStart === '' && $legacyCollectionDate !== '') {
        $rangeStart = $legacyCollectionDate;
    }
    if ($rangeEnd === '' && $legacyCollectionDate !== '') {
        $rangeEnd = $legacyCollectionDate;
    }
}
if ($selectedRange === '') {
    $selectedRange = ($rangeStart !== '' || $rangeEnd !== '') ? 'custom' : 'today';
}
if ($selectedRange !== 'custom' && $legacyCollectionDate !== '' && !isset($_GET['range'])) {
    $selectedRange = 'custom';
    $rangeStart = $legacyCollectionDate;
    $rangeEnd = $legacyCollectionDate;
}
if ($selectedRange === 'custom') {
    if ($rangeStart === '' && $rangeEnd !== '') {
        $rangeStart = $rangeEnd;
    }
    if ($rangeEnd === '' && $rangeStart !== '') {
        $rangeEnd = $rangeStart;
    }
    if ($rangeStart === '' || $rangeEnd === '') {
        $selectedRange = 'today';
    }
}
$resolvedRange = export_daily_resolve_range($selectedRange, $rangeStart, $rangeEnd);
$rangeStart = $resolvedRange['start'];
$rangeEnd = $resolvedRange['end'];
$selectedRange = $resolvedRange['key'];
$rangeLabel = $resolvedRange['label'];
$rangeStartDateTime = $rangeStart . ' 00:00:00';
$rangeEndDateTime = $rangeEnd . ' 23:59:59';
$sourceFilter = trim((string) ($_GET['source'] ?? ''));
$modeFilter = trim((string) ($_GET['mode'] ?? ''));
$preparedBy = (string) ($_SESSION['username'] ?? 'System User');

$transactions = [];
$modeTotals = [
    'Cash' => ['amount' => 0.0, 'count' => 0],
    'GCash' => ['amount' => 0.0, 'count' => 0],
    'Bank Transfer' => ['amount' => 0.0, 'count' => 0],
];
$sourceTotals = [
    'Active' => ['amount' => 0.0, 'count' => 0],
    'Old' => ['amount' => 0.0, 'count' => 0],
];
$grandTotal = 0.0;

$activeSql = "
SELECT
    p.id,
    p.date_paid AS occurred_at,
    p.booklet_no,
    p.receipt_no,
    p.amount,
    p.receipt_note,
    p.remarks,
    COALESCE(NULLIF(TRIM(p.prepared_by), ''), 'System') AS processed_by,
    s.grade,
    s.lrn,
    CONCAT(s.lastname, ', ', s.firstname, CASE WHEN TRIM(COALESCE(s.middlename, '')) <> '' THEN CONCAT(' ', s.middlename) ELSE '' END) AS payee_name,
    COALESCE(at.name, a.type, 'Uncategorized') AS school_fee
FROM payments p
INNER JOIN receipts_registry rr
    ON rr.receipt_no = p.receipt_no
    AND rr.booklet_no = p.booklet_no
    AND rr.voided = 0
    AND rr.used_by IN ('payments', 'other_payment')
LEFT JOIN accounts a ON p.account_id = a.id
LEFT JOIN account_types at ON at.name = a.type
LEFT JOIN students s ON a.student_id = s.id
WHERE p.date_paid >= ?
  AND p.date_paid <= ?
  AND p.booklet_no IS NOT NULL
  AND p.receipt_no IS NOT NULL
  AND COALESCE(NULLIF(TRIM(p.school_year_label), ''), NULLIF(TRIM(a.school_year_label), ''), NULLIF(TRIM(s.school_year_label), '')) = ?
ORDER BY p.date_paid DESC, p.id DESC
";
$activeStmt = $conn->prepare($activeSql);
$activeStmt->bind_param('sss', $rangeStartDateTime, $rangeEndDateTime, $selectedSchoolYear);
$activeStmt->execute();
$activeResult = $activeStmt->get_result();
while ($row = $activeResult->fetch_assoc()) {
    $methodBreakdown = receipt_payment_methods_for_display(
        $conn,
        (int) ($row['booklet_no'] ?? 0),
        (int) ($row['receipt_no'] ?? 0),
        null,
        (string) ($row['receipt_note'] ?? '')
    );
    $mode = receipt_payment_methods_display_label($methodBreakdown, export_daily_detect_payment_mode((string) ($row['receipt_note'] ?? ''), (string) ($row['remarks'] ?? '')));
    if ($modeFilter !== '' && $mode !== $modeFilter) {
        continue;
    }
    if ($sourceFilter !== '' && $sourceFilter !== 'Active') {
        continue;
    }

    $amount = (float) ($row['amount'] ?? 0);
    $transactions[] = [
        'source' => 'Active',
        'occurred_at' => (string) ($row['occurred_at'] ?? ''),
        'payee_name' => (string) ($row['payee_name'] ?? 'Unknown Student'),
        'grade' => (string) ($row['grade'] ?? '-'),
        'lrn' => (string) ($row['lrn'] ?? '-'),
        'booklet_label' => booklet_label_from_stored((int) ($row['booklet_no'] ?? 0)),
        'receipt_no' => (string) ($row['receipt_no'] ?? ''),
        'school_fee' => (string) ($row['school_fee'] ?? 'Uncategorized'),
        'mode' => $mode,
        'reference' => receipt_payment_methods_reference_display($methodBreakdown, export_daily_extract_reference((string) ($row['receipt_note'] ?? ''), (string) ($row['remarks'] ?? ''))),
        'processed_by' => (string) ($row['processed_by'] ?? 'System'),
        'amount' => $amount,
    ];
    $modeTotals[$mode]['amount'] += $amount;
    $modeTotals[$mode]['count']++;
    $sourceTotals['Active']['amount'] += $amount;
    $sourceTotals['Active']['count']++;
    $grandTotal += $amount;
}
$activeStmt->close();

$oldSql = "
SELECT
    p.id,
    COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) AS occurred_at,
    p.booklet_no,
    p.receipt_no,
    p.amount AS amount,
    p.note,
    p.fee_type AS school_fee,
    CONCAT(s.lastname, ', ', s.firstname, CASE WHEN TRIM(COALESCE(s.middlename, '')) <> '' THEN CONCAT(' ', s.middlename) ELSE '' END) AS payee_name,
    s.status
FROM old_student_payments p
INNER JOIN receipts_registry rr
    ON rr.receipt_no = p.receipt_no
    AND rr.booklet_no = p.booklet_no
    AND rr.voided = 0
    AND rr.used_by = 'old_student_payments'
LEFT JOIN old_students s ON s.id = p.old_student_id
WHERE COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) >= ?
  AND COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) <= ?
  AND p.booklet_no IS NOT NULL
  AND p.receipt_no IS NOT NULL
  AND COALESCE(NULLIF(TRIM(s.school_year), ''), ?) = ?
  AND (p.deleted_at IS NULL OR p.deleted_at = '')
ORDER BY COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) DESC, p.id DESC
";
$oldStmt = $conn->prepare($oldSql);
$oldStmt->bind_param('ssss', $rangeStartDateTime, $rangeEndDateTime, $selectedSchoolYear, $selectedSchoolYear);
$oldStmt->execute();
$oldResult = $oldStmt->get_result();
while ($row = $oldResult->fetch_assoc()) {
    $methodBreakdown = receipt_payment_methods_for_display(
        $conn,
        (int) ($row['booklet_no'] ?? 0),
        (int) ($row['receipt_no'] ?? 0),
        'old_student_payments'
    );
    $mode = receipt_payment_methods_display_label($methodBreakdown, export_daily_detect_payment_mode((string) ($row['note'] ?? '')));
    if ($modeFilter !== '' && $mode !== $modeFilter) {
        continue;
    }
    if ($sourceFilter !== '' && $sourceFilter !== 'Old') {
        continue;
    }

    $amount = (float) ($row['amount'] ?? 0);
    $transactions[] = [
        'source' => 'Old',
        'occurred_at' => (string) ($row['occurred_at'] ?? ''),
        'payee_name' => (string) ($row['payee_name'] ?? 'Unknown Student'),
        'grade' => (string) ($row['status'] ?? '-'),
        'lrn' => '-',
        'booklet_label' => booklet_label_from_stored((int) ($row['booklet_no'] ?? 0)),
        'receipt_no' => (string) ($row['receipt_no'] ?? ''),
        'school_fee' => (string) ($row['school_fee'] ?? 'Old Payment'),
        'mode' => $mode,
        'reference' => receipt_payment_methods_reference_display($methodBreakdown, export_daily_extract_reference((string) ($row['note'] ?? ''))),
        'processed_by' => 'Old Account',
        'amount' => $amount,
    ];
    $modeTotals[$mode]['amount'] += $amount;
    $modeTotals[$mode]['count']++;
    $sourceTotals['Old']['amount'] += $amount;
    $sourceTotals['Old']['count']++;
    $grandTotal += $amount;
}
$oldStmt->close();

usort($transactions, static function (array $left, array $right): int {
    return strcmp((string) ($right['occurred_at'] ?? ''), (string) ($left['occurred_at'] ?? ''));
});

$groupedTransactions = [];
foreach ($transactions as $transaction) {
    $groupKey = ($transaction['source'] ?? '') . '|' . ($transaction['booklet_label'] ?? '') . '|' . ($transaction['receipt_no'] ?? '');
    if (!isset($groupedTransactions[$groupKey])) {
        $groupedTransactions[$groupKey] = $transaction;
        $groupedTransactions[$groupKey]['items'] = [];
        $groupedTransactions[$groupKey]['items_count'] = 0;
        $groupedTransactions[$groupKey]['total_amount'] = 0.0;
    }
    $groupedTransactions[$groupKey]['items'][] = [
        'fee' => (string) ($transaction['school_fee'] ?? 'Uncategorized'),
        'amount' => (float) ($transaction['amount'] ?? 0),
    ];
    $groupedTransactions[$groupKey]['items_count']++;
    $groupedTransactions[$groupKey]['total_amount'] += (float) ($transaction['amount'] ?? 0);
}
$transactions = array_values($groupedTransactions);

$spreadsheet = new Spreadsheet();

$summarySheet = $spreadsheet->getActiveSheet();
$summarySheet->setTitle('Collection Summary');
$summarySheet->setCellValue('A1', 'Daily Collection Activity');
$summarySheet->setCellValue('A2', 'School Year: ' . ($selectedSchoolYear !== '' ? $selectedSchoolYear : 'All'));
$summarySheet->setCellValue('A3', 'Range: ' . $rangeLabel);
$summarySheet->setCellValue('A4', 'Source Filter: ' . ($sourceFilter !== '' ? $sourceFilter : 'All'));
$summarySheet->setCellValue('D2', 'Mode Filter');
$summarySheet->setCellValue('E2', $modeFilter !== '' ? $modeFilter : 'All');
$summarySheet->setCellValue('D3', 'Prepared By');
$summarySheet->setCellValue('E3', $preparedBy);
$summarySheet->setCellValue('D4', 'Generated On');
$summarySheet->setCellValue('E4', date('F j, Y g:i A'));
$summarySheet->setCellValue('A5', 'Metric');
$summarySheet->setCellValue('B5', 'Value');

$summaryRows = [
    ['Transactions', count($transactions)],
    ['Grand Total', $grandTotal],
    ['Active Collections', (float) ($sourceTotals['Active']['amount'] ?? 0)],
    ['Old Collections', (float) ($sourceTotals['Old']['amount'] ?? 0)],
    ['Cash Total', (float) ($modeTotals['Cash']['amount'] ?? 0)],
    ['GCash Total', (float) ($modeTotals['GCash']['amount'] ?? 0)],
    ['Bank Transfer Total', (float) ($modeTotals['Bank Transfer']['amount'] ?? 0)],
];
$row = 6;
foreach ($summaryRows as [$label, $value]) {
    $summarySheet->setCellValue("A{$row}", $label);
    $summarySheet->setCellValue("B{$row}", $value);
    $row++;
}
$summarySheet->getStyle("B6:B{$row}")->getNumberFormat()->setFormatCode('#,##0.00');
export_daily_base_style($summarySheet, 'E', max(6, $row - 1));

$transactionsSheet = $spreadsheet->createSheet();
$transactionsSheet->setTitle('Collection Activity');
$transactionsSheet->fromArray(
    ['Date', 'Time', 'Source', 'Payee', 'Grade/Status', 'LRN', 'Booklet No', 'Receipt No', 'Breakdown', 'Mode', 'Processed By', 'Reference', 'Total Amount'],
    null,
    'A1'
);
$row = 2;
foreach ($transactions as $transaction) {
    $occurredAt = (string) ($transaction['occurred_at'] ?? '');
    $datePart = $occurredAt !== '' ? date('n/j/Y', strtotime($occurredAt)) : '';
    $timePart = $occurredAt !== '' ? date('g:i A', strtotime($occurredAt)) : '';
    $breakdownText = export_daily_breakdown_text((array) ($transaction['items'] ?? []));

    $transactionsSheet->setCellValue("A{$row}", $datePart);
    $transactionsSheet->setCellValue("B{$row}", $timePart);
    $transactionsSheet->setCellValue("C{$row}", (string) ($transaction['source'] ?? ''));
    $transactionsSheet->setCellValue("D{$row}", (string) ($transaction['payee_name'] ?? ''));
    $transactionsSheet->setCellValue("E{$row}", (string) ($transaction['grade'] ?? ''));
    $transactionsSheet->setCellValueExplicit("F{$row}", (string) ($transaction['lrn'] ?? ''), DataType::TYPE_STRING);
    $transactionsSheet->setCellValue("G{$row}", (string) ($transaction['booklet_label'] ?? ''));
    $transactionsSheet->setCellValueExplicit("H{$row}", (string) ($transaction['receipt_no'] ?? ''), DataType::TYPE_STRING);
    $transactionsSheet->setCellValue("I{$row}", $breakdownText);
    $transactionsSheet->setCellValue("J{$row}", (string) ($transaction['mode'] ?? ''));
    $transactionsSheet->setCellValue("K{$row}", (string) ($transaction['processed_by'] ?? '-'));
    $transactionsSheet->setCellValue("L{$row}", (string) ($transaction['reference'] ?? '-'));
    $transactionsSheet->setCellValue("M{$row}", (float) ($transaction['total_amount'] ?? 0));
    $row++;
}
$transactionsSheet->getStyle("M2:M{$row}")->getNumberFormat()->setFormatCode('#,##0.00');
export_daily_base_style($transactionsSheet, 'M', max(2, $row - 1));
$transactionsSheet->getColumnDimension('A')->setWidth(14);
$transactionsSheet->getColumnDimension('B')->setWidth(12);
$transactionsSheet->getColumnDimension('C')->setWidth(12);
$transactionsSheet->getColumnDimension('D')->setWidth(30);
$transactionsSheet->getColumnDimension('E')->setWidth(16);
$transactionsSheet->getColumnDimension('F')->setWidth(18);
$transactionsSheet->getColumnDimension('G')->setWidth(14);
$transactionsSheet->getColumnDimension('H')->setWidth(14);
$transactionsSheet->getColumnDimension('I')->setWidth(38);
$transactionsSheet->getColumnDimension('J')->setWidth(14);
$transactionsSheet->getColumnDimension('K')->setWidth(18);
$transactionsSheet->getColumnDimension('L')->setWidth(16);
$transactionsSheet->getColumnDimension('M')->setWidth(16);
$transactionsSheet->getStyle("F2:F{$row}")->getNumberFormat()->setFormatCode('@');
$transactionsSheet->getStyle("H2:H{$row}")->getNumberFormat()->setFormatCode('@');

$filename = 'daily_collection_activity_' . preg_replace('/[^A-Za-z0-9_-]+/', '_', $rangeStart . '_to_' . $rangeEnd) . '_' . preg_replace('/[^A-Za-z0-9_-]+/', '_', $selectedSchoolYear !== '' ? $selectedSchoolYear : 'all') . '.xlsx';

while (ob_get_level() > 0) {
    ob_end_clean();
}
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="' . $filename . '"');
header('Cache-Control: max-age=0');
header('Pragma: public');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
