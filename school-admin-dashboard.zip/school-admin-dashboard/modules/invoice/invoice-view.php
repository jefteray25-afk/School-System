<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/../audit/audit-helper.php';

$currentRole = $_SESSION['role'] ?? '';
if (!hasPermission($currentRole, 'financial', 'view')) {
    audit_log(
        $conn,
        $_SESSION['username'] ?? 'unknown',
        'Blocked invoice view access',
        'Invoice',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing financial:view permission',
        'SECURITY'
    );
    header('Location: /school-admin-dashboard/dashboard.php?error=invoice_denied');
    exit();
}

$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$canAccessInvoiceTotal = can_access_invoice_total((string) $role);
$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
$school_year_options = school_year_finance_options($conn, 'payments');
$active_school_year_label = school_year_get_active_label($conn);
$selected_school_year = trim($_GET['school_year'] ?? '');
if ($selected_school_year === '') {
    $selected_school_year = $active_school_year_label;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invoice Options | School Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --page-bg: #eef4fb;
            --surface: #ffffff;
            --surface-soft: #f7fafc;
            --line: #dbe6f0;
            --ink: #223248;
            --muted: #6d7c8c;
            --blue: #2463a6;
            --cyan: #277f95;
            --green: #2f7d5a;
            --amber: #9a6a19;
            --slate: #5b6d82;
        }
        body {
            background: linear-gradient(180deg, #f8fbff 0%, var(--page-bg) 100%);
            color: var(--ink);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
            min-height: 100vh;
        }
        body.dark-mode {
            --page-bg: #18212b;
            --surface: #243140;
            --surface-soft: #1f2a37;
            --line: #33465a;
            --ink: #edf4fb;
            --muted: #b2bfcc;
            --blue: #8db8e8;
            --cyan: #83c5d7;
            --green: #88c9a8;
            --amber: #e7c071;
            --slate: #b6c2cf;
        }
        .header-section {
            margin: 28px auto 12px;
            text-align: center;
        }
        .header-section img {
            width: 70px;
            height: 70px;
            border-radius: 18px;
            object-fit: contain;
            margin-bottom: 8px;
            box-shadow: 0 12px 28px rgba(34,50,72,0.12);
        }
        .header-section h1 {
            color: var(--ink);
            font-size: 1.25rem;
            font-weight: 800;
            margin: 0;
        }
        .invoice-shell {
            max-width: 1120px;
            margin: 0 auto 38px;
            padding: 0 16px;
        }
        .invoice-hero {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 8px;
            box-shadow: 0 16px 34px rgba(34,50,72,0.07);
            padding: 22px;
            margin-bottom: 16px;
        }
        .hero-grid {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 300px;
            gap: 18px;
            align-items: end;
        }
        .eyebrow {
            color: var(--muted);
            font-size: 0.76rem;
            font-weight: 800;
            letter-spacing: 0.08em;
            text-transform: uppercase;
        }
        .hero-title {
            color: var(--ink);
            font-size: clamp(1.55rem, 2.5vw, 2.25rem);
            font-weight: 850;
            letter-spacing: 0;
            margin: 5px 0 6px;
        }
        .hero-copy {
            color: var(--muted);
            line-height: 1.55;
            margin: 0;
            max-width: 740px;
        }
        .year-panel {
            background: var(--surface-soft);
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 14px;
        }
        .year-panel .form-label {
            color: var(--ink);
            font-size: 0.82rem;
            font-weight: 800;
            margin-bottom: 6px;
        }
        .year-panel .form-select {
            background-color: var(--surface);
            border-color: var(--line);
            border-radius: 8px;
            color: var(--ink);
            min-height: 44px;
        }
        .year-panel .form-text {
            color: var(--muted);
            font-size: 0.78rem;
        }
        .status-strip {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 10px;
            margin-top: 16px;
        }
        .status-tile {
            background: var(--surface-soft);
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 13px 14px;
        }
        .status-label {
            color: var(--muted);
            font-size: 0.76rem;
            font-weight: 800;
            letter-spacing: 0.04em;
            text-transform: uppercase;
        }
        .status-value {
            color: var(--ink);
            font-size: 0.96rem;
            font-weight: 800;
            margin-top: 4px;
        }
        .workspace-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 14px;
        }
        .workspace-card {
            --accent: var(--blue);
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 8px;
            box-shadow: 0 12px 28px rgba(34,50,72,0.06);
            display: flex;
            flex-direction: column;
            min-height: 236px;
            overflow: hidden;
        }
        .workspace-card.featured {
            grid-column: span 2;
            min-height: 214px;
        }
        .workspace-card.old {
            --accent: var(--slate);
        }
        .workspace-card.total {
            --accent: var(--cyan);
        }
        .workspace-card.daily {
            --accent: var(--amber);
        }
        .workspace-card.ledger {
            --accent: var(--green);
        }
        .workspace-card-header {
            align-items: flex-start;
            border-bottom: 1px solid var(--line);
            display: flex;
            gap: 13px;
            padding: 18px 18px 14px;
        }
        .workspace-icon {
            align-items: center;
            background: color-mix(in srgb, var(--accent) 12%, var(--surface));
            border: 1px solid color-mix(in srgb, var(--accent) 24%, var(--line));
            border-radius: 8px;
            color: var(--accent);
            display: inline-flex;
            flex: 0 0 auto;
            font-size: 1.05rem;
            height: 44px;
            justify-content: center;
            width: 44px;
        }
        .workspace-title {
            color: var(--ink);
            font-size: 1.05rem;
            font-weight: 850;
            margin: 0;
        }
        .workspace-subtitle {
            color: var(--muted);
            font-size: 0.88rem;
            line-height: 1.45;
            margin: 4px 0 0;
        }
        .workspace-body {
            display: flex;
            flex: 1;
            flex-direction: column;
            gap: 14px;
            padding: 16px 18px 18px;
        }
        .workspace-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }
        .workspace-tag {
            background: var(--surface-soft);
            border: 1px solid var(--line);
            border-radius: 999px;
            color: var(--muted);
            font-size: 0.78rem;
            font-weight: 750;
            padding: 5px 9px;
        }
        .workspace-action {
            align-items: center;
            align-self: flex-start;
            background: var(--accent);
            border: 1px solid var(--accent);
            border-radius: 8px;
            color: #fff;
            display: inline-flex;
            font-weight: 800;
            gap: 8px;
            justify-content: center;
            margin-top: auto;
            min-height: 42px;
            padding: 0.64rem 0.9rem;
            text-decoration: none;
            transition: transform 0.16s ease, box-shadow 0.16s ease, filter 0.16s ease;
        }
        .workspace-action:hover {
            box-shadow: 0 12px 22px rgba(34,50,72,0.12);
            color: #fff;
            filter: brightness(0.98);
            transform: translateY(-1px);
        }
        .dashboard-btn-bottom {
            align-items: center;
            background: #e7f0fd;
            border: 2px solid #bcdfff;
            border-radius: 50%;
            bottom: 28px;
            box-shadow: 0 5px 16px rgba(33,57,93,0.13);
            color: #517fa4;
            cursor: pointer;
            display: flex;
            font-size: 1.55em;
            height: 58px;
            justify-content: center;
            left: 28px;
            position: fixed;
            text-decoration: none;
            transition: background 0.2s, color 0.2s;
            width: 58px;
            z-index: 1060;
        }
        @supports not (background: color-mix(in srgb, #000 10%, #fff)) {
            .workspace-icon {
                background: var(--surface-soft);
                border-color: var(--line);
            }
        }
        @media (max-width: 900px) {
            .hero-grid,
            .workspace-grid,
            .workspace-card.featured {
                grid-template-columns: 1fr;
                grid-column: auto;
            }
            .status-strip {
                grid-template-columns: 1fr;
            }
        }
        @media (max-width: 576px) {
            .invoice-hero,
            .workspace-card-header,
            .workspace-body {
                padding-left: 14px;
                padding-right: 14px;
            }
            .workspace-card {
                min-height: auto;
            }
            .workspace-action {
                width: 100%;
            }
            .dashboard-btn-bottom {
                bottom: 18px;
                height: 52px;
                left: 18px;
                width: 52px;
            }
        }
    </style>
</head>
<body>
<?php render_admin_nav('invoice', true); ?>
<?php render_school_page_header($schoolName, '/school-admin-dashboard/uploads/logo1.png', '', 'header-section'); ?>
<div class="invoice-shell">
    <section class="invoice-hero">
        <div class="hero-grid">
            <div>
                <div class="eyebrow">Invoice Center</div>
                <h2 class="hero-title">Invoice Control Center</h2>
                <p class="hero-copy">Open collection reports, receipt lookup, and invoice summaries from one clean workspace. This page only routes you to existing invoice tools.</p>
            </div>
            <form method="get" class="year-panel">
                <label class="form-label" for="schoolYearSelector">School Year</label>
                <select id="schoolYearSelector" name="school_year" class="form-select" onchange="this.form.submit()">
                    <?php foreach ($school_year_options as $option): ?>
                        <option value="<?= htmlspecialchars($option) ?>" <?= $selected_school_year === $option ? 'selected' : '' ?>>
                        <?= htmlspecialchars($option) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <div class="form-text">Reports that support school-year filtering will use this selection.</div>
            </form>
        </div>
        <div class="status-strip">
            <div class="status-tile">
                <div class="status-label">Mode</div>
                <div class="status-value">Reporting Only</div>
            </div>
            <div class="status-tile">
                <div class="status-label">Selected Year</div>
                <div class="status-value"><?= htmlspecialchars($selected_school_year) ?></div>
            </div>
            <div class="status-tile">
                <div class="status-label">Access</div>
                <div class="status-value"><?= $canAccessInvoiceTotal ? 'Full Invoice Reports' : 'Standard Invoice Reports' ?></div>
            </div>
        </div>
    </section>

    <section class="workspace-grid" aria-label="Invoice workspaces">
        <article class="workspace-card featured">
            <div class="workspace-card-header">
                <span class="workspace-icon"><i class="fas fa-cash-register"></i></span>
                <div>
                    <h3 class="workspace-title">Daily Collection Report</h3>
                    <p class="workspace-subtitle">Best for end-of-day checking, payment activity review, and collection print/export.</p>
                </div>
            </div>
            <div class="workspace-body">
                <div class="workspace-tags">
                    <span class="workspace-tag">Active + Old</span>
                    <span class="workspace-tag">Date Range</span>
                    <span class="workspace-tag">Mode Breakdown</span>
                    <span class="workspace-tag">Print / Export</span>
                </div>
                <a href="/school-admin-dashboard/modules/invoice/daily-collection-report.php?school_year=<?= urlencode($selected_school_year) ?>" class="workspace-action">
                    <i class="fas fa-arrow-right"></i> Open Daily Collection
                </a>
            </div>
        </article>

        <article class="workspace-card">
            <div class="workspace-card-header">
                <span class="workspace-icon"><i class="fas fa-file-invoice"></i></span>
                <div>
                    <h3 class="workspace-title">Invoice Active</h3>
                    <p class="workspace-subtitle">Current student official receipts and active account invoice records.</p>
                </div>
            </div>
            <div class="workspace-body">
                <div class="workspace-tags">
                    <span class="workspace-tag">Current Students</span>
                    <span class="workspace-tag">School Year</span>
                    <span class="workspace-tag">Excel Export</span>
                </div>
                <a href="/school-admin-dashboard/modules/invoice/invoice-compilation.php?school_year=<?= urlencode($selected_school_year) ?>" class="workspace-action">
                    <i class="fas fa-arrow-right"></i> Open Active
                </a>
            </div>
        </article>

        <article class="workspace-card old">
            <div class="workspace-card-header">
                <span class="workspace-icon"><i class="fas fa-file-invoice-dollar"></i></span>
                <div>
                    <h3 class="workspace-title">Invoice Old</h3>
                    <p class="workspace-subtitle">Legacy account receipt review separated from current student finance records.</p>
                </div>
            </div>
            <div class="workspace-body">
                <div class="workspace-tags">
                    <span class="workspace-tag">Old Accounts</span>
                    <span class="workspace-tag">Historical</span>
                    <span class="workspace-tag">Excel Export</span>
                </div>
                <a href="/school-admin-dashboard/modules/invoice/invoice-old.php" class="workspace-action">
                    <i class="fas fa-arrow-right"></i> Open Old
                </a>
            </div>
        </article>

        <?php if ($canAccessInvoiceTotal): ?>
        <article class="workspace-card total">
            <div class="workspace-card-header">
                <span class="workspace-icon"><i class="fas fa-chart-column"></i></span>
                <div>
                    <h3 class="workspace-title">Invoice Total</h3>
                    <p class="workspace-subtitle">Combined total report for active and old official receipt records.</p>
                </div>
            </div>
            <div class="workspace-body">
                <div class="workspace-tags">
                    <span class="workspace-tag">Grand Total</span>
                    <span class="workspace-tag">Active / Old</span>
                    <span class="workspace-tag">Restricted</span>
                </div>
                <a href="/school-admin-dashboard/modules/invoice/invoice-total.php?school_year=<?= urlencode($selected_school_year) ?>" class="workspace-action">
                    <i class="fas fa-arrow-right"></i> Open Total
                </a>
            </div>
        </article>
        <?php endif; ?>

        <article class="workspace-card ledger">
            <div class="workspace-card-header">
                <span class="workspace-icon"><i class="fas fa-book-open"></i></span>
                <div>
                    <h3 class="workspace-title">Receipt Ledger</h3>
                    <p class="workspace-subtitle">Read-only receipt finder for booklet ranges, used receipts, and voided history.</p>
                </div>
            </div>
            <div class="workspace-body">
                <div class="workspace-tags">
                    <span class="workspace-tag">Booklet Map</span>
                    <span class="workspace-tag">Used / Available</span>
                    <span class="workspace-tag">Read Only</span>
                </div>
                <a href="/school-admin-dashboard/modules/invoice/invoice-receipts.php" class="workspace-action">
                    <i class="fas fa-arrow-right"></i> Open Ledger
                </a>
            </div>
        </article>
    </section>
</div>
<footer class="text-center py-4 text-muted small">
    &copy; <?= date("Y") ?> <?= $schoolName ?> | School Admin Dashboard
</footer>
<a href="/school-admin-dashboard/dashboard.php" class="dashboard-btn-bottom" title="Go to Dashboard">
    <i class="fas fa-tachometer-alt"></i>
</a>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const themeToggleBtn = document.getElementById('themeToggleBtn');
    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');
            const icon = this.querySelector('i');
            if (icon) {
                icon.classList.toggle('fa-moon');
                icon.classList.toggle('fa-sun');
            }
        });
    }
</script>
</body>
</html>
