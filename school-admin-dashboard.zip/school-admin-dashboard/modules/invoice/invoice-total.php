<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/settings-security.php';
require_once __DIR__ . '/../settings/school-info-helper.php';
require_once __DIR__ . '/invoice-total-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/includes-receipt-helper.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/../audit/audit-helper.php';
invoice_total_ensure_old_payment_datetime_column($conn);
ensure_receipts_registry_schema($conn);

$currentRole = $_SESSION['role'] ?? '';
if (!can_access_invoice_total((string) $currentRole)) {
    audit_log(
        $conn,
        $_SESSION['username'] ?? 'unknown',
        'Blocked invoice total access',
        'Invoice',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing invoice total permission',
        'SECURITY'
    );
    header('Location: /school-admin-dashboard/dashboard.php?error=invoice_denied');
    exit();
}

$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$csrfToken = ensure_csrf_token();
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$school_year_options = school_year_finance_options($conn, 'payments');
$active_school_year_label = school_year_get_active_label($conn);
$selected_school_year = trim($_GET['school_year'] ?? '');
if ($selected_school_year === '') {
    $selected_school_year = $active_school_year_label;
}
$searchFilter = trim((string) ($_GET['search'] ?? ''));
$sourceFilter = trim((string) ($_GET['source'] ?? ''));
$bookletFilter = trim((string) ($_GET['booklet'] ?? ''));
$categoryFilter = trim((string) ($_GET['category'] ?? ''));

function invoice_total_normalize_date(string $value): string
{
    $value = trim($value);
    if (!preg_match('/^\\d{4}-\\d{2}-\\d{2}$/', $value)) {
        return '';
    }
    $timestamp = strtotime($value);
    if ($timestamp === false) {
        return '';
    }
    return date('Y-m-d', $timestamp);
}

$today = date('Y-m-d');
$defaultStart = date('Y-m-d', strtotime('-7 days'));
$hasStartDateParam = array_key_exists('start_date', $_GET);
$hasEndDateParam = array_key_exists('end_date', $_GET);
$rangeStart = $hasStartDateParam ? invoice_total_normalize_date((string) ($_GET['start_date'] ?? '')) : $defaultStart;
$rangeEnd = $hasEndDateParam ? invoice_total_normalize_date((string) ($_GET['end_date'] ?? '')) : $today;

if ($rangeStart !== '' && $rangeEnd !== '' && $rangeStart > $rangeEnd) {
    [$rangeStart, $rangeEnd] = [$rangeEnd, $rangeStart];
}

// Prevent accidentally loading extreme ranges. Adjust as needed.
$maxDays = 365;
$startTs = strtotime($rangeStart);
$endTs = strtotime($rangeEnd);
$rangeNotice = '';
if ($rangeStart !== '' && $rangeEnd !== '' && $startTs !== false && $endTs !== false) {
    $days = (int) floor(($endTs - $startTs) / 86400) + 1;
    if ($days > $maxDays) {
        $rangeStart = date('Y-m-d', strtotime('-' . ($maxDays - 1) . ' days', $endTs));
        $rangeNotice = "Date range was limited to the most recent {$maxDays} days for performance.";
    }
}

function formatCurrency(float $amount): string
{
    return 'PHP ' . number_format($amount, 2);
}
$invoiceTotalData = invoice_total_load_receipts($conn, $selected_school_year, $rangeStart, $rangeEnd);
$receipts = $invoiceTotalData['receipts'] ?? [];
$bookletValues = $invoiceTotalData['booklet_values'] ?? [];
$categoryValues = $invoiceTotalData['category_values'] ?? [];
$totalReceipts = (int) ($invoiceTotalData['total_receipts'] ?? 0);
$grandTotal = (float) ($invoiceTotalData['grand_total'] ?? 0.0);
$activeTotal = (float) ($invoiceTotalData['active_total'] ?? 0.0);
$oldTotal = (float) ($invoiceTotalData['old_total'] ?? 0.0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invoice Total | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --page-bg: #eef4fb;
            --surface: #ffffff;
            --surface-soft: #f7fafc;
            --line: #dbe6f0;
            --ink: #223248;
            --muted: #6d7c8c;
            --blue: #2463a6;
            --green: #2f7d5a;
            --amber: #9a6a19;
            --cyan: #277f95;
            --navbar-bg: #23395d;
        }
        body {
            background: linear-gradient(180deg, #f8fbff 0%, var(--page-bg) 100%);
            color: var(--ink);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        }
        body.dark-mode {
            --page-bg: #1b232d;
            --surface: #233140;
            --surface-soft: #1f2a37;
            --line: #33465a;
            --ink: #e6edf3;
            --muted: #b2bfcc;
            --navbar-bg: #161b22;
        }
        .navbar {
            background: var(--navbar-bg) !important;
            box-shadow: 0 2px 12px rgba(33, 57, 93, 0.08);
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.08em;
        }
        .navbar-brand {
            font-weight: 700;
            letter-spacing: 1px;
        }
        .theme-toggle-btn {
            background: none;
            border: none;
            color: #fff;
            cursor: pointer;
            font-size: 1.45em;
            margin-left: 12px;
        }
        .dashboard-header {
            margin: 28px auto 12px;
            text-align: center;
        }
        .dashboard-header img {
            height: 68px;
            margin-bottom: 6px;
            object-fit: contain;
            width: 68px;
        }
        .dashboard-header h1 {
            color: var(--ink);
            font-size: 1.25rem;
            font-weight: 800;
            letter-spacing: 0;
            margin-bottom: 0;
        }
        .invoice-total-shell {
            margin: 0 auto;
            max-width: 1880px;
            padding: 0 14px;
        }
        .report-header {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 8px;
            box-shadow: 0 14px 30px rgba(34,50,72,.07);
            margin-bottom: 14px;
            padding: 22px;
            text-align: left;
        }
        .report-kicker {
            color: var(--muted);
            font-size: .76rem;
            font-weight: 850;
            letter-spacing: .08em;
            text-transform: uppercase;
        }
        .report-header h2 {
            color: var(--ink);
            font-size: clamp(1.35rem, 2vw, 1.9rem);
            font-weight: 900;
            letter-spacing: 0;
            margin: 4px 0 3px;
        }
        .report-header .lead {
            color: var(--muted);
            font-size: 1rem;
            margin: 0;
        }
        .context-badge {
            background: var(--surface-soft);
            border: 1px solid var(--line);
            border-radius: 999px;
            color: var(--muted);
            display: inline-flex;
            font-size: .82rem;
            font-weight: 800;
            gap: 7px;
            margin-top: 10px;
            padding: .36rem .72rem;
        }
        .action-bar {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 8px;
            box-shadow: 0 10px 24px rgba(34,50,72,.055);
            display: flex;
            flex-wrap: wrap;
            gap: 0.65rem;
            margin-bottom: 14px;
            padding: 14px;
        }
        .filter-actions {
            align-items: center;
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
        }
        .action-bar .form-control,
        .action-bar .form-select {
            border-color: var(--line);
            border-radius: 8px;
            display: inline-block;
            min-height: 42px;
            width: 190px;
        }
        .action-bar .btn,
        .filter-actions .btn {
            border-radius: 8px;
            font-weight: 800;
            min-height: 42px;
        }
        .print-meta {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 8px;
            color: var(--muted);
            font-size: 0.9rem;
            margin-bottom: 14px;
            padding: 12px 14px;
        }
        .print-meta strong {
            color: var(--ink);
        }
        .print-meta-grid {
            display: grid;
            gap: 0.85rem;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        }
        .print-meta-item {
            display: flex;
            flex-direction: column;
            gap: 0.2rem;
        }
        .print-meta-item span {
            color: var(--muted);
            font-size: 0.74rem;
            font-weight: 850;
            letter-spacing: 0.05em;
            text-transform: uppercase;
        }
        .summary-card {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 8px;
            box-shadow: 0 10px 24px rgba(34,50,72,.055);
            height: 100%;
            overflow: hidden;
            padding: 1rem 1.15rem;
            position: relative;
        }
        .summary-card::before {
            background: var(--blue);
            content: "";
            height: 3px;
            left: 0;
            position: absolute;
            right: 0;
            top: 0;
        }
        .summary-card.success::before { background: var(--green); }
        .summary-card.warning::before { background: var(--amber); }
        .summary-label {
            color: var(--muted);
            font-size: 0.76rem;
            font-weight: 850;
            letter-spacing: 0.05em;
            margin-bottom: 0.2rem;
            text-transform: uppercase;
        }
        .summary-value {
            color: var(--ink);
            font-size: clamp(1.16rem, 1.5vw, 1.46rem);
            font-weight: 900;
            letter-spacing: 0;
        }
        .card.report-table {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 8px;
            box-shadow: 0 14px 30px rgba(34,50,72,.07);
            overflow: hidden;
        }
        .card.report-table .card-header {
            background: var(--surface) !important;
            border-bottom: 1px solid var(--line);
            color: var(--ink) !important;
            font-size: 1rem;
            font-weight: 900;
            padding: 15px 16px;
        }
        .card.report-table .card-body {
            padding: 0;
        }
        th, td {
            vertical-align: middle;
        }
        th {
            background: #f3f7fb;
            color: #526477;
            font-size: .74rem;
            font-weight: 900;
            letter-spacing: .04em;
            text-align: center;
            text-transform: uppercase;
            white-space: nowrap;
        }
        .table-responsive {
            font-size: 0.95rem;
        }
        .table {
            margin-bottom: 0;
            min-width: 1320px;
        }
        .table td,
        .table th {
            border-color: #e7eef6;
        }
        .table tbody tr:hover td {
            background: #fbfdff;
        }
        .badge-source {
            border-radius: 999px;
            min-width: 72px;
            padding: .38rem .55rem;
        }
        .badge-source.active {
            background: #2463a6;
        }
        .badge-source.old {
            background: #6d7c8c;
        }
        .breakdown-list {
            min-width: 230px;
        }
        .breakdown-item {
            border-bottom: 1px dashed rgba(81, 127, 164, 0.18);
            display: flex;
            gap: 12px;
            justify-content: space-between;
            padding: 0.16rem 0;
        }
        .breakdown-item:last-child {
            border-bottom: none;
        }
        .breakdown-item strong {
            font-weight: 850;
        }
        .note-block {
            color: var(--muted);
            font-size: 0.88rem;
        }
        .empty-state {
            color: var(--muted);
            padding: 2rem 1rem;
            text-align: center;
        }
        .pagination-container {
            align-items: center;
            border-top: 1px solid var(--line);
            display: flex;
            gap: 4px;
            justify-content: center;
            padding: 14px;
        }
        .pagination .page-link {
            min-width: 36px;
            text-align: center;
        }
        .dashboard-btn-bottom {
            align-items: center;
            background: #e7f0fd;
            border: 2px solid #bcdfff;
            border-radius: 50%;
            bottom: 28px;
            box-shadow: 0 5px 16px rgba(33, 57, 93, 0.13);
            color: #517fa4;
            cursor: pointer;
            display: flex;
            font-size: 1.55em;
            height: 58px;
            justify-content: center;
            left: 28px;
            position: fixed;
            text-decoration: none;
            transition: background 0.2s, color 0.2s;
            width: 58px;
            z-index: 1060;
        }
        .dashboard-btn-bottom:hover,
        .dashboard-btn-bottom:focus {
            background: #fff2b3;
            border-color: #ffe599;
            color: #517fa4;
        }
        .print-footer {
            border-top: 1px dashed rgba(81, 127, 164, 0.28);
            color: var(--muted);
            display: flex;
            flex-wrap: wrap;
            font-size: 0.9rem;
            gap: 1rem;
            justify-content: space-between;
            margin-top: 1.25rem;
            padding-top: 0.9rem;
        }
        @media print {
            .action-bar,
            .pagination-container,
            .dashboard-btn-bottom,
            .navbar,
            .footer {
                display: none !important;
            }
            .card {
                box-shadow: none !important;
            }
            .dashboard-header {
                margin-top: 0 !important;
                margin-bottom: 10px !important;
            }
            .print-meta {
                background: #fff !important;
                border-color: #d7e5f4 !important;
            }
        }
    </style>
</head>
<body>
<?php render_admin_nav('invoice'); ?>

<?php render_school_page_header($schoolName, $schoolLogo, '', 'dashboard-header', ''); ?>

<div class="invoice-total-shell py-4">
    <div class="report-header">
        <div class="report-kicker">Invoice Center</div>
        <h2><i class="fas fa-receipt"></i> Invoice Total</h2>
        <div class="lead text-muted">Combined official receipt history for active and old invoice records.</div>
        <div><span class="context-badge"><i class="fas fa-calendar-alt"></i> Active records filtered to <?= htmlspecialchars($selected_school_year) ?></span></div>
    </div>

    <div class="print-meta">
        <div class="print-meta-grid">
            <div class="print-meta-item">
                <span>Report Scope</span>
                <strong>Invoice Total Summary</strong>
            </div>
            <div class="print-meta-item">
                <span>School Year</span>
                <strong><?= htmlspecialchars($selected_school_year) ?></strong>
            </div>
            <div class="print-meta-item">
                <span>Prepared By</span>
                <strong><?= htmlspecialchars($username !== '' ? $username : 'System User') ?></strong>
            </div>
            <div class="print-meta-item">
                <span>Generated On</span>
                <strong><?= htmlspecialchars(date('F j, Y g:i A')) ?></strong>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-3 col-sm-6">
            <div class="summary-card primary">
                <div class="summary-label">Total Receipts</div>
                <div class="summary-value" id="summaryReceiptCount"><?= number_format($totalReceipts) ?></div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="summary-card primary">
                <div class="summary-label">Grand Total</div>
                <div class="summary-value" id="summaryGrandTotal"><?= htmlspecialchars(formatCurrency($grandTotal)) ?></div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="summary-card success">
                <div class="summary-label">Active Total</div>
                <div class="summary-value" id="summaryActiveTotal"><?= htmlspecialchars(formatCurrency($activeTotal)) ?></div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="summary-card warning">
                <div class="summary-label">Old Total</div>
                <div class="summary-value" id="summaryOldTotal"><?= htmlspecialchars(formatCurrency($oldTotal)) ?></div>
            </div>
        </div>
    </div>

    <?php if ($rangeNotice !== ''): ?>
        <div class="alert alert-warning py-2 mb-3">
            <i class="fas fa-triangle-exclamation me-1"></i>
            <?= htmlspecialchars($rangeNotice) ?>
        </div>
    <?php endif; ?>

    <div class="action-bar">
        <select class="form-select" id="schoolYearSelector">
            <?php foreach ($school_year_options as $option): ?>
                <option value="<?= htmlspecialchars($option) ?>" <?= $selected_school_year === $option ? 'selected' : '' ?>>
                    <?= htmlspecialchars($option) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <input type="text" class="form-control" id="searchInput" placeholder="Quick Search" value="<?= htmlspecialchars($searchFilter) ?>">
        <select class="form-select" id="filterSource">
            <option value="">All Records</option>
            <option value="Active" <?= $sourceFilter === 'Active' ? 'selected' : '' ?>>Active</option>
            <option value="Old" <?= $sourceFilter === 'Old' ? 'selected' : '' ?>>Old</option>
        </select>
        <select class="form-select" id="filterBooklet">
            <option value="">All Booklet Nos</option>
            <?php foreach ($bookletValues as $booklet): ?>
                <option value="<?= htmlspecialchars($booklet) ?>" <?= $bookletFilter === $booklet ? 'selected' : '' ?>><?= htmlspecialchars($booklet) ?></option>
            <?php endforeach; ?>
        </select>
        <select class="form-select" id="filterCategory">
            <option value="">All Categories</option>
            <?php foreach ($categoryValues as $category): ?>
                <option value="<?= htmlspecialchars($category) ?>" <?= $categoryFilter === $category ? 'selected' : '' ?>><?= htmlspecialchars($category) ?></option>
            <?php endforeach; ?>
        </select>
        <input type="date" class="form-control" id="filterDateStart" placeholder="Start Date" value="<?= htmlspecialchars($rangeStart) ?>">
        <span>-</span>
        <input type="date" class="form-control" id="filterDateEnd" placeholder="End Date" value="<?= htmlspecialchars($rangeEnd) ?>">
        <div class="filter-actions">
            <button class="btn btn-outline-primary" id="applyDateBtn" type="button">
                <i class="fas fa-check"></i> Apply Filters
            </button>
            <button class="btn btn-outline-secondary" id="clearFiltersBtn" type="button">
                <i class="fas fa-rotate-left"></i> Clear Filters
            </button>
        </div>
        <button class="btn btn-success" id="exportExcelBtn" type="button">
            <i class="fas fa-file-excel"></i> Export to Excel
        </button>
        <a href="/school-admin-dashboard/modules/invoice/invoice-view.php" class="btn btn-primary">
            <i class="fas fa-arrow-left"></i>
        </a>
    </div>
    <div class="print-meta" id="printMeta">
        <strong>Print/Export Context:</strong>
        <span id="printMetaText">School Year: <?= htmlspecialchars($selected_school_year) ?> | Source: <?= htmlspecialchars($sourceFilter !== '' ? $sourceFilter : 'All Records') ?> | Booklet: <?= htmlspecialchars($bookletFilter !== '' ? $bookletFilter : 'All') ?> | Category: <?= htmlspecialchars($categoryFilter !== '' ? $categoryFilter : 'All') ?> | Date Range: <?= htmlspecialchars(($rangeStart !== '' || $rangeEnd !== '') ? (($rangeStart !== '' ? $rangeStart : '...') . ' to ' . ($rangeEnd !== '' ? $rangeEnd : '...')) : 'All Dates') ?> | Search: <?= htmlspecialchars($searchFilter !== '' ? $searchFilter : 'All') ?></span>
    </div>

    <div class="card report-table">
        <div class="card-header">
            <i class="fas fa-table"></i> Combined Receipts Table
        </div>
        <div class="card-body table-responsive">
            <table class="table table-bordered table-hover align-middle" id="invoiceTotalTable">
                <thead>
                    <tr>
                        <th>Record</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Name</th>
                        <th>Grade</th>
                        <th>LRN</th>
                        <th>Booklet No</th>
                        <th>Receipt No</th>
                        <th>Breakdown</th>
                        <th>Notes</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody id="invoiceTotalTableBody">
                <?php if ($receipts): ?>
                    <?php foreach ($receipts as $receipt): ?>
                        <?php
                        $categoryNames = array_keys($receipt['categories']);
                        sort($categoryNames, SORT_NATURAL | SORT_FLAG_CASE);
                        $categorySearch = implode('|', $categoryNames);
                        $dateComparable = $receipt['sort_datetime'] ? date('Y-m-d', strtotime($receipt['sort_datetime'])) : '';
                        ?>
                        <tr
                            data-source="<?= htmlspecialchars($receipt['source']) ?>"
                            data-booklet="<?= htmlspecialchars($receipt['booklet_label']) ?>"
                            data-date="<?= htmlspecialchars($dateComparable) ?>"
                            data-category="<?= htmlspecialchars($categorySearch) ?>"
                            data-total="<?= htmlspecialchars(number_format($receipt['total_amount'], 2, '.', '')) ?>"
                        >
                            <td class="text-center">
                                <span class="badge badge-source <?= strtolower($receipt['source']) === 'active' ? 'active' : 'old' ?>">
                                    <?= htmlspecialchars($receipt['source']) ?>
                                </span>
                            </td>
                            <td><?= htmlspecialchars($receipt['date_display']) ?></td>
                            <td><?= htmlspecialchars($receipt['time_display']) ?></td>
                            <td><?= htmlspecialchars($receipt['student_name']) ?></td>
                            <td class="text-center"><?= htmlspecialchars($receipt['grade']) ?></td>
                            <td class="text-center"><?= htmlspecialchars($receipt['lrn']) ?></td>
                            <td class="text-center"><?= htmlspecialchars($receipt['booklet_label']) ?></td>
                            <td class="text-center"><?= htmlspecialchars($receipt['receipt_no']) ?></td>
                            <td class="breakdown-list">
                                <?php foreach ($categoryNames as $categoryName): ?>
                                    <div class="breakdown-item">
                                        <span><?= htmlspecialchars($categoryName) ?></span>
                                        <strong><?= htmlspecialchars(formatCurrency((float) $receipt['categories'][$categoryName])) ?></strong>
                                    </div>
                                <?php endforeach; ?>
                            </td>
                            <td class="note-block">
                                <?php if ($receipt['notes']): ?>
                                    <?= nl2br(htmlspecialchars(implode("\n", $receipt['notes']))) ?>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end fw-semibold"><?= htmlspecialchars(formatCurrency((float) $receipt['total_amount'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="11" class="empty-state">No invoice records found.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>

            <div class="pagination-container">
                <nav>
                    <ul class="pagination mb-0" id="paginationList"></ul>
                </nav>
            </div>
        </div>
    </div>

    <footer class="footer text-center py-4 text-muted small">
        &copy; <?= date('Y') ?> <?= htmlspecialchars($schoolName) ?> | School Admin Dashboard
    </footer>

    <div class="print-footer">
        <div>Prepared by: <strong><?= htmlspecialchars($username !== '' ? $username : 'System User') ?></strong><?= $role !== '' ? ' (' . htmlspecialchars($role) . ')' : '' ?></div>
        <div class="text-end">Generated invoice totals are based on non-voided official receipt records only.</div>
    </div>

    <a href="/school-admin-dashboard/dashboard.php" class="dashboard-btn-bottom" title="Go to Dashboard">
        <i class="fas fa-tachometer-alt"></i>
    </a>
</div>

<script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
const initialRows = Array.from(document.querySelectorAll('#invoiceTotalTableBody tr')).filter((row) => row.querySelectorAll('td').length > 1);
const rowsData = initialRows.map((tr) => {
    const cells = tr.querySelectorAll('td');
    const breakdownLines = Array.from(cells[8]?.querySelectorAll('.breakdown-item') || [])
        .map((item) => item.innerText.replace(/\s+/g, ' ').trim())
        .filter(Boolean);
    return {
        tr,
        searchText: tr.textContent.toLowerCase(),
        source: tr.dataset.source || '',
        booklet: tr.dataset.booklet || '',
        date: tr.dataset.date || '',
        categories: (tr.dataset.category || '').toLowerCase().split('|').filter(Boolean),
        total: parseFloat(tr.dataset.total || '0'),
        exportRow: [
            cells[0]?.innerText.trim() || '',
            cells[1]?.innerText.trim() || '',
            cells[2]?.innerText.trim() || '',
            cells[3]?.innerText.trim() || '',
            cells[4]?.innerText.trim() || '',
            cells[5]?.innerText.trim() || '',
            cells[6]?.innerText.trim() || '',
            cells[7]?.innerText.trim() || '',
            breakdownLines.join('\n'),
            cells[9]?.innerText.trim() || '',
            cells[10]?.innerText.trim() || ''
        ]
    };
});

const perPage = 50;
const SERVER_RANGE_START = <?= json_encode($rangeStart) ?>;
const SERVER_RANGE_END = <?= json_encode($rangeEnd) ?>;
let appliedFilters = {
    search: <?= json_encode($searchFilter) ?>,
    source: <?= json_encode($sourceFilter) ?>,
    booklet: <?= json_encode($bookletFilter) ?>,
    category: <?= json_encode($categoryFilter) ?>,
    dateStart: <?= json_encode($rangeStart) ?>,
    dateEnd: <?= json_encode($rangeEnd) ?>
};

function getCurrentInputFilters() {
    return {
        search: document.getElementById('searchInput').value.trim(),
        source: document.getElementById('filterSource').value,
        booklet: document.getElementById('filterBooklet').value,
        category: document.getElementById('filterCategory').value.trim(),
        dateStart: document.getElementById('filterDateStart').value || '',
        dateEnd: document.getElementById('filterDateEnd').value || ''
    };
}

function formatCurrency(amount) {
    return 'PHP ' + amount.toLocaleString(undefined, {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function sanitizeFilenamePart(value) {
    return String(value || '')
        .trim()
        .replace(/[^a-z0-9]+/gi, '_')
        .replace(/^_+|_+$/g, '')
        || 'all';
}

function updatePrintMeta() {
    const schoolYear = document.getElementById('schoolYearSelector').value || 'All';
    const source = appliedFilters.source || 'All Records';
    const booklet = appliedFilters.booklet || 'All';
    const category = appliedFilters.category || 'All';
    const dateStart = appliedFilters.dateStart || '';
    const dateEnd = appliedFilters.dateEnd || '';
    const dateLabel = (dateStart || dateEnd) ? `${dateStart || '...'} to ${dateEnd || '...'}` : 'All Dates';
    const search = appliedFilters.search || 'All';

    document.getElementById('printMetaText').textContent =
        `School Year: ${schoolYear} | Source: ${source} | Booklet: ${booklet} | Category: ${category} | Date Range: ${dateLabel} | Search: ${search}`;
}

function updateSummary(filteredRows) {
    const receiptCount = filteredRows.length;
    let grandTotal = 0;
    let activeTotal = 0;
    let oldTotal = 0;

    filteredRows.forEach((row) => {
        grandTotal += row.total;
        if (row.source === 'Active') {
            activeTotal += row.total;
        } else if (row.source === 'Old') {
            oldTotal += row.total;
        }
    });

    document.getElementById('summaryReceiptCount').textContent = receiptCount.toLocaleString();
    document.getElementById('summaryGrandTotal').textContent = formatCurrency(grandTotal);
    document.getElementById('summaryActiveTotal').textContent = formatCurrency(activeTotal);
    document.getElementById('summaryOldTotal').textContent = formatCurrency(oldTotal);
}

function renderPagination(currentPage, totalPages, onPageClick) {
    const pagination = document.getElementById('paginationList');
    pagination.innerHTML = '';

    if (totalPages <= 1) {
        return;
    }

    const addPageItem = (label, page, disabled = false, active = false) => {
        const li = document.createElement('li');
        li.className = 'page-item' + (disabled ? ' disabled' : '') + (active ? ' active' : '');
        const link = document.createElement('a');
        link.className = 'page-link';
        link.href = '#';
        link.textContent = label;
        if (!disabled) {
            link.addEventListener('click', (event) => {
                event.preventDefault();
                onPageClick(page);
            });
        }
        li.appendChild(link);
        pagination.appendChild(li);
    };

    if (currentPage > 1) {
        addPageItem('Previous', currentPage - 1);
    }

    const pagesToShow = [];
    if (totalPages <= 7) {
        for (let i = 1; i <= totalPages; i += 1) {
            pagesToShow.push(i);
        }
    } else {
        pagesToShow.push(1, 2);
        if (currentPage > 3) {
            pagesToShow.push('...');
        }
        for (let i = Math.max(3, currentPage - 1); i <= Math.min(totalPages - 2, currentPage + 1); i += 1) {
            pagesToShow.push(i);
        }
        if (currentPage < totalPages - 2) {
            pagesToShow.push('...');
        }
        pagesToShow.push(totalPages - 1, totalPages);
    }

    pagesToShow.forEach((page) => {
        if (page === '...') {
            addPageItem('...', currentPage, true, false);
        } else {
            addPageItem(String(page), page, false, page === currentPage);
        }
    });

    if (currentPage < totalPages) {
        addPageItem('Next', currentPage + 1);
    }
}

function filterRows() {
    const searchValue = (appliedFilters.search || '').toLowerCase();
    const sourceValue = appliedFilters.source;
    const bookletValue = appliedFilters.booklet;
    const categoryValue = (appliedFilters.category || '').toLowerCase();
    const dateStart = appliedFilters.dateStart;
    const dateEnd = appliedFilters.dateEnd;

    return rowsData.filter((row) => {
        if (searchValue && !row.searchText.includes(searchValue)) {
            return false;
        }
        if (sourceValue && row.source !== sourceValue) {
            return false;
        }
        if (bookletValue && row.booklet !== bookletValue) {
            return false;
        }
        if (categoryValue && !row.categories.includes(categoryValue)) {
            return false;
        }
        if (dateStart && row.date && row.date < dateStart) {
            return false;
        }
        if (dateEnd && row.date && row.date > dateEnd) {
            return false;
        }
        return true;
    });
}

function renderTable(page = 1) {
    const filteredRows = filterRows();
    updateSummary(filteredRows);
    updatePrintMeta();

    const totalPages = Math.max(1, Math.ceil(filteredRows.length / perPage));
    const currentPage = Math.min(Math.max(page, 1), totalPages);
    const start = (currentPage - 1) * perPage;
    const pagedRows = filteredRows.slice(start, start + perPage);
    const tbody = document.getElementById('invoiceTotalTableBody');

    tbody.innerHTML = '';

    if (!pagedRows.length) {
        const emptyRow = document.createElement('tr');
        emptyRow.innerHTML = '<td colspan="11" class="empty-state">No invoice records match the selected filters.</td>';
        tbody.appendChild(emptyRow);
    } else {
        pagedRows.forEach((row) => {
            tbody.appendChild(row.tr);
        });
    }

    renderPagination(currentPage, totalPages, renderTable);
}

function applyServerFiltersReload() {
    const schoolYear = document.getElementById('schoolYearSelector').value || '';
    const currentFilters = getCurrentInputFilters();
    const url = new URL(window.location.href);
    url.searchParams.set('school_year', schoolYear);
    if (currentFilters.dateStart !== '') {
        url.searchParams.set('start_date', currentFilters.dateStart);
    } else {
        url.searchParams.set('start_date', '');
    }
    if (currentFilters.dateEnd !== '') {
        url.searchParams.set('end_date', currentFilters.dateEnd);
    } else {
        url.searchParams.set('end_date', '');
    }
    if (currentFilters.search !== '') {
        url.searchParams.set('search', currentFilters.search);
    } else {
        url.searchParams.delete('search');
    }
    if (currentFilters.source !== '') {
        url.searchParams.set('source', currentFilters.source);
    } else {
        url.searchParams.delete('source');
    }
    if (currentFilters.booklet !== '') {
        url.searchParams.set('booklet', currentFilters.booklet);
    } else {
        url.searchParams.delete('booklet');
    }
    if (currentFilters.category !== '') {
        url.searchParams.set('category', document.getElementById('filterCategory').value);
    } else {
        url.searchParams.delete('category');
    }
    window.location.href = url.toString();
}

document.getElementById('applyDateBtn').addEventListener('click', applyServerFiltersReload);

['filterDateStart', 'filterDateEnd', 'searchInput'].forEach((id) => {
    const input = document.getElementById(id);
    input.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            event.preventDefault();
            applyServerFiltersReload();
        }
    });
});

document.getElementById('clearFiltersBtn').addEventListener('click', () => {
    document.getElementById('searchInput').value = '';
    document.getElementById('filterSource').value = '';
    document.getElementById('filterBooklet').value = '';
    document.getElementById('filterCategory').value = '';
    document.getElementById('filterDateStart').value = '';
    document.getElementById('filterDateEnd').value = '';
    appliedFilters = {
        search: '',
        source: '',
        booklet: '',
        category: '',
        dateStart: '',
        dateEnd: ''
    };
    const url = new URL(window.location.href);
    url.searchParams.set('school_year', document.getElementById('schoolYearSelector').value || '');
    url.searchParams.set('start_date', '');
    url.searchParams.set('end_date', '');
    url.searchParams.delete('search');
    url.searchParams.delete('source');
    url.searchParams.delete('booklet');
    url.searchParams.delete('category');
    window.location.href = url.toString();
});

function auditExportDownload(label, fileName, details) {
    const formData = new FormData();
    formData.append('csrf_token', <?= json_encode($csrfToken) ?>);
    formData.append('action_kind', 'export_download');
    formData.append('label', label);
    formData.append('file_name', fileName);
    formData.append('details', details || '');

    if (navigator.sendBeacon) {
        navigator.sendBeacon('/school-admin-dashboard/modules/audit/audit-client-event.php', formData);
        return;
    }

    fetch('/school-admin-dashboard/modules/audit/audit-client-event.php', {
        method: 'POST',
        body: formData,
        credentials: 'same-origin',
        keepalive: true
    }).catch(function () {});
}

document.getElementById('exportExcelBtn').addEventListener('click', () => {
    const filteredRows = filterRows();
    const dateStart = appliedFilters.dateStart || '';
    const dateEnd = appliedFilters.dateEnd || '';
    const dateRange = (dateStart || dateEnd) ? `${dateStart || '...'} to ${dateEnd || '...'}` : 'All Dates';
    const exportData = [
        ['Invoice Total Summary'],
        ['School Year', document.getElementById('schoolYearSelector').value || 'All'],
        ['Source', appliedFilters.source || 'All Records'],
        ['Booklet', appliedFilters.booklet || 'All'],
        ['Category', appliedFilters.category || 'All'],
        ['Date Range', dateRange],
        ['Prepared By', <?= json_encode($username !== '' ? $username : 'System User') ?>],
        ['Generated On', <?= json_encode(date('F j, Y g:i A')) ?>],
        [],
        ['Record', 'Date', 'Time', 'Name', 'Grade', 'LRN', 'Booklet No', 'Receipt No', 'Breakdown', 'Notes', 'Total']
    ];

    filteredRows.forEach((row) => {
        exportData.push(row.exportRow.map((value) => String(value)));
    });

    if (!filteredRows.length) {
        exportData.push(['No invoice records match the selected filters.']);
    }

    const worksheet = XLSX.utils.aoa_to_sheet(exportData);
    worksheet['!cols'] = [
        { wch: 12 },
        { wch: 14 },
        { wch: 12 },
        { wch: 32 },
        { wch: 12 },
        { wch: 18 },
        { wch: 16 },
        { wch: 16 },
        { wch: 34 },
        { wch: 22 },
        { wch: 16 }
    ];
    worksheet['!autofilter'] = { ref: 'A10:K10' };

    for (let rowIndex = 10; rowIndex < exportData.length; rowIndex += 1) {
        const lrnCell = XLSX.utils.encode_cell({ r: rowIndex, c: 5 });
        if (worksheet[lrnCell]) {
            worksheet[lrnCell].t = 's';
            worksheet[lrnCell].z = '@';
        }
        const receiptCell = XLSX.utils.encode_cell({ r: rowIndex, c: 7 });
        if (worksheet[receiptCell]) {
            worksheet[receiptCell].t = 's';
            worksheet[receiptCell].z = '@';
        }
    }

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Invoice Total');
    const filename = [
        'invoice_total',
        sanitizeFilenamePart(document.getElementById('schoolYearSelector').value),
        sanitizeFilenamePart(appliedFilters.source || 'all'),
        sanitizeFilenamePart(appliedFilters.booklet || 'all')
    ].join('_') + '.xlsx';
    auditExportDownload(
        'Invoice Total Excel',
        filename,
        `School Year: ${document.getElementById('schoolYearSelector').value || 'All'} | Source: ${appliedFilters.source || 'All'} | Booklet: ${appliedFilters.booklet || 'All'} | Category: ${appliedFilters.category || 'All'} | Date Range: ${dateRange} | Search: ${appliedFilters.search || 'All'}`
    );
    XLSX.writeFile(workbook, filename);
});

document.getElementById('themeToggleBtn')?.addEventListener('click', function () {
    document.body.classList.toggle('dark-mode');
    this.querySelector('i')?.classList.toggle('fa-moon');
    this.querySelector('i')?.classList.toggle('fa-sun');
});

window.addEventListener('load', () => {
    appliedFilters = getCurrentInputFilters();
    renderTable(1);
});
</script>
</body>
</html>
<?php $conn->close(); ?>

