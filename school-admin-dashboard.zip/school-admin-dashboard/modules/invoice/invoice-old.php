<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/settings-security.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/includes-receipt-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/schema-migration.php';
require_once __DIR__ . '/../audit/audit-helper.php';
function ensure_old_payment_datetime_column(mysqli $conn): void {
    if (!schema_migration_mode_enabled()) {
        return;
    }
    $columnName = 'paid_at_datetime';
    $check = $conn->prepare("
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'old_student_payments'
          AND COLUMN_NAME = ?
        LIMIT 1
    ");
    $check->bind_param('s', $columnName);
    $check->execute();
    $exists = $check->get_result()->num_rows > 0;
    $check->close();
    if (!$exists) {
        schema_migration_attempt($conn, "ALTER TABLE old_student_payments ADD COLUMN paid_at_datetime DATETIME NULL AFTER paid_at");
    }
}
ensure_old_payment_datetime_column($conn);

// Permission check
$currentRole = $_SESSION['role'] ?? '';
if (!hasPermission($currentRole, 'financial', 'view')) {
    audit_log(
        $conn,
        $_SESSION['username'] ?? 'unknown',
        'Blocked old invoice access',
        'Invoice',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing financial:view permission',
        'SECURITY'
    );
    header('Location: /school-admin-dashboard/dashboard.php?error=invoice_denied');
    exit();
}

$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$csrfToken = ensure_csrf_token();
$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";

// Only use paid fee types, not fee master list
$fee_types = [];
$res_types = $conn->query("SELECT DISTINCT fee_type FROM old_student_payments ORDER BY fee_type ASC");
while ($row = $res_types->fetch_assoc()) {
    $fee_types[] = $row['fee_type'];
}

// Get all old student receipts/payments (not deleted)
$sql = "
SELECT 
    p.id AS payment_id,
    p.paid_at,
    p.paid_at_datetime,
    p.booklet_no,
    p.receipt_no,
    p.amount,
    CONCAT(s.lastname, ', ', s.firstname, ' ', s.middlename) AS student_name,
    p.fee_type,
    p.note
FROM old_student_payments p
INNER JOIN receipts_registry rr
    ON rr.receipt_no = p.receipt_no
    AND rr.booklet_no = p.booklet_no
    AND rr.voided = 0
    AND rr.used_by = 'old_student_payments'
LEFT JOIN old_students s ON p.old_student_id = s.id
WHERE p.booklet_no IS NOT NULL 
  AND p.receipt_no IS NOT NULL 
  AND (p.deleted_at IS NULL OR p.deleted_at = '')
ORDER BY COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) DESC, p.id DESC
";
$res = $conn->query($sql);

// Group data by receipt number
$receipts = [];
if ($res && $res->num_rows > 0) {
    while ($row = $res->fetch_assoc()) {
        $rid = $row['booklet_no'] . '-' . $row['receipt_no'];
        if (!isset($receipts[$rid])) {
            $receipts[$rid] = [
                'student_name' => $row['student_name'],
                'paid_at' => $row['paid_at'],
                'paid_at_full' => $row['paid_at_datetime'] ?: ($row['paid_at'] ? $row['paid_at'] . ' 00:00:00' : ''),
                'booklet_no' => $row['booklet_no'],
                'booklet_label' => booklet_label_from_stored((int) $row['booklet_no']),
                'receipt_no' => $row['receipt_no'],
                'amounts' => [],
                'notes' => [],
            ];
        }
        // Only show amounts actually paid per receipt per fee_type
        $receipts[$rid]['amounts'][$row['fee_type']] = $row['amount'];
        $receipts[$rid]['notes'][$row['fee_type']] = $row['note'];
    }
}

// For filter dropdowns
$booklet_nos = [];
foreach ($receipts as $row) {
    if (!empty($row['booklet_label'])) $booklet_nos[$row['booklet_label']] = true;
}

// Pagination setup
$all_receipt_keys = array_keys($receipts);
$total_receipts = count($all_receipt_keys);
$per_page = 50;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$total_pages = max(1, ceil($total_receipts / $per_page));
$start = ($page - 1) * $per_page;
$end = min($start + $per_page, $total_receipts);
$page_keys = array_slice($all_receipt_keys, $start, $per_page);
$receiptRowsForJs = [];
foreach ($receipts as $row) {
    $amountCells = [];
    foreach ($fee_types as $fee_type) {
        $amountValue = isset($row['amounts'][$fee_type]) ? (float) $row['amounts'][$fee_type] : null;
        $noteValue = isset($row['notes'][$fee_type]) ? trim((string) $row['notes'][$fee_type]) : '';
        $display = '';
        $export = '';
        if ($amountValue !== null) {
            $display = 'PHP ' . number_format($amountValue, 2);
            $export = number_format($amountValue, 2, '.', '');
            if ($noteValue !== '' && !in_array($noteValue, ['Outstanding', 'Fully Paid', 'Low Balance'], true)) {
                $display .= "\n" . $noteValue;
                $export .= ' | ' . $noteValue;
            }
        }
        $amountCells[] = [
            'display' => $display,
            'export' => $export,
        ];
    }

    $dateDisplay = '';
    $dateComparable = '';
    if (!empty($row['paid_at_full'])) {
        $dt = new DateTime($row['paid_at_full']);
        $dateDisplay = $dt->format('n/j/Y');
        $dateComparable = $dt->format('Y-m-d');
    }

    $receiptRowsForJs[] = [
        'name' => (string) ($row['student_name'] ?? ''),
        'date_display' => $dateDisplay,
        'date_compare' => $dateComparable,
        'booklet' => (string) ($row['booklet_label'] ?? ''),
        'receipt' => (string) ($row['receipt_no'] ?? ''),
        'amount_cells' => $amountCells,
        'search_text' => strtolower(trim(implode(' ', [
            (string) ($row['student_name'] ?? ''),
            $dateDisplay,
            (string) ($row['booklet_label'] ?? ''),
            (string) ($row['receipt_no'] ?? ''),
            implode(' ', array_map(static fn($cell) => (string) ($cell['export'] ?? ''), $amountCells)),
        ]))),
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invoice Old Records | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body {
            background: var(--main-bg);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        }
        body.dark-mode {
            --main-bg: #1b232d;
            --card-bg: #23395d;
            --navbar-bg: #161b22;
            color: #e6edf3;
        }
        .navbar {
            background: var(--navbar-bg) !important;
            box-shadow: 0 2px 12px rgba(33,57,93,0.08);
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.08em;
        }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .theme-toggle-btn {
            background: none;
            border: none;
            color: #fff;
            font-size: 1.45em;
            margin-left: 12px;
            cursor: pointer;
        }
        .dashboard-header {
            text-align: center;
            margin-top: 36px;
            margin-bottom: 18px;
        }
        .dashboard-header img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            margin-bottom: 6px;
        }
        .dashboard-header h1 {
            font-size: 1.3rem;
            color: var(--brand-dark);
            font-weight: 700;
            margin-bottom: 0;
            letter-spacing: 0.02em;
        }
        th, td { text-align: center; vertical-align: middle; }
        th { background: #eaf4ff; }
        .table-responsive { font-size: 1rem; }
        .report-header {
            margin-bottom: 1.5rem;
            text-align: center;
        }
        .report-header h2 {
            font-weight: bold;
            margin-bottom: .4rem;
        }
        .action-bar {
            margin-bottom: 1rem;
            display: flex;
            gap: 1rem;
            align-items: center;
            flex-wrap: wrap;
            justify-content: flex-start;
        }
        .filter-actions {
            display: flex;
            gap: 0.5rem;
            align-items: center;
            flex-wrap: wrap;
        }
        @media (min-width: 768px) {
            .action-bar {
                justify-content: flex-end;
            }
        }
        .action-bar .form-control, .action-bar .form-select {
            max-width: 180px;
            display: inline-block;
        }
        .back-dashboard-btn {
            margin-left: auto;
        }
        .pagination-container {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 18px;
            gap: 4px;
        }
        .pagination .page-link {
            min-width: 36px;
            text-align: center;
        }
        @media print {
            .action-bar, .back-dashboard-btn, .pagination-container, .card-header, .navbar, .dashboard-header, .footer, .dashboard-btn-bottom { display: none !important; }
            .card { box-shadow: none !important; }
        }
        .dashboard-btn-bottom {
            position: fixed;
            left: 28px;
            bottom: 28px;
            z-index: 1060;
            background: #e7f0fd;
            color: #517fa4;
            border: 2px solid #bcdfff;
            box-shadow: 0 5px 16px rgba(33,57,93,0.13);
            border-radius: 50%;
            width: 58px;
            height: 58px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.55em;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
            text-decoration: none;
        }
        .dashboard-btn-bottom:hover, .dashboard-btn-bottom:focus {
            background: #fff2b3;
            color: #517fa4;
            border-color: #ffe599;
        }
    </style>
</head>
<body>
<?php render_admin_nav('invoice', true); ?>
<div class="dashboard-header">
    <img src="/school-admin-dashboard/uploads/logo1.png" alt="School Logo" class="mb-2 rounded shadow-sm">
    <h1><?= $schoolName ?></h1>
</div>
<div class="container-fluid py-4">
    <div class="report-header">
        <h2><i class="fas fa-file-invoice-dollar"></i> Invoice Old Records</h2>
        <div class="lead text-muted">All Official Receipts for Old Students (Withdrawn, Former, Graduated)</div>
    </div>
    <div class="action-bar">
        <input type="text" class="form-control" id="searchInput" placeholder="Quick Search">
        <input type="date" class="form-control" id="filterDateStart" placeholder="Start Date">
        <span>-</span>
        <input type="date" class="form-control" id="filterDateEnd" placeholder="End Date">
        <select class="form-select" id="filterBooklet">
            <option value="">All Booklet Nos</option>
            <?php foreach (array_keys($booklet_nos) as $bno): ?>
                <option value="<?= htmlspecialchars($bno) ?>"><?= htmlspecialchars($bno) ?></option>
            <?php endforeach; ?>
        </select>
        <div class="filter-actions">
            <button class="btn btn-primary" type="button" id="applyFiltersBtn">
                <i class="fas fa-filter"></i> Apply Filters
            </button>
            <button class="btn btn-outline-secondary" type="button" id="clearFiltersBtn">
                <i class="fas fa-rotate-left"></i> Clear Filters
            </button>
        </div>
        <button class="btn btn-success" onclick="exportTableToExcel('invoiceTable', 'Invoice_Old_Records')">
            <i class="fas fa-file-excel"></i> Export to Excel
        </button>
        <button class="btn btn-secondary" onclick="window.print()">
            <i class="fas fa-print"></i>
        </button>
        <a href="/school-admin-dashboard/dashboard.php" class="btn btn-primary back-dashboard-btn">
            <i class="fas fa-arrow-left"></i>
        </a>
    </div>
    <div class="alert alert-light border mb-3 py-2 px-3 small" id="printMeta">
        <strong>Print/Export Context:</strong>
        <span id="printMetaText">Booklet: All | Date Range: All Dates</span>
    </div>
    <div class="card shadow-sm">
        <div class="card-header bg-info text-light">
            <i class="fas fa-file-invoice-dollar"></i> Old Receipts Table
        </div>
        <div class="card-body table-responsive">
            <table class="table table-bordered table-hover align-middle" id="invoiceTable">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Date</th>
                        <th>Booklet No</th>
                        <th>Receipt No</th>
                        <?php foreach ($fee_types as $type_name): ?>
                            <th><?= htmlspecialchars($type_name) ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody id="invoiceTableBody">
                <?php if (count($receipts)): ?>
                    <?php foreach ($page_keys as $rid): $row = $receipts[$rid]; ?>
                    <tr>
                        <td><?= htmlspecialchars($row['student_name']) ?></td>
                        <td>
                            <?php
                            if (!empty($row['paid_at_full'])) {
                                $dt = new DateTime($row['paid_at_full']);
                                echo $dt->format('n/j/Y');
                            }
                            ?>
                        </td>
                        <td><?= htmlspecialchars($row['booklet_label']) ?></td>
                        <td><?= htmlspecialchars($row['receipt_no']) ?></td>
                        <?php foreach ($fee_types as $fee_type): ?>
                            <td>
                                <?php
                                if (isset($row['amounts'][$fee_type])) {
                                    echo '&#8369;' . number_format($row['amounts'][$fee_type], 2);
                                    // Only show note if it's NOT a status label
                                    if (!empty($row['notes'][$fee_type])) {
                                        $note = $row['notes'][$fee_type];
                                        if (!in_array($note, ['Outstanding', 'Fully Paid', 'Low Balance'])) {
                                            echo '<br><small class="text-muted">' . htmlspecialchars($note) . '</small>';
                                        }
                                    }
                                } else {
                                    echo '';
                                }
                                ?>
                            </td>
                        <?php endforeach; ?>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="<?= 4 + count($fee_types) ?>" class="text-center">No receipts found.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
            <!-- Pagination Bar -->
            <div class="pagination-container">
                <nav>
                    <ul class="pagination mb-0">
                    <?php if ($page > 1): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?= $page-1 ?>">&#8592;</a></li>
                    <?php endif; ?>
                    <?php
                        $show_pages = [];
                        if ($total_pages <= 7) {
                            for ($i=1; $i<=$total_pages; $i++) $show_pages[] = $i;
                        } else {
                            $show_pages = [1, 2];
                            if ($page > 3) $show_pages[] = '...';
                            for ($i = max(3, $page-1); $i <= min($total_pages-2, $page+1); $i++) $show_pages[] = $i;
                            if ($page < $total_pages-2) $show_pages[] = '...';
                            $show_pages[] = $total_pages-1;
                            $show_pages[] = $total_pages;
                        }
                        foreach ($show_pages as $pg) {
                            if ($pg === '...') {
                                echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                            } else {
                                $active = ($pg == $page) ? ' active' : '';
                                echo '<li class="page-item'.$active.'"><a class="page-link" href="?page='.$pg.'">'.$pg.'</a></li>';
                            }
                        }
                    ?>
                    <?php if ($page < $total_pages): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?= $page+1 ?>">&#8594;</a></li>
                    <?php endif; ?>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
    <footer class="footer text-center py-4 text-muted small">
        &copy; <?= date("Y") ?> <?= $schoolName ?> | School Admin Dashboard
    </footer>
    <a href="/school-admin-dashboard/dashboard.php" class="dashboard-btn-bottom" title="Go to Dashboard">
        <i class="fas fa-tachometer-alt"></i>
    </a>
    <?php if (file_exists('../../includes/footer.php')) include '../../includes/footer.php'; ?>
</div>
<script>
const allRowsData = <?= json_encode($receiptRowsForJs, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const feeTypeLabels = <?= json_encode(array_values($fee_types), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;

let appliedFilters = {
    search: '',
    booklet: '',
    dateStart: '',
    dateEnd: ''
};

function getCurrentInputFilters() {
    return {
        search: document.getElementById('searchInput').value.toLowerCase().trim(),
        booklet: document.getElementById('filterBooklet').value,
        dateStart: document.getElementById('filterDateStart').value || '',
        dateEnd: document.getElementById('filterDateEnd').value || ''
    };
}

function applyFilters(page = 1) {
    appliedFilters = getCurrentInputFilters();
    filterAndPaginate(page);
    updatePrintMeta();
}

function clearFilters() {
    document.getElementById('searchInput').value = '';
    document.getElementById('filterBooklet').value = '';
    document.getElementById('filterDateStart').value = '';
    document.getElementById('filterDateEnd').value = '';
    appliedFilters = getCurrentInputFilters();
    filterAndPaginate(1);
    updatePrintMeta();
}

function filterAndPaginate(page=1) {
    let search = appliedFilters.search;
    let booklet = appliedFilters.booklet;
    let dateStart = appliedFilters.dateStart;
    let dateEnd = appliedFilters.dateEnd;
    let filtered = allRowsData.filter(row => {
        let show = true;
        if (search && !row.search_text.includes(search)) show = false;
        if (booklet && row.booklet !== booklet) show = false;
        if ((dateStart || dateEnd) && row.date_compare) {
            if (dateStart && row.date_compare < dateStart) show = false;
            if (dateEnd && row.date_compare > dateEnd) show = false;
        }
        return show;
    });

    let total = filtered.length;
    let per_page = <?= $per_page ?>;
    let total_pages = Math.max(1, Math.ceil(total / per_page));
    page = Math.max(1, Math.min(page, total_pages));
    let start = (page-1)*per_page;
    let end = start+per_page;
    let paged = filtered.slice(start, end);

    let tbody = document.getElementById('invoiceTableBody');
    tbody.innerHTML = '';
    if (!paged.length) {
        const emptyRow = document.createElement('tr');
        emptyRow.innerHTML = `<td colspan="${4 + feeTypeLabels.length}" class="text-center">No receipts found.</td>`;
        tbody.appendChild(emptyRow);
    } else {
        paged.forEach(row => {
            const amountCellsHtml = row.amount_cells.map(cell => {
                if (!cell.display) {
                    return '<td></td>';
                }
                const parts = String(cell.display).split('\n');
                const primary = escapeHtml(parts.shift() || '');
                const note = parts.length ? `<br><small class="text-muted">${escapeHtml(parts.join(' '))}</small>` : '';
                return `<td>${primary}${note}</td>`;
            }).join('');
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${escapeHtml(row.name)}</td>
                <td>${escapeHtml(row.date_display)}</td>
                <td>${escapeHtml(row.booklet)}</td>
                <td>${escapeHtml(row.receipt)}</td>
                ${amountCellsHtml}
            `;
            tbody.appendChild(tr);
        });
    }

    let pagin = document.querySelector('.pagination');
    if (pagin) {
        pagin.innerHTML = '';
        if (page > 1) {
            let prev = document.createElement('li');
            prev.className = 'page-item';
            prev.innerHTML = '<a class="page-link" href="#">&#8592;</a>';
            prev.onclick = e => { e.preventDefault(); filterAndPaginate(page-1); };
            pagin.appendChild(prev);
        }
        let show_pages = [];
        if (total_pages <= 7) {
            for (let i=1; i<=total_pages; i++) show_pages.push(i);
        } else {
            show_pages = [1,2];
            if (page > 3) show_pages.push('...');
            for (let i=Math.max(3,page-1); i<=Math.min(total_pages-2,page+1); i++) show_pages.push(i);
            if (page < total_pages-2) show_pages.push('...');
            show_pages.push(total_pages-1);
            show_pages.push(total_pages);
        }
        show_pages.forEach(pg => {
            if (pg === '...') {
                let li = document.createElement('li');
                li.className = 'page-item disabled';
                li.innerHTML = '<span class="page-link">...</span>';
                pagin.appendChild(li);
            } else {
                let li = document.createElement('li');
                li.className = 'page-item' + (pg == page ? ' active' : '');
                li.innerHTML = `<a class="page-link" href="#">${pg}</a>`;
                li.onclick = e => { e.preventDefault(); filterAndPaginate(pg); };
                pagin.appendChild(li);
            }
        });
        if (page < total_pages) {
            let next = document.createElement('li');
            next.className = 'page-item';
            next.innerHTML = '<a class="page-link" href="#">&#8594;</a>';
            next.onclick = e => { e.preventDefault(); filterAndPaginate(page+1); };
            pagin.appendChild(next);
        }
    }
}

document.getElementById('applyFiltersBtn').addEventListener('click', function(){ applyFilters(1); });
document.getElementById('clearFiltersBtn').addEventListener('click', function(){ clearFilters(); });
document.getElementById('searchInput').addEventListener('keydown', function(event){
    if (event.key === 'Enter') {
        event.preventDefault();
        applyFilters(1);
    }
});

function sanitizeFilenamePart(value) {
    return String(value || 'all').trim().replace(/[^a-z0-9]+/gi, '_').replace(/^_+|_+$/g, '') || 'all';
}

function auditExportDownload(label, fileName, details) {
    const formData = new FormData();
    formData.append('csrf_token', <?= json_encode($csrfToken) ?>);
    formData.append('action_kind', 'export_download');
    formData.append('label', label);
    formData.append('file_name', fileName);
    formData.append('details', details || '');

    if (navigator.sendBeacon) {
        navigator.sendBeacon('/school-admin-dashboard/modules/audit/audit-client-event.php', formData);
        return;
    }

    fetch('/school-admin-dashboard/modules/audit/audit-client-event.php', {
        method: 'POST',
        body: formData,
        credentials: 'same-origin',
        keepalive: true
    }).catch(function () {});
}

function exportTableToExcel(tableID, filename = ''){
    const booklet = appliedFilters.booklet || 'All';
    const dateStart = appliedFilters.dateStart || '';
    const dateEnd = appliedFilters.dateEnd || '';
    const dateLabel = (dateStart || dateEnd) ? `${dateStart || '...'} to ${dateEnd || '...'}` : 'All Dates';
    const search = appliedFilters.search;

    let filtered = allRowsData.filter(row => {
        let show = true;
        if (search && !row.search_text.includes(search)) show = false;
        if (appliedFilters.booklet && row.booklet !== appliedFilters.booklet) show = false;
        if ((dateStart || dateEnd) && row.date_compare) {
            if (dateStart && row.date_compare < dateStart) show = false;
            if (dateEnd && row.date_compare > dateEnd) show = false;
        }
        return show;
    });

    const exportData = [
        ['Invoice Old Records'],
        ['Booklet', booklet],
        ['Date Range', dateLabel],
        ['Prepared By', <?= json_encode($username !== '' ? $username : 'System User') ?>],
        ['Generated On', <?= json_encode(date('F j, Y g:i A')) ?>],
        [],
        ['Name', 'Date', 'Booklet No', 'Receipt No', ...Array.from(document.querySelectorAll('#invoiceTable thead th')).slice(4).map(th => th.textContent.trim())]
    ];

    filtered.forEach(row => exportData.push([
        String(row.name || ''),
        String(row.date_display || ''),
        String(row.booklet || ''),
        String(row.receipt || ''),
        ...row.amount_cells.map(cell => String(cell.export || ''))
    ]));
    if (!filtered.length) {
        exportData.push(['No old invoice records match the selected filters.']);
    }

    const worksheet = XLSX.utils.aoa_to_sheet(exportData);
    const lastColumnIndex = exportData[6].length - 1;
    const lastColumnLetter = XLSX.utils.encode_col(lastColumnIndex);
    worksheet['!cols'] = [
        { wch: 32 },
        { wch: 14 },
        { wch: 16 },
        { wch: 16 },
        ...Array(Math.max(0, exportData[6].length - 4)).fill({ wch: 16 })
    ];
    worksheet['!autofilter'] = { ref: `A7:${lastColumnLetter}7` };

    for (let rowIndex = 7; rowIndex < exportData.length; rowIndex += 1) {
        const receiptCell = XLSX.utils.encode_cell({ r: rowIndex, c: 3 });
        if (worksheet[receiptCell]) {
            worksheet[receiptCell].t = 's';
            worksheet[receiptCell].z = '@';
        }
    }

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, worksheet, 'Invoice Old');
    const exportFileName = `invoice_old_${sanitizeFilenamePart(appliedFilters.booklet || 'all')}.xlsx`;
    auditExportDownload(
        'Invoice Old Excel',
        exportFileName,
        `Booklet: ${booklet} | Date Range: ${dateLabel} | Search: ${appliedFilters.search || 'All'}`
    );
    return XLSX.writeFile(wb, exportFileName);
}

function updatePrintMeta() {
    const booklet = appliedFilters.booklet || 'All';
    const dateStart = appliedFilters.dateStart || '';
    const dateEnd = appliedFilters.dateEnd || '';
    const dateLabel = (dateStart || dateEnd) ? `${dateStart || '...'} to ${dateEnd || '...'}` : 'All Dates';
    document.getElementById('printMetaText').textContent = `Booklet: ${booklet} | Date Range: ${dateLabel} | Search: ${appliedFilters.search || 'All'}`;
}

function escapeHtml(value) {
    return String(value || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

window.onload = function() {
    appliedFilters = getCurrentInputFilters();
    filterAndPaginate(1);
    updatePrintMeta();
};

document.getElementById('themeToggleBtn').addEventListener('click', function() {
    document.body.classList.toggle('dark-mode');
    this.querySelector('i').classList.toggle('fa-moon');
    this.querySelector('i').classList.toggle('fa-sun');
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>


