<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/settings-security.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/includes-receipt-helper.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/../audit/audit-helper.php';
ensure_receipts_registry_schema($conn);

// Permission check: Only admin/teacher and view permission
$currentRole = $_SESSION['role'] ?? '';
if (!hasPermission($currentRole, 'financial', 'view')) {
    audit_log(
        $conn,
        $_SESSION['username'] ?? 'unknown',
        'Blocked invoice compilation access',
        'Invoice',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing financial:view permission',
        'SECURITY'
    );
    header('Location: /school-admin-dashboard/dashboard.php?error=invoice_denied');
    exit();
}

$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$csrfToken = ensure_csrf_token();
$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
$school_year_options = school_year_finance_options($conn, 'payments');
$active_school_year_label = school_year_get_active_label($conn);
$selected_school_year = trim($_GET['school_year'] ?? '');
if ($selected_school_year === '') {
    $selected_school_year = $active_school_year_label;
}

// Get all account types for dynamic columns (ordered by priority then name)
$account_types = [];
$res_types = $conn->query("SELECT id, name FROM account_types ORDER BY priority ASC, name ASC");
while ($row = $res_types->fetch_assoc()) {
    $account_types[$row['id']] = $row['name'];
}

// Get all receipts/payments with official OR info
$sql = "
SELECT 
    p.id AS payment_id,
    p.date_paid,
    p.booklet_no,
    p.receipt_no,
    p.amount,
    s.lrn,
    s.grade,
    CONCAT(s.lastname, ', ', s.firstname, ' ', s.middlename) AS student_name,
    at.id AS account_type_id,
    at.name AS account_type_name
FROM payments p
INNER JOIN receipts_registry rr
    ON rr.receipt_no = p.receipt_no
    AND rr.booklet_no = p.booklet_no
    AND rr.voided = 0
    AND rr.used_by IN ('payments', 'other_payment')
LEFT JOIN accounts a ON p.account_id = a.id
LEFT JOIN account_types at ON a.type = at.name
LEFT JOIN students s ON a.student_id = s.id
WHERE p.booklet_no IS NOT NULL AND p.receipt_no IS NOT NULL
  AND COALESCE(NULLIF(TRIM(p.school_year_label), ''), NULLIF(TRIM(a.school_year_label), ''), NULLIF(TRIM(s.school_year_label), '')) = ?
ORDER BY p.date_paid DESC, p.id DESC
";
$stmt = $conn->prepare($sql);
$res = false;
if ($stmt) {
    $stmt->bind_param('s', $selected_school_year);
    $stmt->execute();
    $res = $stmt->get_result();
    $stmt->close();
}

// Group data by receipt
$receipts = [];
if ($res && $res->num_rows > 0) {
    while ($row = $res->fetch_assoc()) {
        $rid = $row['booklet_no'] . '-' . $row['receipt_no'];
        if (!isset($receipts[$rid])) {
            $receipts[$rid] = [
                'student_name' => $row['student_name'],
                'grade' => $row['grade'],
                'lrn' => $row['lrn'],
                'date_paid' => $row['date_paid'],
                'booklet_no' => $row['booklet_no'],
                'booklet_label' => booklet_label_from_stored((int) $row['booklet_no']),
                'receipt_no' => $row['receipt_no'],
                'amounts' => []
            ];
        }
        if ($row['account_type_id']) {
            $receipts[$rid]['amounts'][$row['account_type_id']] = $row['amount'];
        }
    }
}

// For filter dropdowns
$grades = [];
$booklet_nos = [];
foreach ($receipts as $row) {
    if (!empty($row['grade'])) $grades[$row['grade']] = true;
    if (!empty($row['booklet_label'])) $booklet_nos[$row['booklet_label']] = true;
}

// Pagination setup
$all_receipt_keys = array_keys($receipts);
$total_receipts = count($all_receipt_keys);
$per_page = 50;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$total_pages = max(1, ceil($total_receipts / $per_page));

// Only show the current page receipts for initial view (JS will handle search/filter pagination)
$start = ($page - 1) * $per_page;
$end = min($start + $per_page, $total_receipts);
$page_keys = array_slice($all_receipt_keys, $start, $per_page);
$receiptRowsForJs = [];
foreach ($receipts as $row) {
    $amountCells = [];
    foreach ($account_types as $type_id => $type_name) {
        $amountValue = isset($row['amounts'][$type_id]) ? (float) $row['amounts'][$type_id] : null;
        $amountCells[] = [
            'display' => $amountValue !== null ? ('PHP ' . number_format($amountValue, 2)) : '',
            'export' => $amountValue !== null ? number_format($amountValue, 2, '.', '') : '',
        ];
    }

    $dateDisplay = '';
    $dateComparable = '';
    if (!empty($row['date_paid'])) {
        $dt = new DateTime($row['date_paid']);
        $dateDisplay = $dt->format('n/j/Y');
        $dateComparable = $dt->format('Y-m-d');
    }

    $receiptRowsForJs[] = [
        'name' => (string) ($row['student_name'] ?? ''),
        'grade' => (string) ($row['grade'] ?? ''),
        'lrn' => (string) ($row['lrn'] ?? ''),
        'date_display' => $dateDisplay,
        'date_compare' => $dateComparable,
        'booklet' => (string) ($row['booklet_label'] ?? ''),
        'receipt' => (string) ($row['receipt_no'] ?? ''),
        'print_url' => '/school-admin-dashboard/modules/accounts/accounts table/account-print.php?receipt_no=' . (int) ($row['receipt_no'] ?? 0) . '&booklet_no=' . (int) ($row['booklet_no'] ?? 0),
        'amount_cells' => $amountCells,
        'search_text' => strtolower(trim(implode(' ', [
            (string) ($row['student_name'] ?? ''),
            (string) ($row['grade'] ?? ''),
            (string) ($row['lrn'] ?? ''),
            $dateDisplay,
            (string) ($row['booklet_label'] ?? ''),
            (string) ($row['receipt_no'] ?? ''),
        ]))),
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invoice Compilation | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- SheetJS for Excel Export -->
    <script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body {
            background: var(--main-bg);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        }
        body.dark-mode {
            --main-bg: #1b232d;
            --card-bg: #23395d;
            --navbar-bg: #161b22;
            color: #e6edf3;
        }
        .navbar {
            background: var(--navbar-bg) !important;
            box-shadow: 0 2px 12px rgba(33,57,93,0.08);
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.08em;
        }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .theme-toggle-btn {
            background: none;
            border: none;
            color: #fff;
            font-size: 1.45em;
            margin-left: 12px;
            cursor: pointer;
        }
        .dashboard-header {
            text-align: center;
            margin-top: 36px;
            margin-bottom: 18px;
        }
        .dashboard-header img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            margin-bottom: 6px;
        }
        .dashboard-header h1 {
            font-size: 1.3rem;
            color: var(--brand-dark);
            font-weight: 700;
            margin-bottom: 0;
            letter-spacing: 0.02em;
        }
        th, td { text-align: center; vertical-align: middle; }
        th { background: #eaf4ff; }
        .table-responsive { font-size: 1rem; }
        .report-header {
            margin-bottom: 1.5rem;
            text-align: center;
        }
        .report-header h2 {
            font-weight: bold;
            margin-bottom: .4rem;
        }
        .action-bar {
            margin-bottom: 1rem;
            display: flex;
            gap: 1rem;
            align-items: center;
            flex-wrap: wrap;
            justify-content: flex-start;
        }
        .filter-actions {
            display: flex;
            gap: 0.5rem;
            align-items: center;
            flex-wrap: wrap;
        }
        @media (min-width: 768px) {
            .action-bar {
                justify-content: flex-end;
            }
        }
        .action-bar .form-control, .action-bar .form-select {
            max-width: 180px;
            display: inline-block;
        }
        .back-dashboard-btn {
            margin-left: auto;
        }
        .pagination-container {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 18px;
            gap: 4px;
        }
        .pagination .page-link {
            min-width: 36px;
            text-align: center;
        }
        @media print {
            .action-bar, .back-dashboard-btn, .pagination-container, .card-header, .navbar, .dashboard-header, .footer, .dashboard-btn-bottom { display: none !important; }
            .card { box-shadow: none !important; }
        }
        .dashboard-btn-bottom {
            position: fixed;
            left: 28px;
            bottom: 28px;
            z-index: 1060;
            background: #e7f0fd;
            color: #517fa4;
            border: 2px solid #bcdfff;
            box-shadow: 0 5px 16px rgba(33,57,93,0.13);
            border-radius: 50%;
            width: 58px;
            height: 58px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.55em;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
            text-decoration: none;
        }
        .dashboard-btn-bottom:hover, .dashboard-btn-bottom:focus {
            background: #fff2b3;
            color: #517fa4;
            border-color: #ffe599;
        }
    </style>
</head>
<body>
<?php render_admin_nav('invoice', true); ?>
<div class="dashboard-header">
    <img src="/school-admin-dashboard/uploads/logo1.png" alt="School Logo" class="mb-2 rounded shadow-sm">
    <h1><?= $schoolName ?></h1>
</div>
    <div class="container-fluid py-4">
        <div class="report-header">
            <h2><i class="fas fa-file-invoice"></i> Invoice Compilation</h2>
            <div class="lead text-muted">All Official Receipts - Compiled and Full Width View</div>
            <div><span class="badge bg-secondary mt-2"><i class="fas fa-calendar-alt"></i> <?= htmlspecialchars($selected_school_year) ?></span></div>
        </div>
        <div class="action-bar">
            <select class="form-select" id="schoolYearSelector" onchange="window.location='invoice-compilation.php?school_year=' + encodeURIComponent(this.value)">
                <?php foreach ($school_year_options as $option): ?>
                    <option value="<?= htmlspecialchars($option) ?>" <?= $selected_school_year === $option ? 'selected' : '' ?>>
                        <?= htmlspecialchars($option) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <input type="text" class="form-control" id="searchInput" placeholder="Quick Search">
            <select class="form-select" id="filterGrade">
                <option value="">All Grades</option>
                <?php foreach (array_keys($grades) as $grade): ?>
                    <option value="<?= htmlspecialchars($grade) ?>"><?= htmlspecialchars($grade) ?></option>
                <?php endforeach; ?>
            </select>
            <!-- Date Range -->
            <input type="date" class="form-control" id="filterDateStart" placeholder="Start Date">
            <span>-</span>
            <input type="date" class="form-control" id="filterDateEnd" placeholder="End Date">
            <!-- Booklet No -->
            <select class="form-select" id="filterBooklet">
                <option value="">All Booklet Nos</option>
                <?php foreach (array_keys($booklet_nos) as $bno): ?>
                    <option value="<?= htmlspecialchars($bno) ?>"><?= htmlspecialchars($bno) ?></option>
                <?php endforeach; ?>
            </select>
            <div class="filter-actions">
                <button class="btn btn-primary" type="button" id="applyFiltersBtn">
                    <i class="fas fa-filter"></i> Apply Filters
                </button>
                <button class="btn btn-outline-secondary" type="button" id="clearFiltersBtn">
                    <i class="fas fa-rotate-left"></i> Clear Filters
                </button>
            </div>
            <!-- Export to Excel Button -->
            <button class="btn btn-success" onclick="exportTableToExcel('invoiceTable', 'Invoice_Compilation')">
                <i class="fas fa-file-excel"></i> Export to Excel
            </button>
            <button class="btn btn-secondary" type="button" onclick="window.print()">
                <i class="fas fa-print"></i>
            </button>
            <a href="/school-admin-dashboard/dashboard.php" class="btn btn-primary back-dashboard-btn">
            </a>
        </div>
        <div class="alert alert-light border mb-3 py-2 px-3 small" id="printMeta">
            <strong>Print/Export Context:</strong>
            <span id="printMetaText">School Year: <?= htmlspecialchars($selected_school_year) ?> | Grade: All Grades | Booklet: All | Date Range: All Dates</span>
        </div>
        <div class="card shadow-sm">
            <div class="card-header bg-info text-light">
                <i class="fas fa-file-invoice"></i> Receipts Table
            </div>
            <div class="card-body table-responsive">
                <table class="table table-bordered table-hover align-middle" id="invoiceTable">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Grade</th>
                            <th>LRN</th>
                            <th>Date</th>
                            <th>Booklet No</th>
                            <th>Receipt No</th>
                            <th>Action</th>
                            <?php foreach ($account_types as $type_name): ?>
                                <th><?= htmlspecialchars($type_name) ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody id="invoiceTableBody">
                    <?php if (count($receipts)): ?>
                        <?php foreach ($page_keys as $rid): $row = $receipts[$rid]; ?>
                        <tr>
                            <td><?= htmlspecialchars($row['student_name']) ?></td>
                            <td><?= htmlspecialchars($row['grade']) ?></td>
                            <td><?= htmlspecialchars($row['lrn']) ?></td>
                            <td>
                                <?php
                                // Format date as M/D/YYYY
                                if (!empty($row['date_paid'])) {
                                    $dt = new DateTime($row['date_paid']);
                                    echo $dt->format('n/j/Y');
                                }
                                ?>
                            </td>
                            <td><?= htmlspecialchars($row['booklet_label']) ?></td>
                            <td><?= htmlspecialchars($row['receipt_no']) ?></td>
                            <td class="text-center">
                                <a href="/school-admin-dashboard/modules/accounts/accounts table/account-print.php?receipt_no=<?= (int) $row['receipt_no'] ?>&booklet_no=<?= (int) $row['booklet_no'] ?>" class="btn btn-sm btn-outline-primary" target="_blank">
                                    <i class="fas fa-print"></i>
                                </a>
                            </td>
                            <?php foreach ($account_types as $type_id => $type_name): ?>
                                <td>
                                    <?php
                                    if (isset($row['amounts'][$type_id])) {
                                        echo '&#8369;' . number_format($row['amounts'][$type_id], 2);
                                    } else {
                                        echo '';
                                    }
                                    ?>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="<?= 7 + count($account_types) ?>" class="text-center">No receipts found.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                <!-- Pagination Bar -->
                <div class="pagination-container">
                    <nav>
                        <ul class="pagination mb-0">
                        <?php if ($page > 1): ?>
                            <li class="page-item"><a class="page-link" href="?page=<?= $page-1 ?>">&#8592;</a></li>
                        <?php endif; ?>
                        <?php
                            $show_pages = [];
                            if ($total_pages <= 7) {
                                for ($i=1; $i<=$total_pages; $i++) $show_pages[] = $i;
                            } else {
                                $show_pages = [1, 2];
                                if ($page > 3) $show_pages[] = '...';
                                for ($i = max(3, $page-1); $i <= min($total_pages-2, $page+1); $i++) $show_pages[] = $i;
                                if ($page < $total_pages-2) $show_pages[] = '...';
                                $show_pages[] = $total_pages-1;
                                $show_pages[] = $total_pages;
                            }
                            foreach ($show_pages as $pg) {
                                if ($pg === '...') {
                                    echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                                } else {
                                    $active = ($pg == $page) ? ' active' : '';
                                    echo '<li class="page-item'.$active.'"><a class="page-link" href="?page='.$pg.'">'.$pg.'</a></li>';
                                }
                            }
                        ?>
                        <?php if ($page < $total_pages): ?>
                            <li class="page-item"><a class="page-link" href="?page=<?= $page+1 ?>">&#8594;</a></li>
                        <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <footer class="footer text-center py-4 text-muted small">
            &copy; <?= date("Y") ?> <?= $schoolName ?> | School Admin Dashboard
        </footer>
        <a href="/school-admin-dashboard/dashboard.php" class="dashboard-btn-bottom" title="Go to Dashboard">
            <i class="fas fa-tachometer-alt"></i>
        </a>
        <?php if (file_exists('../../includes/footer.php')) include '../../includes/footer.php'; ?>
    </div>
    <script>
    // Filters and pagination in JS for search/filter (initial page load is server-side paged)
    const allRowsData = <?= json_encode($receiptRowsForJs, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    const accountTypeLabels = <?= json_encode(array_values($account_types), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;

    let appliedFilters = {
        search: '',
        grade: '',
        booklet: '',
        dateStart: '',
        dateEnd: ''
    };

    function getCurrentInputFilters() {
        return {
            search: document.getElementById('searchInput').value.toLowerCase().trim(),
            grade: document.getElementById('filterGrade').value,
            booklet: document.getElementById('filterBooklet').value,
            dateStart: document.getElementById('filterDateStart').value || '',
            dateEnd: document.getElementById('filterDateEnd').value || ''
        };
    }

    function applyFilters(page = 1) {
        appliedFilters = getCurrentInputFilters();
        filterAndPaginate(page);
        updatePrintMeta();
    }

    function clearFilters() {
        document.getElementById('searchInput').value = '';
        document.getElementById('filterGrade').value = '';
        document.getElementById('filterBooklet').value = '';
        document.getElementById('filterDateStart').value = '';
        document.getElementById('filterDateEnd').value = '';
        appliedFilters = getCurrentInputFilters();
        filterAndPaginate(1);
        updatePrintMeta();
    }

    function filterAndPaginate(page=1) {
        let search = appliedFilters.search;
        let grade = appliedFilters.grade;
        let booklet = appliedFilters.booklet;
        let dateStart = appliedFilters.dateStart;
        let dateEnd = appliedFilters.dateEnd;

        // Filter rows
        let filtered = allRowsData.filter(row => {
            let show = true;
            if (search && !row.search_text.includes(search)) show = false;
            if (grade && row.grade !== grade) show = false;
            if (booklet && row.booklet !== booklet) show = false;
            if ((dateStart || dateEnd) && row.date_compare) {
                if (dateStart && row.date_compare < dateStart) show = false;
                if (dateEnd && row.date_compare > dateEnd) show = false;
            }
            return show;
        });

        // Pagination
        let total = filtered.length;
        let per_page = <?= $per_page ?>;
        let total_pages = Math.max(1, Math.ceil(total / per_page));
        page = Math.max(1, Math.min(page, total_pages));
        let start = (page-1)*per_page;
        let end = start+per_page;
        let paged = filtered.slice(start, end);

        // Render table
        let tbody = document.getElementById('invoiceTableBody');
        tbody.innerHTML = '';
        if (!paged.length) {
            const emptyRow = document.createElement('tr');
            emptyRow.innerHTML = `<td colspan="${7 + accountTypeLabels.length}" class="text-center">No receipts found.</td>`;
            tbody.appendChild(emptyRow);
        } else {
            paged.forEach(row => {
                const amountCellsHtml = row.amount_cells.map(cell => `<td>${cell.display || ''}</td>`).join('');
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${escapeHtml(row.name)}</td>
                    <td>${escapeHtml(row.grade)}</td>
                    <td>${escapeHtml(row.lrn)}</td>
                    <td>${escapeHtml(row.date_display)}</td>
                    <td>${escapeHtml(row.booklet)}</td>
                    <td>${escapeHtml(row.receipt)}</td>
                    <td class="text-center">
                        <a href="${encodeURI(row.print_url)}" class="btn btn-sm btn-outline-primary" target="_blank">
                            <i class="fas fa-print"></i>
                        </a>
                    </td>
                    ${amountCellsHtml}
                `;
                tbody.appendChild(tr);
            });
        }

        // Render pagination
        let pagin = document.querySelector('.pagination');
        if (pagin) {
            pagin.innerHTML = '';
            if (page > 1) {
                let prev = document.createElement('li');
                prev.className = 'page-item';
                prev.innerHTML = '<a class="page-link" href="#">&#8592;</a>';
                prev.onclick = e => { e.preventDefault(); filterAndPaginate(page-1); };
                pagin.appendChild(prev);
            }
            let show_pages = [];
            if (total_pages <= 7) {
                for (let i=1; i<=total_pages; i++) show_pages.push(i);
            } else {
                show_pages = [1,2];
                if (page > 3) show_pages.push('...');
                for (let i=Math.max(3,page-1); i<=Math.min(total_pages-2,page+1); i++) show_pages.push(i);
                if (page < total_pages-2) show_pages.push('...');
                show_pages.push(total_pages-1);
                show_pages.push(total_pages);
            }
            show_pages.forEach(pg => {
                if (pg === '...') {
                    let li = document.createElement('li');
                    li.className = 'page-item disabled';
                    li.innerHTML = '<span class="page-link">...</span>';
                    pagin.appendChild(li);
                } else {
                    let li = document.createElement('li');
                    li.className = 'page-item' + (pg == page ? ' active' : '');
                    li.innerHTML = `<a class="page-link" href="#">${pg}</a>`;
                    li.onclick = e => { e.preventDefault(); filterAndPaginate(pg); };
                    pagin.appendChild(li);
                }
            });
            if (page < total_pages) {
                let next = document.createElement('li');
                next.className = 'page-item';
                next.innerHTML = '<a class="page-link" href="#">&#8594;</a>';
                next.onclick = e => { e.preventDefault(); filterAndPaginate(page+1); };
                pagin.appendChild(next);
            }
        }
    }

    document.getElementById('applyFiltersBtn').addEventListener('click', function(){ applyFilters(1); });
    document.getElementById('clearFiltersBtn').addEventListener('click', function(){ clearFilters(); });
    document.getElementById('searchInput').addEventListener('keydown', function(event){
        if (event.key === 'Enter') {
            event.preventDefault();
            applyFilters(1);
        }
    });

    function sanitizeFilenamePart(value) {
        return String(value || 'all').trim().replace(/[^a-z0-9]+/gi, '_').replace(/^_+|_+$/g, '') || 'all';
    }

    function auditExportDownload(label, fileName, details) {
        const formData = new FormData();
        formData.append('csrf_token', <?= json_encode($csrfToken) ?>);
        formData.append('action_kind', 'export_download');
        formData.append('label', label);
        formData.append('file_name', fileName);
        formData.append('details', details || '');

        if (navigator.sendBeacon) {
            navigator.sendBeacon('/school-admin-dashboard/modules/audit/audit-client-event.php', formData);
            return;
        }

        fetch('/school-admin-dashboard/modules/audit/audit-client-event.php', {
            method: 'POST',
            body: formData,
            credentials: 'same-origin',
            keepalive: true
        }).catch(function () {});
    }

    // Export to Excel using SheetJS (filtered rows with cleaner column sizing and text-safe IDs)
    function exportTableToExcel(tableID, filename = ''){
        const schoolYear = document.getElementById('schoolYearSelector').value || 'all';
        const grade = appliedFilters.grade || 'All Grades';
        const booklet = appliedFilters.booklet || 'All';
        const dateStart = appliedFilters.dateStart || '';
        const dateEnd = appliedFilters.dateEnd || '';
        const dateLabel = (dateStart || dateEnd) ? `${dateStart || '...'} to ${dateEnd || '...'}` : 'All Dates';

        let filtered = allRowsData.filter(row => {
            let show = true;
            const search = appliedFilters.search;
            if (search && !row.search_text.includes(search)) show = false;
            if (appliedFilters.grade && row.grade !== appliedFilters.grade) show = false;
            if (appliedFilters.booklet && row.booklet !== appliedFilters.booklet) show = false;
            if ((dateStart || dateEnd) && row.date_compare) {
                if (dateStart && row.date_compare < dateStart) show = false;
                if (dateEnd && row.date_compare > dateEnd) show = false;
            }
            return show;
        });

        const exportData = [
            ['Invoice Compilation'],
            ['School Year', schoolYear],
            ['Grade', grade],
            ['Booklet', booklet],
            ['Date Range', dateLabel],
            ['Prepared By', <?= json_encode($username !== '' ? $username : 'System User') ?>],
            ['Generated On', <?= json_encode(date('F j, Y g:i A')) ?>],
            [],
            ['Name', 'Grade', 'LRN', 'Date', 'Booklet No', 'Receipt No', ...Array.from(document.querySelectorAll('#invoiceTable thead th')).slice(7).map(th => th.textContent.trim())]
        ];

        filtered.forEach(row => exportData.push([
            String(row.name || ''),
            String(row.grade || ''),
            String(row.lrn || ''),
            String(row.date_display || ''),
            String(row.booklet || ''),
            String(row.receipt || ''),
            ...row.amount_cells.map(cell => String(cell.export || ''))
        ]));
        if (!filtered.length) {
            exportData.push(['No invoice records match the selected filters.']);
        }

        const worksheet = XLSX.utils.aoa_to_sheet(exportData);
        const lastColumnIndex = exportData[8].length - 1;
        const lastColumnLetter = XLSX.utils.encode_col(lastColumnIndex);
        worksheet['!cols'] = [
            { wch: 32 },
            { wch: 12 },
            { wch: 18 },
            { wch: 14 },
            { wch: 16 },
            { wch: 16 },
            ...Array(Math.max(0, exportData[8].length - 6)).fill({ wch: 16 })
        ];
        worksheet['!autofilter'] = { ref: `A9:${lastColumnLetter}9` };

        for (let rowIndex = 9; rowIndex < exportData.length; rowIndex += 1) {
            const lrnCell = XLSX.utils.encode_cell({ r: rowIndex, c: 2 });
            if (worksheet[lrnCell]) {
                worksheet[lrnCell].t = 's';
                worksheet[lrnCell].z = '@';
            }
            const receiptCell = XLSX.utils.encode_cell({ r: rowIndex, c: 5 });
            if (worksheet[receiptCell]) {
                worksheet[receiptCell].t = 's';
                worksheet[receiptCell].z = '@';
            }
        }

        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, worksheet, 'Invoice Compilation');
        const exportFileName = `invoice_compilation_${sanitizeFilenamePart(schoolYear)}_${sanitizeFilenamePart(appliedFilters.grade || 'all')}.xlsx`;
        auditExportDownload(
            'Invoice Compilation Excel',
            exportFileName,
            `School Year: ${schoolYear} | Grade: ${grade} | Booklet: ${booklet} | Date Range: ${dateLabel} | Search: ${appliedFilters.search || 'All'}`
        );
        return XLSX.writeFile(wb, exportFileName);
    }

    function updatePrintMeta() {
        const schoolYear = document.getElementById('schoolYearSelector').value || 'All';
        const grade = appliedFilters.grade || 'All Grades';
        const booklet = appliedFilters.booklet || 'All';
        const dateStart = appliedFilters.dateStart || '';
        const dateEnd = appliedFilters.dateEnd || '';
        const dateLabel = (dateStart || dateEnd) ? `${dateStart || '...'} to ${dateEnd || '...'}` : 'All Dates';
        const searchLabel = appliedFilters.search ? appliedFilters.search : 'All';
        document.getElementById('printMetaText').textContent = `School Year: ${schoolYear} | Grade: ${grade} | Booklet: ${booklet} | Date Range: ${dateLabel} | Search: ${searchLabel}`;
    }

    // On page load, enable full client-side filtering/pagination if JS is available
    function escapeHtml(value) {
        return String(value || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    window.onload = function() {
        appliedFilters = getCurrentInputFilters();
        filterAndPaginate(1);
        updatePrintMeta();
    };

    // Theme toggle
    document.getElementById('themeToggleBtn').addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        this.querySelector('i').classList.toggle('fa-moon');
        this.querySelector('i').classList.toggle('fa-sun');
    });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>


