<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/reports-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Cell\DataType;

if (!hasPermission($_SESSION['role'] ?? '', 'reports', 'view')) {
    $blockedRole = (string) ($_SESSION['role'] ?? '');
    $blockedUser = (string) ($_SESSION['username'] ?? 'unknown');
    if (!isset($conn) || !($conn instanceof mysqli)) {
        $conn = database_open_connection();
    }
    audit_log(
        $conn,
        $blockedUser,
        'Blocked finance report export access',
        'Reports',
        'Role: ' . ($blockedRole !== '' ? $blockedRole : 'unknown') . ' | Reason: missing reports:view permission',
        'SECURITY'
    );
    admin_session_forbidden();
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    $conn = database_open_connection();
}

$schoolYears = reports_school_year_options($conn);
$selectedSchoolYear = trim((string) ($_GET['school_year'] ?? school_year_get_active_label($conn)));
$dateFrom = trim((string) ($_GET['date_from'] ?? ''));
$dateTo = trim((string) ($_GET['date_to'] ?? ''));
$studentNameFilter = trim((string) ($_GET['student_name'] ?? ''));
$studentLrnFilter = trim((string) ($_GET['student_lrn'] ?? ''));

$summary = reports_finance_summary($conn, $selectedSchoolYear, $dateFrom, $dateTo, $studentNameFilter, $studentLrnFilter);
$outstandingRows = reports_finance_outstanding_rows($conn, $selectedSchoolYear, $studentNameFilter, $studentLrnFilter, 5000);
$recentPayments = reports_finance_recent_payments($conn, $selectedSchoolYear, $dateFrom, $dateTo, $studentNameFilter, $studentLrnFilter, 5000);

if ($recentPayments && !array_key_exists('items_count', $recentPayments[0])) {
    $grouped = [];
    foreach ($recentPayments as $row) {
        $bookletNo = (string) ($row['booklet_no'] ?? '');
        $receiptNo = (string) ($row['receipt_no'] ?? '');
        $groupKey = ($bookletNo !== '' && $receiptNo !== '') ? ($bookletNo . '-' . $receiptNo) : ('noreceipt-' . ($row['date_paid'] ?? '') . '-' . ($row['student_id'] ?? ''));
        if (!isset($grouped[$groupKey])) {
            $grouped[$groupKey] = $row;
            $grouped[$groupKey]['items'] = [];
            $grouped[$groupKey]['items_count'] = 0;
            $grouped[$groupKey]['total_amount'] = 0.0;
        }
        $grouped[$groupKey]['items'][] = [
            'fee_type' => (string) ($row['fee_type'] ?? 'Uncategorized'),
            'amount' => (float) ($row['amount'] ?? 0),
        ];
        $grouped[$groupKey]['items_count']++;
        $grouped[$groupKey]['total_amount'] += (float) ($row['amount'] ?? 0);
    }
    $recentPayments = array_values($grouped);
}

function reports_export_base_style($sheet, string $endColumn, int $lastRow): void
{
    $sheet->getStyle("A1:{$endColumn}{$lastRow}")->getFont()->setName('Arial')->setSize(11);
    $sheet->getStyle("A1:{$endColumn}1")->getFont()->setBold(true)->setSize(14);
    $sheet->getStyle("A4:{$endColumn}4")->getFont()->setBold(true);
    $sheet->getStyle("A4:{$endColumn}4")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('DCEAF7');
    $sheet->getStyle("A4:{$endColumn}{$lastRow}")->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN)->getColor()->setRGB('C7D0D9');
    $sheet->getStyle("A1:{$endColumn}{$lastRow}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
    foreach (range('A', $endColumn) as $col) {
        $sheet->getColumnDimension($col)->setAutoSize(true);
    }
}

$spreadsheet = new Spreadsheet();

$summarySheet = $spreadsheet->getActiveSheet();
$summarySheet->setTitle('Finance Summary');
$summarySheet->setCellValue('A1', 'Finance Summary Report');
$summarySheet->setCellValue('A2', 'School Year: ' . ($selectedSchoolYear !== '' ? $selectedSchoolYear : 'All School Years'));
$summarySheet->setCellValue('A3', 'As Of: ' . reports_as_of_label());
$summarySheet->setCellValue('A4', 'Metric');
$summarySheet->setCellValue('B4', 'Value');

$summaryRows = [
    ['Unpaid Students', (int) ($summary['unpaid_students'] ?? 0)],
    ['Outstanding Balance', (float) ($summary['outstanding_balance'] ?? 0)],
    ['Recorded Payments', (int) ($summary['recorded_payments'] ?? 0)],
    ['Collections Total', (float) ($summary['collections_total'] ?? 0)],
    ['Old Accounts', (int) ($summary['old_account_count'] ?? 0)],
    ['Old Collections', (float) ($summary['old_collections_total'] ?? 0)],
];
$row = 5;
foreach ($summaryRows as [$label, $value]) {
    $summarySheet->setCellValue("A{$row}", $label);
    $summarySheet->setCellValue("B{$row}", $value);
    $row++;
}
$summarySheet->setCellValue("D1", 'Active Filters');
$summarySheet->setCellValue("D2", 'Student Name');
$summarySheet->setCellValue("E2", $studentNameFilter !== '' ? $studentNameFilter : 'All');
$summarySheet->setCellValue("D3", 'LRN');
if ($studentLrnFilter !== '') {
    $summarySheet->setCellValueExplicit("E3", $studentLrnFilter, DataType::TYPE_STRING);
    $summarySheet->getStyle('E3')->getNumberFormat()->setFormatCode('@');
} else {
    $summarySheet->setCellValue("E3", 'All');
}
$summarySheet->setCellValue("D4", 'Date Coverage');
$summarySheet->setCellValue("E4", ($dateFrom !== '' || $dateTo !== '') ? (($dateFrom !== '' ? $dateFrom : 'Start Open') . ' to ' . ($dateTo !== '' ? $dateTo : 'Present')) : 'All recorded dates');
$summarySheet->getStyle("B5:B10")->getNumberFormat()->setFormatCode('#,##0.00');
reports_export_base_style($summarySheet, 'E', 10);

$outstandingSheet = $spreadsheet->createSheet();
$outstandingSheet->setTitle('Outstanding Balances');
$outstandingSheet->fromArray(
    ['Student', 'Grade', 'Section', 'Outstanding Balance', 'Priority'],
    null,
    'A1'
);
$row = 2;
foreach ($outstandingRows as $item) {
    $amount = (float) ($item['outstanding_balance'] ?? 0);
    $priority = $amount >= 10000 ? 'High Priority' : ($amount >= 5000 ? 'Medium Priority' : 'Routine Follow-up');
    $outstandingSheet->setCellValue("A{$row}", (string) ($item['student_name'] ?? ''));
    $outstandingSheet->setCellValue("B{$row}", (string) ($item['grade'] ?? ''));
    $outstandingSheet->setCellValue("C{$row}", (string) ($item['section'] ?? ''));
    $outstandingSheet->setCellValue("D{$row}", $amount);
    $outstandingSheet->setCellValue("E{$row}", $priority);
    $row++;
}
$outstandingSheet->getStyle("D2:D{$row}")->getNumberFormat()->setFormatCode('#,##0.00');
reports_export_base_style($outstandingSheet, 'E', max(2, $row - 1));

$paymentsSheet = $spreadsheet->createSheet();
$paymentsSheet->setTitle('Recent Payments');
$paymentsSheet->fromArray(
    ['Date Paid', 'Student', 'LRN', 'Fee Summary', 'Item Count', 'Total Amount', 'Booklet No', 'Receipt No'],
    null,
    'A1'
);
$row = 2;
foreach ($recentPayments as $payment) {
    $paymentsSheet->setCellValue("A{$row}", (string) ($payment['date_paid'] ?? ''));
    $paymentsSheet->setCellValue("B{$row}", (string) ($payment['student_name'] ?? ''));
    $paymentsSheet->setCellValueExplicit("C{$row}", (string) ($payment['lrn'] ?? ''), DataType::TYPE_STRING);
    $paymentsSheet->setCellValue("D{$row}", (string) ($payment['fee_type'] ?? (($payment['items_count'] ?? 0) > 1 ? 'Multiple Items' : '')));
    $paymentsSheet->setCellValue("E{$row}", (int) ($payment['items_count'] ?? 0));
    $paymentsSheet->setCellValue("F{$row}", (float) ($payment['total_amount'] ?? 0));
    $paymentsSheet->setCellValue("G{$row}", (string) ($payment['booklet_no'] ?? ''));
    $paymentsSheet->setCellValue("H{$row}", (string) ($payment['receipt_no'] ?? ''));
    $row++;
}
$paymentsSheet->getStyle("C2:C{$row}")->getNumberFormat()->setFormatCode('@');
$paymentsSheet->getStyle("F2:F{$row}")->getNumberFormat()->setFormatCode('#,##0.00');
reports_export_base_style($paymentsSheet, 'H', max(2, $row - 1));

$filename = 'finance_report_' . preg_replace('/[^A-Za-z0-9_-]+/', '_', $selectedSchoolYear !== '' ? $selectedSchoolYear : 'all') . '.xlsx';

while (ob_get_level() > 0) {
    ob_end_clean();
}
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="' . $filename . '"');
header('Cache-Control: max-age=0');
header('Pragma: public');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
