<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/reports-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;

if (!isset($conn) || !($conn instanceof mysqli)) {
    $conn = database_open_connection();
}

if (!can_export_academic_reports((string) ($_SESSION['role'] ?? ''))) {
    $blockedRole = (string) ($_SESSION['role'] ?? '');
    $blockedUser = (string) ($_SESSION['username'] ?? 'unknown');
    audit_log(
        $conn,
        $blockedUser,
        'Blocked academic report export access',
        'Reports',
        'Role: ' . ($blockedRole !== '' ? $blockedRole : 'unknown') . ' | Reason: academic report export denied',
        'SECURITY'
    );
    admin_session_forbidden();
}

$selectedSchoolYear = trim((string) ($_GET['school_year'] ?? school_year_get_active_label($conn)));
$selectedGradeLevel = trim((string) ($_GET['grade_level'] ?? ''));
$summary = reports_academic_summary($conn, $selectedSchoolYear, $selectedGradeLevel);
$gradeRows = reports_academic_grade_rows($conn, $selectedSchoolYear, $selectedGradeLevel);
$missingLrnRows = reports_academic_missing_rows($conn, $selectedSchoolYear, $selectedGradeLevel, 'lrn', 5000);
$missingSectionRows = reports_academic_missing_rows($conn, $selectedSchoolYear, $selectedGradeLevel, 'section', 5000);
$incompleteRequirementRows = reports_academic_incomplete_requirements($conn, $selectedSchoolYear, $selectedGradeLevel, 5000);

function reports_export_academic_style($sheet, string $endColumn, int $lastRow): void
{
    $sheet->getStyle("A1:{$endColumn}{$lastRow}")->getFont()->setName('Arial')->setSize(11);
    $sheet->getStyle("A1:{$endColumn}1")->getFont()->setBold(true)->setSize(14);
    $sheet->getStyle("A4:{$endColumn}4")->getFont()->setBold(true);
    $sheet->getStyle("A4:{$endColumn}4")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('DCEAF7');
    $sheet->getStyle("A4:{$endColumn}{$lastRow}")->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN)->getColor()->setRGB('C7D0D9');
    $sheet->getStyle("A1:{$endColumn}{$lastRow}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
    foreach (range('A', $endColumn) as $col) {
        $sheet->getColumnDimension($col)->setAutoSize(true);
    }
}

$spreadsheet = new Spreadsheet();
$summarySheet = $spreadsheet->getActiveSheet();
$summarySheet->setTitle('Registrar Summary');
$summarySheet->setCellValue('A1', 'Registrar Summary Report');
$summarySheet->setCellValue('A2', 'School Year: ' . ($selectedSchoolYear !== '' ? $selectedSchoolYear : 'All School Years'));
$summarySheet->setCellValue('A3', 'Grade Level: ' . ($selectedGradeLevel !== '' ? $selectedGradeLevel : 'All Grades'));
$summarySheet->setCellValue('A4', 'As Of: ' . reports_as_of_label());
$summarySheet->setCellValue('A5', 'Metric');
$summarySheet->setCellValue('B5', 'Value');

$rows = [
    ['Students', (int) ($summary['total_students'] ?? 0)],
    ['Pending Registrations', (int) ($summary['pending_registrations'] ?? 0)],
    ['Missing LRN', (int) ($summary['missing_lrn'] ?? 0)],
    ['Missing Section', (int) ($summary['missing_section'] ?? 0)],
    ['Incomplete Requirements', (int) ($summary['incomplete_requirements'] ?? 0)],
];
$row = 6;
foreach ($rows as [$label, $value]) {
    $summarySheet->setCellValue("A{$row}", $label);
    $summarySheet->setCellValue("B{$row}", $value);
    $row++;
}
reports_export_academic_style($summarySheet, 'B', $row - 1);

$gradeSheet = $spreadsheet->createSheet();
$gradeSheet->setTitle('Enrollment By Grade');
$gradeSheet->fromArray(['Grade', 'Total Students'], null, 'A1');
$row = 2;
foreach ($gradeRows as $item) {
    $gradeSheet->setCellValue("A{$row}", (string) ($item['grade'] ?? ''));
    $gradeSheet->setCellValue("B{$row}", (int) ($item['total_students'] ?? 0));
    $row++;
}
reports_export_academic_style($gradeSheet, 'B', max(2, $row - 1));

$missingLrnSheet = $spreadsheet->createSheet();
$missingLrnSheet->setTitle('Missing LRN');
$missingLrnSheet->fromArray(['Student', 'Grade', 'Strand', 'Section'], null, 'A1');
$row = 2;
foreach ($missingLrnRows as $item) {
    $missingLrnSheet->setCellValue("A{$row}", trim(($item['lastname'] ?? '') . ', ' . ($item['firstname'] ?? '') . ' ' . ($item['middlename'] ?? '')));
    $missingLrnSheet->setCellValue("B{$row}", (string) ($item['grade'] ?? ''));
    $missingLrnSheet->setCellValue("C{$row}", (string) (($item['strand'] ?? '') !== '' ? $item['strand'] : 'N/A'));
    $missingLrnSheet->setCellValue("D{$row}", (string) ($item['section'] ?? ''));
    $row++;
}
reports_export_academic_style($missingLrnSheet, 'D', max(2, $row - 1));

$missingSectionSheet = $spreadsheet->createSheet();
$missingSectionSheet->setTitle('Missing Section');
$missingSectionSheet->fromArray(['Student', 'Grade', 'Strand', 'LRN'], null, 'A1');
$row = 2;
foreach ($missingSectionRows as $item) {
    $missingSectionSheet->setCellValue("A{$row}", trim(($item['lastname'] ?? '') . ', ' . ($item['firstname'] ?? '') . ' ' . ($item['middlename'] ?? '')));
    $missingSectionSheet->setCellValue("B{$row}", (string) ($item['grade'] ?? ''));
    $missingSectionSheet->setCellValue("C{$row}", (string) (($item['strand'] ?? '') !== '' ? $item['strand'] : 'N/A'));
    $missingSectionSheet->setCellValue("D{$row}", (string) (($item['lrn'] ?? '') !== '' ? $item['lrn'] : 'Not Set'));
    $row++;
}
reports_export_academic_style($missingSectionSheet, 'D', max(2, $row - 1));

$requirementsSheet = $spreadsheet->createSheet();
$requirementsSheet->setTitle('Incomplete Requirements');
$requirementsSheet->fromArray(['Student', 'Grade', 'Strand', 'Section', 'Submitted', 'Missing', 'To Follow'], null, 'A1');
$row = 2;
foreach ($incompleteRequirementRows as $item) {
    $req = $item['requirement_summary'] ?? ['submitted' => 0, 'missing' => 0, 'to_follow' => 0];
    $requirementsSheet->setCellValue("A{$row}", trim(($item['lastname'] ?? '') . ', ' . ($item['firstname'] ?? '') . ' ' . ($item['middlename'] ?? '')));
    $requirementsSheet->setCellValue("B{$row}", (string) ($item['grade'] ?? ''));
    $requirementsSheet->setCellValue("C{$row}", (string) (($item['strand'] ?? '') !== '' ? $item['strand'] : 'N/A'));
    $requirementsSheet->setCellValue("D{$row}", (string) ($item['section'] ?? ''));
    $requirementsSheet->setCellValue("E{$row}", (int) ($req['submitted'] ?? 0));
    $requirementsSheet->setCellValue("F{$row}", (int) ($req['missing'] ?? 0));
    $requirementsSheet->setCellValue("G{$row}", (int) ($req['to_follow'] ?? 0));
    $row++;
}
reports_export_academic_style($requirementsSheet, 'G', max(2, $row - 1));

$filename = 'registrar_report_' . preg_replace('/[^A-Za-z0-9_-]+/', '_', $selectedSchoolYear !== '' ? $selectedSchoolYear : 'all') . '.xlsx';
while (ob_get_level() > 0) {
    ob_end_clean();
}
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="' . $filename . '"');
header('Cache-Control: max-age=0');
header('Pragma: public');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
