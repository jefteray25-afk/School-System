<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require_once __DIR__ . '/../../includes/ui.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../settings/school-info-helper.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/reports-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

if (!can_access_reports_dashboard((string) ($_SESSION['role'] ?? ''))) {
    $blockedRole = (string) ($_SESSION['role'] ?? '');
    $blockedUser = (string) ($_SESSION['username'] ?? 'unknown');
    audit_log(
        $conn,
        $blockedUser,
        'Blocked reports dashboard access',
        'Reports',
        'Role: ' . ($blockedRole !== '' ? $blockedRole : 'unknown') . ' | Reason: missing reports:view permission',
        'SECURITY'
    );
    admin_session_forbidden();
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    $conn = database_open_connection();
}

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$currentRole = (string) ($_SESSION['role'] ?? '');
$isLimitedAdminOperator = is_limited_admin_operator_role($currentRole);
$isAccountingStaff = is_accounting_staff_role($currentRole);
$reportAsOf = reports_as_of_label();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports Center | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <?php ui_css_link(); ?>
    <style>
        body { background:#f5f8fc; font-family:'Segoe UI','Roboto','Arial',sans-serif; color:#23395d; }
        .navbar { background:#23395d !important; }
        .navbar-brand, .navbar-nav .nav-link { color:#fff !important; }
        .dashboard-header { text-align:center; margin-top:36px; margin-bottom:18px; }
        .dashboard-header img { width:70px; height:70px; object-fit:contain; margin-bottom:6px; }
        .dashboard-header h1 { font-size:1.3rem; color:#23395d; font-weight:700; margin-bottom:0; }
        .page-wrap { max-width:1150px; margin:0 auto; padding:0 12px 32px; }
        .intro-board, .report-card {
            background:#fff;
            border:1px solid #dbe7f4;
            border-radius:18px;
            box-shadow:0 8px 22px rgba(35,57,93,.06);
        }
        .intro-board { padding:18px 20px; margin-bottom:18px; }
        .board-label { font-size:.78rem; text-transform:uppercase; letter-spacing:.08em; color:#607388; font-weight:700; }
        .board-value { font-size:1.08rem; font-weight:700; color:#23395d; }
        .report-card { height:100%; padding:20px; text-decoration:none; color:inherit; display:block; }
        .report-card:hover { border-color:#517fa4; box-shadow:0 10px 24px rgba(35,57,93,.09); }
        .report-icon { width:48px; height:48px; border-radius:14px; background:#eef4fb; color:#517fa4; display:flex; align-items:center; justify-content:center; font-size:1.2rem; margin-bottom:12px; }
        .report-title { font-size:1.08rem; font-weight:700; color:#23395d; margin-bottom:6px; }
        .report-note { color:#607388; font-size:.93rem; margin:0; }
        .report-tag { display:inline-flex; align-items:center; border-radius:999px; padding:4px 10px; background:#edf4fb; color:#23395d; border:1px solid #d9e3ef; font-size:.78rem; font-weight:700; margin-bottom:10px; }
        .context-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:12px; margin-top:16px; }
        .context-item { background:#f8fbff; border:1px solid #dbe7f4; border-radius:14px; padding:12px 14px; }
        .context-label { font-size:.74rem; text-transform:uppercase; letter-spacing:.06em; color:#607388; font-weight:700; }
        .context-value { font-size:.98rem; font-weight:700; color:#23395d; margin-top:4px; }
    </style>
</head>
<body>
<?php render_admin_nav('reports'); ?>
<?php render_school_page_header($schoolName, $schoolLogo); ?>

<div class="page-wrap app-page">
    <div class="intro-board">
        <div class="board-label">Reports Center</div>
        <div class="board-value"><?= $isAccountingStaff ? 'Open only the finance-side reports that matter for collection, balances, and payment review.' : 'Open a consolidated view for one student, finance summaries, or academic summaries without jumping across multiple modules.' ?></div>
        <div class="context-grid">
            <div class="context-item">
                <div class="context-label">As Of</div>
                <div class="context-value"><?= htmlspecialchars($reportAsOf) ?></div>
            </div>
            <div class="context-item">
                <div class="context-label">Access Scope</div>
                <div class="context-value"><?= $isAccountingStaff ? 'Finance reports only' : ($isLimitedAdminOperator ? 'Finance and student-level reports' : 'Full reports center access') ?></div>
            </div>
            <div class="context-item">
                <div class="context-label">Report Mode</div>
                <div class="context-value">Open a report, then apply filters inside the selected page.</div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <?php if (!$isAccountingStaff): ?>
        <div class="col-12 col-md-6 col-lg-4">
            <a href="/school-admin-dashboard/modules/reports/reports-student-summary.php" class="report-card">
                <div class="report-icon"><i class="fas fa-user-graduate"></i></div>
                <div class="report-tag">Student Report</div>
                <div class="report-title">Student Summary Report</div>
                <p class="report-note">One-student summary with profile, requirements, account balances, and recent payments.</p>
            </a>
        </div>
        <?php endif; ?>
        <div class="col-12 col-md-6 col-lg-4">
            <a href="/school-admin-dashboard/modules/reports/reports-finance.php" class="report-card">
                <div class="report-icon"><i class="fas fa-coins"></i></div>
                <div class="report-tag">Finance Report</div>
                <div class="report-title">Finance Summary Report</div>
                <p class="report-note">Outstanding balances, collections totals, and recent payment activity in one place.</p>
            </a>
        </div>
        <?php if (can_access_academic_reports($currentRole)): ?>
        <div class="col-12 col-md-6 col-lg-4">
            <a href="/school-admin-dashboard/modules/reports/reports-academic.php" class="report-card">
                <div class="report-icon"><i class="fas fa-school"></i></div>
                <div class="report-tag">Registrar Report</div>
                <div class="report-title">Registrar Summary Report</div>
                <p class="report-note">Enrollment by grade, missing LRN or section, pending registrations, and requirement follow-up.</p>
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
<?php $conn->close(); ?>
