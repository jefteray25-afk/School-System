<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../settings/school-info-helper.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/reports-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

if (!isset($conn) || !($conn instanceof mysqli)) {
    $conn = database_open_connection();
}

if (!can_access_academic_reports((string) ($_SESSION['role'] ?? ''))) {
    $blockedRole = (string) ($_SESSION['role'] ?? '');
    $blockedUser = (string) ($_SESSION['username'] ?? 'unknown');
    audit_log(
        $conn,
        $blockedUser,
        'Blocked academic reports access',
        'Reports',
        'Role: ' . ($blockedRole !== '' ? $blockedRole : 'unknown') . ' | Reason: academic reports access denied',
        'SECURITY'
    );
    admin_session_forbidden();
}

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$schoolYears = reports_school_year_options($conn);
$selectedSchoolYear = trim((string) ($_GET['school_year'] ?? school_year_get_active_label($conn)));
$selectedGradeLevel = trim((string) ($_GET['grade_level'] ?? ''));
$gradeOptions = reports_academic_grade_options($conn, $selectedSchoolYear);
$reportAsOf = reports_as_of_label();

$summary = reports_academic_summary($conn, $selectedSchoolYear, $selectedGradeLevel);
$gradeRows = reports_academic_grade_rows($conn, $selectedSchoolYear, $selectedGradeLevel);
$missingLrnRows = reports_academic_missing_rows($conn, $selectedSchoolYear, $selectedGradeLevel, 'lrn', 15);
$missingSectionRows = reports_academic_missing_rows($conn, $selectedSchoolYear, $selectedGradeLevel, 'section', 15);
$incompleteRequirementRows = reports_academic_incomplete_requirements($conn, $selectedSchoolYear, $selectedGradeLevel, 25);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Reports | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background:#f5f8fc; font-family:'Segoe UI','Roboto','Arial',sans-serif; color:#23395d; }
        .navbar { background:#23395d !important; }
        .navbar-brand, .navbar-nav .nav-link { color:#fff !important; }
        .dashboard-header { text-align:center; margin-top:36px; margin-bottom:18px; }
        .dashboard-header img { width:70px; height:70px; object-fit:contain; margin-bottom:6px; }
        .dashboard-header h1 { font-size:1.3rem; color:#23395d; font-weight:700; margin-bottom:0; }
        .page-wrap { max-width:1180px; margin:0 auto; padding:0 12px 32px; }
        .panel, .summary-card, .table-card { background:#fff; border:1px solid #dbe7f4; border-radius:18px; box-shadow:0 8px 22px rgba(35,57,93,.06); }
        .panel, .table-card { padding:18px; }
        .summary-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:14px; margin-bottom:18px; }
        .summary-card { padding:14px 16px; }
        .summary-label { font-size:.76rem; text-transform:uppercase; letter-spacing:.06em; color:#607388; font-weight:700; }
        .summary-value { font-size:1.15rem; font-weight:800; color:#23395d; }
        .table-card table { margin-bottom:0; }
        .context-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:12px; margin-top:16px; }
        .context-item { background:#f8fbff; border:1px solid #dbe7f4; border-radius:14px; padding:12px 14px; }
        .context-label { font-size:.74rem; text-transform:uppercase; letter-spacing:.06em; color:#607388; font-weight:700; }
        .context-value { font-size:.98rem; font-weight:700; color:#23395d; margin-top:4px; }
        .section-note { color:#607388; font-size:.88rem; }
        .print-btn { white-space:nowrap; }
        @media print {
            body { background:#fff !important; color:#000 !important; font-size:12px; }
            .navbar, .dashboard-header, .btn, form, .print-hidden { display:none !important; }
            .page-wrap { max-width:none; margin:0; padding:0; }
            .panel, .summary-card, .table-card, .context-item {
                box-shadow:none !important;
                border:1px solid #d0d7de !important;
                break-inside: avoid;
            }
            .summary-grid { gap:10px; }
            .table-card { margin-bottom:14px; }
            a { color:#000 !important; text-decoration:none !important; }
        }
    </style>
</head>
<body>
<?php render_admin_nav('reports'); ?>
<?php render_school_page_header($schoolName, $schoolLogo); ?>

<div class="page-wrap">
    <div class="panel mb-3">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">
            <div>
                <h2 class="h4 mb-1"><i class="fas fa-school me-2"></i>Registrar Reports</h2>
                <div class="text-muted">Review enrollment spread, missing student data, pending registrations, and incomplete requirements.</div>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <a href="/school-admin-dashboard/modules/students/student-list.php?school_year=<?= rawurlencode($selectedSchoolYear) ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Back to Registrar Workspace
                </a>
                <a href="/school-admin-dashboard/modules/reports/export-reports-academic.php?school_year=<?= rawurlencode($selectedSchoolYear) ?>&grade_level=<?= rawurlencode($selectedGradeLevel) ?>" class="btn btn-success">
                    <i class="fas fa-file-excel me-1"></i>Download Excel
                </a>
                <button type="button" class="btn btn-outline-dark print-btn" onclick="window.print()">
                    <i class="fas fa-print me-1"></i>Print Report
                </button>
            </div>
        </div>
        <div class="context-grid">
            <div class="context-item">
                <div class="context-label">School Year</div>
                <div class="context-value"><?= htmlspecialchars($selectedSchoolYear !== '' ? $selectedSchoolYear : 'All School Years') ?></div>
            </div>
            <div class="context-item">
                <div class="context-label">As Of</div>
                <div class="context-value"><?= htmlspecialchars($reportAsOf) ?></div>
            </div>
            <div class="context-item">
                <div class="context-label">Coverage</div>
                <div class="context-value">Enrollment, missing student data, pending registrations, and requirement follow-up.</div>
            </div>
            <div class="context-item">
                <div class="context-label">Grade Level</div>
                <div class="context-value"><?= htmlspecialchars($selectedGradeLevel !== '' ? $selectedGradeLevel : 'All Grades') ?></div>
            </div>
        </div>
        <form method="get" class="row g-3 mt-1">
            <div class="col-12 col-md-4">
                <label class="form-label">School year</label>
                <select name="school_year" class="form-select">
                    <option value="">All</option>
                    <?php foreach ($schoolYears as $option): ?>
                        <option value="<?= htmlspecialchars($option) ?>" <?= $selectedSchoolYear === $option ? 'selected' : '' ?>><?= htmlspecialchars($option) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 col-md-4">
                <label class="form-label">Grade level</label>
                <select name="grade_level" class="form-select">
                    <option value="">All Grades</option>
                    <?php foreach ($gradeOptions as $gradeOption): ?>
                        <option value="<?= htmlspecialchars($gradeOption) ?>" <?= $selectedGradeLevel === $gradeOption ? 'selected' : '' ?>><?= htmlspecialchars($gradeOption) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 col-md-2 d-flex align-items-end gap-2">
                <button type="submit" class="btn btn-primary w-100"><i class="fas fa-filter me-1"></i>Apply</button>
                <a href="/school-admin-dashboard/modules/reports/reports-academic.php" class="btn btn-outline-secondary w-100"><i class="fas fa-rotate-left me-1"></i>Clear</a>
            </div>
        </form>
    </div>

    <div class="summary-grid">
        <div class="summary-card"><div class="summary-label">Students</div><div class="summary-value"><?= number_format((int) $summary['total_students']) ?></div></div>
        <div class="summary-card"><div class="summary-label">Pending Registrations</div><div class="summary-value"><?= number_format((int) $summary['pending_registrations']) ?></div></div>
        <div class="summary-card"><div class="summary-label">Missing LRN</div><div class="summary-value"><?= number_format((int) $summary['missing_lrn']) ?></div></div>
        <div class="summary-card"><div class="summary-label">Missing Section</div><div class="summary-value"><?= number_format((int) $summary['missing_section']) ?></div></div>
        <div class="summary-card"><div class="summary-label">Incomplete Requirements</div><div class="summary-value"><?= number_format((int) $summary['incomplete_requirements']) ?></div></div>
    </div>

        <div class="table-card mb-3">
            <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h3 class="h6 mb-0">Enrollment by Grade</h3>
                <div class="section-note">Student counts per grade level for the selected school year.</div>
            </div>
            <span class="text-muted small"><?= count($gradeRows) ?> row(s)</span>
        </div>
        <div class="table-responsive">
            <table class="table align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Grade</th>
                        <th class="text-end">Total Students</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($gradeRows): ?>
                    <?php foreach ($gradeRows as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars((string) $row['grade']) ?></td>
                            <td class="text-end"><?= number_format((int) $row['total_students']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="2" class="text-center text-muted py-4">No enrollment grade records matched the active filter.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-12 col-lg-6">
            <div class="table-card h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>
                        <h3 class="h6 mb-0">Students Missing LRN</h3>
                        <div class="section-note">Student records that still need LRN completion.</div>
                    </div>
                    <span class="text-muted small"><?= count($missingLrnRows) ?> row(s)</span>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead class="table-light">
                            <tr><th>Student</th><th>Grade</th><th>Strand</th><th>Section</th></tr>
                        </thead>
                        <tbody>
                        <?php if ($missingLrnRows): ?>
                            <?php foreach ($missingLrnRows as $row): ?>
                                <tr>
                                    <td><?= htmlspecialchars(trim(($row['lastname'] ?? '') . ', ' . ($row['firstname'] ?? '') . ' ' . ($row['middlename'] ?? ''))) ?></td>
                                    <td><?= htmlspecialchars((string) ($row['grade'] ?? '')) ?></td>
                                    <td><?= htmlspecialchars((string) (($row['strand'] ?? '') !== '' ? $row['strand'] : 'N/A')) ?></td>
                                    <td><?= htmlspecialchars((string) ($row['section'] ?? '')) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="4" class="text-center text-muted py-4">No student records with missing LRN matched the active filter.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-12 col-lg-6">
            <div class="table-card h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>
                        <h3 class="h6 mb-0">Students Missing Section</h3>
                        <div class="section-note">Student records that still need section assignment.</div>
                    </div>
                    <span class="text-muted small"><?= count($missingSectionRows) ?> row(s)</span>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead class="table-light">
                            <tr><th>Student</th><th>Grade</th><th>Strand</th><th>LRN</th></tr>
                        </thead>
                        <tbody>
                        <?php if ($missingSectionRows): ?>
                            <?php foreach ($missingSectionRows as $row): ?>
                                <tr>
                                    <td><?= htmlspecialchars(trim(($row['lastname'] ?? '') . ', ' . ($row['firstname'] ?? '') . ' ' . ($row['middlename'] ?? ''))) ?></td>
                                    <td><?= htmlspecialchars((string) ($row['grade'] ?? '')) ?></td>
                                    <td><?= htmlspecialchars((string) (($row['strand'] ?? '') !== '' ? $row['strand'] : 'N/A')) ?></td>
                                    <td><?= htmlspecialchars((string) (($row['lrn'] ?? '') !== '' ? $row['lrn'] : 'Not Set')) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="4" class="text-center text-muted py-4">No student records with missing section matched the active filter.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="table-card mt-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h3 class="h6 mb-0">Incomplete Requirements Follow-up</h3>
                <div class="section-note">Students who still need submitted or follow-up requirement completion.</div>
            </div>
            <span class="text-muted small"><?= count($incompleteRequirementRows) ?> row(s)</span>
        </div>
        <div class="table-responsive">
            <table class="table align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Student</th>
                        <th>Grade</th>
                        <th>Strand</th>
                        <th>Section</th>
                        <th class="text-end">Submitted</th>
                        <th class="text-end">Missing</th>
                        <th class="text-end">To Follow</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($incompleteRequirementRows): ?>
                    <?php foreach ($incompleteRequirementRows as $row): ?>
                        <?php $req = $row['requirement_summary'] ?? ['submitted' => 0, 'missing' => 0, 'to_follow' => 0]; ?>
                        <tr>
                            <td><?= htmlspecialchars(trim(($row['lastname'] ?? '') . ', ' . ($row['firstname'] ?? '') . ' ' . ($row['middlename'] ?? ''))) ?></td>
                            <td><?= htmlspecialchars((string) ($row['grade'] ?? '')) ?></td>
                            <td><?= htmlspecialchars((string) (($row['strand'] ?? '') !== '' ? $row['strand'] : 'N/A')) ?></td>
                            <td><?= htmlspecialchars((string) ($row['section'] ?? '')) ?></td>
                            <td class="text-end"><?= number_format((int) ($req['submitted'] ?? 0)) ?></td>
                            <td class="text-end"><?= number_format((int) ($req['missing'] ?? 0)) ?></td>
                            <td class="text-end"><?= number_format((int) ($req['to_follow'] ?? 0)) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="7" class="text-center text-muted py-4">No incomplete requirement records matched the active filter.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
<?php $conn->close(); ?>
