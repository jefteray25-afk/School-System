<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/reports-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Cell\DataType;

if (!hasPermission($_SESSION['role'] ?? '', 'reports', 'view')) {
    $blockedRole = (string) ($_SESSION['role'] ?? '');
    $blockedUser = (string) ($_SESSION['username'] ?? 'unknown');
    if (!isset($conn) || !($conn instanceof mysqli)) {
        $conn = database_open_connection();
    }
    audit_log(
        $conn,
        $blockedUser,
        'Blocked student summary report export access',
        'Reports',
        'Role: ' . ($blockedRole !== '' ? $blockedRole : 'unknown') . ' | Reason: missing reports:view permission',
        'SECURITY'
    );
    admin_session_forbidden();
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    $conn = database_open_connection();
}

$activeSchoolYear = school_year_get_active_label($conn);
$selectedSchoolYear = reports_safe_school_year((string) ($_GET['school_year'] ?? ''), $activeSchoolYear);
$studentId = (int) ($_GET['student_id'] ?? 0);

if ($studentId <= 0) {
    die('Student ID is required.');
}

$studentSummary = reports_student_summary($conn, $studentId, $selectedSchoolYear);
if (!$studentSummary) {
    die('Student summary could not be loaded.');
}

function reports_export_sheet_style($sheet, string $endColumn, int $lastRow): void
{
    $sheet->getStyle("A1:{$endColumn}{$lastRow}")->getFont()->setName('Arial')->setSize(11);
    $sheet->getStyle("A1:{$endColumn}1")->getFont()->setBold(true)->setSize(14);
    $sheet->getStyle("A4:{$endColumn}4")->getFont()->setBold(true);
    $sheet->getStyle("A4:{$endColumn}4")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('DCEAF7');
    $sheet->getStyle("A4:{$endColumn}{$lastRow}")->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN)->getColor()->setRGB('C7D0D9');
    $sheet->getStyle("A1:{$endColumn}{$lastRow}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
    foreach (range('A', $endColumn) as $col) {
        $sheet->getColumnDimension($col)->setAutoSize(true);
    }
}

$student = $studentSummary['student'];
$summary = $studentSummary['summary'];
$reqSummary = $studentSummary['requirement_summary'];
$docSummary = $studentSummary['document_summary'];

$spreadsheet = new Spreadsheet();
$summarySheet = $spreadsheet->getActiveSheet();
$summarySheet->setTitle('Student Summary');
$summarySheet->setCellValue('A1', 'Student Summary Report');
$summarySheet->setCellValue('A2', 'Student: ' . (string) ($student['full_name'] ?? ''));
$summarySheet->setCellValue('A3', 'As Of: ' . reports_as_of_label());
$summarySheet->setCellValue('A4', 'Field');
$summarySheet->setCellValue('B4', 'Value');

$rows = [
    ['Student ID', (int) ($student['id'] ?? 0)],
    ['School Year', (string) ($studentSummary['selected_school_year'] ?? '')],
    ['Grade', (string) ($student['grade'] ?? '')],
    ['Strand', (string) (($student['strand'] ?? '') !== '' ? $student['strand'] : 'N/A')],
    ['Section', (string) ($student['section'] ?? '')],
    ['LRN', (string) (($student['lrn'] ?? '') !== '' ? $student['lrn'] : 'Not Set')],
    ['Date Enrolled', (string) (($student['date_enrolled'] ?? '') !== '' ? $student['date_enrolled'] : '-')],
    ['Total Assessed', (float) ($summary['assessed'] ?? 0)],
    ['Total Paid', (float) ($summary['paid'] ?? 0)],
    ['Remaining Balance', (float) ($summary['balance'] ?? 0)],
    ['Recorded Payments', (int) ($summary['payment_count'] ?? 0)],
    ['Requirements Submitted', (int) ($reqSummary['submitted'] ?? 0)],
    ['Requirements Missing', (int) ($reqSummary['missing'] ?? 0)],
    ['Requirements To Follow', (int) ($reqSummary['to_follow'] ?? 0)],
    ['Files Uploaded', (int) ($docSummary['uploaded'] ?? 0)],
];
$row = 5;
foreach ($rows as [$label, $value]) {
    $summarySheet->setCellValue("A{$row}", $label);
    if ($label === 'LRN') {
        $summarySheet->setCellValueExplicit("B{$row}", (string) $value, DataType::TYPE_STRING);
        $summarySheet->getStyle("B{$row}")->getNumberFormat()->setFormatCode('@');
    } else {
        $summarySheet->setCellValue("B{$row}", $value);
    }
    $row++;
}
$summarySheet->getStyle("B12:B14")->getNumberFormat()->setFormatCode('#,##0.00');
reports_export_sheet_style($summarySheet, 'B', $row - 1);

$accountsSheet = $spreadsheet->createSheet();
$accountsSheet->setTitle('Account Breakdown');
$accountsSheet->fromArray(['Fee Type', 'Assessed Amount', 'Total Paid', 'Balance', 'Status'], null, 'A1');
$row = 2;
foreach (($studentSummary['accounts'] ?? []) as $account) {
    $isPaid = (float) ($account['balance'] ?? 0) <= 0.009;
    $status = $isPaid ? 'Paid' : (((float) ($account['total_paid'] ?? 0) > 0) ? 'Partial' : 'Outstanding');
    $accountsSheet->setCellValue("A{$row}", (string) ($account['type'] ?? ''));
    $accountsSheet->setCellValue("B{$row}", (float) ($account['assessed_amount'] ?? 0));
    $accountsSheet->setCellValue("C{$row}", (float) ($account['total_paid'] ?? 0));
    $accountsSheet->setCellValue("D{$row}", (float) ($account['balance'] ?? 0));
    $accountsSheet->setCellValue("E{$row}", $status);
    $row++;
}
$accountsSheet->getStyle("B2:D{$row}")->getNumberFormat()->setFormatCode('#,##0.00');
reports_export_sheet_style($accountsSheet, 'E', max(2, $row - 1));

$paymentsSheet = $spreadsheet->createSheet();
$paymentsSheet->setTitle('Payments');
$paymentsSheet->fromArray(['Date Paid', 'Fee Type', 'Amount', 'Booklet No', 'Receipt No', 'Remarks'], null, 'A1');
$row = 2;
foreach (($studentSummary['payments'] ?? []) as $payment) {
    $paymentsSheet->setCellValue("A{$row}", (string) ($payment['date_paid'] ?? ''));
    $paymentsSheet->setCellValue("B{$row}", (string) ($payment['fee_type'] ?? ''));
    $paymentsSheet->setCellValue("C{$row}", (float) ($payment['amount'] ?? 0));
    $paymentsSheet->setCellValue("D{$row}", (string) ($payment['booklet_no'] ?? ''));
    $paymentsSheet->setCellValue("E{$row}", (string) ($payment['receipt_no'] ?? ''));
    $paymentsSheet->setCellValue("F{$row}", (string) (($payment['remarks'] ?? '') !== '' ? $payment['remarks'] : '-'));
    $row++;
}
$paymentsSheet->getStyle("C2:C{$row}")->getNumberFormat()->setFormatCode('#,##0.00');
reports_export_sheet_style($paymentsSheet, 'F', max(2, $row - 1));

$filename = 'student_summary_' . preg_replace('/[^A-Za-z0-9_-]+/', '_', (string) ($student['full_name'] ?? 'student')) . '.xlsx';

while (ob_get_level() > 0) {
    ob_end_clean();
}
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="' . $filename . '"');
header('Cache-Control: max-age=0');
header('Pragma: public');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
