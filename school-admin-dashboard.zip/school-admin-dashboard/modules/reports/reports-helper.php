<?php

require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/../settings/school-info-helper.php';
require_once __DIR__ . '/../settings/upload-storage-helper.php';
require_once __DIR__ . '/../students/student-requirements-helper.php';
require_once __DIR__ . '/../students/student-registration-helper.php';
require_once __DIR__ . '/../../includes/includes-receipt-helper.php';

function reports_safe_school_year(string $schoolYearLabel, string $fallback = ''): string
{
    $schoolYearLabel = trim($schoolYearLabel);
    if ($schoolYearLabel !== '') {
        return $schoolYearLabel;
    }

    return trim($fallback);
}

function reports_as_of_label(): string
{
    return date('F j, Y g:i A');
}

function reports_filter_summary(array $filters): array
{
    $summary = [];
    foreach ($filters as $label => $value) {
        $value = trim((string) $value);
        if ($value === '') {
            continue;
        }
        $summary[] = [
            'label' => (string) $label,
            'value' => $value,
        ];
    }

    return $summary;
}

function reports_school_year_options(mysqli $conn): array
{
    school_year_ensure_table($conn);
    return school_year_filter_options($conn);
}

function reports_ensure_student_schema(mysqli $conn): void
{
    registration_ensure_student_strand_column($conn);
}

function reports_find_students(mysqli $conn, string $searchTerm, string $schoolYearLabel = '', int $limit = 20): array
{
    reports_ensure_student_schema($conn);
    $searchTerm = trim($searchTerm);
    if ($searchTerm === '') {
        return [];
    }

    $limit = max(1, min($limit, 50));
    $schoolYearLabel = trim($schoolYearLabel);
    $like = '%' . $searchTerm . '%';

    $sql = "
        SELECT id,
               lastname,
               firstname,
               middlename,
               lrn,
               grade,
               strand,
               section,
               school_year_label
        FROM students
        WHERE (
            CAST(id AS CHAR) LIKE ?
            OR lrn LIKE ?
            OR CONCAT(COALESCE(lastname, ''), ' ', COALESCE(firstname, ''), ' ', COALESCE(middlename, '')) LIKE ?
        )
    ";

    $types = 'sss';
    $params = [$like, $like, $like];

    if ($schoolYearLabel !== '') {
        $sql .= " AND school_year_label = ? ";
        $types .= 's';
        $params[] = $schoolYearLabel;
    }

    $sql .= " ORDER BY lastname ASC, firstname ASC LIMIT ?";
    $types .= 'i';
    $params[] = $limit;

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return [];
    }

    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    $stmt->close();
    return $rows;
}

function reports_student_basic(mysqli $conn, int $studentId): ?array
{
    reports_ensure_student_schema($conn);
    $stmt = $conn->prepare("
        SELECT id,
               lastname,
               firstname,
               middlename,
               lrn,
               grade,
               strand,
               section,
               birthday,
               age,
               gender,
               address,
               contact,
               guardian_name,
               guardian_contact,
               date_enrolled,
               photo,
               school_year_label
        FROM students
        WHERE id = ?
        LIMIT 1
    ");
    if (!$stmt) {
        return null;
    }
    $stmt->bind_param('i', $studentId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result ? $result->fetch_assoc() : null;
    $stmt->close();

    if (!$row) {
        return null;
    }

    $photoFilename = trim((string) ($row['photo'] ?? ''));
    $row['full_name'] = trim((string) ($row['lastname'] ?? '') . ', ' . (string) ($row['firstname'] ?? '') . ' ' . (string) ($row['middlename'] ?? ''));
    $row['photo_url'] = ($photoFilename !== '' && file_exists(student_photo_absolute_path($conn, $photoFilename)))
        ? student_photo_public_url($photoFilename)
        : '/school-admin-dashboard/assets/img/default-profile.png';

    return $row;
}

function reports_student_account_rows(mysqli $conn, int $studentId, string $schoolYearLabel): array
{
    ensure_receipts_registry_schema($conn);
    $stmt = $conn->prepare("
        SELECT
            a.id,
            a.type,
            a.balance,
            a.notes,
            COALESCE(SUM(
                CASE
                    WHEN (p.booklet_no IS NULL OR p.receipt_no IS NULL) THEN p.amount
                    WHEN rr.receipt_no IS NOT NULL THEN p.amount
                    ELSE 0
                END
            ), 0) AS total_paid
        FROM accounts a
        LEFT JOIN payments p
            ON p.account_id = a.id
        LEFT JOIN receipts_registry rr
            ON rr.receipt_no = p.receipt_no
           AND rr.booklet_no = p.booklet_no
           AND rr.voided = 0
           AND rr.used_by IN ('payments', 'other_payment')
        WHERE a.student_id = ?
          AND COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ?
        GROUP BY a.id, a.type, a.balance, a.notes
        ORDER BY a.type ASC
    ");
    if (!$stmt) {
        return [];
    }
    $stmt->bind_param('iss', $studentId, $schoolYearLabel, $schoolYearLabel);
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $row['balance'] = (float) ($row['balance'] ?? 0);
        $row['total_paid'] = (float) ($row['total_paid'] ?? 0);
        $row['assessed_amount'] = $row['balance'] + $row['total_paid'];
        $rows[] = $row;
    }
    $stmt->close();

    return $rows;
}

function reports_student_payment_rows(mysqli $conn, int $studentId, string $schoolYearLabel, int $limit = 12): array
{
    ensure_receipts_registry_schema($conn);
    $limit = max(1, min($limit, 50));
    $sql = "
        SELECT
            p.id,
            p.date_paid,
            p.amount,
            p.booklet_no,
            p.receipt_no,
            p.remarks,
            p.receipt_note,
            COALESCE(a.type, 'Uncategorized') AS fee_type
        FROM payments p
        LEFT JOIN accounts a ON p.account_id = a.id
        LEFT JOIN receipts_registry rr
            ON rr.receipt_no = p.receipt_no
           AND rr.booklet_no = p.booklet_no
           AND rr.voided = 0
           AND rr.used_by IN ('payments', 'other_payment')
        WHERE a.student_id = ?
          AND COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ?
          AND (
                (p.booklet_no IS NULL OR p.receipt_no IS NULL)
                OR rr.receipt_no IS NOT NULL
          )
        ORDER BY p.date_paid DESC, p.id DESC
        LIMIT $limit
    ";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return [];
    }
    $stmt->bind_param('iss', $studentId, $schoolYearLabel, $schoolYearLabel);
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    $stmt->close();

    return $rows;
}

function reports_student_summary(mysqli $conn, int $studentId, string $schoolYearLabel = ''): ?array
{
    school_year_ensure_table($conn);
    student_requirements_ensure_table($conn);

    $student = reports_student_basic($conn, $studentId);
    if (!$student) {
        return null;
    }

    $activeSchoolYear = school_year_get_active_label($conn);
    $selectedSchoolYear = reports_safe_school_year($schoolYearLabel, (string) ($student['school_year_label'] ?? $activeSchoolYear));

    $accountRows = reports_student_account_rows($conn, $studentId, $selectedSchoolYear);
    $paymentRows = reports_student_payment_rows($conn, $studentId, $selectedSchoolYear);
    $requirements = student_requirements_get_for_student($conn, $studentId);
    $requirementCatalogRows = student_requirements_catalog_rows($conn);
    $requirementSummary = student_requirements_completion_summary($requirements);
    $documents = student_requirement_documents_get_for_student($conn, $studentId);
    $documentSummary = student_requirement_documents_summary($documents, count($requirementCatalogRows));

    $summary = [
        'assessed' => 0.0,
        'paid' => 0.0,
        'balance' => 0.0,
        'payment_count' => count($paymentRows),
        'account_count' => count($accountRows),
    ];

    foreach ($accountRows as $row) {
        $summary['assessed'] += (float) $row['assessed_amount'];
        $summary['paid'] += (float) $row['total_paid'];
        $summary['balance'] += (float) $row['balance'];
    }

    return [
        'student' => $student,
        'selected_school_year' => $selectedSchoolYear,
        'accounts' => $accountRows,
        'payments' => $paymentRows,
        'requirements' => $requirements,
        'requirement_summary' => $requirementSummary,
        'documents' => $documents,
        'document_summary' => $documentSummary,
        'summary' => $summary,
    ];
}

function reports_finance_summary(mysqli $conn, string $schoolYearLabel = '', string $dateFrom = '', string $dateTo = '', string $studentName = '', string $studentLrn = ''): array
{
    school_year_ensure_table($conn);
    school_year_ensure_finance_columns($conn);
    $schoolYearLabel = trim($schoolYearLabel);
    $dateFrom = trim($dateFrom);
    $dateTo = trim($dateTo);
    $studentName = trim($studentName);
    $studentLrn = trim($studentLrn);

    $summary = [
        'unpaid_students' => 0,
        'outstanding_balance' => 0.0,
        'recorded_payments' => 0,
        'collections_total' => 0.0,
        'old_account_count' => 0,
        'old_collections_total' => 0.0,
    ];

    $accountSql = "
        SELECT
            COUNT(DISTINCT CASE WHEN a.balance > 0 THEN a.student_id END) AS unpaid_students,
            COALESCE(SUM(a.balance), 0) AS outstanding_balance
        FROM accounts a
        INNER JOIN students s ON s.id = a.student_id
    ";
    $accountWhere = [];
    $accountTypes = '';
    $accountParams = [];
    if ($schoolYearLabel !== '') {
        $accountWhere[] = "COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ?";
        $accountTypes .= 'ss';
        $accountParams[] = $schoolYearLabel;
        $accountParams[] = $schoolYearLabel;
    }
    if ($studentName !== '') {
        $accountWhere[] = "CONCAT(COALESCE(s.lastname, ''), ', ', COALESCE(s.firstname, ''), ' ', COALESCE(s.middlename, '')) LIKE ?";
        $accountTypes .= 's';
        $accountParams[] = '%' . $studentName . '%';
    }
    if ($studentLrn !== '') {
        $accountWhere[] = "COALESCE(s.lrn, '') LIKE ?";
        $accountTypes .= 's';
        $accountParams[] = '%' . $studentLrn . '%';
    }
    if ($accountWhere) {
        $accountSql .= " WHERE " . implode(' AND ', $accountWhere);
    }
    $stmt = $conn->prepare($accountSql);
    if ($stmt) {
        if ($accountTypes !== '') {
            $stmt->bind_param($accountTypes, ...$accountParams);
        }
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($row) {
            $summary['unpaid_students'] = (int) ($row['unpaid_students'] ?? 0);
            $summary['outstanding_balance'] = (float) ($row['outstanding_balance'] ?? 0);
        }
    }

    $paymentSql = "
        SELECT COUNT(*) AS recorded_payments, COALESCE(SUM(p.amount), 0) AS collections_total
        FROM payments p
        INNER JOIN accounts a ON a.id = p.account_id
        INNER JOIN students s ON s.id = a.student_id
        LEFT JOIN receipts_registry rr
            ON rr.receipt_no = p.receipt_no
           AND rr.booklet_no = p.booklet_no
           AND rr.voided = 0
           AND rr.used_by IN ('payments', 'other_payment')
        WHERE ((p.booklet_no IS NULL OR p.receipt_no IS NULL) OR rr.receipt_no IS NOT NULL)
    ";
    $types = '';
    $params = [];
    if ($schoolYearLabel !== '') {
        $paymentSql .= " AND COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ? ";
        $types .= 'ss';
        $params[] = $schoolYearLabel;
        $params[] = $schoolYearLabel;
    }
    if ($dateFrom !== '') {
        $paymentSql .= " AND p.date_paid >= ? ";
        $types .= 's';
        $params[] = $dateFrom;
    }
    if ($dateTo !== '') {
        $paymentSql .= " AND p.date_paid <= ? ";
        $types .= 's';
        $params[] = $dateTo;
    }
    if ($studentName !== '') {
        $paymentSql .= " AND CONCAT(COALESCE(s.lastname, ''), ', ', COALESCE(s.firstname, ''), ' ', COALESCE(s.middlename, '')) LIKE ? ";
        $types .= 's';
        $params[] = '%' . $studentName . '%';
    }
    if ($studentLrn !== '') {
        $paymentSql .= " AND COALESCE(s.lrn, '') LIKE ? ";
        $types .= 's';
        $params[] = '%' . $studentLrn . '%';
    }
    $stmt = $conn->prepare($paymentSql);
    if ($stmt) {
        if ($types !== '') {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($row) {
            $summary['recorded_payments'] = (int) ($row['recorded_payments'] ?? 0);
            $summary['collections_total'] = (float) ($row['collections_total'] ?? 0);
        }
    }

    if (reports_table_exists($conn, 'old_students')) {
        $oldSql = "SELECT COUNT(*) AS total_old_students FROM old_students";
        if ($schoolYearLabel !== '' && reports_column_exists($conn, 'old_students', 'school_year_label')) {
            $stmt = $conn->prepare($oldSql . " WHERE COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?");
            if ($stmt) {
                $stmt->bind_param('ss', $schoolYearLabel, $schoolYearLabel);
                $stmt->execute();
                $row = $stmt->get_result()->fetch_assoc();
                $stmt->close();
                $summary['old_account_count'] = (int) ($row['total_old_students'] ?? 0);
            }
        } else {
            $row = $conn->query($oldSql)->fetch_assoc();
            $summary['old_account_count'] = (int) ($row['total_old_students'] ?? 0);
        }
    }

    if (reports_table_exists($conn, 'old_student_payments')) {
        $oldPaymentSql = "SELECT COALESCE(SUM(amount), 0) AS total_old_collections FROM old_student_payments";
        $oldTypes = '';
        $oldParams = [];
        if ($schoolYearLabel !== '' && reports_column_exists($conn, 'old_student_payments', 'school_year_label')) {
            $oldPaymentSql .= " WHERE COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ? ";
            $oldTypes .= 'ss';
            $oldParams[] = $schoolYearLabel;
            $oldParams[] = $schoolYearLabel;
        } else {
            $oldPaymentSql .= " WHERE 1=1 ";
        }
        if ($dateFrom !== '' && reports_column_exists($conn, 'old_student_payments', 'paid_at')) {
            $oldPaymentSql .= " AND paid_at >= ? ";
            $oldTypes .= 's';
            $oldParams[] = $dateFrom;
        }
        if ($dateTo !== '' && reports_column_exists($conn, 'old_student_payments', 'paid_at')) {
            $oldPaymentSql .= " AND paid_at <= ? ";
            $oldTypes .= 's';
            $oldParams[] = $dateTo;
        }
        $stmt = $conn->prepare($oldPaymentSql);
        if ($stmt) {
            if ($oldTypes !== '') {
                $stmt->bind_param($oldTypes, ...$oldParams);
            }
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            $summary['old_collections_total'] = (float) ($row['total_old_collections'] ?? 0);
        }
    }

    return $summary;
}

function reports_finance_outstanding_rows(mysqli $conn, string $schoolYearLabel = '', string $studentName = '', string $studentLrn = '', int $limit = 20): array
{
    $limit = max(1, min($limit, 100));
    $schoolYearLabel = trim($schoolYearLabel);
    $studentName = trim($studentName);
    $studentLrn = trim($studentLrn);

    $sql = "
        SELECT
            s.id AS student_id,
            CONCAT(COALESCE(s.lastname, ''), ', ', COALESCE(s.firstname, ''), ' ', COALESCE(s.middlename, '')) AS student_name,
            s.grade,
            s.section,
            COALESCE(SUM(a.balance), 0) AS outstanding_balance
        FROM students s
        INNER JOIN accounts a ON a.student_id = s.id
        WHERE a.balance > 0
    ";
    $types = '';
    $params = [];
    if ($schoolYearLabel !== '') {
        $sql .= " AND COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ? ";
        $types .= 'ss';
        $params[] = $schoolYearLabel;
        $params[] = $schoolYearLabel;
    }
    if ($studentName !== '') {
        $sql .= " AND CONCAT(COALESCE(s.lastname, ''), ', ', COALESCE(s.firstname, ''), ' ', COALESCE(s.middlename, '')) LIKE ? ";
        $types .= 's';
        $params[] = '%' . $studentName . '%';
    }
    if ($studentLrn !== '') {
        $sql .= " AND COALESCE(s.lrn, '') LIKE ? ";
        $types .= 's';
        $params[] = '%' . $studentLrn . '%';
    }
    $sql .= "
        GROUP BY s.id, s.lastname, s.firstname, s.middlename, s.grade, s.section
        ORDER BY outstanding_balance DESC, s.lastname ASC
        LIMIT $limit
    ";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return [];
    }
    if ($types !== '') {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    $stmt->close();

    return $rows;
}

function reports_finance_recent_payments(mysqli $conn, string $schoolYearLabel = '', string $dateFrom = '', string $dateTo = '', string $studentName = '', string $studentLrn = '', int $limit = 20): array
{
    $limit = max(1, min($limit, 100));
    $studentName = trim($studentName);
    $studentLrn = trim($studentLrn);
    $sql = "
        SELECT
            p.date_paid,
            p.amount,
            p.receipt_no,
            p.booklet_no,
            COALESCE(a.type, 'Uncategorized') AS fee_type,
            CONCAT(COALESCE(s.lastname, ''), ', ', COALESCE(s.firstname, ''), ' ', COALESCE(s.middlename, '')) AS student_name,
            s.id AS student_id,
            s.lrn
        FROM payments p
        INNER JOIN accounts a ON a.id = p.account_id
        INNER JOIN students s ON s.id = a.student_id
        LEFT JOIN receipts_registry rr
            ON rr.receipt_no = p.receipt_no
           AND rr.booklet_no = p.booklet_no
           AND rr.voided = 0
           AND rr.used_by IN ('payments', 'other_payment')
        WHERE ((p.booklet_no IS NULL OR p.receipt_no IS NULL) OR rr.receipt_no IS NOT NULL)
    ";
    $types = '';
    $params = [];
    if ($schoolYearLabel !== '') {
        $sql .= " AND COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ? ";
        $types .= 'ss';
        $params[] = $schoolYearLabel;
        $params[] = $schoolYearLabel;
    }
    if ($dateFrom !== '') {
        $sql .= " AND p.date_paid >= ? ";
        $types .= 's';
        $params[] = $dateFrom;
    }
    if ($dateTo !== '') {
        $sql .= " AND p.date_paid <= ? ";
        $types .= 's';
        $params[] = $dateTo;
    }
    if ($studentName !== '') {
        $sql .= " AND CONCAT(COALESCE(s.lastname, ''), ', ', COALESCE(s.firstname, ''), ' ', COALESCE(s.middlename, '')) LIKE ? ";
        $types .= 's';
        $params[] = '%' . $studentName . '%';
    }
    if ($studentLrn !== '') {
        $sql .= " AND COALESCE(s.lrn, '') LIKE ? ";
        $types .= 's';
        $params[] = '%' . $studentLrn . '%';
    }
    $sql .= " ORDER BY p.date_paid DESC, p.id DESC LIMIT $limit";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return [];
    }
    if ($types !== '') {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    $stmt->close();

    return $rows;
}

function reports_table_exists(mysqli $conn, string $tableName): bool
{
    $stmt = $conn->prepare("SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1");
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('s', $tableName);
    $stmt->execute();
    $exists = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    return $exists;
}

function reports_column_exists(mysqli $conn, string $tableName, string $columnName): bool
{
    $stmt = $conn->prepare("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1");
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('ss', $tableName, $columnName);
    $stmt->execute();
    $exists = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    return $exists;
}

function reports_academic_grade_options(mysqli $conn, string $schoolYearLabel = ''): array
{
    $sql = "SELECT DISTINCT grade FROM students WHERE COALESCE(NULLIF(TRIM(grade), ''), '') <> ''";
    $types = '';
    $params = [];
    if (trim($schoolYearLabel) !== '') {
        $sql .= " AND school_year_label = ? ";
        $types = 's';
        $params[] = trim($schoolYearLabel);
    }
    $sql .= " ORDER BY grade ASC";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return [];
    }
    if ($types !== '') {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $grade = trim((string) ($row['grade'] ?? ''));
        if ($grade !== '') {
            $rows[] = $grade;
        }
    }
    $stmt->close();

    return $rows;
}

function reports_academic_summary(mysqli $conn, string $schoolYearLabel = '', string $gradeLevel = ''): array
{
    reports_ensure_student_schema($conn);
    student_requirements_ensure_table($conn);
    $schoolYearLabel = trim($schoolYearLabel);
    $gradeLevel = trim($gradeLevel);
    $summary = [
        'total_students' => 0,
        'missing_lrn' => 0,
        'missing_section' => 0,
        'pending_registrations' => 0,
        'incomplete_requirements' => 0,
    ];

    $studentSql = "
        SELECT
            COUNT(*) AS total_students,
            SUM(CASE WHEN COALESCE(NULLIF(TRIM(lrn), ''), '') = '' THEN 1 ELSE 0 END) AS missing_lrn,
            SUM(CASE WHEN COALESCE(NULLIF(TRIM(section), ''), '') = '' THEN 1 ELSE 0 END) AS missing_section
        FROM students
    ";
    if ($schoolYearLabel !== '' || $gradeLevel !== '') {
        $where = [];
        $types = '';
        $params = [];
        if ($schoolYearLabel !== '') {
            $where[] = "school_year_label = ?";
            $types .= 's';
            $params[] = $schoolYearLabel;
        }
        if ($gradeLevel !== '') {
            $where[] = "grade = ?";
            $types .= 's';
            $params[] = $gradeLevel;
        }
        $stmt = $conn->prepare($studentSql . " WHERE " . implode(' AND ', $where));
        if ($stmt) {
            $stmt->bind_param($types, ...$params);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
        } else {
            $row = null;
        }
    } else {
        $row = $conn->query($studentSql)->fetch_assoc();
    }
    if ($row) {
        $summary['total_students'] = (int) ($row['total_students'] ?? 0);
        $summary['missing_lrn'] = (int) ($row['missing_lrn'] ?? 0);
        $summary['missing_section'] = (int) ($row['missing_section'] ?? 0);
    }

    if (reports_table_exists($conn, 'student_registration_pending')) {
        $pendingSql = "SELECT COUNT(*) AS total_pending FROM student_registration_pending WHERE status = 'Pending'";
        if (($schoolYearLabel !== '' && reports_column_exists($conn, 'student_registration_pending', 'school_year_label')) || ($gradeLevel !== '' && reports_column_exists($conn, 'student_registration_pending', 'grade_level'))) {
            $where = [];
            $types = '';
            $params = [];
            if ($schoolYearLabel !== '' && reports_column_exists($conn, 'student_registration_pending', 'school_year_label')) {
                $where[] = "school_year_label = ?";
                $types .= 's';
                $params[] = $schoolYearLabel;
            }
            if ($gradeLevel !== '' && reports_column_exists($conn, 'student_registration_pending', 'grade_level')) {
                $where[] = "grade_level = ?";
                $types .= 's';
                $params[] = $gradeLevel;
            }
            $stmt = $conn->prepare($pendingSql . ($where ? " AND " . implode(' AND ', $where) : ''));
            if ($stmt) {
                $stmt->bind_param($types, ...$params);
                $stmt->execute();
                $row = $stmt->get_result()->fetch_assoc();
                $stmt->close();
                $summary['pending_registrations'] = (int) ($row['total_pending'] ?? 0);
            }
        } else {
            $row = $conn->query($pendingSql)->fetch_assoc();
            $summary['pending_registrations'] = (int) ($row['total_pending'] ?? 0);
        }
    }

    $students = reports_academic_incomplete_requirements($conn, $schoolYearLabel, $gradeLevel, 9999);
    $summary['incomplete_requirements'] = count($students);

    return $summary;
}

function reports_academic_grade_rows(mysqli $conn, string $schoolYearLabel = '', string $gradeLevel = ''): array
{
    reports_ensure_student_schema($conn);
    $sql = "SELECT grade, COUNT(*) AS total_students FROM students";
    $types = '';
    $params = [];
    $where = [];
    if (trim($schoolYearLabel) !== '') {
        $where[] = "school_year_label = ? ";
        $types .= 's';
        $params[] = trim($schoolYearLabel);
    }
    if (trim($gradeLevel) !== '') {
        $where[] = "grade = ? ";
        $types .= 's';
        $params[] = trim($gradeLevel);
    }
    if ($where) {
        $sql .= " WHERE " . implode(' AND ', $where);
    }
    $sql .= " GROUP BY grade ORDER BY grade ASC";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return [];
    }
    if ($types !== '') {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    $stmt->close();

    return $rows;
}

function reports_academic_missing_rows(mysqli $conn, string $schoolYearLabel = '', string $gradeLevel = '', string $mode = 'lrn', int $limit = 25): array
{
    reports_ensure_student_schema($conn);
    $limit = max(1, min($limit, 100));
    $field = $mode === 'section' ? 'section' : 'lrn';
    $sql = "
        SELECT id, lastname, firstname, middlename, grade, strand, section, lrn, school_year_label
        FROM students
        WHERE COALESCE(NULLIF(TRIM($field), ''), '') = ''
    ";
    $types = '';
    $params = [];
    if (trim($schoolYearLabel) !== '') {
        $sql .= " AND school_year_label = ? ";
        $types .= 's';
        $params[] = trim($schoolYearLabel);
    }
    if (trim($gradeLevel) !== '') {
        $sql .= " AND grade = ? ";
        $types .= 's';
        $params[] = trim($gradeLevel);
    }
    $sql .= " ORDER BY lastname ASC, firstname ASC LIMIT $limit";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return [];
    }
    if ($types !== '') {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    $stmt->close();

    return $rows;
}

function reports_academic_incomplete_requirements(mysqli $conn, string $schoolYearLabel = '', string $gradeLevel = '', int $limit = 25): array
{
    reports_ensure_student_schema($conn);
    student_requirements_ensure_table($conn);
    $limit = max(1, min($limit, 10000));
    $sql = "SELECT id, lastname, firstname, middlename, grade, strand, section, school_year_label FROM students";
    $types = '';
    $params = [];
    $where = [];
    if (trim($schoolYearLabel) !== '') {
        $where[] = "school_year_label = ? ";
        $types .= 's';
        $params[] = trim($schoolYearLabel);
    }
    if (trim($gradeLevel) !== '') {
        $where[] = "grade = ? ";
        $types .= 's';
        $params[] = trim($gradeLevel);
    }
    if ($where) {
        $sql .= " WHERE " . implode(' AND ', $where);
    }
    $sql .= " ORDER BY lastname ASC, firstname ASC LIMIT $limit";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return [];
    }
    if ($types !== '') {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $statuses = student_requirements_get_for_student($conn, (int) $row['id']);
        $summary = student_requirements_completion_summary($statuses);
        if ((int) ($summary['missing'] ?? 0) > 0 || (int) ($summary['to_follow'] ?? 0) > 0) {
            $row['requirement_summary'] = $summary;
            $rows[] = $row;
        }
    }
    $stmt->close();

    return array_slice($rows, 0, min(100, $limit));
}

function reports_money(float $amount): string
{
    return 'PHP ' . number_format($amount, 2);
}
