<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require_once __DIR__ . '/../../includes/ui.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../settings/school-info-helper.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/reports-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

if (!hasPermission($_SESSION['role'] ?? '', 'reports', 'view')) {
    $blockedRole = (string) ($_SESSION['role'] ?? '');
    $blockedUser = (string) ($_SESSION['username'] ?? 'unknown');
    audit_log(
        $conn,
        $blockedUser,
        'Blocked finance reports access',
        'Reports',
        'Role: ' . ($blockedRole !== '' ? $blockedRole : 'unknown') . ' | Reason: missing reports:view permission',
        'SECURITY'
    );
    admin_session_forbidden();
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    $conn = database_open_connection();
}

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$schoolYears = reports_school_year_options($conn);
$selectedSchoolYear = trim((string) ($_GET['school_year'] ?? school_year_get_active_label($conn)));
$dateFrom = trim((string) ($_GET['date_from'] ?? ''));
$dateTo = trim((string) ($_GET['date_to'] ?? ''));
$studentNameFilter = trim((string) ($_GET['student_name'] ?? ''));
$studentLrnFilter = trim((string) ($_GET['student_lrn'] ?? ''));

$summary = reports_finance_summary($conn, $selectedSchoolYear, $dateFrom, $dateTo, $studentNameFilter, $studentLrnFilter);
$outstandingRows = reports_finance_outstanding_rows($conn, $selectedSchoolYear, $studentNameFilter, $studentLrnFilter, 20);
$recentPayments = reports_finance_recent_payments($conn, $selectedSchoolYear, $dateFrom, $dateTo, $studentNameFilter, $studentLrnFilter, 20);

if ($recentPayments && !array_key_exists('items_count', $recentPayments[0])) {
    $grouped = [];
    foreach ($recentPayments as $row) {
        $bookletNo = (string) ($row['booklet_no'] ?? '');
        $receiptNo = (string) ($row['receipt_no'] ?? '');
        $groupKey = ($bookletNo !== '' && $receiptNo !== '') ? ($bookletNo . '-' . $receiptNo) : ('noreceipt-' . ($row['date_paid'] ?? '') . '-' . ($row['student_id'] ?? ''));
        if (!isset($grouped[$groupKey])) {
            $grouped[$groupKey] = $row;
            $grouped[$groupKey]['items'] = [];
            $grouped[$groupKey]['items_count'] = 0;
            $grouped[$groupKey]['total_amount'] = 0.0;
        }
        $grouped[$groupKey]['items'][] = [
            'fee_type' => (string) ($row['fee_type'] ?? 'Uncategorized'),
            'amount' => (float) ($row['amount'] ?? 0),
        ];
        $grouped[$groupKey]['items_count']++;
        $grouped[$groupKey]['total_amount'] += (float) ($row['amount'] ?? 0);
    }
    $recentPayments = array_values($grouped);
}
$currentReportQuery = array_filter([
    'school_year' => $selectedSchoolYear,
    'date_from' => $dateFrom,
    'date_to' => $dateTo,
    'student_name' => $studentNameFilter,
    'student_lrn' => $studentLrnFilter,
]);
$returnToFinanceReports = '/school-admin-dashboard/modules/reports/reports-finance.php';
if ($currentReportQuery) {
    $returnToFinanceReports .= '?' . http_build_query($currentReportQuery);
}
$reportAsOf = reports_as_of_label();
$activeFilterSummary = reports_filter_summary([
    'Student Name' => $studentNameFilter,
    'LRN' => $studentLrnFilter,
    'Date From' => $dateFrom,
    'Date To' => $dateTo,
]);

function finance_outstanding_priority(float $amount): array
{
    if ($amount >= 10000) {
        return ['label' => 'High Priority', 'class' => 'priority-high', 'detail' => 'Escalate collection follow-up'];
    }
    if ($amount >= 5000) {
        return ['label' => 'Medium Priority', 'class' => 'priority-medium', 'detail' => 'Needs follow-up this cycle'];
    }
    return ['label' => 'Routine Follow-up', 'class' => 'priority-low', 'detail' => 'Monitor and remind'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance Reports | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <?php ui_css_link(); ?>
    <style>
        body { background:#f5f8fc; font-family:'Segoe UI','Roboto','Arial',sans-serif; color:#23395d; }
        .navbar { background:#23395d !important; }
        .navbar-brand, .navbar-nav .nav-link { color:#fff !important; }
        .dashboard-header { text-align:center; margin-top:36px; margin-bottom:18px; }
        .dashboard-header img { width:70px; height:70px; object-fit:contain; margin-bottom:6px; }
        .dashboard-header h1 { font-size:1.3rem; color:#23395d; font-weight:700; margin-bottom:0; }
        .page-wrap { max-width:1180px; margin:0 auto; padding:0 12px 32px; }
        .panel, .summary-card, .table-card { background:#fff; border:1px solid #dbe7f4; border-radius:18px; box-shadow:0 8px 22px rgba(35,57,93,.06); }
        .panel, .table-card { padding:18px; }
        .summary-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:14px; margin-bottom:18px; }
        .summary-card { padding:14px 16px; }
        .summary-label { font-size:.76rem; text-transform:uppercase; letter-spacing:.06em; color:#607388; font-weight:700; }
        .summary-value { font-size:1.15rem; font-weight:800; color:#23395d; }
        .table-card table { margin-bottom:0; }
        .collapse .table-sm td,
        .collapse .table-sm th { padding: 0.4rem 0.6rem; }
        .priority-chip {
            display: inline-flex;
            align-items: center;
            border-radius: 999px;
            padding: 6px 12px;
            font-size: 0.82rem;
            font-weight: 700;
            border: 1px solid transparent;
        }
        .priority-high {
            background:#fdecec;
            color:#b42318;
            border-color:#f4c9c9;
        }
        .priority-medium {
            background:#fff4d8;
            color:#9a6a00;
            border-color:#f2dfa7;
        }
        .priority-low {
            background:#edf4fb;
            color:#23395d;
            border-color:#d9e3ef;
        }
        .priority-detail {
            display:block;
            margin-top:4px;
            font-size:0.76rem;
            color:#607388;
            line-height:1.35;
        }
        .context-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:12px; margin-top:16px; }
        .context-item { background:#f8fbff; border:1px solid #dbe7f4; border-radius:14px; padding:12px 14px; }
        .context-label { font-size:.74rem; text-transform:uppercase; letter-spacing:.06em; color:#607388; font-weight:700; }
        .context-value { font-size:.98rem; font-weight:700; color:#23395d; margin-top:4px; }
        .filter-chip-list { display:flex; flex-wrap:wrap; gap:8px; margin-top:10px; }
        .filter-chip { display:inline-flex; align-items:center; gap:6px; padding:6px 10px; border-radius:999px; background:#edf4fb; color:#23395d; border:1px solid #d9e3ef; font-size:.84rem; font-weight:700; }
        .section-note { color:#607388; font-size:.88rem; }
        .print-btn { white-space:nowrap; }
        .section-toggle {
            display:inline-flex;
            align-items:center;
            gap:8px;
            border-radius:999px;
            font-weight:700;
        }
        .section-toggle .toggle-icon {
            transition: transform 0.2s ease;
        }
        .section-toggle[aria-expanded="true"] .toggle-icon {
            transform: rotate(180deg);
        }
        @media print {
            body { background:#fff !important; color:#000 !important; font-size:12px; }
            .navbar, .dashboard-header, .btn, form, .print-hidden { display:none !important; }
            .page-wrap { max-width:none; margin:0; padding:0; }
            .panel, .summary-card, .table-card, .context-item {
                box-shadow:none !important;
                border:1px solid #d0d7de !important;
                break-inside: avoid;
            }
            .summary-grid { gap:10px; }
            .table-card { margin-bottom:14px; }
            a { color:#000 !important; text-decoration:none !important; }
        }
    </style>
</head>
<body>
<?php render_admin_nav('reports'); ?>
<?php render_school_page_header($schoolName, $schoolLogo); ?>

<div class="page-wrap">
    <div class="panel mb-3">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">
            <div>
                <h2 class="h4 mb-1"><i class="fas fa-coins me-2"></i>Finance Reports</h2>
                <div class="text-muted">Review balances, collections, and recent payment activity without switching across finance pages.</div>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <a href="/school-admin-dashboard/modules/accounts/account-list.php?school_year=<?= rawurlencode($selectedSchoolYear) ?>" class="btn btn-outline-primary">
                    <i class="fas fa-wallet me-1"></i>Back to Finance Workspace
                </a>
                <a href="/school-admin-dashboard/modules/reports/reports-dashboard.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Back to Reports Center
                </a>
                <a href="/school-admin-dashboard/modules/reports/export-reports-finance.php?<?= htmlspecialchars(http_build_query($currentReportQuery + ['school_year' => $selectedSchoolYear])) ?>" class="btn btn-success">
                    <i class="fas fa-file-excel me-1"></i>Download Excel
                </a>
                <button type="button" class="btn btn-outline-dark print-btn" onclick="window.print()">
                    <i class="fas fa-print me-1"></i>Print Report
                </button>
            </div>
        </div>
        <div class="context-grid">
            <div class="context-item">
                <div class="context-label">School Year</div>
                <div class="context-value"><?= htmlspecialchars($selectedSchoolYear !== '' ? $selectedSchoolYear : 'All School Years') ?></div>
            </div>
            <div class="context-item">
                <div class="context-label">Date Coverage</div>
                <div class="context-value">
                    <?= htmlspecialchars(($dateFrom !== '' || $dateTo !== '') ? (($dateFrom !== '' ? $dateFrom : 'Start Open') . ' to ' . ($dateTo !== '' ? $dateTo : 'Present')) : 'All recorded dates') ?>
                </div>
            </div>
            <div class="context-item">
                <div class="context-label">As Of</div>
                <div class="context-value"><?= htmlspecialchars($reportAsOf) ?></div>
            </div>
        </div>
        <?php if ($activeFilterSummary): ?>
            <div class="filter-chip-list">
                <?php foreach ($activeFilterSummary as $filter): ?>
                    <span class="filter-chip"><?= htmlspecialchars($filter['label']) ?>: <?= htmlspecialchars($filter['value']) ?></span>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <form method="get" class="row g-3 mt-1">
            <div class="col-12 col-md-4">
                <label class="form-label">School year</label>
                <select name="school_year" class="form-select">
                    <option value="">All</option>
                    <?php foreach ($schoolYears as $option): ?>
                        <option value="<?= htmlspecialchars($option) ?>" <?= $selectedSchoolYear === $option ? 'selected' : '' ?>><?= htmlspecialchars($option) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Date from</label>
                <input type="date" name="date_from" class="form-control" value="<?= htmlspecialchars($dateFrom) ?>">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Date to</label>
                <input type="date" name="date_to" class="form-control" value="<?= htmlspecialchars($dateTo) ?>">
            </div>
            <div class="col-12 col-md-3">
                <label class="form-label">Student name</label>
                <input type="text" name="student_name" class="form-control" value="<?= htmlspecialchars($studentNameFilter) ?>" placeholder="Search by student name">
            </div>
            <div class="col-12 col-md-2">
                <label class="form-label">LRN</label>
                <input type="text" name="student_lrn" class="form-control" value="<?= htmlspecialchars($studentLrnFilter) ?>" placeholder="Search LRN">
            </div>
            <div class="col-12 col-md-12 d-flex gap-2 justify-content-end">
                <a href="/school-admin-dashboard/modules/reports/reports-finance.php" class="btn btn-outline-secondary"><i class="fas fa-rotate-left me-1"></i>Clear Filters</a>
                <button type="submit" class="btn btn-primary"><i class="fas fa-filter me-1"></i>Apply Filters</button>
            </div>
        </form>
    </div>

    <div class="summary-grid">
        <div class="summary-card"><div class="summary-label">Unpaid Students</div><div class="summary-value"><?= number_format((int) $summary['unpaid_students']) ?></div></div>
        <div class="summary-card"><div class="summary-label">Outstanding Balance</div><div class="summary-value"><?= htmlspecialchars(reports_money((float) $summary['outstanding_balance'])) ?></div></div>
        <div class="summary-card"><div class="summary-label">Recorded Payments</div><div class="summary-value"><?= number_format((int) $summary['recorded_payments']) ?></div></div>
        <div class="summary-card"><div class="summary-label">Collections Total</div><div class="summary-value"><?= htmlspecialchars(reports_money((float) $summary['collections_total'])) ?></div></div>
        <div class="summary-card"><div class="summary-label">Old Accounts</div><div class="summary-value"><?= number_format((int) $summary['old_account_count']) ?></div></div>
        <div class="summary-card"><div class="summary-label">Old Collections</div><div class="summary-value"><?= htmlspecialchars(reports_money((float) $summary['old_collections_total'])) ?></div></div>
    </div>

    <div class="table-card mb-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h3 class="h6 mb-0">Top Outstanding Balances</h3>
                <div class="section-note">Highest unpaid student balances in the current report view.</div>
            </div>
            <div class="d-flex align-items-center gap-2 flex-wrap">
                <span class="text-muted small"><?= count($outstandingRows) ?> row(s)</span>
                <button
                    type="button"
                    class="btn btn-outline-secondary btn-sm section-toggle"
                    data-bs-toggle="collapse"
                    data-bs-target="#topOutstandingCollapse"
                    aria-expanded="true"
                    aria-controls="topOutstandingCollapse"
                >
                    <i class="fas fa-chevron-down toggle-icon"></i> Toggle View
                </button>
            </div>
        </div>
        <div class="collapse show" id="topOutstandingCollapse">
        <div class="table-responsive">
            <table class="table align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Student</th>
                        <th>Grade</th>
                        <th>Section</th>
                        <th>Priority</th>
                        <th class="text-end">Outstanding</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($outstandingRows): ?>
                    <?php foreach ($outstandingRows as $row): ?>
                        <?php $priority = finance_outstanding_priority((float) $row['outstanding_balance']); ?>
                        <tr>
                            <td><?= htmlspecialchars((string) $row['student_name']) ?></td>
                            <td><?= htmlspecialchars((string) $row['grade']) ?></td>
                            <td><?= htmlspecialchars((string) $row['section']) ?></td>
                            <td>
                                <span class="priority-chip <?= htmlspecialchars($priority['class']) ?>"><?= htmlspecialchars($priority['label']) ?></span>
                                <span class="priority-detail"><?= htmlspecialchars($priority['detail']) ?></span>
                            </td>
                            <td class="text-end"><?= htmlspecialchars(reports_money((float) $row['outstanding_balance'])) ?></td>
                            <td class="text-end">
                                <a href="/school-admin-dashboard/modules/accounts/account-view.php?student_id=<?= (int) $row['student_id'] ?>&school_year=<?= rawurlencode($selectedSchoolYear) ?>&return_to=<?= rawurlencode($returnToFinanceReports) ?>" class="btn btn-sm btn-outline-primary">Open Finance Profile</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="6" class="text-center text-muted py-4">No outstanding balance records matched the active filters.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        </div>
    </div>

    <div class="table-card">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h3 class="h6 mb-0">Recent Payment Activity</h3>
                <div class="section-note">Latest posted payment groups within the selected school year and date coverage.</div>
            </div>
            <span class="text-muted small"><?= count($recentPayments) ?> row(s)</span>
        </div>
        <div class="table-responsive">
            <table class="table align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Date</th>
                        <th>Student</th>
                        <th>Fee Type</th>
                        <th>LRN</th>
                        <th class="text-end">Amount</th>
                        <th>Receipt</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($recentPayments): ?>
                    <?php $rowIndex = 0; ?>
                    <?php foreach ($recentPayments as $payment): ?>
                        <?php
                            $rowIndex++;
                            $collapseId = 'recent-breakdown-' . $rowIndex;
                            $itemsCount = (int) ($payment['items_count'] ?? 0);
                        ?>
                        <tr>
                            <td><?= htmlspecialchars((string) ($payment['date_paid'] ?? '')) ?></td>
                            <td><?= htmlspecialchars((string) ($payment['student_name'] ?? '')) ?></td>
                            <td>
                                <?php if ($itemsCount > 1): ?>
                                    <div class="d-flex align-items-center justify-content-between gap-2">
                                        <span><?= $itemsCount ?> items</span>
                                        <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="collapse" data-bs-target="#<?= $collapseId ?>" aria-expanded="false" aria-controls="<?= $collapseId ?>">
                                            View breakdown
                                        </button>
                                    </div>
                                <?php else: ?>
                                    <?= htmlspecialchars((string) ($payment['fee_type'] ?? '')) ?>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars((string) ($payment['lrn'] ?? '')) ?></td>
                            <td class="text-end"><?= htmlspecialchars(reports_money((float) ($payment['total_amount'] ?? 0))) ?></td>
                            <td>
                                <?php if (!empty($payment['receipt_no'])): ?>
                                    <?= htmlspecialchars((string) ($payment['booklet_no'] ?? '')) ?> / <?= htmlspecialchars((string) ($payment['receipt_no'] ?? '')) ?>
                                <?php else: ?>
                                    <span class="text-muted">No OR</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <a href="/school-admin-dashboard/modules/accounts/account-view.php?student_id=<?= (int) ($payment['student_id'] ?? 0) ?>&school_year=<?= rawurlencode($selectedSchoolYear) ?>&return_to=<?= rawurlencode($returnToFinanceReports) ?>" class="btn btn-sm btn-outline-primary">Open Finance Profile</a>
                            </td>
                        </tr>
                        <?php if ($itemsCount > 1): ?>
                            <tr class="collapse" id="<?= $collapseId ?>">
                                <td colspan="7" class="bg-light">
                                    <div class="p-2">
                                        <div class="fw-semibold mb-2">Receipt Breakdown</div>
                                        <div class="table-responsive">
                                            <table class="table table-sm mb-0">
                                                <thead>
                                                    <tr><th>Fee Type</th><th class="text-end">Amount</th></tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach (($payment['items'] ?? []) as $item): ?>
                                                        <tr>
                                                            <td><?= htmlspecialchars((string) ($item['fee_type'] ?? '')) ?></td>
                                                            <td class="text-end"><?= htmlspecialchars(reports_money((float) ($item['amount'] ?? 0))) ?></td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="7" class="text-center text-muted py-4">No payment activity records matched the active filters.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</div>
</body>
</html>
<?php $conn->close(); ?>
