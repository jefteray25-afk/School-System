<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require_once __DIR__ . '/../../includes/ui.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../settings/school-info-helper.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/reports-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

if (!hasPermission($_SESSION['role'] ?? '', 'reports', 'view')) {
    $blockedRole = (string) ($_SESSION['role'] ?? '');
    $blockedUser = (string) ($_SESSION['username'] ?? 'unknown');
    audit_log(
        $conn,
        $blockedUser,
        'Blocked student summary reports access',
        'Reports',
        'Role: ' . ($blockedRole !== '' ? $blockedRole : 'unknown') . ' | Reason: missing reports:view permission',
        'SECURITY'
    );
    admin_session_forbidden();
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    $conn = database_open_connection();
}

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$schoolYears = reports_school_year_options($conn);
$activeSchoolYear = school_year_get_active_label($conn);

$searchTerm = trim((string) ($_GET['search'] ?? ''));
$selectedSchoolYear = reports_safe_school_year((string) ($_GET['school_year'] ?? ''), $activeSchoolYear);
$studentId = (int) ($_GET['student_id'] ?? 0);
$studentCandidates = [];
$studentSummary = null;
$reportAsOf = reports_as_of_label();

if ($searchTerm !== '') {
    $studentCandidates = reports_find_students($conn, $searchTerm, $selectedSchoolYear, 15);
}

if ($studentId > 0) {
    $studentSummary = reports_student_summary($conn, $studentId, $selectedSchoolYear);
}
$activeFilterSummary = reports_filter_summary([
    'Search' => $searchTerm,
    'Student ID' => $studentId > 0 ? (string) $studentId : '',
]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Summary Report | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <?php ui_css_link(); ?>
    <style>
        body { background:#f5f8fc; font-family:'Segoe UI','Roboto','Arial',sans-serif; color:#23395d; }
        .navbar { background:#23395d !important; }
        .navbar-brand, .navbar-nav .nav-link { color:#fff !important; }
        .dashboard-header { text-align:center; margin-top:36px; margin-bottom:18px; }
        .dashboard-header img { width:70px; height:70px; object-fit:contain; margin-bottom:6px; }
        .dashboard-header h1 { font-size:1.3rem; color:#23395d; font-weight:700; margin-bottom:0; }
        .page-wrap { max-width:1180px; margin:0 auto; padding:0 12px 32px; }
        .panel, .summary-card, .table-card, .student-card {
            background:#fff;
            border:1px solid #dbe7f4;
            border-radius:18px;
            box-shadow:0 8px 22px rgba(35,57,93,.06);
        }
        .panel, .table-card, .student-card { padding:18px; }
        .summary-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:14px; margin-bottom:18px; }
        .summary-card { padding:14px 16px; }
        .summary-label { font-size:.76rem; text-transform:uppercase; letter-spacing:.06em; color:#607388; font-weight:700; }
        .summary-value { font-size:1.15rem; font-weight:800; color:#23395d; }
        .student-photo { width:120px; height:120px; object-fit:cover; border-radius:18px; border:1px solid #dbe7f4; background:#f8fbff; }
        .mini-label { font-size:.78rem; text-transform:uppercase; letter-spacing:.05em; color:#6c757d; font-weight:700; }
        .mini-value { font-weight:700; color:#23395d; }
        .status-chip { display:inline-flex; align-items:center; gap:6px; border-radius:999px; padding:4px 10px; font-size:.82rem; font-weight:700; }
        .status-good { background:#e8f7ef; color:#157347; }
        .status-warn { background:#fff4e5; color:#9a6700; }
        .status-danger { background:#fcebec; color:#b42318; }
        .table-card table { margin-bottom:0; }
        .collapse .table-sm td,
        .collapse .table-sm th { padding: 0.4rem 0.6rem; }
        .hint-list { margin:0; padding-left:1rem; color:#607388; }
        .hint-list li + li { margin-top:.3rem; }
        .context-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:12px; margin-top:16px; }
        .context-item { background:#f8fbff; border:1px solid #dbe7f4; border-radius:14px; padding:12px 14px; }
        .context-label { font-size:.74rem; text-transform:uppercase; letter-spacing:.06em; color:#607388; font-weight:700; }
        .context-value { font-size:.98rem; font-weight:700; color:#23395d; margin-top:4px; }
        .filter-chip-list { display:flex; flex-wrap:wrap; gap:8px; margin-top:10px; }
        .filter-chip { display:inline-flex; align-items:center; gap:6px; padding:6px 10px; border-radius:999px; background:#edf4fb; color:#23395d; border:1px solid #d9e3ef; font-size:.84rem; font-weight:700; }
        .section-note { color:#607388; font-size:.88rem; }
        .print-btn { white-space:nowrap; }
        .receipt-chip,
        .method-chip {
            display: inline-flex;
            align-items: center;
            border-radius: 999px;
            padding: 6px 12px;
            font-weight: 700;
            font-size: 0.86rem;
        }
        .receipt-chip {
            background:#edf4fb;
            color:#23395d;
        }
        .method-chip {
            background:#eef6ff;
            color:#0b5ed7;
        }
        .receipt-meta,
        .detail-meta {
            display:flex;
            flex-wrap:wrap;
            gap:8px;
        }
        @media print {
            body { background:#fff !important; color:#000 !important; font-size:12px; }
            .navbar, .dashboard-header, .btn, form, .print-hidden { display:none !important; }
            .page-wrap { max-width:none; margin:0; padding:0; }
            .panel, .summary-card, .table-card, .student-card, .context-item {
                box-shadow:none !important;
                border:1px solid #d0d7de !important;
                break-inside: avoid;
            }
            .summary-grid { gap:10px; }
            .table-card { margin-bottom:14px; }
            .student-photo { width:88px; height:88px; }
            a { color:#000 !important; text-decoration:none !important; }
        }
    </style>
</head>
<body>
<?php render_admin_nav('reports'); ?>
<?php render_school_page_header($schoolName, $schoolLogo); ?>

<div class="page-wrap">
    <div class="panel mb-3">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">
            <div>
                <h2 class="h4 mb-1"><i class="fas fa-user-graduate me-2"></i>Student Record Report</h2>
                <div class="text-muted">Search one student and review profile, requirements, active balances, and recent payments in one page.</div>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <a href="/school-admin-dashboard/modules/reports/reports-dashboard.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Back to Reports Center
                </a>
                <?php if ($studentId > 0): ?>
                <a href="/school-admin-dashboard/modules/reports/export-reports-student-summary.php?student_id=<?= (int) $studentId ?>&school_year=<?= rawurlencode($selectedSchoolYear) ?>" class="btn btn-success">
                    <i class="fas fa-file-excel me-1"></i>Download Excel
                </a>
                <?php else: ?>
                <button type="button" class="btn btn-success" disabled title="Select a student report first to enable Excel download">
                    <i class="fas fa-file-excel me-1"></i>Download Excel
                </button>
                <?php endif; ?>
                <button type="button" class="btn btn-outline-dark print-btn" onclick="window.print()">
                    <i class="fas fa-print me-1"></i>Print Report
                </button>
            </div>
        </div>
        <div class="context-grid">
            <div class="context-item">
                <div class="context-label">School Year</div>
                <div class="context-value"><?= htmlspecialchars($selectedSchoolYear !== '' ? $selectedSchoolYear : 'Student default / all') ?></div>
            </div>
            <div class="context-item">
                <div class="context-label">As Of</div>
                <div class="context-value"><?= htmlspecialchars($reportAsOf) ?></div>
            </div>
            <div class="context-item">
                <div class="context-label">Selection State</div>
                <div class="context-value"><?= $studentSummary ? 'Student report loaded' : ($searchTerm !== '' ? 'Search results only' : 'Waiting for student search') ?></div>
            </div>
        </div>
        <?php if ($activeFilterSummary): ?>
            <div class="filter-chip-list">
                <?php foreach ($activeFilterSummary as $filter): ?>
                    <span class="filter-chip"><?= htmlspecialchars($filter['label']) ?>: <?= htmlspecialchars($filter['value']) ?></span>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <form method="get" class="row g-3 mt-1">
            <div class="col-12 col-md-5">
                <label class="form-label">Search student</label>
                <input type="text" name="search" class="form-control" value="<?= htmlspecialchars($searchTerm) ?>" placeholder="Name, LRN, or Student ID">
            </div>
            <div class="col-12 col-md-4">
                <label class="form-label">School year</label>
                <select name="school_year" class="form-select">
                    <option value="">All / Student Default</option>
                    <?php foreach ($schoolYears as $option): ?>
                        <option value="<?= htmlspecialchars($option) ?>" <?= $selectedSchoolYear === $option ? 'selected' : '' ?>><?= htmlspecialchars($option) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 col-md-3 d-flex align-items-end">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-search me-1"></i>Apply Search
                </button>
            </div>
        </form>
    </div>

    <?php if ($searchTerm !== '' && $studentCandidates): ?>
        <div class="table-card mb-3">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h3 class="h6 mb-0">Search Matches</h3>
                <span class="text-muted small"><?= count($studentCandidates) ?> result(s)</span>
            </div>
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Student</th>
                            <th>LRN</th>
                            <th>Grade</th>
                            <th>Strand</th>
                            <th>Section</th>
                            <th>School Year</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($studentCandidates as $candidate): ?>
                        <tr>
                            <td><?= htmlspecialchars(trim(($candidate['lastname'] ?? '') . ', ' . ($candidate['firstname'] ?? '') . ' ' . ($candidate['middlename'] ?? ''))) ?></td>
                            <td><?= htmlspecialchars((string) ($candidate['lrn'] ?? '')) ?></td>
                            <td><?= htmlspecialchars((string) ($candidate['grade'] ?? '')) ?></td>
                            <td><?= htmlspecialchars((string) (($candidate['strand'] ?? '') !== '' ? $candidate['strand'] : 'N/A')) ?></td>
                            <td><?= htmlspecialchars((string) ($candidate['section'] ?? '')) ?></td>
                            <td><?= htmlspecialchars((string) ($candidate['school_year_label'] ?? '')) ?></td>
                            <td class="text-end">
                                <a class="btn btn-sm btn-outline-primary" href="/school-admin-dashboard/modules/reports/reports-student-summary.php?student_id=<?= (int) $candidate['id'] ?>&school_year=<?= rawurlencode($selectedSchoolYear) ?>&search=<?= rawurlencode($searchTerm) ?>">
                                    Open Summary
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php elseif ($searchTerm !== ''): ?>
        <div class="alert alert-warning">No student records matched the current search.</div>
    <?php endif; ?>

    <?php if ($studentId > 0 && !$studentSummary): ?>
        <div class="alert alert-danger">The student summary report could not be loaded for the selected record.</div>
    <?php endif; ?>

    <?php if ($studentSummary): ?>
        <?php $student = $studentSummary['student']; ?>
        <?php $summary = $studentSummary['summary']; ?>
        <?php $reqSummary = $studentSummary['requirement_summary']; ?>
        <?php $docSummary = $studentSummary['document_summary']; ?>
        <?php
            $groupedPayments = [];
            foreach (($studentSummary['payments'] ?? []) as $paymentRow) {
                $bookletNo = trim((string) ($paymentRow['booklet_no'] ?? ''));
                $receiptNo = trim((string) ($paymentRow['receipt_no'] ?? ''));
                $datePaid = (string) ($paymentRow['date_paid'] ?? '');
                $groupKey = ($bookletNo !== '' && $receiptNo !== '')
                    ? ($bookletNo . '-' . $receiptNo)
                    : ('noreceipt-' . $datePaid . '-' . (string) ($paymentRow['id'] ?? uniqid('pay', true)));

                if (!isset($groupedPayments[$groupKey])) {
                    $groupedPayments[$groupKey] = [
                        'date_paid' => $datePaid,
                        'booklet_no' => $bookletNo,
                        'receipt_no' => $receiptNo,
                        'receipt_note' => (string) ($paymentRow['receipt_note'] ?? ''),
                        'remarks' => (string) ($paymentRow['remarks'] ?? ''),
                        'items' => [],
                        'items_count' => 0,
                        'total_amount' => 0.0,
                    ];
                }

                $groupedPayments[$groupKey]['items'][] = [
                    'fee_type' => (string) ($paymentRow['fee_type'] ?? 'Uncategorized'),
                    'amount' => (float) ($paymentRow['amount'] ?? 0),
                    'remarks' => (string) ($paymentRow['remarks'] ?? ''),
                ];
                $groupedPayments[$groupKey]['items_count']++;
                $groupedPayments[$groupKey]['total_amount'] += (float) ($paymentRow['amount'] ?? 0);

                if ($groupedPayments[$groupKey]['remarks'] === '' && ($paymentRow['remarks'] ?? '') !== '') {
                    $groupedPayments[$groupKey]['remarks'] = (string) $paymentRow['remarks'];
                }
                if ($groupedPayments[$groupKey]['receipt_note'] === '' && ($paymentRow['receipt_note'] ?? '') !== '') {
                    $groupedPayments[$groupKey]['receipt_note'] = (string) $paymentRow['receipt_note'];
                }
            }
            $groupedPayments = array_values($groupedPayments);
        ?>

        <div class="student-card mb-3">
            <div class="row g-4 align-items-center">
                <div class="col-12 col-md-auto text-center">
                    <img src="<?= htmlspecialchars($student['photo_url']) ?>" alt="Student Photo" class="student-photo">
                </div>
                <div class="col">
                    <h3 class="h4 mb-1"><?= htmlspecialchars((string) $student['full_name']) ?></h3>
                    <div class="text-muted mb-3">Student ID #<?= (int) $student['id'] ?> | School Year: <?= htmlspecialchars((string) $studentSummary['selected_school_year']) ?></div>
                    <div class="row g-3">
                        <div class="col-6 col-md-3"><div class="mini-label">Grade</div><div class="mini-value"><?= htmlspecialchars((string) ($student['grade'] ?? '')) ?></div></div>
                        <div class="col-6 col-md-3"><div class="mini-label">Strand</div><div class="mini-value"><?= htmlspecialchars((string) (($student['strand'] ?? '') !== '' ? $student['strand'] : 'N/A')) ?></div></div>
                        <div class="col-6 col-md-3"><div class="mini-label">Section</div><div class="mini-value"><?= htmlspecialchars((string) ($student['section'] ?? '')) ?></div></div>
                        <div class="col-6 col-md-3"><div class="mini-label">LRN</div><div class="mini-value"><?= htmlspecialchars((string) (($student['lrn'] ?? '') !== '' ? $student['lrn'] : 'Not Set')) ?></div></div>
                        <div class="col-6 col-md-3"><div class="mini-label">Date Enrolled</div><div class="mini-value"><?= htmlspecialchars((string) (($student['date_enrolled'] ?? '') !== '' ? $student['date_enrolled'] : '-')) ?></div></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="summary-grid">
            <div class="summary-card"><div class="summary-label">Total Assessed</div><div class="summary-value"><?= htmlspecialchars(reports_money((float) $summary['assessed'])) ?></div></div>
            <div class="summary-card"><div class="summary-label">Total Paid</div><div class="summary-value"><?= htmlspecialchars(reports_money((float) $summary['paid'])) ?></div></div>
            <div class="summary-card"><div class="summary-label">Remaining Balance</div><div class="summary-value"><?= htmlspecialchars(reports_money((float) $summary['balance'])) ?></div></div>
            <div class="summary-card"><div class="summary-label">Recorded Payments</div><div class="summary-value"><?= number_format((int) $summary['payment_count']) ?></div></div>
            <div class="summary-card"><div class="summary-label">Requirements Submitted</div><div class="summary-value"><?= number_format((int) ($reqSummary['submitted'] ?? 0)) ?>/<?= number_format((int) ($reqSummary['total'] ?? 0)) ?></div></div>
            <div class="summary-card"><div class="summary-label">Files Uploaded</div><div class="summary-value"><?= number_format((int) ($docSummary['uploaded'] ?? 0)) ?>/<?= number_format((int) (($docSummary['uploaded'] ?? 0) + ($docSummary['missing'] ?? 0))) ?></div></div>
        </div>

        <div class="row g-3 mt-1">
            <div class="col-12 col-lg-6">
                <div class="table-card h-100">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h3 class="h6 mb-0">Requirements Snapshot</h3>
                            <div class="section-note">Current submission and follow-up status for required student documents.</div>
                        </div>
                        <?php
                            $reqClass = ((int) ($reqSummary['missing'] ?? 0) === 0 && (int) ($reqSummary['to_follow'] ?? 0) === 0) ? 'status-good' : (((int) ($reqSummary['submitted'] ?? 0) > 0) ? 'status-warn' : 'status-danger');
                        ?>
                        <span class="status-chip <?= $reqClass ?>">
                            <?= htmlspecialchars((string) ($reqSummary['coverage_label'] ?? '')) ?>
                        </span>
                    </div>
                    <ul class="hint-list">
                        <li>Missing: <?= number_format((int) ($reqSummary['missing'] ?? 0)) ?></li>
                        <li>To Follow: <?= number_format((int) ($reqSummary['to_follow'] ?? 0)) ?></li>
                        <li>Uploaded Files: <?= number_format((int) ($docSummary['uploaded'] ?? 0)) ?></li>
                    </ul>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div class="table-card h-100">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h3 class="h6 mb-0">Quick Links</h3>
                            <div class="section-note">Open related student, finance, and statement pages from this report.</div>
                        </div>
                    </div>
                    <div class="d-flex flex-wrap gap-2">
                        <a class="btn btn-outline-primary btn-sm" href="/school-admin-dashboard/modules/students/student-view.php?id=<?= (int) $student['id'] ?>">Open Student View</a>
                        <a class="btn btn-outline-primary btn-sm" href="/school-admin-dashboard/modules/accounts/account-view.php?student_id=<?= (int) $student['id'] ?>&school_year=<?= rawurlencode((string) $studentSummary['selected_school_year']) ?>">Open Account View</a>
                        <a class="btn btn-outline-primary btn-sm" href="/school-admin-dashboard/modules/accounts/account-statement-of-account.php?student_id=<?= (int) $student['id'] ?>&school_year=<?= rawurlencode((string) $studentSummary['selected_school_year']) ?>">Open Statement</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="table-card mt-3">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    <h3 class="h6 mb-0">Account Breakdown</h3>
                    <div class="section-note">Assessed amounts, recorded payments, and current balances by fee type.</div>
                </div>
                <span class="text-muted small"><?= number_format((int) $summary['account_count']) ?> account row(s)</span>
            </div>
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Fee Type</th>
                            <th class="text-end">Assessed</th>
                            <th class="text-end">Paid</th>
                            <th class="text-end">Balance</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($studentSummary['accounts']): ?>
                        <?php foreach ($studentSummary['accounts'] as $account): ?>
                            <?php $isPaid = (float) $account['balance'] <= 0.009; ?>
                            <tr>
                                <td><?= htmlspecialchars((string) $account['type']) ?></td>
                                <td class="text-end"><?= htmlspecialchars(reports_money((float) $account['assessed_amount'])) ?></td>
                                <td class="text-end"><?= htmlspecialchars(reports_money((float) $account['total_paid'])) ?></td>
                                <td class="text-end"><?= htmlspecialchars(reports_money((float) $account['balance'])) ?></td>
                                <td>
                                    <span class="status-chip <?= $isPaid ? 'status-good' : (((float) $account['total_paid'] > 0) ? 'status-warn' : 'status-danger') ?>">
                                        <?= $isPaid ? 'Paid' : (((float) $account['total_paid'] > 0) ? 'Partial' : 'Outstanding') ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="text-center text-muted py-4">No account records were found for this student under the selected school year.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="table-card mt-3">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    <h3 class="h6 mb-0">Recent Payments</h3>
                    <div class="section-note">Latest payment groups for the selected student and school year. One receipt or transaction appears as one row, with breakdown available when multiple fee items were posted together.</div>
                </div>
                <span class="text-muted small"><?= number_format(count($groupedPayments)) ?> grouped row(s)</span>
            </div>
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Date</th>
                            <th>Fee Type</th>
                            <th class="text-end">Amount</th>
                            <th>Receipt</th>
                            <th>Remarks</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($groupedPayments): ?>
                        <?php $paymentRowIndex = 0; ?>
                        <?php foreach ($groupedPayments as $payment): ?>
                            <?php
                                $paymentRowIndex++;
                                $itemsCount = (int) ($payment['items_count'] ?? 0);
                                $collapseId = 'student-payment-breakdown-' . $paymentRowIndex;
                                $firstItem = $payment['items'][0] ?? null;
                            ?>
                            <tr>
                                <td><?= htmlspecialchars((string) ($payment['date_paid'] ?? '')) ?></td>
                                <td>
                                    <?php if ($itemsCount > 1): ?>
                                        <div class="fw-semibold"><?= htmlspecialchars((string) $itemsCount) ?> fee items in one transaction</div>
                                        <div class="text-muted small">Grouped by receipt / transaction</div>
                                    <?php elseif ($firstItem): ?>
                                        <?= htmlspecialchars((string) ($firstItem['fee_type'] ?? '')) ?>
                                    <?php else: ?>
                                        <span class="text-muted">Uncategorized</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end"><?= htmlspecialchars(reports_money((float) ($payment['total_amount'] ?? 0))) ?></td>
                                <td>
                                    <div class="receipt-meta">
                                        <?php if (!empty($payment['receipt_no'])): ?>
                                            <span class="receipt-chip"><?= htmlspecialchars((string) ($payment['booklet_no'] ?? '')) ?> / <?= htmlspecialchars((string) ($payment['receipt_no'] ?? '')) ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">No OR</span>
                                        <?php endif; ?>
                                        <?php if (!empty($payment['receipt_note'])): ?>
                                            <span class="method-chip"><?= htmlspecialchars((string) $payment['receipt_note']) ?></span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td><?= htmlspecialchars((string) (($payment['remarks'] ?? '') !== '' ? $payment['remarks'] : '-')) ?></td>
                                <td class="text-end">
                                    <?php if ($itemsCount > 1): ?>
                                        <button class="btn btn-sm btn-outline-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#<?= htmlspecialchars($collapseId) ?>" aria-expanded="false" aria-controls="<?= htmlspecialchars($collapseId) ?>">
                                            View breakdown
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php if ($itemsCount > 1): ?>
                                <tr class="collapse bg-light" id="<?= htmlspecialchars($collapseId) ?>">
                                    <td colspan="6">
                                        <div class="p-2">
                                            <div class="text-muted small mb-2">Transaction fee-item breakdown</div>
                                            <div class="table-responsive">
                                                <table class="table table-sm align-middle mb-0">
                                                    <thead class="table-light">
                                                        <tr>
                                                            <th>Fee Type</th>
                                                            <th class="text-end">Amount</th>
                                                            <th>Remarks</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php foreach (($payment['items'] ?? []) as $item): ?>
                                                        <tr>
                                                            <td><?= htmlspecialchars((string) ($item['fee_type'] ?? 'Uncategorized')) ?></td>
                                                            <td class="text-end"><?= htmlspecialchars(reports_money((float) ($item['amount'] ?? 0))) ?></td>
                                                            <td><?= htmlspecialchars((string) (($item['remarks'] ?? '') !== '' ? $item['remarks'] : '-')) ?></td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="6" class="text-center text-muted py-4">No recorded payment entries were found for this student under the selected school year.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
