<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require '../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';

$currentRole = $_SESSION['role'] ?? '';
if (!hasPermission($currentRole, 'student_data', 'delete')) {
    admin_session_forbidden();
}

admin_csrf_token();

function h($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$returnUrl = $_SESSION['old_student_list_return_url'] ?? 'student-old-account-list.php';
$selectedIds = array_values(array_unique(array_map('intval', $_POST['selected_ids'] ?? [])));
$selectedIds = array_values(array_filter($selectedIds, fn($id) => $id > 0));
$error = '';
$students = [];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: student-old-account-list.php');
    exit();
}

admin_require_post_csrf();

if (!$error && empty($selectedIds)) {
    $error = 'No old student records were selected.';
}

if (!$error) {
    $placeholders = implode(',', array_fill(0, count($selectedIds), '?'));
    $types = str_repeat('i', count($selectedIds));
    $stmt = $conn->prepare("SELECT id, lastname, firstname, middlename, status, school_year FROM old_students WHERE id IN ($placeholders) ORDER BY lastname ASC, firstname ASC");
    $stmt->bind_param($types, ...$selectedIds);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $students[] = $row;
    }
    $stmt->close();

    if (empty($students)) {
        $error = 'The selected old student records could not be found.';
    }
}

if (!$error && isset($_POST['confirm_bulk_delete'])) {
    $confirmPhrase = trim((string) ($_POST['confirm_phrase'] ?? ''));
    if ($confirmPhrase !== 'DELETE') {
        $error = 'Type DELETE before bulk deleting old student records.';
    }
}

if (!$error && isset($_POST['confirm_bulk_delete'])) {
    $user = $_SESSION['username'] ?? 'unknown';
    $deletedCount = 0;
    foreach ($students as $student) {
        $deleteStmt = $conn->prepare("DELETE FROM old_students WHERE id = ?");
        $deleteStmt->bind_param('i', $student['id']);
        $deleteStmt->execute();
        $deleteStmt->close();
        $deletedCount++;
    }

    include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');
    $details = 'Deleted ' . $deletedCount . ' old student record(s) in bulk | Role: ' . ($_SESSION['role'] ?? 'unknown') . ' | Deleted by: ' . $user;
    audit_log($conn, $user, 'Bulk deleted old student records', 'Old Accounts', $details);

    header('Location: student-old-account-list.php?bulk_deleted=' . $deletedCount);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Bulk Delete Old Students</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #eef3f9; font-family: 'Segoe UI', Arial, sans-serif; }
        .confirm-card {
            max-width: 860px;
            margin: 48px auto;
            background: #fff;
            border: 1px solid #d9e3ef;
            border-radius: 20px;
            box-shadow: 0 14px 32px rgba(35,57,93,0.07);
            overflow: hidden;
        }
        .confirm-header {
            background: linear-gradient(135deg, #23395d, #517fa4);
            color: #fff;
            padding: 18px 22px;
            font-weight: 800;
        }
        .record-list li { padding: 10px 0; border-bottom: 1px solid #eef3f8; }
        .record-list li:last-child { border-bottom: 0; }
    </style>
</head>
<body>
<div class="confirm-card">
    <div class="confirm-header">Bulk Delete Old Students</div>
    <div class="p-4">
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= h($error) ?></div>
            <a href="<?= h($returnUrl) ?>" class="btn btn-secondary">Back to Old Student List</a>
        <?php else: ?>
            <div class="alert alert-danger">
                <strong>Warning:</strong> You are about to permanently delete <strong><?= number_format(count($students)) ?></strong> old student record(s).
            </div>
            <ul class="list-unstyled record-list mb-4">
                <?php foreach ($students as $student): ?>
                    <li>
                        <strong><?= h($student['lastname'] . ', ' . $student['firstname'] . ' ' . $student['middlename']) ?></strong>
                        <span class="text-muted ms-2">Status: <?= h($student['status'] ?: '-') ?></span>
                        <span class="text-muted ms-2">School Year: <?= h($student['school_year'] ?: '-') ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= h(admin_csrf_token()) ?>">
                <?php foreach ($students as $student): ?>
                    <input type="hidden" name="selected_ids[]" value="<?= (int) $student['id'] ?>">
                <?php endforeach; ?>
                <div class="mb-3" style="max-width: 260px;">
                    <label class="form-label fw-semibold">Type DELETE to confirm</label>
                    <input type="text" name="confirm_phrase" class="form-control" required autocomplete="off">
                </div>
                <button type="submit" name="confirm_bulk_delete" class="btn btn-danger">
                    Yes, Delete Selected
                </button>
                <a href="<?= h($returnUrl) ?>" class="btn btn-secondary ms-2">Cancel</a>
            </form>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
