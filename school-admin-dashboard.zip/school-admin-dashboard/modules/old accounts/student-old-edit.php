<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require '../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/settings-security.php';
require_once __DIR__ . '/old-account-followup-helper.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php';

// Check edit permission
$user_role = $_SESSION['role'] ?? '';
if (!hasPermission($user_role, 'student_data', 'edit')) {
    admin_session_forbidden("Access denied. You do not have permission to edit old student records.");
}
ensure_old_student_followup_columns($conn);
$follow_up_options = old_account_followup_options();

// School year dropdown options
$school_years = [];
for ($sy = 2010; $sy <= 2029; $sy++) {
    $school_years[] = $sy . '-' . ($sy+1);
}

// Get student id
$student_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$student_id) {
    die("Invalid student ID.");
}

// Fetch old student record
$stmt = $conn->prepare("SELECT * FROM old_students WHERE id=?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$student) {
    die("Student not found.");
}

// Handle form submission
$error = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    admin_require_post_csrf();
    $lastname    = trim($_POST["lastname"] ?? '');
    $firstname   = trim($_POST["firstname"] ?? '');
    $middlename  = trim($_POST["middlename"] ?? '');
    $contact     = trim($_POST["contact"] ?? '');
    $status      = trim($_POST["status"] ?? '');
    $school_year = trim($_POST["school_year"] ?? '');
    $notes       = trim($_POST["notes"] ?? '');
    $follow_up_status = trim($_POST["follow_up_status"] ?? 'record_only');
    $follow_up_note = trim($_POST["follow_up_note"] ?? '');

    $contact_pattern = '/^09\d{2}-\d{3}-\d{4}$/';
    $name_pattern = "/^[A-Za-z][A-Za-z .'-]*$/";

    if (!$lastname || !$firstname || !$status || !$school_year) {
        $error = "Last Name, First Name, Status, and School Year are required.";
    } elseif (!in_array($school_year, $school_years, true)) {
        $error = "Invalid school year selected.";
    } elseif (!preg_match($name_pattern, $lastname) || !preg_match($name_pattern, $firstname) || ($middlename !== '' && !preg_match($name_pattern, $middlename))) {
        $error = "Name fields may only contain letters, spaces, apostrophes, periods, and hyphens.";
    } elseif ($contact && !preg_match($contact_pattern, $contact)) {
        $error = "Contact number format must be 09xx-xxx-xxxx.";
    } elseif (!isset($follow_up_options[$follow_up_status])) {
        $error = "Invalid follow-up status selected.";
    } else {
        $stmt = $conn->prepare("UPDATE old_students SET lastname=?, firstname=?, middlename=?, contact=?, status=?, school_year=?, notes=?, follow_up_status=?, follow_up_note=? WHERE id=?");
        $stmt->bind_param("sssssssssi", $lastname, $firstname, $middlename, $contact, $status, $school_year, $notes, $follow_up_status, $follow_up_note, $student_id);
        if ($stmt->execute()) {
            $stmt->close();

            // ---------- AUDIT LOGGING: Edit Old Student ----------
            include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');
            $user = $_SESSION['username'] ?? 'unknown';
            $action = "Edited old student record";
            $module = "Old Accounts";
            $details = "Role: " . ($_SESSION['role'] ?? 'unknown') .
                       " | Old Student ID: " . $student_id .
                       " | Last Name: " . $lastname .
                       " | First Name: " . $firstname .
                       " | Middle Name: " . $middlename .
                       " | Status: " . $status .
                       " | School Year: " . $school_year .
                       " | Follow-up: " . old_account_followup_label($follow_up_status) .
                       " | Edited by: " . $user;
            audit_log($conn, $user, $action, $module, $details);

            header("Location: /school-admin-dashboard/modules/old accounts/student-old-account-list.php#archive-list");
            exit();
        } else {
            $error = "Error: Could not update old student.";
            $stmt->close();
        }
    }
} else {
    // Pre-fill form with existing values
    $lastname    = $student['lastname'] ?? '';
    $firstname   = $student['firstname'] ?? '';
    $middlename  = $student['middlename'] ?? '';
    $contact     = $student['contact'] ?? '';
    $status      = $student['status'] ?? '';
    $school_year = $student['school_year'] ?? '';
    $notes       = $student['notes'] ?? '';
    $follow_up_status = $student['follow_up_status'] ?? 'record_only';
    $follow_up_note = $student['follow_up_note'] ?? '';
}
ensure_csrf_token();
$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Old Student | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body {
            background: var(--main-bg);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        }
        body.dark-mode {
            --main-bg: #1b232d;
            --card-bg: #23395d;
            --navbar-bg: #161b22;
            color: #e6edf3;
        }
        .navbar {
            background: var(--navbar-bg) !important;
            box-shadow: 0 2px 12px rgba(33,57,93,0.08);
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.08em;
        }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .theme-toggle-btn {
            background: none;
            border: none;
            color: #fff;
            font-size: 1.45em;
            margin-left: 12px;
            cursor: pointer;
        }
        .header-section {
            text-align: center;
            margin-top: 36px;
            margin-bottom: 18px;
        }
        .header-section img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            margin-bottom: 6px;
        }
        .header-section h1 {
            font-size: 1.3rem;
            color: var(--brand-dark);
            font-weight: 700;
            margin-bottom: 0;
            letter-spacing: 0.02em;
        }
        .edit-card {
            background: var(--card-bg);
            border-radius: 1rem;
            box-shadow: 0 4px 18px rgba(33,57,93,0.09), 0 1.5px 3px rgba(33,57,93,0.07);
            margin: 0 auto;
            margin-top: 18px;
            margin-bottom: 32px;
            padding-top: 1.2rem;
            padding-bottom: 1.3rem;
            max-width: 700px;
        }
        .card-header {
            background: #ffe599 !important;
            color: #23395d !important;
            font-size: 1.11em;
            font-weight: 500;
        }
        .form-label {
            color: #23395d;
            font-weight: 500;
            margin-bottom: 4px;
        }
        .btn-warning {
            background: #ffe599;
            color: #23395d;
            font-weight: 500;
            border: 1px solid #bcdfff;
            border-radius: 7px;
            padding: 7px 18px;
            font-size: 1.03em;
        }
        .btn-warning:hover, .btn-warning:focus {
            background: #517fa4;
            color: #fff;
            border-color: #517fa4;
        }
        .btn-secondary {
            background: #e7f0fd;
            color: #23395d;
            border: 1px solid #bcdfff;
            font-weight: 500;
            border-radius: 7px;
            padding: 7px 18px;
            font-size: 1.03em;
            margin-left: 7px;
        }
        .btn-secondary:hover, .btn-secondary:focus {
            background: #517fa4;
            color: #fff;
            border-color: #517fa4;
        }
        .dashboard-btn-bottom {
            position: fixed;
            left: 28px;
            bottom: 28px;
            z-index: 1060;
            background: #e7f0fd;
            color: #517fa4;
            border: 2px solid #bcdfff;
            box-shadow: 0 5px 16px rgba(33,57,93,0.13);
            border-radius: 50%;
            width: 58px;
            height: 58px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.55em;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
            text-decoration: none;
        }
        .dashboard-btn-bottom:hover, .dashboard-btn-bottom:focus {
            background: #fff2b3;
            color: #517fa4;
            border-color: #ffe599;
        }
        @media (max-width: 900px) {
            .edit-card { padding: 0.6rem 0.2rem; max-width: 99vw;}
        }
        @media (max-width: 600px) {
            .header-section h1 { font-size: 1rem; }
            .edit-card { margin-top: 7px; margin-bottom: 14px; }
            .dashboard-btn-bottom { left: 12px; bottom: 12px; width: 45px; height: 45px; font-size: 1.15em;}
            .btn-warning, .btn-secondary { font-size: 0.97em; padding: 6px 10px;}
        }
    </style>
</head>
<body>
<?php render_admin_nav('old_accounts', true); ?>
<!-- Dashboard Header -->
<div class="header-section">
    <img src="/school-admin-dashboard/uploads/logo1.png" alt="School Logo" class="mb-2 rounded shadow-sm">
    <h1><?= $schoolName ?></h1>
</div>
<!-- Edit Old Student Card -->
<div class="container edit-card px-3">
    <div class="card">
        <div class="card-header">
            <i class="fas fa-user-edit"></i> Old Student Edit Form
        </div>
        <div class="card-body">
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="post" action="" autocomplete="off">
                <?= csrf_input() ?>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Last Name:</label>
                        <input type="text" class="form-control" name="lastname" value="<?= htmlspecialchars($lastname) ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">First Name:</label>
                        <input type="text" class="form-control" name="firstname" value="<?= htmlspecialchars($firstname) ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Middle Name <span class="text-muted">(optional)</span>:</label>
                        <input type="text" class="form-control" name="middlename" value="<?= htmlspecialchars($middlename) ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Contact Number <span class="text-muted">(optional, format: 09xx-xxx-xxxx)</span>:</label>
                        <input type="text" class="form-control" name="contact" id="contactField" value="<?= htmlspecialchars($contact) ?>" placeholder="09xx-xxx-xxxx" maxlength="13">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Status:</label>
                        <select class="form-select" name="status" required>
                            <option value="">Select Status</option>
                            <option value="withdrawn" <?= $status=="withdrawn"?"selected":"" ?>>Withdrawn</option>
                            <option value="graduated" <?= $status=="graduated"?"selected":"" ?>>Graduated</option>
                            <option value="transferred" <?= $status=="transferred"?"selected":"" ?>>Transferred</option>
                            <option value="active" <?= $status=="active"?"selected":"" ?>>Active</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">School Year:</label>
                        <select class="form-select" name="school_year" required>
                            <option value="">Select School Year</option>
                            <?php foreach ($school_years as $sy): ?>
                                <option value="<?= $sy ?>" <?= ($school_year==$sy)?"selected":"" ?>><?= $sy ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-12">
                        <label class="form-label">Reason / Notes <span class="text-muted">(optional)</span>:</label>
                        <input type="text" class="form-control" name="notes" value="<?= htmlspecialchars($notes) ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Follow-up Status:</label>
                        <select class="form-select" name="follow_up_status">
                            <?php foreach ($follow_up_options as $option_value => $option_label): ?>
                                <option value="<?= htmlspecialchars($option_value) ?>" <?= $follow_up_status === $option_value ? 'selected' : '' ?>><?= htmlspecialchars($option_label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Follow-up Note <span class="text-muted">(optional)</span>:</label>
                        <input type="text" class="form-control" name="follow_up_note" value="<?= htmlspecialchars($follow_up_note) ?>" placeholder="Office follow-up or clearance note">
                    </div>
                </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-warning"><i class="fas fa-save"></i> Update Student</button>
                    <a href="/school-admin-dashboard/modules/old accounts/student-old-account-list.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Floating Dashboard Button (left side) -->
<a href="/school-admin-dashboard/dashboard.php" class="dashboard-btn-bottom" title="Go to Dashboard">
    <i class="fas fa-tachometer-alt"></i>
</a>
<footer class="text-center py-4 text-muted small">
    &copy; <?= date("Y") ?> <?= $schoolName ?> | School Admin Dashboard
</footer>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const contactInput = document.getElementById('contactField');
    if (!contactInput) return;
    contactInput.addEventListener('input', function(e) {
        let digits = contactInput.value.replace(/\D/g, '');
        if (digits.length > 11) digits = digits.slice(0, 11);
        let formatted = '';
        if (digits.length > 0) {
            formatted += digits.substring(0, 4); // 09xx
        }
        if (digits.length > 4) {
            formatted += '-' + digits.substring(4, 7); // xxx
        }
        if (digits.length > 7) {
            formatted += '-' + digits.substring(7, 11); // xxxx
        }
        contactInput.value = formatted;
    });
    contactInput.addEventListener('keypress', function(e) {
        if (!/[0-9]/.test(e.key) && !['Backspace', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(e.key)) {
            e.preventDefault();
        }
    });
    // Theme toggle
    document.getElementById('themeToggleBtn').addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        this.querySelector('i').classList.toggle('fa-moon');
        this.querySelector('i').classList.toggle('fa-sun');
    });
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
