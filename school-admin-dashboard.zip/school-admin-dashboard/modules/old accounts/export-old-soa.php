<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();

require __DIR__ . '/../../vendor/autoload.php';
require __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../audit/audit-helper.php';
require_once __DIR__ . '/old-account-followup-helper.php';
require_once __DIR__ . '/../../includes/receipt-payment-method-helper.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Color;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;

$role = $_SESSION['role'] ?? '';
if (!hasPermission($role, 'financial', 'export')) {
    admin_session_forbidden();
}

ensure_old_student_followup_columns($conn);
$hasOldAnchorColumn = old_account_column_exists($conn, 'old_anchor_id');

$linkedStudentId = isset($_GET['student_id']) ? (int) ($_GET['student_id'] ?? 0) : 0;
$oldAnchorId = isset($_GET['old_anchor_id']) ? (int) ($_GET['old_anchor_id'] ?? 0) : 0;

if ($linkedStudentId <= 0 && $oldAnchorId <= 0) {
    http_response_code(400);
    exit('Invalid SOA export source.');
}

function old_soa_flush_xlsx(string $filename, Xlsx $writer): void
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: max-age=0, no-cache, must-revalidate');
    header('Pragma: public');
    header('Expires: 0');

    $writer->save('php://output');
}

function sheet_style_header_row(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet, int $row, array $headers): void
{
    $col = 1;
    foreach ($headers as $header) {
        $sheet->setCellValue(sheet_cell_ref($col, $row), $header);
        $col++;
    }

    $lastCol = count($headers);
    $range = sheet_cell_ref(1, $row) . ':' . sheet_cell_ref($lastCol, $row);
    $sheet->getStyle($range)->getFont()->setBold(true)->getColor()->setARGB('FFFFFFFF');
    $sheet->getStyle($range)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FF203A5F');
    $sheet->getStyle($range)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER)->setVertical(Alignment::VERTICAL_CENTER);
    $sheet->getStyle($range)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN)->getColor()->setARGB('FFD9E3EF');
    $sheet->getStyle($range)->getAlignment()->setWrapText(true);
    $sheet->getRowDimension($row)->setRowHeight(24);
}

function sheet_cell_ref(int $col, int $row): string
{
    return Coordinate::stringFromColumnIndex($col) . (string) $row;
}

function sheet_autosize_columns(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet, int $maxCol): void
{
    for ($i = 1; $i <= $maxCol; $i++) {
        $sheet->getColumnDimension(Coordinate::stringFromColumnIndex($i))->setAutoSize(true);
    }
}

function sheet_apply_workbook_defaults(Spreadsheet $spreadsheet): void
{
    $spreadsheet->getDefaultStyle()->getFont()->setName('Calibri')->setSize(11);
}

function sheet_style_title(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet, string $range): void
{
    $sheet->getStyle($range)->getFont()->setBold(true)->setSize(16)->getColor()->setARGB('FF16324F');
    $sheet->getStyle($range)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER)->setVertical(Alignment::VERTICAL_CENTER);
    $sheet->getStyle($range)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFF4F8FC');
    $sheet->getStyle($range)->getBorders()->getOutline()->setBorderStyle(Border::BORDER_THIN)->getColor()->setARGB('FFD9E3EF');
}

function sheet_style_meta_pair(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet, string $labelCell, string $valueCell): void
{
    $sheet->getStyle($labelCell)->getFont()->setBold(true)->getColor()->setARGB('FF5F7186');
    $sheet->getStyle($valueCell)->getFont()->setBold(false)->getColor()->setARGB('FF203A5F');
}

function sheet_style_section_heading(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet, string $range): void
{
    $sheet->getStyle($range)->getFont()->setBold(true)->setSize(12)->getColor()->setARGB('FF203A5F');
    $sheet->getStyle($range)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFEAF1F8');
    $sheet->getStyle($range)->getBorders()->getOutline()->setBorderStyle(Border::BORDER_THIN)->getColor()->setARGB('FFD9E3EF');
}

function sheet_style_table_body(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet, int $startRow, int $endRow, int $maxCol): void
{
    if ($endRow < $startRow) {
        return;
    }

    for ($row = $startRow; $row <= $endRow; $row++) {
        $range = sheet_cell_ref(1, $row) . ':' . sheet_cell_ref($maxCol, $row);
        $fill = ($row % 2 === 0) ? 'FFF9FBFD' : 'FFFFFFFF';
        $sheet->getStyle($range)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB($fill);
        $sheet->getStyle($range)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN)->getColor()->setARGB('FFE4EAF1');
        $sheet->getStyle($range)->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
    }
}

function sheet_style_total_row(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet, string $range): void
{
    $sheet->getStyle($range)->getFont()->setBold(true)->getColor()->setARGB('FF16324F');
    $sheet->getStyle($range)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFF2F7FB');
    $sheet->getStyle($range)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN)->getColor()->setARGB('FFD9E3EF');
}

function sheet_style_kpi_card(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet, string $labelCell, string $valueCell): void
{
    $range = $labelCell . ':' . $valueCell;
    $sheet->getStyle($range)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFF7FAFD');
    $sheet->getStyle($range)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN)->getColor()->setARGB('FFD9E3EF');
    $sheet->getStyle($labelCell)->getFont()->setBold(true)->getColor()->setARGB('FF5F7186');
    $sheet->getStyle($valueCell)->getFont()->setBold(true)->setSize(12)->getColor()->setARGB('FF16324F');
}

function sheet_format_currency(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet, string $range): void
{
    $sheet->getStyle($range)->getNumberFormat()->setFormatCode('#,##0.00');
}

function old_soa_year_totals(mysqli $conn, array $records, mysqli_stmt $feeTotalStmt, mysqli_stmt $payTotalStmt): array
{
    $remainingBalance = 0.0;
    $totalPaid = 0.0;

    foreach ($records as $rec) {
        $oldId = (int) ($rec['id'] ?? 0);
        if ($oldId <= 0) {
            continue;
        }

        $feeTotalStmt->bind_param('i', $oldId);
        $feeTotalStmt->execute();
        $feeRow = $feeTotalStmt->get_result()->fetch_assoc();
        $remainingBalance += (float) ($feeRow['total_balance'] ?? 0);

        $payTotalStmt->bind_param('i', $oldId);
        $payTotalStmt->execute();
        $payRow = $payTotalStmt->get_result()->fetch_assoc();
        $totalPaid += (float) ($payRow['total_paid'] ?? 0);
    }

    return [
        'remaining_balance' => $remainingBalance,
        'total_paid' => $totalPaid,
    ];
}

$studentName = '';
$studentGrade = '';
$studentLrn = '';
$exportIdentityLabel = '';
$oldRecords = [];

if ($linkedStudentId > 0) {
    // Load current student label (for export header)
    $studentStmt = $conn->prepare("SELECT lastname, firstname, middlename, grade, lrn FROM students WHERE id = ? LIMIT 1");
    $studentStmt->bind_param('i', $linkedStudentId);
    $studentStmt->execute();
    $studentRow = $studentStmt->get_result()->fetch_assoc();
    $studentStmt->close();

    if (!$studentRow) {
        http_response_code(404);
        exit('Student not found.');
    }

    $studentName = trim((string) ($studentRow['lastname'] ?? '') . ', ' . (string) ($studentRow['firstname'] ?? '') . ' ' . (string) ($studentRow['middlename'] ?? ''));
    $studentGrade = (string) ($studentRow['grade'] ?? '');
    $studentLrn = (string) ($studentRow['lrn'] ?? '');
    $exportIdentityLabel = 'Current Student Anchor';

    $oldStmt = $conn->prepare("
        SELECT id, lastname, firstname, middlename, status, school_year, follow_up_status, follow_up_note, old_anchor_id
        FROM old_students
        WHERE linked_student_id = ?
        ORDER BY school_year DESC, lastname ASC, firstname ASC, id DESC
    ");
    $oldStmt->bind_param('i', $linkedStudentId);
    $oldStmt->execute();
    $oldRes = $oldStmt->get_result();
    while ($row = $oldRes->fetch_assoc()) {
        $oldRecords[] = $row;
    }
    $oldStmt->close();
} else {
    if (!$hasOldAnchorColumn) {
        http_response_code(400);
        exit(schema_migration_missing_schema_message('old account anchor export'));
    }

    $anchorStmt = $conn->prepare("
        SELECT id, lastname, firstname, middlename, school_year
        FROM old_students
        WHERE id = ?
        LIMIT 1
    ");
    $anchorStmt->bind_param('i', $oldAnchorId);
    $anchorStmt->execute();
    $anchorRow = $anchorStmt->get_result()->fetch_assoc();
    $anchorStmt->close();

    if (!$anchorRow) {
        http_response_code(404);
        exit('Old anchor record not found.');
    }

    $studentName = trim((string) ($anchorRow['lastname'] ?? '') . ', ' . (string) ($anchorRow['firstname'] ?? '') . ' ' . (string) ($anchorRow['middlename'] ?? ''));
    $studentGrade = '-';
    $studentLrn = '';
    $exportIdentityLabel = 'Old Anchor Head';

    $oldStmt = $conn->prepare("
        SELECT id, lastname, firstname, middlename, status, school_year, follow_up_status, follow_up_note, old_anchor_id
        FROM old_students
        WHERE old_anchor_id = ?
        ORDER BY school_year DESC, lastname ASC, firstname ASC, id DESC
    ");
    $oldStmt->bind_param('i', $oldAnchorId);
    $oldStmt->execute();
    $oldRes = $oldStmt->get_result();
    while ($row = $oldRes->fetch_assoc()) {
        $oldRecords[] = $row;
    }
    $oldStmt->close();
}

if (!$oldRecords) {
    http_response_code(404);
    exit('No linked old account records found for this export source.');
}

// Group old records by school year
$byYear = [];
foreach ($oldRecords as $rec) {
    $year = (string) ($rec['school_year'] ?? '');
    if ($year === '') {
        $year = 'Unknown';
    }
    if (!isset($byYear[$year])) {
        $byYear[$year] = [];
    }
    $byYear[$year][] = $rec;
}

$spreadsheet = new Spreadsheet();
sheet_apply_workbook_defaults($spreadsheet);

// All Years summary sheet
$summarySheet = $spreadsheet->getActiveSheet();
$summarySheet->setTitle('All Years');
$summarySheet->setCellValue('A1', 'Old Accounts - Statement of Account (Summary)');
$summarySheet->mergeCells('A1:E1');
$summarySheet->getRowDimension(1)->setRowHeight(26);
sheet_style_title($summarySheet, 'A1:E1');

$summarySheet->setCellValue('A3', 'Student');
$summarySheet->setCellValue('B3', $studentName);
$summarySheet->setCellValue('D3', 'Grade');
$summarySheet->setCellValue('E3', $studentGrade !== '' ? $studentGrade : '-');
$summarySheet->setCellValue('A4', 'LRN');
$summarySheet->setCellValueExplicit('B4', $studentLrn, DataType::TYPE_STRING);
$summarySheet->setCellValue('D4', 'Generated On');
$summarySheet->setCellValue('E4', date('F j, Y g:i A'));
$summarySheet->setCellValue('A5', 'Anchor Source');
$summarySheet->setCellValue('B5', $exportIdentityLabel);
sheet_style_meta_pair($summarySheet, 'A3', 'B3');
sheet_style_meta_pair($summarySheet, 'D3', 'E3');
sheet_style_meta_pair($summarySheet, 'A4', 'B4');
sheet_style_meta_pair($summarySheet, 'D4', 'E4');
sheet_style_meta_pair($summarySheet, 'A5', 'B5');

$summaryHeaders = ['School Year', 'Old Record Count', 'Total Paid', 'Remaining Balance', 'Notes'];
sheet_style_header_row($summarySheet, 7, $summaryHeaders);

$rowIdx = 8;
$grandPaid = 0.0;
$grandRemainingBalance = 0.0;

// Helper statements for totals
$feeTotalStmt = $conn->prepare("SELECT COALESCE(SUM(balance), 0) AS total_balance FROM old_student_fees WHERE old_student_id = ?");
$payTotalStmt = $conn->prepare("SELECT COALESCE(SUM(amount), 0) AS total_paid FROM old_student_payments WHERE old_student_id = ? AND (deleted_at IS NULL OR deleted_at = '')");
$yearSummaries = [];

foreach ($byYear as $year => $records) {
    $totals = old_soa_year_totals($conn, $records, $feeTotalStmt, $payTotalStmt);
    $yearSummaries[$year] = $totals;

    $grandPaid += (float) $totals['total_paid'];
    $grandRemainingBalance += (float) $totals['remaining_balance'];

    $summarySheet->setCellValue("A{$rowIdx}", $year);
    $summarySheet->setCellValue("B{$rowIdx}", count($records));
    $summarySheet->setCellValue("C{$rowIdx}", (float) $totals['total_paid']);
    $summarySheet->setCellValue("D{$rowIdx}", (float) $totals['remaining_balance']);
    $summarySheet->setCellValue("E{$rowIdx}", ((float) $totals['remaining_balance']) > 0 ? 'Outstanding balance remains' : 'Cleared for this year');
    $rowIdx++;
}

$feeTotalStmt->close();
$payTotalStmt->close();

$summarySheet->setCellValue("A{$rowIdx}", 'GRAND TOTAL');
$summarySheet->mergeCells("A{$rowIdx}:B{$rowIdx}");
$summarySheet->setCellValue("C{$rowIdx}", $grandPaid);
$summarySheet->setCellValue("D{$rowIdx}", $grandRemainingBalance);
$summarySheet->setCellValue("E{$rowIdx}", $grandRemainingBalance > 0 ? 'Total remaining across all grouped years' : 'All grouped years fully cleared');
sheet_style_table_body($summarySheet, 8, $rowIdx - 1, 5);
sheet_style_total_row($summarySheet, "A{$rowIdx}:E{$rowIdx}");
sheet_format_currency($summarySheet, "C8:D{$rowIdx}");
$summarySheet->freezePane('A8');
$summarySheet->getSheetView()->setZoomScale(115);

sheet_autosize_columns($summarySheet, 5);
$summarySheet->getColumnDimension('E')->setWidth(32);

// Per-year sheets
$yearIndex = 0;
foreach ($byYear as $year => $records) {
    $yearIndex++;
    $sheet = $spreadsheet->createSheet($yearIndex);
    $safeTitle = preg_replace('/[\\[\\]\\*:\\?\\/\\\\]/', '-', $year);
    $sheet->setTitle(mb_substr($safeTitle, 0, 31));

    $sheet->setCellValue('A1', 'Old Accounts - Statement of Account');
    $sheet->mergeCells('A1:I1');
    $sheet->getRowDimension(1)->setRowHeight(26);
    sheet_style_title($sheet, 'A1:I1');

    $sheet->setCellValue('A3', 'Student');
    $sheet->setCellValue('B3', $studentName);
    $sheet->setCellValue('E3', 'School Year');
    $sheet->setCellValue('F3', $year);
    $sheet->setCellValue('A4', 'Grade');
    $sheet->setCellValue('B4', $studentGrade !== '' ? $studentGrade : '-');
    $sheet->setCellValue('E4', 'Generated On');
    $sheet->setCellValue('F4', date('F j, Y g:i A'));
    $sheet->setCellValue('A5', 'Anchor Source');
    $sheet->setCellValue('B5', $exportIdentityLabel);
    sheet_style_meta_pair($sheet, 'A3', 'B3');
    sheet_style_meta_pair($sheet, 'E3', 'F3');
    sheet_style_meta_pair($sheet, 'A4', 'B4');
    sheet_style_meta_pair($sheet, 'E4', 'F4');
    sheet_style_meta_pair($sheet, 'A5', 'B5');

    $yearSummary = $yearSummaries[$year] ?? [
        'remaining_balance' => 0.0,
        'total_paid' => 0.0,
    ];
    $sheet->setCellValue('H3', 'Total Paid');
    $sheet->setCellValue('I3', (float) $yearSummary['total_paid']);
    $sheet->setCellValue('H4', 'Remaining Balance');
    $sheet->setCellValue('I4', (float) $yearSummary['remaining_balance']);
    sheet_style_kpi_card($sheet, 'H3', 'I3');
    sheet_style_kpi_card($sheet, 'H4', 'I4');
    sheet_format_currency($sheet, 'I3:I4');

    $cursor = 7;

    // Old records list (for this year)
    $sheet->setCellValue("A{$cursor}", 'Old Records');
    $sheet->mergeCells("A{$cursor}:I{$cursor}");
    sheet_style_section_heading($sheet, "A{$cursor}:I{$cursor}");
    $cursor++;

    $recordHeaders = ['Old ID', 'Old Name', 'Status', 'Follow-up', 'Follow-up Note'];
    sheet_style_header_row($sheet, $cursor, $recordHeaders);
    $recordHeaderRow = $cursor;
    $cursor++;
    $recordStartRow = $cursor;
    foreach ($records as $rec) {
        $oldId = (int) ($rec['id'] ?? 0);
        $oldName = trim((string) ($rec['lastname'] ?? '') . ', ' . (string) ($rec['firstname'] ?? '') . ' ' . (string) ($rec['middlename'] ?? ''));
        $sheet->setCellValue(sheet_cell_ref(1, $cursor), $oldId);
        $sheet->setCellValue(sheet_cell_ref(2, $cursor), $oldName);
        $sheet->setCellValue(sheet_cell_ref(3, $cursor), (string) ($rec['status'] ?? ''));
        $sheet->setCellValue(sheet_cell_ref(4, $cursor), (string) ($rec['follow_up_status'] ?? ''));
        $sheet->setCellValue(sheet_cell_ref(5, $cursor), (string) ($rec['follow_up_note'] ?? ''));
        $cursor++;
    }
    sheet_style_table_body($sheet, $recordStartRow, $cursor - 1, 5);
    $cursor += 1;

    // Fee balances section
    $sheet->setCellValue("A{$cursor}", 'Fee Balances');
    $sheet->mergeCells("A{$cursor}:I{$cursor}");
    sheet_style_section_heading($sheet, "A{$cursor}:I{$cursor}");
    $cursor++;

    $feeHeaders = ['Old ID', 'Fee Type', 'Balance', 'Paid Flag', 'Note'];
    sheet_style_header_row($sheet, $cursor, $feeHeaders);
    $feeHeaderRow = $cursor;
    $cursor++;
    $feeStartRow = $cursor;

    $feeStmt = $conn->prepare("SELECT old_student_id, fee_type, balance, paid, note FROM old_student_fees WHERE old_student_id = ? ORDER BY fee_type ASC");
    $yearFeeTotal = 0.0;
    foreach ($records as $rec) {
        $oldId = (int) ($rec['id'] ?? 0);
        if ($oldId <= 0) {
            continue;
        }
        $feeStmt->bind_param('i', $oldId);
        $feeStmt->execute();
        $feeRes = $feeStmt->get_result();
        while ($fee = $feeRes->fetch_assoc()) {
            $bal = (float) ($fee['balance'] ?? 0);
            $yearFeeTotal += $bal;
            $sheet->setCellValue(sheet_cell_ref(1, $cursor), (int) ($fee['old_student_id'] ?? 0));
            $sheet->setCellValue(sheet_cell_ref(2, $cursor), (string) ($fee['fee_type'] ?? ''));
            $sheet->setCellValue(sheet_cell_ref(3, $cursor), $bal);
            $sheet->setCellValue(sheet_cell_ref(4, $cursor), (int) ($fee['paid'] ?? 0) === 1 ? 'Yes' : 'No');
            $sheet->setCellValue(sheet_cell_ref(5, $cursor), (string) ($fee['note'] ?? ''));
            $cursor++;
        }
    }
    $feeStmt->close();
    sheet_style_table_body($sheet, $feeStartRow, $cursor - 1, 5);

    $sheet->setCellValue(sheet_cell_ref(2, $cursor), 'Total Old Balance');
    $sheet->setCellValue(sheet_cell_ref(3, $cursor), $yearFeeTotal);
    sheet_style_total_row($sheet, "B{$cursor}:E{$cursor}");
    sheet_format_currency($sheet, "C{$feeStartRow}:C{$cursor}");
    $cursor += 2;

    // Payments section
    $sheet->setCellValue("A{$cursor}", 'Payments');
    $sheet->mergeCells("A{$cursor}:I{$cursor}");
    sheet_style_section_heading($sheet, "A{$cursor}:I{$cursor}");
    $cursor++;

    $payHeaders = ['Old ID', 'Date Paid', 'Fee Type', 'Amount', 'Receipt', 'Method', 'Reference No.', 'Payment Note', 'Status'];
    sheet_style_header_row($sheet, $cursor, $payHeaders);
    $paymentHeaderRow = $cursor;
    $cursor++;
    $paymentStartRow = $cursor;

    $payStmt = $conn->prepare("
        SELECT old_student_id,
               fee_type,
               amount,
               booklet_no,
               receipt_no,
               note,
               payment_method,
               reference_number,
               payment_note,
               COALESCE(paid_at_datetime, CONCAT(paid_at, ' 00:00:00')) AS paid_at_full
        FROM old_student_payments
        WHERE old_student_id = ?
          AND (deleted_at IS NULL OR deleted_at = '')
        ORDER BY COALESCE(paid_at_datetime, CONCAT(paid_at, ' 00:00:00')) ASC, id ASC
    ");
    $yearPaidTotal = 0.0;
    foreach ($records as $rec) {
        $oldId = (int) ($rec['id'] ?? 0);
        if ($oldId <= 0) {
            continue;
        }
        $payStmt->bind_param('i', $oldId);
        $payStmt->execute();
        $payRes = $payStmt->get_result();
        while ($pay = $payRes->fetch_assoc()) {
            $amt = (float) ($pay['amount'] ?? 0);
            $yearPaidTotal += $amt;
            $sheet->setCellValue(sheet_cell_ref(1, $cursor), (int) ($pay['old_student_id'] ?? 0));
            $sheet->setCellValue(sheet_cell_ref(2, $cursor), (string) ($pay['paid_at_full'] ?? ''));
            $sheet->setCellValue(sheet_cell_ref(3, $cursor), (string) ($pay['fee_type'] ?? ''));
            $sheet->setCellValue(sheet_cell_ref(4, $cursor), $amt);
            $receiptText = '';
            $booklet = (int) ($pay['booklet_no'] ?? 0);
            $receipt = (string) ($pay['receipt_no'] ?? '');
            if ($booklet > 0 && $receipt !== '') {
                $receiptText = (string) $booklet . ' / ' . $receipt;
            }
            $methodBreakdown = receipt_payment_methods_for_display(
                $conn,
                $booklet,
                (int) $receipt,
                'old_student_payments',
                (string) ($pay['payment_method'] ?? ''),
                (string) ($pay['reference_number'] ?? ''),
                (string) ($pay['payment_note'] ?? '')
            );
            $sheet->setCellValue(sheet_cell_ref(5, $cursor), $receiptText !== '' ? $receiptText : '-');
            $sheet->setCellValue(sheet_cell_ref(6, $cursor), receipt_payment_methods_display_label($methodBreakdown, '-'));
            $sheet->setCellValue(sheet_cell_ref(7, $cursor), receipt_payment_methods_reference_display($methodBreakdown, '-'));
            $sheet->setCellValue(sheet_cell_ref(8, $cursor), receipt_payment_methods_note_display($methodBreakdown, '-'));
            $sheet->setCellValue(sheet_cell_ref(9, $cursor), (string) (($pay['note'] ?? '') !== '' ? $pay['note'] : '-'));
            $cursor++;
        }
    }
    $payStmt->close();
    sheet_style_table_body($sheet, $paymentStartRow, $cursor - 1, 9);

    $sheet->setCellValue(sheet_cell_ref(3, $cursor), 'Total Paid');
    $sheet->setCellValue(sheet_cell_ref(4, $cursor), $yearPaidTotal);
    sheet_style_total_row($sheet, "C{$cursor}:I{$cursor}");
    sheet_format_currency($sheet, "D{$paymentStartRow}:D{$cursor}");
    $cursor += 2;

    $sheet->setCellValue(sheet_cell_ref(2, $cursor), 'Remaining Balance');
    $sheet->setCellValue(sheet_cell_ref(3, $cursor), $yearFeeTotal);
    sheet_style_total_row($sheet, "B{$cursor}:C{$cursor}");
    sheet_format_currency($sheet, "C{$cursor}");

    $sheet->freezePane('A8');
    $sheet->getSheetView()->setZoomScale(115);
    sheet_autosize_columns($sheet, 9);
    $sheet->getColumnDimension('B')->setWidth(24);
    $sheet->getColumnDimension('E')->setWidth(18);
    $sheet->getColumnDimension('F')->setWidth(18);
    $sheet->getColumnDimension('G')->setWidth(18);
    $sheet->getColumnDimension('H')->setWidth(20);
    $sheet->getColumnDimension('I')->setWidth(18);
}

$filename = 'Old-SOA_' . preg_replace('/\s+/', '_', trim($studentName !== '' ? $studentName : ('student_' . ($linkedStudentId > 0 ? $linkedStudentId : $oldAnchorId)))) . '_' . date('Ymd_His') . '.xlsx';
$writer = new Xlsx($spreadsheet);

$username = $_SESSION['username'] ?? 'unknown';
audit_log(
    $conn,
    $username,
    'Exported old SOA',
    'Old Accounts',
    'Student ID: ' . ($linkedStudentId > 0 ? $linkedStudentId : 'N/A')
        . ' | Old Anchor ID: ' . ($oldAnchorId > 0 ? $oldAnchorId : 'N/A')
        . ' | Source: ' . $exportIdentityLabel
        . ' | Sheets: ' . count($byYear)
);

old_soa_flush_xlsx($filename, $writer);
exit;

