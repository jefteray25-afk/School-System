<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require '../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';

$currentRole = $_SESSION['role'] ?? '';
if (!hasPermission($currentRole, 'student_data', 'delete')) {
    admin_session_forbidden();
}

admin_csrf_token();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';
$student = null;

if ($id <= 0) {
    header("Location: student-old-account-list.php");
    exit();
}

$stmt = $conn->prepare("SELECT id, lastname, firstname, middlename, status, school_year FROM old_students WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();
$stmt->close();

if (!$student) {
    header("Location: student-old-account-list.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_require_post_csrf();
    $submittedId = isset($_POST['id']) ? intval($_POST['id']) : 0;

    if ($submittedId !== (int) $student['id']) {
        $error = "Invalid deletion request.";
    } elseif (!isset($_POST['confirm_delete'])) {
        header("Location: student-old-account-list.php");
        exit();
    } else {
        $deleteStmt = $conn->prepare("DELETE FROM old_students WHERE id = ?");
        $deleteStmt->bind_param("i", $student['id']);
        $deleteStmt->execute();
        $deleteStmt->close();

        include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');
        $user = $_SESSION['username'] ?? 'unknown';
        $action = "Deleted old student record";
        $module = "Old Accounts";
        $details = "Role: " . ($_SESSION['role'] ?? 'unknown') .
                   " | Old Student ID: " . $student['id'] .
                   " | Student: " . $student['lastname'] . ", " . $student['firstname'] . " " . $student['middlename'] .
                   " | Status: " . ($student['status'] ?? '') .
                   " | School Year: " . ($student['school_year'] ?? '') .
                   " | Deleted by: " . $user;
        audit_log($conn, $user, $action, $module, $details);

        header("Location: student-old-account-list.php?deleted=1");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Old Student</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="mt-5 mb-3">
        <h3><i class="fas fa-trash"></i> Delete Old Student</h3>
        <hr>
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <div class="alert alert-danger">
            <strong>Warning:</strong> This action is irreversible and will permanently delete
            <strong><?= htmlspecialchars($student['lastname'] . ', ' . $student['firstname'] . ' ' . $student['middlename']) ?></strong>.
            <br>
            Status: <strong><?= htmlspecialchars($student['status'] ?? '-') ?></strong>
            <br>
            School Year: <strong><?= htmlspecialchars($student['school_year'] ?? '-') ?></strong>
        </div>
        <form method="post">
            <input type="hidden" name="id" value="<?= (int) $student['id'] ?>">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(admin_csrf_token()) ?>">
            <button type="submit" name="confirm_delete" class="btn btn-danger">
                <i class="fas fa-trash"></i> Yes, Delete Permanently
            </button>
            <a href="student-old-account-list.php" class="btn btn-secondary ms-2">Cancel</a>
        </form>
    </div>
</div>
</body>
</html>
