<?php

function ensure_old_student_followup_columns(mysqli $conn): void
{
    static $ensured = false;
    if ($ensured) {
        return;
    }

    require_once __DIR__ . '/../../includes/schema-migration.php';
    if (!schema_migration_mode_enabled()) {
        $ensured = true;
        return;
    }

    $existing = [];
    $result = $conn->query("SHOW COLUMNS FROM old_students");
    while ($row = $result->fetch_assoc()) {
        $existing[(string) ($row['Field'] ?? '')] = true;
    }
    $result->close();

    if (!isset($existing['follow_up_status'])) {
        schema_migration_attempt($conn, "ALTER TABLE old_students ADD COLUMN follow_up_status VARCHAR(40) NOT NULL DEFAULT 'record_only' AFTER notes");
    }
    if (!isset($existing['follow_up_note'])) {
        schema_migration_attempt($conn, "ALTER TABLE old_students ADD COLUMN follow_up_note TEXT NULL AFTER follow_up_status");
    }
    if (!isset($existing['linked_student_id'])) {
        schema_migration_attempt($conn, "ALTER TABLE old_students ADD COLUMN linked_student_id INT NULL AFTER follow_up_note");
    }
    if (!isset($existing['old_anchor_id'])) {
        schema_migration_attempt($conn, "ALTER TABLE old_students ADD COLUMN old_anchor_id INT NULL AFTER linked_student_id");
    }

    $ensured = true;
}

function old_account_column_exists(mysqli $conn, string $columnName): bool
{
    $columnName = trim($columnName);
    if ($columnName === '') {
        return false;
    }

    $stmt = $conn->prepare("
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'old_students'
          AND COLUMN_NAME = ?
        LIMIT 1
    ");
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('s', $columnName);
    $stmt->execute();
    $exists = $stmt->get_result()->num_rows > 0;
    $stmt->close();

    return $exists;
}

function old_account_followup_options(): array
{
    return [
        'record_only' => 'Record Only',
        'cleared' => 'Cleared',
        'pending_documents' => 'Pending Documents',
        'requested_history' => 'Requested History',
        'needs_review' => 'Needs Review',
        'balance_concern' => 'Balance Concern',
    ];
}

function old_account_followup_label(?string $status): string
{
    $options = old_account_followup_options();
    $key = (string) ($status ?? '');
    return $options[$key] ?? 'Record Only';
}

function old_account_followup_badge_class(?string $status): string
{
    return match ((string) ($status ?? 'record_only')) {
        'cleared' => 'bg-success',
        'pending_documents' => 'bg-warning text-dark',
        'requested_history' => 'bg-info text-dark',
        'needs_review' => 'bg-danger',
        'balance_concern' => 'bg-dark',
        default => 'bg-secondary',
    };
}

function old_account_link_status_key(?string $studentStatus, ?int $linkedStudentId = null, bool $linkedStudentExists = false): string
{
    $normalized = strtolower(trim((string) ($studentStatus ?? '')));

    if ((int) ($linkedStudentId ?? 0) > 0) {
        return $linkedStudentExists ? 'linked' : 'needs_review';
    }

    return match ($normalized) {
        'graduated', 'transferred', 'withdrawn' => 'no_current_student',
        default => 'unlinked',
    };
}

function old_account_link_status_label(?string $studentStatus, ?int $linkedStudentId = null, bool $linkedStudentExists = false): string
{
    return match (old_account_link_status_key($studentStatus, $linkedStudentId, $linkedStudentExists)) {
        'linked' => 'Linked',
        'needs_review' => 'Needs Review',
        'no_current_student' => 'No Current Student',
        default => 'Unlinked',
    };
}

function old_account_link_status_badge_class(?string $studentStatus, ?int $linkedStudentId = null, bool $linkedStudentExists = false): string
{
    return match (old_account_link_status_key($studentStatus, $linkedStudentId, $linkedStudentExists)) {
        'linked' => 'bg-success',
        'needs_review' => 'bg-danger',
        'no_current_student' => 'bg-dark',
        default => 'bg-warning text-dark',
    };
}

function old_account_link_status_note(?string $studentStatus, ?int $linkedStudentId = null, bool $linkedStudentExists = false): string
{
    return match (old_account_link_status_key($studentStatus, $linkedStudentId, $linkedStudentExists)) {
        'linked' => 'This old account is already connected to a current student record, so the finance module can surface it later.',
        'needs_review' => 'This record points to a current student link that no longer resolves cleanly. Review the match before relying on it.',
        'no_current_student' => 'This record can stay standalone in Old Accounts because the student may have graduated, transferred, or no longer returned.',
        default => 'This record is not linked yet. Once a matching current student exists, we can safely connect it in the next wave.',
    };
}

function old_account_linked_records_for_student(mysqli $conn, int $studentId): array
{
    if ($studentId <= 0) {
        return [
            'count' => 0,
            'total_balance' => 0.0,
            'records' => [],
        ];
    }

    ensure_old_student_followup_columns($conn);

    $stmt = $conn->prepare("
        SELECT
            os.id,
            os.lastname,
            os.firstname,
            os.middlename,
            os.status,
            os.school_year,
            os.follow_up_status,
            os.follow_up_note,
            COALESCE(SUM(f.balance), 0) AS total_balance
        FROM old_students os
        LEFT JOIN old_student_fees f ON f.old_student_id = os.id
        WHERE os.linked_student_id = ?
        GROUP BY os.id, os.lastname, os.firstname, os.middlename, os.status, os.school_year, os.follow_up_status, os.follow_up_note
        ORDER BY os.school_year DESC, os.lastname ASC, os.firstname ASC
    ");
    $stmt->bind_param('i', $studentId);
    $stmt->execute();
    $result = $stmt->get_result();

    $records = [];
    $totalBalance = 0.0;
    while ($row = $result->fetch_assoc()) {
        $row['total_balance'] = (float) ($row['total_balance'] ?? 0);
        $records[] = $row;
        $totalBalance += $row['total_balance'];
    }
    $stmt->close();

    return [
        'count' => count($records),
        'total_balance' => $totalBalance,
        'records' => $records,
    ];
}

function old_account_anchor_head_id(array $row): int
{
    return (int) ($row['old_anchor_id'] ?? 0);
}

function old_account_anchor_status_key(int $oldStudentId, ?int $oldAnchorId = null): string
{
    $oldStudentId = max(0, $oldStudentId);
    $oldAnchorId = (int) ($oldAnchorId ?? 0);

    if ($oldStudentId > 0 && $oldAnchorId === $oldStudentId) {
        return 'head_anchor';
    }
    if ($oldAnchorId > 0) {
        return 'linked_to_anchor';
    }
    return 'no_anchor';
}

function old_account_anchor_status_label(int $oldStudentId, ?int $oldAnchorId = null): string
{
    return match (old_account_anchor_status_key($oldStudentId, $oldAnchorId)) {
        'head_anchor' => 'Head Anchor',
        'linked_to_anchor' => 'Linked To Anchor',
        default => 'No Anchor',
    };
}

function old_account_anchor_status_badge_class(int $oldStudentId, ?int $oldAnchorId = null): string
{
    return match (old_account_anchor_status_key($oldStudentId, $oldAnchorId)) {
        'head_anchor' => 'bg-primary',
        'linked_to_anchor' => 'bg-info text-dark',
        default => 'bg-secondary',
    };
}

function old_account_anchor_status_note(int $oldStudentId, ?int $oldAnchorId = null, string $anchorName = '', string $anchorYear = ''): string
{
    $anchorName = trim($anchorName);
    $anchorYear = trim($anchorYear);

    return match (old_account_anchor_status_key($oldStudentId, $oldAnchorId)) {
        'head_anchor' => 'This old record is the head anchor for grouped old-account history.',
        'linked_to_anchor' => 'This old record is grouped under '
            . ($anchorName !== '' ? $anchorName : 'another old-account head')
            . ($anchorYear !== '' ? ' (' . $anchorYear . ')' : '')
            . '.',
        default => 'No old-account anchor is assigned yet. Set one when this student has multiple old-year records.',
    };
}

function old_account_anchor_related_records(mysqli $conn, int $oldAnchorId): array
{
    if ($oldAnchorId <= 0) {
        return [];
    }

    ensure_old_student_followup_columns($conn);
    $stmt = $conn->prepare("
        SELECT id, lastname, firstname, middlename, school_year, status
        FROM old_students
        WHERE old_anchor_id = ?
        ORDER BY school_year DESC, lastname ASC, firstname ASC, id DESC
    ");
    $stmt->bind_param('i', $oldAnchorId);
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    $stmt->close();

    return $rows;
}

function old_account_anchor_member_count(mysqli $conn, int $oldAnchorId, bool $excludeHead = false): int
{
    if ($oldAnchorId <= 0) {
        return 0;
    }

    ensure_old_student_followup_columns($conn);
    if ($excludeHead) {
        $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM old_students WHERE old_anchor_id = ? AND id <> ?");
        $stmt->bind_param('ii', $oldAnchorId, $oldAnchorId);
    } else {
        $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM old_students WHERE old_anchor_id = ?");
        $stmt->bind_param('i', $oldAnchorId);
    }
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return (int) ($row['c'] ?? 0);
}

function old_account_effective_anchor_label(bool $hasCurrentLink, int $oldStudentId, ?int $oldAnchorId = null): string
{
    if ($hasCurrentLink) {
        return 'Uses Active Anchor';
    }

    return match (old_account_anchor_status_key($oldStudentId, $oldAnchorId)) {
        'head_anchor' => 'Head Anchor',
        'linked_to_anchor' => 'Linked To Head',
        default => 'No Anchor Yet',
    };
}

function old_account_effective_anchor_note(
    bool $hasCurrentLink,
    int $oldStudentId,
    ?int $oldAnchorId = null,
    string $anchorName = '',
    string $anchorYear = ''
): string {
    if ($hasCurrentLink) {
        return 'This old account already uses its linked active/current student as the main anchor.';
    }

    return old_account_anchor_status_note($oldStudentId, $oldAnchorId, $anchorName, $anchorYear);
}
