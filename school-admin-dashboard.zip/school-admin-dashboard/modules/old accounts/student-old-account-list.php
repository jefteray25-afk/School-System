<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require '../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/old-account-followup-helper.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$_SESSION['old_student_list_return_url'] = $_SERVER['REQUEST_URI'];
ensure_old_student_followup_columns($conn);
$hasOldAnchorColumn = old_account_column_exists($conn, 'old_anchor_id');
$follow_up_options = old_account_followup_options();

function old_account_normalize_school_year_option(string $label): string
{
    $label = trim($label);
    if (stripos($label, 'SY ') === 0) {
        $label = trim(substr($label, 3));
    }
    return $label;
}

function old_account_school_year_sort_value(string $label): int
{
    if (preg_match('/^(\d{4})-(\d{4})$/', $label, $matches)) {
        return ((int) $matches[1]) * 10000 + (int) $matches[2];
    }
    return 0;
}

function old_account_school_year_options(mysqli $conn): array
{
    $options = [];

    foreach (school_year_filter_options($conn) as $label) {
        $normalized = old_account_normalize_school_year_option((string) $label);
        if ($normalized !== '') {
            $options[$normalized] = $normalized;
        }
    }

    $result = $conn->query("SELECT DISTINCT school_year FROM old_students WHERE school_year IS NOT NULL AND TRIM(school_year) <> ''");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $normalized = old_account_normalize_school_year_option((string) ($row['school_year'] ?? ''));
            if ($normalized !== '') {
                $options[$normalized] = $normalized;
            }
        }
        $result->close();
    }

    $values = array_values($options);
    usort($values, static function (string $a, string $b): int {
        return old_account_school_year_sort_value($b) <=> old_account_school_year_sort_value($a);
    });

    return $values;
}

$can_manage_old_account_link = is_super_admin_role($_SESSION['role'] ?? '');

// --- LOCK ALL FILTERS FEATURE ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['lock_all'])) {
    admin_require_post_csrf();
    $_SESSION['locked_filters'] = [
        'name' => $_POST['name'] ?? $_GET['name'] ?? '',
        'school_year' => $_POST['school_year'] ?? $_GET['school_year'] ?? '',
        'status' => $_POST['status'] ?? $_GET['status'] ?? '',
        'follow_up' => $_POST['follow_up'] ?? $_GET['follow_up'] ?? '',
        'head_anchor' => $_POST['head_anchor'] ?? $_GET['head_anchor'] ?? '',
        'sort' => $_POST['sort'] ?? $_GET['sort'] ?? 'az'
    ];
    audit_log(
        $conn,
        $_SESSION['username'] ?? 'unknown',
        'Locked old accounts list view filters',
        'Old Accounts',
        'Name: ' . ($_POST['name'] ?? $_GET['name'] ?? '')
            . ' | School Year: ' . ($_POST['school_year'] ?? $_GET['school_year'] ?? '')
            . ' | Status: ' . ($_POST['status'] ?? $_GET['status'] ?? '')
            . ' | Follow Up: ' . ($_POST['follow_up'] ?? $_GET['follow_up'] ?? '')
            . ' | Head Anchor: ' . ($_POST['head_anchor'] ?? $_GET['head_anchor'] ?? '')
            . ' | Sort: ' . ($_POST['sort'] ?? $_GET['sort'] ?? 'az'),
        'INFO'
    );
    header("Location: student-old-account-list.php");
    exit();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_lock_all'])) {
    admin_require_post_csrf();
    unset($_SESSION['locked_filters']);
    audit_log($conn, $_SESSION['username'] ?? 'unknown', 'Unlocked old accounts list view filters', 'Old Accounts', 'Cleared locked old account filter state.', 'INFO');
    header("Location: student-old-account-list.php");
    exit();
}
if (isset($_SESSION['locked_filters'])) {
    $_GET['name'] = $_SESSION['locked_filters']['name'];
    $_GET['school_year'] = $_SESSION['locked_filters']['school_year'];
    $_GET['status'] = $_SESSION['locked_filters']['status'] ?? '';
    $_GET['follow_up'] = $_SESSION['locked_filters']['follow_up'] ?? '';
    $_GET['head_anchor'] = $_SESSION['locked_filters']['head_anchor'] ?? '';
    $_GET['sort'] = $_SESSION['locked_filters']['sort'];
    $filters_locked = true;
} else {
    $filters_locked = false;
}

// School year filter
school_year_ensure_table($conn);
$school_years = old_account_school_year_options($conn);
$selected_school_year = old_account_normalize_school_year_option((string) ($_GET['school_year'] ?? ''));
$selected_status = trim((string) ($_GET['status'] ?? ''));
$selected_follow_up = trim((string) ($_GET['follow_up'] ?? ''));
$head_anchor_filter_enabled = (string) ($_GET['head_anchor'] ?? '') === '1';

// Name filter and Sort order
$name_filter = trim($_GET['name'] ?? '');
$sort_order = ($_GET['sort'] ?? 'az') === 'za' ? 'DESC' : 'ASC';

// Query from old_students table with filter
$sql = "
    SELECT 
        os.id,
        os.lastname,
        os.firstname,
        os.middlename,
        os.contact,
        os.status,
        os.school_year,
        os.notes,
        os.follow_up_status,
        os.follow_up_note,
        os.linked_student_id,
        " . ($hasOldAnchorColumn ? "os.old_anchor_id" : "NULL AS old_anchor_id") . ",
        s.lastname AS linked_lastname,
        s.firstname AS linked_firstname,
        s.middlename AS linked_middlename,
        s.grade AS linked_grade,
        s.section AS linked_section,
        s.school_year_label AS linked_school_year_label,
        " . ($hasOldAnchorColumn ? "anchor.lastname AS anchor_lastname,
        anchor.firstname AS anchor_firstname,
        anchor.middlename AS anchor_middlename,
        anchor.school_year AS anchor_school_year" : "'' AS anchor_lastname,
        '' AS anchor_firstname,
        '' AS anchor_middlename,
        '' AS anchor_school_year") . "
    FROM old_students os
    LEFT JOIN students s ON s.id = os.linked_student_id
    " . ($hasOldAnchorColumn ? "LEFT JOIN old_students anchor ON anchor.id = os.old_anchor_id" : "") . "
";
$where_clauses = [];
$params = [];
$types = '';

// Add school year filter
if ($selected_school_year) {
    $where_clauses[] = "(os.school_year = ? OR os.school_year = CONCAT('SY ', ?))";
    $params[] = $selected_school_year;
    $params[] = $selected_school_year;
    $types .= 'ss';
}
if ($selected_status !== '') {
    $where_clauses[] = "os.status = ?";
    $params[] = $selected_status;
    $types .= 's';
}
if ($selected_follow_up !== '') {
    $where_clauses[] = "os.follow_up_status = ?";
    $params[] = $selected_follow_up;
    $types .= 's';
}
if ($head_anchor_filter_enabled && $hasOldAnchorColumn) {
    $where_clauses[] = "os.old_anchor_id = os.id";
}

// Add name filter
if ($name_filter !== '') {
    $where_clauses[] = "(os.lastname LIKE ? OR os.firstname LIKE ? OR os.middlename LIKE ?)";
    $like = '%' . $name_filter . '%';
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $types .= 'sss';
}

if ($where_clauses) {
    $sql .= " WHERE " . implode(" AND ", $where_clauses);
}

// Add sort order
$sql .= " ORDER BY os.school_year DESC, os.lastname $sort_order, os.firstname $sort_order";

if ($where_clauses) {
    $stmt = $conn->prepare($sql);
    if ($types !== '') {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($sql);
}

// Count total students (filtered)
$total_students_count = ($result) ? $result->num_rows : 0;
$archived_with_notes_count = 0;
$needs_follow_up_count = 0;
$status_breakdown = [
    'graduated' => 0,
    'transferred' => 0,
    'withdrawn' => 0,
    'active' => 0,
];
$list_rows = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $list_rows[] = $row;
        $status_key = (string) ($row['status'] ?? '');
        if (isset($status_breakdown[$status_key])) {
            $status_breakdown[$status_key]++;
        }
        if (trim((string) ($row['notes'] ?? '')) !== '') {
            $archived_with_notes_count++;
        }
        if (($row['follow_up_status'] ?? 'record_only') !== 'record_only') {
            $needs_follow_up_count++;
        }
    }
}

$grouped_old_account_rows = [];
$old_account_name_history_map = [];
foreach ($list_rows as $row) {
    $nameKey = mb_strtolower(trim((string) (($row['lastname'] ?? '') . '|' . ($row['firstname'] ?? '') . '|' . ($row['middlename'] ?? ''))));
    $yearKey = trim((string) ($row['school_year'] ?? ''));
    if ($nameKey !== '') {
        if (!isset($old_account_name_history_map[$nameKey])) {
            $old_account_name_history_map[$nameKey] = [
                'years' => [],
                'records' => 0,
            ];
        }
        if ($yearKey !== '') {
            $old_account_name_history_map[$nameKey]['years'][$yearKey] = true;
        }
        $old_account_name_history_map[$nameKey]['records']++;
    }

    $groupLabel = trim((string) ($row['school_year'] ?? ''));
    if ($groupLabel === '') {
        $groupLabel = 'Unassigned School Year';
    }
    if (!isset($grouped_old_account_rows[$groupLabel])) {
        $grouped_old_account_rows[$groupLabel] = [];
    }
    $grouped_old_account_rows[$groupLabel][] = $row;
}

// Check permissions for actions
$user_role = $_SESSION['role'] ?? '';
$can_delete = hasPermission($user_role, 'student_data', 'delete');
$can_edit = hasPermission($user_role, 'student_data', 'edit');
$delete_success = isset($_GET['deleted']) && $_GET['deleted'] === '1';
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';
$role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";
$old_account_export_query = http_build_query([
    'name' => $name_filter,
    'school_year' => $selected_school_year,
    'status' => $selected_status,
    'follow_up' => $selected_follow_up,
    'head_anchor' => $head_anchor_filter_enabled ? '1' : '',
    'sort' => ($_GET['sort'] ?? 'az'),
]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Old Student Account List | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
            --filter-btn-bg: #e7f0fd;
            --filter-btn-color: #517fa4;
            --filter-btn-border: #bcdfff;
            --filter-btn-active-bg: #517fa4;
            --filter-btn-active-color: #fff;
        }
        body {
            background: var(--main-bg);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        }
        body.dark-mode {
            --main-bg: #1b232d;
            --card-bg: #23395d;
            --navbar-bg: #161b22;
            color: #e6edf3;
        }
        .navbar {
            background: var(--navbar-bg) !important;
            box-shadow: 0 2px 12px rgba(33,57,93,0.08);
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.08em;
        }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .nav-link.active { border-bottom: 2px solid #517fa4; }
        .theme-toggle-btn {
            background: none;
            border: none;
            color: #fff;
            font-size: 1.45em;
            margin-left: 12px;
            cursor: pointer;
        }
        .dashboard-header {
            text-align: center;
            margin-top: 36px;
            margin-bottom: 18px;
        }
        .dashboard-header img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            margin-bottom: 6px;
        }
        .dashboard-header h1 {
            font-size: 1.3rem;
            color: var(--brand-dark);
            font-weight: 700;
            margin-bottom: 0;
            letter-spacing: 0.02em;
        }
        .old-list-card {
            background: var(--card-bg);
            border-radius: 1rem;
            box-shadow: 0 4px 18px rgba(33,57,93,0.09), 0 1.5px 3px rgba(33,57,93,0.07);
            margin: 0 auto;
            margin-top: 18px;
            margin-bottom: 32px;
            padding: 1.2rem 2.5rem 1.3rem 2.5rem;
            max-width: 1050px;
        }
        .old-table-header {
            font-size: 1.23rem;
            font-weight: 700;
            color: #23395d;
            margin-bottom: 0.6rem;
            letter-spacing: 0.04em;
        }
        .old-table-desc {
            color: #517fa4;
            font-size: 0.99rem;
            margin-bottom: 13px;
        }
        .table thead th {
            background: #23395d !important;
            color: #fff !important;
        }
        .table tbody tr {
            transition: background 0.18s;
        }
        .table tbody tr:hover {
            background: transparent;
        }
        .table .btn-outline-info, .table .btn-outline-warning, .table .btn-outline-danger {
            font-size: 0.96em;
            padding: 2px 8px;
        }
        .old-year-accordion {
            display: flex;
            flex-direction: column;
            gap: 0.95rem;
        }
        .old-year-card {
            border: 1px solid #d8e4f0;
            border-radius: 18px;
            overflow: hidden;
            background: #fff;
            box-shadow: 0 8px 24px rgba(35,57,93,0.05);
        }
        .old-year-toggle {
            width: 100%;
            border: 0;
            background: linear-gradient(180deg, #fafdff 0%, #f3f8fd 100%);
            color: #23395d;
            text-align: left;
            padding: 1rem 1.1rem;
        }
        .old-year-toggle:hover,
        .old-year-toggle:focus {
            background: linear-gradient(180deg, #f6fbff 0%, #ecf4fb 100%);
        }
        .old-year-heading {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }
        .old-year-title {
            font-size: 1rem;
            font-weight: 800;
            color: #23395d;
        }
        .old-year-subtitle {
            font-size: 0.86rem;
            color: #607388;
            margin-top: 0.16rem;
        }
        .old-year-meta {
            display: flex;
            align-items: center;
            gap: 0.55rem;
            flex-wrap: wrap;
            justify-content: flex-end;
        }
        .old-year-count {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            background: #eaf3ff;
            color: #294e76;
            border: 1px solid #cfe0f4;
            border-radius: 999px;
            padding: 0.32rem 0.7rem;
            font-size: 0.84rem;
            font-weight: 700;
        }
        .old-year-chevron {
            color: #5f7894;
            transition: transform 0.2s ease;
        }
        .old-year-toggle[aria-expanded="true"] .old-year-chevron {
            transform: rotate(180deg);
        }
        .old-year-body {
            padding: 1rem 1.05rem 1.1rem;
            border-top: 1px solid #e2ebf4;
            background: #fff;
        }
        .continuity-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            margin-top: 0.45rem;
            background: #eef4fb;
            color: #2c537d;
            border: 1px solid #d8e4f0;
            border-radius: 999px;
            padding: 0.24rem 0.55rem;
            font-size: 0.75rem;
            font-weight: 700;
        }
        .continuity-note {
            margin-top: 0.3rem;
            font-size: 0.76rem;
            color: #607388;
            line-height: 1.35;
        }
        .add-btn {
            background: #517fa4;
            border: none;
            color: #fff;
            font-weight: 500;
            box-shadow: 0 1px 4px rgba(33,57,93,0.09);
            border-radius: 7px;
            padding: 7px 17px;
            font-size: 1.02em;
            transition: background 0.18s, color 0.18s;
            margin-bottom: 13px;
        }
        .add-btn:hover, .add-btn:focus {
            background: #23395d;
            color: #fff;
        }
        /* Floating round filter button */
        .floating-filter-btn {
            position: fixed;
            left: 28px;
            bottom: 28px;
            z-index: 1060;
            background: var(--filter-btn-bg);
            color: var(--filter-btn-color);
            border: 2px solid var(--filter-btn-border);
            box-shadow: 0 5px 16px rgba(33,57,93,0.13);
            border-radius: 50%;
            width: 58px;
            height: 58px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.55em;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
        }
        .floating-filter-btn:hover, .floating-filter-btn:focus {
            background: #fff2b3;
            color: #517fa4;
            border-color: #ffe599;
        }
        /* Floating round total students button (lower left) */
        .floating-total-btn {
            position: fixed;
            left: 28px;
            bottom: 100px;
            z-index: 1061;
            background: #517fa4;
            color: #fff;
            border: 2px solid #bcdfff;
            box-shadow: 0 5px 16px rgba(33,57,93,0.13);
            border-radius: 50%;
            width: 58px;
            height: 58px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.48em;
            font-weight: bold;
            user-select: none;
            pointer-events: none;
            opacity: 0.92;
        }
        /* Floating round lock button (lower left, above total students and filter) */
        .floating-lock-btn {
            position: fixed;
            left: 28px;
            bottom: 172px; /* adjust for stacking above total students */
            z-index: 1062;
            border: 2px solid #bcdfff;
            box-shadow: 0 5px 16px rgba(33,57,93,0.13);
            border-radius: 50%;
            width: 58px;
            height: 58px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.55em;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
        }
        .floating-lock-btn.locked {
            background: #dc3545; /* red */
            color: #fff;
            border-color: #dc3545;
        }
        .floating-lock-btn.unlocked {
            background: #28a745; /* green */
            color: #fff;
            border-color: #28a745;
        }
        .floating-lock-btn:hover, .floating-lock-btn:focus {
            opacity: 0.85;
        }
        @media (max-width: 600px) {
            .floating-total-btn { left: 12px; bottom: 80px; width: 45px; height: 45px; font-size: 1em;}
            .floating-filter-btn { left: 12px; bottom: 28px; width: 45px; height: 45px; font-size: 1em;}
            .floating-lock-btn { left: 12px; bottom: 152px; width: 45px; height: 45px; font-size: 1em;}
        }
        /* Modal custom style for school year filter */
        .modal-schoolyr-list {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            padding: 8px 2px;
        }
        .modal-schoolyr-pill {
            background: var(--filter-btn-bg);
            color: #23395d;
            border: none;
            border-radius: 15px;
            padding: 7px 19px;
            font-size: 1.01em;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            transition: background 0.18s, color 0.18s;
        }
        .modal-schoolyr-pill.active,
        .modal-schoolyr-pill:active {
            background: var(--filter-btn-active-bg);
            color: var(--filter-btn-active-color);
            font-weight: 700;
        }
        .modal-title { font-size: 1.13em; color: #23395d;}
        .modal-header { background: #f5f8fc; }
        /* Disabled state for filter form */
        .filters-locked input,
        .filters-locked select,
        .filters-locked button:not(.lock-btn) {
            pointer-events: none;
            opacity: 0.6;
        }
        .filters-locked {
            position: relative;
        }
        .filters-locked:after {
            content: "Locked";
            position: absolute;
            top: -28px;
            left: 0;
            font-size: 1em;
            color: #dc3545;
            background: #fff;
            padding: 2px 7px;
            border-radius: 6px;
            font-weight: bold;
            border: 1px solid #dc3545;
        }
        /* View Wave 1 + 2: shared list view system */
        :root {
            --vw-page-bg: #eef3f9;
            --vw-card-bg: #ffffff;
            --vw-card-border: #d9e3ef;
            --vw-brand-dark: #23395d;
            --vw-brand-mid: #517fa4;
            --vw-brand-soft: #edf4fb;
            --vw-text-soft: #5f7186;
        }
        body {
            background:
                radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 30%),
                linear-gradient(180deg, #f8fbff 0%, var(--vw-page-bg) 100%);
            color: var(--vw-brand-dark);
        }
        .dashboard-header img {
            width: 72px;
            height: 72px;
            border-radius: 18px;
            background: #fff;
            padding: 6px;
            box-shadow: 0 10px 25px rgba(35,57,93,0.12);
        }
        .dashboard-header h1 {
            font-weight: 800;
        }
        .old-list-card {
            background: var(--vw-card-bg);
            border: 1px solid var(--vw-card-border);
            border-radius: 20px;
            box-shadow: 0 14px 32px rgba(35,57,93,0.07);
            width: min(1760px, calc(100vw - 36px));
            max-width: 1760px;
            margin-inline: auto;
            padding: 1.5rem 1.4rem 1.7rem !important;
            position: relative;
            overflow: hidden;
        }
        .old-list-card::before {
            content: "";
            position: absolute;
            inset: 0 0 auto 0;
            height: 5px;
            background: linear-gradient(90deg, var(--vw-brand-dark), var(--vw-brand-mid), #7da6c7);
        }
        .old-table-header {
            font-weight: 800;
            margin-bottom: 0.5rem;
        }
        .view-kicker {
            font-size: 0.78rem;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: var(--vw-text-soft);
            font-weight: 800;
            margin-bottom: 0.3rem;
        }
        .old-table-desc {
            color: var(--vw-text-soft);
            margin-bottom: 1rem;
        }
        .old-list-card form.row {
            background: #f8fbff;
            border: 1px solid var(--vw-card-border);
            border-radius: 16px;
            padding: 14px 12px;
            margin-bottom: 1rem !important;
            max-width: 100% !important;
        }
        .old-list-card .form-select,
        .old-list-card .form-control {
            border-color: #d7e1ed;
            min-height: 44px;
            box-shadow: none;
        }
        .old-list-card .btn-primary,
        .old-list-card .add-btn {
            background: var(--vw-brand-dark);
            border-color: var(--vw-brand-dark);
            color: #fff;
            font-weight: 600;
        }
        .old-list-card .btn-outline-info,
        .old-list-card .btn-outline-warning,
        .old-list-card .btn-outline-danger,
        .old-list-card .btn-outline-secondary {
            background: #eef3f8;
            border-color: #d7e1ed;
            color: var(--vw-brand-dark);
            font-weight: 600;
        }
        .old-list-card .table thead th {
            background: var(--vw-brand-soft) !important;
            color: var(--vw-brand-dark) !important;
            border-bottom: 1px solid var(--vw-card-border);
            font-weight: 700;
            white-space: nowrap;
            font-size: 0.9rem;
        }
        .old-list-card .table tbody tr:hover {
            background: transparent;
        }
        .old-list-card .badge {
            border-radius: 999px;
            padding: 0.5rem 0.8rem;
            font-weight: 700;
        }
        .old-list-card .btn.btn-sm,
        .old-list-card .action-btn {
            border-radius: 999px;
            min-height: 34px;
            font-weight: 700;
            box-shadow: none;
            padding: 0.35rem 0.8rem;
            font-size: 0.84rem;
        }
        .old-list-card .btn-outline-info {
            background: #edf4fb;
            border-color: #d7e1ed;
            color: var(--vw-brand-dark);
        }
        .old-list-card .btn-outline-warning {
            background: #fff4d8;
            border-color: #f0dd9a;
            color: #8a6400;
        }
        .old-list-card .btn-outline-danger {
            background: #fdecec;
            border-color: #f2c9c9;
            color: #b42318;
        }
        .old-list-card .btn-outline-info:hover,
        .old-list-card .btn-outline-warning:hover,
        .old-list-card .btn-outline-danger:hover {
            filter: brightness(0.98);
        }
        .bulk-toolbar {
            display:flex;
            justify-content:space-between;
            align-items:center;
            gap:12px;
            flex-wrap:wrap;
            margin-bottom:0.85rem;
        }
        .bulk-toolbar .selection-note {
            color: var(--vw-text-soft);
            font-weight: 700;
        }
        .archive-summary-card {
            background: #f8fbff;
            border: 1px solid var(--vw-card-border);
            border-radius: 16px;
            padding: 0.95rem 1rem;
            height: 100%;
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.75);
        }
        .archive-summary-card .label {
            text-transform: uppercase;
            letter-spacing: 0.08em;
            font-size: 0.72rem;
            color: var(--vw-text-soft);
            font-weight: 800;
        }
        .archive-summary-card .value {
            font-size: 1.45rem;
            font-weight: 800;
            color: var(--vw-brand-dark);
            margin-top: 0.2rem;
        }
        .active-filter-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            background: #edf4fb;
            color: var(--vw-brand-dark);
            border: 1px solid var(--vw-card-border);
            border-radius: 999px;
            padding: 0.38rem 0.78rem;
            font-size: 0.86rem;
            font-weight: 700;
            margin: 0 0.45rem 0.45rem 0;
        }
        .archive-summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 0.9rem;
            margin-bottom: 1rem;
        }
        .old-account-table-wrap {
            border: 1px solid var(--vw-card-border);
            border-radius: 18px;
            overflow: hidden;
            background: #fff;
        }
        .old-account-table-wrap .table-responsive {
            overflow-x: auto;
        }
        .old-account-table-wrap table {
            min-width: 1260px;
            width: 100%;
        }
        .old-account-table-wrap .table td {
            padding: 0.9rem 0.68rem;
        }
        .old-account-table-wrap .table {
            margin-bottom: 0;
        }
        .old-account-table-wrap .table tbody td {
            border-color: #e5edf5;
            background: rgba(255,255,255,0.94);
        }
        .old-account-table-wrap .table tbody tr:nth-child(even) td {
            background: #fbfdff;
        }
        .old-account-table-wrap .table tbody tr:hover td {
            background: #f4f9ff;
        }
        .old-account-name {
            min-width: 240px;
        }
        .old-account-name .student-name {
            color: var(--vw-brand-dark);
            font-weight: 800;
            line-height: 1.25;
        }
        .old-account-name .student-sub {
            color: var(--vw-text-soft);
            font-size: 0.82rem;
            margin-top: 0.18rem;
        }
        .old-followup-cell {
            min-width: 175px;
        }
        .old-anchor-cell {
            min-width: 195px;
        }
        .old-notes-cell {
            min-width: 180px;
            color: #567089;
            font-size: 0.9rem;
        }
        .old-contact-cell {
            min-width: 145px;
            white-space: normal;
            overflow-wrap: anywhere;
            word-break: break-word;
            line-height: 1.4;
        }
        .old-actions {
            min-width: 160px;
            display: flex;
            flex-wrap: wrap;
            gap: 0.45rem;
        }
        .old-actions form {
            margin: 0;
        }
        .old-action-toolbar {
            display: flex;
            flex-wrap: wrap;
            gap: 0.75rem;
            align-items: center;
            margin-bottom: 1rem;
            padding: 0.9rem 1rem;
            border: 1px solid var(--vw-card-border);
            background: linear-gradient(180deg, #f8fbff 0%, #edf4fb 100%);
            border-radius: 16px;
        }
        .old-action-toolbar .btn,
        .old-filter-tools .btn {
            border-radius: 999px;
            font-weight: 700;
            min-height: 42px;
            padding-inline: 1rem;
        }
        .toolbar-spacer {
            flex: 1 1 auto;
        }
        .export-btn-green {
            background: #e9f7ef;
            border-color: #b7dfc5;
            color: #166534;
        }
        .export-btn-green:hover {
            background: #dcf2e5;
            border-color: #9ed0b0;
            color: #14532d;
        }
        .export-btn-blue {
            background: #edf4fb;
            border-color: #cfdeee;
            color: var(--vw-brand-dark);
        }
        .export-btn-blue:hover {
            background: #e4eef8;
            border-color: #bed1e7;
            color: #1c3555;
        }
        .reset-btn {
            background: #fff;
            border: 1px solid #d7e1ed;
            color: var(--vw-brand-dark);
        }
        .old-filter-tools {
            display: flex;
            flex-wrap: wrap;
            gap: 0.75rem;
            align-items: center;
            margin-bottom: 0.85rem;
        }
        .filter-help-text {
            color: var(--vw-text-soft);
            font-size: 0.88rem;
            font-weight: 600;
        }
        .old-filter-form {
            max-width: none !important;
            align-items: end;
        }
        .old-filter-form .filter-actions {
            display: flex;
            gap: 0.6rem;
            flex-wrap: nowrap;
            justify-content: flex-start;
            align-items: center;
            width: 100%;
        }
        .lock-inline-form {
            display: inline-flex;
            margin: 0;
        }
        .lock-btn {
            border-radius: 999px;
            font-weight: 700;
            min-height: 42px;
            padding-inline: 1rem;
            border: 1px solid #d7e1ed;
            background: #fff7e8;
            color: #8a5a00;
        }
        .lock-btn.locked {
            background: #fff1f2;
            color: #9f1239;
            border-color: #f5c2c7;
        }
        .anchor-toggle-btn {
            border-radius: 999px;
            font-weight: 700;
            min-height: 42px;
            padding-inline: 1rem;
            border: 1px solid #cfdeee;
            background: #fff;
            color: var(--vw-brand-dark);
        }
        .anchor-toggle-btn.active {
            background: #23395d;
            border-color: #23395d;
            color: #fff;
            box-shadow: 0 6px 14px rgba(35,57,93,0.16);
        }
        .anchor-link-count {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            margin-top: 0.4rem;
            padding: 0.28rem 0.6rem;
            border-radius: 999px;
            background: #edf4fb;
            border: 1px solid #d7e5f3;
            color: #284766;
            font-size: 0.78rem;
            font-weight: 700;
        }
        .section-caption {
            padding: 0.95rem 1rem;
            border: 1px solid var(--vw-card-border);
            border-radius: 16px;
            background: linear-gradient(180deg, #ffffff 0%, #f8fbff 100%);
        }
        .section-caption .caption-title {
            font-weight: 800;
            color: var(--vw-brand-dark);
        }
        .section-caption .caption-text {
            color: var(--vw-text-soft);
            font-size: 0.95rem;
        }
        .oa-shell {
            width: min(1780px, calc(100vw - 28px));
            margin: 0 auto 34px;
        }
        .oa-hero {
            position: relative;
            display: grid;
            grid-template-columns: minmax(0, 1.3fr) minmax(280px, 0.9fr);
            gap: 1.25rem;
            padding: 1.4rem 1.45rem;
            margin-bottom: 1.15rem;
            border: 1px solid rgba(210, 223, 237, 0.95);
            border-radius: 24px;
            background:
                radial-gradient(circle at top right, rgba(125, 166, 199, 0.22), transparent 32%),
                linear-gradient(145deg, #ffffff 0%, #f4f8fd 62%, #eef4fb 100%);
            box-shadow: 0 18px 36px rgba(35,57,93,0.09);
            overflow: visible;
            z-index: 5;
        }
        .oa-hero::after {
            content: "";
            position: absolute;
            inset: auto -45px -55px auto;
            width: 210px;
            height: 210px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(81,127,164,0.18), transparent 68%);
            pointer-events: none;
        }
        .oa-hero-copy {
            position: relative;
            z-index: 1;
        }
        .oa-eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            padding: 0.4rem 0.78rem;
            border-radius: 999px;
            background: rgba(255,255,255,0.76);
            border: 1px solid rgba(206, 222, 238, 0.96);
            color: var(--vw-brand-mid);
            font-size: 0.75rem;
            font-weight: 800;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            margin-bottom: 0.9rem;
            backdrop-filter: blur(4px);
        }
        .oa-title {
            margin: 0;
            font-size: clamp(1.9rem, 2.5vw, 2.7rem);
            line-height: 1.08;
            font-weight: 800;
            color: #1c3555;
            letter-spacing: -0.03em;
        }
        .oa-title-accent {
            display: inline-block;
            color: var(--vw-brand-mid);
        }
        .oa-hero-subtitle {
            max-width: 760px;
            margin: 0.85rem 0 0;
            color: #5f7186;
            font-size: 1rem;
            line-height: 1.65;
        }
        .oa-hero-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 0.7rem;
            margin-top: 1rem;
        }
        .oa-meta-pill {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.52rem 0.82rem;
            border-radius: 999px;
            background: rgba(255,255,255,0.86);
            border: 1px solid rgba(214, 226, 239, 0.96);
            color: #284766;
            font-size: 0.83rem;
            font-weight: 700;
        }
        .oa-hero-actions {
            position: relative;
            z-index: 1;
            display: grid;
            gap: 0.8rem;
            align-content: start;
            overflow: visible;
        }
        .oa-action-card {
            position: relative;
            z-index: 1;
            border: 1px solid rgba(214, 226, 239, 0.95);
            border-radius: 20px;
            background: rgba(255,255,255,0.88);
            padding: 1rem;
            backdrop-filter: blur(8px);
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.7);
            overflow: visible;
        }
        .oa-action-card-title {
            font-size: 0.76rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #6c8197;
            font-weight: 800;
            margin-bottom: 0.65rem;
        }
        .oa-action-stack {
            display: flex;
            flex-wrap: wrap;
            gap: 0.68rem;
        }
        .oa-export-group {
            display: inline-flex;
            align-items: stretch;
            border-radius: 14px;
            box-shadow: 0 14px 24px rgba(35,57,93,0.1);
            position: relative;
            z-index: 20;
        }
        .oa-export-main,
        .oa-export-toggle {
            border-radius: 0 !important;
            box-shadow: none !important;
            min-height: 46px;
        }
        .oa-export-main {
            border-right: 1px solid rgba(35,57,93,0.08);
            border-top-left-radius: 14px !important;
            border-bottom-left-radius: 14px !important;
        }
        .oa-export-toggle {
            min-width: 48px;
            padding-inline: 0.9rem;
            border-top-right-radius: 14px !important;
            border-bottom-right-radius: 14px !important;
        }
        .oa-export-menu {
            border: 1px solid #d7e1ed;
            border-radius: 16px;
            padding: 0.5rem;
            box-shadow: 0 18px 36px rgba(35,57,93,0.12);
            min-width: 240px;
            margin-top: 0.55rem;
            z-index: 1200;
        }
        .oa-export-menu .dropdown-item {
            border-radius: 12px;
            padding: 0.72rem 0.85rem;
            color: #23395d;
            font-weight: 700;
        }
        .oa-export-menu .dropdown-item small {
            display: block;
            color: #6b7d91;
            font-weight: 600;
            margin-top: 0.18rem;
        }
        .oa-export-menu .dropdown-item:hover,
        .oa-export-menu .dropdown-item:focus {
            background: #edf4fb;
            color: #1e3858;
        }
        .oa-toolbar-note {
            color: #607388;
            font-size: 0.9rem;
            line-height: 1.55;
            margin: 0;
        }
        .oa-section-card {
            background: rgba(255,255,255,0.9);
            border: 1px solid rgba(217, 227, 239, 0.95);
            border-radius: 22px;
            box-shadow: 0 14px 32px rgba(35,57,93,0.06);
            padding: 1.15rem;
            margin-bottom: 1rem;
        }
        .oa-summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
            gap: 0.95rem;
        }
        .archive-summary-card {
            position: relative;
            overflow: hidden;
            border-radius: 18px;
            padding: 1.05rem 1rem;
            background: linear-gradient(180deg, #ffffff 0%, #f8fbff 100%);
            border: 1px solid #dce7f2;
            box-shadow: 0 10px 20px rgba(35,57,93,0.05);
        }
        .archive-summary-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, #23395d 0%, #517fa4 100%);
        }
        .archive-summary-card .value {
            font-size: 1.62rem;
        }
        .oa-filters-header,
        .oa-table-headerbar {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 1rem;
            flex-wrap: wrap;
            margin-bottom: 0.9rem;
        }
        .oa-section-title {
            margin: 0;
            font-size: 1.08rem;
            font-weight: 800;
            color: #1f3d61;
        }
        .oa-section-text {
            margin: 0.3rem 0 0;
            color: #64778c;
            font-size: 0.92rem;
        }
        .oa-record-pill {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            border-radius: 999px;
            border: 1px solid #d8e4ef;
            background: #f8fbff;
            color: #294968;
            font-size: 0.84rem;
            font-weight: 800;
            padding: 0.55rem 0.88rem;
            white-space: nowrap;
        }
        .old-filter-form {
            margin-bottom: 0 !important;
            padding: 1rem 1rem 0.2rem !important;
            background: linear-gradient(180deg, #ffffff 0%, #f8fbff 100%) !important;
            border-radius: 20px !important;
        }
        .old-filter-form .col-lg-5.col-md-12 {
            display: flex;
            align-items: flex-end;
        }
        .oa-filter-actions-block {
            width: 100%;
            padding: 0.35rem 0 0;
        }
        .oa-filter-actions-card {
            display: flex;
            align-items: flex-start;
            justify-content: flex-start;
            gap: 0.55rem;
            width: 100%;
            padding: 0.15rem 0 0;
            flex-wrap: nowrap;
            flex-direction: column;
        }
        .oa-filter-actions-card .filter-help-text {
            margin: 0;
            padding-top: 0.2rem;
        }
        .oa-field-label {
            display: block;
            margin-bottom: 0.42rem;
            color: #607388;
            font-size: 0.73rem;
            font-weight: 800;
            letter-spacing: 0.08em;
            text-transform: uppercase;
        }
        .oa-search-wrap {
            position: relative;
        }
        .oa-search-wrap .form-control {
            padding-left: 2.65rem;
            border-radius: 14px;
            background: #fff;
        }
        .oa-search-wrap i {
            position: absolute;
            top: 50%;
            left: 0.95rem;
            transform: translateY(-50%);
            color: #7a8da2;
            font-size: 0.95rem;
            pointer-events: none;
        }
        .old-filter-form .form-select,
        .old-filter-form .form-control {
            min-height: 46px;
            border-radius: 14px;
            border-color: #d7e1ed;
            background: #fff;
            transition: border-color 0.2s ease, box-shadow 0.2s ease, transform 0.2s ease;
        }
        .old-filter-form .form-select:focus,
        .old-filter-form .form-control:focus {
            border-color: #8cb2cf;
            box-shadow: 0 0 0 0.22rem rgba(81,127,164,0.12);
            transform: translateY(-1px);
        }
        .old-filter-form .filter-actions {
            align-items: center;
        }
        .old-filter-form .btn,
        .lock-btn,
        .old-action-toolbar .btn {
            min-height: 46px;
            border-radius: 14px;
            padding-inline: 1rem;
            font-weight: 700;
            transition: transform 0.18s ease, box-shadow 0.18s ease, background 0.18s ease, border-color 0.18s ease;
        }
        .old-filter-form .btn:hover,
        .lock-btn:hover,
        .old-action-toolbar .btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 10px 18px rgba(35,57,93,0.08);
        }
        .old-filter-form .btn-outline-primary,
        .old-filter-form .reset-btn {
            min-width: 150px;
        }
        .old-filter-tools {
            margin-bottom: 0;
        }
        .old-action-toolbar {
            padding: 0;
            margin: 0;
            background: transparent;
            border: none;
        }
        .add-btn,
        .export-btn-green,
        .export-btn-blue,
        .reset-btn,
        .lock-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        .add-btn {
            background: linear-gradient(135deg, #23395d 0%, #33557f 100%);
            box-shadow: 0 14px 24px rgba(35,57,93,0.16);
        }
        .export-btn-green {
            background: linear-gradient(180deg, #eefaf3 0%, #e0f5e7 100%);
        }
        .export-btn-blue {
            background: linear-gradient(180deg, #f0f6fd 0%, #e4eef8 100%);
        }
        .active-filter-chip {
            background: #ffffff;
            box-shadow: 0 6px 14px rgba(35,57,93,0.05);
        }
        .oa-table-panel {
            padding: 1rem;
            background: linear-gradient(180deg, #ffffff 0%, #fbfdff 100%);
        }
        .section-caption {
            margin-bottom: 0.9rem !important;
            border-radius: 18px;
        }
        .oa-table-headerbar .caption-title {
            margin-bottom: 0.2rem;
        }
        .old-account-table-wrap {
            border-radius: 20px;
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.75);
        }
        .old-account-table-wrap .table-responsive {
            border-radius: 20px;
        }
        .old-account-table-wrap .table thead th {
            position: sticky;
            top: 0;
            z-index: 2;
            padding-block: 0.92rem;
            background: linear-gradient(180deg, #eef4fb 0%, #e5edf6 100%) !important;
            color: #203a5a !important;
            letter-spacing: 0.02em;
        }
        .old-account-table-wrap .table tbody td {
            vertical-align: top;
            transition: background 0.2s ease;
        }
        .old-account-table-wrap .table tbody tr {
            transition: transform 0.18s ease, box-shadow 0.18s ease;
        }
        .old-account-table-wrap .table tbody tr:hover {
            transform: translateY(-1px);
            box-shadow: inset 0 0 0 999px rgba(81,127,164,0.04);
        }
        .old-actions {
            gap: 0.5rem;
        }
        .old-list-card .btn.btn-sm,
        .old-list-card .action-btn {
            min-height: 36px;
            border-radius: 12px;
            font-size: 0.82rem;
            padding: 0.42rem 0.8rem;
        }
        .old-list-card .btn-outline-info {
            background: linear-gradient(180deg, #f0f6fd 0%, #e6eff8 100%);
        }
        .old-list-card .btn-outline-warning {
            background: linear-gradient(180deg, #fff6de 0%, #ffefc4 100%);
        }
        .old-list-card .btn-outline-secondary,
        .old-list-card .btn-outline-dark {
            background: linear-gradient(180deg, #f4f7fb 0%, #eaf0f6 100%);
            border-color: #d7e1ed;
            color: #244263;
        }
        .bulk-toolbar {
            padding: 0.8rem 1rem;
            background: #f8fbff;
            border: 1px solid #d9e3ef;
            border-radius: 16px;
        }
        .alert {
            border-radius: 16px;
            border: none;
            box-shadow: 0 10px 18px rgba(35,57,93,0.06);
        }
        @media (max-width: 1180px) {
            .oa-hero {
                grid-template-columns: 1fr;
            }
        }
        @media (max-width: 768px) {
            .oa-shell {
                width: min(100vw - 18px, 1780px);
            }
            .old-list-card {
                padding: 1rem 0.9rem 1.15rem !important;
                width: calc(100vw - 18px);
            }
            .oa-hero {
                padding: 1.1rem 1rem;
                border-radius: 20px;
            }
            .oa-title {
                font-size: 1.7rem;
            }
            .archive-summary-card .value {
                font-size: 1.38rem;
            }
            .old-filter-form .filter-actions {
                justify-content: stretch;
                width: 100%;
                flex-wrap: wrap;
            }
            .oa-filter-actions-card {
                flex-direction: column;
                align-items: stretch;
                flex-wrap: wrap;
            }
            .old-filter-form .filter-actions .btn,
            .old-filter-form .filter-actions .reset-btn,
            .lock-inline-form .btn {
                width: 100%;
            }
            .old-filter-form .col-lg-5.col-md-12 {
                align-items: stretch;
            }
            .old-account-table-wrap table {
                min-width: 1120px;
            }
        }
    </style>
</head>
<body>
<!-- Navbar -->
<?php render_admin_nav('old_accounts', true); ?>
<!-- Dashboard Header -->
<?php render_school_page_header($schoolName); ?>
<!-- Main Card Content -->
<div class="oa-shell">
    <section class="oa-hero">
        <div class="oa-hero-copy">
            <div class="oa-eyebrow"><i class="fas fa-clock-rotate-left"></i> Historical Balance Workspace</div>
            <h1 class="oa-title">Old Accounts <span class="oa-title-accent">Review Hub</span></h1>
            <p class="oa-hero-subtitle">Monitor archived student balances, review follow-up records, and manage linking between old records and current student accounts without changing the existing workflow underneath.</p>
            <div class="oa-hero-meta">
                <span class="oa-meta-pill"><i class="fas fa-layer-group"></i> <?= number_format($total_students_count) ?> filtered record<?= $total_students_count === 1 ? '' : 's' ?></span>
                <span class="oa-meta-pill"><i class="fas fa-link"></i> Historical linking stays active</span>
                <span class="oa-meta-pill"><i class="fas fa-shield-halved"></i> Current logic preserved</span>
            </div>
        </div>
        <div class="oa-hero-actions">
            <div class="oa-action-card">
                <div class="oa-action-card-title">Quick Actions</div>
                <div class="old-action-toolbar">
                    <a href="student-old-add.php" class="btn add-btn mb-0">
                        <i class="fas fa-plus"></i> Add Old Student
                    </a>
                    <div class="btn-group oa-export-group">
                        <a href="/school-admin-dashboard/modules/settings/export/export-old-student.php?<?= htmlspecialchars($old_account_export_query) ?>" class="btn export-btn-green oa-export-main">
                            <i class="fas fa-file-export"></i> Export
                        </a>
                        <button type="button"
                                class="btn export-btn-green dropdown-toggle dropdown-toggle-split oa-export-toggle"
                                data-bs-toggle="dropdown"
                                aria-expanded="false">
                            <span class="visually-hidden">Toggle export options</span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end oa-export-menu">
                            <li>
                                <a class="dropdown-item" href="/school-admin-dashboard/modules/settings/export/export-old-student.php?<?= htmlspecialchars($old_account_export_query) ?>">
                                    <i class="fas fa-table-list me-2"></i> Old Accounts List
                                    <small>Download the filtered old accounts list.</small>
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="/school-admin-dashboard/modules/settings/export/export-old-account-finance.php?<?= htmlspecialchars($old_account_export_query) ?>">
                                    <i class="fas fa-chart-line me-2"></i> Old Accounts Finance Summary
                                    <small>Download the filtered finance summary for old accounts.</small>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="container-fluid old-list-card px-3 px-xl-4">
    <div class="oa-section-card">
        <div class="oa-filters-header">
            <div>
                <div class="view-kicker">Overview</div>
                <div class="old-table-header"><i class="fas fa-user-slash"></i> Old Student Account List</div>
                <div class="old-table-desc">Review archived student histories for graduated, transferred, or withdrawn learners with the current old-account controls intact.</div>
            </div>
        </div>
        <div class="oa-summary-grid archive-summary-grid">
            <div class="archive-summary-card"><div class="label">Filtered Records</div><div class="value"><?= number_format($total_students_count) ?></div></div>
            <div class="archive-summary-card"><div class="label">Graduated</div><div class="value"><?= number_format($status_breakdown['graduated']) ?></div></div>
            <div class="archive-summary-card"><div class="label">Transferred / Withdrawn</div><div class="value"><?= number_format($status_breakdown['transferred'] + $status_breakdown['withdrawn']) ?></div></div>
            <div class="archive-summary-card"><div class="label">With Notes</div><div class="value"><?= number_format($archived_with_notes_count) ?></div></div>
            <div class="archive-summary-card"><div class="label">Needs Follow-up</div><div class="value"><?= number_format($needs_follow_up_count) ?></div></div>
        </div>
    </div>
    <?php if ($delete_success): ?>
        <div class="alert alert-success" role="alert">
            <i class="fas fa-check-circle"></i> Old student deleted successfully.
        </div>
    <?php endif; ?>
    <?php if (isset($_GET['bulk_deleted'])): ?>
        <div class="alert alert-success" role="alert">
            <i class="fas fa-check-circle"></i> Deleted <?= number_format((int) $_GET['bulk_deleted']) ?> old student record(s).
        </div>
    <?php endif; ?>
    <div class="oa-section-card">
    <div class="oa-filters-header">
        <div>
            <h2 class="oa-section-title">Search and Filter</h2>
            <p class="oa-section-text">Refine the current old-account view without changing the backend behavior. Everything below still uses the same forms and data source.</p>
        </div>
        <div class="oa-record-pill"><i class="fas fa-sliders"></i> Old Accounts filter workspace</div>
    </div>
    <div class="old-filter-tools">
        <div class="filter-help-text">Use one filter row for old-account review, then lock the exact view if you need to preserve it.</div>
    </div>
    <!-- Filter Form -->
    <form method="get" class="row mb-3 g-2 old-filter-form <?= $filters_locked ? 'filters-locked' : '' ?>">
        <div class="col-lg-3 col-md-6">
            <label class="oa-field-label" for="oldAccountsName">Search Name</label>
            <div class="oa-search-wrap">
                <i class="fas fa-magnifying-glass"></i>
                <input id="oldAccountsName" type="text" name="name" value="<?= htmlspecialchars($_GET['name'] ?? '') ?>"
                       class="form-control" placeholder="Lastname, firstname, middlename" <?= $filters_locked ? 'readonly' : '' ?>>
            </div>
        </div>
        <div class="col-lg-2 col-md-6">
            <label class="oa-field-label" for="oldAccountsSchoolYear">School Year</label>
            <select id="oldAccountsSchoolYear" name="school_year" class="form-select" <?= $filters_locked ? 'disabled' : '' ?>>
                <option value="">All School Years</option>
                <?php foreach ($school_years as $sy): ?>
                    <option value="<?= htmlspecialchars($sy) ?>" <?= $selected_school_year === $sy ? 'selected' : '' ?>>SY <?= htmlspecialchars($sy) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-lg-2 col-md-6">
            <label class="oa-field-label" for="oldAccountsFollowUp">Follow-up</label>
            <select id="oldAccountsFollowUp" name="follow_up" class="form-select" <?= $filters_locked ? 'disabled' : '' ?>>
                <option value="">All Follow-up</option>
                <?php foreach ($follow_up_options as $option_value => $option_label): ?>
                    <option value="<?= htmlspecialchars($option_value) ?>" <?= $selected_follow_up === $option_value ? 'selected' : '' ?>><?= htmlspecialchars($option_label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-lg-2 col-md-6">
            <label class="oa-field-label" for="oldAccountsAnchorView">Anchor View</label>
            <select id="oldAccountsAnchorView" name="head_anchor" class="form-select" <?= $filters_locked ? 'disabled' : '' ?>>
                <option value="">All Anchor Views</option>
                <option value="1" <?= $head_anchor_filter_enabled ? 'selected' : '' ?>>Head Anchor Only</option>
            </select>
        </div>
        <div class="col-lg-5 col-md-12">
            <label class="oa-field-label d-none d-lg-block">&nbsp;</label>
            <div class="oa-filter-actions-block">
                <div class="oa-filter-actions-card">
                    <div class="filter-actions">
                        <button type="submit" class="btn btn-outline-primary" <?= $filters_locked ? 'disabled' : '' ?>>
                            <i class="fas fa-filter"></i> Apply Filter
                        </button>
                        <a href="student-old-account-list.php" class="btn reset-btn <?= $filters_locked ? 'disabled' : '' ?>">
                            <i class="fas fa-sync-alt"></i> Clear Filter
                        </a>
                        <button type="submit"
                                form="lockCurrentFilterForm"
                                name="<?= $filters_locked ? 'clear_lock_all' : 'lock_all' ?>"
                                class="btn lock-btn <?= $filters_locked ? 'locked' : '' ?>">
                            <i class="fas <?= $filters_locked ? 'fa-lock' : 'fa-key' ?>"></i> <?= $filters_locked ? 'Unlock View' : 'Lock View' ?>
                        </button>
                    </div>
                    <div class="filter-help-text"><?= $filters_locked ? 'This filtered view is locked until you unlock it.' : 'Lock the current filter set when you want to keep the exact old-account view in place.' ?></div>
                </div>
            </div>
        </div>
    </form>
    <form method="post" id="lockCurrentFilterForm" class="d-none">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(admin_csrf_token()) ?>">
        <input type="hidden" name="name" value="<?= htmlspecialchars($name_filter) ?>">
        <input type="hidden" name="school_year" value="<?= htmlspecialchars($selected_school_year) ?>">
        <input type="hidden" name="follow_up" value="<?= htmlspecialchars($selected_follow_up) ?>">
        <input type="hidden" name="head_anchor" value="<?= $head_anchor_filter_enabled ? '1' : '' ?>">
    </form>
    </div>
    <?php if ($name_filter !== '' || $selected_school_year !== '' || $selected_follow_up !== '' || $head_anchor_filter_enabled): ?>
        <div class="mb-3">
            <?php if ($name_filter !== ''): ?><span class="active-filter-chip"><i class="fas fa-font"></i> Name: <?= htmlspecialchars($name_filter) ?></span><?php endif; ?>
            <?php if ($selected_school_year !== ''): ?><span class="active-filter-chip"><i class="fas fa-calendar-alt"></i> School Year: <?= htmlspecialchars($selected_school_year) ?></span><?php endif; ?>
            <?php if ($selected_follow_up !== ''): ?><span class="active-filter-chip"><i class="fas fa-clipboard-check"></i> Follow-up: <?= htmlspecialchars(old_account_followup_label($selected_follow_up)) ?></span><?php endif; ?>
            <?php if ($head_anchor_filter_enabled): ?><span class="active-filter-chip"><i class="fas fa-diagram-project"></i> Head Anchor Only</span><?php endif; ?>
        </div>
    <?php endif; ?>
    <!-- LOCK VIEW INDICATOR (top of table) -->
    <?php if ($filters_locked): ?>
        <div class="mb-2">
            <span class="text-danger"><i class="fas fa-lock"></i> <b>Locked view</b> (Name: <strong><?= htmlspecialchars($_GET['name']) ?></strong>, School Year: <strong><?= htmlspecialchars($_GET['school_year']) ?></strong>, Follow-up: <strong><?= htmlspecialchars(old_account_followup_label($_GET['follow_up'] ?? '')) ?></strong>, Head Anchor: <strong><?= $head_anchor_filter_enabled ? 'On' : 'Off' ?></strong>)</span>
        </div>
    <?php endif; ?>
    <div class="oa-section-card oa-table-panel">
    <div class="oa-table-headerbar">
        <div id="archive-list" class="section-caption d-flex justify-content-between align-items-center flex-wrap gap-2 mb-0">
            <div>
                <div class="caption-title"><i class="fas fa-table-list me-1"></i> Archive Student List</div>
                <div class="caption-text">Records are grouped by school year so each archive cycle stays separate even when the same student appears across multiple years.</div>
            </div>
        </div>
        <div class="oa-record-pill">
            <i class="fas fa-layer-group"></i>
            <?= $grouped_old_account_rows ? number_format(count($grouped_old_account_rows)) . ' school-year section(s)' : 'No school-year sections' ?>
        </div>
    </div>
    <?php if ($can_delete): ?>
    <div class="bulk-toolbar">
        <div class="selection-note"><span id="oldStudentSelectionCount">0</span> selected</div>
        <div class="d-flex gap-2">
            <button type="button" class="btn btn-outline-secondary btn-sm" id="oldStudentToggleAllBtn">
                <i class="fas fa-check-square"></i> Mark All
            </button>
            <button type="submit" form="bulkOldStudentDeleteForm" class="btn btn-danger btn-sm" id="bulkOldStudentDeleteBtn" disabled>
                <i class="fas fa-trash"></i> Delete Selected
            </button>
        </div>
    </div>
    <?php endif; ?>
    <form method="post" action="student-old-bulk-delete.php" id="bulkOldStudentDeleteForm">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
    <?php if ($grouped_old_account_rows): ?>
    <div class="old-year-accordion" id="oldYearAccordion">
        <?php foreach ($grouped_old_account_rows as $schoolYearLabel => $yearRows): ?>
        <?php $yearSectionId = 'oldYearSection' . md5($schoolYearLabel); ?>
        <?php $shouldExpand = $selected_school_year !== '' && old_account_normalize_school_year_option($schoolYearLabel) === $selected_school_year; ?>
        <section class="old-year-card">
            <button
                type="button"
                class="old-year-toggle"
                data-bs-toggle="collapse"
                data-bs-target="#<?= htmlspecialchars($yearSectionId) ?>"
                aria-expanded="<?= $shouldExpand ? 'true' : 'false' ?>"
                aria-controls="<?= htmlspecialchars($yearSectionId) ?>"
            >
                <div class="old-year-heading">
                    <div>
                        <div class="old-year-title"><?= htmlspecialchars($schoolYearLabel) ?></div>
                        <div class="old-year-subtitle">Open this school year to review only the archived records registered in this cycle.</div>
                    </div>
                    <div class="old-year-meta">
                        <span class="old-year-count"><i class="fas fa-users"></i> <?= number_format(count($yearRows)) ?> record(s)</span>
                        <span class="old-year-chevron"><i class="fas fa-chevron-down"></i></span>
                    </div>
                </div>
            </button>
            <div id="<?= htmlspecialchars($yearSectionId) ?>" class="collapse<?= $shouldExpand ? ' show' : '' ?>" data-bs-parent="#oldYearAccordion">
                <div class="old-year-body">
                    <div class="old-account-table-wrap">
                    <div class="table-responsive">
                    <table class="table table-bordered table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <?php if ($can_delete): ?><th><input type="checkbox" class="old-year-select-all" data-target-year="<?= htmlspecialchars($yearSectionId) ?>"></th><?php endif; ?>
                                <th>Name</th>
                                <th>Status</th>
                                <th>Link Status</th>
                                <th>Anchor Status</th>
                                <th>Follow-up</th>
                                <th>School Year</th>
                                <th>Contact</th>
                                <th>Reason/Notes</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($yearRows as $row): ?>
                                <?php
                                    $historyNameKey = mb_strtolower(trim((string) (($row['lastname'] ?? '') . '|' . ($row['firstname'] ?? '') . '|' . ($row['middlename'] ?? ''))));
                                    $historyMeta = $old_account_name_history_map[$historyNameKey] ?? ['years' => [], 'records' => 0];
                                    $historyYearCount = count($historyMeta['years']);
                                    $historyRecordCount = (int) ($historyMeta['records'] ?? 0);
                                ?>
                                <tr data-old-year-group="<?= htmlspecialchars($yearSectionId) ?>">
                                    <?php if ($can_delete): ?><td><input type="checkbox" class="old-student-row-check" name="selected_ids[]" value="<?= (int) $row['id'] ?>"></td><?php endif; ?>
                                    <td class="old-account-name">
                                        <div class="student-name">
                                            <?= htmlspecialchars($row['lastname']) ?>,
                                            <?= htmlspecialchars($row['firstname']) ?>
                                            <?= $row['middlename'] ? htmlspecialchars(' '.$row['middlename']) : '' ?>
                                        </div>
                                        <div class="student-sub">Old Student ID: <?= (int) $row['id'] ?></div>
                                        <?php if ($historyYearCount > 1): ?>
                                            <div class="continuity-chip">
                                                <i class="fas fa-clock-rotate-left"></i>
                                                Historical repeats: <?= number_format($historyYearCount) ?> year(s)
                                            </div>
                                            <div class="continuity-note">
                                                This same student name appears in <?= number_format($historyRecordCount) ?> archived record(s) across <?= number_format($historyYearCount) ?> school year(s).
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                            $badge = 'bg-secondary';
                                            if ($row['status'] == 'graduated') $badge = 'bg-success';
                                            elseif ($row['status'] == 'transferred') $badge = 'bg-info text-dark';
                                            elseif ($row['status'] == 'withdrawn') $badge = 'bg-warning text-dark';
                                            elseif ($row['status'] == 'active') $badge = 'bg-primary';
                                            if ($row['status']) {
                                        ?>
                                            <span class="badge <?= $badge ?>">
                                                <?= htmlspecialchars(ucfirst($row['status'])) ?>
                                            </span>
                                        <?php } else { ?>
                                            <span class="text-muted">-</span>
                                        <?php } ?>
                                    </td>
                                    <td class="old-followup-cell">
                                        <?php $linkedStudentExists = !empty($row['linked_lastname']) || !empty($row['linked_firstname']); ?>
                                        <span class="badge <?= old_account_link_status_badge_class($row['status'] ?? '', (int) ($row['linked_student_id'] ?? 0), $linkedStudentExists) ?>">
                                            <?= htmlspecialchars(old_account_link_status_label($row['status'] ?? '', (int) ($row['linked_student_id'] ?? 0), $linkedStudentExists)) ?>
                                        </span>
                                        <div class="small text-muted mt-1">
                                            <?= htmlspecialchars(
                                                $linkedStudentExists
                                                    ? 'Current: ' . trim((string) (($row['linked_lastname'] ?? '') . ', ' . ($row['linked_firstname'] ?? '') . ' ' . ($row['linked_middlename'] ?? '')))
                                                        . ' | ' . trim((string) ($row['linked_grade'] ?? '-'))
                                                        . ' | ' . trim((string) ($row['linked_section'] ?? '-'))
                                                    : old_account_link_status_note($row['status'] ?? '', (int) ($row['linked_student_id'] ?? 0), $linkedStudentExists)
                                            ) ?>
                                        </div>
                                    </td>
                                    <td class="old-anchor-cell">
                                        <?php $anchorHeadId = (int) ($row['old_anchor_id'] ?? 0); ?>
                                        <?php $effectiveAnchorClass = $linkedStudentExists ? 'bg-success' : old_account_anchor_status_badge_class((int) $row['id'], $anchorHeadId); ?>
                                        <?php $isHeadAnchorRow = !$linkedStudentExists && old_account_anchor_status_key((int) $row['id'], $anchorHeadId) === 'head_anchor'; ?>
                                        <span class="badge <?= $effectiveAnchorClass ?>">
                                            <?= htmlspecialchars(old_account_effective_anchor_label($linkedStudentExists, (int) $row['id'], $anchorHeadId)) ?>
                                        </span>
                                        <div class="small text-muted mt-1">
                                            <?= htmlspecialchars(
                                                old_account_effective_anchor_note(
                                                    $linkedStudentExists,
                                                    (int) $row['id'],
                                                    $anchorHeadId,
                                                    trim((string) (($row['anchor_lastname'] ?? '') . ', ' . ($row['anchor_firstname'] ?? '') . ' ' . ($row['anchor_middlename'] ?? ''))),
                                                    (string) ($row['anchor_school_year'] ?? '')
                                                )
                                            ) ?>
                                        </div>
                                        <?php if ($isHeadAnchorRow): ?>
                                            <?php $linkedMemberCount = old_account_anchor_member_count($conn, (int) $row['id'], true); ?>
                                            <div class="anchor-link-count">
                                                <i class="fas fa-link"></i> Linked: <?= number_format($linkedMemberCount) ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="old-followup-cell">
                                        <span class="badge <?= old_account_followup_badge_class($row['follow_up_status'] ?? 'record_only') ?>">
                                            <?= htmlspecialchars(old_account_followup_label($row['follow_up_status'] ?? 'record_only')) ?>
                                        </span>
                                        <?php if (trim((string) ($row['follow_up_note'] ?? '')) !== ''): ?>
                                            <div class="small text-muted mt-1"><?= htmlspecialchars($row['follow_up_note']) ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($row['school_year'] ?? '-') ?></td>
                                    <td class="old-contact-cell"><?= htmlspecialchars($row['contact'] ?? '-') ?></td>
                                    <td class="old-notes-cell"><?= htmlspecialchars($row['notes'] ?? '-') ?></td>
                                    <td>
                                        <div class="old-actions">
                                        <a href="student-old-payment-history.php?id=<?= urlencode($row['id']) ?>" class="btn btn-sm btn-outline-info">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <?php if ($can_edit): ?>
                                            <a href="student-old-edit.php?id=<?= urlencode($row['id']) ?>" class="btn btn-sm btn-outline-warning action-btn">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>
                                        <?php endif; ?>
                                        <?php if ($can_manage_old_account_link): ?>
                                            <a href="student-old-link-student.php?id=<?= urlencode($row['id']) ?>" class="btn btn-sm btn-outline-dark action-btn">
                                                <i class="fas fa-link"></i> <?= !empty($row['linked_student_id']) ? 'Change Link' : 'Link Student' ?>
                                            </a>
                                            <?php if (!$linkedStudentExists): ?>
                                                <a href="student-old-anchor-head.php?id=<?= urlencode($row['id']) ?>" class="btn btn-sm btn-outline-secondary action-btn">
                                                    <i class="fas fa-diagram-project"></i> <?= (int) ($row['old_anchor_id'] ?? 0) > 0 ? 'Anchor Head' : 'Set Anchor' ?>
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    </div>
                    </div>
                </div>
            </div>
        </section>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="old-account-table-wrap">
        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle mb-0">
                <tbody>
                    <tr>
                        <td colspan="<?= $can_delete ? 10 : 9 ?>" class="text-center">No old students found.</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
    </form>
    </div>
    </div>
</div>
<footer class="text-center py-4 text-muted small">
    &copy; <?= date("Y") ?> <?= $schoolName ?> | School Admin Dashboard
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Theme toggle
    const themeToggleBtn = document.getElementById('themeToggleBtn');
    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');
            this.querySelector('i').classList.toggle('fa-moon');
            this.querySelector('i').classList.toggle('fa-sun');
        });
    }

    const oldStudentChecks = Array.from(document.querySelectorAll('.old-student-row-check'));
    const oldStudentSelectAll = document.getElementById('oldStudentSelectAll');
    const oldYearSelectAll = Array.from(document.querySelectorAll('.old-year-select-all'));
    const oldStudentToggleAllBtn = document.getElementById('oldStudentToggleAllBtn');
    const oldStudentSelectionCount = document.getElementById('oldStudentSelectionCount');
    const bulkOldStudentDeleteBtn = document.getElementById('bulkOldStudentDeleteBtn');

    function updateOldStudentSelectionState() {
        if (!oldStudentSelectionCount || !bulkOldStudentDeleteBtn) return;
        const checked = oldStudentChecks.filter(cb => cb.checked).length;
        oldStudentSelectionCount.textContent = checked;
        bulkOldStudentDeleteBtn.disabled = checked === 0;
        if (oldStudentSelectAll) {
            oldStudentSelectAll.checked = oldStudentChecks.length > 0 && checked === oldStudentChecks.length;
        }
        if (oldStudentToggleAllBtn) {
            oldStudentToggleAllBtn.innerHTML = checked === oldStudentChecks.length && checked > 0
                ? '<i class="fas fa-square"></i> Unmark All'
                : '<i class="fas fa-check-square"></i> Mark All';
        }
        oldYearSelectAll.forEach(function(toggle) {
            const targetYear = toggle.getAttribute('data-target-year');
            const yearChecks = oldStudentChecks.filter(cb => cb.closest('tr')?.getAttribute('data-old-year-group') === targetYear);
            const yearChecked = yearChecks.filter(cb => cb.checked).length;
            toggle.checked = yearChecks.length > 0 && yearChecked === yearChecks.length;
        });
    }

    if (oldStudentSelectAll) {
        oldStudentSelectAll.addEventListener('change', function() {
            oldStudentChecks.forEach(cb => cb.checked = oldStudentSelectAll.checked);
            updateOldStudentSelectionState();
        });
    }

    oldYearSelectAll.forEach(function(toggle) {
        toggle.addEventListener('change', function() {
            const targetYear = toggle.getAttribute('data-target-year');
            oldStudentChecks.forEach(function(cb) {
                if (cb.closest('tr')?.getAttribute('data-old-year-group') === targetYear) {
                    cb.checked = toggle.checked;
                }
            });
            updateOldStudentSelectionState();
        });
    });

    if (oldStudentToggleAllBtn) {
        oldStudentToggleAllBtn.addEventListener('click', function() {
            const allChecked = oldStudentChecks.length > 0 && oldStudentChecks.every(cb => cb.checked);
            oldStudentChecks.forEach(cb => cb.checked = !allChecked);
            if (oldStudentSelectAll) oldStudentSelectAll.checked = !allChecked;
            updateOldStudentSelectionState();
        });
    }

    oldStudentChecks.forEach(cb => cb.addEventListener('change', updateOldStudentSelectionState));
    updateOldStudentSelectionState();
</script>
</body>
</html>
<?php
$conn->close();
?>
