﻿<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require '../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
include_once __DIR__ . '/old-account-followup-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/includes-receipt-helper.php';
require_once __DIR__ . '/../../includes/receipt-payment-method-helper.php';
include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');
include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/includes/schema-migration.php');
require_once __DIR__ . '/old-payments-schema-helper.php';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn->set_charset('utf8mb4');
ensure_old_student_followup_columns($conn);
$hasOldAnchorColumn = old_account_column_exists($conn, 'old_anchor_id');
function ensure_old_payment_datetime_column(mysqli $conn): void {
    if (!schema_migration_mode_enabled()) {
        return;
    }
    $columnName = 'paid_at_datetime';
    $check = $conn->prepare("
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'old_student_payments'
          AND COLUMN_NAME = ?
        LIMIT 1
    ");
    $check->bind_param('s', $columnName);
    $check->execute();
    $exists = $check->get_result()->num_rows > 0;
    $check->close();
    if (!$exists) {
        schema_migration_attempt($conn, "ALTER TABLE old_student_payments ADD COLUMN paid_at_datetime DATETIME NULL AFTER paid_at");
    }
}
ensure_old_payment_datetime_column($conn);

// CSRF & HTML Escape
admin_csrf_token();
function csrf_check($token) { return admin_csrf_validate((string) $token); }
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function old_payment_extract_ref_from_note(?string $note): string
{
    $note = (string) ($note ?? '');
    if (preg_match('/Ref#:\s*([A-Za-z0-9\-_]+)/', $note, $m)) {
        return (string) $m[1];
    }
    return '';
}

function old_payment_extract_note_from_status(?string $status): string
{
    $status = (string) ($status ?? '');
    if (preg_match('/\(Note:\s*(.*?)\)\s*$/i', $status, $m)) {
        return trim((string) $m[1]);
    }
    return '';
}

function old_payment_infer_method(string $status, string $reference): string
{
    $s = strtolower($status);
    if (strpos($s, 'gcash') !== false) {
        return 'GCash';
    }
    if (strpos($s, 'bank transfer') !== false || strpos($s, 'banktransfer') !== false) {
        return 'Bank Transfer';
    }
    if ($reference !== '') {
        return 'Digital';
    }
    return '-';
}

function old_payment_group_append_unique(array &$bucket, string $value): void
{
    $value = trim($value);
    if ($value === '' || in_array($value, $bucket, true)) {
        return;
    }
    $bucket[] = $value;
}

// Receipt booklet config
const BOOKLET_MIN = REGULAR_BOOKLET_MIN;
const BOOKLET_MAX = REGULAR_BOOKLET_MAX;
[$GLOBAL_RECEIPT_MIN, $GLOBAL_RECEIPT_MAX] = (function() {
    [$sMin, ] = receipt_window_for_booklet(BOOKLET_MIN);
    [, $eMax] = receipt_window_for_booklet(BOOKLET_MAX);
    return [$sMin, $eMax];
})();

$student_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$student_id) {
    header("Location: /school-admin-dashboard/modules/old accounts/student-old-account-list.php");
    exit();
}

// Permissions
$user_role = $_SESSION['role'] ?? '';
$can_add_payment = hasPermission($user_role, 'financial', 'add');
$can_edit_fee_balance = hasPermission($user_role, 'student_data', 'edit');
$can_delete_fee_row = hasPermission($user_role, 'student_data', 'delete'); // Super admin only
$can_delete_payment_row = (strtolower($user_role) === 'super administrator');
$can_view_receipt = hasPermission($user_role, 'financial', 'view');
$can_manage_old_account_link = is_super_admin_role($user_role);
if (!$can_view_receipt) {
    header('Location: /school-admin-dashboard/dashboard.php?error=old_accounts_denied');
    exit();
}

// Student
$stmt = $conn->prepare("
    SELECT
        os.*,
        s.lastname AS linked_lastname,
        s.firstname AS linked_firstname,
        s.middlename AS linked_middlename,
        s.grade AS linked_grade,
        s.section AS linked_section,
        s.lrn AS linked_lrn,
        s.school_year_label AS linked_school_year_label" .
        ($hasOldAnchorColumn ? ",
        anchor.lastname AS anchor_lastname,
        anchor.firstname AS anchor_firstname,
        anchor.middlename AS anchor_middlename,
        anchor.school_year AS anchor_school_year" : ",
        '' AS anchor_lastname,
        '' AS anchor_firstname,
        '' AS anchor_middlename,
        '' AS anchor_school_year") . "
    FROM old_students os
    LEFT JOIN students s ON s.id = os.linked_student_id
    " . ($hasOldAnchorColumn ? "LEFT JOIN old_students anchor ON anchor.id = os.old_anchor_id" : "") . "
    WHERE os.id = ?
");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$student) { echo "<div class='alert alert-danger'>Old student not found.</div>"; exit(); }
$school_year = $student['school_year'] ?? '';
$linked_student_id = (int) ($student['linked_student_id'] ?? 0);
$old_anchor_id = $hasOldAnchorColumn ? (int) ($student['old_anchor_id'] ?? 0) : 0;
$anchor_related_records = $old_anchor_id > 0 ? old_account_anchor_related_records($conn, $old_anchor_id) : [];

// Fees for this student
$fee_rows = [];
$stmt = $conn->prepare("SELECT * FROM old_student_fees WHERE old_student_id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $fee_rows[$row['fee_type']] = $row;
$stmt->close();

// Used receipts by booklet + next available (from registry)
$used_receipts_by_booklet = [];
$next_available_receipt_by_booklet = [];
for ($b = BOOKLET_MIN; $b <= BOOKLET_MAX; $b++) {
    [$used, $next] = get_receipts_for_booklet($conn, $b);
    $used_receipts_by_booklet[$b] = $used;
    $next_available_receipt_by_booklet[$b] = $next;
}

// Next available globally
$next_receipt_no = get_next_regular_receipt_no($conn);

// Messages
$error = $success = "";

// Delete Fee Row (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_fee']) && $can_delete_fee_row) {
    if (!csrf_check($_POST['csrf_token'] ?? '')) {
        $error = "Invalid CSRF token.";
    } else {
        $del_id = intval($_POST['delete_fee']);
        $stmt = $conn->prepare("SELECT id, fee_type FROM old_student_fees WHERE id = ? AND old_student_id = ?");
        $stmt->bind_param("ii", $del_id, $student_id);
        $stmt->execute();
        $fee_row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($fee_row) {
            $stmt = $conn->prepare("DELETE FROM old_student_fees WHERE id = ? AND old_student_id = ?");
            $stmt->bind_param("ii", $del_id, $student_id);
            $stmt->execute();
            $stmt->close();

            // ---------- AUDIT LOGGING: Delete Fee Row ----------
            include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');
            $user = $_SESSION['username'] ?? 'unknown';
            $action = "Deleted old student fee row";
            $module = "Old Accounts";
            $details = "Role: " . ($_SESSION['role'] ?? 'unknown') .
                       " | Old Student ID: " . $student_id .
                       " | Fee Row ID: " . $del_id .
                       " | Fee Type: " . ($fee_row['fee_type'] ?? 'unknown') .
                       " | Deleted by: " . $user;
            audit_log($conn, $user, $action, $module, $details);

            $success = "Fee row deleted.";
        } else {
            $error = "Cannot delete this fee row.";
        }
    }
}

// Utility for dynamic bind_param
function dynamic_bind_params($stmt, $types, $params) {
    $bind_names[] = $types;
    for ($i=0; $i<count($params);$i++) {
        $bind_name = 'bind' . $i;
        $$bind_name = $params[$i];
        $bind_names[] = &$$bind_name;
    }
    call_user_func_array([$stmt, 'bind_param'], $bind_names);
}

// Pagination logic
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 10;

// Load all NOT DELETED payments, then paginate by grouped receipts so a single OR never gets split across pages.
$stmt = $conn->prepare("SELECT COUNT(*) FROM old_student_payments WHERE old_student_id = ? AND deleted_at IS NULL");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$stmt->bind_result($total_payments);
$stmt->fetch();
$stmt->close();

$stmt = $conn->prepare("SELECT *, COALESCE(paid_at_datetime, CONCAT(paid_at, ' 00:00:00')) AS paid_at_full FROM old_student_payments WHERE old_student_id = ? AND deleted_at IS NULL ORDER BY COALESCE(paid_at_datetime, CONCAT(paid_at, ' 00:00:00')) DESC, id DESC");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$res = $stmt->get_result();
$allPayments = [];
while ($row = $res->fetch_assoc()) {
    $allPayments[] = $row;
}
$stmt->close();

$total_paid_amount = 0.0;
foreach ($allPayments as $paymentRow) {
    $total_paid_amount += (float) ($paymentRow['amount'] ?? 0);
}
$receipt_registry_active_count = 0;
$receipt_registry_voided_count = 0;
$receipt_registry_missing_count = 0;
$payment_receipt_state = [];
foreach ($allPayments as $paymentRow) {
    $receipt_no = (int) ($paymentRow['receipt_no'] ?? 0);
    $booklet_no = (int) ($paymentRow['booklet_no'] ?? 0);
    $receipt_entry = ($receipt_no > 0)
        ? get_receipt_registry_entry($conn, $receipt_no, $booklet_no)
        : null;

    if ($receipt_entry && (int) ($receipt_entry['voided'] ?? 0) === 1) {
        $receipt_registry_voided_count++;
        $payment_receipt_state[(int) $paymentRow['id']] = [
            'label' => 'Voided',
            'class' => 'bg-warning text-dark',
            'note' => 'Receipt exists in the registry but is marked voided.',
        ];
    } elseif ($receipt_entry) {
        $receipt_registry_active_count++;
        $payment_receipt_state[(int) $paymentRow['id']] = [
            'label' => 'Linked',
            'class' => 'bg-success',
            'note' => 'Receipt is linked cleanly in the registry.',
        ];
    } else {
        $receipt_registry_missing_count++;
        $payment_receipt_state[(int) $paymentRow['id']] = [
            'label' => 'Missing',
            'class' => 'bg-danger',
            'note' => 'No matching receipt registry row was found for this payment.',
        ];
    }
}
$receiptGroups = [];
foreach ($allPayments as $paymentRow) {
    $receiptNo = (int) ($paymentRow['receipt_no'] ?? 0);
    $bookletNo = (int) ($paymentRow['booklet_no'] ?? 0);
    $paidAtFull = (string) ($paymentRow['paid_at_full'] ?? '');
    $groupKey = ($receiptNo > 0 && $bookletNo > 0)
        ? ('receipt-' . $bookletNo . '-' . $receiptNo)
        : ('row-' . (int) ($paymentRow['id'] ?? 0));

    if (!isset($receiptGroups[$groupKey])) {
        $receiptState = $payment_receipt_state[(int) ($paymentRow['id'] ?? 0)] ?? [
            'label' => 'Missing',
            'class' => 'bg-danger',
            'note' => 'No matching receipt registry row was found for this payment.',
        ];
        $receiptGroups[$groupKey] = [
            'group_key' => $groupKey,
            'modal_id' => 'oldReceiptDrilldown' . preg_replace('/[^a-zA-Z0-9_-]/', '', $groupKey),
            'paid_at_full' => $paidAtFull,
            'booklet_no' => $bookletNo,
            'booklet_label' => booklet_label_from_stored($bookletNo),
            'receipt_no' => $receiptNo,
            'receipt_state' => $receiptState,
            'method_label' => '',
            'reference_display' => '',
            'payment_note_display' => '',
            'method_breakdown_text' => '',
            'method_breakdown' => [],
            'remarks' => [],
            'prepared_by' => '',
            'items' => [],
            'total' => 0.0,
        ];
    }

    $methodBreakdown = receipt_payment_methods_for_display(
        $conn,
        $bookletNo,
        $receiptNo,
        'old_student_payments',
        (string) ($paymentRow['payment_method'] ?? ''),
        (string) ($paymentRow['reference_number'] ?? ''),
        (string) ($paymentRow['payment_note'] ?? '')
    );
    $method = receipt_payment_methods_display_label($methodBreakdown, '');
    $ref = receipt_payment_methods_reference_display($methodBreakdown, '');
    $payNote = receipt_payment_methods_note_display($methodBreakdown, '');
    $statusNote = (string) ($paymentRow['note'] ?? '');
    if ($ref === '' && $statusNote !== '') {
        $ref = old_payment_extract_ref_from_note($statusNote);
    }
    if ($payNote === '' && $statusNote !== '') {
        $payNote = old_payment_extract_note_from_status($statusNote);
    }
    if ($method === '' && $statusNote !== '') {
        $method = old_payment_infer_method($statusNote, $ref);
    }

    if ($receiptGroups[$groupKey]['method_label'] === '' && $method !== '') {
        $receiptGroups[$groupKey]['method_label'] = $method;
    }
    if ($receiptGroups[$groupKey]['reference_display'] === '' && $ref !== '') {
        $receiptGroups[$groupKey]['reference_display'] = $ref;
    }
    if ($receiptGroups[$groupKey]['payment_note_display'] === '' && $payNote !== '') {
        $receiptGroups[$groupKey]['payment_note_display'] = $payNote;
    }
    if ($receiptGroups[$groupKey]['method_breakdown_text'] === '' && !empty($methodBreakdown)) {
        $receiptGroups[$groupKey]['method_breakdown_text'] = receipt_payment_methods_summary_text($methodBreakdown);
        $receiptGroups[$groupKey]['method_breakdown'] = $methodBreakdown;
    }
    if ($receiptGroups[$groupKey]['prepared_by'] === '') {
        $preparedByValue = trim((string) ($paymentRow['prepared_by'] ?? ''));
        if ($preparedByValue === '') {
            $preparedByValue = trim((string) ($paymentRow['processed_by'] ?? ''));
        }
        if ($preparedByValue !== '') {
            $receiptGroups[$groupKey]['prepared_by'] = $preparedByValue;
        }
    }
    $receiptGroups[$groupKey]['items'][] = [
        'payment_id' => (int) ($paymentRow['id'] ?? 0),
        'fee_type' => (string) ($paymentRow['fee_type'] ?? ''),
        'amount' => (float) ($paymentRow['amount'] ?? 0),
        'status_note' => $statusNote,
    ];
    $receiptGroups[$groupKey]['total'] += (float) ($paymentRow['amount'] ?? 0);
    old_payment_group_append_unique($receiptGroups[$groupKey]['remarks'], $statusNote);
}

$receiptGroups = array_values($receiptGroups);
$total_grouped_receipts = count($receiptGroups);
$total_pages = max(1, (int) ceil($total_grouped_receipts / $per_page));
$page = min($page, $total_pages);
$offset = ($page - 1) * $per_page;
$groupedPayments = array_slice($receiptGroups, $offset, $per_page);
$outstanding_fee_count = 0;
foreach ($fee_rows as $feeRow) {
    if ((float) ($feeRow['balance'] ?? 0) > 0) {
        $outstanding_fee_count++;
    }
}

// Status utility
function get_fee_status($balance) {
    $balance = (float)$balance;
    if ($balance == 0.0) return ['Fully Paid', 'bg-success'];
    if ($balance <= 500.0) return ['Low Balance', 'bg-warning text-dark'];
    return ['Outstanding', 'bg-danger'];
}

$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";
$csrf_token = admin_csrf_token();
$legacyPreparedByLabel = 'Not Captured';
$legacyPreparedByDetail = 'Not captured in old record';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Old Student Payment History<?= $school_year ? " - " . h($school_year) : "" ?> | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script>
        const BOOKLET_MIN = <?= BOOKLET_MIN ?>;
        const BOOKLET_MAX = <?= BOOKLET_MAX ?>;
        var usedReceiptsByBooklet = <?= json_encode($used_receipts_by_booklet) ?>;
        var nextAvailableReceiptByBooklet = <?= json_encode($next_available_receipt_by_booklet) ?>;
function bookletReceiptRange(b) {
            let start = <?= REGULAR_RECEIPT_START ?> + (b - <?= REGULAR_BOOKLET_RECEIPT_ANCHOR ?>) * <?= REGULAR_RECEIPTS_PER_BOOKLET ?>;
            let end = start + <?= REGULAR_RECEIPTS_PER_BOOKLET - 1 ?>;
            return [start, end];
        }
    </script>
    <style>
        :root { --main-bg:#f5f8fc; --card-bg:#fff; --navbar-bg:#23395d; --brand-blue:#517fa4; --brand-dark:#23395d; }
        body { background:var(--main-bg); font-family:'Segoe UI','Roboto','Arial',sans-serif; }
        body.dark-mode { --main-bg:#1b232d; --card-bg:#23395d; --navbar-bg:#161b22; color:#e6edf3; }
        .navbar { background:var(--navbar-bg)!important; box-shadow:0 2px 12px rgba(33,57,93,0.08); }
        .navbar-brand,.navbar-nav .nav-link { color:#fff!important; font-size:1.08em; }
        .navbar-brand { font-weight:700; letter-spacing:1px; }
        .theme-toggle-btn { background:none; border:none; color:#fff; font-size:1.45em; margin-left:12px; cursor:pointer; }
        .dashboard-header { text-align:center; margin-top:36px; margin-bottom:18px; }
        .dashboard-header img { width:70px; height:70px; object-fit:contain; margin-bottom:6px; }
        .dashboard-header h1 { font-size:1.3rem; color:var(--brand-dark); font-weight:700; margin-bottom:0; letter-spacing:0.02em; }
        .main-card { background:var(--card-bg); border-radius:1rem; box-shadow:0 4px 18px rgba(33,57,93,0.09),0 1.5px 3px rgba(33,57,93,0.07); margin:0 auto; margin-top:18px; margin-bottom:32px; padding:2.2rem 2.5rem 2.3rem; max-width:1050px; }
        .section-title { font-size:1.23rem; font-weight:700; color:#23395d; margin-bottom:1.1rem; letter-spacing:0.04em; }
        .table td,.table th{ vertical-align:middle!important; }
        #deletePaymentModal .modal-dialog{ max-width:480px; }
        /* View Wave 5: detail view alignment */
        :root {
            --vw-page-bg:#eef3f9;
            --vw-card-bg:#ffffff;
            --vw-card-border:#d9e3ef;
            --vw-brand-dark:#23395d;
            --vw-brand-mid:#517fa4;
            --vw-brand-soft:#edf4fb;
            --vw-text-soft:#5f7186;
        }
        body {
            background:
                radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 30%),
                linear-gradient(180deg, #f8fbff 0%, var(--vw-page-bg) 100%);
            color: var(--vw-brand-dark);
        }
        .dashboard-header { margin-top:32px; margin-bottom:18px; }
        .dashboard-header img {
            width:72px; height:72px; border-radius:18px; background:#fff; padding:6px;
            box-shadow:0 10px 25px rgba(35,57,93,0.12);
        }
        .dashboard-header h1 { font-weight:800; }
        .main-card {
            background:var(--vw-card-bg);
            border:1px solid var(--vw-card-border);
            border-radius:20px;
            box-shadow:0 14px 32px rgba(35,57,93,0.07);
            max-width:1400px;
            overflow:hidden;
            position:relative;
        }
        /* Keep critical columns readable */
        .history-table-wrap table th,
        .history-table-wrap table td {
            vertical-align: middle;
            padding: .9rem .85rem;
        }
        .history-table-wrap table th {
            white-space: nowrap;
        }
        .history-table-wrap table th:nth-child(1),
        .history-table-wrap table td:nth-child(1) { min-width: 110px; }
        .history-table-wrap table th:nth-child(2),
        .history-table-wrap table td:nth-child(2) { min-width: 105px; }
        .history-table-wrap table th:nth-child(3),
        .history-table-wrap table td:nth-child(3) { min-width: 145px; }
        .history-table-wrap table th:nth-child(4),
        .history-table-wrap table td:nth-child(4) { min-width: 200px; }
        .history-table-wrap table th:nth-child(5),
        .history-table-wrap table td:nth-child(5) { min-width: 140px; }
        .history-table-wrap table th:nth-child(6),
        .history-table-wrap table td:nth-child(6) { min-width: 135px; }
        .history-table-wrap table th:nth-child(7),
        .history-table-wrap table td:nth-child(7) { min-width: 125px; }
        .history-table-wrap table th:nth-child(8),
        .history-table-wrap table td:nth-child(8) { min-width: 230px; }
        .main-card::before {
            content:"";
            position:absolute;
            inset:0 0 auto 0;
            height:5px;
            background:linear-gradient(90deg, var(--vw-brand-dark), var(--vw-brand-mid), #7da6c7);
        }
        .section-title { font-weight:800; }
        .main-card .card {
            border:1px solid var(--vw-card-border);
            border-radius:18px;
            overflow:hidden;
            box-shadow:0 10px 24px rgba(35,57,93,0.05);
        }
        .main-card .card-header {
            background:linear-gradient(135deg, var(--vw-brand-dark), var(--vw-brand-mid)) !important;
            color:#fff !important;
            border:0;
            font-weight:700;
        }
        .main-card .table thead th {
            background:var(--vw-brand-soft);
            color:var(--vw-brand-dark);
            border-bottom:1px solid var(--vw-card-border);
            font-weight:700;
        }
        .main-card .btn {
            border-radius:10px;
            font-weight:700;
        }
        .history-summary-card {
            background:#f8fbff;
            border:1px solid var(--vw-card-border);
            border-radius:16px;
            padding:0.95rem 1rem;
            height:100%;
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.75);
        }
        .history-summary-card .label {
            text-transform:uppercase;
            letter-spacing:.08em;
            font-size:.72rem;
            color:var(--vw-text-soft);
            font-weight:800;
        }
        .history-summary-card .value {
            font-size:1.35rem;
            font-weight:800;
            color:var(--vw-brand-dark);
            margin-top:.2rem;
        }
        .history-action-toolbar {
            display:flex;
            flex-wrap:wrap;
            gap:.75rem;
            align-items:center;
            margin-bottom:1rem;
            padding:.9rem 1rem;
            border:1px solid var(--vw-card-border);
            border-radius:16px;
            background:linear-gradient(180deg, #f8fbff 0%, #edf4fb 100%);
        }
        .history-action-toolbar .btn {
            border-radius:999px;
            min-height:42px;
            padding-inline:1rem;
        }
        .history-toolbar-note {
            flex:1 1 220px;
            color:var(--vw-text-soft);
            font-size:.92rem;
            font-weight:600;
        }
        .section-kicker {
            text-transform: uppercase;
            letter-spacing: .08em;
            font-size: .76rem;
            color: var(--vw-text-soft);
            font-weight: 800;
            margin-bottom: .35rem;
        }
        .section-note {
            color: var(--vw-text-soft);
            font-size: .92rem;
            margin-bottom: 1rem;
        }
        .history-export-btn {
            background:#e9f7ef;
            border-color:#b7dfc5;
            color:#166534;
        }
        .history-export-btn:hover {
            background:#dcf2e5;
            border-color:#9ed0b0;
            color:#14532d;
        }
        .history-link-btn {
            background:#edf4fb;
            border-color:#cfdeee;
            color:var(--vw-brand-dark);
        }
        .history-link-btn:hover {
            background:#e3eef9;
            border-color:#bdd0e6;
            color:#1c3555;
        }
        .history-back-btn {
            background:#fff;
            border-color:#d7e1ed;
            color:var(--vw-brand-dark);
        }
        .student-detail-card {
            background:linear-gradient(180deg, #ffffff 0%, #f9fbfe 100%);
        }
        .student-detail-card h5 {
            font-weight:800;
            color:var(--vw-brand-dark);
            margin-bottom:.9rem;
        }
        .student-detail-card p {
            line-height:1.7;
            margin-bottom:0;
            color:#32465f;
        }
        .student-overview-grid {
            display:grid;
            grid-template-columns:repeat(auto-fit, minmax(180px, 1fr));
            gap:.85rem;
            margin-top:.85rem;
        }
        .student-overview-item {
            background:#f8fbff;
            border:1px solid var(--vw-card-border);
            border-radius:14px;
            padding:.85rem .95rem;
        }
        .student-overview-item .label {
            text-transform:uppercase;
            letter-spacing:.06em;
            font-size:.72rem;
            color:var(--vw-text-soft);
            font-weight:800;
        }
        .student-overview-item .value {
            font-weight:700;
            color:var(--vw-brand-dark);
            margin-top:.25rem;
            line-height:1.45;
        }
        .linked-status-panel {
            background:#f8fbff !important;
            border:1px solid var(--vw-card-border) !important;
            border-radius:14px;
        }
        .anchor-related-list {
            margin-top:.75rem;
            padding-top:.75rem;
            border-top:1px dashed #d7e1ed;
            color:#607388;
            font-size:.9rem;
        }
        .anchor-related-list strong {
            color:var(--vw-brand-dark);
        }
        .history-search-shell {
            padding:1rem 1.05rem;
            border:1px solid #dbe6f2;
            border-radius:18px;
            background:linear-gradient(180deg, #ffffff 0%, #f7fbff 100%);
            box-shadow:inset 0 1px 0 rgba(255,255,255,.85);
        }
        .history-search-shell .form-control {
            min-height:46px;
            border-color:#d7e1ed;
            border-radius:14px;
            padding-inline:1rem;
            box-shadow:none;
        }
        .history-search-shell .form-control:focus {
            border-color:#9bbddd;
            box-shadow:0 0 0 .18rem rgba(81,127,164,.12);
        }
        .history-table-wrap {
            border:1px solid #dbe6f2;
            border-radius:22px;
            overflow:hidden;
            background:#fff;
            box-shadow:0 14px 28px rgba(35,57,93,.05);
        }
        .history-table-wrap .table {
            margin-bottom:0;
            width:100%;
            min-width:1280px;
            table-layout:auto;
        }
        .history-table-wrap .table thead th {
            padding-top:1rem;
            padding-bottom:1rem;
            background:linear-gradient(180deg, #f6faff 0%, #eef4fb 100%);
            font-size:.86rem;
            letter-spacing:.01em;
        }
        .history-table-wrap .table tbody td {
            border-color:#e5edf5;
            padding-top:1rem;
            padding-bottom:1rem;
        }
        .history-table-wrap .table tbody tr:nth-child(even) td {
            background:#fbfdff;
        }
        .history-table-wrap .table tbody tr:hover td {
            background:#f4f9ff;
        }
        .old-payment-history-row td:first-child {
            font-weight:700;
            color:var(--vw-brand-dark);
        }
        .receipt-integrity-card {
            background:linear-gradient(180deg, #fffdf8 0%, #f9fbfe 100%);
        }
        .receipt-integrity-card .card-header {
            background: linear-gradient(180deg, #fdf7e7 0%, #f7f0db 100%) !important;
            color: #5f4916 !important;
            cursor: pointer;
        }
        .fee-breakdown-card .card-header {
            background: linear-gradient(135deg, var(--vw-brand-dark), var(--vw-brand-mid)) !important;
            color: #fff !important;
            cursor: pointer;
            border: 0;
        }
        .fee-breakdown-toggle {
            width:100%;
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:1rem;
            background:transparent;
            border:0;
            color:inherit;
            padding:0;
            text-align:left;
            font-weight:700;
        }
        .fee-breakdown-toggle:focus {
            outline:none;
            box-shadow:none;
        }
        .fee-breakdown-summary {
            display:flex;
            flex-wrap:wrap;
            align-items:center;
            gap:.5rem;
            color:rgba(255,255,255,.88);
            font-size:.84rem;
        }
        .fee-breakdown-pill {
            display:inline-flex;
            align-items:center;
            gap:.35rem;
            padding:.3rem .7rem;
            border-radius:999px;
            border:1px solid rgba(255,255,255,.16);
            background:rgba(255,255,255,.14);
            font-weight:700;
        }
        .fee-breakdown-caret {
            transition:transform .2s ease;
        }
        .fee-breakdown-toggle[aria-expanded="true"] .fee-breakdown-caret {
            transform:rotate(180deg);
        }
        .receipt-integrity-toggle {
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            background: transparent;
            border: 0;
            color: inherit;
            padding: 0;
            font-weight: 700;
            text-align: left;
        }
        .receipt-integrity-toggle:focus {
            outline: none;
            box-shadow: none;
        }
        .receipt-integrity-summary {
            display: flex;
            flex-wrap: wrap;
            gap: .5rem;
            align-items: center;
            font-size: .84rem;
            color: #7a6330;
        }
        .receipt-mini-pill {
            display: inline-flex;
            align-items: center;
            gap: .3rem;
            padding: .3rem .65rem;
            border-radius: 999px;
            background: rgba(255,255,255,.72);
            border: 1px solid #eadfbf;
            font-weight: 700;
        }
        .receipt-integrity-caret {
            transition: transform .2s ease;
        }
        .receipt-integrity-toggle[aria-expanded="true"] .receipt-integrity-caret {
            transform: rotate(180deg);
        }
        .receipt-integrity-grid {
            display:grid;
            grid-template-columns:repeat(auto-fit, minmax(180px, 1fr));
            gap:.85rem;
        }
        .receipt-integrity-card .history-summary-card .value {
            font-size:1.2rem;
        }
        .receipt-chip,
        .method-chip,
        .prep-chip {
            display:inline-flex;
            align-items:center;
            gap:.35rem;
            border-radius:999px;
            padding:.34rem .78rem;
            font-size:.79rem;
            font-weight:700;
            border:1px solid #d7e1ed;
            background:#f8fbff;
            color:var(--vw-brand-dark);
        }
        .receipt-chip {
            background:#f6f9fd;
            border-color:#d2deeb;
        }
        .method-chip {
            background:#edf7ff;
            border-color:#cce3f7;
            color:#14507a;
        }
        .prep-chip {
            background:#f7fafc;
            border-color:#d8e2ec;
        }
        .amount-chip {
            display:inline-flex;
            align-items:center;
            border-radius:999px;
            padding:.42rem .9rem;
            background:linear-gradient(180deg, #f1f7fe 0%, #e7f1fb 100%);
            color:#0f4f8a;
            font-weight:800;
            font-size:.95rem;
            border:1px solid #c9dff3;
            box-shadow:inset 0 1px 0 rgba(255,255,255,.75);
        }
        .receipt-meta {
            display:flex;
            flex-wrap:wrap;
            gap:.35rem;
        }
        .prep-chip.prep-chip-legacy {
            background:#fff7ed;
            border-color:#fed7aa;
            color:#9a3412;
        }
        .hero-stat-value.hero-stat-legacy {
            color:#fde68a;
        }
        .coverage-stack {
            display:grid;
            gap:.55rem;
        }
        .coverage-text {
            color:var(--vw-brand-dark);
            font-size:.92rem;
            font-weight:700;
            line-height:1.35;
        }
        .coverage-actions {
            display:flex;
            flex-wrap:wrap;
            gap:.5rem;
        }
        .coverage-actions .btn {
            min-height:34px;
        }
        .table-summary-text {
            color:#4f6278;
            font-size:.89rem;
            line-height:1.4;
            word-break:break-word;
            display:-webkit-box;
            -webkit-line-clamp:3;
            -webkit-box-orient:vertical;
            overflow:hidden;
        }
        .receipt-action.btn {
            border-radius:999px;
            padding-inline:.9rem;
            font-weight:700;
            border-color:#bfd6ee;
            color:var(--vw-brand-dark);
            background:#f8fbff;
            box-shadow:inset 0 1px 0 rgba(255,255,255,.78);
        }
        .receipt-action.btn:hover {
            background:#eef5fd;
            border-color:#a8c8e6;
            color:var(--vw-brand-dark);
        }
        .history-card-header {
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:1rem;
        }
        .drilldown-modal .modal-dialog {
            max-width:min(1140px, 92vw);
        }
        .drilldown-modal .modal-content {
            border-radius:28px;
            overflow:hidden;
            background:
                radial-gradient(circle at top right, rgba(81,127,164,0.12), transparent 24%),
                linear-gradient(180deg, #fbfdff 0%, #f4f8fc 100%);
        }
        .drilldown-modal .modal-header {
            padding:0;
            border-bottom:0;
            background:transparent;
        }
        .drilldown-modal .modal-body {
            padding:1.5rem;
        }
        .drilldown-modal .modal-footer {
            border-top:1px solid rgba(81,127,164,0.12);
            padding:1rem 1.5rem 1.35rem;
            background:rgba(255,255,255,0.72);
        }
        .drilldown-hero {
            position:relative;
            padding:1.4rem 1.45rem 1.2rem;
            background:linear-gradient(135deg, rgba(35,57,93,0.96), rgba(81,127,164,0.92));
            color:#fff;
        }
        .drilldown-hero-top {
            display:flex;
            align-items:flex-start;
            justify-content:space-between;
            gap:1rem;
            margin-bottom:1rem;
        }
        .drilldown-kicker {
            display:inline-flex;
            align-items:center;
            gap:.4rem;
            padding:.38rem .78rem;
            border-radius:999px;
            background:rgba(255,255,255,0.14);
            color:rgba(255,255,255,0.92);
            font-size:.76rem;
            font-weight:700;
            text-transform:uppercase;
            letter-spacing:.08em;
        }
        .drilldown-title {
            margin:.8rem 0 .28rem;
            font-size:1.45rem;
            font-weight:800;
        }
        .drilldown-subtitle {
            margin:0;
            color:rgba(255,255,255,0.82);
            line-height:1.55;
        }
        .drilldown-close {
            flex-shrink:0;
            border:1px solid rgba(255,255,255,0.18);
            border-radius:999px;
            background:rgba(255,255,255,0.1);
            color:#fff;
            width:42px;
            height:42px;
            display:inline-flex;
            align-items:center;
            justify-content:center;
        }
        .drilldown-hero-grid {
            display:grid;
            grid-template-columns:repeat(auto-fit, minmax(160px, 1fr));
            gap:12px;
        }
        .hero-stat {
            padding:.9rem 1rem;
            border-radius:18px;
            background:rgba(255,255,255,0.12);
            border:1px solid rgba(255,255,255,0.12);
        }
        .hero-stat-label {
            display:block;
            font-size:.74rem;
            font-weight:700;
            letter-spacing:.08em;
            text-transform:uppercase;
            color:rgba(255,255,255,0.7);
            margin-bottom:.4rem;
        }
        .hero-stat-value {
            font-size:1rem;
            font-weight:800;
            color:#fff;
            word-break:break-word;
        }
        .drilldown-meta-strip {
            display:flex;
            flex-wrap:wrap;
            gap:10px;
            margin-bottom:1.1rem;
        }
        .meta-pill {
            display:inline-flex;
            align-items:center;
            gap:.5rem;
            padding:.72rem .95rem;
            border-radius:999px;
            background:rgba(255,255,255,0.92);
            border:1px solid rgba(81,127,164,0.14);
            color:var(--vw-brand-dark);
            font-size:.88rem;
            font-weight:700;
        }
        .detail-card {
            border:1px solid rgba(81,127,164,0.14);
            border-radius:18px;
            background:linear-gradient(180deg, rgba(255,255,255,0.98), rgba(244,249,255,0.95));
            padding:14px 15px;
            box-shadow:0 10px 24px rgba(35,57,93,0.05);
        }
        .drilldown-section-heading {
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:.8rem;
            margin-bottom:.85rem;
        }
        .drilldown-section-heading h6 {
            margin:0;
            font-size:.95rem;
            font-weight:800;
            color:var(--vw-brand-dark);
        }
        .drilldown-section-heading span,
        .detail-card-label {
            font-size:.82rem;
            color:var(--vw-text-soft);
        }
        .detail-card-label {
            display:block;
            font-weight:700;
            letter-spacing:.08em;
            text-transform:uppercase;
            margin-bottom:6px;
        }
        .detail-card-value {
            color:var(--vw-brand-dark);
            font-weight:800;
            font-size:1rem;
            word-break:break-word;
        }
        .modal-detail-grid {
            display:grid;
            grid-template-columns:repeat(auto-fit, minmax(250px, 1fr));
            gap:16px;
        }
        .method-breakdown-list {
            display:grid;
            gap:12px;
        }
        .method-breakdown-item {
            border:1px solid rgba(81,127,164,0.14);
            border-radius:18px;
            padding:14px 15px;
            background:linear-gradient(180deg, #ffffff 0%, #f9fbfe 100%);
        }
        .method-breakdown-top {
            display:flex;
            align-items:flex-start;
            justify-content:space-between;
            gap:.8rem;
            flex-wrap:wrap;
        }
        .method-name-chip {
            display:inline-flex;
            align-items:center;
            gap:.45rem;
            border-radius:999px;
            padding:.42rem .8rem;
            background:#edf5fe;
            color:#0d5fb8;
            font-weight:800;
            font-size:.84rem;
        }
        .method-amount {
            color:var(--vw-brand-dark);
            font-size:1rem;
            font-weight:800;
        }
        .method-breakdown-meta {
            display:grid;
            gap:.45rem;
            margin-top:.8rem;
        }
        .method-breakdown-meta-line,
        .modal-note-block {
            color:var(--vw-text-soft);
            font-size:.88rem;
            line-height:1.45;
            word-break:break-word;
        }
        .modal-note-block {
            border:1px solid rgba(81,127,164,0.14);
            border-radius:18px;
            background:linear-gradient(180deg, #ffffff 0%, #f9fbfe 100%);
            padding:14px 15px;
            color:var(--vw-brand-dark);
            white-space:pre-wrap;
        }
        .fee-table-shell {
            border:1px solid rgba(81,127,164,0.12);
            border-radius:18px;
            overflow:hidden;
        }
        .fee-table-shell .table {
            margin-bottom:0;
        }
        .fee-table-shell thead th {
            background:#eef5fd;
            color:var(--vw-brand-dark);
            border-bottom:1px solid rgba(81,127,164,0.12);
        }
        .fee-total-row td {
            font-weight:800;
            color:var(--vw-brand-dark);
            background:#f8fbff;
        }
        .history-card-header {
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:1rem;
        }
        .history-card-title {
            display:inline-flex;
            align-items:center;
            gap:.5rem;
            font-weight:800;
        }
        .history-card-meta {
            display:flex;
            flex-wrap:wrap;
            gap:.45rem;
        }
        .history-card-pill {
            display:inline-flex;
            align-items:center;
            gap:.35rem;
            padding:.28rem .68rem;
            border-radius:999px;
            background:rgba(255,255,255,.18);
            border:1px solid rgba(255,255,255,.18);
            font-size:.8rem;
            font-weight:700;
            color:#fff;
        }
        @media (max-width: 1199.98px) {
            .drilldown-modal .modal-dialog {
                max-width:min(980px, 94vw);
            }
            .modal-detail-grid {
                grid-template-columns:repeat(auto-fit, minmax(220px, 1fr));
            }
        }
        @media (max-width: 991.98px) {
            .history-table-wrap .table {
                min-width:1380px;
            }
            .drilldown-hero-grid {
                grid-template-columns:repeat(auto-fit, minmax(220px, 1fr));
            }
            .modal-detail-grid {
                grid-template-columns:1fr;
            }
        }
        @media (max-width: 767.98px) {
            .history-table-wrap .table {
                min-width:1220px;
            }
            .drilldown-modal .modal-dialog {
                max-width:calc(100vw - 1rem);
                margin:.5rem auto;
            }
            .drilldown-modal .modal-body,
            .drilldown-modal .modal-footer {
                padding-inline:1rem;
            }
            .drilldown-hero {
                padding:1.15rem 1rem 1rem;
            }
            .drilldown-title {
                font-size:1.2rem;
            }
            .drilldown-hero-grid {
                grid-template-columns:1fr;
            }
        }
    </style>
</head>
<body>
<?php render_admin_nav('old_accounts', true); ?>
<div class="container-fluid main-card px-3">
    <div class="section-title">
        <div class="text-uppercase small fw-bold mb-2" style="letter-spacing:.08em; color: var(--vw-text-soft);">Historical Payment Detail</div>
        <i class="fas fa-file-invoice-dollar"></i>
        Old Student Payment History<?= $school_year ? " - " . h($school_year) : "" ?>
    </div>
    <?php if (isset($_GET['linked'])): ?>
        <div class="alert alert-success"><i class="fas fa-link"></i> Old account linked to the selected current student successfully.</div>
    <?php elseif (isset($_GET['relinked'])): ?>
        <div class="alert alert-success"><i class="fas fa-link"></i> Old account link updated successfully.</div>
    <?php elseif (isset($_GET['unlinked'])): ?>
        <div class="alert alert-warning"><i class="fas fa-link-slash"></i> Old account link removed successfully.</div>
    <?php elseif (isset($_GET['anchor_head'])): ?>
        <div class="alert alert-success"><i class="fas fa-crown"></i> This old account is now the head anchor for grouped old-year records.</div>
    <?php elseif (isset($_GET['anchor_linked'])): ?>
        <div class="alert alert-success"><i class="fas fa-diagram-project"></i> Old account linked to the selected head anchor successfully.</div>
    <?php elseif (isset($_GET['anchor_removed'])): ?>
        <div class="alert alert-warning"><i class="fas fa-link-slash"></i> Old account anchor link removed successfully.</div>
    <?php elseif (isset($_GET['anchor_unset'])): ?>
        <div class="alert alert-warning"><i class="fas fa-unlink"></i> Head anchor removed successfully.</div>
    <?php endif; ?>
    <div class="history-action-toolbar">
        <a href="/school-admin-dashboard/modules/settings/export/export-old-payment-history.php?id=<?= (int) $student_id ?>" class="btn history-export-btn">
            <i class="fas fa-file-excel"></i> Export Payment History
        </a>
        <?php if ($linked_student_id > 0 || $old_anchor_id > 0): ?>
            <a href="/school-admin-dashboard/modules/old accounts/export-old-soa.php?<?= $linked_student_id > 0 ? 'student_id=' . (int) $linked_student_id : 'old_anchor_id=' . (int) $old_anchor_id ?>" class="btn history-export-btn">
                <i class="fas fa-file-invoice-dollar"></i> Export Grouped Old SOA
            </a>
        <?php endif; ?>
        <?php if ($can_manage_old_account_link): ?>
            <a href="/school-admin-dashboard/modules/old accounts/student-old-link-student.php?id=<?= (int) $student_id ?>" class="btn history-link-btn">
                <i class="fas fa-link"></i> <?= !empty($student['linked_student_id']) ? 'Change Link' : 'Link Current Student' ?>
            </a>
            <?php if ($linked_student_id <= 0): ?>
                <a href="/school-admin-dashboard/modules/old accounts/student-old-anchor-head.php?id=<?= (int) $student_id ?>" class="btn history-link-btn">
                    <i class="fas fa-diagram-project"></i> <?= $old_anchor_id > 0 ? 'Manage Anchor Head' : 'Set Anchor Head' ?>
                </a>
            <?php endif; ?>
        <?php endif; ?>
        <a href="/school-admin-dashboard/modules/old accounts/student-old-account-list.php" class="btn history-back-btn">
            <i class="fas fa-arrow-left"></i> Back to Old Accounts
        </a>
        <div class="history-toolbar-note">Review this student's historical balances and receipts, then export the same page context when you need an offline copy.</div>
    </div>

    <div class="card mb-4 student-detail-card">
        <div class="card-body">
            <div class="section-kicker">Student Overview</div>
            <h5><?= h($student['lastname']) ?>, <?= h($student['firstname']) ?> <?= h($student['middlename']) ?></h5>
            <div class="section-note">Historical student context stays at the top so we can verify identity, follow-up state, and linked records before reviewing fees and receipts.</div>
            <?php $linkedStudentExists = !empty($student['linked_lastname']) || !empty($student['linked_firstname']); ?>
            <?php $effectiveAnchorClass = $linked_student_id > 0 ? 'bg-success' : old_account_anchor_status_badge_class($student_id, $old_anchor_id); ?>
            <div class="student-overview-grid">
                <div class="student-overview-item">
                    <div class="label">Old Status</div>
                    <div class="value"><span class="badge bg-secondary"><?= h(ucfirst((string) $student['status'])) ?></span></div>
                </div>
                <div class="student-overview-item">
                    <div class="label">Link Status</div>
                    <div class="value"><span class="badge <?= h(old_account_link_status_badge_class($student['status'] ?? '', (int) ($student['linked_student_id'] ?? 0), $linkedStudentExists)) ?>"><?= h(old_account_link_status_label($student['status'] ?? '', (int) ($student['linked_student_id'] ?? 0), $linkedStudentExists)) ?></span></div>
                </div>
                <div class="student-overview-item">
                    <div class="label">Anchor Status</div>
                    <div class="value"><span class="badge <?= h($effectiveAnchorClass) ?>"><?= h(old_account_effective_anchor_label($linked_student_id > 0, $student_id, $old_anchor_id)) ?></span></div>
                </div>
                <div class="student-overview-item">
                    <div class="label">Follow-up</div>
                    <div class="value"><span class="badge <?= h(old_account_followup_badge_class($student['follow_up_status'] ?? 'record_only')) ?>"><?= h(old_account_followup_label($student['follow_up_status'] ?? 'record_only')) ?></span></div>
                </div>
                <div class="student-overview-item">
                    <div class="label">School Year</div>
                    <div class="value"><?= h($school_year) ?></div>
                </div>
                <div class="student-overview-item">
                    <div class="label">Contact</div>
                    <div class="value"><?= h($student['contact'] ?? '-') ?></div>
                </div>
                <div class="student-overview-item">
                    <div class="label">Notes</div>
                    <div class="value"><?= h(trim((string) ($student['notes'] ?? '')) !== '' ? $student['notes'] : '-') ?></div>
                </div>
                <div class="student-overview-item">
                    <div class="label">Follow-up Note</div>
                    <div class="value"><?= h(trim((string) ($student['follow_up_note'] ?? '')) !== '' ? $student['follow_up_note'] : '-') ?></div>
                </div>
            </div>
            <div class="alert alert-light border mb-0 linked-status-panel">
                <i class="fas fa-link me-1"></i>
                <?php if ($linkedStudentExists): ?>
                    Linked Current Student:
                    <strong><?= h(trim((string) (($student['linked_lastname'] ?? '') . ', ' . ($student['linked_firstname'] ?? '') . ' ' . ($student['linked_middlename'] ?? '')))) ?></strong>
                    | Grade: <?= h($student['linked_grade'] ?? '-') ?>
                    | Section: <?= h($student['linked_section'] ?? '-') ?>
                    | LRN: <?= h($student['linked_lrn'] ?? '-') ?>
                    | School Year: <?= h($student['linked_school_year_label'] ?? '-') ?>
                <?php else: ?>
                    <?= h(old_account_link_status_note($student['status'] ?? '', (int) ($student['linked_student_id'] ?? 0), $linkedStudentExists)) ?>
                <?php endif; ?>
                <div class="anchor-related-list">
                    <i class="fas fa-diagram-project me-1"></i>
                    <?= h(old_account_effective_anchor_note(
                        $linked_student_id > 0,
                        $student_id,
                        $old_anchor_id,
                        trim((string) (($student['anchor_lastname'] ?? '') . ', ' . ($student['anchor_firstname'] ?? '') . ' ' . ($student['anchor_middlename'] ?? ''))),
                        (string) ($student['anchor_school_year'] ?? '')
                    )) ?>
                    <?php if ($old_anchor_id > 0 && $anchor_related_records): ?>
                        <div class="mt-2">
                            <strong><?= number_format(count($anchor_related_records)) ?></strong> grouped old record(s):
                            <div class="mt-2 d-flex flex-wrap gap-2">
                                <?php foreach ($anchor_related_records as $anchorRow): ?>
                                    <a href="/school-admin-dashboard/modules/old accounts/student-old-payment-history.php?id=<?= (int) ($anchorRow['id'] ?? 0) ?>" class="btn btn-sm btn-outline-secondary">
                                        <?= h(trim((string) ($anchorRow['school_year'] ?? 'Unknown'))) ?> (#<?= (int) ($anchorRow['id'] ?? 0) ?>)
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="mb-4">
        <div class="section-kicker">Key Summary</div>
        <div class="row g-3">
            <div class="col-12 col-md-6 col-xl-3"><div class="history-summary-card"><div class="label">Recorded Payments</div><div class="value"><?= number_format((int) $total_payments) ?></div></div></div>
            <div class="col-12 col-md-6 col-xl-3"><div class="history-summary-card"><div class="label">Visible Total Paid</div><div class="value">P<?= number_format($total_paid_amount, 2) ?></div></div></div>
            <div class="col-12 col-md-6 col-xl-3"><div class="history-summary-card"><div class="label">Outstanding Fee Types</div><div class="value"><?= number_format($outstanding_fee_count) ?></div></div></div>
            <div class="col-12 col-md-6 col-xl-3"><div class="history-summary-card"><div class="label">Receipt Mismatches</div><div class="value"><?= number_format($receipt_registry_missing_count) ?></div></div></div>
        </div>
    </div>

    <div class="card mb-4 fee-breakdown-card">
        <div class="card-header">
            <button class="fee-breakdown-toggle" type="button" data-bs-toggle="collapse" data-bs-target="#historicalFeeBreakdownBody" aria-expanded="true" aria-controls="historicalFeeBreakdownBody">
                <span><i class="fas fa-receipt"></i> Historical Fee Breakdown</span>
                <span class="fee-breakdown-summary">
                    <span class="fee-breakdown-pill"><?= number_format(count($fee_rows)) ?> fee type<?= count($fee_rows) === 1 ? '' : 's' ?></span>
                    <span class="fee-breakdown-pill"><?= number_format($outstanding_fee_count) ?> outstanding</span>
                    <i class="fas fa-chevron-down fee-breakdown-caret"></i>
                </span>
            </button>
        </div>
        <div class="collapse show" id="historicalFeeBreakdownBody">
        <div class="card-body">
            <div class="d-flex flex-wrap gap-2 justify-content-end mb-3">
                <?php if ($can_edit_fee_balance): ?>
                    <a href="/school-admin-dashboard/modules/old accounts/booklet/student-old-balance-edit.php?id=<?= $student_id ?>"
                       class="btn btn-outline-warning btn-sm">
                        <i class="fas fa-edit"></i> Fee Type Balance Edit
                    </a>
                <?php endif; ?>
                <?php if ($can_add_payment): ?>
                    <a href="/school-admin-dashboard/modules/old accounts/booklet/student-old-add-payment.php?id=<?= $student_id ?>"
                       class="btn btn-success btn-sm ms-2">
                        <i class="fas fa-plus"></i> Add Payment
                    </a>
                <?php endif; ?>
                <?php if ($can_edit_fee_balance): ?>
                    <a href="/school-admin-dashboard/modules/old accounts/booklet/student-old-add-fee.php?id=<?= $student_id ?>"
                       class="btn btn-primary btn-sm ms-2">
                        <i class="fas fa-plus"></i> Add Fee
                    </a>
                <?php endif; ?>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead>
                        <tr>
                            <th>Fee Type</th>
                            <th>Balance</th>
                            <th>Status</th>
                            <?php if ($can_delete_fee_row): ?><th>Action</th><?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($fee_rows as $type => $fee):
                        [$status, $badge_class] = get_fee_status((float)$fee['balance']);
                    ?>
                        <tr>
                            <td><?= h($type) ?></td>
                            <td>PHP <?= number_format((float)$fee['balance'], 2) ?></td>
                            <td><span class="badge <?= h($badge_class) ?>"><?= h($status) ?></span></td>
                            <?php if ($can_delete_fee_row): ?>
                                <td>
                                    <form method="post" class="d-inline" onsubmit="return confirm('Delete this fee row?');">
                                        <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
                                        <input type="hidden" name="delete_fee" value="<?= (int)$fee['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-danger">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header bg-primary text-light">
            <div class="history-card-header">
                <span class="history-card-title"><i class="fas fa-history"></i> Payment History</span>
                <div class="history-card-meta">
                    <span class="history-card-pill"><i class="fas fa-layer-group"></i> <?= number_format($total_grouped_receipts) ?> grouped receipt<?= $total_grouped_receipts === 1 ? '' : 's' ?></span>
                    <span class="history-card-pill"><i class="fas fa-file-circle-check"></i> <?= number_format($receipt_registry_active_count) ?> linked</span>
                </div>
            </div>
        </div>
        <div class="card-body">
            <?php if ($success): ?><div class="alert alert-success"><?= h($success) ?></div><?php endif; ?>
            <?php if ($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>
            <div class="history-search-shell mb-3">
            <div class="row g-2 align-items-center">
                <div class="col-12 col-md-7">
                    <input type="text" id="oldPaymentHistorySearch" class="form-control" placeholder="Search by receipt no, fee type, amount, or booklet">
                </div>
                <div class="col-12 col-md-5 text-muted small d-flex align-items-center">
                    Filter the visible grouped receipts on this page.
                </div>
            </div>
            </div>

            <div class="table-responsive history-table-wrap">
                <table class="table table-striped mb-0" id="oldPaymentHistoryTable">
                    <thead>
                        <tr>
                            <th>Date Paid</th>
                            <th>Time Paid</th>
                            <th>Total Paid</th>
                            <th>Coverage</th>
                            <th>Receipt</th>
                            <th>Payment Method</th>
                            <th>Prepared By</th>
                            <th>Receipt State</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $receiptModals = []; ?>
                        <?php if ($groupedPayments): foreach ($groupedPayments as $payment):
                            $dt = !empty($payment['paid_at_full']) ? new DateTime($payment['paid_at_full']) : null;
                            $date = $dt ? $dt->format('m-d-Y') : '';
                            $time = $dt ? $dt->format('h:i A') : '';
                            $itemsCount = count($payment['items']);
                            $modalId = $payment['modal_id'];
                        ?>
                            <tr class="old-payment-history-row">
                                <td><?= h($date) ?></td>
                                <td><?= h($time) ?></td>
                                <td>
                                    <span class="amount-chip">&#8369;<?= number_format((float) $payment['total'], 2) ?></span>
                                </td>
                                <td>
                                    <div class="coverage-stack">
                                        <span class="coverage-text"><?= h($itemsCount > 1 ? ($itemsCount . ' items') : (($payment['items'][0]['fee_type'] ?? ''))) ?></span>
                                        <div class="coverage-actions">
                                            <button type="button" class="btn btn-sm btn-outline-primary receipt-action" data-bs-toggle="modal" data-bs-target="#<?= h($modalId) ?>">
                                                <i class="fas fa-receipt"></i> View details
                                            </button>
                                            <?php if ($can_view_receipt && !empty($payment['receipt_no']) && !empty($payment['booklet_no'])): ?>
                                                <a href="/school-admin-dashboard/modules/accounts/accounts table/account-print.php?receipt_no=<?= (int) $payment['receipt_no'] ?>&booklet_no=<?= (int) $payment['booklet_no'] ?>" class="btn btn-sm btn-outline-secondary receipt-action" target="_blank" rel="noopener">
                                                    <i class="fas fa-print"></i> Receipt
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php if (!empty($payment['booklet_no']) && !empty($payment['receipt_no'])): ?>
                                        <div class="receipt-meta">
                                            <span class="receipt-chip"><?= h($payment['booklet_label']) ?></span>
                                            <span class="receipt-chip">OR <?= h((string) $payment['receipt_no']) ?></span>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-muted">No OR</span>
                                    <?php endif; ?>
                                </td>
                                <td><span class="method-chip"><?= h((string) ($payment['method_label'] !== '' ? $payment['method_label'] : 'Not Set')) ?></span></td>
                                <td>
                                    <?php if ($payment['prepared_by'] !== ''): ?>
                                        <span class="prep-chip"><?= h((string) $payment['prepared_by']) ?></span>
                                    <?php else: ?>
                                        <span class="prep-chip prep-chip-legacy" title="<?= h($legacyPreparedByDetail) ?>"><?= h($legacyPreparedByLabel) ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge <?= h($payment['receipt_state']['class']) ?>"><?= h($payment['receipt_state']['label']) ?></span>
                                    <div class="small text-muted mt-1"><?= h($payment['receipt_state']['note']) ?></div>
                                </td>
                            </tr>
                            <?php ob_start(); ?>
                            <div class="modal fade drilldown-modal" id="<?= h($modalId) ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
                                    <div class="modal-content border-0 shadow-lg">
                                        <div class="modal-header">
                                            <div class="drilldown-hero w-100">
                                                <div class="drilldown-hero-top">
                                                    <div>
                                                        <span class="drilldown-kicker"><i class="fas fa-receipt"></i> Receipt Drilldown</span>
                                                        <h5 class="drilldown-title">Old account receipt overview</h5>
                                                        <p class="drilldown-subtitle">Official receipt context, posted fee items, and saved payment details for this grouped old-account transaction.</p>
                                                    </div>
                                                    <button type="button" class="btn drilldown-close" data-bs-dismiss="modal" aria-label="Close">
                                                        <i class="fas fa-times"></i>
                                                    </button>
                                                </div>
                                                <div class="drilldown-hero-grid">
                                                    <div class="hero-stat">
                                                        <span class="hero-stat-label">Official Receipt</span>
                                                        <div class="hero-stat-value"><?= h($payment['booklet_label']) ?> / OR <?= h((string) $payment['receipt_no']) ?></div>
                                                    </div>
                                                    <div class="hero-stat">
                                                        <span class="hero-stat-label">Total Paid</span>
                                                        <div class="hero-stat-value">PHP <?= number_format((float) $payment['total'], 2) ?></div>
                                                    </div>
                                                    <div class="hero-stat">
                                                        <span class="hero-stat-label">Payment Method</span>
                                                        <div class="hero-stat-value"><?= h((string) ($payment['method_label'] !== '' ? $payment['method_label'] : 'Not Set')) ?></div>
                                                    </div>
                                                    <div class="hero-stat">
                                    <span class="hero-stat-label">Prepared By</span>
                                    <div class="hero-stat-value <?= $payment['prepared_by'] !== '' ? '' : 'hero-stat-legacy' ?>"><?= h((string) ($payment['prepared_by'] !== '' ? $payment['prepared_by'] : $legacyPreparedByDetail)) ?></div>
                                </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-body">
                                            <div class="drilldown-meta-strip">
                                                <span class="meta-pill"><i class="far fa-calendar-alt"></i> Date Paid: <?= h($date ?: '-') ?></span>
                                                <span class="meta-pill"><i class="far fa-clock"></i> Time Paid: <?= h($time ?: '-') ?></span>
                                                <span class="meta-pill"><i class="fas fa-layer-group"></i> <?= (int) $itemsCount ?> fee item<?= $itemsCount === 1 ? '' : 's' ?> covered</span>
                                            </div>
                                            <div class="row g-3 mb-3">
                                                <div class="col-12 col-lg-<?= !empty($payment['method_breakdown']) ? '6' : '12' ?>">
                                                    <div class="detail-card h-100">
                                                        <div class="drilldown-section-heading">
                                                            <h6>Payment Method Breakdown</h6>
                                                            <?php if ($payment['method_breakdown_text'] !== ''): ?>
                                                                <span><?= h((string) $payment['method_breakdown_text']) ?></span>
                                                            <?php endif; ?>
                                                        </div>
                                                        <?php if (!empty($payment['method_breakdown'])): ?>
                                                            <div class="method-breakdown-list">
                                                                <?php foreach (($payment['method_breakdown'] ?? []) as $methodRow): ?>
                                                                    <div class="method-breakdown-item">
                                                                        <div class="method-breakdown-top">
                                                                            <span class="method-name-chip"><i class="fas fa-wallet"></i> <?= h((string) ($methodRow['method'] ?? '')) ?></span>
                                                                            <span class="method-amount">PHP <?= number_format((float) ($methodRow['amount'] ?? 0), 2) ?></span>
                                                                        </div>
                                                                        <div class="method-breakdown-meta">
                                                                            <?php if (!empty($methodRow['reference_number'])): ?>
                                                                                <div class="method-breakdown-meta-line"><strong>Reference:</strong> <?= h((string) $methodRow['reference_number']) ?></div>
                                                                            <?php endif; ?>
                                                                            <?php if (!empty($methodRow['note'])): ?>
                                                                                <div class="method-breakdown-meta-line"><strong>Note:</strong> <?= h((string) $methodRow['note']) ?></div>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    </div>
                                                                <?php endforeach; ?>
                                                            </div>
                                                        <?php else: ?>
                                                            <div class="detail-card-value"><?= h((string) ($payment['method_label'] !== '' ? $payment['method_label'] : 'No payment method saved')) ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="col-12 col-lg-<?= !empty($payment['method_breakdown']) ? '6' : '12' ?>">
                                                    <div class="detail-card h-100">
                                                        <div class="drilldown-section-heading">
                                                            <h6>Receipt Context</h6>
                                                            <span>Reference, state, and receipt note</span>
                                                        </div>
                                                        <div class="modal-detail-grid mb-3">
                                                            <div>
                                                                <span class="detail-card-label">Reference No.</span>
                                                                <div class="detail-card-value"><?= h((string) ($payment['reference_display'] !== '' ? $payment['reference_display'] : '-')) ?></div>
                                                            </div>
                                                            <div>
                                                                <span class="detail-card-label">Receipt State</span>
                                                                <div class="detail-card-value"><?= h((string) ($payment['receipt_state']['label'] ?? '-')) ?></div>
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <span class="detail-card-label">Receipt Note</span>
                                                            <div class="modal-note-block"><?= h(!empty($payment['payment_note_display']) ? $payment['payment_note_display'] : (!empty($payment['remarks']) ? implode("\n", $payment['remarks']) : '-')) ?></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="detail-card">
                                                <div class="drilldown-section-heading">
                                                    <h6>Fee Items Covered</h6>
                                                    <span><?= (int) $itemsCount ?> item<?= $itemsCount === 1 ? '' : 's' ?> posted under this receipt</span>
                                                </div>
                                                <div class="table-responsive fee-table-shell">
                                                    <table class="table table-sm breakdown-table mb-0">
                                                        <thead>
                                                            <tr>
                                                                <th>Fee Type</th>
                                                                <th class="text-end">Amount</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php foreach ($payment['items'] as $item): ?>
                                                                <tr>
                                                                    <td><?= h((string) ($item['fee_type'] ?? '')) ?></td>
                                                                    <td class="text-end">PHP <?= number_format((float) ($item['amount'] ?? 0), 2) ?></td>
                                                                </tr>
                                                            <?php endforeach; ?>
                                                            <tr class="fee-total-row">
                                                                <td>Total Receipt Amount</td>
                                                                <td class="text-end">PHP <?= number_format((float) $payment['total'], 2) ?></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php $receiptModals[] = ob_get_clean(); ?>
                        <?php endforeach; else: ?>
                            <tr><td colspan="8" class="text-center">No grouped receipts found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if (!empty($receiptModals)): ?>
                <?= implode("\n", $receiptModals) ?>
            <?php endif; ?>
            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <nav>
                <ul class="pagination justify-content-center">
                    <?php for ($pageno = 1; $pageno <= $total_pages; $pageno++): ?>
                        <li class="page-item <?= $pageno == $page ? 'active' : '' ?>">
                            <a class="page-link" href="?id=<?= (int)$student_id ?>&page=<?= $pageno ?>"><?= $pageno ?></a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>

    <div class="card mb-4 receipt-integrity-card">
        <div class="card-header">
            <button class="receipt-integrity-toggle" type="button" data-bs-toggle="collapse" data-bs-target="#receiptIntegrityBody" aria-expanded="false" aria-controls="receiptIntegrityBody">
                <span><i class="fas fa-shield-check"></i> Receipt Integrity</span>
                <span class="receipt-integrity-summary">
                    <span class="receipt-mini-pill">Mismatch: <?= number_format($receipt_registry_missing_count) ?></span>
                    <span class="receipt-mini-pill">Voided: <?= number_format($receipt_registry_voided_count) ?></span>
                    <span class="receipt-mini-pill">Valid: <?= number_format($receipt_registry_active_count) ?></span>
                    <i class="fas fa-chevron-down receipt-integrity-caret"></i>
                </span>
            </button>
        </div>
        <div class="collapse" id="receiptIntegrityBody">
        <div class="card-body">
            <div class="receipt-integrity-grid">
                <div class="history-summary-card">
                    <div class="label">Valid Receipt Links</div>
                    <div class="value"><?= number_format($receipt_registry_active_count) ?></div>
                </div>
                <div class="history-summary-card">
                    <div class="label">Voided Receipts</div>
                    <div class="value"><?= number_format($receipt_registry_voided_count) ?></div>
                </div>
                <div class="history-summary-card">
                    <div class="label">Receipt Mismatches</div>
                    <div class="value"><?= number_format($receipt_registry_missing_count) ?></div>
                </div>
            </div>
        </div>
        </div>
    </div>

    <a href="/school-admin-dashboard/modules/old accounts/student-old-account-list.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Back to Old Student List
    </a>
</div>

<?php if ($can_delete_payment_row): ?>
<!-- Delete Payment Modal -->
<div class="modal fade" id="deletePaymentModal" tabindex="-1" aria-labelledby="deletePaymentModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form method="post" action="/school-admin-dashboard/modules/old accounts/booklet/student-old-delete-payment.php" class="modal-content" id="deletePaymentForm">
      <div class="modal-header bg-danger text-light">
        <h5 class="modal-title" id="deletePaymentModalLabel">
            <i class="fas fa-trash"></i> Confirm Delete Payment Receipt
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
        <input type="hidden" name="payment_id" id="modalPaymentId" value="">
        <input type="hidden" name="student_id" id="modalStudentId" value="">
        <p class="mb-0">Are you sure you want to permanently delete this payment receipt?<br>
        This action <strong>cannot be undone</strong> and will remove this payment and its receipt from the records.</p>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Yes, Delete</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="fas fa-times"></i> Cancel</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Theme toggle
    var toggle = document.getElementById('themeToggleBtn');
    if (toggle) toggle.addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        var icon = this.querySelector('i');
        if (icon) { icon.classList.toggle('fa-moon'); icon.classList.toggle('fa-sun'); }
    });

    // Modal data transfer for payment deletion
    var deletePaymentModal = document.getElementById('deletePaymentModal');
    if (deletePaymentModal) {
        deletePaymentModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var paymentId = button.getAttribute('data-payment-id');
            var studentId = button.getAttribute('data-student-id');
            document.getElementById('modalPaymentId').value = paymentId;
            document.getElementById('modalStudentId').value = studentId;
        });
    }

    var historySearch = document.getElementById('oldPaymentHistorySearch');
    var historyRows = Array.from(document.querySelectorAll('.old-payment-history-row'));
    if (historySearch) {
        historySearch.addEventListener('input', function () {
            var search = historySearch.value.trim().toLowerCase();
            historyRows.forEach(function (row) {
                row.style.display = row.textContent.toLowerCase().includes(search) ? '' : 'none';
            });
        });
    }
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<footer class="text-center py-4 text-muted small">
    &copy; <?= h(date("Y")) ?> <?= h($schoolName) ?> | School Admin Dashboard
</footer>
</body>
</html>
<?php $conn->close(); ?>


