<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require '../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/school-info-helper.php';
require_once __DIR__ . '/old-account-followup-helper.php';
include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');

$currentRole = (string) ($_SESSION['role'] ?? '');
if (!is_super_admin_role($currentRole)) {
    admin_session_forbidden('Only the Super Administrator can manage old account anchors.');
}

ensure_old_student_followup_columns($conn);
$hasOldAnchorColumn = old_account_column_exists($conn, 'old_anchor_id');
admin_csrf_token();

$oldStudentId = isset($_GET['id']) ? (int) $_GET['id'] : (int) ($_POST['old_student_id'] ?? 0);
if ($oldStudentId <= 0) {
    header('Location: /school-admin-dashboard/modules/old accounts/student-old-account-list.php?error=invalid_old_anchor');
    exit();
}

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);

$oldStmt = $conn->prepare("
    SELECT
        os.*,
        " . ($hasOldAnchorColumn ? "anchor.lastname AS anchor_lastname,
        anchor.firstname AS anchor_firstname,
        anchor.middlename AS anchor_middlename,
        anchor.school_year AS anchor_school_year" : "'' AS anchor_lastname,
        '' AS anchor_firstname,
        '' AS anchor_middlename,
        '' AS anchor_school_year") . "
    FROM old_students os
    " . ($hasOldAnchorColumn ? "LEFT JOIN old_students anchor ON anchor.id = os.old_anchor_id" : "") . "
    WHERE os.id = ?
    LIMIT 1
");
$oldStmt->bind_param('i', $oldStudentId);
$oldStmt->execute();
$oldStudent = $oldStmt->get_result()->fetch_assoc();
$oldStmt->close();

if (!$oldStudent) {
    header('Location: /school-admin-dashboard/modules/old accounts/student-old-account-list.php?error=old_student_missing');
    exit();
}

$error = '';
$searchTerm = trim((string) ($_GET['search'] ?? ''));
$matches = [];
$anchorReason = trim((string) ($_POST['anchor_reason'] ?? ''));
$currentAnchorId = $hasOldAnchorColumn ? (int) ($oldStudent['old_anchor_id'] ?? 0) : 0;
$currentAnchorRows = $currentAnchorId > 0 ? old_account_anchor_related_records($conn, $currentAnchorId) : [];
$linkedStudentId = (int) ($oldStudent['linked_student_id'] ?? 0);
$isHeadAnchor = $currentAnchorId > 0 && $currentAnchorId === $oldStudentId;
$isLinkedToOtherAnchor = $currentAnchorId > 0 && $currentAnchorId !== $oldStudentId;
$anchorChildCount = $isHeadAnchor ? old_account_anchor_member_count($conn, $oldStudentId, true) : 0;

if (!$hasOldAnchorColumn) {
    $error = schema_migration_missing_schema_message('old account anchor grouping');
}

if ($error === '' && $linkedStudentId > 0) {
    $error = 'This old account is already linked to an active current student. Its main anchor now comes from that current student link, so old-to-old anchor assignment is disabled.';
}

if ($hasOldAnchorColumn && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_anchor_link'])) {
    admin_require_post_csrf();
    $removeReason = trim((string) ($_POST['remove_anchor_reason'] ?? ''));

    if ($linkedStudentId > 0) {
        $error = 'Old-to-old anchor removal is blocked because this record already uses the active current-student link as its main anchor.';
    } elseif (!$isLinkedToOtherAnchor) {
        $error = 'This old account is not currently linked under another anchor head.';
    } elseif ($removeReason === '') {
        $error = 'Please enter a reason before removing this anchor link.';
    } else {
        $stmt = $conn->prepare("UPDATE old_students SET old_anchor_id = NULL WHERE id = ?");
        $stmt->bind_param('i', $oldStudentId);
        if ($stmt->execute()) {
            $user = $_SESSION['username'] ?? 'unknown';
            $oldStudentName = trim((string) (($oldStudent['lastname'] ?? '') . ', ' . ($oldStudent['firstname'] ?? '') . ' ' . ($oldStudent['middlename'] ?? '')));
            $details = 'Old Student ID: ' . $oldStudentId
                . ' | Old Account: ' . $oldStudentName
                . ' | Removed Anchor Head ID: ' . $currentAnchorId
                . ' | Reason: ' . $removeReason;
            audit_log($conn, $user, 'Removed old account anchor link', 'Old Accounts', $details, 'WARNING');
            $stmt->close();
            header('Location: /school-admin-dashboard/modules/old accounts/student-old-payment-history.php?id=' . $oldStudentId . '&anchor_removed=1');
            exit();
        }
        $stmt->close();
        $error = 'Could not remove this old-account anchor link.';
    }
}

if ($hasOldAnchorColumn && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['unset_head_anchor'])) {
    admin_require_post_csrf();
    $unsetReason = trim((string) ($_POST['unset_anchor_reason'] ?? ''));

    if ($linkedStudentId > 0) {
        $error = 'This record already uses the active current-student link as its main anchor, so old-anchor changes are disabled.';
    } elseif (!$isHeadAnchor) {
        $error = 'Only a head anchor can be unset from this page.';
    } elseif ($anchorChildCount > 0) {
        $error = 'Remove all old records linked to this head anchor first before unsetting it.';
    } elseif ($unsetReason === '') {
        $error = 'Please enter a reason before unsetting this head anchor.';
    } else {
        $stmt = $conn->prepare("UPDATE old_students SET old_anchor_id = NULL WHERE id = ?");
        $stmt->bind_param('i', $oldStudentId);
        if ($stmt->execute()) {
            $user = $_SESSION['username'] ?? 'unknown';
            $oldStudentName = trim((string) (($oldStudent['lastname'] ?? '') . ', ' . ($oldStudent['firstname'] ?? '') . ' ' . ($oldStudent['middlename'] ?? '')));
            $details = 'Old Student ID: ' . $oldStudentId
                . ' | Old Account: ' . $oldStudentName
                . ' | Removed Head Anchor ID: ' . $oldStudentId
                . ' | Reason: ' . $unsetReason;
            audit_log($conn, $user, 'Unset old account head anchor', 'Old Accounts', $details, 'WARNING');
            $stmt->close();
            header('Location: /school-admin-dashboard/modules/old accounts/student-old-payment-history.php?id=' . $oldStudentId . '&anchor_unset=1');
            exit();
        }
        $stmt->close();
        $error = 'Could not unset this head anchor.';
    }
}

if ($hasOldAnchorColumn && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_self_anchor'])) {
    admin_require_post_csrf();
    if ($linkedStudentId > 0) {
        $error = 'This old account is already linked to an active current student, so old-to-old anchor setup is disabled.';
    } elseif ($isLinkedToOtherAnchor) {
        $error = 'This record is already linked to a head anchor. Remove that anchor link first before setting a new head.';
    } elseif ($anchorReason === '') {
        $error = 'Please enter a reason before setting this record as the head anchor.';
    } else {
        $stmt = $conn->prepare("UPDATE old_students SET old_anchor_id = id WHERE id = ?");
        $stmt->bind_param('i', $oldStudentId);
        if ($stmt->execute()) {
            $user = $_SESSION['username'] ?? 'unknown';
            $oldStudentName = trim((string) (($oldStudent['lastname'] ?? '') . ', ' . ($oldStudent['firstname'] ?? '') . ' ' . ($oldStudent['middlename'] ?? '')));
            $details = 'Old Student ID: ' . $oldStudentId
                . ' | Old Account: ' . $oldStudentName
                . ' | New Anchor Head ID: ' . $oldStudentId
                . ' | Reason: ' . $anchorReason;
            audit_log($conn, $user, 'Set old account as head anchor', 'Old Accounts', $details, 'INFO');
            $stmt->close();
            header('Location: /school-admin-dashboard/modules/old accounts/student-old-payment-history.php?id=' . $oldStudentId . '&anchor_head=1');
            exit();
        }
        $stmt->close();
        $error = 'Could not set this record as the head anchor.';
    }
}

if ($hasOldAnchorColumn && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['anchor_old_student_id'])) {
    admin_require_post_csrf();
    $targetOldStudentId = (int) ($_POST['anchor_old_student_id'] ?? 0);
    if ($linkedStudentId > 0) {
        $error = 'This old account already uses the active current-student link as its anchor, so old-to-old grouping is disabled.';
    } elseif ($isHeadAnchor) {
        $error = 'This record is already the head anchor. Unset it first if you want to move it under another head.';
    } elseif ($isLinkedToOtherAnchor) {
        $error = 'This record is already linked to a head anchor. Remove that anchor link first before assigning a new one.';
    } elseif ($targetOldStudentId <= 0) {
        $error = 'Choose a valid old account anchor before saving.';
    } elseif ($anchorReason === '') {
        $error = 'Please enter a reason before linking to this anchor.';
    } else {
        $targetStmt = $conn->prepare("
            SELECT id, lastname, firstname, middlename, school_year, old_anchor_id
            FROM old_students
            WHERE id = ?
            LIMIT 1
        ");
        $targetStmt->bind_param('i', $targetOldStudentId);
        $targetStmt->execute();
        $target = $targetStmt->get_result()->fetch_assoc();
        $targetStmt->close();

        if (!$target) {
            $error = 'The selected old account was not found.';
        } else {
            $resolvedAnchorId = (int) ($target['old_anchor_id'] ?? 0);
            if ($resolvedAnchorId <= 0) {
                $resolvedAnchorId = (int) ($target['id'] ?? 0);
                $promoteStmt = $conn->prepare("UPDATE old_students SET old_anchor_id = id WHERE id = ?");
                $promoteStmt->bind_param('i', $resolvedAnchorId);
                $promoteStmt->execute();
                $promoteStmt->close();
            }

            $updateStmt = $conn->prepare("UPDATE old_students SET old_anchor_id = ? WHERE id = ?");
            $updateStmt->bind_param('ii', $resolvedAnchorId, $oldStudentId);
            if ($updateStmt->execute()) {
                $user = $_SESSION['username'] ?? 'unknown';
                $oldStudentName = trim((string) (($oldStudent['lastname'] ?? '') . ', ' . ($oldStudent['firstname'] ?? '') . ' ' . ($oldStudent['middlename'] ?? '')));
                $targetName = trim((string) (($target['lastname'] ?? '') . ', ' . ($target['firstname'] ?? '') . ' ' . ($target['middlename'] ?? '')));
                $details = 'Old Student ID: ' . $oldStudentId
                    . ' | Old Account: ' . $oldStudentName
                    . ' | Anchor Head ID: ' . $resolvedAnchorId
                    . ' | Selected Record ID: ' . $targetOldStudentId
                    . ' | Anchor Record: ' . $targetName
                    . ' | Anchor Year: ' . (($target['school_year'] ?? '') !== '' ? $target['school_year'] : 'Unknown')
                    . ' | Reason: ' . $anchorReason;
                audit_log($conn, $user, 'Linked old account to head anchor', 'Old Accounts', $details, 'INFO');
                $updateStmt->close();
                header('Location: /school-admin-dashboard/modules/old accounts/student-old-payment-history.php?id=' . $oldStudentId . '&anchor_linked=1');
                exit();
            }
            $updateStmt->close();
            $error = 'Could not save the old-account anchor.';
        }
    }
}

if ($hasOldAnchorColumn && $searchTerm !== '') {
    $like = '%' . $searchTerm . '%';
    $matchStmt = $conn->prepare("
        SELECT
            id,
            lastname,
            firstname,
            middlename,
            status,
            school_year,
            contact,
            old_anchor_id,
            linked_student_id
        FROM old_students
        WHERE id <> ?
          AND (
            lastname LIKE ?
            OR firstname LIKE ?
            OR middlename LIKE ?
            OR contact LIKE ?
            OR school_year LIKE ?
          )
        ORDER BY lastname ASC, firstname ASC, school_year DESC
        LIMIT 25
    ");
    $matchStmt->bind_param('isssss', $oldStudentId, $like, $like, $like, $like, $like);
    $matchStmt->execute();
    $matchResult = $matchStmt->get_result();
    while ($row = $matchResult->fetch_assoc()) {
        $matches[] = $row;
    }
    $matchStmt->close();
}

$anchorHeadName = trim((string) (($oldStudent['anchor_lastname'] ?? '') . ', ' . ($oldStudent['anchor_firstname'] ?? '') . ' ' . ($oldStudent['anchor_middlename'] ?? '')));
$anchorActionsDisabled = !$hasOldAnchorColumn || $linkedStudentId > 0;
$csrfToken = admin_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Old Account Head Anchor | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background:
                radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 28%),
                linear-gradient(180deg, #f8fbff 0%, #eef3f9 100%);
            font-family:'Segoe UI','Roboto','Arial',sans-serif;
            color:#23395d;
        }
        .app-navbar {
            background:#23395d !important;
            box-shadow:0 10px 24px rgba(35,57,93,.12);
        }
        .app-navbar .navbar-brand,
        .app-navbar .nav-link,
        .app-navbar .navbar-brand i {
            color:#ffffff !important;
        }
        .app-navbar .nav-link.active {
            font-weight:800;
            position:relative;
        }
        .app-navbar .nav-link.active::after {
            content:"";
            position:absolute;
            left:.85rem;
            right:.85rem;
            bottom:.35rem;
            height:2px;
            border-radius:999px;
            background:#d8e6f6;
        }
        .app-navbar .theme-toggle-btn {
            background:none;
            border:none;
            color:#fff;
            font-size:1.25rem;
        }
        .compact-header { text-align:center; padding:18px 0 4px; }
        .compact-header img { width:52px; height:52px; object-fit:contain; border-radius:14px; background:#fff; padding:5px; box-shadow:0 10px 24px rgba(35,57,93,.10); margin-bottom:8px; }
        .compact-header h1 { font-size:1.08rem; font-weight:800; color:#23395d; margin-bottom:0.2rem; }
        .compact-header p { color:#607388; font-size:0.92rem; margin:0; }
        .page-wrap { max-width:1460px; margin:0 auto; padding:18px 24px 40px; }
        .section-card { background:rgba(255,255,255,.96); border:1px solid #dbe7f4; border-radius:20px; box-shadow:0 14px 30px rgba(35,57,93,.07); padding:22px; margin-bottom:18px; }
        .card-title-row { display:flex; justify-content:space-between; align-items:flex-start; gap:12px; flex-wrap:wrap; margin-bottom:14px; }
        .card-kicker { font-size:.78rem; text-transform:uppercase; letter-spacing:.08em; color:#607388; font-weight:700; }
        .card-title { font-size:1.2rem; font-weight:800; color:#23395d; }
        .identity-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(210px,1fr)); gap:14px; }
        .identity-item { background:#f8fbff; border:1px solid #dbe7f4; border-radius:16px; padding:12px 14px; min-height:96px; }
        .identity-label { font-size:.74rem; text-transform:uppercase; letter-spacing:.06em; color:#607388; font-weight:700; }
        .identity-value { font-size:.96rem; font-weight:700; color:#23395d; margin-top:4px; line-height:1.4; }
        .match-card { border:1px solid #dbe7f4; border-radius:18px; padding:16px; height:100%; background:#fff; box-shadow:0 8px 20px rgba(35,57,93,.04); }
        .match-card.match-disabled { background:#f8fafc; border-style:dashed; }
        .match-name { font-size:1rem; font-weight:700; color:#23395d; margin-bottom:8px; }
        .match-meta { color:#607388; font-size:.9rem; margin-bottom:12px; line-height:1.55; }
        .match-state-badge { border-radius:999px; font-weight:700; padding:.45rem .75rem; margin-bottom:.75rem; display:inline-flex; align-items:center; gap:.4rem; }
        .match-note { font-size:.86rem; color:#607388; margin:.6rem 0 .85rem; line-height:1.5; }
        .hint-box { background:#fff8e1; border:1px solid #ffe8a1; color:#7a5c00; border-radius:16px; padding:13px 15px; }
        .search-panel { background:#f8fbff; border:1px solid #dbe7f4; border-radius:16px; padding:14px; }
        .search-help { color:#607388; font-size:.88rem; margin-top:8px; }
        .reason-input { border-radius:12px; min-height:44px; }
        .match-card .btn { border-radius:999px; font-weight:700; }
        .anchor-list { margin-top:10px; color:#607388; font-size:.9rem; }
        @media (min-width: 1200px) {
            .anchor-results-grid .col-lg-6 {
                width: 33.333333%;
            }
        }
        @media (max-width: 991.98px) {
            .page-wrap {
                padding:16px 16px 34px;
            }
        }
    </style>
</head>
<body>
<?php render_admin_nav('old_accounts'); ?>
<?php render_school_page_header($schoolName, $schoolLogo, 'Assign a head anchor so multiple old-year records can stay grouped even without an active current student.', 'compact-header', 'rounded shadow-sm', ''); ?>

<div class="page-wrap">
    <div class="section-card">
        <div class="card-title-row">
            <div>
                <div class="card-kicker">Old Accounts Anchor</div>
                <div class="card-title">Assign Head Anchor For Old-Year Records</div>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <a href="/school-admin-dashboard/modules/old accounts/student-old-payment-history.php?id=<?= (int) $oldStudentId ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left"></i> Back To Old Account
                </a>
            </div>
        </div>

        <div class="hint-box mb-3">
            Use this only for the same person across old school years. This does not replace the current old-to-active link. It only adds an old-to-old grouping head.
        </div>

        <div class="row g-3">
            <div class="col-12 col-lg-6">
                <div class="identity-grid">
                    <div class="identity-item">
                        <div class="identity-label">Old Account</div>
                        <div class="identity-value"><?= htmlspecialchars(trim((string) (($oldStudent['lastname'] ?? '') . ', ' . ($oldStudent['firstname'] ?? '') . ' ' . ($oldStudent['middlename'] ?? '')))) ?></div>
                    </div>
                    <div class="identity-item">
                        <div class="identity-label">School Year</div>
                        <div class="identity-value"><?= htmlspecialchars((string) ($oldStudent['school_year'] ?? '-')) ?></div>
                    </div>
                    <div class="identity-item">
                        <div class="identity-label">Old Status</div>
                        <div class="identity-value"><?= htmlspecialchars((string) ($oldStudent['status'] ?? '-')) ?></div>
                    </div>
                    <div class="identity-item">
                        <div class="identity-label">Contact</div>
                        <div class="identity-value"><?= htmlspecialchars((string) ($oldStudent['contact'] ?? '-')) ?></div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div class="identity-grid">
                    <div class="identity-item">
                        <div class="identity-label">Anchor Status</div>
                        <div class="identity-value"><?= htmlspecialchars(old_account_anchor_status_label($oldStudentId, $currentAnchorId)) ?></div>
                    </div>
                    <div class="identity-item">
                        <div class="identity-label">Current Head Anchor</div>
                        <div class="identity-value"><?= $currentAnchorId > 0 ? htmlspecialchars($anchorHeadName !== '' ? $anchorHeadName : ('Record #' . $currentAnchorId)) : 'None yet' ?></div>
                    </div>
                    <div class="identity-item">
                        <div class="identity-label">Anchor Year</div>
                        <div class="identity-value"><?= $currentAnchorId > 0 ? htmlspecialchars((string) ($oldStudent['anchor_school_year'] ?? '-')) : '-' ?></div>
                    </div>
                    <div class="identity-item">
                        <div class="identity-label">Grouped Records</div>
                        <div class="identity-value"><?= $currentAnchorId > 0 ? number_format(count($currentAnchorRows)) : '0' ?></div>
                    </div>
                    <div class="identity-item">
                        <div class="identity-label">Active Current Link</div>
                        <div class="identity-value"><?= $linkedStudentId > 0 ? ('Current Student #' . $linkedStudentId) : 'None' ?></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-3 pt-3 border-top">
            <form method="post" class="row g-2 align-items-end">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="old_student_id" value="<?= (int) $oldStudentId ?>">
                <input type="hidden" name="set_self_anchor" value="1">
                <div class="col-12 col-lg-9">
                    <label class="form-label">Reason for setting this record as the head anchor</label>
                    <input type="text" name="anchor_reason" class="form-control reason-input" placeholder="Example: this is the clearest old-year record for the same student" required>
                </div>
                <div class="col-12 col-lg-3">
                    <button type="submit" class="btn btn-primary w-100" <?= $anchorActionsDisabled || $isLinkedToOtherAnchor ? 'disabled' : '' ?>>
                        <i class="fas fa-crown"></i> Set This As Head
                    </button>
                </div>
            </form>
            <?php if ($currentAnchorId > 0 && $currentAnchorRows): ?>
                <div class="anchor-list">
                    Grouped records under the current head:
                    <?php
                        $labels = [];
                        foreach ($currentAnchorRows as $anchorRow) {
                            $labels[] = trim((string) ($anchorRow['school_year'] ?? 'Unknown')) . ' (#' . (int) ($anchorRow['id'] ?? 0) . ')';
                        }
                    ?>
                    <strong><?= htmlspecialchars(implode(', ', $labels)) ?></strong>
                </div>
            <?php endif; ?>
            <?php if ($isLinkedToOtherAnchor): ?>
                <form method="post" class="row g-2 align-items-end mt-3">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="old_student_id" value="<?= (int) $oldStudentId ?>">
                    <input type="hidden" name="remove_anchor_link" value="1">
                    <div class="col-12 col-lg-9">
                        <label class="form-label">Reason for removing this anchor link</label>
                        <input type="text" name="remove_anchor_reason" class="form-control reason-input" placeholder="Example: wrong old-year grouping" required>
                    </div>
                    <div class="col-12 col-lg-3">
                        <button type="submit" class="btn btn-outline-danger w-100" <?= $anchorActionsDisabled ? 'disabled' : '' ?>>
                            <i class="fas fa-link-slash"></i> Remove Anchor Link
                        </button>
                    </div>
                </form>
            <?php elseif ($isHeadAnchor): ?>
                <form method="post" class="row g-2 align-items-end mt-3">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="old_student_id" value="<?= (int) $oldStudentId ?>">
                    <input type="hidden" name="unset_head_anchor" value="1">
                    <div class="col-12 col-lg-9">
                        <label class="form-label">Reason for unsetting this head anchor</label>
                        <input type="text" name="unset_anchor_reason" class="form-control reason-input" placeholder="Example: regrouping this student under a different old record" required>
                    </div>
                    <div class="col-12 col-lg-3">
                        <button type="submit" class="btn btn-outline-danger w-100" <?= $anchorActionsDisabled || $anchorChildCount > 0 ? 'disabled' : '' ?>>
                            <i class="fas fa-unlink"></i> Unset Head
                        </button>
                    </div>
                    <?php if ($anchorChildCount > 0): ?>
                        <div class="col-12">
                            <div class="small text-danger">This head anchor still has <?= number_format($anchorChildCount) ?> linked old record(s). Remove those links first before unsetting the head.</div>
                        </div>
                    <?php endif; ?>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <div class="section-card">
        <div class="card-title-row">
            <div>
                <div class="card-kicker">Search Old Records</div>
                <div class="card-title">Link This Record To An Existing Head Anchor</div>
            </div>
        </div>

        <?php if ($error !== ''): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="search-panel">
            <form method="get" class="row g-2 align-items-end">
                <input type="hidden" name="id" value="<?= (int) $oldStudentId ?>">
                <div class="col-12 col-md-9">
                    <label class="form-label">Search old accounts</label>
                    <input type="text" name="search" class="form-control" value="<?= htmlspecialchars($searchTerm) ?>" placeholder="Name, contact, or school year">
                    <div class="search-help">Search the same student across old school years, then choose which record should act as the anchor head.</div>
                </div>
                <div class="col-12 col-md-3">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search"></i> Search
                    </button>
                </div>
            </form>
        </div>

        <?php if ($searchTerm !== ''): ?>
            <div class="mt-4">
                <div class="small text-muted mb-3"><?= number_format(count($matches)) ?> match(es) found for <strong><?= htmlspecialchars($searchTerm) ?></strong>.</div>
                <div class="row g-3 anchor-results-grid">
                    <?php if ($matches): ?>
                        <?php foreach ($matches as $match): ?>
                            <?php
                                $candidateAnchorId = (int) ($match['old_anchor_id'] ?? 0);
                                $candidateResolvedAnchorId = $candidateAnchorId > 0 ? $candidateAnchorId : (int) ($match['id'] ?? 0);
                                $candidateLinkedStudentId = (int) ($match['linked_student_id'] ?? 0);
                                $candidateIsHead = $candidateAnchorId > 0 && $candidateAnchorId === (int) ($match['id'] ?? 0);
                                $candidateIsChild = $candidateAnchorId > 0 && $candidateAnchorId !== (int) ($match['id'] ?? 0);
                                $candidateUsesActive = $candidateLinkedStudentId > 0;
                                $candidateAvailable = !$candidateUsesActive && !$candidateIsChild;
                                $candidateStateClass = $candidateUsesActive ? 'bg-success text-white' : ($candidateIsHead ? 'bg-primary text-white' : ($candidateIsChild ? 'bg-secondary text-white' : 'bg-light text-dark'));
                                $candidateStateLabel = $candidateUsesActive ? 'Uses Active Anchor' : ($candidateIsHead ? 'Head Anchor' : ($candidateIsChild ? 'Linked To Head' : 'Available'));
                                $candidateNote = $candidateUsesActive
                                    ? 'This record already uses its active/current student as the main anchor, so it cannot be reused for old-to-old grouping.'
                                    : ($candidateIsHead
                                        ? 'This record is already the head anchor. You can use it as the destination head for the current record.'
                                        : ($candidateIsChild
                                            ? 'This record is already grouped under another head, so it must be removed there first before it can be reused.'
                                            : 'This record is still available and can be promoted or used as the destination head.'));
                            ?>
                            <div class="col-12 col-lg-6">
                                <div class="match-card <?= !$candidateAvailable && !$candidateIsHead ? 'match-disabled' : '' ?>">
                                    <div class="match-name"><?= htmlspecialchars(trim((string) (($match['lastname'] ?? '') . ', ' . ($match['firstname'] ?? '') . ' ' . ($match['middlename'] ?? '')))) ?></div>
                                    <div class="match-state-badge <?= $candidateStateClass ?>">
                                        <i class="fas <?= $candidateUsesActive ? 'fa-link' : ($candidateIsHead ? 'fa-crown' : ($candidateIsChild ? 'fa-diagram-project' : 'fa-circle-check')) ?>"></i>
                                        <?= htmlspecialchars($candidateStateLabel) ?>
                                    </div>
                                    <div class="match-meta">
                                        School Year: <?= htmlspecialchars((string) (($match['school_year'] ?? '') !== '' ? $match['school_year'] : 'N/A')) ?><br>
                                        Status: <?= htmlspecialchars((string) (($match['status'] ?? '') !== '' ? $match['status'] : 'N/A')) ?><br>
                                        Contact: <?= htmlspecialchars((string) (($match['contact'] ?? '') !== '' ? $match['contact'] : 'N/A')) ?><br>
                                        Anchor Status: <?= htmlspecialchars($candidateStateLabel) ?>
                                    </div>
                                    <div class="match-note"><?= htmlspecialchars($candidateNote) ?></div>
                                    <form method="post">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                                        <input type="hidden" name="old_student_id" value="<?= (int) $oldStudentId ?>">
                                        <input type="hidden" name="anchor_old_student_id" value="<?= (int) $match['id'] ?>">
                                        <div class="mb-2">
                                            <input type="text" name="anchor_reason" class="form-control reason-input" value="<?= htmlspecialchars($anchorReason) ?>" placeholder="Reason for grouping these old records together" required>
                                        </div>
                                        <button type="submit" class="btn btn-success" <?= $anchorActionsDisabled || $isHeadAnchor || $isLinkedToOtherAnchor || (!$candidateAvailable && !$candidateIsHead) ? 'disabled' : '' ?>>
                                            <i class="fas fa-diagram-project"></i> <?= $candidateIsHead ? 'Use This Head' : 'Link To This Head' ?>
                                        </button>
                                        <span class="badge bg-light text-dark ms-2">Head ID: <?= (int) $candidateResolvedAnchorId ?></span>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="col-12">
                            <div class="alert alert-secondary mb-0">No old account matched that search yet. If this student has only one old-year record for now, you can set the current record as the head anchor first.</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
<?php $conn->close(); ?>
