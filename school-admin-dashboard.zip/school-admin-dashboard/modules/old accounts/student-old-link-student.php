<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require '../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/school-info-helper.php';
require_once __DIR__ . '/../settings/settings-security.php';
require_once __DIR__ . '/old-account-followup-helper.php';
include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');

$currentRole = (string) ($_SESSION['role'] ?? '');
if (!is_super_admin_role($currentRole)) {
    admin_session_forbidden('Only the Super Administrator can link old accounts to current students.');
}

ensure_old_student_followup_columns($conn);
$csrfToken = admin_csrf_token();

$oldStudentId = isset($_GET['id']) ? (int) $_GET['id'] : (int) ($_POST['old_student_id'] ?? 0);
if ($oldStudentId <= 0) {
    header('Location: /school-admin-dashboard/modules/old accounts/student-old-account-list.php?error=invalid_old_student');
    exit();
}

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);

$oldStmt = $conn->prepare("
    SELECT
        os.*,
        s.lastname AS linked_lastname,
        s.firstname AS linked_firstname,
        s.middlename AS linked_middlename,
        s.grade AS linked_grade,
        s.section AS linked_section,
        s.lrn AS linked_lrn,
        s.school_year_label AS linked_school_year_label
    FROM old_students os
    LEFT JOIN students s ON s.id = os.linked_student_id
    WHERE os.id = ?
    LIMIT 1
");
$oldStmt->bind_param('i', $oldStudentId);
$oldStmt->execute();
$oldStudent = $oldStmt->get_result()->fetch_assoc();
$oldStmt->close();

if (!$oldStudent) {
    header('Location: /school-admin-dashboard/modules/old accounts/student-old-account-list.php?error=old_student_missing');
    exit();
}

$error = '';
$success = '';
$searchTerm = trim((string) ($_GET['search'] ?? ''));
$matches = [];
$linkReason = trim((string) ($_POST['link_reason'] ?? ''));

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_link'])) {
    admin_require_post_csrf();
    $removeReason = trim((string) ($_POST['remove_link_reason'] ?? ''));
    $existingLinkedStudentId = (int) ($oldStudent['linked_student_id'] ?? 0);
    if ($existingLinkedStudentId <= 0) {
        $error = 'There is no current student link to remove from this old account.';
    } elseif ($removeReason === '') {
        $error = 'Please enter a reason before removing the current student link.';
    } else {
        $updateStmt = $conn->prepare("UPDATE old_students SET linked_student_id = NULL WHERE id = ?");
        $updateStmt->bind_param('i', $oldStudentId);
        if ($updateStmt->execute()) {
            $user = $_SESSION['username'] ?? 'unknown';
            $oldStudentName = trim((string) (($oldStudent['lastname'] ?? '') . ', ' . ($oldStudent['firstname'] ?? '') . ' ' . ($oldStudent['middlename'] ?? '')));
            $currentStudentName = trim((string) (($oldStudent['linked_lastname'] ?? '') . ', ' . ($oldStudent['linked_firstname'] ?? '') . ' ' . ($oldStudent['linked_middlename'] ?? '')));
            $details = 'Old Student ID: ' . $oldStudentId
                . ' | Old Account: ' . $oldStudentName
                . ' | Removed Current Student ID: ' . $existingLinkedStudentId
                . ' | Removed Current Student: ' . ($currentStudentName !== '' ? $currentStudentName : 'Unknown')
                . ' | Reason: ' . $removeReason;
            audit_log($conn, $user, 'Removed old account link to current student', 'Old Accounts', $details, 'WARNING');
            header('Location: /school-admin-dashboard/modules/old accounts/student-old-payment-history.php?id=' . $oldStudentId . '&unlinked=1');
            exit();
        }
        $updateStmt->close();
        $error = 'Could not remove the current student link.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['link_student_id'])) {
    admin_require_post_csrf();
    $linkStudentId = (int) ($_POST['link_student_id'] ?? 0);
    if ($linkStudentId <= 0) {
        $error = 'Choose a valid current student before saving the link.';
    } elseif ($linkReason === '') {
        $error = 'Please enter a reason before saving or changing the student link.';
    } else {
        $studentStmt = $conn->prepare("
            SELECT id, lastname, firstname, middlename, grade, section, lrn, school_year_label
            FROM students
            WHERE id = ?
            LIMIT 1
        ");
        $studentStmt->bind_param('i', $linkStudentId);
        $studentStmt->execute();
        $linkedStudent = $studentStmt->get_result()->fetch_assoc();
        $studentStmt->close();

        if (!$linkedStudent) {
            $error = 'The selected current student was not found.';
        } else {
            $updateStmt = $conn->prepare("UPDATE old_students SET linked_student_id = ? WHERE id = ?");
            $updateStmt->bind_param('ii', $linkStudentId, $oldStudentId);
            if ($updateStmt->execute()) {
                $user = $_SESSION['username'] ?? 'unknown';
                $oldStudentName = trim((string) (($oldStudent['lastname'] ?? '') . ', ' . ($oldStudent['firstname'] ?? '') . ' ' . ($oldStudent['middlename'] ?? '')));
                $currentStudentName = trim((string) (($linkedStudent['lastname'] ?? '') . ', ' . ($linkedStudent['firstname'] ?? '') . ' ' . ($linkedStudent['middlename'] ?? '')));
                $previousLinkedStudentId = (int) ($oldStudent['linked_student_id'] ?? 0);
                $previousLinkedStudentName = trim((string) (($oldStudent['linked_lastname'] ?? '') . ', ' . ($oldStudent['linked_firstname'] ?? '') . ' ' . ($oldStudent['linked_middlename'] ?? '')));
                $details = 'Old Student ID: ' . $oldStudentId
                    . ' | Old Account: ' . $oldStudentName
                    . ' | Previous Current Student ID: ' . ($previousLinkedStudentId > 0 ? $previousLinkedStudentId : 'None')
                    . ' | Previous Current Student: ' . ($previousLinkedStudentName !== '' ? $previousLinkedStudentName : 'None')
                    . ' | Linked Current Student ID: ' . $linkStudentId
                    . ' | Current Student: ' . $currentStudentName
                    . ' | Current LRN: ' . (($linkedStudent['lrn'] ?? '') !== '' ? $linkedStudent['lrn'] : 'N/A')
                    . ' | Current School Year: ' . (($linkedStudent['school_year_label'] ?? '') !== '' ? $linkedStudent['school_year_label'] : 'N/A')
                    . ' | Reason: ' . $linkReason;
                audit_log($conn, $user, $previousLinkedStudentId > 0 ? 'Changed old account link to current student' : 'Linked old account to current student', 'Old Accounts', $details, 'INFO');
                header('Location: /school-admin-dashboard/modules/old accounts/student-old-payment-history.php?id=' . $oldStudentId . '&' . ($previousLinkedStudentId > 0 ? 'relinked=1' : 'linked=1'));
                exit();
            }
            $updateStmt->close();
            $error = 'Could not save the student link.';
        }
    }
}

if ($searchTerm !== '') {
    $like = '%' . $searchTerm . '%';
    $matchStmt = $conn->prepare("
        SELECT id, lastname, firstname, middlename, grade, section, lrn, school_year_label, date_enrolled
        FROM students
        WHERE lastname LIKE ?
           OR firstname LIKE ?
           OR middlename LIKE ?
           OR lrn LIKE ?
           OR section LIKE ?
        ORDER BY lastname ASC, firstname ASC
        LIMIT 25
    ");
    $matchStmt->bind_param('sssss', $like, $like, $like, $like, $like);
    $matchStmt->execute();
    $matchResult = $matchStmt->get_result();
    while ($row = $matchResult->fetch_assoc()) {
        $matches[] = $row;
    }
    $matchStmt->close();
}

$linkedStudentExists = !empty($oldStudent['linked_lastname']) || !empty($oldStudent['linked_firstname']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Link Old Account | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background:
                radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 28%),
                linear-gradient(180deg, #f8fbff 0%, #eef3f9 100%);
            font-family:'Segoe UI','Roboto','Arial',sans-serif;
            color:#23395d;
        }
        .app-navbar {
            background:#23395d !important;
            box-shadow:0 10px 24px rgba(35,57,93,.12);
        }
        .app-navbar .navbar-brand,
        .app-navbar .nav-link,
        .app-navbar .navbar-brand i {
            color:#ffffff !important;
        }
        .app-navbar .nav-link.active {
            font-weight:800;
            position:relative;
        }
        .app-navbar .nav-link.active::after {
            content:"";
            position:absolute;
            left:.85rem;
            right:.85rem;
            bottom:.35rem;
            height:2px;
            border-radius:999px;
            background:rgba(255,255,255,.95);
        }
        .app-navbar .theme-toggle-btn {
            background:none;
            border:none;
            color:#fff;
            font-size:1.25rem;
        }
        .compact-header {
            text-align:center;
            padding:18px 0 4px;
        }
        .compact-header img {
            width:52px;
            height:52px;
            object-fit:contain;
            border-radius:14px;
            background:#fff;
            padding:5px;
            box-shadow:0 10px 24px rgba(35,57,93,.10);
            margin-bottom:8px;
        }
        .compact-header h1 {
            font-size:1.08rem;
            font-weight:800;
            color:#23395d;
            margin-bottom:0.2rem;
        }
        .compact-header p {
            color:#607388;
            font-size:0.92rem;
            margin:0;
        }
        .page-wrap { max-width:1460px; margin:0 auto; padding:18px 24px 40px; }
        .section-card {
            background:rgba(255,255,255,.96);
            border:1px solid #dbe7f4;
            border-radius:20px;
            box-shadow:0 14px 30px rgba(35,57,93,.07);
            padding:22px;
            margin-bottom:18px;
        }
        .card-title-row {
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            gap:12px;
            flex-wrap:wrap;
            margin-bottom:14px;
        }
        .card-kicker { font-size:.78rem; text-transform:uppercase; letter-spacing:.08em; color:#607388; font-weight:700; }
        .card-title { font-size:1.2rem; font-weight:800; color:#23395d; }
        .identity-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(210px,1fr)); gap:14px; }
        .identity-item { background:#f8fbff; border:1px solid #dbe7f4; border-radius:16px; padding:12px 14px; min-height:96px; }
        .identity-label { font-size:.74rem; text-transform:uppercase; letter-spacing:.06em; color:#607388; font-weight:700; }
        .identity-value { font-size:.96rem; font-weight:700; color:#23395d; margin-top:4px; line-height:1.4; }
        .match-card { border:1px solid #dbe7f4; border-radius:18px; padding:18px; height:100%; background:#fff; box-shadow:0 8px 20px rgba(35,57,93,.04); }
        .match-name { font-size:1rem; font-weight:700; color:#23395d; margin-bottom:8px; }
        .match-meta { color:#607388; font-size:.9rem; margin-bottom:12px; line-height:1.55; }
        .hint-box { background:#fff8e1; border:1px solid #ffe8a1; color:#7a5c00; border-radius:16px; padding:13px 15px; }
        .search-panel {
            background:#f8fbff;
            border:1px solid #dbe7f4;
            border-radius:16px;
            padding:14px;
        }
        .search-help {
            color:#607388;
            font-size:.88rem;
            margin-top:8px;
        }
        .reason-input {
            border-radius:12px;
            min-height:44px;
        }
        .match-card .btn {
            border-radius:999px;
            font-weight:700;
        }
        @media (min-width: 1200px) {
            .link-results-grid .col-lg-6 {
                width:33.333333%;
            }
        }
        @media (max-width: 991.98px) {
            .page-wrap {
                padding:16px 16px 34px;
            }
        }
    </style>
</head>
<body>
<?php render_admin_nav('students'); ?>
<?php render_school_page_header($schoolName, $schoolLogo, 'Review and confirm the correct current student before saving the link.', 'compact-header', 'rounded shadow-sm', ''); ?>

<div class="page-wrap">
    <div class="section-card">
        <div class="card-title-row">
            <div>
                <div class="card-kicker">Wave 2 Manual Link</div>
                <div class="card-title">Link Old Account To Current Student</div>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <a href="/school-admin-dashboard/modules/old accounts/student-old-payment-history.php?id=<?= (int) $oldStudentId ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left"></i> Back To Old Account
                </a>
                <?php if ($linkedStudentExists): ?>
                    <a href="/school-admin-dashboard/modules/students/student-view.php?id=<?= (int) $oldStudent['linked_student_id'] ?>" class="btn btn-outline-primary">
                        <i class="fas fa-eye"></i> Open Current Student
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <div class="hint-box mb-3">
            Use LRN first when available, then confirm the full name, grade, section, and school year before saving. This action is restricted to Super Admin and is recorded in audit logs.
        </div>

        <div class="row g-3">
            <div class="col-12 col-lg-6">
                <div class="identity-grid">
                    <div class="identity-item">
                        <div class="identity-label">Old Account</div>
                        <div class="identity-value"><?= htmlspecialchars(trim((string) (($oldStudent['lastname'] ?? '') . ', ' . ($oldStudent['firstname'] ?? '') . ' ' . ($oldStudent['middlename'] ?? '')))) ?></div>
                    </div>
                    <div class="identity-item">
                        <div class="identity-label">Old Status</div>
                        <div class="identity-value"><?= htmlspecialchars((string) ($oldStudent['status'] ?? '-')) ?></div>
                    </div>
                    <div class="identity-item">
                        <div class="identity-label">Old School Year</div>
                        <div class="identity-value"><?= htmlspecialchars((string) ($oldStudent['school_year'] ?? '-')) ?></div>
                    </div>
                    <div class="identity-item">
                        <div class="identity-label">Contact</div>
                        <div class="identity-value"><?= htmlspecialchars((string) ($oldStudent['contact'] ?? '-')) ?></div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div class="identity-grid">
                    <div class="identity-item">
                        <div class="identity-label">Current Link Status</div>
                        <div class="identity-value"><?= htmlspecialchars(old_account_link_status_label($oldStudent['status'] ?? '', (int) ($oldStudent['linked_student_id'] ?? 0), $linkedStudentExists)) ?></div>
                    </div>
                    <div class="identity-item">
                        <div class="identity-label">Linked Current Student</div>
                        <div class="identity-value"><?= $linkedStudentExists ? htmlspecialchars(trim((string) (($oldStudent['linked_lastname'] ?? '') . ', ' . ($oldStudent['linked_firstname'] ?? '') . ' ' . ($oldStudent['linked_middlename'] ?? '')))) : 'None yet' ?></div>
                    </div>
                    <div class="identity-item">
                        <div class="identity-label">Current Grade / Section</div>
                        <div class="identity-value"><?= $linkedStudentExists ? htmlspecialchars(trim((string) (($oldStudent['linked_grade'] ?? '-') . ' / ' . ($oldStudent['linked_section'] ?? '-')))) : '-' ?></div>
                    </div>
                    <div class="identity-item">
                        <div class="identity-label">Current LRN</div>
                        <div class="identity-value"><?= $linkedStudentExists ? htmlspecialchars((string) ($oldStudent['linked_lrn'] ?? '-')) : '-' ?></div>
                    </div>
                </div>
            </div>
        </div>
        <?php if ($linkedStudentExists): ?>
            <div class="mt-3 pt-3 border-top">
                <form method="post" class="row g-2 align-items-end">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="old_student_id" value="<?= (int) $oldStudentId ?>">
                    <input type="hidden" name="remove_link" value="1">
                    <div class="col-12 col-lg-9">
                        <label class="form-label">Reason for removing this link</label>
                        <input type="text" name="remove_link_reason" class="form-control" placeholder="Example: wrong student match during pilot cleanup" required>
                    </div>
                    <div class="col-12 col-lg-3">
                        <button type="submit" class="btn btn-outline-danger w-100">
                            <i class="fas fa-link-slash"></i> Remove Link
                        </button>
                    </div>
                </form>
            </div>
        <?php endif; ?>
    </div>

    <div class="section-card">
        <div class="card-title-row">
            <div>
                <div class="card-kicker">Search Current Students</div>
                <div class="card-title">Find The Matching Current Record</div>
            </div>
        </div>

        <?php if ($error !== ''): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php elseif ($success !== ''): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <div class="search-panel">
            <form method="get" class="row g-2 align-items-end">
                <input type="hidden" name="id" value="<?= (int) $oldStudentId ?>">
                <div class="col-12 col-md-9">
                    <label class="form-label">Search current student</label>
                    <input type="text" name="search" class="form-control" value="<?= htmlspecialchars($searchTerm) ?>" placeholder="Name or LRN">
                    <div class="search-help">Best practice: search by full name first, then use LRN to confirm the final match.</div>
                </div>
                <div class="col-12 col-md-3">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search"></i> Search
                    </button>
                </div>
            </form>
        </div>

        <?php if ($searchTerm !== ''): ?>
            <div class="mt-4">
                <div class="small text-muted mb-3"><?= number_format(count($matches)) ?> match(es) found for <strong><?= htmlspecialchars($searchTerm) ?></strong>.</div>
                <div class="row g-3 link-results-grid">
                    <?php if ($matches): ?>
                        <?php foreach ($matches as $match): ?>
                            <div class="col-12 col-lg-6">
                                <div class="match-card">
                                    <div class="match-name"><?= htmlspecialchars(trim((string) (($match['lastname'] ?? '') . ', ' . ($match['firstname'] ?? '') . ' ' . ($match['middlename'] ?? '')))) ?></div>
                                    <div class="match-meta">
                                        Grade: <?= htmlspecialchars((string) ($match['grade'] ?? '-')) ?>
                                        | Section: <?= htmlspecialchars((string) ($match['section'] ?? '-')) ?><br>
                                        LRN: <?= htmlspecialchars((string) (($match['lrn'] ?? '') !== '' ? $match['lrn'] : 'N/A')) ?><br>
                                        School Year: <?= htmlspecialchars((string) (($match['school_year_label'] ?? '') !== '' ? $match['school_year_label'] : 'N/A')) ?><br>
                                        Date Enrolled: <?= htmlspecialchars((string) (($match['date_enrolled'] ?? '') !== '' ? $match['date_enrolled'] : 'N/A')) ?>
                                    </div>
                                    <form method="post">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                                        <input type="hidden" name="old_student_id" value="<?= (int) $oldStudentId ?>">
                                        <input type="hidden" name="link_student_id" value="<?= (int) $match['id'] ?>">
                                        <div class="mb-2">
                                            <input type="text" name="link_reason" class="form-control reason-input" value="<?= htmlspecialchars($linkReason) ?>" placeholder="Reason for linking or changing this match" required>
                                        </div>
                                        <button type="submit" class="btn btn-success">
                                            <i class="fas fa-link"></i> <?= (int) ($oldStudent['linked_student_id'] ?? 0) === (int) $match['id'] ? 'Keep This Link' : 'Link This Student' ?>
                                        </button>
                                        <a href="/school-admin-dashboard/modules/students/student-view.php?id=<?= (int) $match['id'] ?>" class="btn btn-outline-primary ms-2">
                                            <i class="fas fa-eye"></i> Open Student
                                        </a>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="col-12">
                            <div class="alert alert-secondary mb-0">No current student matched that search yet. If the student no longer exists in the current registrar list, leave this old account unlinked for now.</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
<?php $conn->close(); ?>
