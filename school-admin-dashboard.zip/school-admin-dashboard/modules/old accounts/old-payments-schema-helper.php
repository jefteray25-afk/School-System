<?php

require_once __DIR__ . '/../../includes/schema-migration.php';

if (!function_exists('old_payments_schema_has_reference_note_columns')) {
    function old_payments_schema_has_reference_note_columns(mysqli $conn): bool
    {
        $res = $conn->query("SHOW COLUMNS FROM old_student_payments LIKE 'payment_method'");
        $hasMethod = $res && $res->num_rows > 0;
        if ($res) {
            $res->close();
        }
        $res2 = $conn->query("SHOW COLUMNS FROM old_student_payments LIKE 'reference_number'");
        $hasRef = $res2 && $res2->num_rows > 0;
        if ($res2) {
            $res2->close();
        }
        $res3 = $conn->query("SHOW COLUMNS FROM old_student_payments LIKE 'payment_note'");
        $hasNote = $res3 && $res3->num_rows > 0;
        if ($res3) {
            $res3->close();
        }
        return $hasMethod && $hasRef && $hasNote;
    }
}

if (!function_exists('ensure_old_student_payments_reference_note_columns')) {
    function ensure_old_student_payments_reference_note_columns(mysqli $conn): void
    {
        static $initialized = false;
        if ($initialized) {
            return;
        }

        if (!schema_migration_mode_enabled()) {
            $initialized = true;
            return;
        }

        $col = $conn->query("SHOW COLUMNS FROM old_student_payments LIKE 'payment_method'");
        if ($col && $col->num_rows === 0) {
            schema_migration_attempt($conn, "ALTER TABLE old_student_payments ADD COLUMN payment_method VARCHAR(30) NULL AFTER receipt_no");
        }

        $col2 = $conn->query("SHOW COLUMNS FROM old_student_payments LIKE 'reference_number'");
        if ($col2 && $col2->num_rows === 0) {
            schema_migration_attempt($conn, "ALTER TABLE old_student_payments ADD COLUMN reference_number VARCHAR(80) NULL AFTER payment_method");
        }

        $col3 = $conn->query("SHOW COLUMNS FROM old_student_payments LIKE 'payment_note'");
        if ($col3 && $col3->num_rows === 0) {
            schema_migration_attempt($conn, "ALTER TABLE old_student_payments ADD COLUMN payment_note TEXT NULL AFTER reference_number");
        }

        $initialized = true;
    }
}

if (!function_exists('ensure_old_student_payments_prepared_by_column')) {
    function ensure_old_student_payments_prepared_by_column(mysqli $conn): void
    {
        static $initialized = false;
        if ($initialized) {
            return;
        }

        if (!schema_migration_mode_enabled()) {
            $initialized = true;
            return;
        }

        $col = $conn->query("SHOW COLUMNS FROM old_student_payments LIKE 'prepared_by'");
        if ($col && $col->num_rows === 0) {
            schema_migration_attempt($conn, "ALTER TABLE old_student_payments ADD COLUMN prepared_by VARCHAR(100) NULL AFTER payment_note");
        }
        if ($col) {
            $col->close();
        }

        $initialized = true;
    }
}

if (!function_exists('old_payments_schema_has_prepared_by_column')) {
    function old_payments_schema_has_prepared_by_column(mysqli $conn): bool
    {
        $res = $conn->query("SHOW COLUMNS FROM old_student_payments LIKE 'prepared_by'");
        $hasPreparedBy = $res && $res->num_rows > 0;
        if ($res) {
            $res->close();
        }
        return $hasPreparedBy;
    }
}

