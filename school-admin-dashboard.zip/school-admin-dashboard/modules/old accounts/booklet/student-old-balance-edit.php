<?php
require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();
require '../../../config/database.php';
require_once __DIR__ . '/../../settings/settings-permissions-roles.php';
include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');

$conn->set_charset('utf8mb4');
admin_csrf_token();
function h($v) { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); }

$student_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$student_id) { die('Invalid student ID.'); }

$user_role = $_SESSION['role'] ?? '';
$can_edit_fee_balance = hasPermission($user_role, 'student_data', 'edit');
$can_delete_fee_row = hasPermission($user_role, 'student_data', 'delete');

$error = $success = "";

$stmt = $conn->prepare("SELECT * FROM old_students WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$student) { die('Student not found.'); }

$fee_rows = [];
$stmt = $conn->prepare("SELECT * FROM old_student_fees WHERE old_student_id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $fee_rows[$row['fee_type']] = $row;
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $can_edit_fee_balance) {
    if (!admin_csrf_validate($_POST['csrf_token'] ?? '')) {
        $error = "Invalid CSRF token.";
    } else {
        $edit_balances = $_POST['edit_balance'] ?? [];
        $audit_changes = [];
        foreach ($edit_balances as $type => $new_balance) {
            $type = trim((string) $type);
            $new_balance = (float) $new_balance;
            $current_balance = isset($fee_rows[$type]) ? (float) $fee_rows[$type]['balance'] : null;
            if ($current_balance === null) continue;
            $is_super_admin = $can_delete_fee_row;
            $can_update = ($current_balance == 0.0) || $is_super_admin;
            if ($can_update) {
                $stmt = $conn->prepare("UPDATE old_student_fees SET balance = ? WHERE old_student_id = ? AND fee_type = ?");
                $stmt->bind_param("dis", $new_balance, $student_id, $type);
                $stmt->execute();
                $stmt->close();
                $audit_changes[] = $type . ': ' . number_format($current_balance, 2) . ' -> ' . number_format($new_balance, 2);
            }
        }

        if (!empty($audit_changes)) {
            $user = $_SESSION['username'] ?? 'unknown';
            $action = "Edited old student fee balances";
            $module = "Old Accounts";
            $details = "Role: " . ($_SESSION['role'] ?? 'unknown') .
                       " | Old Student ID: " . $student_id .
                       " | Student Name: " . ($student['lastname'] ?? '') . ', ' . ($student['firstname'] ?? '') . ' ' . ($student['middlename'] ?? '') .
                       " | Fee Changes: [" . implode("; ", $audit_changes) . "]" .
                       " | Edited by: " . $user;
            audit_log($conn, $user, $action, $module, $details);
        }

        header("Location: ../student-old-payment-history.php?id=$student_id");
        exit();
    }
}
$csrf_token = admin_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Fee Balances | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f5f8fc; font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif; }
        .main-card { background: #fff; border-radius: 1rem; box-shadow: 0 4px 18px rgba(33,57,93,0.09), 0 1.5px 3px rgba(33,57,93,0.07); margin: 0 auto; margin-top: 48px; padding:2.2rem 2.5rem 2.3rem; max-width: 500px; }
        .section-title { font-size: 1.23rem; font-weight: 700; color: #23395d; margin-bottom: 1.1rem; letter-spacing: 0.04em; }
        .form-label { font-weight: 500; }
        .btn { min-width: 120px; }
    </style>
</head>
<body>
<div class="container main-card px-3">
    <div class="section-title">
        <i class="fas fa-edit"></i> Edit Fee Balances
    </div>
    <div class="mb-3">
        <strong>Student:</strong>
        <span><?= h($student['lastname']) ?>, <?= h($student['firstname']) ?> <?= h($student['middlename']) ?></span>
    </div>
    <?php if ($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>
    <form method="post" id="feeBalanceForm">
        <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
        <?php foreach ($fee_rows as $type => $fee):
            $current = (float) $fee['balance'];
            $balance_val = number_format($current, 2, '.', '');
            $is_locked = ($current !== 0.0 && !$can_delete_fee_row);
        ?>
        <div class="mb-3">
            <label class="form-label"><?= h($type) ?></label>
            <input type="number" name="edit_balance[<?= h($type) ?>]" step="0.01" class="form-control"
                   value="<?= h($balance_val) ?>" <?= $is_locked ? 'readonly disabled' : '' ?>>
            <?php if ($is_locked): ?>
                <div class="form-text text-danger">Only 0 balances can be set (unless super admin)</div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
        <div class="d-flex justify-content-between mt-4">
            <button type="submit" class="btn btn-primary" id="updateBalanceBtn"><i class="fas fa-save"></i> Update Balances</button>
            <a href="../student-old-payment-history.php?id=<?= $student_id ?>" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Cancel</a>
        </div>
    </form>
</div>
<footer class="text-center py-4 text-muted small">
    &copy; <?= h(date("Y")) ?> School Admin Dashboard
</footer>
<script>
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('feeBalanceForm').addEventListener('submit', function(e){
        if(!confirm("Would you like to update the fee balances?\n\nPlease review all changes before submitting.")){
            e.preventDefault();
        }
    });
});
</script>
</body>
</html>
<?php $conn->close(); ?>
