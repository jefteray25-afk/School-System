<?php
require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();
require '../../../config/database.php';
require_once __DIR__ . '/../../settings/settings-permissions-roles.php';
include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');

$conn->set_charset('utf8mb4');
admin_csrf_token();
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$student_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$student_id) { die('Invalid student ID.'); }

$user_role = $_SESSION['role'] ?? '';
$can_edit_fee_balance = hasPermission($user_role, 'student_data', 'edit');
if (!$can_edit_fee_balance) {
    $blockedUser = $_SESSION['username'] ?? 'unknown';
    audit_log(
        $conn,
        $blockedUser,
        'Blocked old account add fee access',
        'Old Accounts',
        'Role: ' . ($user_role !== '' ? $user_role : 'unknown') . ' | Old Student ID: ' . $student_id . ' | Reason: missing student_data:edit permission',
        'SECURITY'
    );
    admin_session_forbidden();
}

$error = "";

// Get existing fee types to prevent duplicates
$fee_types = [];
$stmt = $conn->prepare("SELECT fee_type FROM old_student_fees WHERE old_student_id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $fee_types[] = $row['fee_type'];
$stmt->close();

// ---------- FETCH STUDENT INFO ----------
$student = null;
$stmt = $conn->prepare("SELECT lastname, firstname, middlename FROM old_students WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows > 0) {
    $student = $res->fetch_assoc();
} else {
    $student = ['lastname' => 'Unknown', 'firstname' => '', 'middlename' => ''];
}
$stmt->close();

// Handle Add Fee Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_fee_row'])) {
    if (!admin_csrf_validate($_POST['csrf_token'] ?? '')) {
        $error = "Invalid CSRF token.";
    } else {
        $type = trim((string)($_POST['new_fee_type'] ?? ''));
        $balance = (float)($_POST['new_fee_balance'] ?? 0);
        if ($type === '') {
            $error = "Fee type name is required.";
        } elseif (in_array($type, $fee_types, true)) {
            $error = "Fee type already exists.";
        } elseif ($balance < 0) {
            $error = "Initial balance must not be negative.";
        } else {
            $stmt = $conn->prepare("INSERT INTO old_student_fees (old_student_id, fee_type, balance, paid, note) VALUES (?, ?, ?, 0, '')");
            $stmt->bind_param("isd", $student_id, $type, $balance);
            $stmt->execute();
            $stmt->close();

            $user = $_SESSION['username'] ?? 'unknown';
            $action = "Added fee type to old student";
            $module = "Old Accounts";
            $details = "Role: " . ($_SESSION['role'] ?? 'unknown') .
                       " | Old Student ID: " . $student_id .
                       " | Student Name: " . ($student['lastname'] ?? '') . ', ' . ($student['firstname'] ?? '') . ' ' . ($student['middlename'] ?? '') .
                       " | Fee Type: " . $type .
                       " | Initial Balance: " . number_format($balance, 2) .
                       " | Added by: " . $user;
            audit_log($conn, $user, $action, $module, $details);

            header("Location: ../student-old-payment-history.php?id=" . $student_id);
            exit();
        }
    }
}
$csrf_token = admin_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Fee | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f5f8fc; font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif; }
        .main-card { background: #fff; border-radius: 1rem; box-shadow: 0 4px 18px rgba(33,57,93,0.09), 0 1.5px 3px rgba(33,57,93,0.07); margin: 0 auto; margin-top: 48px; padding:2.2rem 2.5rem 2.3rem; max-width: 500px; }
        .section-title { font-size: 1.23rem; font-weight: 700; color: #0d6efd; margin-bottom: 1.1rem; letter-spacing: 0.04em; }
        .form-label { font-weight: 500; }
        .btn { min-width: 120px; }
    </style>
</head>
<body>
<div class="container main-card px-3">
    <div class="section-title">
        <i class="fas fa-plus"></i> Add Fee Type
    </div>
    <div class="mb-3">
        <strong>Student:</strong>
        <span><?= h($student['lastname']) ?>, <?= h($student['firstname']) ?> <?= h($student['middlename']) ?></span>
    </div>
    <?php if ($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>
    <form method="post" autocomplete="off">
        <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
        <input type="hidden" name="add_fee_row" value="1">
        <div class="mb-3">
            <label class="form-label">Fee Type Name</label>
            <input type="text" name="new_fee_type" class="form-control" required placeholder="e.g. Graduation Fee">
        </div>
        <div class="mb-3">
            <label class="form-label">Initial Balance</label>
            <input type="number" name="new_fee_balance" class="form-control" step="0.01" min="0" required placeholder="e.g. 1200.00">
        </div>
        <div class="d-flex justify-content-between mt-4">
            <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Add Fee</button>
            <a href="../student-old-payment-history.php?id=<?= $student_id ?>" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</a>
        </div>
    </form>
</div>
<footer class="text-center py-4 text-muted small">
    &copy; <?= h(date("Y")) ?> School Admin Dashboard
</footer>
</body>
</html>
<?php $conn->close(); ?>
