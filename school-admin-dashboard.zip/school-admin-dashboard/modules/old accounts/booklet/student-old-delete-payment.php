<?php
require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();
require '../../../config/database.php';
require_once __DIR__ . '/../../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../../../includes/includes-receipt-helper.php';
require_once __DIR__ . '/../../../includes/schema-migration.php';

$conn->set_charset('utf8mb4');
function ensure_old_payment_datetime_column(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }
    $columnName = 'paid_at_datetime';
    $check = $conn->prepare("
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'old_student_payments'
          AND COLUMN_NAME = ?
        LIMIT 1
    ");
    $check->bind_param('s', $columnName);
    $check->execute();
    $exists = $check->get_result()->num_rows > 0;
    $check->close();
    if (!$exists) {
        schema_migration_attempt($conn, "ALTER TABLE old_student_payments ADD COLUMN paid_at_datetime DATETIME NULL AFTER paid_at");
    }
}

ensure_old_payment_datetime_column($conn);

admin_require_post_csrf();

// Permissions check
$user_role = $_SESSION['role'] ?? '';
if (strtolower($user_role) !== 'super administrator') {
    die('<div class="error-message">Access denied. Only Super Administrators can delete payments.</div>');
}

// Validate input
$payment_id = isset($_POST['payment_id']) ? intval($_POST['payment_id']) : 0;
$student_id = isset($_POST['student_id']) ? intval($_POST['student_id']) : 0;
if ($payment_id <= 0 || $student_id <= 0) {
    die('<div class="error-message">Invalid request: missing payment or student ID.</div>');
}

try {
    $conn->begin_transaction();

    // Fetch payment details for audit before deletion
    $stmt = $conn->prepare("SELECT fee_type, amount, booklet_no, receipt_no, paid_at, COALESCE(paid_at_datetime, CONCAT(paid_at, ' 00:00:00')) AS paid_at_full FROM old_student_payments WHERE id = ? AND old_student_id = ? AND deleted_at IS NULL");
    $stmt->bind_param("ii", $payment_id, $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $payment = $result->fetch_assoc();
    $stmt->close();

    if (!$payment) {
        throw new Exception("Payment record not found or already deleted.");
    }

    // Soft delete payment
    $stmt = $conn->prepare("UPDATE old_student_payments SET deleted_at = NOW() WHERE id = ? AND old_student_id = ? AND deleted_at IS NULL");
    $stmt->bind_param("ii", $payment_id, $student_id);
    $stmt->execute();
    if ($stmt->affected_rows === 0) {
        throw new Exception("Payment record not found or already deleted.");
    }
    $stmt->close();

    $booklet_no = (int) ($payment['booklet_no'] ?? 0);
    $receipt_no = (int) ($payment['receipt_no'] ?? 0);

    if ($booklet_no > 0 && $receipt_no > 0) {
        $remainingStmt = $conn->prepare("
            SELECT COUNT(*)
            FROM old_student_payments
            WHERE old_student_id = ?
              AND booklet_no = ?
              AND receipt_no = ?
              AND deleted_at IS NULL
        ");
        $remainingStmt->bind_param("iii", $student_id, $booklet_no, $receipt_no);
        $remainingStmt->execute();
        $remainingStmt->bind_result($remainingCount);
        $remainingStmt->fetch();
        $remainingStmt->close();

        if ((int) $remainingCount === 0) {
            void_receipt(
                $conn,
                $receipt_no,
                'Old student payment deleted; receipt released for reuse',
                (int) ($_SESSION['user_id'] ?? 0),
                $booklet_no
            );
        }
    }

    $conn->commit();

    // ---------- AUDIT LOGGING: Delete Old Student Payment ----------
    include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');
    $user = $_SESSION['username'] ?? 'unknown';
    $action = "Deleted old student payment";
    $module = "Old Accounts";
    $details = "Role: " . ($_SESSION['role'] ?? 'unknown') .
               " | Old Student ID: " . $student_id .
               " | Payment ID: " . $payment_id .
               " | Fee Type: " . ($payment['fee_type'] ?? 'unknown') .
               " | Amount: " . ($payment['amount'] ?? 'unknown') .
               " | Booklet No: " . (isset($payment['booklet_no']) ? booklet_label_from_stored((int) $payment['booklet_no']) : 'unknown') .
               " | Receipt No: " . ($payment['receipt_no'] ?? 'unknown') .
               " | Paid At: " . ($payment['paid_at_full'] ?? ($payment['paid_at'] ?? 'unknown')) .
               " | Deleted by: " . $user;
    audit_log($conn, $user, $action, $module, $details);

    // Success message (redirect)
    header("Location: ../student-old-payment-history.php?id=" . $student_id . "&success=Payment+deleted+successfully");
    exit();
} catch (Exception $e) {
    $conn->rollback();
    echo '<div class="error-message">Delete failed: ' . htmlspecialchars($e->getMessage()) . '</div>';
}
?>
