﻿<?php
require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();
require '../../../config/database.php';
require_once __DIR__ . '/../../../includes/payment-collision-helper.php';
require_once __DIR__ . '/../../settings/settings-permissions-roles.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/includes-receipt-helper.php';
require_once __DIR__ . '/../../../includes/receipt-payment-method-helper.php';
include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');
require_once __DIR__ . '/../old-payments-schema-helper.php';

$conn->set_charset('utf8mb4');
admin_csrf_token();
ensure_old_student_payments_prepared_by_column($conn);
ensure_receipt_payment_methods_table($conn);
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$student_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$student_id) { die('Invalid student ID.'); }

$user_role = $_SESSION['role'] ?? '';
$can_add_payment = hasPermission($user_role, 'financial', 'add');
if (!$can_add_payment) {
    $blockedUser = $_SESSION['username'] ?? 'unknown';
    audit_log(
        $conn,
        $blockedUser,
        'Blocked old account add payment access',
        'Old Accounts',
        'Role: ' . ($user_role !== '' ? $user_role : 'unknown') . ' | Reason: missing financial:add permission',
        'SECURITY'
    );
    admin_session_forbidden();
}

$error = $success = "";

// SUPER ADMIN VOID RECEIPT
if ($user_role === 'Super Administrator' && isset($_POST['void_receipt_submit'])) {
    $receipt_no = intval($_POST['void_receipt_no'] ?? 0);
    $void_reason = trim($_POST['void_reason'] ?? '');
    $voided_by = $_SESSION['user_id'] ?? 0;
    if ($receipt_no && $void_reason && $voided_by) {
        if (void_receipt($conn, $receipt_no, $void_reason, $voided_by)) {
            $user = $_SESSION['username'] ?? 'unknown';
            $action = "Voided receipt";
            $module = "Old Accounts";
            $details = "Role: " . ($_SESSION['role'] ?? 'unknown') .
                       " | Receipt No: " . $receipt_no .
                       " | Reason: " . $void_reason .
                       " | Voided by: " . $user .
                       " | Student ID: " . $student_id;
            audit_log($conn, $user, $action, $module, $details);

            $success = "Receipt #$receipt_no has been voided.";
        } else {
            $error = "Failed to void receipt #$receipt_no (already voided or does not exist).";
        }
    } else {
        $error = "Please enter a valid receipt number and reason.";
    }
}

// Fetch old student info
$stmt = $conn->prepare("SELECT * FROM old_students WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$student) { die('Student not found.'); }

$school_year = $student['school_year'] ?? '';
$status = $student['status'] ?? '';
$contact = $student['contact'] ?? '';
$notes = $student['notes'] ?? '';

// Fetch fee rows from old_student_fees
$fee_rows = [];
$stmt = $conn->prepare("SELECT * FROM old_student_fees WHERE old_student_id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $fee_rows[$row['fee_type']] = $row;
$stmt->close();

const BOOKLET_MIN = REGULAR_BOOKLET_MIN;
const BOOKLET_MAX = REGULAR_BOOKLET_MAX;

// Used receipts and next available per booklet
$regular_booklet_rows = receipt_booklet_registry_payment_rows($conn, 'regular', true);
$regular_booklet_map = [];
$regular_booklet_usage = receipt_booklet_usage_map($conn, $regular_booklet_rows);
$used_receipts_by_booklet = [];
$next_available_receipt_by_booklet = [];
foreach ($regular_booklet_rows as $booklet_row) {
    $storage_no = (int) $booklet_row['storage_number'];
    $usage_row = $regular_booklet_usage[$storage_no] ?? ['used' => [], 'next' => null];
    $used_receipts_by_booklet[$storage_no] = $usage_row['used'];
    $next_available_receipt_by_booklet[$storage_no] = $usage_row['next'];
    $regular_booklet_map[$storage_no] = [
        'booklet_code' => (string) $booklet_row['booklet_code'],
        'range_start' => (int) $booklet_row['range_start'],
        'range_end' => (int) $booklet_row['range_end'],
    ];
}

$next_receipt_no = get_next_regular_receipt_no($conn);
$payment_balance_snapshot_token = payment_collision_token(old_payment_balance_snapshot($conn, $student_id));

// Handle payment submission (MULTI-FEE)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_payment'])) {
    if (!admin_csrf_validate($_POST['csrf_token'] ?? '')) {
        $error = "Invalid CSRF token.";
    } else {
        $submittedBalanceToken = trim((string) ($_POST['payment_balance_snapshot_token'] ?? ''));
        $date_paid  = (string)($_POST['date_paid'] ?? date('Y-m-d'));
        $time_paid  = (string)($_POST['time_paid'] ?? date('H:i'));
        $booklet_no = (int)($_POST['booklet_no'] ?? 0);
        $receipt_no = (int)($_POST['receipt_no'] ?? 0);
        $payment_note = trim((string)($_POST['payment_note'] ?? ''));
        $fees = $_POST['fees'] ?? [];
        $payment_methods = receipt_payment_methods_normalize($_POST['payment_methods'] ?? []);
        $prepared_by = trim((string) ($_SESSION['username'] ?? 'System'));
        $expected_payment_total = 0.0;
        foreach ($fees as $fee_item) {
            $expected_payment_total += (float) str_replace(',', '', (string) ($fee_item['amount'] ?? '0'));
        }
        $expected_payment_total = round($expected_payment_total, 2);
        $legacyMethodSummary = receipt_payment_methods_build_legacy_summary($payment_methods, $payment_note);
        $receipt_note = $legacyMethodSummary['method_label'];
        $reference_number = $legacyMethodSummary['reference_summary'];
        $payment_note = $legacyMethodSummary['note_summary'];

        $valid_booklet = ($booklet_no >= BOOKLET_MIN && $booklet_no <= BOOKLET_MAX);
        [$start, $end] = receipt_window_for_booklet($booklet_no);
        $valid_receipt = $valid_booklet && ($receipt_no >= $start && $receipt_no <= $end);

        $receipt_entry = get_receipt_registry_entry($conn, $receipt_no, $booklet_no);
        $exists = $receipt_entry !== null;
        $voided_status = $receipt_entry ? (int) $receipt_entry['voided'] : null;

        $max_regular_receipt = receipt_window_for_booklet(BOOKLET_MAX)[1];
        if ($submittedBalanceToken === '') {
            $error = "This payment form is missing collision protection data. Please refresh and try again.";
        } elseif (!hash_equals(payment_collision_token(old_payment_balance_snapshot($conn, $student_id)), $submittedBalanceToken)) {
            $error = "This old-account balance changed while you were preparing the payment. Refresh the page first so you don't save against stale balances.";
        } elseif (!$valid_booklet) {
            $error = "Booklet No. must be between " . BOOKLET_MIN . " and " . BOOKLET_MAX . ".";
        } elseif (!$valid_receipt) {
            $error = "Receipt No. for Booklet " . $booklet_no . " must be between " . $start . " and " . $end . ".";
        
        } elseif ($exists && $voided_status == 0) {
            $error = "Receipt No. $receipt_no is already registered and not voided. Please use the suggested next receipt no: $next_receipt_no";
        } elseif (!receipt_payment_methods_validate($payment_methods, $expected_payment_total, $error)) {
            // Validation message populated by helper.
        } elseif (empty($fees) || !is_array($fees)) {
            $error = "No payment fees entered.";
        } else {
            $datetime_paid = $date_paid . ' ' . $time_paid . ':00';
            $hasPaidAtDateTimeColumn = false;
            $paidAtColumnCheck = $conn->query("SHOW COLUMNS FROM old_student_payments LIKE 'paid_at_datetime'");
            if ($paidAtColumnCheck && $paidAtColumnCheck->num_rows > 0) {
                $hasPaidAtDateTimeColumn = true;
            }
            if ($paidAtColumnCheck) {
                $paidAtColumnCheck->close();
            }
            $hasPreparedByColumn = old_payments_schema_has_prepared_by_column($conn);
            try {
                $conn->begin_transaction();

                $reserve = reserve_or_reuse_receipt(
                    $conn,
                    $receipt_no,
                    $booklet_no,
                    'old_student_payments',
                    ($exists && $voided_status == 1) ? 'Reused for corrected old student payment entry' : null
                );
                $receipt_row_created = $reserve['success'];

                if ($receipt_row_created === false && !$error) {
                    $conn->rollback();
                    $error = $reserve['message'] ?: "Failed to create or reuse receipt. Please try a different receipt number.";
                }
                if (!$error && !receipt_payment_methods_replace_for_receipt($conn, $booklet_no, $receipt_no, 'old_student_payments', $payment_methods)) {
                    $conn->rollback();
                    $error = receipt_payment_methods_last_error() !== ''
                        ? receipt_payment_methods_last_error()
                        : 'Failed to save payment method breakdown.';
                }

                $success_payments = 0;
                $first_payment_id = null;
                $audit_fee_details = [];
                if (!$error) {
                    foreach ($fees as $fee_item) {
                        $fee_type = trim($fee_item['fee_type'] ?? '');
                        $amount = floatval(str_replace(',', '', $fee_item['amount'] ?? '0'));

                    if ($fee_type && isset($fee_rows[$fee_type]) && $amount > 0) {
                        $old_balance = (float)$fee_rows[$fee_type]['balance'];
                        if ($amount > $old_balance) {
                            $error = "Payment for {$fee_type} cannot exceed the remaining balance of PHP " . number_format($old_balance, 2) . ".";
                            break;
                        }
                        $new_balance = max(0, $old_balance - $amount);
                        $status_note = ($new_balance == 0.0) ? 'Fully Paid' : (($new_balance <= 500) ? 'Low Balance' : 'Outstanding');
                        $payment_remarks = $status_note;

                            $hasStructured = old_payments_schema_has_reference_note_columns($conn);
                            if ($hasStructured) {
                                $payment_method = $receipt_note;
                                $refValue = $reference_number;
                                if ($hasPaidAtDateTimeColumn) {
                                    if ($hasPreparedByColumn) {
                                        $sql = "INSERT INTO old_student_payments (old_student_id, fee_type, amount, paid_at, paid_at_datetime, booklet_no, receipt_no, note, payment_method, reference_number, payment_note, prepared_by)
                                                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("isdssiisssss", $student_id, $fee_type, $amount, $date_paid, $datetime_paid, $booklet_no, $receipt_no, $payment_remarks, $payment_method, $refValue, $payment_note, $prepared_by);
                                    } else {
                                        $sql = "INSERT INTO old_student_payments (old_student_id, fee_type, amount, paid_at, paid_at_datetime, booklet_no, receipt_no, note, payment_method, reference_number, payment_note)
                                                VALUES (?,?,?,?,?,?,?,?,?,?,?)";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("isdssiissss", $student_id, $fee_type, $amount, $date_paid, $datetime_paid, $booklet_no, $receipt_no, $payment_remarks, $payment_method, $refValue, $payment_note);
                                    }
                                } else {
                                    if ($hasPreparedByColumn) {
                                        $sql = "INSERT INTO old_student_payments (old_student_id, fee_type, amount, paid_at, booklet_no, receipt_no, note, payment_method, reference_number, payment_note, prepared_by)
                                                VALUES (?,?,?,?,?,?,?,?,?,?,?)";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("isdsiisssss", $student_id, $fee_type, $amount, $datetime_paid, $booklet_no, $receipt_no, $payment_remarks, $payment_method, $refValue, $payment_note, $prepared_by);
                                    } else {
                                        $sql = "INSERT INTO old_student_payments (old_student_id, fee_type, amount, paid_at, booklet_no, receipt_no, note, payment_method, reference_number, payment_note)
                                                VALUES (?,?,?,?,?,?,?,?,?,?)";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("isdsiissss", $student_id, $fee_type, $amount, $datetime_paid, $booklet_no, $receipt_no, $payment_remarks, $payment_method, $refValue, $payment_note);
                                    }
                                }
                            } else {
                                if ($reference_number !== '') {
                                    $payment_remarks .= " (Ref#: " . $reference_number . ")";
                                }
                                if ($payment_note !== '') {
                                    $payment_remarks .= " (Note: " . $payment_note . ")";
                                }
                                if ($hasPaidAtDateTimeColumn) {
                                    if ($hasPreparedByColumn) {
                                        $sql = "INSERT INTO old_student_payments (old_student_id, fee_type, amount, paid_at, paid_at_datetime, booklet_no, receipt_no, note, prepared_by) VALUES (?,?,?,?,?,?,?,?,?)";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("isdssiiss", $student_id, $fee_type, $amount, $date_paid, $datetime_paid, $booklet_no, $receipt_no, $payment_remarks, $prepared_by);
                                    } else {
                                        $sql = "INSERT INTO old_student_payments (old_student_id, fee_type, amount, paid_at, paid_at_datetime, booklet_no, receipt_no, note) VALUES (?,?,?,?,?,?,?,?)";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("isdssiis", $student_id, $fee_type, $amount, $date_paid, $datetime_paid, $booklet_no, $receipt_no, $payment_remarks);
                                    }
                                } else {
                                    if ($hasPreparedByColumn) {
                                        $sql = "INSERT INTO old_student_payments (old_student_id, fee_type, amount, paid_at, booklet_no, receipt_no, note, prepared_by) VALUES (?,?,?,?,?,?,?,?)";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("isdsiiss", $student_id, $fee_type, $amount, $datetime_paid, $booklet_no, $receipt_no, $payment_remarks, $prepared_by);
                                    } else {
                                        $sql = "INSERT INTO old_student_payments (old_student_id, fee_type, amount, paid_at, booklet_no, receipt_no, note) VALUES (?,?,?,?,?,?,?)";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("isdsiis", $student_id, $fee_type, $amount, $datetime_paid, $booklet_no, $receipt_no, $payment_remarks);
                                    }
                                }
                            }
                            if (!$stmt) {
                                $error = "Failed to prepare old payment row for {$fee_type}: " . $conn->error;
                                break;
                            }
                            if ($stmt->execute()) {
                                $new_payment_id = $stmt->insert_id;
                                $update_stmt = $conn->prepare("UPDATE old_student_fees SET balance = ? WHERE old_student_id = ? AND fee_type = ?");
                                $update_stmt->bind_param("dis", $new_balance, $student_id, $fee_type);
                                $update_stmt->execute();
                                $update_stmt->close();

                                if ($success_payments === 0) {
                                    attach_receipt_to_payment($conn, $receipt_no, $new_payment_id, $booklet_no);
                                    $first_payment_id = $new_payment_id;
                                }
                                $success_payments++;
                                $audit_fee_details[] = "FeeType: $fee_type, Amount: $amount, OldBalance: $old_balance, NewBalance: $new_balance";
                            } else {
                                $error = "Failed to save old payment row for {$fee_type}: " . $stmt->error;
                                break;
                            }
                            $stmt->close();
                        }
                    }
                }

                if ($success_payments > 0) {
                    $conn->commit();
                    $success = "Payments successfully added.";

                    $user = $_SESSION['username'] ?? 'unknown';
                    $action = "Added payment(s) to old student";
                    $module = "Old Accounts";
                    $details = "Role: " . ($_SESSION['role'] ?? 'unknown') .
                        " | Old Student ID: " . $student_id .
                        " | Student Name: " . ($student['lastname'] ?? '') . ', ' . ($student['firstname'] ?? '') . ' ' . ($student['middlename'] ?? '') .
                        " | Fees: [" . implode("; ", $audit_fee_details) . "]" .
                        " | Booklet No: " . booklet_label_from_stored($booklet_no) .
                        " | Receipt No: " . $receipt_no .
                        " | PaymentType: " . ($receipt_note !== '' ? $receipt_note : 'Not Set') .
                        " | MethodBreakdown: " . receipt_payment_methods_summary_text($payment_methods) .
                        ($reference_number !== '' ? " | Ref#: " . $reference_number : "") .
                        ($payment_note !== '' ? " | Note: " . $payment_note : "") .
                        " | Paid by: " . $user .
                        " | DatePaid: " . $datetime_paid;
                    audit_log($conn, $user, $action, $module, $details);

                    header("Location: ../student-old-payment-history.php?id=" . $student_id);
                    exit;
                } else {
                    $conn->rollback();
                    if ($error === '') {
                        $error = "No valid payments entered.";
                    }
                }
            } catch (Exception $e) {
                $conn->rollback();
                $error = "Failed to add payment. " . h($e->getMessage());
            }
        }
    }
}
$csrf_token = admin_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Payment | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f5f8fc; font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif; }
        .main-card { background: #fff; border-radius: 1rem; box-shadow: 0 4px 18px rgba(33,57,93,0.09), 0 1.5px 3px rgba(33,57,93,0.07); margin: 0 auto; margin-top: 48px; padding:2.2rem 2.5rem 2.3rem; max-width: 530px; }
        .section-title { font-size: 1.23rem; font-weight: 700; color: #198754; margin-bottom: 1.1rem; letter-spacing: 0.04em; }
        .form-label { font-weight: 500; }
        .student-details { font-size: 0.97rem; margin-bottom: .35rem; color: #555; }
        .fee-row { margin-bottom: 10px; }
        .total-payment-row { font-size: 1.1em; color: #198754; text-align: right; margin-bottom: 1em; }
        .void-section { background: #fffbe5; border: 1px solid #ffe58f; border-radius: 0.5rem; padding: 1rem; margin-bottom: 2rem;}
        .void-label { color: #a97d11; font-weight: bold;}
    </style>
</head>
<body>
<div class="container main-card px-3">
    <div class="section-title">
        <i class="fas fa-plus"></i> Add Payment
    </div>
    <div class="student-details mb-2">
        <strong>Student:</strong>
        <span><?= h($student['lastname']) ?>, <?= h($student['firstname']) ?> <?= h($student['middlename']) ?></span><br>
        <strong>Status:</strong> <?= h($status) ?> |
        <strong>School Year:</strong> <?= h($school_year) ?><br>
        <strong>Contact:</strong> <?= h($contact) ?><br>
        <strong>Notes:</strong> <?= h($notes) ?>
    </div>
    <?php if ($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><?= h($success) ?></div><?php endif; ?>

    <?php if ($user_role === 'Super Administrator'): ?>
    <div class="void-section mb-4">
        <form method="post" class="row g-2 align-items-center">
            <div class="col-auto void-label">Void Receipt (Super Administrator Only):</div>
            <div class="col-auto">
                <input type="number" name="void_receipt_no" class="form-control" placeholder="Receipt No" min="<?= REGULAR_RECEIPT_START ?>" max="<?= receipt_window_for_booklet(BOOKLET_MAX)[1] ?>" required>
            </div>
            <div class="col-auto">
                <input type="text" name="void_reason" class="form-control" placeholder="Reason for voiding" required>
            </div>
            <div class="col-auto">
                <button type="submit" name="void_receipt_submit" class="btn btn-warning"><i class="fas fa-ban"></i> Void Receipt</button>
            </div>
        </form>
        <div class="form-text">Voided receipts will become available for future payments. This action is recorded for audit.</div>
    </div>
    <?php endif; ?>

    <form method="post" id="addPaymentForm" autocomplete="off">
        <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
        <input type="hidden" name="add_payment" value="1">
        <input type="hidden" name="payment_balance_snapshot_token" value="<?= h($payment_balance_snapshot_token) ?>">
        <div id="feeRows"></div>
        <div class="total-payment-row">
            <strong>Total Payment:</strong> <span id="totalPayment">PHP 0.00</span>
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">Date Paid</label>
            <input type="date" name="date_paid" id="datePaidField" class="form-control" readonly>
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">Time Paid</label>
            <input type="time" name="time_paid" id="timePaidField" class="form-control" readonly>
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">Booklet No</label>
            <select name="booklet_no" id="bookletNoField" class="form-select" required>
                <option value="">Select Booklet No</option>
                <?php foreach ($regular_booklet_rows as $booklet_row): ?>
                    <option value="<?= (int) $booklet_row['storage_number'] ?>"><?= htmlspecialchars((string) $booklet_row['booklet_code']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">Receipt No</label>
            <select name="receipt_no" id="receiptNoField" class="form-select" required>
                <option value="">Select Receipt No</option>
            </select>
            <div class="form-text" id="receiptNoRange"></div>
            <div class="form-text">
                Global next available receipt (suggestion): <strong><?= (int)$next_receipt_no ?></strong>
            </div>
        </div>
        <div class="mb-3">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <label class="form-label fw-bold mb-0">Mode of Payment Breakdown</label>
                <button type="button" class="btn btn-outline-success btn-sm" id="addPaymentMethodBtn">+ Add Method</button>
            </div>
            <div id="paymentMethodRows"></div>
            <div class="form-text">Use 1 to 3 methods. The total of all method rows must match the total payment amount above.</div>
            <div class="form-text" id="paymentMethodTotalText">Payment method total: PHP 0.00</div>
            <div class="mt-2">
                <label class="form-label">Payment Note (optional)</label>
                <input type="text" name="payment_note" id="paymentNoteField" class="form-control" maxlength="255" placeholder="Optional note for this receipt">
            </div>
        </div>
        <div class="d-flex justify-content-between mt-4">
            <button type="submit" class="btn btn-success"><i class="fas fa-plus"></i> Add Payment</button>
            <a href="../student-old-payment-history.php?id=<?= $student_id ?>" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</a>
        </div>
    </form>
</div>
<!-- Double Check Modal -->
<div class="modal fade" id="doubleCheckModal" tabindex="-1" aria-labelledby="doubleCheckModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form id="finalPaymentForm" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="doubleCheckModalLabel"><i class="fas fa-exclamation-triangle text-warning"></i> Please Double Check</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <ul id="doubleCheckList" style="font-size:1.02em;">
          <li><strong>Payment Amounts:</strong> <span id="dcPaymentSummary"></span></li>
          <li><strong>Date Paid:</strong> <span id="dcDatePaid"></span></li>
          <li><strong>Time Paid:</strong> <span id="dcTimePaid"></span></li>
          <li><strong>Booklet No:</strong> <span id="dcBookletNo"></span></li>
          <li><strong>Receipt No:</strong> <span id="dcReceiptNo"></span></li>
          <li><strong>Payment Methods:</strong> <span id="dcPaymentType"></span></li>
          <li><strong>Payment Note:</strong> <span id="dcPaymentNote"></span></li>
        </ul>
        <div class="form-check mt-3">
          <input type="checkbox" class="form-check-input" id="doubleCheckConfirm" required>
          <label class="form-check-label" for="doubleCheckConfirm">I have double-checked the above information</label>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" id="doubleCheckEditBtn" data-bs-dismiss="modal">No, Edit Info</button>
        <button type="submit" class="btn btn-success" id="doubleCheckProceedBtn" disabled>Yes, Proceed</button>
      </div>
    </form>
  </div>
</div>
<footer class="text-center py-4 text-muted small">
    &copy; <?= h(date("Y")) ?> School Admin Dashboard
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
let feeRowIdx = 0;
let selectedFees = [];
let paymentMethodRowIdx = 0;
const feeRowsDiv = document.getElementById('feeRows');
const paymentMethodRowsDiv = document.getElementById('paymentMethodRows');
const feeRowsData = <?= json_encode(array_values($fee_rows)) ?>;
const supportedPaymentMethods = ['Cash', 'GCash', 'Bank Transfer'];

function getAvailableFeeTypes() {
    return feeRowsData.filter(function(fa) {
        return !selectedFees.includes(fa.fee_type);
    });
}

function makeFeeRow(idx) {
    let options = '<option value="">Select Fee Type</option>';
    let availableFeeTypes = getAvailableFeeTypes();
    for (let fa of availableFeeTypes) {
        options += `<option value="${fa.fee_type}">${fa.fee_type} (Current: PHP ${parseFloat(fa.balance).toLocaleString()})</option>`;
    }
    return `
    <div class="row fee-row align-items-center" id="feeRow_${idx}">
        <div class="col-7">
            <select class="form-select fee-type-select" name="fees[${idx}][fee_type]" data-row="${idx}" required>
                ${options}
            </select>
        </div>
        <div class="col-4">
            <input type="number" class="form-control" name="fees[${idx}][amount]" min="0" step="0.01" placeholder="Amount" required>
        </div>
        <div class="col-1 d-flex justify-content-end">
            <button type="button" class="btn btn-outline-danger removeFeeBtn" data-row="${idx}" aria-label="Remove Fee Row"><i class="fas fa-times"></i></button>
        </div>
    </div>
    `;
}

function addFeeRow() {
    let availableFeeTypes = getAvailableFeeTypes();
    if (availableFeeTypes.length > 0) {
        feeRowsDiv.insertAdjacentHTML('beforeend', makeFeeRow(feeRowIdx));
        feeRowIdx++;
        updateTotalPayment();
    }
}

function makePaymentMethodRow(idx) {
    return `
    <div class="border rounded p-2 mb-2 payment-method-row" id="paymentMethodRow_${idx}">
        <div class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label mb-1">Method</label>
                <select class="form-select payment-method-select" name="payment_methods[${idx}][method]" required>
                    <option value="">Select Method</option>
                    <option value="Cash">Cash</option>
                    <option value="GCash">GCash</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label mb-1">Amount</label>
                <input type="number" class="form-control payment-method-amount" name="payment_methods[${idx}][amount]" min="0.01" step="0.01" placeholder="Amount" required>
            </div>
            <div class="col-md-4 payment-method-ref-wrap" style="display:none;">
                <label class="form-label mb-1">Reference No.</label>
                <input type="text" class="form-control payment-method-ref" name="payment_methods[${idx}][reference_number]" maxlength="60" placeholder="Reference number">
            </div>
            <div class="col-md-1 d-flex justify-content-end">
                <button type="button" class="btn btn-outline-danger removePaymentMethodBtn" data-row="${idx}" aria-label="Remove Payment Method"><i class="fas fa-times"></i></button>
            </div>
        </div>
    </div>`;
}

function updateTotalPayment() {
    let total = 0;
    document.querySelectorAll('#feeRows input[type="number"]').forEach(input => {
        let val = parseFloat(input.value) || 0;
        total += val;
    });
    document.getElementById('totalPayment').textContent = 'PHP ' + total.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
    updatePaymentMethodTotal();
}

function getSelectedPaymentMethods() {
    return Array.from(document.querySelectorAll('.payment-method-select'))
        .map(select => String(select.value || '').trim())
        .filter(Boolean);
}

function syncPaymentMethodOptions() {
    const selected = new Set(getSelectedPaymentMethods());
    document.querySelectorAll('.payment-method-select').forEach(function(selectElement) {
        const currentValue = String(selectElement.value || '').trim();
        selectElement.querySelectorAll('option').forEach(function(option) {
            if (!option.value) {
                option.disabled = false;
                return;
            }
            option.disabled = selected.has(option.value) && option.value !== currentValue;
        });
    });
}

function togglePaymentMethodReference(rowDiv) {
    if (!rowDiv) {
        return;
    }
    const methodSelect = rowDiv.querySelector('.payment-method-select');
    const refWrap = rowDiv.querySelector('.payment-method-ref-wrap');
    const refInput = rowDiv.querySelector('.payment-method-ref');
    const needsRef = methodSelect && (methodSelect.value === 'GCash' || methodSelect.value === 'Bank Transfer');
    if (refWrap) {
        refWrap.style.display = needsRef ? '' : 'none';
    }
    if (refInput) {
        refInput.required = !!needsRef;
        if (!needsRef) {
            refInput.value = '';
        }
    }
}

function addPaymentMethodRow() {
    if (document.querySelectorAll('.payment-method-row').length >= supportedPaymentMethods.length) {
        return;
    }
    paymentMethodRowsDiv.insertAdjacentHTML('beforeend', makePaymentMethodRow(paymentMethodRowIdx));
    togglePaymentMethodReference(document.getElementById('paymentMethodRow_' + paymentMethodRowIdx));
    paymentMethodRowIdx++;
    syncPaymentMethodOptions();
    updatePaymentMethodTotal();
}

function updatePaymentMethodTotal() {
    let total = 0;
    document.querySelectorAll('.payment-method-amount').forEach(function(input) {
        total += parseFloat(input.value) || 0;
    });
    document.getElementById('paymentMethodTotalText').textContent =
        'Payment method total: PHP ' + total.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
}

addFeeRow();
addPaymentMethodRow();

feeRowsDiv.addEventListener('change', function(e) {
    if (e.target.classList.contains('fee-type-select')) {
        let val = e.target.value;
        if (val) {
            selectedFees.push(val);
            document.querySelectorAll('.fee-type-select').forEach(function(sel) {
                sel.querySelectorAll('option[value="' + val + '"]').forEach(function(opt) {
                    if (sel !== e.target) {
                        opt.disabled = true;
                    }
                });
            });
            if (getAvailableFeeTypes().length > 0) {
                addFeeRow();
            }
        } else {
            let prev = selectedFees.indexOf(val);
            if (prev !== -1) {
                selectedFees.splice(prev, 1);
            }
        }
    }
});

feeRowsDiv.addEventListener('click', function(e) {
    if (e.target.classList.contains('removeFeeBtn')) {
        let idx = e.target.getAttribute('data-row');
        let rowDiv = document.getElementById('feeRow_' + idx);
        if (rowDiv) {
            let sel = rowDiv.querySelector('.fee-type-select');
            if (sel && sel.value) {
                let i = selectedFees.indexOf(sel.value);
                if (i !== -1) {
                    selectedFees.splice(i, 1);
                }
            }
            rowDiv.remove();
            if (document.querySelectorAll('.fee-row').length === 0) {
                addFeeRow();
            }
            updateTotalPayment();
        }
    }
});

document.getElementById('addPaymentMethodBtn').addEventListener('click', addPaymentMethodRow);
paymentMethodRowsDiv.addEventListener('change', function(e) {
    if (e.target.classList.contains('payment-method-select')) {
        togglePaymentMethodReference(e.target.closest('.payment-method-row'));
        syncPaymentMethodOptions();
    }
});
paymentMethodRowsDiv.addEventListener('input', function(e) {
    if (e.target.classList.contains('payment-method-amount')) {
        updatePaymentMethodTotal();
    }
});
paymentMethodRowsDiv.addEventListener('click', function(e) {
    const removeButton = e.target.closest('.removePaymentMethodBtn');
    if (!removeButton) {
        return;
    }
    const rowDiv = document.getElementById('paymentMethodRow_' + removeButton.getAttribute('data-row'));
    if (rowDiv) {
        rowDiv.remove();
    }
    if (document.querySelectorAll('.payment-method-row').length === 0) {
        addPaymentMethodRow();
    } else {
        syncPaymentMethodOptions();
        updatePaymentMethodTotal();
    }
});

document.addEventListener('input', function(e) {
    if (e.target.matches('#feeRows input[type="number"]')) {
        updateTotalPayment();
    }
});

document.addEventListener('DOMContentLoaded', function() {
    var dateField = document.getElementById('datePaidField');
    var timeField = document.getElementById('timePaidField');
    if (dateField) {
        var now = new Date();
        var yyyy = now.getFullYear();
        var mm = String(now.getMonth() + 1).padStart(2, '0');
        var dd = String(now.getDate()).padStart(2, '0');
        dateField.value = yyyy + '-' + mm + '-' + dd;
    }
    if (timeField) {
        var now = new Date();
        var hh = String(now.getHours()).padStart(2, '0');
        var min = String(now.getMinutes()).padStart(2, '0');
        timeField.value = hh + ':' + min;
    }
});

const bookletNoField = document.getElementById('bookletNoField');
const receiptNoField = document.getElementById('receiptNoField');
const receiptNoRange = document.getElementById('receiptNoRange');
var usedReceiptsByBooklet = <?= json_encode($used_receipts_by_booklet) ?>;
var nextAvailableReceiptByBooklet = <?= json_encode($next_available_receipt_by_booklet) ?>;
var bookletCatalogByStorage = <?= json_encode($regular_booklet_map) ?>;

function updateReceiptNos() {
    let bookletNo = parseInt(bookletNoField.value);
    receiptNoField.innerHTML = '<option value="">Select Receipt No</option>';
    let bookletMeta = bookletCatalogByStorage[bookletNo];
    if (!isNaN(bookletNo) && bookletMeta) {
        let start = parseInt(bookletMeta.range_start, 10);
        let end = parseInt(bookletMeta.range_end, 10);
        let usedReceipts = usedReceiptsByBooklet[bookletNo] || [];
        let nextAvailable = nextAvailableReceiptByBooklet[bookletNo] || "";
        let selectedSet = false;
        for (let i = start; i <= end; i++) {
            if (usedReceipts.includes(i)) {
                receiptNoField.innerHTML += `<option value="${i}" disabled>${i} (Used)</option>`;
            } else {
                let selected = '';
                if (!selectedSet && nextAvailable == i) {
                    selected = ' selected';
                    selectedSet = true;
                }
                receiptNoField.innerHTML += `<option value="${i}"${selected}>${i}</option>`;
            }
        }
        receiptNoRange.textContent = `Receipt numbers for booklet ${bookletMeta.booklet_code}: ${start} - ${end}. Next available: ${nextAvailable ? nextAvailable : 'None'}`;
    } else {
        receiptNoRange.textContent = '';
    }
}

if (bookletNoField) {
    bookletNoField.addEventListener('change', updateReceiptNos);
    bookletNoField.addEventListener('focus', updateReceiptNos);
    if (bookletNoField.value) {
        updateReceiptNos();
    }
}

const paymentForm = document.getElementById('addPaymentForm');
const paymentNoteField = document.getElementById('paymentNoteField');
const doubleCheckModalEl = document.getElementById('doubleCheckModal');
const doubleCheckModal = doubleCheckModalEl ? new bootstrap.Modal(doubleCheckModalEl) : null;
const dcPaymentSummary = document.getElementById('dcPaymentSummary');
const dcDatePaid = document.getElementById('dcDatePaid');
const dcTimePaid = document.getElementById('dcTimePaid');
const dcBookletNo = document.getElementById('dcBookletNo');
const dcReceiptNo = document.getElementById('dcReceiptNo');
const dcPaymentType = document.getElementById('dcPaymentType');
const dcPaymentNote = document.getElementById('dcPaymentNote');
const doubleCheckConfirm = document.getElementById('doubleCheckConfirm');
const doubleCheckProceedBtn = document.getElementById('doubleCheckProceedBtn');

if (paymentForm && doubleCheckModal) {
    paymentForm.addEventListener('submit', function(e) {
        e.preventDefault();

        let payments = [];
        document.querySelectorAll('#feeRows .fee-row').forEach(row => {
            let type = row.querySelector('.fee-type-select');
            let amount = row.querySelector('input[type="number"]');
            if (type && type.value && amount && amount.value) {
                let typeText = type.options[type.selectedIndex].text;
                payments.push(typeText + ': PHP ' + parseFloat(amount.value).toLocaleString('en-US', {minimumFractionDigits:2}));
            }
        });

        let paymentBreakdown = [];
        document.querySelectorAll('.payment-method-row').forEach(function(row) {
            let method = row.querySelector('.payment-method-select')?.value || '';
            let amount = parseFloat(row.querySelector('.payment-method-amount')?.value || '0') || 0;
            let refNum = row.querySelector('.payment-method-ref')?.value.trim() || '';
            if (method && amount > 0) {
                let line = method + ': PHP ' + amount.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
                if (refNum) {
                    line += ' (Ref#: ' + refNum + ')';
                }
                paymentBreakdown.push(line);
            }
        });

        dcPaymentSummary.textContent = payments.length ? payments.join(', ') : 'No payment entered';
        dcDatePaid.textContent = document.getElementById('datePaidField').value;
        dcTimePaid.textContent = document.getElementById('timePaidField').value;
        dcBookletNo.textContent = document.getElementById('bookletNoField').value;
        dcReceiptNo.textContent = document.getElementById('receiptNoField').value;
        dcPaymentType.textContent = paymentBreakdown.length ? paymentBreakdown.join(' | ') : '-';
        dcPaymentNote.textContent = (paymentNoteField && paymentNoteField.value ? paymentNoteField.value.trim() : '') || '-';
        doubleCheckConfirm.checked = false;
        doubleCheckProceedBtn.disabled = true;
        doubleCheckModal.show();
    });

    if (doubleCheckConfirm) {
        doubleCheckConfirm.addEventListener('change', function() {
            doubleCheckProceedBtn.disabled = !this.checked;
        });
    }

    const finalForm = document.getElementById('finalPaymentForm');
    if (finalForm) {
        finalForm.addEventListener('submit', function(e) {
            e.preventDefault();
            doubleCheckModal.hide();
            paymentForm.submit();
        });
    }
}
</script>
</body>
</html>
<?php $conn->close(); ?>

