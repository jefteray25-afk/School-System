<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
include '../../config/database.php';
include __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/includes-receipt-helper.php';

function gs_h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function gs_money(float $amount): string
{
    return 'PHP ' . number_format($amount, 2);
}

function gs_booklet_storage_query_value(string $query): ?int
{
    $normalized = strtoupper(trim($query));
    if ($normalized === '') {
        return null;
    }
    if (preg_match('/^S\s*(\d+)$/', $normalized, $matches)) {
        return 0 - (int) $matches[1];
    }
    if (preg_match('/^\d+$/', $normalized)) {
        return (int) $normalized;
    }
    return null;
}

function gs_build_like(string $query): string
{
    return '%' . $query . '%';
}

$currentRole = $_SESSION['role'] ?? '';
$isOwn = in_array($currentRole, ['Administrator 1', 'Administrator 2'], true);
$canViewStudents = hasPermission($currentRole, 'student_data', 'view');
$canViewOldAccounts = hasPermission($currentRole, 'student_data', 'view');
$canViewFinancial =
    hasPermission($currentRole, 'financial', 'view') ||
    hasPermission($currentRole, 'account_mgmt', 'view') ||
    (hasPermission($currentRole, 'account_mgmt', 'view_own') && $isOwn);

if (is_limited_admin_operator_role($currentRole) || (!$canViewStudents && !$canViewOldAccounts && !$canViewFinancial)) {
    admin_session_forbidden();
}

school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
ensure_receipts_registry_schema($conn);
$schoolYearOptions = school_year_finance_options($conn, 'payments');
$activeSchoolYearLabel = school_year_get_active_label($conn);

$query = trim($_GET['q'] ?? '');
$scope = trim($_GET['scope'] ?? 'all');
$selectedSchoolYear = trim($_GET['school_year'] ?? $activeSchoolYearLabel);
if ($selectedSchoolYear === '') {
    $selectedSchoolYear = $activeSchoolYearLabel;
}
$allowedScopes = ['all', 'students', 'old', 'receipts'];
if (!in_array($scope, $allowedScopes, true)) {
    $scope = 'all';
}

$studentResults = [];
$oldResults = [];
$receiptResults = [];
$summary = ['students' => 0, 'old' => 0, 'receipts' => 0];
$bookletSearchValue = gs_booklet_storage_query_value($query);
$searchLike = gs_build_like($query);
$searchDigits = preg_replace('/\D/', '', $query);
$looksLikeReceipt = $searchDigits !== '' && strlen($searchDigits) <= 8;

if ($query !== '') {
    if (($scope === 'all' || $scope === 'students') && $canViewStudents) {
        $studentSql = "
            SELECT id, lastname, firstname, middlename, lrn, grade, section, school_year_label
            FROM students
            WHERE (
                lrn LIKE ?
                OR CONCAT(COALESCE(lastname,''), ' ', COALESCE(firstname,''), ' ', COALESCE(middlename,'')) LIKE ?
                OR section LIKE ?
            )
              AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?
            ORDER BY lastname ASC, firstname ASC
            LIMIT 20
        ";
        $studentStmt = $conn->prepare($studentSql);
        $studentStmt->bind_param('sssss', $searchLike, $searchLike, $searchLike, $selectedSchoolYear, $selectedSchoolYear);
        $studentStmt->execute();
        $studentResult = $studentStmt->get_result();
        while ($row = $studentResult->fetch_assoc()) {
            $studentResults[] = $row;
        }
        $studentStmt->close();
        $summary['students'] = count($studentResults);
    }

    if (($scope === 'all' || $scope === 'old') && $canViewOldAccounts) {
        $oldSql = "
            SELECT id, lastname, firstname, middlename, school_year, status, contact
            FROM old_students
            WHERE (
                CONCAT(COALESCE(lastname,''), ' ', COALESCE(firstname,''), ' ', COALESCE(middlename,'')) LIKE ?
                OR contact LIKE ?
                OR notes LIKE ?
            )
            ORDER BY lastname ASC, firstname ASC, school_year DESC
            LIMIT 20
        ";
        $oldStmt = $conn->prepare($oldSql);
        $oldStmt->bind_param('sss', $searchLike, $searchLike, $searchLike);
        $oldStmt->execute();
        $oldResult = $oldStmt->get_result();
        while ($row = $oldResult->fetch_assoc()) {
            $oldResults[] = $row;
        }
        $oldStmt->close();
        $summary['old'] = count($oldResults);
    }

    if (($scope === 'all' || $scope === 'receipts') && $canViewFinancial) {
        $receiptLike = $looksLikeReceipt ? '%' . $searchDigits . '%' : $searchLike;

        if ($bookletSearchValue !== null) {
            $activeReceiptSql = "
                SELECT
                    p.date_paid AS occurred_at,
                    p.amount,
                    p.booklet_no,
                    p.receipt_no,
                    COALESCE(at.name, a.type, 'Uncategorized') AS fee_type,
                    CONCAT(s.lastname, ', ', s.firstname, CASE WHEN TRIM(COALESCE(s.middlename, '')) <> '' THEN CONCAT(' ', s.middlename) ELSE '' END) AS payee_name,
                    s.grade AS grade_level,
                    s.school_year_label AS school_year_label
                FROM payments p
                LEFT JOIN accounts a ON p.account_id = a.id
                LEFT JOIN account_types at ON at.name = a.type
                LEFT JOIN students s ON a.student_id = s.id
                LEFT JOIN receipts_registry rr
                    ON rr.receipt_no = p.receipt_no
                   AND rr.booklet_no = p.booklet_no
                   AND rr.voided = 0
                   AND rr.used_by IN ('payments', 'other_payment')
                WHERE (
                    p.receipt_no LIKE ?
                    OR CONCAT(COALESCE(s.lastname,''), ' ', COALESCE(s.firstname,''), ' ', COALESCE(s.middlename,'')) LIKE ?
                    OR p.booklet_no = ?
                )
                  AND COALESCE(NULLIF(TRIM(p.school_year_label), ''), NULLIF(TRIM(a.school_year_label), ''), NULLIF(TRIM(s.school_year_label), ''), ?) = ?
                  AND ((p.booklet_no IS NULL OR p.receipt_no IS NULL) OR rr.receipt_no IS NOT NULL)
                ORDER BY p.date_paid DESC, p.id DESC
                LIMIT 20
            ";
            $activeStmt = $conn->prepare($activeReceiptSql);
            $activeStmt->bind_param('ssiss', $receiptLike, $searchLike, $bookletSearchValue, $selectedSchoolYear, $selectedSchoolYear);
        } else {
            $activeReceiptSql = "
                SELECT
                    p.date_paid AS occurred_at,
                    p.amount,
                    p.booklet_no,
                    p.receipt_no,
                    COALESCE(at.name, a.type, 'Uncategorized') AS fee_type,
                    CONCAT(s.lastname, ', ', s.firstname, CASE WHEN TRIM(COALESCE(s.middlename, '')) <> '' THEN CONCAT(' ', s.middlename) ELSE '' END) AS payee_name,
                    s.grade AS grade_level,
                    s.school_year_label AS school_year_label
                FROM payments p
                LEFT JOIN accounts a ON p.account_id = a.id
                LEFT JOIN account_types at ON at.name = a.type
                LEFT JOIN students s ON a.student_id = s.id
                LEFT JOIN receipts_registry rr
                    ON rr.receipt_no = p.receipt_no
                   AND rr.booklet_no = p.booklet_no
                   AND rr.voided = 0
                   AND rr.used_by IN ('payments', 'other_payment')
                WHERE (
                    p.receipt_no LIKE ?
                    OR CONCAT(COALESCE(s.lastname,''), ' ', COALESCE(s.firstname,''), ' ', COALESCE(s.middlename,'')) LIKE ?
                )
                  AND COALESCE(NULLIF(TRIM(p.school_year_label), ''), NULLIF(TRIM(a.school_year_label), ''), NULLIF(TRIM(s.school_year_label), ''), ?) = ?
                  AND ((p.booklet_no IS NULL OR p.receipt_no IS NULL) OR rr.receipt_no IS NOT NULL)
                ORDER BY p.date_paid DESC, p.id DESC
                LIMIT 20
            ";
            $activeStmt = $conn->prepare($activeReceiptSql);
            $activeStmt->bind_param('ssss', $receiptLike, $searchLike, $selectedSchoolYear, $selectedSchoolYear);
        }
        $activeStmt->execute();
        $activeResult = $activeStmt->get_result();
        while ($row = $activeResult->fetch_assoc()) {
            $receiptResults[] = [
                'source_type' => 'Active',
                'occurred_at' => $row['occurred_at'],
                'amount' => (float) $row['amount'],
                'booklet_label' => booklet_label_from_stored((int) $row['booklet_no']),
                'receipt_no' => (string) $row['receipt_no'],
                'fee_type' => $row['fee_type'],
                'payee_name' => $row['payee_name'] ?: 'Unknown Student',
                'grade_level' => $row['grade_level'] ?: '-',
                'school_year_label' => $row['school_year_label'] ?: $selectedSchoolYear,
            ];
        }
        $activeStmt->close();

        if ($bookletSearchValue !== null) {
            $oldReceiptSql = "
                SELECT
                    COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) AS occurred_at,
                    p.amount,
                    p.booklet_no,
                    p.receipt_no,
                    p.fee_type,
                    CONCAT(os.lastname, ', ', os.firstname, CASE WHEN TRIM(COALESCE(os.middlename, '')) <> '' THEN CONCAT(' ', os.middlename) ELSE '' END) AS payee_name,
                    os.school_year AS school_year_label
                FROM old_student_payments p
                LEFT JOIN old_students os ON p.old_student_id = os.id
                LEFT JOIN receipts_registry rr
                    ON rr.receipt_no = p.receipt_no
                   AND rr.booklet_no = p.booklet_no
                   AND rr.voided = 0
                   AND rr.used_by = 'old_student_payments'
                WHERE (
                    p.receipt_no LIKE ?
                    OR CONCAT(COALESCE(os.lastname,''), ' ', COALESCE(os.firstname,''), ' ', COALESCE(os.middlename,'')) LIKE ?
                    OR p.booklet_no = ?
                )
                  AND (p.deleted_at IS NULL OR p.deleted_at = '')
                  AND COALESCE(NULLIF(TRIM(os.school_year), ''), ?) = ?
                  AND rr.receipt_no IS NOT NULL
                ORDER BY COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) DESC, p.id DESC
                LIMIT 20
            ";
            $oldStmt = $conn->prepare($oldReceiptSql);
            $oldStmt->bind_param('ssiss', $receiptLike, $searchLike, $bookletSearchValue, $selectedSchoolYear, $selectedSchoolYear);
        } else {
            $oldReceiptSql = "
                SELECT
                    COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) AS occurred_at,
                    p.amount,
                    p.booklet_no,
                    p.receipt_no,
                    p.fee_type,
                    CONCAT(os.lastname, ', ', os.firstname, CASE WHEN TRIM(COALESCE(os.middlename, '')) <> '' THEN CONCAT(' ', os.middlename) ELSE '' END) AS payee_name,
                    os.school_year AS school_year_label
                FROM old_student_payments p
                LEFT JOIN old_students os ON p.old_student_id = os.id
                LEFT JOIN receipts_registry rr
                    ON rr.receipt_no = p.receipt_no
                   AND rr.booklet_no = p.booklet_no
                   AND rr.voided = 0
                   AND rr.used_by = 'old_student_payments'
                WHERE (
                    p.receipt_no LIKE ?
                    OR CONCAT(COALESCE(os.lastname,''), ' ', COALESCE(os.firstname,''), ' ', COALESCE(os.middlename,'')) LIKE ?
                )
                  AND (p.deleted_at IS NULL OR p.deleted_at = '')
                  AND COALESCE(NULLIF(TRIM(os.school_year), ''), ?) = ?
                  AND rr.receipt_no IS NOT NULL
                ORDER BY COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) DESC, p.id DESC
                LIMIT 20
            ";
            $oldStmt = $conn->prepare($oldReceiptSql);
            $oldStmt->bind_param('ssss', $receiptLike, $searchLike, $selectedSchoolYear, $selectedSchoolYear);
        }
        $oldStmt->execute();
        $oldResult = $oldStmt->get_result();
        while ($row = $oldResult->fetch_assoc()) {
            $receiptResults[] = [
                'source_type' => 'Old',
                'occurred_at' => $row['occurred_at'],
                'amount' => (float) $row['amount'],
                'booklet_label' => booklet_label_from_stored((int) $row['booklet_no']),
                'receipt_no' => (string) $row['receipt_no'],
                'fee_type' => $row['fee_type'],
                'payee_name' => $row['payee_name'] ?: 'Unknown Old Student',
                'grade_level' => '-',
                'school_year_label' => $row['school_year_label'] ?: $selectedSchoolYear,
            ];
        }
        $oldStmt->close();

        usort($receiptResults, static function (array $a, array $b): int {
            return strtotime((string) $b['occurred_at']) <=> strtotime((string) $a['occurred_at']);
        });
        $summary['receipts'] = count($receiptResults);
    }
}

$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";
$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Global Search | School Admin and Finance Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --page-bg:#f2f6fb;
            --card-bg:#ffffff;
            --card-border:#d9e3ef;
            --brand-dark:#172941;
            --brand-mid:#315f86;
            --brand-soft:#edf6ff;
            --text-soft:#5f7186;
            --line-soft:#dbe7f4;
        }
        body { background:linear-gradient(180deg, #f8fbff 0%, var(--page-bg) 100%); font-family:'Segoe UI','Roboto','Arial',sans-serif; color:var(--brand-dark); }
        .navbar { background: var(--brand-dark)!important; }
        .navbar-brand,.navbar-nav .nav-link { color:#fff!important; }
        .dashboard-header { text-align:center; margin-top:28px; margin-bottom:18px; }
        .dashboard-header h1 { font-size:1.35rem; font-weight:800; color:var(--brand-dark); }
        .search-card,.summary-card,.result-card { background:var(--card-bg); border:1px solid var(--card-border); border-radius:18px; box-shadow:0 12px 28px rgba(23,41,65,0.07); }
        .search-card { padding:1.45rem; }
        .result-card { padding:0; overflow:hidden; }
        .result-head { display:flex; align-items:center; justify-content:space-between; gap:1rem; padding:1.1rem 1.25rem; border-bottom:1px solid var(--line-soft); background:#fbfdff; }
        .summary-card { padding:1rem 1.1rem; height:100%; display:flex; align-items:center; justify-content:space-between; gap:1rem; }
        .summary-label { font-size:.8rem; text-transform:uppercase; letter-spacing:.05em; color:var(--text-soft); }
        .summary-value { font-size:1.45rem; font-weight:800; color:var(--brand-dark); }
        .summary-icon { width:38px; height:38px; border-radius:12px; display:inline-flex; align-items:center; justify-content:center; background:var(--brand-soft); color:var(--brand-mid); }
        .section-title { font-size:1.08rem; font-weight:800; color:var(--brand-dark); margin-bottom:0; }
        .search-kicker { display:inline-flex; align-items:center; gap:.45rem; padding:.45rem .7rem; border:1px solid #d7eafe; border-radius:999px; color:var(--brand-mid); background:var(--brand-soft); font-size:.86rem; font-weight:700; margin-bottom:1rem; }
        .search-help { color:var(--text-soft); font-size:.92rem; line-height:1.45; margin-top:.55rem; }
        .form-control,.form-select { border-radius:12px; border-color:var(--line-soft); padding:.72rem .86rem; }
        .form-control:focus,.form-select:focus { border-color:#74a6ce; box-shadow:0 0 0 .2rem rgba(49,95,134,.14); }
        .btn { border-radius:12px; font-weight:700; }
        .result-card .table thead th { background:var(--brand-soft); color:var(--brand-dark); border-bottom:1px solid var(--card-border); }
        .result-card .table tbody tr:hover { background:#f8fbff; }
        .result-card .table th,.result-card .table td { padding:.9rem 1rem; }
        .badge-chip { display:inline-flex; align-items:center; gap:.4rem; border-radius:999px; padding:.35rem .75rem; background:#eef4fb; color:var(--brand-dark); font-weight:700; font-size:.82rem; }
        .empty-state { padding:2rem; text-align:center; color:var(--text-soft); }
        .empty-state i { display:block; font-size:1.8rem; color:#8aa6c0; margin-bottom:.75rem; }
        .action-stack { display:flex; flex-wrap:wrap; gap:.45rem; }
        @media (max-width: 767px) {
            .result-head { align-items:flex-start; flex-direction:column; }
            .summary-card { align-items:flex-start; }
            .result-card .table th,.result-card .table td { white-space:nowrap; }
        }
    </style>
</head>
<body>
<?php render_admin_nav('search'); ?>

<?php render_school_page_header($schoolName, null, 'Search students, old accounts, receipt numbers, and booklet numbers from one page.', 'dashboard-header', 'mb-2 rounded shadow-sm', 'text-muted mb-0'); ?>

<div class="container pb-5">
    <div class="search-card mb-4">
        <div class="search-kicker"><i class="fas fa-shield-halved"></i> Permission-aware search</div>
        <div class="section-title mb-1"><i class="fas fa-magnifying-glass me-2"></i>Global Search</div>
        <div class="search-help mb-3">Search by student name, LRN, receipt number, or booklet number. Use a specific school year to narrow current student and receipt results.</div>
        <form method="get" class="row g-3 align-items-end">
            <div class="col-md-5">
                <label class="form-label fw-semibold">Keyword</label>
                <input type="text" name="q" class="form-control" value="<?= gs_h($query) ?>" placeholder="Search by student name, LRN, receipt no, or booklet no">
            </div>
            <div class="col-md-3">
                <label class="form-label fw-semibold">Scope</label>
                <select name="scope" class="form-select">
                    <option value="all" <?= $scope === 'all' ? 'selected' : '' ?>>All Results</option>
                    <option value="students" <?= $scope === 'students' ? 'selected' : '' ?>>Students</option>
                    <option value="old" <?= $scope === 'old' ? 'selected' : '' ?>>Old Accounts</option>
                    <option value="receipts" <?= $scope === 'receipts' ? 'selected' : '' ?>>Receipts</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label fw-semibold">School Year</label>
                <select name="school_year" class="form-select">
                    <?php foreach ($schoolYearOptions as $option): ?>
                        <option value="<?= gs_h($option) ?>" <?= $selectedSchoolYear === $option ? 'selected' : '' ?>><?= gs_h($option) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2 d-grid">
                <button type="submit" class="btn btn-dark"><i class="fas fa-search me-1"></i> Search</button>
            </div>
            <?php if ($query !== ''): ?>
            <div class="col-12">
                <a href="global-search.php" class="btn btn-sm btn-outline-secondary"><i class="fas fa-rotate-left me-1"></i>Clear Search</a>
            </div>
            <?php endif; ?>
        </form>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-4"><div class="summary-card"><div><div class="summary-label">Students</div><div class="summary-value"><?= number_format($summary['students']) ?></div></div><span class="summary-icon"><i class="fas fa-user-graduate"></i></span></div></div>
        <div class="col-md-4"><div class="summary-card"><div><div class="summary-label">Old Accounts</div><div class="summary-value"><?= number_format($summary['old']) ?></div></div><span class="summary-icon"><i class="fas fa-box-archive"></i></span></div></div>
        <div class="col-md-4"><div class="summary-card"><div><div class="summary-label">Receipts</div><div class="summary-value"><?= number_format($summary['receipts']) ?></div></div><span class="summary-icon"><i class="fas fa-receipt"></i></span></div></div>
    </div>

    <?php if ($query === ''): ?>
        <div class="result-card"><div class="empty-state"><i class="fas fa-magnifying-glass"></i>Type a keyword to search across the system.</div></div>
    <?php else: ?>
        <?php if (($scope === 'all' || $scope === 'students') && $canViewStudents): ?>
            <div class="result-card mb-4">
                <div class="result-head">
                    <div class="section-title"><i class="fas fa-user-graduate me-2"></i>Students</div>
                    <span class="badge-chip"><?= number_format(count($studentResults)) ?> match(es)</span>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle mb-0">
                        <thead><tr><th>Name</th><th>Grade</th><th>LRN</th><th>School Year</th><th>Action</th></tr></thead>
                        <tbody>
                        <?php if ($studentResults): ?>
                            <?php foreach ($studentResults as $row): ?>
                                <tr>
                                    <td><?= gs_h(trim(($row['lastname'] ?? '') . ', ' . ($row['firstname'] ?? '') . ' ' . ($row['middlename'] ?? ''))) ?></td>
                                    <td><?= gs_h($row['grade'] ?: '-') ?></td>
                                    <td><?= gs_h($row['lrn'] ?: '-') ?></td>
                                    <td><?= gs_h($row['school_year_label'] ?: $selectedSchoolYear) ?></td>
                                    <td>
                                        <div class="action-stack">
                                            <a href="/school-admin-dashboard/modules/accounts/account-view.php?student_id=<?= (int) $row['id'] ?>&school_year=<?= urlencode((string) ($row['school_year_label'] ?: $selectedSchoolYear)) ?>" class="btn btn-sm btn-outline-primary">Open Account</a>
                                            <a href="/school-admin-dashboard/modules/students/student-view.php?id=<?= (int) $row['id'] ?>" class="btn btn-sm btn-outline-secondary">Student Profile</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="5" class="text-center text-muted py-4">No student matches found.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <?php if (($scope === 'all' || $scope === 'old') && $canViewOldAccounts): ?>
            <div class="result-card mb-4">
                <div class="result-head">
                    <div class="section-title"><i class="fas fa-box-archive me-2"></i>Old Accounts</div>
                    <span class="badge-chip"><?= number_format(count($oldResults)) ?> match(es)</span>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle mb-0">
                        <thead><tr><th>Name</th><th>Status</th><th>Contact</th><th>School Year</th><th>Action</th></tr></thead>
                        <tbody>
                        <?php if ($oldResults): ?>
                            <?php foreach ($oldResults as $row): ?>
                                <tr>
                                    <td><?= gs_h(trim(($row['lastname'] ?? '') . ', ' . ($row['firstname'] ?? '') . ' ' . ($row['middlename'] ?? ''))) ?></td>
                                    <td><?= gs_h($row['status'] ?: '-') ?></td>
                                    <td><?= gs_h($row['contact'] ?: '-') ?></td>
                                    <td><?= gs_h($row['school_year'] ?: $selectedSchoolYear) ?></td>
                                    <td><a href="/school-admin-dashboard/modules/old accounts/student-old-payment-history.php?id=<?= (int) $row['id'] ?>" class="btn btn-sm btn-outline-primary">Open History</a></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="5" class="text-center text-muted py-4">No old-account matches found.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <?php if (($scope === 'all' || $scope === 'receipts') && $canViewFinancial): ?>
            <div class="result-card">
                <div class="result-head">
                    <div class="section-title"><i class="fas fa-receipt me-2"></i>Receipts</div>
                    <span class="badge-chip"><?= number_format(count($receiptResults)) ?> match(es)</span>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle mb-0">
                        <thead><tr><th>Source</th><th>Date</th><th>Payee</th><th>Fee Type</th><th>Booklet / Receipt</th><th class="text-end">Amount</th></tr></thead>
                        <tbody>
                        <?php if ($receiptResults): ?>
                            <?php foreach ($receiptResults as $row): ?>
                                <tr>
                                    <td><span class="badge-chip"><?= gs_h($row['source_type']) ?></span></td>
                                    <td><?= gs_h(date('n/j/Y g:i A', strtotime((string) $row['occurred_at']))) ?></td>
                                    <td><?= gs_h($row['payee_name']) ?><div class="small text-muted"><?= gs_h($row['school_year_label']) ?></div></td>
                                    <td><?= gs_h($row['fee_type']) ?><div class="small text-muted"><?= gs_h($row['grade_level']) ?></div></td>
                                    <td><?= gs_h($row['booklet_label']) ?> / <?= gs_h($row['receipt_no']) ?></td>
                                    <td class="text-end fw-semibold"><?= gs_h(gs_money((float) $row['amount'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="6" class="text-center text-muted py-4">No receipt matches found.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
