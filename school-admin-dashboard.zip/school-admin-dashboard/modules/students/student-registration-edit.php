<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require '../../config/database.php';
require __DIR__ . '/../settings/settings-permissions-roles.php';
require __DIR__ . '/student-registration-helper.php';
include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');

$currentRole = $_SESSION['role'] ?? '';
$canEditRegistrations = hasPermission($currentRole, 'student_registration', 'approve');
if (!isset($_SESSION['loggedin']) || !$canEditRegistrations) {
    $blockedUser = $_SESSION['username'] ?? 'unknown';
    audit_log(
        $conn,
        $blockedUser,
        'Blocked student registration edit access',
        'Students',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing student_registration:approve permission',
        'SECURITY'
    );
    admin_session_forbidden();
}

registration_ensure_pending_table($conn);
$pendingId = (int) ($_GET['id'] ?? $_POST['pending_id'] ?? 0);
$pending = $pendingId > 0 ? registration_get_pending_by_id($conn, $pendingId) : null;
if (!$pending) {
    die('Pending registration not found.');
}

if (($pending['status'] ?? '') !== 'Pending') {
    die('Only pending registration requests can be edited.');
}

$grades = registration_get_grades();
$user = $_SESSION['username'] ?? 'unknown';
$error = '';
$success = '';
$csrfToken = registration_csrf_token();

$lastname = $pending['lastname'] ?? '';
$firstname = $pending['firstname'] ?? '';
$middlename = $pending['middlename'] ?? '';
$lrn = $pending['lrn'] ?? '';
$birthday = $pending['birthday'] ?? '';
$age = (string) ($pending['age'] ?? '');
$gender = $pending['gender'] ?? '';
$address = $pending['address'] ?? '';
$contact = $pending['contact'] ?? '';
$grade = $pending['grade'] ?? '';
$strand = $pending['strand'] ?? '';
$strandOptions = registration_get_strand_options();
$section = $pending['section'] ?? '';
$date_enrolled = $pending['date_enrolled'] ?? '';
$photo = $pending['photo'] ?? '';
$guardian_name = $pending['guardian_name'] ?? '';
$guardian_contact = $pending['guardian_contact'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!registration_verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request token. Please refresh the page and try again.';
    } else {
        $lastname = trim((string) ($_POST['lastname'] ?? ''));
        $firstname = trim((string) ($_POST['firstname'] ?? ''));
        $middlename = trim((string) ($_POST['middlename'] ?? ''));
        $lrn = trim((string) ($_POST['lrn'] ?? ''));
        $birthday = trim((string) ($_POST['birthday'] ?? ''));
        $age = trim((string) ($_POST['age'] ?? ''));
        $gender = trim((string) ($_POST['gender'] ?? ''));
        $address = trim((string) ($_POST['address'] ?? ''));
        $contact = trim((string) ($_POST['contact'] ?? ''));
        $grade = trim((string) ($_POST['grade'] ?? ''));
        $strand = trim((string) ($_POST['strand'] ?? ''));
        $section = trim((string) ($_POST['section'] ?? ''));
        $date_enrolled = trim((string) ($_POST['date_enrolled'] ?? ''));
        $guardian_name = trim((string) ($_POST['guardian_name'] ?? ''));
        $guardian_contact = trim((string) ($_POST['guardian_contact'] ?? ''));
        $newPhoto = $photo;

        if (isset($_FILES['photo']) && ($_FILES['photo']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            $upload = registration_upload_photo($_FILES['photo'], $grade, $lastname, $firstname, 'pending');
            if ($upload['error'] !== '') {
                $error = $upload['error'];
            } else {
                $newPhoto = $upload['path'];
            }
        }

        if ($error === '') {
            $result = registration_update_pending($conn, $pendingId, [
                'lastname' => $lastname,
                'firstname' => $firstname,
                'middlename' => $middlename,
                'lrn' => $lrn,
                'birthday' => $birthday,
                'age' => $age,
                'gender' => $gender,
                'address' => $address,
                'contact' => $contact,
                'grade' => $grade,
                'strand' => $strand,
                'section' => $section,
                'date_enrolled' => $date_enrolled,
                'photo' => $newPhoto,
                'guardian_name' => $guardian_name,
                'guardian_contact' => $guardian_contact,
            ]);

            if ($result['success']) {
                $photo = $newPhoto;
                $pending = $result['record'] ?? registration_get_pending_by_id($conn, $pendingId);
                $success = $result['message'];
                audit_log($conn, $user, 'Edited pending student registration', 'Students', 'Pending Request ID: ' . $pendingId . ' | Student: ' . $lastname . ', ' . $firstname . ' | LRN: ' . registration_normalize_lrn_value($lrn));
            } else {
                $error = $result['message'];
            }
        }
    }
}

$duplicate = registration_find_duplicate($conn, $lrn, $pendingId, (string) ($pending['school_year_label'] ?? ''));
$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Pending Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body { background: var(--main-bg); font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif; }
        .navbar { background: var(--navbar-bg) !important; }
        .navbar-brand, .navbar-nav .nav-link { color: #fff !important; }
        .dashboard-header { text-align: center; margin-top: 34px; margin-bottom: 18px; }
        .dashboard-header h1 { font-size: 1.3rem; color: var(--brand-dark); font-weight: 700; margin-bottom: 0; }
        .card { border-radius: 1rem; box-shadow: 0 2px 12px rgba(33,57,93,0.10); }
        .section-title { color: var(--brand-dark); font-weight: 700; font-size: 1.03rem; margin-bottom: 1rem; }
        .mini-note { font-size: 0.92rem; color: #6c757d; }
    </style>
</head>
<body>
<?php render_admin_nav('students', true); ?>

<div class="container pb-4">
    <div class="dashboard-header">
        <h1><?= htmlspecialchars($schoolName) ?></h1>
        <p class="text-muted mb-0">Review and complete this registration before approval.</p>
    </div>

    <div class="card p-4">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
            <div>
                <h2 class="mb-1"><i class="fas fa-user-pen text-primary me-2"></i>Edit Pending Registration</h2>
                <div class="text-muted">Pending Request ID: <?= (int) $pendingId ?> | Submitted <?= htmlspecialchars(date('F j, Y g:i A', strtotime((string) ($pending['submitted_at'] ?? 'now')))) ?></div>
                <div class="text-muted small">School Year: <?= htmlspecialchars((string) ($pending['school_year_label'] ?? 'Unassigned')) ?></div>
            </div>
            <div>
                <a href="/school-admin-dashboard/modules/students/student-registration-pending.php" class="btn btn-outline-secondary">
                    <i class="fas fa-list"></i> Back to Queue
                </a>
            </div>
        </div>

        <?php if ($error !== ''): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if ($success !== ''): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        <div class="alert alert-<?= $duplicate['has_duplicate'] ? 'danger' : 'success' ?>">
            <?= htmlspecialchars($duplicate['has_duplicate'] ? $duplicate['message'] : 'No duplicate LRN found for the current value.') ?>
        </div>

        <form method="post" enctype="multipart/form-data" class="row g-3">
            <input type="hidden" name="pending_id" value="<?= (int) $pendingId ?>">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">

            <div class="col-12"><div class="section-title">Student Record Information</div></div>
            <div class="col-md-4">
                <label class="form-label">Last Name</label>
                <input type="text" name="lastname" class="form-control" value="<?= htmlspecialchars($lastname) ?>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">First Name</label>
                <input type="text" name="firstname" class="form-control" value="<?= htmlspecialchars($firstname) ?>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Middle Name</label>
                <input type="text" name="middlename" class="form-control" value="<?= htmlspecialchars($middlename) ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">LRN (optional)</label>
                <input type="text" name="lrn" class="form-control" value="<?= htmlspecialchars($lrn) ?>" maxlength="12" inputmode="numeric">
            </div>
            <div class="col-md-4">
                <label class="form-label">Birthday</label>
                <input type="date" name="birthday" class="form-control" value="<?= htmlspecialchars($birthday) ?>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Age</label>
                <input type="number" name="age" class="form-control" value="<?= htmlspecialchars($age) ?>" required min="1">
            </div>
            <div class="col-md-4">
                <label class="form-label">Gender</label>
                <select name="gender" class="form-select" required>
                    <option value="">Select gender</option>
                    <option value="Male" <?= $gender === 'Male' ? 'selected' : '' ?>>Male</option>
                    <option value="Female" <?= $gender === 'Female' ? 'selected' : '' ?>>Female</option>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Contact</label>
                <input type="text" name="contact" class="form-control" value="<?= htmlspecialchars($contact) ?>" placeholder="09xx-xxx-xxxx" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Date Enrolled</label>
                <input type="date" name="date_enrolled" class="form-control" value="<?= htmlspecialchars($date_enrolled) ?>" required>
            </div>
            <div class="col-12">
                <label class="form-label">Address</label>
                <textarea name="address" class="form-control" rows="2" required><?= htmlspecialchars($address) ?></textarea>
            </div>

            <div class="col-12"><div class="section-title">Enrollment Details</div></div>
            <div class="col-md-6">
                <label class="form-label">Grade Level</label>
                <select name="grade" class="form-select" required>
                    <option value="">Select grade</option>
                    <?php foreach ($grades as $gradeOption): ?>
                        <option value="<?= htmlspecialchars($gradeOption) ?>" <?= $grade === $gradeOption ? 'selected' : '' ?>><?= htmlspecialchars($gradeOption) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label">Grade Section (optional)</label>
                <input type="text" name="section" class="form-control" value="<?= htmlspecialchars($section) ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label">Strand <span class="text-muted">(required for Grade 11 / 12)</span></label>
                <select name="strand" class="form-select">
                    <option value="">No strand</option>
                    <?php foreach ($strandOptions as $option): ?>
                        <option value="<?= htmlspecialchars($option) ?>" <?= $strand === $option ? 'selected' : '' ?>><?= htmlspecialchars($option) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-12"><div class="section-title">Guardian and Photo</div></div>
            <div class="col-md-6">
                <label class="form-label">Guardian Name</label>
                <input type="text" name="guardian_name" class="form-control" value="<?= htmlspecialchars($guardian_name) ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Guardian Contact (optional)</label>
                <input type="text" name="guardian_contact" class="form-control" value="<?= htmlspecialchars($guardian_contact) ?>" placeholder="09xx-xxx-xxxx">
            </div>
            <div class="col-12">
                <label class="form-label">Photo (optional)</label>
                <input type="file" name="photo" class="form-control" accept=".jpg,.jpeg,.png,.gif">
                <?php if ($photo !== ''): ?>
                    <div class="mt-3 d-flex align-items-center gap-3">
                        <img
                            src="<?= htmlspecialchars(student_photo_public_url((string) $photo)) ?>"
                            alt="Current student photo"
                            width="96"
                            height="96"
                            style="width:96px;height:96px;object-fit:cover;border-radius:10px;border:1px solid #dee2e6;"
                            onerror="this.onerror=null;this.src='/school-admin-dashboard/assets/img/default-profile.png';"
                        >
                        <div class="mini-note">Current photo on file. Upload a new file only if you need to replace it.</div>
                    </div>
                <?php else: ?>
                    <div class="mini-note mt-2">No photo uploaded yet.</div>
                <?php endif; ?>
            </div>

            <div class="col-12 d-flex flex-wrap gap-2 mt-3">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i>Save Pending Changes
                </button>
                <a href="/school-admin-dashboard/modules/students/student-registration-pending.php" class="btn btn-outline-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<?= admin_session_warning_script() ?>
</body>
</html>
<?php $conn->close(); ?>
