<?php

require_once __DIR__ . '/../settings/upload-storage-helper.php';
require_once __DIR__ . '/../../includes/schema-migration.php';

function student_requirement_document_allowed_extensions(): array {
    return ['pdf', 'jpg', 'jpeg', 'png'];
}

function student_requirement_document_allowed_mime_types(): array {
    return [
        'application/pdf',
        'image/jpeg',
        'image/png',
    ];
}

function student_requirement_document_upload_dir(mysqli $conn = null): string {
    if ($conn instanceof mysqli) {
        return requirement_document_base_dir($conn);
    }

    return upload_storage_default_values()['requirement_document_dir'];
}

function student_requirement_document_public_base_path(): string {
    return '/school-admin-dashboard/modules/students/student-requirement-file.php';
}

function student_requirement_document_normalize_filename(string $filename): string {
    $filename = trim($filename);
    $filename = preg_replace('/[^A-Za-z0-9._-]+/', '_', $filename);
    return trim((string) $filename, '._-');
}

function student_requirement_document_storage_name(int $studentId, string $requirementKey, string $originalName): string {
    $safeRequirementKey = preg_replace('/[^a-z0-9_]+/i', '_', $requirementKey);
    $safeRequirementKey = trim((string) $safeRequirementKey, '_');
    if ($safeRequirementKey === '') {
        $safeRequirementKey = 'requirement';
    }

    $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    $extension = $extension !== '' ? '.' . $extension : '';

    return sprintf(
        'student_%d_%s_%s_%s%s',
        $studentId,
        $safeRequirementKey,
        date('YmdHis'),
        upload_storage_random_token(8),
        $extension
    );
}

function student_requirement_documents_ensure_table(mysqli $conn): void {
    if (!schema_migration_mode_enabled()) {
        return;
    }
    $sql = "CREATE TABLE IF NOT EXISTS student_requirement_documents (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        requirement_key VARCHAR(64) NOT NULL,
        original_filename VARCHAR(255) NOT NULL,
        stored_filename VARCHAR(255) NOT NULL,
        file_path VARCHAR(255) NOT NULL,
        mime_type VARCHAR(120) NOT NULL,
        file_size_bytes BIGINT NOT NULL DEFAULT 0,
        note TEXT NULL,
        uploaded_by VARCHAR(120) NULL,
        uploaded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        KEY idx_requirement_documents_student (student_id),
        KEY idx_requirement_documents_key (requirement_key),
        KEY idx_requirement_documents_uploaded (uploaded_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    schema_migration_attempt($conn, $sql);
}

function student_requirement_documents_ensure_storage(mysqli $conn = null): void {
    $directory = student_requirement_document_upload_dir($conn);
    if (!is_dir($directory)) {
        @mkdir($directory, 0775, true);
    }
}

function student_requirement_documents_foundation_summary(mysqli $conn): array {
    student_requirements_ensure_table($conn);
    student_requirement_documents_ensure_table($conn);
    student_requirement_documents_ensure_storage($conn);

    $uploadDir = student_requirement_document_upload_dir($conn);
    $isReady = is_dir($uploadDir) && is_writable($uploadDir);

    return [
        'table_ready' => true,
        'storage_ready' => $isReady,
        'upload_dir' => $uploadDir,
        'public_base_path' => student_requirement_document_public_base_path(),
        'allowed_extensions' => student_requirement_document_allowed_extensions(),
        'allowed_mime_types' => student_requirement_document_allowed_mime_types(),
    ];
}

function student_requirement_documents_get_for_student(mysqli $conn, int $studentId): array {
    student_requirement_documents_ensure_table($conn);
    $rows = [];

    $stmt = $conn->prepare("
        SELECT id, requirement_key, original_filename, stored_filename, file_path, mime_type, file_size_bytes, note, uploaded_by, uploaded_at
        FROM student_requirement_documents
        WHERE student_id = ?
        ORDER BY uploaded_at DESC, id DESC
    ");
    if (!$stmt) {
        return $rows;
    }

    $stmt->bind_param('i', $studentId);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $key = (string) ($row['requirement_key'] ?? '');
        if ($key === '' || isset($rows[$key])) {
            continue;
        }
        $row['public_url'] = requirement_document_public_url((int) ($row['id'] ?? 0));
        $rows[$key] = $row;
    }
    $stmt->close();

    return $rows;
}

function student_requirement_document_human_size(int $bytes): string {
    if ($bytes <= 0) {
        return '0 B';
    }
    $units = ['B', 'KB', 'MB', 'GB'];
    $size = (float) $bytes;
    $unitIndex = 0;
    while ($size >= 1024 && $unitIndex < count($units) - 1) {
        $size /= 1024;
        $unitIndex++;
    }
    return number_format($size, $unitIndex === 0 ? 0 : 2) . ' ' . $units[$unitIndex];
}

function student_requirement_documents_summary(array $documents, int $totalRequirements): array {
    $uploadedCount = count($documents);
    return [
        'uploaded' => $uploadedCount,
        'missing' => max(0, $totalRequirements - $uploadedCount),
        'has_any' => $uploadedCount > 0,
        'coverage_label' => $totalRequirements > 0
            ? ($uploadedCount . '/' . $totalRequirements . ' with files')
            : 'No requirements configured',
    ];
}

function student_requirement_documents_summary_for_students(mysqli $conn, array $studentIds, int $totalRequirements): array {
    student_requirement_documents_ensure_table($conn);
    $summaries = [];
    foreach ($studentIds as $studentId) {
        $studentId = (int) $studentId;
        if ($studentId > 0) {
            $summaries[$studentId] = [
                'uploaded' => 0,
                'missing' => max(0, $totalRequirements),
                'has_any' => false,
                'coverage_label' => $totalRequirements > 0 ? ('0/' . $totalRequirements . ' with files') : 'No requirements configured',
            ];
        }
    }
    if (empty($summaries)) {
        return $summaries;
    }

    $safeIds = array_map('intval', array_keys($summaries));
    $idList = implode(',', $safeIds);
    $sql = "
        SELECT student_id, COUNT(DISTINCT requirement_key) AS uploaded_count
        FROM student_requirement_documents
        WHERE student_id IN ($idList)
        GROUP BY student_id
    ";
    $result = $conn->query($sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $studentId = (int) ($row['student_id'] ?? 0);
            $uploaded = (int) ($row['uploaded_count'] ?? 0);
            if (!isset($summaries[$studentId])) {
                continue;
            }
            $summaries[$studentId] = [
                'uploaded' => $uploaded,
                'missing' => max(0, $totalRequirements - $uploaded),
                'has_any' => $uploaded > 0,
                'coverage_label' => $totalRequirements > 0
                    ? ($uploaded . '/' . $totalRequirements . ' with files')
                    : 'No requirements configured',
            ];
        }
        $result->close();
    }

    return $summaries;
}

function student_requirement_documents_save_uploaded_files(mysqli $conn, int $studentId, array $files, string $uploadedBy, array $notes = []): array {
    student_requirements_ensure_table($conn);
    student_requirement_documents_ensure_storage($conn);
    $catalog = student_requirements_catalog($conn);
    $allowedExtensions = student_requirement_document_allowed_extensions();
    $allowedMimeTypes = student_requirement_document_allowed_mime_types();
    $saved = 0;
    $savedKeys = [];

    if (!isset($files['name']) || !is_array($files['name'])) {
        return ['saved' => 0, 'saved_keys' => []];
    }

    $stmt = $conn->prepare("
        INSERT INTO student_requirement_documents
        (student_id, requirement_key, original_filename, stored_filename, file_path, mime_type, file_size_bytes, note, uploaded_by, uploaded_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    if (!$stmt) {
        throw new RuntimeException('Could not prepare requirement document upload.');
    }

    foreach ($files['name'] as $key => $originalName) {
        if (!isset($catalog[$key])) {
            continue;
        }

        $originalName = trim((string) $originalName);
        $errorCode = (int) ($files['error'][$key] ?? UPLOAD_ERR_NO_FILE);
        if ($originalName === '' || $errorCode === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        if ($errorCode !== UPLOAD_ERR_OK) {
            $stmt->close();
            throw new RuntimeException('One or more requirement documents failed to upload.');
        }

        $tmpName = (string) ($files['tmp_name'][$key] ?? '');
        if ($tmpName === '' || !is_uploaded_file($tmpName)) {
            $stmt->close();
            throw new RuntimeException('Uploaded requirement document could not be verified.');
        }

        $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        if (!in_array($extension, $allowedExtensions, true)) {
            $stmt->close();
            throw new RuntimeException('Only PDF, JPG, JPEG, and PNG requirement documents are allowed.');
        }

        if ($extension === '' || upload_storage_is_dangerous_extension($extension)) {
            $stmt->close();
            throw new RuntimeException('This document file type is not allowed.');
        }

        $browserMimeType = (string) ($files['type'][$key] ?? '');
        if ($browserMimeType !== '' && !in_array($browserMimeType, $allowedMimeTypes, true)) {
            $stmt->close();
            throw new RuntimeException('Uploaded requirement document type is not allowed.');
        }

        $fileSize = (int) ($files['size'][$key] ?? 0);
        if ($fileSize <= 0 || $fileSize > requirement_document_max_bytes($conn)) {
            $stmt->close();
            $maxMb = requirement_document_storage_settings($conn)['requirement_document_max_mb'] ?? 10;
            throw new RuntimeException('Requirement documents must be between 1 byte and ' . (int) $maxMb . ' MB.');
        }

        $safeOriginalName = student_requirement_document_normalize_filename($originalName);
        if ($safeOriginalName === '') {
            $safeOriginalName = 'document.' . $extension;
        }

        $storedName = student_requirement_document_storage_name($studentId, (string) $key, $safeOriginalName);
        $relativePath = $storedName;
        $targetPath = rtrim(student_requirement_document_upload_dir($conn), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $storedName;

        if (!move_uploaded_file($tmpName, $targetPath)) {
            $stmt->close();
            throw new RuntimeException('Could not store one or more requirement documents.');
        }

        $mimeType = upload_storage_detect_mime_type($targetPath);
        if (!in_array($mimeType, $allowedMimeTypes, true)) {
            @unlink($targetPath);
            $stmt->close();
            throw new RuntimeException('Uploaded requirement document content is not allowed.');
        }

        if (in_array($extension, ['jpg', 'jpeg', 'png'], true) && !@getimagesize($targetPath)) {
            @unlink($targetPath);
            $stmt->close();
            throw new RuntimeException('Uploaded requirement image could not be verified as a readable image.');
        }

        $note = trim((string) ($notes[$key] ?? ''));
        $stmt->bind_param(
            'isssssiss',
            $studentId,
            $key,
            $safeOriginalName,
            $storedName,
            $relativePath,
            $mimeType,
            $fileSize,
            $note,
            $uploadedBy
        );
        if (!$stmt->execute()) {
            @unlink($targetPath);
            $stmt->close();
            throw new RuntimeException('Failed to save one or more requirement document records.');
        }

        $saved++;
        $savedKeys[] = $key;
    }

    $stmt->close();

    return [
        'saved' => $saved,
        'saved_keys' => $savedKeys,
    ];
}

function student_requirements_default_catalog_rows(): array {
    return [
        ['requirement_key' => 'birth_certificate', 'label' => 'Birth Certificate', 'sort_order' => 10, 'is_required' => 1, 'is_active' => 1],
        ['requirement_key' => 'report_card', 'label' => 'Report Card', 'sort_order' => 20, 'is_required' => 1, 'is_active' => 1],
        ['requirement_key' => 'good_moral', 'label' => 'Good Moral', 'sort_order' => 30, 'is_required' => 0, 'is_active' => 1],
        ['requirement_key' => 'form_137', 'label' => 'Form 137', 'sort_order' => 40, 'is_required' => 0, 'is_active' => 1],
        ['requirement_key' => 'form_138', 'label' => 'Form 138', 'sort_order' => 50, 'is_required' => 0, 'is_active' => 1],
        ['requirement_key' => 'id_photo', 'label' => 'ID Photo', 'sort_order' => 60, 'is_required' => 0, 'is_active' => 1],
        ['requirement_key' => 'lrn_follow_up', 'label' => 'LRN To Follow', 'sort_order' => 70, 'is_required' => 0, 'is_active' => 1],
    ];
}

function student_requirements_catalog(mysqli $conn = null, bool $includeInactive = false): array {
    $rows = $conn ? student_requirements_catalog_rows($conn, $includeInactive) : student_requirements_default_catalog_rows();
    $catalog = [];
    foreach ($rows as $row) {
        $catalog[(string) $row['requirement_key']] = (string) $row['label'];
    }

    return $catalog;
}

function student_requirements_catalog_rows(mysqli $conn, bool $includeInactive = false): array {
    student_requirements_ensure_settings_table($conn);
    $rows = [];
    $sql = "SELECT requirement_key, label, sort_order, is_required, is_active
        FROM requirement_settings";
    if (!$includeInactive) {
        $sql .= " WHERE is_active = 1";
    }
    $sql .= " ORDER BY sort_order ASC, label ASC";
    $result = $conn->query($sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $rows[] = [
                'requirement_key' => (string) ($row['requirement_key'] ?? ''),
                'label' => (string) ($row['label'] ?? ''),
                'sort_order' => (int) ($row['sort_order'] ?? 0),
                'is_required' => (int) ($row['is_required'] ?? 0),
                'is_active' => (int) ($row['is_active'] ?? 1),
            ];
        }
        $result->close();
    }

    return $rows;
}

function student_requirements_allowed_statuses(): array {
    return ['Missing', 'Submitted', 'To Follow'];
}

function student_requirements_ensure_settings_table(mysqli $conn): void {
    if (!schema_migration_mode_enabled()) {
        return;
    }
    $sql = "CREATE TABLE IF NOT EXISTS requirement_settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        requirement_key VARCHAR(64) NOT NULL,
        label VARCHAR(120) NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        is_required TINYINT(1) NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_requirement_key (requirement_key),
        KEY idx_requirement_sort (sort_order),
        KEY idx_requirement_active (is_active)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    schema_migration_attempt($conn, $sql);

    $existingKeys = [];
    $result = $conn->query("SELECT requirement_key FROM requirement_settings");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $existingKeys[] = (string) ($row['requirement_key'] ?? '');
        }
        $result->close();
    }

    $seedStmt = $conn->prepare(
        "INSERT INTO requirement_settings (requirement_key, label, sort_order, is_required, is_active)
         VALUES (?, ?, ?, ?, ?)"
    );
    if (!$seedStmt) {
        return;
    }

    foreach (student_requirements_default_catalog_rows() as $row) {
        if (in_array($row['requirement_key'], $existingKeys, true)) {
            continue;
        }
        $key = (string) $row['requirement_key'];
        $label = (string) $row['label'];
        $sortOrder = (int) $row['sort_order'];
        $isRequired = (int) $row['is_required'];
        $isActive = (int) $row['is_active'];
        $seedStmt->bind_param('ssiii', $key, $label, $sortOrder, $isRequired, $isActive);
        $seedStmt->execute();
    }
    $seedStmt->close();
}

function student_requirements_slugify_key(string $label): string {
    $key = strtolower(trim($label));
    $key = preg_replace('/[^a-z0-9]+/', '_', $key);
    $key = trim((string) $key, '_');
    if ($key === '') {
        $key = 'requirement_' . substr(md5((string) microtime(true)), 0, 8);
    }
    return substr($key, 0, 64);
}

function student_requirements_update_settings(mysqli $conn, array $rows): array {
    student_requirements_ensure_settings_table($conn);
    $updated = 0;
    $stmt = $conn->prepare(
        "UPDATE requirement_settings
         SET label = ?, sort_order = ?, is_required = ?, is_active = ?
         WHERE requirement_key = ?"
    );
    if (!$stmt) {
        throw new RuntimeException('Could not prepare requirement settings update.');
    }

    foreach ($rows as $row) {
        $key = trim((string) ($row['requirement_key'] ?? ''));
        if ($key === '') {
            continue;
        }
        $label = trim((string) ($row['label'] ?? ''));
        if ($label === '') {
            $label = ucwords(str_replace('_', ' ', $key));
        }
        $sortOrder = (int) ($row['sort_order'] ?? 0);
        $isRequired = !empty($row['is_required']) ? 1 : 0;
        $isActive = !empty($row['is_active']) ? 1 : 0;
        $stmt->bind_param('siiis', $label, $sortOrder, $isRequired, $isActive, $key);
        if ($stmt->execute()) {
            $updated++;
        }
    }
    $stmt->close();

    return ['updated' => $updated];
}

function student_requirements_add_setting(mysqli $conn, string $label, int $sortOrder = 0, bool $isRequired = false, bool $isActive = true): string {
    student_requirements_ensure_settings_table($conn);
    $label = trim($label);
    if ($label === '') {
        throw new RuntimeException('Requirement label is required.');
    }

    $baseKey = student_requirements_slugify_key($label);
    $key = $baseKey;
    $suffix = 1;
    while (true) {
        $stmtCheck = $conn->prepare("SELECT id FROM requirement_settings WHERE requirement_key = ? LIMIT 1");
        if (!$stmtCheck) {
            throw new RuntimeException('Could not validate requirement key.');
        }
        $stmtCheck->bind_param('s', $key);
        $stmtCheck->execute();
        $exists = $stmtCheck->get_result()->num_rows > 0;
        $stmtCheck->close();
        if (!$exists) {
            break;
        }
        $suffix++;
        $key = substr($baseKey, 0, max(1, 64 - strlen((string) $suffix) - 1)) . '_' . $suffix;
    }

    $stmt = $conn->prepare(
        "INSERT INTO requirement_settings (requirement_key, label, sort_order, is_required, is_active)
         VALUES (?, ?, ?, ?, ?)"
    );
    if (!$stmt) {
        throw new RuntimeException('Could not prepare new requirement insert.');
    }
    $requiredInt = $isRequired ? 1 : 0;
    $activeInt = $isActive ? 1 : 0;
    $stmt->bind_param('ssiii', $key, $label, $sortOrder, $requiredInt, $activeInt);
    if (!$stmt->execute()) {
        $stmt->close();
        throw new RuntimeException('Could not add requirement setting.');
    }
    $stmt->close();

    return $key;
}

function student_requirements_ensure_table(mysqli $conn): void {
    student_requirements_ensure_settings_table($conn);
    student_requirement_documents_ensure_table($conn);

    if (!schema_migration_mode_enabled()) {
        return;
    }

    $sql = "CREATE TABLE IF NOT EXISTS student_requirement_status (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        requirement_key VARCHAR(64) NOT NULL,
        status VARCHAR(32) NOT NULL DEFAULT 'Missing',
        note TEXT NULL,
        updated_by VARCHAR(120) NULL,
        checked_at DATETIME NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_student_requirement (student_id, requirement_key),
        KEY idx_student_requirement_student (student_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    schema_migration_attempt($conn, $sql);

    $existingColumns = [];
    $result = $conn->query("SHOW COLUMNS FROM student_requirement_status");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $existingColumns[] = (string) ($row['Field'] ?? '');
        }
        $result->close();
    }

    if (!in_array('note', $existingColumns, true)) {
        schema_migration_attempt($conn, "ALTER TABLE student_requirement_status ADD COLUMN note TEXT NULL AFTER status");
    }
    if (!in_array('updated_by', $existingColumns, true)) {
        schema_migration_attempt($conn, "ALTER TABLE student_requirement_status ADD COLUMN updated_by VARCHAR(120) NULL AFTER note");
    }
    if (!in_array('checked_at', $existingColumns, true)) {
        schema_migration_attempt($conn, "ALTER TABLE student_requirement_status ADD COLUMN checked_at DATETIME NULL AFTER updated_by");
    }

    $historySql = "CREATE TABLE IF NOT EXISTS student_requirement_activity (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        requirement_key VARCHAR(64) NOT NULL,
        old_status VARCHAR(32) NULL,
        new_status VARCHAR(32) NOT NULL,
        old_note TEXT NULL,
        new_note TEXT NULL,
        changed_by VARCHAR(120) NOT NULL,
        changed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY idx_student_requirement_activity_student (student_id),
        KEY idx_student_requirement_activity_changed (changed_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    schema_migration_attempt($conn, $historySql);
}

function student_requirements_get_for_student(mysqli $conn, int $studentId): array {
    student_requirements_ensure_table($conn);
    $catalog = student_requirements_catalog($conn);
    $requirements = [];
    foreach (array_keys($catalog) as $key) {
        $requirements[$key] = [
            'status' => 'Missing',
            'note' => '',
            'updated_by' => '',
            'checked_at' => '',
        ];
    }

    $stmt = $conn->prepare("SELECT requirement_key, status, note, updated_by, checked_at FROM student_requirement_status WHERE student_id = ?");
    if (!$stmt) {
        return $requirements;
    }
    $stmt->bind_param('i', $studentId);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $key = (string) ($row['requirement_key'] ?? '');
        $status = (string) ($row['status'] ?? 'Missing');
        if (isset($catalog[$key])) {
            $requirements[$key] = [
                'status' => in_array($status, student_requirements_allowed_statuses(), true) ? $status : 'Missing',
                'note' => trim((string) ($row['note'] ?? '')),
                'updated_by' => trim((string) ($row['updated_by'] ?? '')),
                'checked_at' => (string) ($row['checked_at'] ?? ''),
            ];
        }
    }
    $stmt->close();

    return $requirements;
}

function student_requirements_save_for_student(mysqli $conn, int $studentId, array $submittedRequirements, string $updatedBy): void {
    student_requirements_ensure_table($conn);
    $catalog = student_requirements_catalog($conn);
    $allowed = student_requirements_allowed_statuses();
    $existingRequirements = student_requirements_get_for_student($conn, $studentId);

    $stmt = $conn->prepare(
        "INSERT INTO student_requirement_status (student_id, requirement_key, status, note, updated_by, checked_at)
         VALUES (?, ?, ?, ?, ?, NOW())
         ON DUPLICATE KEY UPDATE status = VALUES(status), note = VALUES(note), updated_by = VALUES(updated_by), checked_at = NOW(), updated_at = CURRENT_TIMESTAMP"
    );
    if (!$stmt) {
        throw new RuntimeException('Could not prepare requirement save query.');
    }

    foreach ($catalog as $key => $_label) {
        $requirementRow = $submittedRequirements[$key] ?? [];
        $status = is_array($requirementRow) ? (string) ($requirementRow['status'] ?? 'Missing') : 'Missing';
        if (!in_array($status, $allowed, true)) {
            $status = 'Missing';
        }
        $note = is_array($requirementRow) ? trim((string) ($requirementRow['note'] ?? '')) : '';
        $existing = $existingRequirements[$key] ?? [
            'status' => 'Missing',
            'note' => '',
            'updated_by' => '',
            'checked_at' => '',
        ];
        $existingStatus = (string) ($existing['status'] ?? 'Missing');
        $existingNote = trim((string) ($existing['note'] ?? ''));

        if ($status === $existingStatus && $note === $existingNote) {
            continue;
        }

        $stmt->bind_param('issss', $studentId, $key, $status, $note, $updatedBy);
        if (!$stmt->execute()) {
            $stmt->close();
            throw new RuntimeException('Failed to save one or more requirement statuses.');
        }

        $historyStmt = $conn->prepare(
            "INSERT INTO student_requirement_activity
            (student_id, requirement_key, old_status, new_status, old_note, new_note, changed_by, changed_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())"
        );
        if ($historyStmt) {
            $historyStmt->bind_param(
                'issssss',
                $studentId,
                $key,
                $existingStatus,
                $status,
                $existingNote,
                $note,
                $updatedBy
            );
            $historyStmt->execute();
            $historyStmt->close();
        }
    }

    $stmt->close();
}

function student_requirement_activity_get_for_student(mysqli $conn, int $studentId, int $limit = 10): array {
    student_requirements_ensure_table($conn);
    $limit = max(1, min($limit, 50));
    $rows = [];

    $stmt = $conn->prepare(
        "SELECT requirement_key, old_status, new_status, old_note, new_note, changed_by, changed_at
         FROM student_requirement_activity
         WHERE student_id = ?
         ORDER BY changed_at DESC, id DESC
         LIMIT ?"
    );
    if (!$stmt) {
        return $rows;
    }

    $stmt->bind_param('ii', $studentId, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    $stmt->close();

    return $rows;
}

function student_requirements_completion_summary(array $statuses): array {
    $total = count($statuses);
    $submitted = 0;
    $toFollow = 0;
    foreach ($statuses as $row) {
        $status = is_array($row) ? (string) ($row['status'] ?? 'Missing') : (string) $row;
        if ($status === 'Submitted') {
            $submitted++;
        } elseif ($status === 'To Follow') {
            $toFollow++;
        }
    }

    return [
        'total' => $total,
        'submitted' => $submitted,
        'missing' => max(0, $total - $submitted - $toFollow),
        'to_follow' => $toFollow,
        'overall_status' => $submitted === $total && $total > 0
            ? 'Complete'
            : ($submitted > 0 || $toFollow > 0 ? 'For Follow-up' : 'Incomplete'),
    ];
}
