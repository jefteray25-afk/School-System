﻿<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/ui.php';
include '../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/../settings/section-management-helper.php';
require_once __DIR__ . '/../settings/upload-storage-helper.php';
require_once __DIR__ . '/student-registration-helper.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

// Use the centralized permissions system!
$currentRole = $_SESSION['role'] ?? '';
if (!hasPermission($currentRole, 'student_data', 'add')) {
    $blockedUser = $_SESSION['username'] ?? 'unknown';
    audit_log(
        $conn,
        $blockedUser,
        'Blocked student add access',
        'Students',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing student_data:add permission',
        'SECURITY'
    );
    admin_session_forbidden();
}

registration_ensure_pending_table($conn);
registration_ensure_student_strand_column($conn);
school_year_ensure_finance_columns($conn);
section_management_ensure_table($conn);
$active_school_year_label = school_year_get_active_label($conn);
$managedSectionsByGrade = section_management_get_sections_by_grade($conn, $active_school_year_label, true);

// Map grade string to numbers for DB queries and accounts
$grade_levels = [
    "Junior Kindergarten" => 101,
    "Senior Kindergarten" => 102,
    "Grade 1" => 1, "Grade 2" => 2, "Grade 3" => 3, "Grade 4" => 4, "Grade 5" => 5,
    "Grade 6" => 6, "Grade 7" => 7, "Grade 8" => 8, "Grade 9" => 9, "Grade 10" => 10,
    "Grade 11" => 11, "Grade 12" => 12
];

$grades = array_keys($grade_levels);
$strandOptions = registration_get_strand_options();

// Add section variable
$lastname = $firstname = $middlename = $lrn = $birthday = $age = $gender = $address = $contact = $grade = $strand = $section = $date_enrolled = $photo = "";
$guardian_name = $guardian_contact = "";
$school_year_label = $active_school_year_label;
$error = "";
$photoSettings = student_photo_storage_settings($conn);
$maxPhotoMb = (int) ($photoSettings['student_photo_max_mb'] ?? 2);
$csrfToken = registration_csrf_token();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!registration_verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = "Invalid request token. Please refresh the page and try again.";
    }

    $lastname = trim($_POST["lastname"] ?? "");
    $firstname = trim($_POST["firstname"] ?? "");
    $middlename = trim($_POST["middlename"] ?? "");
    $lrn = trim($_POST["lrn"] ?? "");
    $birthday = trim($_POST["birthday"] ?? "");
    $age = trim($_POST["age"] ?? "");
    $gender = trim($_POST["gender"] ?? "");
    $address = trim($_POST["address"] ?? "");
    $contact = trim($_POST["contact"] ?? "");
    $grade = trim($_POST["grade"] ?? "");
    $strand = trim($_POST["strand"] ?? "");
    $section = trim($_POST["section"] ?? "");
    $date_enrolled = trim($_POST["date_enrolled"] ?? "");
    $guardian_name = trim($_POST["guardian_name"] ?? "");
    $guardian_contact = trim($_POST["guardian_contact"] ?? "");
    $school_year_label = $active_school_year_label;
    $allowedSections = section_management_get_section_names($conn, $school_year_label, $grade, true);

    $contact_pattern = '/^09\d{2}-\d{3}-\d{4}$/';
    $guardian_contact_pattern = '/^09\d{2}-\d{3}-\d{4}$/';
    $contact_digits = preg_replace('/[^0-9]/', '', $contact);
    $guardian_contact_digits = preg_replace('/[^0-9]/', '', $guardian_contact);

    // --- Begin custom photo filename and folder logic ---
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] != UPLOAD_ERR_NO_FILE) {
        $photoUpload = student_photo_store_uploaded_file($conn, $_FILES['photo'], $grade, $lastname, $firstname);
        if (($photoUpload['error'] ?? '') !== '') {
            $error = (string) $photoUpload['error'];
        } else {
            $photo = (string) ($photoUpload['path'] ?? '');
        }
    }
    // --- End custom photo filename and folder logic ---

    $grade_level_num = isset($grade_levels[$grade]) ? $grade_levels[$grade] : 0;
    $is_senior_high = in_array($grade, ['Grade 11', 'Grade 12'], true);
    if (!$is_senior_high) {
        $strand = '';
    }

    // Validation
    if ($lrn !== "" && !preg_match('/^\d{12}$/', preg_replace('/\D/', '', $lrn))) {
        $error = "LRN must be exactly 12 digits if provided.";
    } elseif ($lrn !== "" && registration_find_duplicate($conn, $lrn, null, $active_school_year_label)['has_duplicate']) {
        $error = "This LRN already exists in the student or pending registration records.";
    } elseif ($is_senior_high && $strand === '') {
        $error = "Strand is required for Grade 11 and Grade 12 students.";
    } elseif ($is_senior_high && !in_array($strand, $strandOptions, true)) {
        $error = "Please select a valid strand for Grade 11 or Grade 12.";
    } elseif ($section !== '' && !in_array($section, $allowedSections, true)) {
        $error = "Selected section is not active for the chosen grade level. Please update it from Section Management.";
    } elseif (!preg_match($contact_pattern, $contact)) {
        $error = "Contact number format must be 09xx-xxx-xxxx (e.g. 0917-345-6789)";
    } elseif (
        $guardian_contact !== "" &&
        (strlen($guardian_contact_digits) !== 11 || !preg_match($guardian_contact_pattern, $guardian_contact))
    ) {
        $error = "Guardian contact number format must be 09xx-xxx-xxxx (e.g. 0917-345-6789) and exactly 11 digits.";
    } elseif (
        $lastname && $firstname && $birthday && $age &&
        $gender && $address && $contact && $grade && $date_enrolled && $guardian_name && !$error
    ) {
        $stmt = $conn->prepare("INSERT INTO students (lastname, firstname, middlename, lrn, birthday, age, gender, address, contact, grade, strand, section, date_enrolled, school_year_label, photo, guardian_name, guardian_contact) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssssssssssssss", $lastname, $firstname, $middlename, $lrn, $birthday, $age, $gender, $address, $contact, $grade, $strand, $section, $date_enrolled, $school_year_label, $photo, $guardian_name, $guardian_contact);
        try {
            $executed = $stmt->execute();
        } catch (Throwable $e) {
            $executed = false;
            $error = $e->getMessage() ?: "Error: Could not add student.";
        }
        if ($executed) {
            $student_id = $stmt->insert_id;
            $stmt->close();

            // --- Automatically create accounts for each fee based on grade ---
            $fees_stmt = $conn->prepare("SELECT at.name, f.amount, f.school_year_label FROM fee f JOIN account_types at ON f.fee_type_id = at.id WHERE f.grade_level = ? AND (f.school_year_label = ? OR f.school_year_label IS NULL OR TRIM(f.school_year_label) = '') ORDER BY CASE WHEN f.school_year_label = ? THEN 0 ELSE 1 END, at.priority ASC, at.name ASC");
            $fees_stmt->bind_param("iss", $grade_level_num, $school_year_label, $school_year_label);
            $fees_stmt->execute();
            $fees_stmt->bind_result($type, $balance, $feeSchoolYear);
            $fee_rows = [];
            while ($fees_stmt->fetch()) {
                if (!isset($fee_rows[$type])) {
                    $fee_rows[$type] = [
                        'type' => $type,
                        'balance' => $balance,
                        'school_year_label' => trim((string) $feeSchoolYear) !== '' ? $feeSchoolYear : $school_year_label,
                    ];
                }
            }
            $fees_stmt->close();
            $fee_rows = array_values($fee_rows);

            foreach ($fee_rows as $fee) {
                $existing_stmt = $conn->prepare("SELECT id FROM accounts WHERE student_id = ? AND type = ? AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ? LIMIT 1");
                $existing_stmt->bind_param("isss", $student_id, $fee['type'], $school_year_label, $school_year_label);
                $existing_stmt->execute();
                $existing_stmt->store_result();
                $account_exists = $existing_stmt->num_rows > 0;
                $existing_stmt->close();
                if ($account_exists) {
                    continue;
                }

                $notes = "Auto-created from fee setup";
                $studentDisplayName = trim($lastname . ', ' . $firstname . ' ' . $middlename);
                $stmt2 = $conn->prepare("INSERT INTO accounts (student_id, name, type, balance, notes, school_year_label) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt2->bind_param("issdss", $student_id, $studentDisplayName, $fee['type'], $fee['balance'], $notes, $school_year_label);
                $stmt2->execute();
                $stmt2->close();
            }

            // --- AUDIT LOGGING: Add Student ---
            require_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');
            $user = $_SESSION['username'] ?? 'unknown';
            $student_name = "$lastname, $firstname";
            $action = "Added student";
            $module = "Students";
            $details = "Student: $student_name | LRN: " . ($lrn !== '' ? $lrn : 'N/A') . " | School Year: " . ($school_year_label !== '' ? $school_year_label : 'Unassigned') . " | Role: " . ($_SESSION['role'] ?? 'unknown');
            audit_log($conn, $user, $action, $module, $details);

            header("Location: student-view.php?id=" . $student_id);
            exit();
        } else {
            if (!$error) $error = "Error: Could not add student.";
            $stmt->close();
        }
    } else {
        if (!$error) $error = "All fields are required except LRN, Middle Name, Grade Section, Guardian Contact, Photo, and Strand (only for Grade 11/12).";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Official Student | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <?php ui_css_link(); ?>
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body {
            background: var(--main-bg);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
            transition: background 0.6s;
        }
        body.dark-mode {
            --main-bg: #1b232d;
            --card-bg: #23395d;
            --navbar-bg: #161b22;
            color: #e6edf3;
        }
        .navbar {
            background: var(--navbar-bg) !important;
            transition: background 0.6s;
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.08em;
        }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .nav-link.active { border-bottom: 2px solid #517fa4; }
        .theme-toggle-btn {
            background: none;
            border: none;
            color: #fff;
            font-size: 1.45em;
            margin-left: 12px;
            cursor: pointer;
            transition: color 0.3s;
        }
        .dashboard-header {
            text-align: center;
            margin-top: 36px;
            margin-bottom: 18px;
        }
        .dashboard-header img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            margin-bottom: 6px;
        }
        .dashboard-header h1 {
            font-size: 1.3rem;
            color: var(--brand-dark);
            font-weight: 700;
            margin-bottom: 0;
            transition: color 0.6s;
        }
        .card {
            border-radius: 1rem;
            box-shadow: 0 2px 12px rgba(33,57,93,0.10);
            background: var(--card-bg);
            transition: background 0.6s, color 0.6s;
        }
        .card-header {
            font-weight: 600;
            font-size: 1.13em;
        }
        .dashboard-btn-bottom {
            position: fixed;
            left: 20px;
            bottom: 20px;
            z-index: 1000;
        }
        @media (max-width: 576px) {
            .dashboard-header img { width: 36px; height: 36px;}
            .dashboard-header { margin-top: 12px; margin-bottom: 12px;}
            .card { padding: 8px; }
            .dashboard-btn-bottom { left: 10px; bottom: 10px; font-size: 0.92em;}
        }
        /* View Wave 6: legacy detail polish */
        :root {
            --vw-page-bg:#eef3f9;
            --vw-card-bg:#ffffff;
            --vw-card-border:#d9e3ef;
            --vw-brand-dark:#23395d;
            --vw-brand-mid:#517fa4;
            --vw-text-soft:#5f7186;
        }
        body {
            background:
                radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 30%),
                linear-gradient(180deg, #f8fbff 0%, var(--vw-page-bg) 100%);
            color: var(--vw-brand-dark);
        }
        .dashboard-header img {
            width:72px;
            height:72px;
            border-radius:18px;
            background:#fff;
            padding:6px;
            box-shadow:0 10px 25px rgba(35,57,93,0.12);
        }
        .dashboard-header h1 { font-weight:800; }
        .card {
            border:1px solid var(--vw-card-border);
            border-radius:20px;
            box-shadow:0 14px 32px rgba(35,57,93,0.07);
        }
        .card-header {
            background:linear-gradient(135deg, var(--vw-brand-dark), var(--vw-brand-mid)) !important;
            border:0;
            font-weight:700;
        }
        .card-body {
            background:#fbfdff;
        }
        .form-control, .form-select {
            border-color:#d7e1ed;
            min-height:44px;
            box-shadow:none;
        }
    </style>
</head>
<body>
<?php render_admin_nav('students', true); ?>
<!-- Header -->
<div class="dashboard-header">
    <img src="/school-admin-dashboard/uploads/logo1.png" alt="School Logo" class="mb-2 rounded shadow-sm">
    <h1>The Lord's Wisdom Academy Of Caloocan Inc.</h1>
</div>
<div class="container mt-4">
    <div class="card">
        <div class="card-header bg-primary text-light">
            <i class="fas fa-user-plus"></i> Official Student Registration
        </div>
        <div class="card-body">
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="post" action="" autocomplete="off" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Last Name:</label>
                        <input type="text" class="form-control" name="lastname" value="<?= htmlspecialchars($lastname) ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">First Name:</label>
                        <input type="text" class="form-control" name="firstname" value="<?= htmlspecialchars($firstname) ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Middle Name <span class="text-muted">(optional)</span>:</label>
                        <input type="text" class="form-control" name="middlename" value="<?= htmlspecialchars($middlename) ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">LRN <span class="text-muted">(optional, 12 digits if available)</span>:</label>
                        <input type="text" class="form-control" name="lrn" value="<?= htmlspecialchars($lrn) ?>" maxlength="12">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Birthday:</label>
                        <input type="date" class="form-control" name="birthday" id="birthday" value="<?= htmlspecialchars($birthday) ?>" required onchange="calcAge()">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Age:</label>
                        <input type="text" class="form-control" name="age" id="age" value="<?= htmlspecialchars($age) ?>" readonly required>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Gender:</label>
                        <select class="form-select" name="gender" required>
                            <option value="">Select</option>
                            <option value="Male" <?= $gender=="Male"?"selected":"" ?>>Male</option>
                            <option value="Female" <?= $gender=="Female"?"selected":"" ?>>Female</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Address:</label>
                        <input type="text" class="form-control" name="address" value="<?= htmlspecialchars($address) ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Grade Section <span class="text-muted">(optional)</span>:</label>
                        <select class="form-select" name="section" id="sectionField" data-current-section="<?= htmlspecialchars($section) ?>">
                            <option value="">No section yet</option>
                        </select>
                        <small class="text-muted" id="sectionHelpText">Select a section after choosing a grade level.</small>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">
                            Contact Number <span class="text-muted">(format: 09xx-xxx-xxxx)</span>:
                        </label>
                        <input type="text" class="form-control" name="contact" id="contactField" value="<?= htmlspecialchars($contact) ?>" placeholder="e.g. 0917-345-6789" maxlength="13" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Grade Level:</label>
                        <select class="form-select" name="grade" id="gradeField" required>
                            <option value="">Select Grade</option>
                            <?php foreach ($grades as $g): ?>
                                <option value="<?= htmlspecialchars($g) ?>" <?= $grade==$g?"selected":"" ?>><?= htmlspecialchars($g) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Date Enrolled:</label>
                        <input type="date" class="form-control" name="date_enrolled" value="<?= htmlspecialchars($date_enrolled) ?>" required>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Strand:</label>
                        <select class="form-select" name="strand" id="strandField" data-current-strand="<?= htmlspecialchars($strand) ?>">
                            <option value="">Select Strand</option>
                            <?php foreach ($strandOptions as $option): ?>
                                <option value="<?= htmlspecialchars($option) ?>" <?= $strand === $option ? "selected" : "" ?>><?= htmlspecialchars($option) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <small class="text-muted" id="strandHelpText">Required for Grade 11 or Grade 12 only.</small>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Guardian Name:</label>
                        <input type="text" class="form-control" name="guardian_name" value="<?= htmlspecialchars($guardian_name) ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">
                            Guardian Contact <span class="text-muted">(format: 09xx-xxx-xxxx, optional)</span>:
                        </label>
                        <input type="text" class="form-control" name="guardian_contact" id="guardian_contact" value="<?= htmlspecialchars($guardian_contact) ?>" placeholder="e.g. 0917-345-6789" maxlength="13">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Photo (max <?= $maxPhotoMb ?>MB):</label>
                    <input type="file" class="form-control" name="photo" accept="image/*">
                </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Add Student</button>
                    <a href="student-list.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>
<footer class="text-center py-4 text-muted small">
    &copy; <?= date("Y") ?> The Lord's Wisdom Academy Of Caloocan Inc. | School Admin Dashboard
</footer>
<!-- Dashboard Button (points to /school-admin-dashboard/Dashboard.php) -->
<a href="/school-admin-dashboard/Dashboard.php" class="btn btn-dark dashboard-btn-bottom">
    <i class="fas fa-tachometer-alt"></i> Dashboard
</a>
<script>
const managedSectionsByGrade = <?= json_encode($managedSectionsByGrade, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;

function calcAge() {
    var bday = document.getElementById("birthday").value;
    if (bday) {
        var birth = new Date(bday);
        var today = new Date();
        var age = today.getFullYear() - birth.getFullYear();
        var m = today.getMonth() - birth.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
            age--;
        }
        document.getElementById("age").value = age;
    } else {
        document.getElementById("age").value = '';
    }
}

// Contact input mask and validation
document.addEventListener('DOMContentLoaded', function() {
    const contactInput = document.getElementById('contactField');
    const guardianContactInput = document.getElementById('guardian_contact');
    const gradeField = document.getElementById('gradeField');
    const sectionField = document.getElementById('sectionField');
    const sectionHelpText = document.getElementById('sectionHelpText');
    const strandField = document.getElementById('strandField');
    const strandHelpText = document.getElementById('strandHelpText');
    const seniorHighGrades = ['Grade 11', 'Grade 12'];

    function renderSectionOptions() {
        const selectedGrade = gradeField ? gradeField.value : '';
        const currentSection = sectionField ? (sectionField.dataset.currentSection || '') : '';
        const options = managedSectionsByGrade[selectedGrade] || [];

        if (!sectionField) {
            return;
        }

        sectionField.innerHTML = '';
        const emptyOption = document.createElement('option');
        emptyOption.value = '';
        emptyOption.textContent = 'No section yet';
        sectionField.appendChild(emptyOption);

        options.forEach((sectionName) => {
            const option = document.createElement('option');
            option.value = sectionName;
            option.textContent = sectionName;
            sectionField.appendChild(option);
        });

        if (currentSection && !options.includes(currentSection)) {
            const legacyOption = document.createElement('option');
            legacyOption.value = currentSection;
            legacyOption.textContent = currentSection + ' (saved value)';
            sectionField.appendChild(legacyOption);
        }

        sectionField.value = currentSection;
        if (sectionHelpText) {
            sectionHelpText.textContent = options.length > 0
                ? 'Only active sections for the selected grade level are shown here.'
                : 'No managed sections yet for this grade level. Leave this blank or add one in Settings.';
        }
    }

    function updateStrandState() {
        if (!strandField) {
            return;
        }
        const selectedGrade = gradeField ? gradeField.value : '';
        const isSeniorHigh = seniorHighGrades.includes(selectedGrade);

        strandField.disabled = !isSeniorHigh;
        if (isSeniorHigh) {
            if (strandField.dataset.currentStrand) {
                strandField.value = strandField.dataset.currentStrand;
            }
            if (strandHelpText) {
                strandHelpText.textContent = 'Select the strand for Grade 11 or Grade 12 students.';
            }
        } else {
            strandField.value = '';
            if (strandHelpText) {
                strandHelpText.textContent = 'Strand is only required for Grade 11 or Grade 12.';
            }
        }
    }

    if (contactInput) {
        contactInput.addEventListener('input', function(e) {
            let digits = contactInput.value.replace(/\D/g, '');
            if (digits.length > 11) digits = digits.slice(0, 11);
            let formatted = '';
            if (digits.length > 0) {
                formatted += digits.substring(0, 4); // 09xx
            }
            if (digits.length > 4) {
                formatted += '-' + digits.substring(4, 7); // xxx
            }
            if (digits.length > 7) {
                formatted += '-' + digits.substring(7, 11); // xxxx
            }
            contactInput.value = formatted;
        });
        contactInput.addEventListener('keypress', function(e) {
            if (!/[0-9]/.test(e.key) && !['Backspace', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(e.key)) {
                e.preventDefault();
            }
        });
    }
    if (guardianContactInput) {
        guardianContactInput.addEventListener('input', function(e) {
            let digits = guardianContactInput.value.replace(/\D/g, '');
            if (digits.length > 11) digits = digits.slice(0, 11);
            let formatted = '';
            if (digits.length > 0) {
                formatted += digits.substring(0, 4); // 09xx
            }
            if (digits.length > 4) {
                formatted += '-' + digits.substring(4, 7); // xxx
            }
            if (digits.length > 7) {
                formatted += '-' + digits.substring(7, 11); // xxxx
            }
            guardianContactInput.value = formatted;
        });
        guardianContactInput.addEventListener('keypress', function(e) {
            if (!/[0-9]/.test(e.key) && !['Backspace', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(e.key)) {
                e.preventDefault();
            }
        });
    }
    // Theme toggle
    const btn = document.getElementById('themeToggleBtn');
    if (btn) {
        btn.addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');
            this.querySelector('i').classList.toggle('fa-moon');
            this.querySelector('i').classList.toggle('fa-sun');
        });
    }
    renderSectionOptions();
    updateStrandState();
    if (gradeField) {
        gradeField.addEventListener('change', function() {
            if (sectionField) {
                sectionField.dataset.currentSection = '';
            }
            if (strandField) {
                strandField.dataset.currentStrand = '';
            }
            renderSectionOptions();
            updateStrandState();
        });
    }
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<?= admin_session_warning_script() ?>
</body>
</html>
<?php $conn->close(); ?>

