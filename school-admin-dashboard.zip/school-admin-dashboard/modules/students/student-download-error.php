<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require '../../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Only Super Administrator allowed
if ($_SESSION['role'] !== 'Super Administrator') {
    die("You are not authorized to access this page.");
}

if (!hash_equals($_SESSION['student_import_csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
    die('Invalid request token.');
}

if (!empty($_SESSION['import_error_rows'])) {
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();
    $sheet->setTitle('Import Errors');
    $sheet->setCellValue('A1', 'Row Number');
    $sheet->setCellValue('B1', 'Reason');
    $sheet->setCellValue('C1', 'Last Name');
    $sheet->setCellValue('D1', 'First Name');
    $sheet->setCellValue('E1', 'Middle Name');
    $sheet->setCellValue('F1', 'LRN');
    $sheet->setCellValue('G1', 'Section');
    $sheet->setCellValue('H1', 'Birthday');
    $sheet->setCellValue('I1', 'Gender');
    $sheet->setCellValue('J1', 'Address');
    $sheet->setCellValue('K1', 'Contact Number');
    $sheet->setCellValue('L1', 'Date Enrolled');
    $sheet->setCellValue('M1', 'Guardian Name');
    $sheet->setCellValue('N1', 'Guardian Contact');

    $rowNum = 2;
    foreach ($_SESSION['import_error_rows'] as $error) {
        $sheet->setCellValue('A'.$rowNum, $error['row_number']);
        $sheet->setCellValue('B'.$rowNum, $error['reason']);
        $sheet->setCellValue('C'.$rowNum, $error['data'][0]);
        $sheet->setCellValue('D'.$rowNum, $error['data'][1]);
        $sheet->setCellValue('E'.$rowNum, $error['data'][2]);
        $sheet->setCellValue('F'.$rowNum, $error['data'][3]);
        $sheet->setCellValue('G'.$rowNum, $error['data'][4] ?? '');
        $sheet->setCellValue('H'.$rowNum, $error['data'][5] ?? '');
        $sheet->setCellValue('I'.$rowNum, $error['data'][6] ?? '');
        $sheet->setCellValue('J'.$rowNum, $error['data'][7] ?? '');
        $sheet->setCellValue('K'.$rowNum, $error['data'][8] ?? '');
        $sheet->setCellValue('L'.$rowNum, $error['data'][9] ?? '');
        $sheet->setCellValue('M'.$rowNum, $error['data'][10] ?? '');
        $sheet->setCellValue('N'.$rowNum, $error['data'][11] ?? '');
        $rowNum++;
    }
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="student_import_error_report.xlsx"');
    header('Cache-Control: max-age=0');
    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;
} else {
    echo "<h2>No error rows to download.</h2>";
}
?>
