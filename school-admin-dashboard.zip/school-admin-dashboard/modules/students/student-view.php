<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
include '../../config/database.php';
include __DIR__ . '/../settings/settings-permissions-roles.php';
include __DIR__ . '/../settings/upload-storage-helper.php';
include __DIR__ . '/student-registration-helper.php';

// Determine current role and permissions
$currentRole = $_SESSION['role'] ?? '';
$can_edit = hasPermission($currentRole, 'student_data', 'edit');
$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";
registration_ensure_student_strand_column($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Record | School Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body {
            background: var(--main-bg);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
            font-size: 1.09rem;
            color: var(--brand-dark);
            transition: background 0.6s;
        }
        body.dark-mode {
            --main-bg: #1b232d;
            --card-bg: #23395d;
            --navbar-bg: #161b22;
            color: #e6edf3;
        }
        .navbar {
            background: var(--navbar-bg) !important;
            transition: background 0.6s;
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.08em;
        }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .nav-link.active { border-bottom: 2px solid #517fa4; }
        .theme-toggle-btn {
            background: none;
            border: none;
            color: #fff;
            font-size: 1.45em;
            margin-left: 12px;
            cursor: pointer;
            transition: color 0.3s;
        }
        .dashboard-header {
            text-align: center;
            margin-top: 36px;
            margin-bottom: 18px;
        }
        .dashboard-header img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            margin-bottom: 6px;
        }
        .dashboard-header h1 {
            font-size: 1.3rem;
            color: var(--brand-dark);
            font-weight: 700;
            margin-bottom: 0;
            transition: color 0.6s;
        }
        .main-content-centered {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .student-info-card {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            box-shadow: 0 4px 24px rgba(33,57,93,0.10), 0 1.5px 3px rgba(33,57,93,0.07);
            border-radius: 1rem;
            overflow: hidden;
            background: var(--card-bg);
            transition: background 0.6s, color 0.6s;
        }
        .student-header {
            background: linear-gradient(90deg,#517fa4 0,#23395d 100%);
            color: #fff;
            padding: 32px 28px 24px 28px;
            text-align: center;
        }
        .student-header h3 {
            font-family: 'Segoe UI Semibold', 'Roboto', 'Arial', sans-serif;
            font-size: 2.15rem;
            letter-spacing: 1px;
        }
        .student-photo-lg {
            max-width: 320px;
            max-height: 320px;
            width: 320px;
            height: 320px;
            object-fit: cover;
            border-radius: 16px;
            border: 4px solid #dee2e6;
            background: #f8f9fa;
            margin-bottom: 18px;
            box-shadow: 0 2px 14px rgba(33,57,93,0.15);
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
        .student-photo-placeholder {
            width: 320px;
            height: 320px;
            border-radius: 16px;
            background: #6c757d;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 110px;
            margin-bottom: 18px;
            box-shadow: 0 2px 14px rgba(33,57,93,0.15);
            margin-left: auto;
            margin-right: auto;
        }
        .student-info-table th {
            width: 200px;
            color: var(--brand-dark);
            font-weight: 600;
            background: #f5f7fc;
            border-right: 1px solid #eee;
            font-size: 1.09rem;
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        }
        .student-info-table td {
            background: #f8fafc;
            color: var(--brand-dark);
            font-size: 1.09rem;
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        }
        .student-btn-group {
            display: flex;
            justify-content: center;
            gap: 14px;
            margin-top: 24px;
            margin-bottom: 6px;
        }
        .dashboard-btn-bottom {
            position: fixed;
            left: 22px;
            bottom: 22px;
            z-index: 1000;
        }
        @media (max-width: 1400px) {
            .student-info-card { max-width: 98vw; }
        }
        @media (max-width: 900px) {
            .student-info-card { max-width: 99vw; }
        }
        @media (max-width: 576px) {
            .dashboard-header { margin-top: 10px; margin-bottom: 10px;}
            .student-header { padding: 16px 10px 14px 10px; }
            .student-header h3 { font-size: 1.22rem; }
            .student-photo-lg, .student-photo-placeholder { width: 160px; height: 160px; font-size: 54px; }
            .student-btn-group { gap: 8px; flex-direction: column; align-items: stretch; }
            .dashboard-btn-bottom { left: 10px; bottom: 10px; font-size: 0.92em;}
            .student-info-table th { font-size: 1.01rem; }
            .student-info-table td { font-size: 1.01rem; }
        }
        /* View Wave 5: detail view alignment */
        :root {
            --vw-page-bg: #eef3f9;
            --vw-card-bg: #ffffff;
            --vw-card-border: #d9e3ef;
            --vw-brand-dark: #23395d;
            --vw-brand-mid: #517fa4;
            --vw-brand-soft: #edf4fb;
            --vw-text-soft: #5f7186;
        }
        body {
            background:
                radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 30%),
                linear-gradient(180deg, #f8fbff 0%, var(--vw-page-bg) 100%);
            color: var(--vw-brand-dark);
        }
        .dashboard-header {
            margin-top: 32px;
            margin-bottom: 18px;
        }
        .dashboard-header img {
            width: 72px;
            height: 72px;
            border-radius: 18px;
            background: #fff;
            padding: 6px;
            box-shadow: 0 10px 25px rgba(35,57,93,0.12);
        }
        .dashboard-header h1 {
            font-weight: 800;
        }
        .student-info-card {
            background: var(--vw-card-bg);
            border: 1px solid var(--vw-card-border);
            border-radius: 20px;
            box-shadow: 0 14px 32px rgba(35,57,93,0.07);
        }
        .student-header {
            background: linear-gradient(135deg, var(--vw-brand-dark), var(--vw-brand-mid));
            padding: 28px 24px 22px 24px;
        }
        .student-header h3 {
            font-size: 1.95rem;
            font-weight: 800;
        }
        .student-info-table th {
            background: var(--vw-brand-soft);
            border-right: 1px solid var(--vw-card-border);
            font-weight: 700;
        }
        .student-info-table td {
            background: #fbfdff;
        }
        .student-btn-group .btn {
            border-radius: 12px;
            font-weight: 700;
        }
    </style>
</head>
<body>
<!-- Navbar -->
<?php render_admin_nav('students', true); ?>

<!-- Header -->
<?php render_school_page_header($schoolName); ?>

<div class="main-content-centered">
    <div class="student-info-card">
<?php
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = "";
if ($id > 0) {
    $sql = "SELECT id, lastname, firstname, middlename, lrn, birthday, age, gender, address, contact, grade, strand, section, date_enrolled, photo, guardian_name, guardian_contact
            FROM students
            WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($student_id, $lastname, $firstname, $middlename, $lrn, $birthday, $age, $gender, $address, $contact, $grade, $strand, $section, $date_enrolled, $photo, $guardian_name, $guardian_contact);
    if (!$stmt->fetch()) {
        $error = "Student not found.";
    }
    $stmt->close();
} else {
    $error = "Invalid student ID.";
}
?>
    <div class="student-header">
        <div class="text-uppercase small fw-bold mb-2" style="letter-spacing:.08em; opacity:.85;">Student Profile</div>
        <div>
                    <?php if ($photo): ?>
                        <img src="<?= htmlspecialchars(student_photo_public_url((string) $photo)) ?>" alt="Photo" class="student-photo-lg">
            <?php else: ?>
                <div class="student-photo-placeholder">
                    <i class="fas fa-user"></i>
                </div>
            <?php endif; ?>
        </div>
        <h3 class="mb-1">
            <?php if (!$error): ?>
                <?= htmlspecialchars($lastname . ', ' . $firstname . ' ' . $middlename) ?>
            <?php else: ?>
                Student Record
            <?php endif; ?>
        </h3>
        <?php if (!$error): ?>
            <span class="badge bg-info fs-6 px-3 py-1"><i class="fas fa-layer-group"></i> Grade: <?= htmlspecialchars($grade) ?></span>
            <?php if (!empty($strand)): ?>
                <span class="badge bg-success fs-6 px-3 py-1"><i class="fas fa-tags"></i> Strand: <?= htmlspecialchars($strand) ?></span>
            <?php endif; ?>
            <span class="badge bg-secondary fs-6 px-3 py-1"><i class="fas fa-clipboard-list"></i> Section: <?= htmlspecialchars($section) ?></span>
        <?php endif; ?>
    </div>
    <div class="p-4">
        <?php if ($error): ?>
            <div class="alert alert-danger text-center"><?= htmlspecialchars($error) ?></div>
        <?php else: ?>
            <div class="row justify-content-center">
                <div class="col-12 col-md-8 col-lg-10">
                    <table class="table table-bordered student-info-table mb-2 w-100">
                        <tr>
                            <th>Name</th>
                            <td><?= htmlspecialchars($lastname . ', ' . $firstname . ' ' . $middlename) ?></td>
                        </tr>
                        <tr>
                            <th>LRN</th>
                            <td><?= htmlspecialchars($lrn) ?></td>
                        </tr>
                        <tr>
                            <th>Birthday</th>
                            <td>
                                <?php
                                if (!empty($birthday)) {
                                    $d = date_create($birthday);
                                    echo htmlspecialchars(date_format($d, 'm-d-Y'));
                                } else {
                                    echo '<span class="text-muted"><i>Not set</i></span>';
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Age</th>
                            <td><?= htmlspecialchars($age) ?></td>
                        </tr>
                        <tr>
                            <th>Gender</th>
                            <td><?= htmlspecialchars($gender) ?></td>
                        </tr>
                        <tr>
                            <th>Address</th>
                            <td><?= htmlspecialchars($address) ?></td>
                        </tr>
                        <tr>
                            <th>Contact Number</th>
                            <td><?= htmlspecialchars($contact) ?></td>
                        </tr>
                        <tr>
                            <th>Grade Level</th>
                            <td><?= htmlspecialchars($grade) ?></td>
                        </tr>
                        <tr>
                            <th>Strand</th>
                            <td>
                                <?php if (!empty($strand)): ?>
                                    <?= htmlspecialchars($strand) ?>
                                <?php else: ?>
                                    <span class="text-muted"><i>Not applicable</i></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Grade Section</th>
                            <td><?= htmlspecialchars($section) ?></td>
                        </tr>
                        <tr>
                            <th>Date Enrolled</th>
                            <td>
                                <?php if (!empty($date_enrolled)): ?>
                                    <?= htmlspecialchars(date('F j, Y', strtotime($date_enrolled))) ?>
                                <?php else: ?>
                                    <span class="text-muted"><i>Not set</i></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Guardian Name</th>
                            <td><?= htmlspecialchars($guardian_name) ?></td>
                        </tr>
                        <tr>
                            <th>Guardian Contact Number</th>
                            <td><?= htmlspecialchars($guardian_contact) ?></td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="student-btn-group">
                <a href="student-list.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Student List</a>
                <a href="../accounts/account-list.php" class="btn btn-info"><i class="fas fa-arrow-left"></i> Back to Student Account</a>
                <?php if ($can_edit): ?>
                <a href="student-edit.php?id=<?= $student_id ?>" class="btn btn-primary"><i class="fas fa-edit"></i> Edit Student</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    </div>
</div>
<footer class="text-center py-4 text-muted small">
    &copy; <?= date("Y") ?> <?= $schoolName ?> | School Admin Dashboard
</footer>
<!-- Dashboard Button (points to /school-admin-dashboard/Dashboard.php) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Theme toggle
    document.getElementById('themeToggleBtn').addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        // Animate moon/sun icon
        this.querySelector('i').classList.toggle('fa-moon');
        this.querySelector('i').classList.toggle('fa-sun');
    });
</script>
</body>
</html>
<?php $conn->close(); ?>
