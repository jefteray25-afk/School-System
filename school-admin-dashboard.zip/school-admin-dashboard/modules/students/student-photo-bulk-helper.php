<?php

require_once __DIR__ . '/../../includes/schema-migration.php';
require_once __DIR__ . '/../settings/upload-storage-helper.php';
require_once __DIR__ . '/student-photo-matching-helper.php';

/**
 * Schema only for Wave 1. No page calls these tables yet and no student photo
 * record is changed until the future controlled Apply step.
 */
function student_photo_bulk_ensure_tables(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }

    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS student_photo_assignments (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        stored_relative_path VARCHAR(255) NOT NULL,
        original_filename VARCHAR(255) NOT NULL,
        normalized_filename_key VARCHAR(255) NOT NULL,
        source_type VARCHAR(30) NOT NULL DEFAULT 'bulk',
        match_status VARCHAR(30) NOT NULL DEFAULT 'matched',
        match_score DECIMAL(5,2) DEFAULT NULL,
        file_hash CHAR(64) DEFAULT NULL,
        assigned_by VARCHAR(100) DEFAULT NULL,
        assigned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        replaced_at DATETIME DEFAULT NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        notes TEXT DEFAULT NULL,
        INDEX idx_student_photo_assignment_student (student_id, is_active),
        INDEX idx_student_photo_assignment_hash (file_hash)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS student_photo_bulk_batches (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        batch_token CHAR(64) NOT NULL UNIQUE,
        school_year_label VARCHAR(50) NOT NULL,
        grade VARCHAR(50) NOT NULL,
        section VARCHAR(100) DEFAULT NULL,
        source_type VARCHAR(30) NOT NULL,
        status VARCHAR(30) NOT NULL DEFAULT 'staged',
        created_by VARCHAR(100) DEFAULT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        applied_at DATETIME DEFAULT NULL,
        INDEX idx_student_photo_batch_scope (school_year_label, grade, section, status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS student_photo_bulk_batch_items (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        batch_id BIGINT UNSIGNED NOT NULL,
        student_id INT DEFAULT NULL,
        staged_relative_path VARCHAR(255) DEFAULT NULL,
        original_filename VARCHAR(255) NOT NULL,
        normalized_filename_key VARCHAR(255) NOT NULL,
        file_hash CHAR(64) DEFAULT NULL,
        match_status VARCHAR(30) NOT NULL,
        match_score DECIMAL(5,2) DEFAULT NULL,
        is_selected TINYINT(1) NOT NULL DEFAULT 0,
        applied_at DATETIME DEFAULT NULL,
        notes TEXT DEFAULT NULL,
        INDEX idx_student_photo_batch_item_batch (batch_id),
        INDEX idx_student_photo_batch_item_student (student_id),
        CONSTRAINT fk_student_photo_batch_items_batch FOREIGN KEY (batch_id)
            REFERENCES student_photo_bulk_batches(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function student_photo_bulk_path_segment(string $value, string $fallback = 'unassigned'): string
{
    $value = strtolower(trim($value));
    $value = (string) preg_replace('/[^a-z0-9]+/i', '-', $value);
    $value = trim($value, '-');
    return $value !== '' ? $value : $fallback;
}

function student_photo_bulk_inbox_scope_dir(array $settings, string $schoolYear, string $grade, string $section = ''): string
{
    $baseDir = rtrim((string) ($settings['bulk_photo_inbox_dir'] ?? ''), '/\\');
    $gradeCode = student_photo_grade_code($grade);
    $parts = [
        $baseDir,
        student_photo_bulk_path_segment($schoolYear, 'school-year'),
        $gradeCode !== '' ? $gradeCode : 'grade',
    ];
    if (trim($section) !== '') {
        $parts[] = student_photo_bulk_path_segment($section, 'section');
    }

    return implode('/', $parts);
}

function student_photo_bulk_scan_scope(array $settings, string $schoolYear, string $grade, string $section = ''): array
{
    $directory = student_photo_bulk_inbox_scope_dir($settings, $schoolYear, $grade, $section);
    $result = ['directory' => $directory, 'files' => [], 'error' => ''];
    if (!is_dir($directory)) {
        $result['error'] = 'The selected inbox folder does not exist yet.';
        return $result;
    }
    if (!is_readable($directory)) {
        $result['error'] = 'The selected inbox folder is not readable by PHP.';
        return $result;
    }

    $maxBytes = max(1, (int) ($settings['bulk_photo_source_max_mb'] ?? 5)) * 1024 * 1024;
    $maxWidth = max(600, (int) ($settings['bulk_photo_source_max_width'] ?? 5000));
    $maxHeight = max(600, (int) ($settings['bulk_photo_source_max_height'] ?? 5000));
    $allowedExtensions = ['jpg', 'jpeg', 'png'];

    foreach (scandir($directory) ?: [] as $filename) {
        if ($filename === '.' || $filename === '..') {
            continue;
        }
        $absolutePath = $directory . '/' . $filename;
        if (!is_file($absolutePath)) {
            continue;
        }

        $extension = strtolower((string) pathinfo($filename, PATHINFO_EXTENSION));
        $item = [
            'filename' => $filename,
            'absolute_path' => $absolutePath,
            'extension' => $extension,
            'size' => (int) @filesize($absolutePath),
            'width' => 0,
            'height' => 0,
            'file_hash' => (string) (@hash_file('sha256', $absolutePath) ?: ''),
            'status' => 'unknown',
            'message' => '',
        ];

        if (!in_array($extension, $allowedExtensions, true)) {
            $item['status'] = 'invalid';
            $item['message'] = 'Only JPG, JPEG, and PNG files are supported for bulk photos.';
        } elseif ($item['size'] <= 0 || $item['size'] > $maxBytes) {
            $item['status'] = 'invalid';
            $item['message'] = 'File exceeds the configured bulk source size limit.';
        } else {
            $imageInfo = @getimagesize($absolutePath);
            if (!$imageInfo) {
                $item['status'] = 'invalid';
                $item['message'] = 'File is not a readable image.';
            } else {
                $item['width'] = (int) ($imageInfo[0] ?? 0);
                $item['height'] = (int) ($imageInfo[1] ?? 0);
                if ($item['width'] > $maxWidth || $item['height'] > $maxHeight) {
                    $item['status'] = 'invalid';
                    $item['message'] = 'Image exceeds the configured bulk source resolution limit.';
                }
            }
        }

        $result['files'][] = $item;
    }

    return $result;
}

function student_photo_bulk_preview(array $students, array $files, string $grade): array
{
    $studentsByLrn = [];
    $studentsByName = [];
    foreach ($students as $student) {
        $studentId = (int) ($student['id'] ?? 0);
        if ($studentId <= 0) {
            continue;
        }
        $lrn = student_photo_normalize_lrn((string) ($student['lrn'] ?? ''));
        if ($lrn !== '1111') {
            $studentsByLrn[$lrn][] = $student;
        }
        $nameKey = student_photo_student_name_key($student);
        if ($nameKey !== '') {
            $studentsByName[$nameKey][] = $student;
        }
    }

    $gradeCode = student_photo_grade_code($grade);
    $matchesByStudent = [];
    $unmatchedFiles = [];
    foreach ($files as $file) {
        if (($file['status'] ?? '') === 'invalid') {
            $unmatchedFiles[] = $file;
            continue;
        }

        $parsed = student_photo_parse_source_filename((string) ($file['filename'] ?? ''));
        if (!$parsed['valid'] || $parsed['grade_code'] !== $gradeCode) {
            $file['status'] = 'unknown';
            $file['message'] = 'Filename does not match the selected grade naming format.';
            $unmatchedFiles[] = $file;
            continue;
        }

        $candidates = [];
        $matchType = '';
        $score = 0;
        if ($parsed['lrn'] !== '1111' && count($studentsByLrn[$parsed['lrn']] ?? []) === 1) {
            $candidates = $studentsByLrn[$parsed['lrn']];
            $matchType = 'Exact LRN';
            $score = 100;
        } elseif (count($studentsByName[$parsed['name_key']] ?? []) === 1) {
            $candidates = $studentsByName[$parsed['name_key']];
            $matchType = 'Exact Name';
            $score = 90;
        }

        if (count($candidates) !== 1) {
            $file['status'] = 'unknown';
            $file['message'] = 'No unique student match was found.';
            $unmatchedFiles[] = $file;
            continue;
        }

        $student = $candidates[0];
        $studentId = (int) $student['id'];
        $file['status'] = 'matched';
        $file['match_type'] = $matchType;
        $file['match_score'] = $score;
        $matchesByStudent[$studentId][] = $file;
    }

    $rows = [];
    foreach ($students as $student) {
        $studentId = (int) ($student['id'] ?? 0);
        $matches = $matchesByStudent[$studentId] ?? [];
        $hasExistingPhoto = trim((string) ($student['photo'] ?? '')) !== '';
        $row = [
            'student' => $student,
            'expected_filename' => student_photo_expected_source_filename($student),
            'matches' => $matches,
            'status' => $hasExistingPhoto ? 'already_attached' : 'missing',
            'message' => $hasExistingPhoto ? 'Student already has an attached photo.' : 'No matching inbox photo was found.',
        ];
        if (count($matches) === 1) {
            $row['status'] = $hasExistingPhoto ? 'replacement_candidate' : 'matched';
            $row['message'] = $matches[0]['match_type'] . ' match (' . (int) $matches[0]['match_score'] . '% confidence).';
        } elseif (count($matches) > 1) {
            $row['status'] = 'duplicate';
            $row['message'] = 'More than one inbox photo matched this student. Review is required.';
        }
        $rows[] = $row;
    }

    return ['rows' => $rows, 'unmatched_files' => $unmatchedFiles];
}

function student_photo_bulk_tables_ready(mysqli $conn): bool
{
    foreach (['student_photo_assignments', 'student_photo_bulk_batches', 'student_photo_bulk_batch_items'] as $tableName) {
        $stmt = $conn->prepare('SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1');
        if (!$stmt) { return false; }
        $stmt->bind_param('s', $tableName);
        $stmt->execute();
        $exists = $stmt->get_result()->num_rows > 0;
        $stmt->close();
        if (!$exists) { return false; }
    }
    return true;
}

function student_photo_bulk_create_preview_batch(mysqli $conn, string $schoolYear, string $grade, string $section, array $preview, string $username): ?string
{
    if (!student_photo_bulk_tables_ready($conn)) { return null; }
    try { $token = bin2hex(random_bytes(32)); } catch (Throwable $e) { return null; }
    $stmt = $conn->prepare('INSERT INTO student_photo_bulk_batches (batch_token, school_year_label, grade, section, source_type, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)');
    if (!$stmt) { return null; }
    $sourceType = 'inbox_scan'; $status = 'staged';
    $stmt->bind_param('sssssss', $token, $schoolYear, $grade, $section, $sourceType, $status, $username);
    if (!$stmt->execute()) { $stmt->close(); return null; }
    $batchId = (int) $stmt->insert_id;
    $stmt->close();

    $itemStmt = $conn->prepare('INSERT INTO student_photo_bulk_batch_items (batch_id, student_id, staged_relative_path, original_filename, normalized_filename_key, file_hash, match_status, match_score, is_selected, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    if (!$itemStmt) { return null; }
    $created = true;
    foreach ($preview['rows'] ?? [] as $row) {
        $studentId = (int) (($row['student']['id'] ?? 0));
        if (empty($row['matches'])) {
            $path = ''; $filename = ''; $key = ''; $hash = '';
            $matchStatus = (string) ($row['status'] ?? 'missing');
            $score = 0.0; $selected = 0; $notes = (string) ($row['message'] ?? '');
            $itemStmt->bind_param('iisssssdis', $batchId, $studentId, $path, $filename, $key, $hash, $matchStatus, $score, $selected, $notes);
            if (!$itemStmt->execute()) { $created = false; break; }
        }
        foreach ($row['matches'] ?? [] as $file) {
            $path = (string) ($file['filename'] ?? '');
            $filename = (string) ($file['filename'] ?? '');
            $key = student_photo_normalize_key($filename);
            $hash = (string) ($file['file_hash'] ?? '');
            $matchStatus = (string) ($row['status'] ?? 'unknown');
            $score = (float) ($file['match_score'] ?? 0);
            $selected = $matchStatus === 'matched' ? 1 : 0;
            $notes = (string) ($row['message'] ?? '');
            $itemStmt->bind_param('iisssssdis', $batchId, $studentId, $path, $filename, $key, $hash, $matchStatus, $score, $selected, $notes);
            if (!$itemStmt->execute()) { $created = false; break; }
        }
        if (!$created) { break; }
    }
    if ($created) {
        foreach ($preview['unmatched_files'] ?? [] as $file) {
            $studentId = null;
            $path = (string) ($file['filename'] ?? '');
            $filename = (string) ($file['filename'] ?? '');
            $key = student_photo_normalize_key($filename);
            $hash = (string) ($file['file_hash'] ?? '');
            $matchStatus = (string) ($file['status'] ?? 'unknown');
            $score = 0.0; $selected = 0; $notes = (string) ($file['message'] ?? '');
            $itemStmt->bind_param('iisssssdis', $batchId, $studentId, $path, $filename, $key, $hash, $matchStatus, $score, $selected, $notes);
            if (!$itemStmt->execute()) { $created = false; break; }
        }
    }
    $itemStmt->close();
    if (!$created) {
        $deleteStmt = $conn->prepare('DELETE FROM student_photo_bulk_batches WHERE id = ?');
        if ($deleteStmt) { $deleteStmt->bind_param('i', $batchId); $deleteStmt->execute(); $deleteStmt->close(); }
        return null;
    }
    return $token;
}

function student_photo_bulk_load_batch(mysqli $conn, string $token): ?array
{
    $stmt = $conn->prepare('SELECT id, batch_token, school_year_label, grade, section, status, created_by, created_at, applied_at FROM student_photo_bulk_batches WHERE batch_token = ? LIMIT 1');
    if (!$stmt) { return null; }
    $stmt->bind_param('s', $token); $stmt->execute();
    $batch = $stmt->get_result()->fetch_assoc() ?: null; $stmt->close();
    if (!$batch) { return null; }
    $itemStmt = $conn->prepare("SELECT i.*, s.lastname, s.firstname, s.middlename, s.lrn, s.photo FROM student_photo_bulk_batch_items i LEFT JOIN students s ON s.id = i.student_id WHERE i.batch_id = ? ORDER BY s.lastname ASC, s.firstname ASC, i.id ASC");
    if (!$itemStmt) { return null; }
    $batchId = (int) $batch['id']; $itemStmt->bind_param('i', $batchId); $itemStmt->execute();
    $batch['items'] = $itemStmt->get_result()->fetch_all(MYSQLI_ASSOC); $itemStmt->close();
    return $batch;
}

function student_photo_bulk_final_target(mysqli $conn, array $batch, int $studentId, string $sourceFilename): ?array
{
    $extension = strtolower((string) pathinfo($sourceFilename, PATHINFO_EXTENSION));
    if (!in_array($extension, ['jpg', 'jpeg', 'png'], true)) { return null; }
    $relativeDir = upload_storage_relative_path(implode('/', [
        'bulk',
        student_photo_bulk_path_segment((string) $batch['school_year_label'], 'school-year'),
        student_photo_grade_code((string) $batch['grade']) ?: 'grade',
        student_photo_bulk_path_segment((string) ($batch['section'] ?? ''), 'section'),
    ]));
    $targetDir = student_photo_base_dir($conn) . '/' . $relativeDir;
    if (!is_dir($targetDir) && !@mkdir($targetDir, 0775, true) && !is_dir($targetDir)) { return null; }
    try { $suffix = substr(bin2hex(random_bytes(8)), 0, 12); } catch (Throwable $e) { $suffix = uniqid(); }
    $filename = 'student-' . $studentId . '-' . $suffix . '.' . $extension;
    return ['relative_path' => $relativeDir . '/' . $filename, 'absolute_path' => $targetDir . '/' . $filename];
}

function student_photo_bulk_apply_batch(mysqli $conn, array $settings, string $token, array $selectedItemIds, array $replacementItemIds, string $username): array
{
    $result = ['success' => [], 'errors' => [], 'batch_status' => ''];
    $token = trim($token);
    $selected = array_fill_keys(array_map('intval', $selectedItemIds), true);
    $replacementSelected = array_fill_keys(array_map('intval', $replacementItemIds), true);
    if ($token === '' || !$selected) { $result['errors'][] = 'Choose at least one matched photo before applying.'; return $result; }

    $lockStmt = $conn->prepare("UPDATE student_photo_bulk_batches SET status = 'applying' WHERE batch_token = ? AND status = 'staged'");
    if (!$lockStmt) { $result['errors'][] = 'Unable to lock this batch for processing.'; return $result; }
    $lockStmt->bind_param('s', $token); $lockStmt->execute(); $locked = $lockStmt->affected_rows === 1; $lockStmt->close();
    if (!$locked) { $result['errors'][] = 'This batch was already applied or is no longer available.'; return $result; }

    $batch = student_photo_bulk_load_batch($conn, $token);
    if (!$batch) { $result['errors'][] = 'Unable to load the locked batch.'; return $result; }
    $inboxDir = student_photo_bulk_inbox_scope_dir($settings, (string) $batch['school_year_label'], (string) $batch['grade'], (string) ($batch['section'] ?? ''));

    foreach ($batch['items'] as $item) {
        $itemId = (int) $item['id'];
        if (!isset($selected[$itemId])) { continue; }
        $status = (string) $item['match_status'];
        if ($status !== 'matched' && !($status === 'replacement_candidate' && isset($replacementSelected[$itemId]))) {
            $result['errors'][] = 'Skipped ' . (string) $item['original_filename'] . ': it is not an approved match.';
            continue;
        }
        $studentId = (int) ($item['student_id'] ?? 0);
        $filename = basename((string) $item['original_filename']);
        $sourcePath = $inboxDir . '/' . $filename;
        if ($studentId <= 0 || !is_file($sourcePath) || !@getimagesize($sourcePath)) {
            $result['errors'][] = 'Skipped ' . $filename . ': the source file is missing or invalid.';
            continue;
        }
        $currentHash = (string) (@hash_file('sha256', $sourcePath) ?: '');
        if ($currentHash === '' || !hash_equals((string) ($item['file_hash'] ?? ''), $currentHash)) {
            $result['errors'][] = 'Skipped ' . $filename . ': the inbox file changed after preview. Scan again first.';
            continue;
        }
        $target = student_photo_bulk_final_target($conn, $batch, $studentId, $filename);
        if (!$target || !@copy($sourcePath, $target['absolute_path'])) {
            $result['errors'][] = 'Skipped ' . $filename . ': unable to place the final photo file.';
            continue;
        }
        student_photo_optimize_image($target['absolute_path'], (string) pathinfo($filename, PATHINFO_EXTENSION), student_photo_storage_settings($conn));
        $conn->begin_transaction();
        try {
            $deactivateStmt = $conn->prepare('UPDATE student_photo_assignments SET is_active = 0, replaced_at = NOW() WHERE student_id = ? AND is_active = 1');
            if (!$deactivateStmt) { throw new RuntimeException('Unable to archive the previous photo assignment.'); }
            $deactivateStmt->bind_param('i', $studentId); $deactivateStmt->execute(); $deactivateStmt->close();
            $updateStudent = $conn->prepare('UPDATE students SET photo = ? WHERE id = ?');
            if (!$updateStudent) { throw new RuntimeException('Unable to update the student photo.'); }
            $updateStudent->bind_param('si', $target['relative_path'], $studentId); $updateStudent->execute(); $updateStudent->close();
            $assignStmt = $conn->prepare("INSERT INTO student_photo_assignments (student_id, stored_relative_path, original_filename, normalized_filename_key, source_type, match_status, match_score, file_hash, assigned_by, is_active, notes) VALUES (?, ?, ?, ?, 'bulk', ?, ?, ?, ?, 1, ?)");
            if (!$assignStmt) { throw new RuntimeException('Unable to create the photo assignment history.'); }
            $key = (string) $item['normalized_filename_key']; $matchStatus = $status; $score = (float) $item['match_score']; $hash = $currentHash; $notes = 'Applied from bulk batch ' . $token;
            $assignStmt->bind_param('issssdsss', $studentId, $target['relative_path'], $filename, $key, $matchStatus, $score, $hash, $username, $notes);
            $assignStmt->execute(); $assignStmt->close();
            $itemUpdate = $conn->prepare('UPDATE student_photo_bulk_batch_items SET applied_at = NOW(), is_selected = 1 WHERE id = ?');
            if (!$itemUpdate) { throw new RuntimeException('Unable to mark the batch item complete.'); }
            $itemUpdate->bind_param('i', $itemId); $itemUpdate->execute(); $itemUpdate->close();
            $conn->commit();
            $result['success'][] = ['student_id' => $studentId, 'filename' => $filename, 'replacement' => $status === 'replacement_candidate'];
        } catch (Throwable $e) {
            $conn->rollback(); @unlink($target['absolute_path']);
            $result['errors'][] = 'Skipped ' . $filename . ': ' . $e->getMessage();
        }
    }
    $finalStatus = $result['errors'] ? (empty($result['success']) ? 'failed' : 'partial') : 'applied';
    $finishStmt = $conn->prepare('UPDATE student_photo_bulk_batches SET status = ?, applied_at = NOW() WHERE id = ?');
    if ($finishStmt) { $batchId = (int) $batch['id']; $finishStmt->bind_param('si', $finalStatus, $batchId); $finishStmt->execute(); $finishStmt->close(); }
    $result['batch_status'] = $finalStatus;
    return $result;
}
