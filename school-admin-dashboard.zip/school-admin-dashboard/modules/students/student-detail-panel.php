<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
include '../../config/database.php';
include __DIR__ . '/../settings/settings-permissions-roles.php';
include __DIR__ . '/../settings/upload-storage-helper.php';
include __DIR__ . '/student-requirements-helper.php';
include __DIR__ . '/student-registration-helper.php';

header('Content-Type: text/html; charset=UTF-8');

function h($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$currentRole = $_SESSION['role'] ?? '';
$canView = hasPermission($currentRole, 'student_data', 'view');
$canEdit = hasPermission($currentRole, 'student_data', 'edit');
$canViewPanel = $canView && (is_super_admin_role($currentRole) || is_administrator_role($currentRole));
if (!$canViewPanel) {
    http_response_code(403);
    echo '<div class="alert alert-danger mb-0">Access denied.</div>';
    exit();
}

$studentId = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($studentId <= 0) {
    echo '<div class="alert alert-danger mb-0">Invalid student ID.</div>';
    exit();
}

admin_csrf_token();

registration_ensure_student_strand_column($conn);

$message = '';
$messageType = 'success';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $canEdit) {
    $token = $_POST['csrf_token'] ?? '';
    if (!admin_csrf_validate($token)) {
        $message = 'Security validation failed. Please refresh and try again.';
        $messageType = 'danger';
    } else {
        try {
            $user = $_SESSION['username'] ?? 'unknown';
            student_requirements_save_for_student($conn, $studentId, $_POST['requirements'] ?? [], $user);
            $documentSave = student_requirement_documents_save_uploaded_files(
                $conn,
                $studentId,
                $_FILES['requirement_documents'] ?? [],
                $user,
                $_POST['requirement_document_notes'] ?? []
            );
            include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');
            audit_log(
                $conn,
                $user,
                'Updated student requirements',
                'Students',
                'Role: ' . ($currentRole ?: 'unknown') . ' | Student ID: ' . $studentId . ' | Requirement documents uploaded: ' . (int) ($documentSave['saved'] ?? 0)
            );
            $message = (int) ($documentSave['saved'] ?? 0) > 0
                ? 'Requirement statuses updated and document uploads saved.'
                : 'Requirement statuses updated.';
        } catch (Throwable $e) {
            $message = $e->getMessage();
            $messageType = 'danger';
        }
    }
}

$stmt = $conn->prepare("SELECT id, lastname, firstname, middlename, lrn, birthday, age, gender, grade, strand, section, school_year_label, address, contact, guardian_name, guardian_contact, date_enrolled, photo FROM students WHERE id = ?");
$stmt->bind_param('i', $studentId);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$student) {
    echo '<div class="alert alert-danger mb-0">Student not found.</div>';
    exit();
}

$statuses = student_requirements_get_for_student($conn, $studentId);
$catalogRows = student_requirements_catalog_rows($conn);
$catalog = student_requirements_catalog($conn);
$summary = student_requirements_completion_summary($statuses);
$activityRows = student_requirement_activity_get_for_student($conn, $studentId, 50);
$documents = student_requirement_documents_get_for_student($conn, $studentId);
$documentSummary = student_requirement_documents_summary($documents, count($catalogRows));

function requirement_badge_class(string $status): string {
    return match ($status) {
        'Submitted' => 'bg-success-subtle text-success-emphasis border border-success-subtle',
        'To Follow' => 'bg-warning-subtle text-warning-emphasis border border-warning-subtle',
        default => 'bg-danger-subtle text-danger-emphasis border border-danger-subtle',
    };
}

function overall_badge_class(string $status): string {
    return match ($status) {
        'Complete' => 'bg-success-subtle text-success-emphasis border border-success-subtle',
        'For Follow-up' => 'bg-warning-subtle text-warning-emphasis border border-warning-subtle',
        default => 'bg-danger-subtle text-danger-emphasis border border-danger-subtle',
    };
}

function requirement_label(array $catalog, string $key): string {
    return $catalog[$key] ?? ucwords(str_replace('_', ' ', $key));
}
?>
<div class="student-wave-panel card border-0 shadow-sm">
    <div class="card-header d-flex justify-content-between align-items-start flex-wrap gap-3">
        <div>
            <div class="panel-kicker">Student Record Panel</div>
            <div class="panel-title"><?= h($student['lastname'] . ', ' . $student['firstname'] . ' ' . $student['middlename']) ?></div>
            <div class="panel-subtitle">Full profile view plus requirement tracking, so you no longer need to jump out to a separate page for the basics.</div>
        </div>
        <div class="d-flex gap-2 flex-wrap">
            <span class="badge rounded-pill text-bg-light border">Grade: <?= h($student['grade']) ?></span>
            <?php if (!empty($student['strand'])): ?>
                <span class="badge rounded-pill text-bg-light border">Strand: <?= h($student['strand']) ?></span>
            <?php endif; ?>
            <span class="badge rounded-pill text-bg-light border">Section: <?= h($student['section'] ?: '-') ?></span>
            <span class="badge rounded-pill text-bg-light border">School Year: <?= h($student['school_year_label'] ?: 'Unassigned') ?></span>
        </div>
    </div>
    <div class="card-body">
        <?php if ($message !== ''): ?>
            <div class="alert alert-<?= h($messageType) ?>"><?= h($message) ?></div>
        <?php endif; ?>

        <div class="row g-3 mb-4 align-items-start">
            <div class="col-lg-4">
                <div class="panel-block">
                    <div class="text-center mb-3">
                        <?php if (!empty($student['photo'])): ?>
                            <img src="<?= h(student_photo_public_url((string) $student['photo'])) ?>" alt="Student Photo" class="student-panel-photo">
                        <?php else: ?>
                            <div class="student-panel-photo-placeholder">
                                <i class="fas fa-user"></i>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="block-title">Student Information</div>
                    <div class="detail-grid">
                        <div><strong>LRN</strong><span><?= h($student['lrn'] ?: 'N/A') ?></span></div>
                        <div><strong>Birthday</strong><span><?= h($student['birthday'] ?: '-') ?></span></div>
                        <div><strong>Age</strong><span><?= h($student['age'] ?: '-') ?></span></div>
                        <div><strong>Gender</strong><span><?= h($student['gender'] ?: '-') ?></span></div>
                        <div><strong>Strand</strong><span><?= h($student['strand'] ?: 'Not applicable') ?></span></div>
                        <div><strong>Contact</strong><span><?= h($student['contact'] ?: '-') ?></span></div>
                        <div><strong>Address</strong><span><?= h($student['address'] ?: '-') ?></span></div>
                        <div><strong>Guardian</strong><span><?= h($student['guardian_name'] ?: '-') ?></span></div>
                        <div><strong>Guardian Contact</strong><span><?= h($student['guardian_contact'] ?: '-') ?></span></div>
                        <div><strong>Date Enrolled</strong><span><?= h($student['date_enrolled'] ?: '-') ?></span></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="panel-block mb-3">
                    <div class="block-title">Requirement Snapshot</div>
                    <div class="summary-chips compact-summary mb-3">
                        <span class="badge rounded-pill <?= h(overall_badge_class($summary['overall_status'])) ?>"><?= h($summary['overall_status']) ?></span>
                        <span class="summary-chip"><?= number_format($summary['submitted']) ?>/<?= number_format($summary['total']) ?> Submitted</span>
                        <span class="summary-chip"><?= h($documentSummary['coverage_label']) ?></span>
                    </div>
                    <div class="snapshot-stats">
                        <div class="snapshot-stat">
                            <span class="snapshot-label">Submitted</span>
                            <strong class="snapshot-value text-success-emphasis"><?= number_format($summary['submitted']) ?></strong>
                        </div>
                        <div class="snapshot-stat">
                            <span class="snapshot-label">For Follow-up</span>
                            <strong class="snapshot-value text-warning-emphasis"><?= number_format($summary['to_follow']) ?></strong>
                        </div>
                        <div class="snapshot-stat">
                            <span class="snapshot-label">Missing</span>
                            <strong class="snapshot-value text-danger-emphasis"><?= number_format($summary['missing']) ?></strong>
                        </div>
                        <div class="snapshot-stat">
                            <span class="snapshot-label">Files Uploaded</span>
                            <strong class="snapshot-value text-primary-emphasis"><?= number_format($documentSummary['uploaded']) ?></strong>
                        </div>
                    </div>
                    <p class="small text-muted mt-3 mb-0">Only the requirement rows you actually change will get a new checker and timestamp. Untouched rows keep their last-touch history.</p>
                </div>
                <div class="panel-block">
                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
                        <div class="block-title mb-0">Recent Requirement Activity</div>
                        <span class="badge rounded-pill text-bg-light border">Latest 50 updates</span>
                    </div>
                    <?php if (!empty($activityRows)): ?>
                        <div class="requirement-activity-list">
                            <?php foreach ($activityRows as $activity): ?>
                                <?php
                                    $activityLabel = requirement_label($catalog, (string) ($activity['requirement_key'] ?? ''));
                                    $oldStatus = trim((string) ($activity['old_status'] ?? ''));
                                    $newStatus = trim((string) ($activity['new_status'] ?? ''));
                                    $oldNote = trim((string) ($activity['old_note'] ?? ''));
                                    $newNote = trim((string) ($activity['new_note'] ?? ''));
                                    $changedAt = !empty($activity['changed_at']) ? date('M j, Y g:i A', strtotime((string) $activity['changed_at'])) : '-';
                                ?>
                                <div class="activity-item">
                                    <div class="activity-dot"><i class="fas fa-check"></i></div>
                                    <div class="activity-body">
                                        <div class="activity-title">
                                            <strong><?= h((string) ($activity['changed_by'] ?? 'Unknown')) ?></strong>
                                            updated
                                            <strong><?= h($activityLabel) ?></strong>
                                        </div>
                                        <div class="activity-meta">
                                            <span><?= h($changedAt) ?></span>
                                            <span>Status: <?= h($oldStatus !== '' ? $oldStatus : 'New') ?> -> <?= h($newStatus) ?></span>
                                            <?php if ($oldNote !== $newNote): ?>
                                                <span>Note updated</span>
                                            <?php endif; ?>
                                        </div>
                                        <?php if ($newNote !== ''): ?>
                                            <div class="activity-note">Note: <?= h($newNote) ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-muted small">No requirement activity yet for this student.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <form method="post" action="student-detail-panel.php?id=<?= (int) $studentId ?>" id="studentRequirementForm" data-student-id="<?= (int) $studentId ?>" enctype="multipart/form-data" onsubmit="return window.submitStudentRequirementPanel ? window.submitStudentRequirementPanel(this) : false;">
            <input type="hidden" name="csrf_token" value="<?= h(admin_csrf_token()) ?>">
            <div class="panel-block">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
                    <div class="block-title mb-0">Requirements Checklist</div>
                    <?php if (!$canEdit): ?>
                        <span class="badge rounded-pill text-bg-light border">View Only</span>
                    <?php endif; ?>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle mb-0">
                        <thead>
                                <tr>
                                    <th>Requirement</th>
                                    <th>Status</th>
                                    <th>Note</th>
                                    <th>Checked By</th>
                                    <th>Checked At</th>
                                    <th>Document</th>
                                    <?php if ($canEdit): ?><th class="text-end">Update</th><?php endif; ?>
                                </tr>
                            </thead>
                        <tbody>
                            <?php foreach ($catalogRows as $catalogRow): ?>
                                <?php
                                    $key = (string) ($catalogRow['requirement_key'] ?? '');
                                    $label = (string) ($catalogRow['label'] ?? $key);
                                    $requirement = $statuses[$key] ?? ['status' => 'Missing', 'note' => '', 'updated_by' => '', 'checked_at' => ''];
                                    $status = $requirement['status'] ?? 'Missing';
                                    $checkedAt = !empty($requirement['checked_at']) ? date('M j, Y g:i A', strtotime((string) $requirement['checked_at'])) : '-';
                                    $requiredBadge = !empty($catalogRow['is_required']) ? 'Required' : 'Optional';
                                    $document = $documents[$key] ?? null;
                                    $documentUploadedAt = !empty($document['uploaded_at']) ? date('M j, Y g:i A', strtotime((string) $document['uploaded_at'])) : '';
                                ?>
                                <tr>
                                    <td>
                                        <div class="fw-semibold"><?= h($label) ?></div>
                                        <div class="small text-muted"><?= h($requiredBadge) ?></div>
                                    </td>
                                    <td><span class="badge rounded-pill <?= h(requirement_badge_class($status)) ?>"><?= h($status) ?></span></td>
                                    <td class="text-muted small"><?= h($requirement['note'] ?: '-') ?></td>
                                    <td class="text-muted small"><?= h($requirement['updated_by'] ?: '-') ?></td>
                                    <td class="text-muted small"><?= h($checkedAt) ?></td>
                                    <td>
                                        <?php if ($document): ?>
                                            <div class="small">
                                                <a href="<?= h((string) ($document['public_url'] ?? '#')) ?>" target="_blank" rel="noopener noreferrer" class="fw-semibold text-decoration-none">
                                                    <i class="fas fa-paperclip me-1"></i><?= h((string) ($document['original_filename'] ?? 'Document')) ?>
                                                </a>
                                            </div>
                                            <div class="small text-muted">
                                                <?= h($documentUploadedAt ?: '-') ?>
                                                <?php if (!empty($document['uploaded_by'])): ?>
                                                    <span>by <?= h((string) $document['uploaded_by']) ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="small text-muted"><?= h(student_requirement_document_human_size((int) ($document['file_size_bytes'] ?? 0))) ?></div>
                                            <?php if (!empty($document['note'])): ?>
                                                <div class="small text-muted">Note: <?= h((string) $document['note']) ?></div>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted small">No file uploaded</span>
                                        <?php endif; ?>
                                    </td>
                                    <?php if ($canEdit): ?>
                                        <td class="text-end">
                                            <div class="requirement-update-stack ms-auto">
                                                <select name="requirements[<?= h($key) ?>][status]" class="form-select form-select-sm d-inline-block requirement-select">
                                                    <?php foreach (student_requirements_allowed_statuses() as $allowedStatus): ?>
                                                        <option value="<?= h($allowedStatus) ?>" <?= $status === $allowedStatus ? 'selected' : '' ?>><?= h($allowedStatus) ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <input type="text" name="requirements[<?= h($key) ?>][note]" value="<?= h($requirement['note'] ?? '') ?>" class="form-control form-control-sm requirement-note" placeholder="Add follow-up note">
                                                <input type="file" name="requirement_documents[<?= h($key) ?>]" class="form-control form-control-sm requirement-note" accept=".pdf,.jpg,.jpeg,.png">
                                                <input type="text" name="requirement_document_notes[<?= h($key) ?>]" value="<?= h((string) (($document['note'] ?? ''))) ?>" class="form-control form-control-sm requirement-note" placeholder="Document note (optional)">
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php if ($canEdit): ?>
                    <p class="small text-muted mt-3 mb-2">Allowed document types: PDF, JPG, JPEG, PNG. Uploads are additive and will not change the student list flow.</p>
                    <div class="text-end mt-3">
                        <button type="button" class="btn btn-primary" id="studentRequirementSaveBtn" onclick="return window.submitStudentRequirementPanel ? window.submitStudentRequirementPanel(document.getElementById('studentRequirementForm')) : false;">
                            <i class="fas fa-save"></i> Save Requirement Status
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>
