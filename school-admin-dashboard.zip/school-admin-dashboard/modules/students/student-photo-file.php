<?php
// Capture accidental include output (BOM/whitespace) so image bytes stay clean.
ob_start();

require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require '../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/upload-storage-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

$currentRole = $_SESSION['role'] ?? '';
$canView =
    hasPermission($currentRole, 'student_data', 'view') ||
    hasPermission($currentRole, 'student_registration', 'view') ||
    hasPermission($currentRole, 'account_mgmt', 'view') ||
    hasPermission($currentRole, 'financial', 'view');

if (!$canView) {
    $blockedUser = $_SESSION['username'] ?? 'unknown';
    audit_log(
        $conn,
        $blockedUser,
        'Blocked student photo access',
        'Students',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing view permission for student photo endpoint',
        'SECURITY'
    );
    admin_session_forbidden();
}

$relativePath = upload_storage_relative_path((string) ($_GET['path'] ?? ''));
$absolutePath = student_photo_absolute_path($conn, $relativePath);
if ($relativePath === '' || $absolutePath === '' || !is_file($absolutePath)) {
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    http_response_code(404);
    exit('Photo not found.');
}

$extension = strtolower(pathinfo($absolutePath, PATHINFO_EXTENSION));
$mime = match ($extension) {
    'jpg', 'jpeg' => 'image/jpeg',
    'png' => 'image/png',
    'gif' => 'image/gif',
    default => 'application/octet-stream',
};

while (ob_get_level() > 0) {
    ob_end_clean();
}

header('Content-Type: ' . $mime);
header('Content-Length: ' . (string) filesize($absolutePath));
header('Content-Disposition: inline; filename="' . basename($absolutePath) . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=300');
readfile($absolutePath);
exit();
