<?php
require_once __DIR__ . '/../../config/app-env.php';
ini_set('display_errors', '0');
error_reporting(E_ALL);

require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require __DIR__ . '/../../config/database.php';
require __DIR__ . '/../../vendor/autoload.php';
require __DIR__ . '/../settings/school-year-helper.php';
require __DIR__ . '/../settings/settings-permissions-roles.php';
require __DIR__ . '/student-registration-helper.php';
require __DIR__ . '/student-requirements-helper.php';

$role = $_SESSION['role'] ?? '';
if (!hasPermission($role, 'student_data', 'export')) {
    include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');
    $blockedUser = $_SESSION['username'] ?? 'unknown';
    audit_log(
        $conn,
        $blockedUser,
        'Blocked student list export access',
        'Students',
        'Role: ' . ($role !== '' ? $role : 'unknown') . ' | Reason: missing student_data:export permission',
        'SECURITY'
    );
    admin_session_forbidden();
}

$hasStrandColumn = registration_column_exists($conn, 'students', 'strand');
$strandSelect = $hasStrandColumn ? "COALESCE(strand, '')" : "''";

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Cell\DataType;

// ----------------------------
// SCHOOL INFO (SUMMARY SHEET ONLY)
// ----------------------------
$school = [
    'school_name' => "The Lord's Wisdom Academy of Caloocan Inc",
    'address' => "1162 Santol St. cor Guyabano, Camarin Rd, Caloocan, 1400 Metro Manila",
    'contact_number' => "(02) 8866 4101",
    'email' => "thelordwisdomacademyinc@gmail.com"
];

// ----------------------------
// GRADE LEVELS & COLOR THEME
// ----------------------------
$grades = [
    "Junior Kindergarten", "Senior Kindergarten", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5",
    "Grade 6", "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"
];
// Colors for summary
$headerFill = 'AED6F1';     // Soft blue
$totalFill  = 'A2D9CE';     // Soft green
$rowAltFill = 'E9F7EF';     // Mint green
$summaryFill = 'F0F8FF';    // Very light blue for summary rows
$maleFill = 'E3F0FF';       // Light blue for male
$femaleFill = 'FFE3F1';     // Light pink for female
$tableHeaderFill = 'BFEFFF'; // Table header fill

// ----------------------------
// FILTERED VIEW
// ----------------------------
$is_locked = ($_SESSION['students_list_locked'] ?? 'unlocked') === 'locked';
$locked_filters = $_SESSION['students_list_locked_filters'] ?? null;
if ($is_locked && $locked_filters) {
    $_GET['grade'] = $locked_filters['grade'];
    $_GET['school_year'] = $locked_filters['school_year'] ?? '';
    $_GET['search'] = $locked_filters['search'];
    $_GET['view_mode'] = $locked_filters['view_mode'] ?? ($locked_filters['sort'] ?? 'az');
}
$selected_grade = $_GET['grade'] ?? '';
$selected_school_year = trim($_GET['school_year'] ?? '');
$search_term = trim($_GET['search'] ?? '');
$view_mode = trim((string) ($_GET['view_mode'] ?? ($_GET['sort'] ?? 'az')));
$allowed_view_modes = ['az', 'za', 'missing_lrn', 'no_section', 'incomplete_requirements'];
if (!in_array($view_mode, $allowed_view_modes, true)) {
    $view_mode = 'az';
}
$sort_order = $view_mode === 'za' ? 'za' : 'az';
$totalRequirementItems = count(student_requirements_catalog($conn));

$where = [];
$params = [];
$types = '';
if ($selected_grade) {
    $where[] = "grade = ?";
    $params[] = $selected_grade;
    $types .= 's';
}
if ($selected_school_year) {
    $where[] = "school_year_label = ?";
    $params[] = $selected_school_year;
    $types .= 's';
}
if ($search_term) {
    // Include SECTION in search logic!
    $where[] = "(lrn LIKE ? OR CONCAT(COALESCE(lastname,''), ' ', COALESCE(firstname,''), ' ', COALESCE(middlename,'')) LIKE ? OR section LIKE ?)";
    $params[] = "%" . $search_term . "%";
    $params[] = "%" . $search_term . "%";
    $params[] = "%" . $search_term . "%";
    $types .= 'sss';
}
if ($view_mode === 'missing_lrn') {
    $where[] = "COALESCE(NULLIF(TRIM(lrn), ''), '') = ''";
} elseif ($view_mode === 'no_section') {
    $where[] = "COALESCE(NULLIF(TRIM(section), ''), '') = ''";
} elseif ($view_mode === 'incomplete_requirements' && $totalRequirementItems > 0) {
    $where[] = "(SELECT COUNT(DISTINCT srd.requirement_key) FROM student_requirement_documents srd WHERE srd.student_id = students.id) < ?";
    $params[] = $totalRequirementItems;
    $types .= 'i';
}

$sqlFiltered = "SELECT lrn, firstname, middlename, lastname, grade, {$strandSelect} AS strand, section, birthday, age, gender, address, contact, guardian_name, guardian_contact, date_enrolled FROM students";
if ($where) {
    $sqlFiltered .= " WHERE " . implode(" AND ", $where);
}
$sqlFiltered .= " ORDER BY lastname " . ($sort_order === 'az' ? 'ASC' : 'DESC') . ", firstname " . ($sort_order === 'az' ? 'ASC' : 'DESC');

$stmt = $conn->prepare($sqlFiltered);
if (!$stmt) {
    die('Database error: ' . $conn->error);
}
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$resultFiltered = $stmt->get_result();

$filtered_students = [];
$total_male_filtered = 0;
$total_female_filtered = 0;
while ($student = $resultFiltered->fetch_assoc()) {
    $filtered_students[] = $student;
    if (strtolower(trim($student['gender'])) == 'male') $total_male_filtered++;
    if (strtolower(trim($student['gender'])) == 'female') $total_female_filtered++;
}
$total_students_filtered = count($filtered_students);
$stmt->close();

// ----------------------------
// ALL STUDENTS BY GRADE
// ----------------------------
$students_by_grade = [];
$summary_counts = [];
$grand_total = 0;
$grand_boys = 0;
$grand_girls = 0;

foreach ($grades as $grade_name) {
    $gradeSql = "SELECT lrn, firstname, middlename, lastname, grade, {$strandSelect} AS strand, section, birthday, age, gender, address, contact, guardian_name, guardian_contact, date_enrolled FROM students WHERE grade = ?";
    $gradeParams = [$grade_name];
    $gradeTypes = 's';
    if ($selected_school_year) {
        $gradeSql .= " AND school_year_label = ?";
        $gradeParams[] = $selected_school_year;
        $gradeTypes .= 's';
    }
    $gradeSql .= " ORDER BY lastname ASC, firstname ASC";

    $stmtG = $conn->prepare($gradeSql);
    $stmtG->bind_param($gradeTypes, ...$gradeParams);
    $stmtG->execute();
    $resultG = $stmtG->get_result();

    $students_grade = [];
    $boys = 0;
    $girls = 0;
    while ($student = $resultG->fetch_assoc()) {
        $students_grade[] = $student;
        if (strtolower(trim($student['gender'])) == 'male') $boys++;
        if (strtolower(trim($student['gender'])) == 'female') $girls++;
    }
    $stmtG->close();
    $total = count($students_grade);

    $students_by_grade[$grade_name] = $students_grade;
    $summary_counts[$grade_name] = ['boys'=>$boys, 'girls'=>$girls, 'total'=>$total];
    $grand_total += $total;
    $grand_boys += $boys;
    $grand_girls += $girls;
}

// ----------------------------
// HELPER: Title Case
// ----------------------------
function toTitleCase($str) {
    return preg_replace_callback('/\\b([a-z])/u', function ($match) {
        return strtoupper($match[1]);
    }, strtolower(trim($str)));
}

// ----------------------------
// HELPER: Format date for Excel export (handles empty/bad date)
// ----------------------------
function exportFormatDate($date_str, $default = '01-01-2020') {
    if (!$date_str || $date_str == '0000-00-00' || $date_str == '1970-01-01') return $default;
    $ts = strtotime($date_str);
    if ($ts && $date_str != '0000-00-00') {
        return date('m-d-Y', $ts);
    }
    return $default;
}

// ----------------------------
// CREATE SPREADSHEET
// ----------------------------
$spreadsheet = new Spreadsheet();

// ----------------------------
// 1. SUMMARY SHEET (ONLY SCHOOL INFO HERE)
// ----------------------------
$summarySheet = new Worksheet($spreadsheet, 'Summary');
$spreadsheet->addSheet($summarySheet, 0);
$spreadsheet->setActiveSheetIndex(0);

// Adjust columns for summary sheet for wide school info
$summarySheet->getColumnDimension('A')->setWidth(35); // Grade column + also fits school info
$summarySheet->getColumnDimension('B')->setWidth(11); // Boys
$summarySheet->getColumnDimension('C')->setWidth(11); // Girls
$summarySheet->getColumnDimension('D')->setWidth(11); // Total

$row = 1;
// School Name (centered, readable, wrap text)
$summarySheet->mergeCells("A$row:D$row");
$summarySheet->setCellValue("A$row", $school['school_name']);
$summarySheet->getStyle("A$row")->getFont()->setBold(true)->setSize(22)->getColor()->setRGB('34495E');
$summarySheet->getStyle("A$row")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER)->setVertical(Alignment::VERTICAL_CENTER)->setWrapText(true);
$summarySheet->getRowDimension($row)->setRowHeight(52);

$row++;
// Address (centered, italics, wrap text)
$summarySheet->mergeCells("A$row:D$row");
$summarySheet->setCellValue("A$row", "Address: " . $school['address']);
$summarySheet->getStyle("A$row")->getFont()->setSize(14)->setItalic(true);
$summarySheet->getStyle("A$row")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER)->setVertical(Alignment::VERTICAL_CENTER)->setWrapText(true);
$summarySheet->getRowDimension($row)->setRowHeight(36);

$row++;
// Contact and Email (centered, wrap text)
$summarySheet->mergeCells("A$row:D$row");
$summarySheet->setCellValue("A$row", "Contact: " . $school['contact_number'] . " | Email: " . $school['email']);
$summarySheet->getStyle("A$row")->getFont()->setSize(13);
$summarySheet->getStyle("A$row")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER)->setVertical(Alignment::VERTICAL_CENTER)->setWrapText(true);
$summarySheet->getRowDimension($row)->setRowHeight(32);

$row++; // Blank line for spacing
$row++;

// Table Header
$summarySheet->setCellValue("A$row", "Grade");
$summarySheet->setCellValue("B$row", "Boys");
$summarySheet->setCellValue("C$row", "Girls");
$summarySheet->setCellValue("D$row", "Total");
$summarySheet->getStyle("A$row:D$row")->applyFromArray([
    'font'=>['bold'=>true,'size'=>16,'name'=>'Arial'],
    'fill'=>['fillType'=>Fill::FILL_SOLID,'startColor'=>['rgb'=>$headerFill]],
    'alignment'=>['horizontal'=>Alignment::HORIZONTAL_CENTER, 'vertical'=>Alignment::VERTICAL_CENTER]
]);
$tableStart = $row + 1;

// Table Data Rows
foreach ($grades as $i => $grade_name) {
    $r = $tableStart + $i;
    $summarySheet->setCellValue("A$r", $grade_name);
    $summarySheet->setCellValue("B$r", $summary_counts[$grade_name]['boys']);
    $summarySheet->setCellValue("C$r", $summary_counts[$grade_name]['girls']);
    $summarySheet->setCellValue("D$r", $summary_counts[$grade_name]['total']);
    $summarySheet->getStyle("A$r:D$r")->applyFromArray([
        'alignment'=>['horizontal'=>Alignment::HORIZONTAL_CENTER, 'vertical'=>Alignment::VERTICAL_CENTER],
        'font'=>['size'=>14]
    ]);
    // Alternate row color
    if ($i % 2 == 1) {
        $summarySheet->getStyle("A$r:D$r")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB($rowAltFill);
    }
}

// Grand Total Row
$rowTotal = $tableStart + count($grades);
$summarySheet->setCellValue("A$rowTotal", "Grand Total");
$summarySheet->setCellValue("B$rowTotal", $grand_boys);
$summarySheet->setCellValue("C$rowTotal", $grand_girls);
$summarySheet->setCellValue("D$rowTotal", $grand_total);
$summarySheet->getStyle("A$rowTotal:D$rowTotal")->applyFromArray([
    'font'=>['bold'=>true,'size'=>16,'name'=>'Arial'],
    'fill'=>['fillType'=>Fill::FILL_SOLID,'startColor'=>['rgb'=>$totalFill]],
    'alignment'=>['horizontal'=>Alignment::HORIZONTAL_CENTER,'vertical'=>Alignment::VERTICAL_CENTER]
]);

// ----------------------------
// HEADERS (COMMON TO ALL SHEETS EXCEPT SUMMARY)
// ----------------------------
$headers = [
    'No.','LRN','First Name','Middle Name','Last Name','Grade','Strand','Section','Birthday','Age','Gender',
    'Address','Contact','Guardian Name','Guardian Contact','Date Enrolled'
];

// ----------------------------
// 2. FILTERED VIEW SHEET (NO SCHOOL INFO HEADER)
// ----------------------------
$filteredSheet = new Worksheet($spreadsheet, 'Filtered View');
$spreadsheet->addSheet($filteredSheet, 1);

$row = 1;
$titleText = "Student List (Filtered)";
if ($selected_grade) {
    $titleText .= " - " . $selected_grade;
}
if ($selected_school_year) {
    $titleText .= " | " . $selected_school_year;
}
$titleText .= " (" . date('F j, Y') . ")";
$filteredSheet->mergeCells("A$row:P$row"); // 16 columns
$filteredSheet->setCellValue("A$row", $titleText);
$filteredSheet->getStyle("A$row")->getFont()->setBold(true)->setSize(18);
$filteredSheet->getStyle("A$row")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

// Gender summary row
$row++;
$filteredSheet->mergeCells('A'.$row.':D'.$row);
$filteredSheet->mergeCells('E'.$row.':H'.$row);
$filteredSheet->mergeCells('I'.$row.':P'.$row);
$filteredSheet->setCellValue('A'.$row, "Total Boys (Male): $total_male_filtered");
$filteredSheet->setCellValue('E'.$row, "Total Girls (Female): $total_female_filtered");
$filteredSheet->setCellValue('I'.$row, "Total Students: $total_students_filtered");
$filteredSheet->getStyle('A'.$row.':P'.$row)->getFont()->setBold(true)->setSize(15);
$filteredSheet->getStyle('A'.$row.':P'.$row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER)->setVertical(Alignment::VERTICAL_CENTER);
$filteredSheet->getStyle('A'.$row.':P'.$row)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB($summaryFill);

// Header row
$row++;
$col = 'A';
foreach ($headers as $header) {
    $filteredSheet->setCellValue($col . $row, $header);
    $col++;
}
$filteredSheet->getStyle("A$row:P$row")->applyFromArray([
    'font'=>['bold'=>true,'size'=>16,'name'=>'Arial'],
    'fill'=>['fillType'=>Fill::FILL_SOLID,'startColor'=>['rgb'=>$tableHeaderFill]],
    'alignment'=>['horizontal'=>Alignment::HORIZONTAL_CENTER, 'vertical'=>Alignment::VERTICAL_CENTER]
]);
$filteredSheet->getRowDimension($row)->setRowHeight(28);

// Student rows
$dataStart = $row+1;
$num = 1;
$firstDataRow = $dataStart;
foreach ($filtered_students as $student) {
    $r = $dataStart++;
    $filteredSheet->setCellValue('A'.$r, $num++);
    $filteredSheet->setCellValueExplicit('B'.$r, (string)$student['lrn'], DataType::TYPE_STRING);
    $filteredSheet->setCellValue('C'.$r, toTitleCase($student['firstname']));
    $filteredSheet->setCellValue('D'.$r, toTitleCase($student['middlename']));
    $filteredSheet->setCellValue('E'.$r, toTitleCase($student['lastname']));
    $filteredSheet->setCellValue('F'.$r, $student['grade']);
    $filteredSheet->setCellValue('G'.$r, (string) (($student['strand'] ?? '') !== '' ? $student['strand'] : 'N/A'));
    $filteredSheet->setCellValue('H'.$r, $student['section']); // <--- SECTION!
    $filteredSheet->setCellValue('I'.$r, exportFormatDate($student['birthday'], '01-01-2020'));
    $filteredSheet->setCellValue('J'.$r, $student['age']);
    $filteredSheet->setCellValue('K'.$r, $student['gender']);
    $filteredSheet->setCellValue('L'.$r, $student['address']);
    $filteredSheet->setCellValue('M'.$r, $student['contact']);
    $filteredSheet->setCellValue('N'.$r, toTitleCase($student['guardian_name']));
    $filteredSheet->setCellValue('O'.$r, $student['guardian_contact']);
    $filteredSheet->setCellValue('P'.$r, exportFormatDate($student['date_enrolled'], '01-01-2025'));

    // Conditional row coloring by gender
    $rowRange = "A$r:P$r";
    if (strtolower($student['gender']) == 'female') {
        $filteredSheet->getStyle($rowRange)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB($femaleFill);
    } elseif (strtolower($student['gender']) == 'male') {
        $filteredSheet->getStyle($rowRange)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB($maleFill);
    }
    $filteredSheet->getRowDimension($r)->setRowHeight(26);
}

// Center all data cells and increase font size
if ($firstDataRow < $dataStart) {
    $filteredSheet->getStyle("A$firstDataRow:P".($dataStart-1))->applyFromArray([
        'alignment'=>['horizontal'=>Alignment::HORIZONTAL_CENTER, 'vertical'=>Alignment::VERTICAL_CENTER],
        'font'=>['size'=>14]
    ]);
}

// Footer summary
$footerRow = $dataStart + 1;
$filteredSheet->mergeCells("A$footerRow:D$footerRow");
$filteredSheet->mergeCells("E$footerRow:P$footerRow");
$filteredSheet->setCellValue("A$footerRow", "Total Students: " . ($num-1));
$filteredSheet->setCellValue("E$footerRow", "Exported: " . date('F j, Y, g:i A'));
$filteredSheet->getStyle("A$footerRow:P$footerRow")->getFont()->setBold(true)->setSize(14);
$filteredSheet->getStyle("A$footerRow:P$footerRow")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

// Auto-size columns
foreach (range('A', 'P') as $col) {
    $filteredSheet->getColumnDimension($col)->setAutoSize(true);
}
$filteredSheet->freezePane('A'.($row+1));
$filteredSheet->setAutoFilter("A$row:P$row");

// ----------------------------
// 3. GRADE SHEETS (NO SCHOOL INFO HEADER)
// ----------------------------
$sheetIdx = 2;
foreach ($grades as $grade_name) {
    $students_grade = $students_by_grade[$grade_name];
    $boys = $summary_counts[$grade_name]['boys'];
    $girls = $summary_counts[$grade_name]['girls'];
    $total = $summary_counts[$grade_name]['total'];

    $sheetGrade = new Worksheet($spreadsheet, $grade_name);
    $spreadsheet->addSheet($sheetGrade, $sheetIdx++);

    // Title row only (no school info header)
    $row = 1;
    $sheetGrade->mergeCells("A$row:P$row");
    $gradeTitle = "Student List - $grade_name";
    if ($selected_school_year) {
        $gradeTitle .= " | " . $selected_school_year;
    }
    $gradeTitle .= " (" . date('F j, Y') . ")";
    $sheetGrade->setCellValue("A$row", $gradeTitle);
    $sheetGrade->getStyle("A$row")->getFont()->setBold(true)->setSize(18);
    $sheetGrade->getStyle("A$row")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

    // Gender summary row
    $row++;
    $sheetGrade->mergeCells('A'.$row.':D'.$row);
    $sheetGrade->mergeCells('E'.$row.':H'.$row);
    $sheetGrade->mergeCells('I'.$row.':P'.$row);
    $sheetGrade->setCellValue('A'.$row, "Total Boys (Male): $boys");
    $sheetGrade->setCellValue('E'.$row, "Total Girls (Female): $girls");
    $sheetGrade->setCellValue('I'.$row, "Total Students: $total");
    $sheetGrade->getStyle('A'.$row.':P'.$row)->getFont()->setBold(true)->setSize(15);
    $sheetGrade->getStyle('A'.$row.':P'.$row)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER)->setVertical(Alignment::VERTICAL_CENTER);
    $sheetGrade->getStyle('A'.$row.':P'.$row)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB($summaryFill);

    // Header row
    $row++;
    $col = 'A';
    foreach ($headers as $header) {
        $sheetGrade->setCellValue($col . $row, $header);
        $col++;
    }
    $sheetGrade->getStyle("A$row:P$row")->applyFromArray([
        'font'=>['bold'=>true,'size'=>16,'name'=>'Arial'],
        'fill'=>['fillType'=>Fill::FILL_SOLID,'startColor'=>['rgb'=>$tableHeaderFill]],
        'alignment'=>['horizontal'=>Alignment::HORIZONTAL_CENTER, 'vertical'=>Alignment::VERTICAL_CENTER]
    ]);
    $sheetGrade->getRowDimension($row)->setRowHeight(28);

    // Student rows
    $dataStart = $row+1;
    $num = 1;
    $firstDataRow = $dataStart;
    foreach ($students_grade as $student) {
        $r = $dataStart++;
        $sheetGrade->setCellValue('A'.$r, $num++);
        $sheetGrade->setCellValueExplicit('B'.$r, (string)$student['lrn'], DataType::TYPE_STRING);
        $sheetGrade->setCellValue('C'.$r, toTitleCase($student['firstname']));
        $sheetGrade->setCellValue('D'.$r, toTitleCase($student['middlename']));
        $sheetGrade->setCellValue('E'.$r, toTitleCase($student['lastname']));
        $sheetGrade->setCellValue('F'.$r, $student['grade']);
        $sheetGrade->setCellValue('G'.$r, (string) (($student['strand'] ?? '') !== '' ? $student['strand'] : 'N/A'));
        $sheetGrade->setCellValue('H'.$r, $student['section']); // <--- SECTION!
        $sheetGrade->setCellValue('I'.$r, exportFormatDate($student['birthday'], '01-01-2020'));
        $sheetGrade->setCellValue('J'.$r, $student['age']);
        $sheetGrade->setCellValue('K'.$r, $student['gender']);
        $sheetGrade->setCellValue('L'.$r, $student['address']);
        $sheetGrade->setCellValue('M'.$r, $student['contact']);
        $sheetGrade->setCellValue('N'.$r, toTitleCase($student['guardian_name']));
        $sheetGrade->setCellValue('O'.$r, $student['guardian_contact']);
        $sheetGrade->setCellValue('P'.$r, exportFormatDate($student['date_enrolled'], '01-01-2025'));

        // Conditional row coloring by gender
        $rowRange = "A$r:P$r";
        if (strtolower($student['gender']) == 'female') {
            $sheetGrade->getStyle($rowRange)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB($femaleFill);
        } elseif (strtolower($student['gender']) == 'male') {
            $sheetGrade->getStyle($rowRange)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB($maleFill);
        }
        $sheetGrade->getRowDimension($r)->setRowHeight(26);
    }

    // Center all data cells and increase font size
    if ($firstDataRow < $dataStart) {
        $sheetGrade->getStyle("A$firstDataRow:P".($dataStart-1))->applyFromArray([
            'alignment'=>['horizontal'=>Alignment::HORIZONTAL_CENTER, 'vertical'=>Alignment::VERTICAL_CENTER],
            'font'=>['size'=>14]
        ]);
    }

    // Footer summary
    $footerRow = $dataStart + 1;
    $sheetGrade->mergeCells("A$footerRow:D$footerRow");
    $sheetGrade->mergeCells("E$footerRow:P$footerRow");
    $sheetGrade->setCellValue("A$footerRow", "Total Students: " . ($num-1));
    $sheetGrade->setCellValue("E$footerRow", "Exported: " . date('F j, Y, g:i A'));
    $sheetGrade->getStyle("A$footerRow:P$footerRow")->getFont()->setBold(true)->setSize(14);
    $sheetGrade->getStyle("A$footerRow:P$footerRow")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

    // Auto-size columns
    foreach (range('A', 'P') as $col) {
        $sheetGrade->getColumnDimension($col)->setAutoSize(true);
    }
    $sheetGrade->freezePane('A'.($row+1));
    $sheetGrade->setAutoFilter("A$row:P$row");
}

// ----------------------------
// EXPORT FILE
// ----------------------------
$filename = "Student-list";
if ($selected_school_year) {
    $filename .= "-" . preg_replace('/[^A-Za-z0-9]+/', '-', $selected_school_year);
}
$filename .= "-" . date('Y-m-d');
$filename_suffix = substr(str_shuffle("0123456789"), 0, 4);
$filename .= ($filename_suffix ? "-$filename_suffix" : "");
$filename .= ".xlsx";

include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');
if (function_exists('audit_log')) {
    $exportUser = $_SESSION['username'] ?? 'unknown';
    $exportDetails = 'Student list export | School Year: ' . ($selected_school_year !== '' ? $selected_school_year : 'All') .
        ' | Grade: ' . ($selected_grade !== '' ? $selected_grade : 'All') .
        ' | Search: ' . ($search_term !== '' ? $search_term : 'none') .
        ' | Sort: ' . $sort_order .
        ' | Role: ' . ($_SESSION['role'] ?? 'unknown');
    audit_log($conn, $exportUser, 'Exported student list report', 'Students', $exportDetails);
}

while (ob_get_level() > 0) {
    ob_end_clean();
}
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="' . $filename . '"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
?>
