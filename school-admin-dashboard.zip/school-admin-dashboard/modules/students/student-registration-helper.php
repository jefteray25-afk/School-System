﻿<?php

require_once __DIR__ . '/../settings/upload-storage-helper.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/../settings/settings-security.php';
require_once __DIR__ . '/../../includes/includes-receipt-helper.php';
require_once __DIR__ . '/../../includes/schema-migration.php';

function registration_ensure_session_started() {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
}

function registration_csrf_token() {
    // Standardized: use the app-wide CSRF token so all forms behave consistently.
    registration_ensure_session_started();
    return ensure_csrf_token();
}

function registration_verify_csrf(?string $token) {
    registration_ensure_session_started();
    return csrf_validate($token);
}

function registration_array_is_list(array $value): bool
{
    if (function_exists('array_is_list')) {
        return array_is_list($value);
    }

    return array_keys($value) === range(0, count($value) - 1);
}

function registration_client_ip(): string
{
    // Prefer the direct socket address. Only trust forwarded headers when the app is
    // behind a localhost reverse proxy on the same machine.
    $remoteAddr = trim((string) ($_SERVER['REMOTE_ADDR'] ?? ''));
    if ($remoteAddr !== '' && $remoteAddr !== '127.0.0.1' && $remoteAddr !== '::1') {
        return substr($remoteAddr, 0, 45);
    }

    $candidates = [
        $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '',
        $_SERVER['HTTP_CLIENT_IP'] ?? '',
        $remoteAddr,
    ];

    foreach ($candidates as $candidate) {
        if (!is_string($candidate) || trim($candidate) === '') {
            continue;
        }

        $parts = array_map('trim', explode(',', $candidate));
        foreach ($parts as $part) {
            if ($part !== '') {
                return substr($part, 0, 45);
            }
        }
    }

    return 'unknown';
}

function registration_allowlist_config(): array
{
    return [
        'allowed_exact_ips' => ['127.0.0.1', '::1'],
        'allowed_ipv4_ranges' => [
            ['prefix' => '192.168.1.', 'start' => 10, 'end' => 50],
        ],
        'blocked_message' => 'Access denied. Registration is only available on the campus network.',
    ];
}

function registration_ip_allowed(string $ip, ?array $config = null): bool
{
    $config = $config ?? registration_allowlist_config();
    $ip = trim($ip);
    if ($ip === '') {
        return false;
    }

    if (in_array($ip, $config['allowed_exact_ips'] ?? [], true)) {
        return true;
    }

    foreach (($config['allowed_ipv4_ranges'] ?? []) as $range) {
        $prefix = trim((string) ($range['prefix'] ?? ''));
        $start = (int) ($range['start'] ?? -1);
        $end = (int) ($range['end'] ?? -1);
        if ($prefix === '' || $start < 0 || $end < $start) {
            continue;
        }

        $pattern = '/^' . preg_quote($prefix, '/') . '(\d{1,3})$/';
        if (!preg_match($pattern, $ip, $matches)) {
            continue;
        }

        $octet = (int) $matches[1];
        if ($octet >= $start && $octet <= $end) {
            return true;
        }
    }

    return false;
}

function registration_allowlist_summary(?array $config = null): string
{
    $config = $config ?? registration_allowlist_config();
    $ranges = [];

    foreach (($config['allowed_ipv4_ranges'] ?? []) as $range) {
        $prefix = trim((string) ($range['prefix'] ?? ''));
        $start = (int) ($range['start'] ?? -1);
        $end = (int) ($range['end'] ?? -1);
        if ($prefix === '' || $start < 0 || $end < $start) {
            continue;
        }

        $ranges[] = $prefix . $start . ' - ' . $prefix . $end;
    }

    return implode(', ', $ranges);
}

function registration_ensure_rate_limit_table(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }

    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS student_registration_rate_limits (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        ip_address VARCHAR(45) NOT NULL,
        action_key VARCHAR(40) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_registration_rate_limit (ip_address, action_key, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
}

function registration_rate_limit_config(string $actionKey): array
{
    $config = [
        'check_lrn' => ['limit' => 20, 'window_minutes' => 10, 'message' => 'Too many LRN checks from this device. Please wait a few minutes and try again.'],
        'public_submit' => ['limit' => 60, 'window_minutes' => 20, 'message' => 'Too many registration submissions from this device. Please wait before trying again.'],
        // Used when an authenticated admin/operator encodes many students using the public form.
        // Keeps public anti-spam limits intact while allowing controlled bulk encoding.
        'operator_submit' => ['limit' => 200, 'window_minutes' => 60, 'message' => 'Too many operator submissions from this device. Please wait before trying again.'],
        'offline_import' => ['limit' => 20, 'window_minutes' => 20, 'message' => 'Too many offline sync requests from this device. Please wait before syncing again.'],
        'allowlist_block' => ['limit' => 6, 'window_minutes' => 30, 'message' => 'Blocked registration access recorded.'],
    ];

    return $config[$actionKey] ?? ['limit' => 10, 'window_minutes' => 15, 'message' => 'Too many requests from this device. Please wait and try again.'];
}

function registration_rate_limit_status(mysqli $conn, string $actionKey, ?string $ipAddress = null): array
{
    registration_ensure_rate_limit_table($conn);
    $ipAddress = trim((string) ($ipAddress ?: registration_client_ip()));
    $config = registration_rate_limit_config($actionKey);

    $stmt = $conn->prepare("
        SELECT COUNT(*) AS attempt_count,
               MIN(created_at) AS first_attempt_at
        FROM student_registration_rate_limits
        WHERE ip_address = ?
          AND action_key = ?
          AND created_at >= (NOW() - INTERVAL ? MINUTE)
    ");
    $stmt->bind_param('ssi', $ipAddress, $actionKey, $config['window_minutes']);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result ? $result->fetch_assoc() : null;
    $stmt->close();

    $attemptCount = (int) ($row['attempt_count'] ?? 0);
    $remaining = max(0, (int) $config['limit'] - $attemptCount);
    $retryAfter = 0;

    if ($attemptCount >= (int) $config['limit'] && !empty($row['first_attempt_at'])) {
        $firstAttempt = strtotime((string) $row['first_attempt_at']);
        if ($firstAttempt !== false) {
            $windowEndsAt = $firstAttempt + (((int) $config['window_minutes']) * 60);
            $retryAfter = max(0, $windowEndsAt - time());
        }
    }

    return [
        'allowed' => $attemptCount < (int) $config['limit'],
        'attempt_count' => $attemptCount,
        'limit' => (int) $config['limit'],
        'window_minutes' => (int) $config['window_minutes'],
        'retry_after' => $retryAfter,
        'message' => $config['message'],
        'ip_address' => $ipAddress,
        'remaining' => $remaining,
    ];
}

function registration_rate_limit_record(mysqli $conn, string $actionKey, ?string $ipAddress = null): void
{
    registration_ensure_rate_limit_table($conn);
    $ipAddress = trim((string) ($ipAddress ?: registration_client_ip()));
    $stmt = $conn->prepare("INSERT INTO student_registration_rate_limits (ip_address, action_key) VALUES (?, ?)");
    if ($stmt) {
        $stmt->bind_param('ss', $ipAddress, $actionKey);
        $stmt->execute();
        $stmt->close();
    }
}

function registration_record_blocked_allowlist_attempt(mysqli $conn, string $ipAddress, string $entryPoint = 'public_form'): void
{
    $status = registration_rate_limit_status($conn, 'allowlist_block', $ipAddress);
    if (!$status['allowed']) {
        return;
    }

    registration_rate_limit_record($conn, 'allowlist_block', $ipAddress);
    if (function_exists('audit_log')) {
        audit_log(
            $conn,
            'public-registration',
            'Blocked registration access',
            'Students',
            'IP: ' . $ipAddress . ' | Entry Point: ' . $entryPoint . ' | Reason: outside registration allowlist',
            'WARNING'
        );
    }
}

function registration_get_grade_levels() {
    return [
        "Junior Kindergarten" => 101,
        "Senior Kindergarten" => 102,
        "Grade 1" => 1,
        "Grade 2" => 2,
        "Grade 3" => 3,
        "Grade 4" => 4,
        "Grade 5" => 5,
        "Grade 6" => 6,
        "Grade 7" => 7,
        "Grade 8" => 8,
        "Grade 9" => 9,
        "Grade 10" => 10,
        "Grade 11" => 11,
        "Grade 12" => 12,
    ];
}

function registration_get_grades() {
    return array_keys(registration_get_grade_levels());
}

function registration_normalize_lrn_value($lrn) {
    $normalized = preg_replace('/\D/', '', (string) $lrn);
    return $normalized === '' ? null : $normalized;
}

function registration_normalize_submission(array $input) {
    return [
        'lastname' => trim((string) ($input['lastname'] ?? '')),
        'firstname' => trim((string) ($input['firstname'] ?? '')),
        'middlename' => trim((string) ($input['middlename'] ?? '')),
        'lrn' => registration_normalize_lrn_value($input['lrn'] ?? ''),
        'birthday' => trim((string) ($input['birthday'] ?? '')),
        'age' => trim((string) ($input['age'] ?? '')),
        'gender' => trim((string) ($input['gender'] ?? '')),
        'address' => trim((string) ($input['address'] ?? '')),
        'contact' => trim((string) ($input['contact'] ?? '')),
        'grade' => trim((string) ($input['grade'] ?? '')),
        'strand' => trim((string) ($input['strand'] ?? '')),
        'section' => trim((string) ($input['section'] ?? '')),
        'date_enrolled' => trim((string) ($input['date_enrolled'] ?? '')),
        'school_year_label' => trim((string) ($input['school_year_label'] ?? '')),
        'photo' => trim((string) ($input['photo'] ?? '')),
        'guardian_name' => trim((string) ($input['guardian_name'] ?? '')),
        'guardian_contact' => trim((string) ($input['guardian_contact'] ?? '')),
        'source_channel' => trim((string) ($input['source_channel'] ?? 'public_online')),
        'source_station' => trim((string) ($input['source_station'] ?? '')),
        'source_details' => trim((string) ($input['source_details'] ?? '')),
    ];
}

function registration_validate_submission(array $data) {
    $contactPattern = '/^09\d{2}-\d{3}-\d{4}$/';
    $guardianContactPattern = '/^09\d{2}-\d{3}-\d{4}$/';
    $guardianDigits = preg_replace('/[^0-9]/', '', $data['guardian_contact']);

    if (
        !$data['lastname'] || !$data['firstname'] || !$data['birthday'] || !$data['age'] ||
        !$data['gender'] || !$data['address'] || !$data['contact'] || !$data['grade'] ||
        !$data['date_enrolled'] || !$data['guardian_name']
    ) {
        return 'All fields are required except Middle Name, Grade Section, Guardian Contact, and Photo.';
    }

    if ($data['lrn'] !== null && !preg_match('/^\d{12}$/', $data['lrn'])) {
        return 'LRN must be exactly 12 digits.';
    }

    if (!preg_match($contactPattern, $data['contact'])) {
        return 'Contact number format must be 09xx-xxx-xxxx.';
    }

    if ($data['guardian_contact'] !== '' && (!preg_match($guardianContactPattern, $data['guardian_contact']) || strlen($guardianDigits) !== 11)) {
        return 'Guardian contact number format must be 09xx-xxx-xxxx and exactly 11 digits.';
    }

    if (in_array($data['grade'], ['Grade 11', 'Grade 12'], true) && !in_array($data['strand'], registration_get_strand_options(), true)) {
        return 'Select a valid strand for Grade 11 or Grade 12.';
    }

    return '';
}

function registration_ensure_pending_table(mysqli $conn) {
    school_year_ensure_table($conn);
    registration_ensure_rate_limit_table($conn);
    $sql = "CREATE TABLE IF NOT EXISTS student_registration_pending (
        id INT AUTO_INCREMENT PRIMARY KEY,
        lastname VARCHAR(50) NOT NULL,
        firstname VARCHAR(50) NOT NULL,
        middlename VARCHAR(50) NOT NULL DEFAULT '',
        lrn VARCHAR(20) DEFAULT NULL,
        birthday DATE NOT NULL,
        age INT NOT NULL,
        gender VARCHAR(10) NOT NULL,
        address VARCHAR(255) NOT NULL,
        contact VARCHAR(15) NOT NULL,
        grade VARCHAR(20) NOT NULL,
        strand VARCHAR(20) NOT NULL DEFAULT '',
        section VARCHAR(50) NOT NULL DEFAULT '',
        date_enrolled DATE NOT NULL,
        photo VARCHAR(255) DEFAULT NULL,
        guardian_name VARCHAR(255) NOT NULL,
        guardian_contact VARCHAR(20) NOT NULL DEFAULT '',
        status VARCHAR(20) NOT NULL DEFAULT 'Pending',
        review_notes TEXT DEFAULT NULL,
        submitted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        reviewed_at DATETIME DEFAULT NULL,
        reviewed_by VARCHAR(100) DEFAULT NULL,
        approved_student_id INT DEFAULT NULL,
        source_channel VARCHAR(40) NOT NULL DEFAULT 'public_online',
        source_station VARCHAR(100) DEFAULT NULL,
        source_ip VARCHAR(45) DEFAULT NULL,
        source_details TEXT DEFAULT NULL,
        INDEX idx_registration_pending_lrn (lrn),
        INDEX idx_registration_pending_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    if (schema_migration_mode_enabled()) {
        if (!schema_migration_attempt($conn, $sql)) {
            return false;
        }
    }

    registration_ensure_pending_table_columns($conn);
    registration_ensure_lrn_database_guards($conn);

    return true;
}

function registration_column_exists(mysqli $conn, string $table, string $column) {
    $safeTable = $conn->real_escape_string($table);
    $safeColumn = $conn->real_escape_string($column);
    $sql = "SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '{$safeTable}' AND COLUMN_NAME = '{$safeColumn}'";
    $result = $conn->query($sql);
    return $result && $result->num_rows > 0;
}

function registration_trigger_exists(mysqli $conn, string $triggerName) {
    $safeTrigger = $conn->real_escape_string($triggerName);
    $sql = "SELECT 1 FROM INFORMATION_SCHEMA.TRIGGERS WHERE TRIGGER_SCHEMA = DATABASE() AND TRIGGER_NAME = '{$safeTrigger}'";
    $result = $conn->query($sql);
    return $result && $result->num_rows > 0;
}

function registration_trigger_statement(mysqli $conn, string $triggerName): string
{
    $safeTrigger = $conn->real_escape_string($triggerName);
    $sql = "SELECT ACTION_STATEMENT FROM INFORMATION_SCHEMA.TRIGGERS WHERE TRIGGER_SCHEMA = DATABASE() AND TRIGGER_NAME = '{$safeTrigger}' LIMIT 1";
    $result = $conn->query($sql);
    if (!$result) {
        return '';
    }

    $row = $result->fetch_assoc() ?: [];
    $result->close();

    return (string) ($row['ACTION_STATEMENT'] ?? '');
}

function registration_ensure_pending_table_columns(mysqli $conn) {
    if (!schema_migration_mode_enabled()) {
        return;
    }
    $columns = [
        "ALTER TABLE student_registration_pending MODIFY lrn VARCHAR(20) NULL",
        "ALTER TABLE students MODIFY lrn VARCHAR(20) NULL",
    ];

    foreach ($columns as $sql) {
        @schema_migration_attempt($conn, $sql);
    }

    $extraColumns = [
        'strand' => "ALTER TABLE student_registration_pending ADD COLUMN strand VARCHAR(20) NOT NULL DEFAULT '' AFTER grade",
        'source_channel' => "ALTER TABLE student_registration_pending ADD COLUMN source_channel VARCHAR(40) NOT NULL DEFAULT 'public_online'",
        'source_station' => "ALTER TABLE student_registration_pending ADD COLUMN source_station VARCHAR(100) DEFAULT NULL",
        'source_ip' => "ALTER TABLE student_registration_pending ADD COLUMN source_ip VARCHAR(45) DEFAULT NULL",
        'source_details' => "ALTER TABLE student_registration_pending ADD COLUMN source_details TEXT DEFAULT NULL",
    ];

    foreach ($extraColumns as $column => $sql) {
        if (!registration_column_exists($conn, 'student_registration_pending', $column)) {
            @schema_migration_attempt($conn, $sql);
        }
    }

    @schema_migration_attempt($conn, "UPDATE students SET lrn = NULL WHERE lrn IS NOT NULL AND TRIM(lrn) = ''");
    @schema_migration_attempt($conn, "UPDATE student_registration_pending SET lrn = NULL WHERE lrn IS NOT NULL AND TRIM(lrn) = ''");
}

function registration_ensure_student_strand_column(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }
    if (!registration_column_exists($conn, 'students', 'strand')) {
        @schema_migration_attempt($conn, "ALTER TABLE students ADD COLUMN strand VARCHAR(20) NOT NULL DEFAULT '' AFTER grade");
    }
}

function registration_get_strand_options(): array
{
    return ['HUMMS', 'ABM', 'GAS', 'TVL', 'STEM'];
}

function student_transaction_summary(mysqli $conn, int $studentId): array
{
    if ($studentId <= 0) {
        return [
            'has_transactions' => false,
            'payment_count' => 0,
            'latest_payment_date' => '',
        ];
    }

    ensure_receipts_registry_schema($conn);
    $stmt = $conn->prepare("
        SELECT
            COUNT(*) AS payment_count,
            MAX(p.date_paid) AS latest_payment_date
        FROM payments p
        INNER JOIN accounts a
            ON a.id = p.account_id
        LEFT JOIN receipts_registry rr
            ON rr.receipt_no = p.receipt_no
           AND rr.booklet_no = p.booklet_no
           AND rr.voided = 0
           AND rr.used_by IN ('payments', 'other_payment')
        WHERE a.student_id = ?
          AND (
                (p.booklet_no IS NULL OR p.receipt_no IS NULL)
                OR rr.receipt_no IS NOT NULL
          )
    ");
    if (!$stmt) {
        return [
            'has_transactions' => false,
            'payment_count' => 0,
            'latest_payment_date' => '',
        ];
    }

    $stmt->bind_param('i', $studentId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc() ?: [];
    $stmt->close();

    $paymentCount = (int) ($row['payment_count'] ?? 0);
    return [
        'has_transactions' => $paymentCount > 0,
        'payment_count' => $paymentCount,
        'latest_payment_date' => (string) ($row['latest_payment_date'] ?? ''),
    ];
}

function student_has_financial_transactions(mysqli $conn, int $studentId): bool
{
    return student_transaction_summary($conn, $studentId)['has_transactions'];
}

function registration_ensure_lrn_database_guards(mysqli $conn) {
    static $checked = false;
    if ($checked) {
        return;
    }

    $triggers = [
        'trg_students_lrn_insert' => "
            CREATE TRIGGER trg_students_lrn_insert
            BEFORE INSERT ON students
            FOR EACH ROW
            BEGIN
                IF NEW.lrn IS NOT NULL AND TRIM(NEW.lrn) = '' THEN
                    SET NEW.lrn = NULL;
                END IF;
                IF NEW.lrn IS NOT NULL AND EXISTS (
                    SELECT 1
                    FROM students s
                    WHERE s.lrn = NEW.lrn
                      AND COALESCE(NULLIF(TRIM(s.school_year_label), ''), '') = COALESCE(NULLIF(TRIM(NEW.school_year_label), ''), '')
                ) THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Duplicate LRN is not allowed in students for the same school year.';
                END IF;
            END",
        'trg_students_lrn_update' => "
            CREATE TRIGGER trg_students_lrn_update
            BEFORE UPDATE ON students
            FOR EACH ROW
            BEGIN
                IF NEW.lrn IS NOT NULL AND TRIM(NEW.lrn) = '' THEN
                    SET NEW.lrn = NULL;
                END IF;
                IF NEW.lrn IS NOT NULL AND EXISTS (
                    SELECT 1
                    FROM students s
                    WHERE s.lrn = NEW.lrn
                      AND s.id <> OLD.id
                      AND COALESCE(NULLIF(TRIM(s.school_year_label), ''), '') = COALESCE(NULLIF(TRIM(NEW.school_year_label), ''), '')
                ) THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Duplicate LRN is not allowed in students for the same school year.';
                END IF;
            END",
        'trg_pending_lrn_insert' => "
            CREATE TRIGGER trg_pending_lrn_insert
            BEFORE INSERT ON student_registration_pending
            FOR EACH ROW
            BEGIN
                IF NEW.lrn IS NOT NULL AND TRIM(NEW.lrn) = '' THEN
                    SET NEW.lrn = NULL;
                END IF;
                IF NEW.lrn IS NOT NULL AND EXISTS (
                    SELECT 1
                    FROM students s
                    WHERE s.lrn = NEW.lrn
                      AND COALESCE(NULLIF(TRIM(s.school_year_label), ''), '') = COALESCE(NULLIF(TRIM(NEW.school_year_label), ''), '')
                ) THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Duplicate LRN is not allowed in students for the same school year.';
                END IF;
                IF NEW.lrn IS NOT NULL AND EXISTS (
                    SELECT 1
                    FROM student_registration_pending p
                    WHERE p.lrn = NEW.lrn
                      AND COALESCE(NULLIF(TRIM(p.school_year_label), ''), '') = COALESCE(NULLIF(TRIM(NEW.school_year_label), ''), '')
                ) THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Duplicate LRN is not allowed in pending registrations for the same school year.';
                END IF;
            END",
        'trg_pending_lrn_update' => "
            CREATE TRIGGER trg_pending_lrn_update
            BEFORE UPDATE ON student_registration_pending
            FOR EACH ROW
            BEGIN
                IF NEW.lrn IS NOT NULL AND TRIM(NEW.lrn) = '' THEN
                    SET NEW.lrn = NULL;
                END IF;
                IF NEW.lrn IS NOT NULL AND NEW.status <> 'Approved' AND EXISTS (
                    SELECT 1
                    FROM students s
                    WHERE s.lrn = NEW.lrn
                      AND COALESCE(NULLIF(TRIM(s.school_year_label), ''), '') = COALESCE(NULLIF(TRIM(NEW.school_year_label), ''), '')
                ) THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Duplicate LRN is not allowed in students for the same school year.';
                END IF;
                IF NEW.lrn IS NOT NULL AND NEW.status <> 'Approved' AND EXISTS (
                    SELECT 1
                    FROM student_registration_pending p
                    WHERE p.lrn = NEW.lrn
                      AND p.id <> OLD.id
                      AND COALESCE(NULLIF(TRIM(p.school_year_label), ''), '') = COALESCE(NULLIF(TRIM(NEW.school_year_label), ''), '')
                ) THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Duplicate LRN is not allowed in pending registrations for the same school year.';
                END IF;
            END",
    ];

    foreach ($triggers as $name => $sql) {
        $statement = registration_trigger_statement($conn, $name);
        $needsRefresh = $statement === ''
            || stripos($statement, 'school_year_label') === false
            || stripos($statement, 'same school year') === false;

        if ($needsRefresh && $statement !== '') {
            @$conn->query("DROP TRIGGER IF EXISTS {$name}");
        }

        if ($needsRefresh) {
            @$conn->query($sql);
        }
    }

    $checked = true;
}

function registration_duplicate_school_year_label(mysqli $conn, ?string $schoolYearLabel = null): string
{
    $label = trim((string) ($schoolYearLabel ?? ''));
    if ($label !== '') {
        return $label;
    }

    return school_year_get_active_label($conn);
}

function registration_find_duplicate(mysqli $conn, $lrn, ?int $excludePendingId = null, ?string $schoolYearLabel = null) {
    $lrn = registration_normalize_lrn_value($lrn);
    $duplicate = [
        'has_duplicate' => false,
        'in_students' => false,
        'in_pending' => false,
        'message' => '',
    ];

    if ($lrn === null) {
        return $duplicate;
    }

    $schoolYearLabel = registration_duplicate_school_year_label($conn, $schoolYearLabel);

    $studentStmt = $conn->prepare("
        SELECT id
        FROM students
        WHERE lrn = ?
          AND COALESCE(NULLIF(TRIM(school_year_label), ''), '') = COALESCE(NULLIF(TRIM(?), ''), '')
        LIMIT 1
    ");
    $studentStmt->bind_param("ss", $lrn, $schoolYearLabel);
    $studentStmt->execute();
    $studentStmt->store_result();
    $duplicate['in_students'] = $studentStmt->num_rows > 0;
    $studentStmt->close();

    if ($excludePendingId) {
        $pendingStmt = $conn->prepare("
            SELECT id
            FROM student_registration_pending
            WHERE lrn = ?
              AND status IN ('Pending', 'Approved')
              AND id <> ?
              AND COALESCE(NULLIF(TRIM(school_year_label), ''), '') = COALESCE(NULLIF(TRIM(?), ''), '')
            LIMIT 1
        ");
        $pendingStmt->bind_param("sis", $lrn, $excludePendingId, $schoolYearLabel);
    } else {
        $pendingStmt = $conn->prepare("
            SELECT id
            FROM student_registration_pending
            WHERE lrn = ?
              AND status IN ('Pending', 'Approved')
              AND COALESCE(NULLIF(TRIM(school_year_label), ''), '') = COALESCE(NULLIF(TRIM(?), ''), '')
            LIMIT 1
        ");
        $pendingStmt->bind_param("ss", $lrn, $schoolYearLabel);
    }
    $pendingStmt->execute();
    $pendingStmt->store_result();
    $duplicate['in_pending'] = $pendingStmt->num_rows > 0;
    $pendingStmt->close();

    $duplicate['has_duplicate'] = $duplicate['in_students'] || $duplicate['in_pending'];
    if ($duplicate['in_students']) {
        $duplicate['message'] = 'This LRN already exists in the student records for the same school year.';
    } elseif ($duplicate['in_pending']) {
        $duplicate['message'] = 'This LRN already has a pending or approved registration request for the same school year.';
    }

    return $duplicate;
}

function registration_insert_pending(mysqli $conn, array $data) {
    $data = registration_normalize_submission($data);
    if ($data['school_year_label'] === '') {
        $data['school_year_label'] = school_year_get_active_label($conn);
    }
    $validationError = registration_validate_submission($data);
    if ($validationError !== '') {
        return ['success' => false, 'message' => $validationError];
    }

    $duplicate = registration_find_duplicate($conn, $data['lrn'], null, $data['school_year_label']);
    if ($duplicate['has_duplicate']) {
        return ['success' => false, 'message' => $duplicate['message']];
    }

    $sourceIp = trim((string) ($data['source_ip'] ?? registration_client_ip()));
    $insertStmt = $conn->prepare("INSERT INTO student_registration_pending (lastname, firstname, middlename, lrn, birthday, age, gender, address, contact, grade, strand, section, date_enrolled, school_year_label, photo, guardian_name, guardian_contact, source_channel, source_station, source_ip, source_details) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $insertStmt->bind_param(
        "sssssssssssssssssssss",
        $data['lastname'],
        $data['firstname'],
        $data['middlename'],
        $data['lrn'],
        $data['birthday'],
        $data['age'],
        $data['gender'],
        $data['address'],
        $data['contact'],
        $data['grade'],
        $data['strand'],
        $data['section'],
        $data['date_enrolled'],
        $data['school_year_label'],
        $data['photo'],
        $data['guardian_name'],
        $data['guardian_contact'],
        $data['source_channel'],
        $data['source_station'],
        $sourceIp,
        $data['source_details']
    );

    try {
        $success = $insertStmt->execute();
        $insertId = (int) $insertStmt->insert_id;
        $insertStmt->close();
    } catch (Throwable $e) {
        $insertStmt->close();
        return ['success' => false, 'message' => $e->getMessage() ?: 'Could not submit registration right now.'];
    }

    if (!$success) {
        return ['success' => false, 'message' => 'Could not submit registration right now.'];
    }

    return ['success' => true, 'id' => $insertId];
}

function registration_extract_import_rows($payload): array
{
    if (!is_array($payload)) {
        return [];
    }

    if (registration_array_is_list($payload)) {
        return $payload;
    }

    $records = $payload['records'] ?? null;
    if (!is_array($records)) {
        return [];
    }

    $defaults = [
        'source_channel' => trim((string) ($payload['source_channel'] ?? 'offline_saved')),
        'source_station' => trim((string) ($payload['source_station'] ?? '')),
        'source_details' => trim((string) ($payload['source_details'] ?? 'Imported offline JSON')),
    ];

    $rows = [];
    foreach ($records as $record) {
        if (!is_array($record)) {
            $rows[] = $record;
            continue;
        }

        $rows[] = array_merge($defaults, $record);
    }

    return $rows;
}

function registration_import_pending_batch(mysqli $conn, array $rows) {
    $summary = [
        'imported' => 0,
        'skipped' => 0,
        'errors' => [],
    ];

    foreach ($rows as $index => $row) {
        if (!is_array($row)) {
            $summary['skipped']++;
            $summary['errors'][] = 'Row ' . ($index + 1) . ': invalid record format.';
            continue;
        }

        $result = registration_insert_pending($conn, $row);
        if ($result['success']) {
            $summary['imported']++;
        } else {
            $summary['skipped']++;
            $name = trim((string) (($row['lastname'] ?? '') . ', ' . ($row['firstname'] ?? '')), ', ');
            $label = $name !== '' ? $name : ('Row ' . ($index + 1));
            $summary['errors'][] = $label . ': ' . $result['message'];
        }
    }

    return $summary;
}

function registration_get_pending_by_id(mysqli $conn, int $pendingId) {
    $stmt = $conn->prepare("SELECT * FROM student_registration_pending WHERE id = ? LIMIT 1");
    if (!$stmt) {
        return null;
    }

    $stmt->bind_param('i', $pendingId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result ? $result->fetch_assoc() : null;
    $stmt->close();
    return $row ?: null;
}

function registration_update_pending(mysqli $conn, int $pendingId, array $data) {
    $existing = registration_get_pending_by_id($conn, $pendingId);
    if (!$existing) {
        return ['success' => false, 'message' => 'Pending registration request not found.'];
    }

    if (($existing['status'] ?? '') !== 'Pending') {
        return ['success' => false, 'message' => 'Only pending registration requests can be edited.'];
    }

    $data = registration_normalize_submission(array_merge($existing, $data));
    if ($data['school_year_label'] === '') {
        $data['school_year_label'] = (string) ($existing['school_year_label'] ?? school_year_get_active_label($conn));
    }
    $validationError = registration_validate_submission($data);
    if ($validationError !== '') {
        return ['success' => false, 'message' => $validationError];
    }

    $duplicate = registration_find_duplicate($conn, $data['lrn'], $pendingId, $data['school_year_label']);
    if ($duplicate['has_duplicate']) {
        return ['success' => false, 'message' => $duplicate['message']];
    }

    $stmt = $conn->prepare("UPDATE student_registration_pending
        SET lastname = ?, firstname = ?, middlename = ?, lrn = ?, birthday = ?, age = ?, gender = ?, address = ?, contact = ?, grade = ?, strand = ?, section = ?, date_enrolled = ?, school_year_label = ?, photo = ?, guardian_name = ?, guardian_contact = ?
        WHERE id = ? AND status = 'Pending'
        LIMIT 1");
    if (!$stmt) {
        return ['success' => false, 'message' => 'Could not prepare the update request.'];
    }

    $stmt->bind_param(
        'sssssssssssssssssi',
        $data['lastname'],
        $data['firstname'],
        $data['middlename'],
        $data['lrn'],
        $data['birthday'],
        $data['age'],
        $data['gender'],
        $data['address'],
        $data['contact'],
        $data['grade'],
        $data['strand'],
        $data['section'],
        $data['date_enrolled'],
        $data['school_year_label'],
        $data['photo'],
        $data['guardian_name'],
        $data['guardian_contact'],
        $pendingId
    );

    try {
        $success = $stmt->execute();
        $affected = $stmt->affected_rows;
        $stmt->close();
    } catch (Throwable $e) {
        $stmt->close();
        return ['success' => false, 'message' => $e->getMessage() ?: 'Could not update the pending registration.'];
    }

    if (!$success) {
        return ['success' => false, 'message' => 'Could not update the pending registration.'];
    }

    return [
        'success' => true,
        'message' => $affected > 0 ? 'Pending registration updated successfully.' : 'No changes were saved.',
        'record' => registration_get_pending_by_id($conn, $pendingId),
    ];
}

function registration_upload_photo(array $file, string $grade, string $lastname, string $firstname, string $prefix = 'pending') {
    global $conn;

    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['path' => '', 'error' => ''];
    }
    return student_photo_store_uploaded_file($conn, $file, $grade, $lastname, $firstname, $prefix);
}

function registration_move_photo_to_student_folder(?string $photoPath, string $grade, string $lastname, string $firstname) {
    global $conn;
    return student_photo_move_between_folders($conn, $photoPath, $grade, $lastname, $firstname);
}

function registration_create_student_accounts(mysqli $conn, int $studentId, string $grade) {
    $gradeLevels = registration_get_grade_levels();
    $gradeLevelNum = $gradeLevels[$grade] ?? 0;
    if ($gradeLevelNum <= 0) {
        return true;
    }

    $studentName = '';
    $studentNameStmt = $conn->prepare("SELECT lastname, firstname, middlename FROM students WHERE id = ? LIMIT 1");
    if ($studentNameStmt) {
        $studentNameStmt->bind_param("i", $studentId);
        $studentNameStmt->execute();
        $studentNameStmt->bind_result($ln, $fn, $mn);
        if ($studentNameStmt->fetch()) {
            $studentName = trim(implode(' ', array_filter([
                trim((string) $ln),
                trim((string) $fn),
                trim((string) $mn),
            ])));
        }
        $studentNameStmt->close();
    }

    school_year_ensure_finance_columns($conn);
    $studentSchoolYear = school_year_get_active_label($conn);
    $studentYearStmt = $conn->prepare("SELECT school_year_label FROM students WHERE id = ? LIMIT 1");
    if ($studentYearStmt) {
        $studentYearStmt->bind_param("i", $studentId);
        $studentYearStmt->execute();
        $studentYearStmt->bind_result($studentYearLabel);
        if ($studentYearStmt->fetch() && trim((string) $studentYearLabel) !== '') {
            $studentSchoolYear = trim((string) $studentYearLabel);
        }
        $studentYearStmt->close();
    }

    $feesStmt = $conn->prepare("SELECT at.name, f.amount, f.school_year_label FROM fee f JOIN account_types at ON f.fee_type_id = at.id WHERE f.grade_level = ? AND (f.school_year_label = ? OR f.school_year_label IS NULL OR TRIM(f.school_year_label) = '') ORDER BY CASE WHEN f.school_year_label = ? THEN 0 ELSE 1 END, at.priority ASC, at.name ASC");
    $feesStmt->bind_param("iss", $gradeLevelNum, $studentSchoolYear, $studentSchoolYear);
    $feesStmt->execute();
    $feesStmt->bind_result($type, $balance, $feeSchoolYear);

    $feeRows = [];
    while ($feesStmt->fetch()) {
        if (!isset($feeRows[$type])) {
            $feeRows[$type] = ['type' => $type, 'balance' => $balance, 'school_year_label' => trim((string) $feeSchoolYear) !== '' ? $feeSchoolYear : $studentSchoolYear];
        }
    }
    $feesStmt->close();
    $feeRows = array_values($feeRows);

    foreach ($feeRows as $fee) {
        $existingStmt = $conn->prepare("SELECT id FROM accounts WHERE student_id = ? AND type = ? AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ? LIMIT 1");
        if (!$existingStmt) {
            return false;
        }
        $existingStmt->bind_param("isss", $studentId, $fee['type'], $studentSchoolYear, $studentSchoolYear);
        $existingStmt->execute();
        $existingStmt->bind_result($existingAccountId);
        $hasExisting = $existingStmt->fetch();
        $existingStmt->close();

        if ($hasExisting) {
            continue;
        }

        $notes = "Auto-created from fee setup";
        $accountStmt = $conn->prepare("INSERT INTO accounts (student_id, name, type, balance, notes, school_year_label) VALUES (?, ?, ?, ?, ?, ?)");
        $accountStmt->bind_param("issdss", $studentId, $studentName, $fee['type'], $fee['balance'], $notes, $studentSchoolYear);
        if (!$accountStmt->execute()) {
            $accountStmt->close();
            return false;
        }
        $accountStmt->close();
    }

    return true;
}

function registration_approve_pending(mysqli $conn, int $pendingId, string $reviewedBy) {
    $conn->begin_transaction();

    try {
        $pendingStmt = $conn->prepare("SELECT id, lastname, firstname, middlename, lrn, birthday, age, gender, address, contact, grade, strand, section, date_enrolled, school_year_label, photo, guardian_name, guardian_contact, status FROM student_registration_pending WHERE id = ? FOR UPDATE");
        $pendingStmt->bind_param("i", $pendingId);
        $pendingStmt->execute();
        $pendingRow = $pendingStmt->get_result()->fetch_assoc();
        $pendingStmt->close();

        if (!$pendingRow) {
            throw new RuntimeException('Registration request not found.');
        }

        if ($pendingRow['status'] !== 'Pending') {
            throw new RuntimeException('Only pending registration requests can be approved.');
        }

        $duplicate = registration_find_duplicate($conn, $pendingRow['lrn'], $pendingId, (string) ($pendingRow['school_year_label'] ?? ''));
        if ($duplicate['has_duplicate']) {
            throw new RuntimeException($duplicate['message']);
        }

        $finalPhotoPath = registration_move_photo_to_student_folder(
            $pendingRow['photo'] ?? '',
            $pendingRow['grade'],
            $pendingRow['lastname'],
            $pendingRow['firstname']
        );

        $studentStmt = $conn->prepare("INSERT INTO students (lastname, firstname, middlename, lrn, birthday, age, gender, address, contact, grade, strand, section, date_enrolled, school_year_label, photo, guardian_name, guardian_contact) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $studentStmt->bind_param(
            "sssssssssssssssss",
            $pendingRow['lastname'],
            $pendingRow['firstname'],
            $pendingRow['middlename'],
            $pendingRow['lrn'],
            $pendingRow['birthday'],
            $pendingRow['age'],
            $pendingRow['gender'],
            $pendingRow['address'],
            $pendingRow['contact'],
            $pendingRow['grade'],
            $pendingRow['strand'],
            $pendingRow['section'],
            $pendingRow['date_enrolled'],
            $pendingRow['school_year_label'],
            $finalPhotoPath,
            $pendingRow['guardian_name'],
            $pendingRow['guardian_contact']
        );

        if (!$studentStmt->execute()) {
            throw new RuntimeException('Could not create student record.');
        }

        $studentId = (int) $studentStmt->insert_id;
        $studentStmt->close();

        $accountsCreated = registration_create_student_accounts($conn, $studentId, $pendingRow['grade']);

        $updateStmt = $conn->prepare("UPDATE student_registration_pending SET status = 'Approved', reviewed_by = ?, reviewed_at = NOW(), approved_student_id = ?, photo = ?, review_notes = NULL WHERE id = ?");
        $updateStmt->bind_param("sisi", $reviewedBy, $studentId, $finalPhotoPath, $pendingId);
        if (!$updateStmt->execute()) {
            throw new RuntimeException('Could not update registration status.');
        }
        $updateStmt->close();

        $conn->commit();

        $message = '';
        if (!$accountsCreated) {
            $message = 'Student was approved, but accounts could not be created automatically. You can sync/create fee accounts from Finance after confirming fee setup for this grade and school year.';
        }

        return [
            'success' => true,
            'student_id' => $studentId,
            'student_name' => $pendingRow['lastname'] . ', ' . $pendingRow['firstname'],
            'lrn' => $pendingRow['lrn'],
            'accounts_created' => (bool) $accountsCreated,
            'message' => $message,
        ];
    } catch (Throwable $e) {
        $conn->rollback();
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

function registration_reject_pending(mysqli $conn, int $pendingId, string $reviewedBy, string $reason = '') {
    $stmt = $conn->prepare("UPDATE student_registration_pending SET status = 'Rejected', reviewed_by = ?, reviewed_at = NOW(), review_notes = ? WHERE id = ? AND status = 'Pending'");
    $stmt->bind_param("ssi", $reviewedBy, $reason, $pendingId);
    $stmt->execute();
    $affected = $stmt->affected_rows;
    $stmt->close();

    if ($affected < 1) {
        return ['success' => false, 'message' => 'Registration request was already reviewed or could not be updated.'];
    }

    return ['success' => true];
}




