<?php
ob_start();

require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/upload-storage-helper.php';
require_once __DIR__ . '/student-photo-bulk-helper.php';

if (!can_access_bulk_photo_attachment((string) ($_SESSION['role'] ?? ''))) {
    admin_session_forbidden();
}

$schoolYear = trim((string) ($_GET['school_year'] ?? ''));
$grade = trim((string) ($_GET['grade'] ?? ''));
$section = trim((string) ($_GET['section'] ?? ''));
$filename = basename((string) ($_GET['file'] ?? ''));
$settings = upload_storage_get($conn);
$directory = student_photo_bulk_inbox_scope_dir($settings, $schoolYear, $grade, $section);
$path = $directory . '/' . $filename;
$extension = strtolower((string) pathinfo($filename, PATHINFO_EXTENSION));

if ($schoolYear === '' || student_photo_grade_code($grade) === '' || $section === '' || $filename === '' || !in_array($extension, ['jpg', 'jpeg', 'png'], true) || !is_file($path) || !@getimagesize($path)) {
    while (ob_get_level() > 0) { ob_end_clean(); }
    http_response_code(404);
    exit('Preview image not found.');
}

while (ob_get_level() > 0) { ob_end_clean(); }
header('Content-Type: ' . ($extension === 'png' ? 'image/png' : 'image/jpeg'));
header('Content-Length: ' . (string) filesize($path));
header('Content-Disposition: inline; filename="' . $filename . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=300');
readfile($path);
exit();
