<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
include '../../config/database.php';
include __DIR__ . '/../settings/settings-permissions-roles.php';
include __DIR__ . '/../settings/upload-storage-helper.php';
include __DIR__ . '/student-registration-helper.php';

$currentRole = $_SESSION['role'] ?? '';
if (!hasPermission($currentRole, 'student_data', 'delete')) {
    admin_session_forbidden();
}

admin_csrf_token();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';
$student = null;
$transactionSummary = ['has_transactions' => false, 'payment_count' => 0, 'latest_payment_date' => ''];

if ($id <= 0) {
    header("Location: student-list.php");
    exit();
}

$stmt = $conn->prepare("SELECT id, lastname, firstname, lrn, photo FROM students WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();
$stmt->close();

if (!$student) {
    header("Location: student-list.php");
    exit();
}

$transactionSummary = student_transaction_summary($conn, $id);
$hasFinancialTransactions = (bool) ($transactionSummary['has_transactions'] ?? false);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_require_post_csrf();
    $submittedId = isset($_POST['id']) ? intval($_POST['id']) : 0;

    if ($submittedId !== (int) $student['id']) {
        $error = "Invalid deletion request.";
    } elseif ($hasFinancialTransactions) {
        $error = "This student already has recorded financial transactions. Void related receipts first or keep the student record for audit history.";
    } elseif (!isset($_POST['confirm_delete'])) {
        header("Location: student-list.php");
        exit();
    } else {
        $user = $_SESSION['username'] ?? 'unknown';

        if (!empty($student['photo'])) {
            student_photo_delete($conn, (string) $student['photo']);
        }

        $deleteStmt = $conn->prepare("DELETE FROM students WHERE id = ?");
        $deleteStmt->bind_param("i", $student['id']);
        $deleteStmt->execute();
        $deleteStmt->close();

        include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');
        $studentName = $student['lastname'] . ", " . $student['firstname'];
        $action = "Deleted student";
        $module = "Students";
        $details = "Student: $studentName | LRN: " . $student['lrn'] . " | Role: " . ($_SESSION['role'] ?? 'unknown') . " | Deleted by: $user";
        audit_log($conn, $user, $action, $module, $details);

        header("Location: student-list.php?deleted=1");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Student Record | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="mt-5 mb-3">
        <h3><i class="fas fa-trash"></i> Delete Student Record</h3>
        <hr>
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if ($hasFinancialTransactions): ?>
            <div class="alert alert-warning">
                <strong>Delete blocked.</strong>
                This student has <?= number_format((int) ($transactionSummary['payment_count'] ?? 0)) ?> recorded payment(s)
                <?php if (!empty($transactionSummary['latest_payment_date'])): ?>
                    with latest activity on <?= htmlspecialchars(date('F j, Y', strtotime((string) $transactionSummary['latest_payment_date']))) ?>.
                <?php endif; ?>
                Void related finance transactions first if this record truly needs to be removed.
            </div>
        <?php endif; ?>
        <div class="alert alert-danger">
            <strong>Warning:</strong> This action is irreversible and will permanently delete
            <strong><?= htmlspecialchars($student['lastname'] . ', ' . $student['firstname']) ?></strong>.
            <br>
            LRN: <strong><?= htmlspecialchars($student['lrn']) ?></strong>
        </div>
        <form method="post">
            <input type="hidden" name="id" value="<?= (int) $student['id'] ?>">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(admin_csrf_token()) ?>">
            <button type="submit" name="confirm_delete" class="btn btn-danger" <?= $hasFinancialTransactions ? 'disabled' : '' ?>>
                <i class="fas fa-trash"></i> Yes, Delete Permanently
            </button>
            <a href="student-list.php" class="btn btn-secondary ms-2">Cancel</a>
        </form>
    </div>
</div>
</body>
</html>
