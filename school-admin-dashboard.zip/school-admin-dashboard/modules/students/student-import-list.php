<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require '../../config/database.php';
require '../../vendor/autoload.php';
require __DIR__ . '/../settings/school-year-helper.php';
require __DIR__ . '/student-registration-helper.php';
require __DIR__ . '/student-requirements-helper.php';

use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

if (($_SESSION['role'] ?? '') !== 'Super Administrator') {
    die("You are not authorized to access this page.");
}

school_year_ensure_finance_columns($conn);
student_requirements_ensure_table($conn);
$active_school_year_label = school_year_get_active_label($conn);
if (empty($_SESSION['student_import_csrf_token'])) {
    $_SESSION['student_import_csrf_token'] = bin2hex(random_bytes(32));
}

$grades = [
    "Junior Kindergarten", "Senior Kindergarten", "Grade 1", "Grade 2", "Grade 3",
    "Grade 4", "Grade 5", "Grade 6", "Grade 7", "Grade 8", "Grade 9",
    "Grade 10", "Grade 11", "Grade 12"
];

$message = '';
$import_results = [];
$import_preview = $_SESSION['student_import_preview'] ?? null;

function importNormalizeContact(string $value): string
{
    $digits = preg_replace('/\D/', '', trim($value));
    if (strlen($digits) !== 11 || strpos($digits, '09') !== 0) {
        return trim($value);
    }

    return substr($digits, 0, 4) . '-' . substr($digits, 4, 3) . '-' . substr($digits, 7, 4);
}

function importComputeAge(string $birthdayDb): int
{
    $timestamp = strtotime($birthdayDb);
    if ($timestamp === false) {
        return 0;
    }

    try {
        $birthday = new DateTime(date('Y-m-d', $timestamp));
        $today = new DateTime(date('Y-m-d'));
        return max(0, (int) $today->diff($birthday)->y);
    } catch (Throwable $e) {
        return 0;
    }
}

function importStudentDefaultRequirements(): array
{
    $requirements = [];
    foreach (student_requirements_catalog() as $key => $_label) {
        $requirements[$key] = ['status' => 'Missing', 'note' => ''];
    }
    return $requirements;
}

function get_next_lrn(mysqli $conn): int
{
    $result = $conn->query("SELECT MAX(CAST(lrn AS UNSIGNED)) AS max_lrn FROM students");
    $max_lrn = 0;
    if ($row = $result->fetch_assoc()) {
        $max_lrn = (int) $row['max_lrn'];
    }
    return max(1, $max_lrn + 1);
}

function importFormatDate($date, string $default = '2000-01-01'): string
{
    if ($date === null || $date === '') {
        return $default;
    }

    if (is_numeric($date)) {
        try {
            $dt = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject((float) $date);
            return $dt->format('Y-m-d');
        } catch (Throwable $e) {
            return $default;
        }
    }

    $value = trim((string) $date);
    if (preg_match('/^\d{2}-\d{2}-\d{4}$/', $value)) {
        $parts = explode('-', $value);
        return $parts[2] . '-' . $parts[0] . '-' . $parts[1];
    }
    if (preg_match('/^\d{2}\/\d{2}\/\d{4}$/', $value)) {
        $parts = explode('/', $value);
        return $parts[2] . '-' . $parts[0] . '-' . $parts[1];
    }
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
        return $value;
    }
    return $default;
}

function importRowDataArray(
    string $lastname,
    string $firstname,
    string $middlename,
    string $lrn,
    string $section,
    string $birthdayDb,
    string $gender,
    string $address,
    string $contact,
    string $dateEnrolledDb,
    string $guardianName,
    string $guardianContact
): array {
    return [
        $lastname,
        $firstname,
        $middlename,
        $lrn,
        $section,
        $birthdayDb,
        $gender,
        $address,
        $contact,
        $dateEnrolledDb,
        $guardianName,
        $guardianContact,
    ];
}

function importBuildPreview(mysqli $conn, string $tmpFile, string $grade, string $activeSchoolYearLabel): array
{
    $spreadsheet = IOFactory::load($tmpFile);
    $sheet = $spreadsheet->getActiveSheet();
    $studentHashes = [];
    $previewRows = [];
    $errorRows = [];
    $validRows = [];
    $summary = [
        'total_rows' => 0,
        'valid' => 0,
        'file_duplicate' => 0,
        'db_duplicate' => 0,
        'blank' => 0,
        'invalid' => 0,
    ];

    $rowNum = 1;
    foreach ($sheet->getRowIterator(2) as $row) {
        $rowNum++;
        $cells = [];
        foreach ($row->getCellIterator() as $cell) {
            $cells[] = trim((string) $cell->getValue());
        }

        $lastname = $cells[0] ?? '';
        $firstname = $cells[1] ?? '';
        $middlename = $cells[2] ?? '';
        $lrn = $cells[3] ?? '';
        $section = $cells[4] ?? '';
        $birthday = $cells[5] ?? '01-01-2020';
        $gender = $cells[6] ?? '';
        $address = $cells[7] ?? '';
        $contact = $cells[8] ?? '';
        $dateEnrolled = $cells[9] ?? '01-01-2025';
        $guardianName = $cells[10] ?? '';
        $guardianContact = $cells[11] ?? '';

        if (
            $lastname === '' && $firstname === '' && $middlename === '' && $lrn === '' &&
            $section === '' && $birthday === '' && $gender === '' && $address === '' &&
            $contact === '' && $dateEnrolled === '' && $guardianName === '' && $guardianContact === ''
        ) {
            continue;
        }

        $summary['total_rows']++;

        $section = trim((string) $section);
        $isTemplateSample = strcasecmp($lastname, 'Villadolid') === 0
            && strcasecmp($firstname, 'Jefte Ray') === 0
            && strcasecmp($middlename, 'Reynoso') === 0
            && trim((string) $lrn) !== ''
            && strcasecmp($gender, 'Male') === 0
            && strcasecmp($address, 'NA') === 0
            && trim((string) $contact) !== ''
            && strcasecmp($guardianName, 'Juan Dela Cruz') === 0
            && trim((string) $guardianContact) !== '';
        if ($isTemplateSample) {
            continue;
        }
        if ($section === '' || preg_match('/^n\/?a$/i', $section)) {
            $section = 'NA';
        }

        $birthdayDb = importFormatDate($birthday, '2000-01-01');
        $dateEnrolledDb = importFormatDate($dateEnrolled, '2025-01-01');
        $contact = importNormalizeContact($contact);
        $guardianContact = importNormalizeContact($guardianContact);
        $age = importComputeAge($birthdayDb);
        $rowData = importRowDataArray(
            $lastname,
            $firstname,
            $middlename,
            $lrn,
            $section,
            $birthdayDb,
            $gender,
            $address,
            $contact,
            $dateEnrolledDb,
            $guardianName,
            $guardianContact
        );

        $rowError = null;

        if (
            !$lastname || !$firstname || !$gender || !$birthday || !$dateEnrolled
        ) {
            $rowError = "Row $rowNum: Missing required fields";
            $summary['blank']++;
        } else {
            $rowHash = md5(strtolower(trim($lastname . $firstname . $middlename . $section . $address . $gender . $contact . $birthdayDb . $dateEnrolledDb . $guardianName . $guardianContact)));
            if (isset($studentHashes[$rowHash])) {
                $rowError = "Row $rowNum: Duplicate in uploaded file";
                $summary['file_duplicate']++;
            } else {
                $studentHashes[$rowHash] = true;

                $stmt = $conn->prepare("SELECT COUNT(*) FROM students WHERE lastname = ? AND firstname = ? AND middlename = ? AND section = ? AND address = ? AND gender = ? AND contact = ?");
                $stmt->bind_param('sssssss', $lastname, $firstname, $middlename, $section, $address, $gender, $contact);
                $stmt->execute();
                $stmt->bind_result($existsName);
                $stmt->fetch();
                $stmt->close();
                if ($existsName) {
                    $rowError = "Row $rowNum: Duplicate in system";
                    $summary['db_duplicate']++;
                }
            }
        }

        if ($rowError === null && $lrn !== '') {
            $duplicateLrn = registration_find_duplicate($conn, $lrn, null, $active_school_year_label);
            if (!empty($duplicateLrn['has_duplicate'])) {
                $rowError = "Row $rowNum: " . ($duplicateLrn['message'] ?: 'Duplicate LRN in system or pending registrations');
                $summary['db_duplicate']++;
            }
        }

        if ($rowError === null && !preg_match('/^(Male|Female)$/i', $gender)) {
            $rowError = "Row $rowNum: Gender must be Male or Female";
            $summary['invalid']++;
        }

        if ($rowError === null && $contact !== '' && !preg_match('/^09\d{2}-\d{3}-\d{4}$/', $contact)) {
            $rowError = "Row $rowNum: Contact number must use 09xx-xxx-xxxx format";
            $summary['invalid']++;
        }

        if ($rowError === null && $guardianContact !== '' && !preg_match('/^09\d{2}-\d{3}-\d{4}$/', $guardianContact)) {
            $rowError = "Row $rowNum: Guardian contact must use 09xx-xxx-xxxx format";
            $summary['invalid']++;
        }

        if ($rowError !== null) {
            $previewRows[] = [
                'row_number' => $rowNum,
                'status' => 'error',
                'message' => $rowError,
            ];
            $errorRows[] = [
                'row_number' => $rowNum,
                'reason' => $rowError,
                'data' => $rowData,
            ];
            continue;
        }

        $previewRows[] = [
            'row_number' => $rowNum,
            'status' => 'valid',
            'message' => "Row $rowNum: Ready to import",
        ];
        $validRows[] = [
            'row_number' => $rowNum,
            'lastname' => $lastname,
            'firstname' => $firstname,
            'middlename' => $middlename,
            'lrn' => $lrn,
            'section' => $section,
            'birthday_db' => $birthdayDb,
            'age' => $age,
            'gender' => $gender,
            'address' => $address !== '' ? $address : 'NA',
            'contact' => $contact,
            'date_enrolled_db' => $dateEnrolledDb,
            'guardian_name' => $guardianName,
            'guardian_contact' => $guardianContact,
            'grade' => $grade,
            'school_year_label' => $activeSchoolYearLabel,
        ];
        $summary['valid']++;
    }

    return [
        'grade' => $grade,
        'summary' => $summary,
        'preview_rows' => $previewRows,
        'valid_rows' => $validRows,
        'error_rows' => $errorRows,
    ];
}

if (isset($_POST['download_template'])) {
    if (!hash_equals($_SESSION['student_import_csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        die('Invalid request token.');
    }

    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();
    $sheet->setTitle('Template');
    $sheet->setCellValue('A1', 'Last Name*');
    $sheet->setCellValue('B1', 'First Name*');
    $sheet->setCellValue('C1', 'Middle Name (optional)');
    $sheet->setCellValue('D1', 'LRN (optional, keep leading zeros)');
    $sheet->setCellValue('E1', 'Section (optional, leave blank if none)');
    $sheet->setCellValue('F1', 'Birthday (mm/dd/yyyy, default 01/01/2020)');
    $sheet->setCellValue('G1', 'Gender* (Male/Female)');
    $sheet->setCellValue('H1', 'Address* (if blank, NA)');
    $sheet->setCellValue('I1', 'Contact Number* (09xx-xxx-xxxx)');
    $sheet->setCellValue('J1', 'Date Enrolled (mm/dd/yyyy, default 01/01/2025)');
    $sheet->setCellValue('K1', 'Guardian Name*');
    $sheet->setCellValue('L1', 'Guardian Contact*');
    $sheet->setCellValue('A2', 'Villadolid');
    $sheet->setCellValue('B2', 'Jefte Ray');
    $sheet->setCellValue('C2', '');
    $sheet->setCellValueExplicit('D2', '', DataType::TYPE_STRING);
    $sheet->setCellValue('E2', '');
    $sheet->setCellValue('F2', '01/15/2010');
    $sheet->setCellValue('G2', 'Male');
    $sheet->setCellValue('H2', '');
    $sheet->setCellValueExplicit('I2', '', DataType::TYPE_STRING);
    $sheet->setCellValue('J2', '01/01/2025');
    $sheet->setCellValue('K2', '');
    $sheet->setCellValueExplicit('L2', '', DataType::TYPE_STRING);

    $spreadsheet->getDefaultStyle()->getFont()->setName('Calibri')->setSize(11);
    $sheet->getStyle('D:D')->getNumberFormat()->setFormatCode('@');
    $sheet->getStyle('I:I')->getNumberFormat()->setFormatCode('@');
    $sheet->getStyle('L:L')->getNumberFormat()->setFormatCode('@');
    $sheet->getStyle('F2')->getNumberFormat()->setFormatCode('mm/dd/yyyy');
    $sheet->getStyle('J2')->getNumberFormat()->setFormatCode('mm/dd/yyyy');
    $sheet->getStyle('D2:D2000')->getNumberFormat()->setFormatCode('@');
    $sheet->getStyle('I2:I2000')->getNumberFormat()->setFormatCode('@');
    $sheet->getStyle('L2:L2000')->getNumberFormat()->setFormatCode('@');
    $sheet->getStyle('F2:F2000')->getNumberFormat()->setFormatCode('mm/dd/yyyy');
    $sheet->getStyle('J2:J2000')->getNumberFormat()->setFormatCode('mm/dd/yyyy');
    $sheet->getStyle('A1:L1')->getFont()->setBold(true);
    $sheet->getStyle('A1:L1')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
    $sheet->getStyle('A1:L1')->getAlignment()->setVertical(\PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER);
    $sheet->getStyle('A1:L1')->getAlignment()->setWrapText(true);
    $sheet->getStyle('A1:L1')->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)->getStartColor()->setRGB('D9EAF7');
    $sheet->freezePane('A2');
    $sheet->getRowDimension(1)->setRowHeight(28);

    $columnWidths = [
        'A' => 18, 'B' => 18, 'C' => 20, 'D' => 20, 'E' => 16, 'F' => 26,
        'G' => 18, 'H' => 28, 'I' => 22, 'J' => 28, 'K' => 22, 'L' => 22,
    ];
    foreach ($columnWidths as $col => $width) {
        $sheet->getColumnDimension($col)->setWidth($width);
    }

    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="student_import_template.xlsx"');
    header('Cache-Control: max-age=0');
    header('Pragma: public');
    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['preview_import'])) {
    $grade = $_POST['grade'] ?? '';
    $_SESSION['import_error_rows'] = [];

    if (!hash_equals($_SESSION['student_import_csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        $message = "<span class='text-danger'>Invalid request token. Please refresh and try again.</span>";
    } elseif (!in_array($grade, $grades, true)) {
        $message = "<span class='text-danger'>Invalid grade selected for import.</span>";
    } elseif (!isset($_FILES['import_file']) || $_FILES['import_file']['error'] !== UPLOAD_ERR_OK) {
        $message = "<span class='text-danger'>No file uploaded or error in upload.</span>";
    } else {
        $filename = $_FILES['import_file']['name'];
        $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if ($extension !== 'xlsx') {
            $message = "<span class='text-danger'>Only .xlsx files are allowed for student import.</span>";
        } else {
            $import_preview = importBuildPreview($conn, $_FILES['import_file']['tmp_name'], $grade, $active_school_year_label);
            $_SESSION['student_import_preview'] = $import_preview;
            $_SESSION['import_error_rows'] = $import_preview['error_rows'];
            $summary = $import_preview['summary'];
            $message = "Preview ready for $grade. Valid rows: {$summary['valid']}. Duplicate in file: {$summary['file_duplicate']}. Duplicate in system: {$summary['db_duplicate']}. Missing info: {$summary['blank']}. Invalid rows: {$summary['invalid']}.";
            $import_results = array_map(static function (array $row): string {
                return $row['message'];
            }, $import_preview['preview_rows']);
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['finalize_import'])) {
    $grade = $_POST['grade'] ?? '';
    $import_preview = $_SESSION['student_import_preview'] ?? null;

    if (!hash_equals($_SESSION['student_import_csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        $message = "<span class='text-danger'>Invalid request token. Please refresh and try again.</span>";
    } elseif (!is_array($import_preview) || ($import_preview['grade'] ?? '') !== $grade) {
        $message = "<span class='text-danger'>No valid preview found for this grade. Please preview the file first.</span>";
    } else {
        $_SESSION['import_error_rows'] = $import_preview['error_rows'] ?? [];
        $results = [];
        $imported = 0;
        $lrn_auto_counter = get_next_lrn($conn);

        foreach (($import_preview['valid_rows'] ?? []) as $row) {
            $rowNum = (int) ($row['row_number'] ?? 0);
            $lastname = (string) ($row['lastname'] ?? '');
            $firstname = (string) ($row['firstname'] ?? '');
            $middlename = (string) ($row['middlename'] ?? '');
            $lrn = (string) ($row['lrn'] ?? '');
            $section = (string) ($row['section'] ?? '');
            $birthday_db = (string) ($row['birthday_db'] ?? '2000-01-01');
            $age = (int) ($row['age'] ?? 0);
            $gender = (string) ($row['gender'] ?? '');
            $address = (string) ($row['address'] ?? 'NA');
            $contact = (string) ($row['contact'] ?? '');
            $date_enrolled_db = (string) ($row['date_enrolled_db'] ?? '2025-01-01');
            $guardian_name = (string) ($row['guardian_name'] ?? '');
            $guardian_contact = (string) ($row['guardian_contact'] ?? '');
            $schoolYearLabel = (string) ($row['school_year_label'] ?? $active_school_year_label);

            if ($lrn !== '') {
                $duplicateLrn = registration_find_duplicate($conn, $lrn, null, $schoolYearLabel);
                if (!empty($duplicateLrn['has_duplicate'])) {
                    $reason = "Row $rowNum: " . ($duplicateLrn['message'] ?: 'Duplicate LRN in system or pending registrations');
                    $results[] = $reason;
                    $_SESSION['import_error_rows'][] = [
                        'row_number' => $rowNum,
                        'reason' => $reason,
                        'data' => importRowDataArray($lastname, $firstname, $middlename, $lrn, $section, $birthday_db, $gender, $address, $contact, $date_enrolled_db, $guardian_name, $guardian_contact),
                    ];
                    continue;
                }
            } else {
                do {
                    $lrn = str_pad($lrn_auto_counter, 4, "0", STR_PAD_LEFT);
                    $stmt = $conn->prepare("SELECT COUNT(*) FROM students WHERE lrn = ?");
                    $stmt->bind_param('s', $lrn);
                    $stmt->execute();
                    $stmt->bind_result($existsLrn);
                    $stmt->fetch();
                    $stmt->close();
                    $lrn_auto_counter++;
                } while ($existsLrn);
            }

            try {
                $conn->begin_transaction();

                $stmt = $conn->prepare("INSERT INTO students 
                    (lastname, firstname, middlename, lrn, birthday, age, gender, address, contact, grade, section, date_enrolled, school_year_label, photo, guardian_name, guardian_contact) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '', ?, ?)");
                $stmt->bind_param(
                    'sssssisssssssss',
                    $lastname,
                    $firstname,
                    $middlename,
                    $lrn,
                    $birthday_db,
                    $age,
                    $gender,
                    $address,
                    $contact,
                    $grade,
                    $section,
                    $date_enrolled_db,
                    $schoolYearLabel,
                    $guardian_name,
                    $guardian_contact
                );
                $stmt->execute();
                $studentId = (int) $stmt->insert_id;
                $stmt->close();

                if (!registration_create_student_accounts($conn, $studentId, $grade)) {
                    throw new RuntimeException('Could not auto-create accounts for imported student.');
                }

                student_requirements_save_for_student(
                    $conn,
                    $studentId,
                    importStudentDefaultRequirements(),
                    $_SESSION['username'] ?? 'system import'
                );

                include_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');
                $user = $_SESSION['username'] ?? 'unknown';
                $studentName = $lastname . ', ' . $firstname;
                $action = 'Imported student';
                $module = 'Students';
                $details = "Student: $studentName | LRN: " . ($lrn !== '' ? $lrn : 'N/A') . " | Grade: $grade | Section: $section | School Year: $schoolYearLabel | Imported by: $user";
                audit_log($conn, $user, $action, $module, $details);

                $conn->commit();
                $imported++;
                $results[] = "Row $rowNum: Imported";
            } catch (Throwable $e) {
                $conn->rollback();
                $reason = "Row $rowNum: " . ($e->getMessage() ?: 'Import failed');
                $results[] = $reason;
                $_SESSION['import_error_rows'][] = [
                    'row_number' => $rowNum,
                    'reason' => $reason,
                    'data' => importRowDataArray($lastname, $firstname, $middlename, $lrn, $section, $birthday_db, $gender, $address, $contact, $date_enrolled_db, $guardian_name, $guardian_contact),
                ];
            }
        }

        $summary = $import_preview['summary'] ?? ['file_duplicate' => 0, 'db_duplicate' => 0, 'blank' => 0, 'invalid' => 0];
        $message = "Imported: $imported students. Preview skipped rows remained unchanged. Duplicate in file: {$summary['file_duplicate']}. Duplicate in system: {$summary['db_duplicate']}. Missing info: {$summary['blank']}. Invalid rows: {$summary['invalid']}.";
        $import_results = $results;
        unset($_SESSION['student_import_preview']);
        $import_preview = null;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Import Students by Grade Level</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f8fafc; }
        .tab-pane { background: #fff; border-radius: 8px; padding: 2rem; margin-top: 1rem; box-shadow: 0 2px 12px rgba(0,0,0,0.06); }
        .nav-tabs .nav-link { font-weight: 500; }
        .nav-tabs .nav-link.active { color: #fff !important; background: #2a9d8f !important; }
        .form-label { font-weight: 500; }
        .alert-info { margin-top: 1rem; }
        .table-sm th, .table-sm td { font-size: 0.96rem; }
        .bottom-btns { display: flex; gap: 1rem; margin-top: 3rem; justify-content: center; }
        .import-status { margin-top: 2rem; }
    </style>
    <script>
    function confirmImport(formId) {
        if (confirm("Are you sure you want to finalize import for this grade?")) {
            document.getElementById(formId).submit();
        }
    }
    </script>
</head>
<body>
<div class="container mt-4 mb-5">
    <h2 class="mb-4">Import Students by Grade Level</h2>
    <?php if ($message): ?>
        <div class="alert alert-info"><?= $message ?></div>
    <?php endif; ?>

    <ul class="nav nav-tabs" role="tablist">
        <?php foreach ($grades as $idx => $grade): ?>
            <li class="nav-item" role="presentation">
                <button class="nav-link <?= $idx === 0 ? 'active' : '' ?>"
                        id="tab-<?= $idx ?>"
                        data-bs-toggle="tab"
                        data-bs-target="#grade-<?= $idx ?>"
                        type="button"
                        role="tab"><?= htmlspecialchars($grade) ?></button>
            </li>
        <?php endforeach; ?>
    </ul>

    <div class="tab-content">
        <?php foreach ($grades as $idx => $grade): ?>
            <div class="tab-pane fade <?= $idx === 0 ? 'show active' : '' ?>" id="grade-<?= $idx ?>" role="tabpanel">
                <form method="post" enctype="multipart/form-data" class="mt-3" id="previewform<?= $idx ?>">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['student_import_csrf_token']) ?>">
                    <input type="hidden" name="grade" value="<?= htmlspecialchars($grade) ?>">
                    <div class="mb-3">
                        <label for="import_file_<?= $idx ?>" class="form-label">Excel File for <strong><?= htmlspecialchars($grade) ?></strong></label>
                        <input type="file" name="import_file" id="import_file_<?= $idx ?>" class="form-control" required>
                        <div class="form-text">Only <strong>.xlsx</strong> files are accepted.<br>
                            <strong>Section</strong> column is required in the template for each student.</div>
                    </div>
                    <button type="submit" name="preview_import" value="1" class="btn btn-primary">
                        <i class="fas fa-magnifying-glass"></i> Preview Import for <?= htmlspecialchars($grade) ?>
                    </button>
                </form>

                <?php if (is_array($import_preview) && ($import_preview['grade'] ?? '') === $grade): ?>
                    <?php $previewSummary = $import_preview['summary'] ?? []; ?>
                    <div class="import-status">
                        <h5>Preview Summary</h5>
                        <div class="alert alert-secondary">
                            Total rows: <strong><?= (int) ($previewSummary['total_rows'] ?? 0) ?></strong>,
                            Ready to import: <strong><?= (int) ($previewSummary['valid'] ?? 0) ?></strong>,
                            Duplicate in file: <strong><?= (int) ($previewSummary['file_duplicate'] ?? 0) ?></strong>,
                            Duplicate in system: <strong><?= (int) ($previewSummary['db_duplicate'] ?? 0) ?></strong>,
                            Missing info: <strong><?= (int) ($previewSummary['blank'] ?? 0) ?></strong>,
                            Invalid: <strong><?= (int) ($previewSummary['invalid'] ?? 0) ?></strong>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-sm table-bordered align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>Row</th>
                                        <th>Status</th>
                                        <th>Details</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach (($import_preview['preview_rows'] ?? []) as $previewRow): ?>
                                        <tr>
                                            <td><?= (int) $previewRow['row_number'] ?></td>
                                            <td>
                                                <?php if (($previewRow['status'] ?? '') === 'valid'): ?>
                                                    <span class="badge bg-success">Ready</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Skipped</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?= htmlspecialchars((string) ($previewRow['message'] ?? '')) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php if (!empty($import_preview['valid_rows'])): ?>
                            <form method="post" id="finalizeImport<?= $idx ?>" class="mt-3">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['student_import_csrf_token']) ?>">
                                <input type="hidden" name="grade" value="<?= htmlspecialchars($grade) ?>">
                                <input type="hidden" name="finalize_import" value="1">
                                <button type="button" onclick="confirmImport('finalizeImport<?= $idx ?>')" class="btn btn-success">
                                    <i class="fas fa-file-import"></i> Finalize Import for <?= htmlspecialchars($grade) ?>
                                </button>
                            </form>
                        <?php endif; ?>
                        <?php if (!empty($_SESSION['import_error_rows'])): ?>
                            <form method="post" action="student-download-error.php" target="_blank" style="margin-top: 1.5rem;">
                                <button type="submit" class="btn btn-warning">
                                    <i class="fas fa-file-download"></i> Download Error
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php elseif (!empty($import_results) && isset($_POST['grade']) && $_POST['grade'] === $grade): ?>
                    <div class="import-status">
                        <h5>Import Status:</h5>
                        <ul class="list-group">
                            <?php foreach ($import_results as $result): ?>
                                <li class="list-group-item"><?= htmlspecialchars($result) ?></li>
                            <?php endforeach; ?>
                        </ul>
                        <?php if (!empty($_SESSION['import_error_rows'])): ?>
                            <form method="post" action="student-download-error.php" target="_blank" style="margin-top: 1.5rem;">
                                <button type="submit" class="btn btn-warning">
                                    <i class="fas fa-file-download"></i> Download Error
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="mt-3 text-muted">
        <ul>
            <li>Only sheets named "Junior Kindergarten" up to "Grade 12" will be processed.</li>
            <li>Only <strong>.xlsx</strong> files can be uploaded.</li>
            <li>Duplicates in file and in system will be skipped.</li>
            <li>Required columns: Last Name*, First Name*, Middle Name (optional), LRN (optional, whole number), <strong>Section*</strong>, Birthday (mm-dd-yyyy), Gender*, Address* (if blank, NA), Contact Number* (0900-000-0000), Date Enrolled (mm-dd-yyyy), Guardian Name*, Guardian Contact*</li>
            <li>LRN will be auto-generated if blank, address is "NA" if blank, birthday defaults to 01-01-2020, date enrolled defaults to 01-01-2025.</li>
            <li>Import now uses a <strong>Preview</strong> step first, then a separate <strong>Finalize Import</strong> confirmation.</li>
        </ul>
    </div>

    <div class="bottom-btns">
        <form method="post" style="display:inline;">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['student_import_csrf_token']) ?>">
            <button type="submit" name="download_template" class="btn btn-info">
                <i class="fas fa-file-download"></i> Download Template
            </button>
        </form>
        <a href="student-list.php" class="btn btn-outline-secondary back-btn">
            &larr; Back to Student List
        </a>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</body>
</html>
