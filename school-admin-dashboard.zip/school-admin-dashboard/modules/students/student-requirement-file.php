<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require '../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/upload-storage-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

$currentRole = $_SESSION['role'] ?? '';
$canView = hasPermission($currentRole, 'student_data', 'view') || hasPermission($currentRole, 'documents', 'view');
if (!$canView) {
    $blockedUser = $_SESSION['username'] ?? 'unknown';
    audit_log(
        $conn,
        $blockedUser,
        'Blocked student requirement document access',
        'Students',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing documents:view or student_data:view permission',
        'SECURITY'
    );
    admin_session_forbidden();
}

$documentId = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($documentId <= 0) {
    http_response_code(404);
    exit('Document not found.');
}

$stmt = $conn->prepare("
    SELECT original_filename, stored_filename, file_path, mime_type
    FROM student_requirement_documents
    WHERE id = ?
    LIMIT 1
");
if (!$stmt) {
    http_response_code(500);
    exit('Document lookup failed.');
}

$stmt->bind_param('i', $documentId);
$stmt->execute();
$result = $stmt->get_result();
$document = $result ? $result->fetch_assoc() : null;
$stmt->close();

if (!$document) {
    http_response_code(404);
    exit('Document not found.');
}

$absolutePath = requirement_document_absolute_path($conn, (string) ($document['file_path'] ?? ''));
if ($absolutePath === '' || !is_file($absolutePath)) {
    http_response_code(404);
    exit('Document file not found.');
}

$mimeType = trim((string) ($document['mime_type'] ?? ''));
if ($mimeType === '') {
    $mimeType = 'application/octet-stream';
}

$safeFilename = basename((string) (($document['original_filename'] ?? '') !== '' ? $document['original_filename'] : ($document['stored_filename'] ?? 'document')));

header('Content-Type: ' . $mimeType);
header('Content-Length: ' . (string) filesize($absolutePath));
header('Content-Disposition: inline; filename="' . str_replace('"', '', $safeFilename) . '"');
header('X-Content-Type-Options: nosniff');
readfile($absolutePath);
exit();
