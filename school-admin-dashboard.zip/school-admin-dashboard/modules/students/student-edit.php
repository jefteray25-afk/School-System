<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require_once __DIR__ . '/../../includes/ui.php';
include '../../config/database.php';
require_once __DIR__ . '/../../includes/record-conflict-helper.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/section-management-helper.php';
require_once __DIR__ . '/../settings/upload-storage-helper.php';
require_once __DIR__ . '/student-registration-helper.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php';

$currentRole = $_SESSION['role'] ?? '';
if (!hasPermission($currentRole, 'student_data', 'edit')) {
    $blockedUser = $_SESSION['username'] ?? 'unknown';
    audit_log(
        $conn,
        $blockedUser,
        'Blocked student edit access',
        'Students',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing student_data:edit permission',
        'SECURITY'
    );
    admin_session_forbidden();
}

registration_ensure_student_strand_column($conn);

$id = $_GET['id'] ?? null;
$lastname = $firstname = $middlename = $lrn = $birthday = $age = $gender = $address = $contact = $grade = $strand = $section = $date_enrolled = $photo = "";
$guardian_name = $guardian_contact = "";
$school_year_label = '';
$original_section = '';
$student_conflict_token = '';
$transactionSummary = ['has_transactions' => false, 'payment_count' => 0, 'latest_payment_date' => ''];
$overrideReason = '';
$error = "";
$photoSettings = student_photo_storage_settings($conn);
$maxPhotoMb = (int) ($photoSettings['student_photo_max_mb'] ?? 2);

$grades = [
    "Junior Kindergarten", "Senior Kindergarten", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5",
    "Grade 6", "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"
];
$strandOptions = registration_get_strand_options();
section_management_ensure_table($conn);
$managedSectionsByGrade = [];

// Fetch current student info if editing
if ($id) {
    $stmt = $conn->prepare("SELECT lastname, firstname, middlename, lrn, birthday, age, gender, address, contact, grade, strand, section, date_enrolled, photo, guardian_name, guardian_contact, school_year_label FROM students WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $studentRow = $stmt->get_result()->fetch_assoc();
    if (!$studentRow) {
        $error = "Student not found.";
    } else {
        $lastname = (string) ($studentRow['lastname'] ?? '');
        $firstname = (string) ($studentRow['firstname'] ?? '');
        $middlename = (string) ($studentRow['middlename'] ?? '');
        $lrn = (string) ($studentRow['lrn'] ?? '');
        $birthday = (string) ($studentRow['birthday'] ?? '');
        $age = (string) ($studentRow['age'] ?? '');
        $gender = (string) ($studentRow['gender'] ?? '');
        $address = (string) ($studentRow['address'] ?? '');
        $contact = (string) ($studentRow['contact'] ?? '');
        $grade = (string) ($studentRow['grade'] ?? '');
        $strand = (string) ($studentRow['strand'] ?? '');
        $section = (string) ($studentRow['section'] ?? '');
        $date_enrolled = (string) ($studentRow['date_enrolled'] ?? '');
        $photo = (string) ($studentRow['photo'] ?? '');
        $guardian_name = (string) ($studentRow['guardian_name'] ?? '');
        $guardian_contact = (string) ($studentRow['guardian_contact'] ?? '');
        $school_year_label = (string) ($studentRow['school_year_label'] ?? '');
        $student_conflict_token = record_conflict_token(student_record_conflict_payload($studentRow));
    }
    $stmt->close();
    $school_year_label = trim((string) $school_year_label) !== '' ? trim((string) $school_year_label) : school_year_default_label();
    $original_section = $section;
    $transactionSummary = student_transaction_summary($conn, (int) $id);
    $managedSectionsByGrade = section_management_get_sections_by_grade($conn, $school_year_label, true);
} else {
    $error = "Invalid student ID.";
}

$hasFinancialTransactions = (bool) ($transactionSummary['has_transactions'] ?? false);
$isSuperAdmin = is_super_admin_role($currentRole);
$lockProtectedFields = $hasFinancialTransactions && !$isSuperAdmin;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    admin_require_post_csrf();
    $submittedConflictToken = trim((string) ($_POST['record_conflict_token'] ?? ''));
    $lastname = trim($_POST["lastname"]);
    $firstname = trim($_POST["firstname"]);
    $middlename = trim($_POST["middlename"]); // optional
    $lrn = preg_replace('/\D+/', '', trim($_POST["lrn"])); // optional, digits only
    $birthday = trim($_POST["birthday"]);
    $age = intval(trim($_POST["age"])); // ensure age is integer!
    $gender = trim($_POST["gender"]);
    $address = trim($_POST["address"]);
    $contact = trim($_POST["contact"]);
    $grade = trim($_POST["grade"]);
    $strand = trim($_POST["strand"] ?? "");
    $section = trim($_POST["section"]);
    $date_enrolled = trim($_POST["date_enrolled"]);
    $guardian_name = trim($_POST["guardian_name"]); // optional
    $guardian_contact = trim($_POST["guardian_contact"]); // optional
    $overrideReason = trim((string) ($_POST['protected_override_reason'] ?? ''));
    $newPhoto = $photo;

    // Accept numbers like 09xx-xxx-xxxx (Philippine mobile format)
    $contact_pattern = '/^09\d{2}-\d{3}-\d{4}$/';
    $guardian_contact_pattern = '/^09\d{2}-\d{3}-\d{4}$/';

    $contact_digits = preg_replace('/[^0-9]/', '', $contact);
    $guardian_contact_digits = preg_replace('/[^0-9]/', '', $guardian_contact);
    $allowedSections = section_management_get_section_names($conn, $school_year_label, $grade, true);
    $is_senior_high = in_array($grade, ['Grade 11', 'Grade 12'], true);
    if (!$is_senior_high) {
        $strand = '';
    }

    if ($submittedConflictToken === '') {
        $error = "This edit session is missing conflict protection data. Please refresh the page and try again.";
    } else {
        $currentStmt = $conn->prepare("SELECT lastname, firstname, middlename, lrn, birthday, age, gender, address, contact, grade, strand, section, date_enrolled, photo, guardian_name, guardian_contact, school_year_label FROM students WHERE id = ?");
        $currentStmt->bind_param("i", $id);
        $currentStmt->execute();
        $currentRow = $currentStmt->get_result()->fetch_assoc();
        $currentStmt->close();
        if (!$currentRow) {
            $error = "Student record no longer exists.";
        } elseif (!hash_equals(record_conflict_token(student_record_conflict_payload($currentRow)), $submittedConflictToken)) {
            $error = "This student record was updated by another user while you were editing. Refresh the page first so you don't overwrite newer changes.";
        } else {
            $transactionSummary = student_transaction_summary($conn, (int) $id);
            $hasFinancialTransactions = (bool) ($transactionSummary['has_transactions'] ?? false);
            $lockProtectedFields = $hasFinancialTransactions && !$isSuperAdmin;
            $protectedFieldsChanged =
                $lastname !== (string) ($currentRow['lastname'] ?? '') ||
                $firstname !== (string) ($currentRow['firstname'] ?? '') ||
                $middlename !== (string) ($currentRow['middlename'] ?? '') ||
                $grade !== (string) ($currentRow['grade'] ?? '') ||
                $section !== (string) ($currentRow['section'] ?? '');

            if ($lockProtectedFields) {
                if ($protectedFieldsChanged) {
                    $error = "This student already has recorded financial transactions. Name, grade, and section are locked for non-Super Admin users.";
                }

                $lastname = (string) ($currentRow['lastname'] ?? '');
                $firstname = (string) ($currentRow['firstname'] ?? '');
                $middlename = (string) ($currentRow['middlename'] ?? '');
                $grade = (string) ($currentRow['grade'] ?? '');
                $section = (string) ($currentRow['section'] ?? '');
                $original_section = $section;
            } elseif ($hasFinancialTransactions && $isSuperAdmin && $protectedFieldsChanged && $overrideReason === '') {
                $error = "Please provide a reason before changing protected student fields with recorded financial transactions.";
            }
        }
    }

    // Photo upload logic with grade folder and custom name
    if (!$error && isset($_FILES['photo']) && $_FILES['photo']['error'] != UPLOAD_ERR_NO_FILE) {
        $photoUpload = student_photo_store_uploaded_file($conn, $_FILES['photo'], $grade, $lastname, $firstname);
        if (($photoUpload['error'] ?? '') !== '') {
            $error = (string) $photoUpload['error'];
        } else {
            if ($photo !== '') {
                student_photo_delete($conn, $photo);
            }
            $newPhoto = (string) ($photoUpload['path'] ?? '');
        }
    }

    if ($lrn !== '' && strlen($lrn) !== 12) {
        $error = "LRN must be exactly 12 digits.";
    } elseif ($is_senior_high && $strand === '') {
        $error = "Strand is required for Grade 11 and Grade 12 students.";
    } elseif ($is_senior_high && !in_array($strand, $strandOptions, true)) {
        $error = "Please select a valid strand for Grade 11 or Grade 12.";
    } elseif (strlen($contact_digits) !== 11 || !preg_match($contact_pattern, $contact)) {
        $error = "Contact number format must be 09xx-xxx-xxxx (e.g. 0917-345-6789) and exactly 11 digits.";
    } elseif ($section !== '' && !in_array($section, $allowedSections, true) && $section !== $original_section) {
        $error = "Selected section is not active for the chosen grade level. Please update it from Section Management.";
    } elseif (
        ($guardian_contact !== "" && (strlen($guardian_contact_digits) !== 11 || !preg_match($guardian_contact_pattern, $guardian_contact)))
    ) {
        $error = "Guardian contact number format must be 09xx-xxx-xxxx (e.g. 0917-345-6789) and exactly 11 digits.";
    } elseif (
        $lastname && $firstname && $birthday && $age &&
        $gender && $address && $contact && $grade && $date_enrolled && !$error
    ) {
        // Only the above fields are required!
        $stmt = $conn->prepare("UPDATE students SET lastname = ?, firstname = ?, middlename = ?, lrn = ?, birthday = ?, age = ?, gender = ?, address = ?, contact = ?, grade = ?, strand = ?, section = ?, date_enrolled = ?, photo = ?, guardian_name = ?, guardian_contact = ? WHERE id = ?");
        $stmt->bind_param(
            "sssssissssssssssi",
            $lastname, $firstname, $middlename, $lrn, $birthday, $age, $gender, $address, $contact, $grade, $strand, $section, $date_enrolled, $newPhoto, $guardian_name, $guardian_contact, $id
        );
        if ($stmt->execute()) {
            require_once($_SERVER['DOCUMENT_ROOT'].'/school-admin-dashboard/modules/audit/audit-helper.php');
            $user = $_SESSION['username'] ?? 'unknown';
            $student_name = "$lastname, $firstname";
            $details = format_student_action_details($student_name, "edited", $user);
            if (!empty($currentRow) && $hasFinancialTransactions && $isSuperAdmin) {
                $protectedChanges = [];
                $protectedFields = [
                    'lastname' => 'Last Name',
                    'firstname' => 'First Name',
                    'middlename' => 'Middle Name',
                    'grade' => 'Grade',
                    'section' => 'Section',
                ];
                foreach ($protectedFields as $fieldKey => $fieldLabel) {
                    $oldValue = trim((string) ($currentRow[$fieldKey] ?? ''));
                    $newValue = trim((string) ${$fieldKey});
                    if ($oldValue !== $newValue) {
                        $protectedChanges[] = $fieldLabel . ': "' . ($oldValue !== '' ? $oldValue : 'blank') . '" -> "' . ($newValue !== '' ? $newValue : 'blank') . '"';
                    }
                }

                if (!empty($protectedChanges)) {
                    $details .= ' | Protected override reason: ' . $overrideReason . ' | Changes: ' . implode('; ', $protectedChanges);
                }
            }
            audit_log($conn, $user, "Edited student", "Students", $details);

            header("Location: student-view.php?id=" . $id);
            exit();
        } else {
            $error = "Error updating student.";
        }
        $stmt->close();
    } else {
        if (!$error) $error = "All fields except Middle Name, LRN, Guardian Name, Guardian Contact, and Strand (only for Grade 11/12) are required.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Student Record | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <?php ui_css_link(); ?>
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body {
            background: var(--main-bg);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
            transition: background 0.6s;
        }
        body.dark-mode {
            --main-bg: #1b232d;
            --card-bg: #23395d;
            --navbar-bg: #161b22;
            color: #e6edf3;
        }
        .navbar {
            background: var(--navbar-bg) !important;
            transition: background 0.6s;
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.08em;
        }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .nav-link.active { border-bottom: 2px solid #517fa4; }
        .theme-toggle-btn {
            background: none;
            border: none;
            color: #fff;
            font-size: 1.45em;
            margin-left: 12px;
            cursor: pointer;
            transition: color 0.3s;
        }
        .dashboard-header {
            text-align: center;
            margin-top: 36px;
            margin-bottom: 18px;
        }
        .dashboard-header img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            margin-bottom: 6px;
        }
        .dashboard-header h1 {
            font-size: 1.3rem;
            color: var(--brand-dark);
            font-weight: 700;
            margin-bottom: 0;
            transition: color 0.6s;
        }
        .card {
            border-radius: 1rem;
            box-shadow: 0 2px 12px rgba(33,57,93,0.10);
            background: var(--card-bg);
            transition: background 0.6s, color 0.6s;
        }
        .card-header {
            font-weight: 600;
            font-size: 1.13em;
        }
        .dashboard-btn-bottom {
            position: fixed;
            left: 20px;
            bottom: 20px;
            z-index: 1000;
        }
        @media (max-width: 576px) {
            .dashboard-header img { width: 36px; height: 36px;}
            .dashboard-header { margin-top: 12px; margin-bottom: 12px;}
            .card { padding: 8px; }
            .dashboard-btn-bottom { left: 10px; bottom: 10px; font-size: 0.92em;}
        }
    </style>
</head>
<body>
<!-- Navbar -->
<?php render_admin_nav('students', true); ?>
<!-- Header -->
<?php render_school_page_header("The Lord's Wisdom Academy Of Caloocan Inc."); ?>
<div class="container mt-4">
    <div class="card">
        <div class="card-header bg-info text-light">
            <i class="fas fa-user-edit"></i> Edit Student Record
        </div>
        <div class="card-body">
            <?php if ($hasFinancialTransactions): ?>
                <div class="alert <?= $isSuperAdmin ? 'alert-warning' : 'alert-info' ?>">
                    <strong>Transaction protection active.</strong>
                    This student already has <?= number_format((int) ($transactionSummary['payment_count'] ?? 0)) ?> recorded payment(s)
                    <?php if (!empty($transactionSummary['latest_payment_date'])): ?>
                        with latest activity on <?= htmlspecialchars(date('F j, Y', strtotime((string) $transactionSummary['latest_payment_date']))) ?>.
                    <?php else: ?>
                        in the finance module.
                    <?php endif; ?>
                    <?= $isSuperAdmin
                        ? 'You can still edit protected identity fields, but please review changes very carefully.'
                        : 'Name, grade, and section are locked to protect finance history.' ?>
                </div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="post" action="" autocomplete="off" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(admin_csrf_token()) ?>">
                <input type="hidden" name="record_conflict_token" value="<?= htmlspecialchars($student_conflict_token) ?>">
                <?php if ($hasFinancialTransactions && $isSuperAdmin): ?>
                    <div class="mb-3">
                        <label class="form-label">Protected Field Override Reason</label>
                        <textarea class="form-control" name="protected_override_reason" rows="2" placeholder="Required if you change name, grade, or section after posted transactions exist."><?= htmlspecialchars($overrideReason) ?></textarea>
                        <small class="text-muted">This reason is required only when protected fields are changed and will be included in the audit log.</small>
                    </div>
                <?php endif; ?>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Last Name:</label>
                        <input type="text" class="form-control" name="lastname" value="<?= htmlspecialchars($lastname) ?>" required <?= $lockProtectedFields ? 'readonly' : '' ?>>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">First Name:</label>
                        <input type="text" class="form-control" name="firstname" value="<?= htmlspecialchars($firstname) ?>" required <?= $lockProtectedFields ? 'readonly' : '' ?>>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Middle Name:</label>
                        <input type="text" class="form-control" name="middlename" value="<?= htmlspecialchars($middlename) ?>" <?= $lockProtectedFields ? 'readonly' : '' ?>>
                        <small class="text-muted">(optional)</small>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">LRN:</label>
                        <input
                            type="text"
                            class="form-control"
                            name="lrn"
                            id="lrn"
                            value="<?= htmlspecialchars($lrn) ?>"
                            maxlength="12"
                            inputmode="numeric"
                            pattern="\d{12}"
                            oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 12);"
                        >
                        <small class="text-muted">(optional, 12 digits only)</small>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Birthday:</label>
                        <input type="date" class="form-control" name="birthday" id="birthday" value="<?= htmlspecialchars($birthday) ?>" required onchange="calcAge()" >
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Age:</label>
                        <input type="text" class="form-control" name="age" id="age" value="<?= htmlspecialchars($age) ?>" readonly required>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Gender:</label>
                        <select class="form-select" name="gender" required>
                            <option value="">Select</option>
                            <option value="Male" <?= $gender=="Male"?"selected":"" ?>>Male</option>
                            <option value="Female" <?= $gender=="Female"?"selected":"" ?>>Female</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Address:</label>
                        <input type="text" class="form-control" name="address" value="<?= htmlspecialchars($address) ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Grade Section:</label>
                        <select class="form-select" name="section" id="sectionField" data-current-section="<?= htmlspecialchars($section) ?>" <?= $lockProtectedFields ? 'disabled' : '' ?>>
                            <option value="">No section yet</option>
                        </select>
                        <?php if ($lockProtectedFields): ?>
                            <input type="hidden" name="section" value="<?= htmlspecialchars($section) ?>">
                        <?php endif; ?>
                        <small class="text-muted" id="sectionHelpText">Select a section after choosing a grade level.</small>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">
                            Contact Number <span class="text-muted">(format: 09xx-xxx-xxxx)</span>:
                        </label>
                        <input type="text" class="form-control" name="contact" id="contact" value="<?= htmlspecialchars($contact) ?>" placeholder="e.g. 0917-345-6789" maxlength="13" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Grade Level:</label>
                        <select class="form-select" name="grade" id="gradeField" required <?= $lockProtectedFields ? 'disabled' : '' ?>>
                            <option value="">Select Grade</option>
                            <?php foreach ($grades as $g): ?>
                                <option value="<?= htmlspecialchars($g) ?>" <?= $grade==$g?"selected":"" ?>><?= htmlspecialchars($g) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if ($lockProtectedFields): ?>
                            <input type="hidden" name="grade" value="<?= htmlspecialchars($grade) ?>">
                        <?php endif; ?>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Date Enrolled:</label>
                        <input type="date" class="form-control" name="date_enrolled" value="<?= htmlspecialchars($date_enrolled) ?>" required>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Strand:</label>
                        <select class="form-select" name="strand" id="strandField" data-current-strand="<?= htmlspecialchars($strand) ?>">
                            <option value="">Select Strand</option>
                            <?php foreach ($strandOptions as $option): ?>
                                <option value="<?= htmlspecialchars($option) ?>" <?= $strand === $option ? "selected" : "" ?>><?= htmlspecialchars($option) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <small class="text-muted" id="strandHelpText">Required for Grade 11 or Grade 12 only.</small>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Guardian Name:</label>
                        <input type="text" class="form-control" name="guardian_name" value="<?= htmlspecialchars($guardian_name) ?>">
                        <small class="text-muted">(optional)</small>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">
                            Guardian Contact <span class="text-muted">(format: 09xx-xxx-xxxx, optional)</span>:
                        </label>
                        <input type="text" class="form-control" name="guardian_contact" id="guardian_contact" value="<?= htmlspecialchars($guardian_contact) ?>" placeholder="e.g. 0917-345-6789" maxlength="13">
                        <small class="text-muted">(optional)</small>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Photo (max <?= $maxPhotoMb ?>MB):</label>
                    <?php if ($photo): ?>
                        <img src="<?= htmlspecialchars(student_photo_public_url($photo)) ?>" alt="Photo" class="rounded mb-2" style="max-width:60px;max-height:60px;"><br>
                    <?php endif; ?>
                    <input type="file" class="form-control" name="photo" accept="image/*">
                </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-info"><i class="fas fa-save"></i> Update Student</button>
                    <a href="student-view.php?id=<?= $id ?>" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>
<footer class="text-center py-4 text-muted small">
    &copy; <?= date("Y") ?> The Lord's Wisdom Academy Of Caloocan Inc. | School Admin Dashboard
</footer>
<a href="/school-admin-dashboard/Dashboard.php" class="btn btn-dark dashboard-btn-bottom">
    <i class="fas fa-tachometer-alt"></i> Dashboard
</a>
<script>
const managedSectionsByGrade = <?= json_encode($managedSectionsByGrade, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;

function calcAge() {
    var bday = document.getElementById("birthday").value;
    if (bday) {
        var birth = new Date(bday);
        var today = new Date();
        var age = today.getFullYear() - birth.getFullYear();
        var m = today.getMonth() - birth.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
            age--;
        }
        document.getElementById("age").value = age;
    } else {
        document.getElementById("age").value = '';
    }
}
// Contact number mask: auto-format as 09xx-xxx-xxxx
document.addEventListener('DOMContentLoaded', function() {
    const gradeField = document.getElementById('gradeField');
    const sectionField = document.getElementById('sectionField');
    const sectionHelpText = document.getElementById('sectionHelpText');
    const strandField = document.getElementById('strandField');
    const strandHelpText = document.getElementById('strandHelpText');
    const seniorHighGrades = ['Grade 11', 'Grade 12'];

    function renderSectionOptions() {
        const selectedGrade = gradeField ? gradeField.value : '';
        const currentSection = sectionField ? (sectionField.dataset.currentSection || '') : '';
        const options = managedSectionsByGrade[selectedGrade] || [];

        if (!sectionField) {
            return;
        }

        sectionField.innerHTML = '';
        const emptyOption = document.createElement('option');
        emptyOption.value = '';
        emptyOption.textContent = 'No section yet';
        sectionField.appendChild(emptyOption);

        options.forEach((sectionName) => {
            const option = document.createElement('option');
            option.value = sectionName;
            option.textContent = sectionName;
            sectionField.appendChild(option);
        });

        if (currentSection && !options.includes(currentSection)) {
            const legacyOption = document.createElement('option');
            legacyOption.value = currentSection;
            legacyOption.textContent = currentSection + ' (saved value)';
            sectionField.appendChild(legacyOption);
        }

        sectionField.value = currentSection;
        if (sectionHelpText) {
            sectionHelpText.textContent = options.length > 0
                ? 'Only active sections for the selected grade level are shown here.'
                : 'No managed sections yet for this grade level. Leave this blank or add one in Settings.';
        }
    }

    function updateStrandState() {
        if (!strandField) {
            return;
        }
        const selectedGrade = gradeField ? gradeField.value : '';
        const isSeniorHigh = seniorHighGrades.includes(selectedGrade);

        strandField.disabled = !isSeniorHigh;
        if (isSeniorHigh) {
            if (strandField.dataset.currentStrand) {
                strandField.value = strandField.dataset.currentStrand;
            }
            if (strandHelpText) {
                strandHelpText.textContent = 'Select the strand for Grade 11 or Grade 12 students.';
            }
        } else {
            strandField.value = '';
            if (strandHelpText) {
                strandHelpText.textContent = 'Strand is only required for Grade 11 or Grade 12.';
            }
        }
    }

    function maskContact(input) {
        input.addEventListener('input', function(e) {
            let val = input.value.replace(/[^0-9]/g, '');
            if (val.length > 11) val = val.substring(0, 11);
            let formatted = '';
            if (val.length > 0) {
                formatted = val.substring(0, 4);
                if (val.length > 4) formatted += '-' + val.substring(4, 7);
                if (val.length > 7) formatted += '-' + val.substring(7, 11);
            }
            input.value = formatted;
        });
    }
    const contactInput = document.getElementById('contact');
    const guardianContactInput = document.getElementById('guardian_contact');
    if (contactInput) maskContact(contactInput);
    if (guardianContactInput) maskContact(guardianContactInput);
    // Theme toggle
    const btn = document.getElementById('themeToggleBtn');
    if (btn) {
        btn.addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');
            this.querySelector('i').classList.toggle('fa-moon');
            this.querySelector('i').classList.toggle('fa-sun');
        });
    }
    renderSectionOptions();
    updateStrandState();
    if (gradeField) {
        gradeField.addEventListener('change', function() {
            if (sectionField) {
                sectionField.dataset.currentSection = '';
            }
            if (strandField) {
                strandField.dataset.currentStrand = '';
            }
            renderSectionOptions();
            updateStrandState();
        });
    }
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
