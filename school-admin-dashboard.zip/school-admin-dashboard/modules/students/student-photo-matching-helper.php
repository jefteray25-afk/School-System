<?php

/**
 * Pure matching helpers for the staged Bulk Photo Attachment feature.
 * These functions do not read or write student records.
 */

function student_photo_grade_code(string $grade): string
{
    $normalized = strtolower(trim(preg_replace('/\s+/', ' ', $grade)));
    $map = [
        'junior kindergarten' => 'jr',
        'senior kindergarten' => 'sr',
    ];
    if (isset($map[$normalized])) {
        return $map[$normalized];
    }

    if (preg_match('/^grade\s*(1[0-2]|[1-9])$/', $normalized, $matches)) {
        return 'g' . (int) $matches[1];
    }

    return '';
}

function student_photo_normalize_key(string $value): string
{
    $value = trim(pathinfo($value, PATHINFO_FILENAME));
    if ($value === '') {
        return '';
    }

    if (function_exists('iconv')) {
        $transliterated = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
        if (is_string($transliterated) && $transliterated !== '') {
            $value = $transliterated;
        }
    }

    return strtolower((string) preg_replace('/[^a-z0-9]+/i', '', $value));
}

function student_photo_normalize_lrn(?string $lrn): string
{
    $digits = preg_replace('/\D+/', '', (string) $lrn);
    return strlen($digits) === 12 ? $digits : '1111';
}

function student_photo_student_name_key(array $student): string
{
    return student_photo_normalize_key(
        (string) ($student['lastname'] ?? '')
        . (string) ($student['firstname'] ?? '')
        . (string) ($student['middlename'] ?? '')
    );
}

function student_photo_expected_source_filename(array $student, string $extension = 'jpg'): string
{
    $gradeCode = student_photo_grade_code((string) ($student['grade'] ?? ''));
    $gradeCode = $gradeCode !== '' ? $gradeCode : 'grade';
    $lrn = student_photo_normalize_lrn((string) ($student['lrn'] ?? ''));
    $nameKey = student_photo_student_name_key($student);
    $nameKey = $nameKey !== '' ? $nameKey : 'student';
    $extension = strtolower(trim($extension));
    $extension = in_array($extension, ['jpg', 'jpeg', 'png'], true) ? $extension : 'jpg';

    return $gradeCode . '_' . $lrn . '_' . $nameKey . '.' . $extension;
}

function student_photo_parse_source_filename(string $filename): array
{
    $base = strtolower(trim(pathinfo($filename, PATHINFO_FILENAME)));
    if (!preg_match('/^(jr|sr|g(?:1[0-2]|[1-9]))_([0-9]{4}|[0-9]{12})_(.+)$/', $base, $matches)) {
        return ['valid' => false, 'grade_code' => '', 'lrn' => '', 'name_key' => ''];
    }

    $nameKey = student_photo_normalize_key($matches[3]);
    return [
        'valid' => $nameKey !== '',
        'grade_code' => $matches[1],
        'lrn' => $matches[2],
        'name_key' => $nameKey,
    ];
}
