﻿<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
include '../../config/database.php';
include __DIR__ . '/../settings/settings-permissions-roles.php';
include __DIR__ . '/../settings/school-year-helper.php';
include __DIR__ . '/student-registration-helper.php';
include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');

$currentRole = $_SESSION['role'] ?? '';
if (!isset($_SESSION['loggedin']) || !hasPermission($currentRole, 'student_registration', 'view')) {
    $blockedUser = $_SESSION['username'] ?? 'unknown';
    audit_log(
        $conn,
        $blockedUser,
        'Blocked student registration queue access',
        'Students',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing student_registration:view permission',
        'SECURITY'
    );
    admin_session_forbidden();
}

registration_ensure_pending_table($conn);
registration_csrf_token();
$schoolYearOptions = school_year_filter_options($conn);
$activeSchoolYearLabel = school_year_get_active_label($conn);

$user = $_SESSION['username'] ?? 'unknown';
$message = '';
$messageType = '';
$canApproveRegistrations = hasPermission($currentRole, 'student_registration', 'approve');
$canRejectRegistrations = hasPermission($currentRole, 'student_registration', 'reject');
$canImportRegistrations = hasPermission($currentRole, 'student_registration', 'import');
$canEditRegistrations = $canApproveRegistrations;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pendingId = (int) ($_POST['pending_id'] ?? 0);
    $action = $_POST['review_action'] ?? '';

    if (!registration_verify_csrf($_POST['csrf_token'] ?? '')) {
        $message = 'Invalid request token. Please refresh the page and try again.';
        $messageType = 'danger';
    } elseif ($action === 'import_offline_json' && !$canImportRegistrations) {
        $message = 'You do not have permission to import offline registrations.';
        $messageType = 'danger';
    } elseif ($action === 'approve' && !$canApproveRegistrations) {
        $message = 'You do not have permission to approve registrations.';
        $messageType = 'danger';
    } elseif ($action === 'reject' && !$canRejectRegistrations) {
        $message = 'You do not have permission to reject registrations.';
        $messageType = 'danger';
    } elseif ($action === 'import_offline_json') {
        if (!isset($_FILES['offline_json']) || $_FILES['offline_json']['error'] !== UPLOAD_ERR_OK) {
            $message = 'Please choose a valid offline JSON file.';
            $messageType = 'danger';
        } else {
            $rawJson = file_get_contents($_FILES['offline_json']['tmp_name']);
            $payload = json_decode($rawJson, true);
            $rows = registration_extract_import_rows($payload);
            if (count($rows) === 0) {
                $message = 'Invalid JSON file format.';
                $messageType = 'danger';
            } else {
                $summary = registration_import_pending_batch($conn, $rows);
                $message = 'Imported ' . $summary['imported'] . ' registration(s). Skipped ' . $summary['skipped'] . '.';
                if (!empty($summary['errors'])) {
                    $message .= ' Issues: ' . implode(' | ', array_slice($summary['errors'], 0, 5));
                }
                $messageType = $summary['imported'] > 0 ? 'success' : 'warning';
                $stations = [];
                foreach ($rows as $row) {
                    $station = trim((string) ($row['source_station'] ?? ''));
                    if ($station !== '') {
                        $stations[$station] = true;
                    }
                }
                audit_log($conn, $user, 'Imported offline registration queue', 'Students', 'Imported: ' . $summary['imported'] . ' | Skipped: ' . $summary['skipped'] . ' | Source Stations: ' . (implode(', ', array_keys($stations)) ?: 'unknown'));
            }
        }
    } elseif ($pendingId > 0 && $action === 'approve') {
        $approval = registration_approve_pending($conn, $pendingId, $user);
        if ($approval['success']) {
            $message = $approval['message'] ?? '';
            if ($message === '') {
                $message = 'Registration approved and student record created successfully.';
            }
            $messageType = !empty($approval['accounts_created']) ? 'success' : 'warning';
            audit_log($conn, $user, 'Approved student registration', 'Students', 'Student: ' . $approval['student_name'] . ' | LRN: ' . $approval['lrn']);
        } else {
            $message = $approval['message'];
            $messageType = 'danger';
        }
    } elseif ($pendingId > 0 && $action === 'reject') {
        $reason = trim($_POST['review_notes'] ?? '');
        $rejection = registration_reject_pending($conn, $pendingId, $user, $reason);
        if ($rejection['success']) {
            $message = 'Registration request rejected.';
            $messageType = 'warning';
            audit_log($conn, $user, 'Rejected student registration', 'Students', 'Pending Request ID: ' . $pendingId . ($reason !== '' ? ' | Reason: ' . $reason : ''));
        } else {
            $message = $rejection['message'];
            $messageType = 'danger';
        }
    }
}

audit_log($conn, $user, 'Viewed student registration approvals', 'Students', 'Role: ' . $currentRole);

$statusFilter = $_GET['status'] ?? 'Pending';
$hasSchoolYearParam = array_key_exists('school_year', $_GET);
$schoolYearFilter = trim($_GET['school_year'] ?? '');
if (!$hasSchoolYearParam) {
    $schoolYearFilter = $activeSchoolYearLabel;
}
$searchTerm = trim($_GET['search'] ?? '');
$allowedStatuses = ['Pending', 'Approved', 'Rejected', 'All'];
if (!in_array($statusFilter, $allowedStatuses, true)) {
    $statusFilter = 'Pending';
}

$countSql = "SELECT
    SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) AS pending_count,
    SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END) AS approved_count,
    SUM(CASE WHEN status = 'Rejected' THEN 1 ELSE 0 END) AS rejected_count
FROM student_registration_pending";
$counts = $conn->query($countSql)->fetch_assoc();

$where = [];
$params = [];
$types = '';

if ($statusFilter !== 'All') {
    $where[] = "status = ?";
    $params[] = $statusFilter;
    $types .= 's';
}

if ($schoolYearFilter !== '') {
    $where[] = "school_year_label = ?";
    $params[] = $schoolYearFilter;
    $types .= 's';
}

if ($searchTerm !== '') {
    $where[] = "(lrn LIKE ? OR lastname LIKE ? OR firstname LIKE ? OR section LIKE ?)";
    $searchLike = '%' . $searchTerm . '%';
    $params[] = $searchLike;
    $params[] = $searchLike;
    $params[] = $searchLike;
    $params[] = $searchLike;
    $types .= 'ssss';
}

$sql = "SELECT id, lastname, firstname, middlename, lrn, birthday, age, gender, address, contact, grade, strand, section, date_enrolled, school_year_label, photo, guardian_name, guardian_contact, status, submitted_at, reviewed_at, reviewed_by, review_notes, approved_student_id, source_channel, source_station, source_ip
FROM student_registration_pending";
if ($where) {
    $sql .= " WHERE " . implode(" AND ", $where);
}
$sql .= " ORDER BY CASE status WHEN 'Pending' THEN 0 WHEN 'Approved' THEN 1 ELSE 2 END, submitted_at DESC";

$stmt = $conn->prepare($sql);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pending Registration | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
            --header-bg: #23395d;
            --header-text: #fff;
            --table-head-bg: #eaf4ff;
        }
        body {
            background: var(--main-bg);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        }
        .navbar {
            background: var(--navbar-bg) !important;
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.08em;
        }
        .navbar-brand {
            font-weight: 700;
            letter-spacing: 1px;
        }
        .nav-link.active {
            border-bottom: 2px solid var(--brand-blue);
        }
        .dashboard-header {
            background: var(--header-bg);
            color: var(--header-text);
            padding: 30px 0 16px 0;
            border-bottom: 2px solid var(--brand-blue);
            text-align: center;
        }
        .dashboard-header img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            margin-bottom: 8px;
            background: #fff;
            border: 2px solid #fff;
        }
        .dashboard-header h1 {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 0;
        }
        .approval-card {
            background: var(--card-bg);
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(33,57,93,0.10);
            max-width: 1280px;
            margin: 32px auto;
            padding: 28px 24px;
        }
        .stats-strip {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 14px;
            margin-bottom: 20px;
        }
        .stat-box {
            background: #f7fbff;
            border: 1px solid #d6e9fb;
            border-radius: 14px;
            padding: 16px 18px;
        }
        .stat-box .label {
            color: var(--brand-blue);
            font-size: 0.95rem;
            font-weight: 600;
        }
        .stat-box .value {
            color: var(--brand-dark);
            font-size: 1.5rem;
            font-weight: 700;
        }
        .table th {
            background: var(--table-head-bg);
            color: var(--brand-dark);
        }
        .action-stack {
            min-width: 240px;
        }
        .note-box {
            width: 100%;
            min-height: 64px;
            resize: vertical;
        }
        .badge-soft {
            background: #eef5fc;
            color: var(--brand-dark);
        }
        @media (max-width: 768px) {
            .approval-card {
                padding: 18px 12px;
            }
            .dashboard-header img {
                width: 42px;
                height: 42px;
            }
        }
    </style>
</head>
<body>
<?php render_admin_nav('students'); ?>

<div class="dashboard-header">
    <img src="/school-admin-dashboard/uploads/logo1.png" alt="School Logo" class="mb-2 rounded shadow-sm">
    <h1><?= $schoolName ?></h1>
</div>

<div class="approval-card">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <div>
            <h2 class="mb-1"><i class="fas fa-user-clock text-primary me-2"></i>Pending Registration</h2>
            <div class="text-muted">Review incoming registration requests before moving them into official student records.</div>
        </div>
        <div>
            <a href="student-list.php" class="btn btn-outline-secondary"><i class="fas fa-arrow-left"></i> Back to Registrar</a>
        </div>
    </div>

    <?php if ($message !== ''): ?>
        <div class="alert alert-<?= htmlspecialchars($messageType) ?>"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <div class="card border-0 bg-light mb-3">
        <div class="card-body">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
                <div>
                    <strong><i class="fas fa-file-import me-2"></i>Offline Registration Import</strong>
                    <div class="small text-muted">Use this on the main server after exporting the offline JSON queue from PC 1, PC 2, or PC 3.</div>
                </div>
                <?php if ($canImportRegistrations): ?>
                <form method="post" enctype="multipart/form-data" class="d-flex flex-wrap gap-2 align-items-center">
                    <input type="hidden" name="review_action" value="import_offline_json">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(registration_csrf_token()) ?>">
                    <input type="file" name="offline_json" accept="application/json" class="form-control" required>
                    <button type="submit" class="btn btn-outline-primary">
                        <i class="fas fa-upload"></i> Import Offline Queue
                    </button>
                </form>
                <?php else: ?>
                <div class="small text-muted">Your role can view the queue but cannot import offline files.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="stats-strip">
        <div class="stat-box">
            <div class="label">Pending</div>
            <div class="value"><?= (int) ($counts['pending_count'] ?? 0) ?></div>
        </div>
        <div class="stat-box">
            <div class="label">Approved</div>
            <div class="value"><?= (int) ($counts['approved_count'] ?? 0) ?></div>
        </div>
        <div class="stat-box">
            <div class="label">Rejected</div>
            <div class="value"><?= (int) ($counts['rejected_count'] ?? 0) ?></div>
        </div>
    </div>

    <form method="get" class="row g-2 mb-3">
        <div class="col-md-3">
            <select name="status" class="form-select">
                <?php foreach ($allowedStatuses as $status): ?>
                    <option value="<?= htmlspecialchars($status) ?>" <?= $statusFilter === $status ? 'selected' : '' ?>><?= htmlspecialchars($status) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3">
            <select name="school_year" class="form-select">
                <option value="">All School Years</option>
                <?php foreach ($schoolYearOptions as $schoolYearOption): ?>
                    <option value="<?= htmlspecialchars($schoolYearOption) ?>" <?= $schoolYearFilter === $schoolYearOption ? 'selected' : '' ?>><?= htmlspecialchars($schoolYearOption) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-4">
            <input type="text" name="search" class="form-control" value="<?= htmlspecialchars($searchTerm) ?>" placeholder="Search by LRN, name, or section">
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-outline-primary w-100"><i class="fas fa-filter"></i> Filter</button>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
                <tr>
                    <th>Student</th>
                    <th>Request</th>
                    <th>Guardian</th>
                    <th>Status</th>
                    <th>Review</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <?php $duplicate = registration_find_duplicate($conn, $row['lrn'], (int) $row['id'], (string) ($row['school_year_label'] ?? '')); ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-start gap-2">
                                <?php if (!empty($row['photo'])): ?>
                                    <img
                                        src="<?= htmlspecialchars(student_photo_public_url((string) $row['photo'])) ?>"
                                        alt="Student photo"
                                        width="56"
                                        height="56"
                                        style="width:56px;height:56px;object-fit:cover;border-radius:8px;border:1px solid #dee2e6;flex-shrink:0;"
                                        onerror="this.onerror=null;this.src='/school-admin-dashboard/assets/img/default-profile.png';"
                                    >
                                <?php else: ?>
                                    <div style="width:56px;height:56px;border-radius:8px;border:1px solid #dee2e6;background:#f1f3f5;display:flex;align-items:center;justify-content:center;color:#adb5bd;flex-shrink:0;">
                                        <i class="fas fa-user"></i>
                                    </div>
                                <?php endif; ?>
                                <div>
                                    <strong><?= htmlspecialchars($row['lastname'] . ', ' . $row['firstname'] . ' ' . $row['middlename']) ?></strong><br>
                                    <span class="text-muted">LRN: <?= htmlspecialchars($row['lrn']) ?></span><br>
                                    <span class="text-muted"><?= htmlspecialchars($row['gender']) ?>, Age <?= (int) $row['age'] ?></span>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="badge badge-soft"><?= htmlspecialchars($row['grade']) ?></span>
                            <span class="badge badge-soft"><?= htmlspecialchars($row['section']) ?></span><br>
                            <?php if (!empty($row['strand'])): ?><span class="text-muted">Strand: <?= htmlspecialchars($row['strand']) ?></span><br><?php endif; ?>
                            <span class="text-muted">School Year: <?= htmlspecialchars($row['school_year_label'] ?: 'Unassigned') ?></span><br>
                            <span class="text-muted">Birthday: <?= htmlspecialchars(date('F j, Y', strtotime($row['birthday']))) ?></span><br>
                            <span class="text-muted">Submitted: <?= htmlspecialchars(date('F j, Y g:i A', strtotime($row['submitted_at']))) ?></span><br>
                            <span class="text-muted">Source: <?= htmlspecialchars($row['source_channel'] ?: 'public_online') ?><?= !empty($row['source_station']) ? ' | Station: ' . htmlspecialchars($row['source_station']) : '' ?><?= !empty($row['source_ip']) ? ' | IP: ' . htmlspecialchars($row['source_ip']) : '' ?></span><br>
                            <span class="text-muted">Contact: <?= htmlspecialchars($row['contact']) ?></span><br>
                            <span class="text-muted"><?= htmlspecialchars($row['address']) ?></span>
                        </td>
                        <td>
                            <strong><?= htmlspecialchars($row['guardian_name']) ?></strong><br>
                            <span class="text-muted"><?= htmlspecialchars($row['guardian_contact'] ?: 'No guardian contact') ?></span>
                        </td>
                        <td>
                            <?php if ($row['status'] === 'Pending'): ?>
                                <span class="badge bg-warning text-dark">Pending</span>
                            <?php elseif ($row['status'] === 'Approved'): ?>
                                <span class="badge bg-success">Approved</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Rejected</span>
                            <?php endif; ?>
                            <div class="small mt-2 <?= $duplicate['has_duplicate'] ? 'text-danger' : 'text-success' ?>">
                                <?= htmlspecialchars($duplicate['has_duplicate'] ? $duplicate['message'] : 'No duplicate LRN found.') ?>
                            </div>
                        </td>
                        <td>
                            <?php if (!empty($row['reviewed_by'])): ?>
                                <span class="text-muted">By <?= htmlspecialchars($row['reviewed_by']) ?></span><br>
                            <?php endif; ?>
                            <?php if (!empty($row['reviewed_at'])): ?>
                                <span class="text-muted"><?= htmlspecialchars(date('F j, Y g:i A', strtotime($row['reviewed_at']))) ?></span><br>
                            <?php endif; ?>
                            <?php if (!empty($row['review_notes'])): ?>
                                <span class="small text-muted"><?= nl2br(htmlspecialchars($row['review_notes'])) ?></span>
                            <?php elseif (!empty($row['approved_student_id'])): ?>
                                <a href="student-view.php?id=<?= (int) $row['approved_student_id'] ?>" class="small">Open approved student record</a>
                            <?php else: ?>
                                <span class="text-muted">Not reviewed yet</span>
                            <?php endif; ?>
                        </td>
                        <td class="action-stack">
                            <?php if ($row['status'] === 'Pending'): ?>
                                <form method="post" class="mb-2">
                                    <input type="hidden" name="pending_id" value="<?= (int) $row['id'] ?>">
                                    <input type="hidden" name="review_action" value="approve">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(registration_csrf_token()) ?>">
                                    <button type="submit" class="btn btn-success btn-sm w-100" <?= ($duplicate['has_duplicate'] || !$canApproveRegistrations) ? 'disabled' : '' ?>>
                                        <i class="fas fa-check"></i> Approve
                                    </button>
                                </form>
                                <?php if ($canEditRegistrations): ?>
                                <a href="student-registration-edit.php?id=<?= (int) $row['id'] ?>" class="btn btn-outline-primary btn-sm w-100 mb-2">
                                    <i class="fas fa-pen"></i> Edit Pending
                                </a>
                                <?php endif; ?>
                                <form method="post">
                                    <input type="hidden" name="pending_id" value="<?= (int) $row['id'] ?>">
                                    <input type="hidden" name="review_action" value="reject">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(registration_csrf_token()) ?>">
                                    <textarea name="review_notes" class="form-control note-box mb-2" placeholder="Optional rejection note"></textarea>
                                    <button type="submit" class="btn btn-outline-danger btn-sm w-100" <?= !$canRejectRegistrations ? 'disabled' : '' ?>>
                                        <i class="fas fa-ban"></i> Reject
                                    </button>
                                </form>
                            <?php else: ?>
                                <span class="text-muted">Review completed</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center text-muted">No registration requests found for this filter.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<footer class="text-center py-4 text-muted small">
    &copy; <?= date('Y') ?> <?= $schoolName ?> | School Admin Dashboard
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<?= admin_session_warning_script() ?>
</body>
</html>
<?php
$stmt->close();
$conn->close();
?>

