<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require_once __DIR__ . '/../../includes/ui.php';
include '../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/student-registration-helper.php';
require_once __DIR__ . '/student-requirements-helper.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

$active_school_year_label = school_year_get_active_label($conn);
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$_SESSION['student_list_return_url'] = $_SERVER['REQUEST_URI'];

// Lock state (persisted in session)
if (isset($_POST['lock_state'])) {
    admin_require_post_csrf();
    $_SESSION['students_list_locked'] = $_POST['lock_state'] === 'locked' ? 'locked' : 'unlocked';
    if ($_SESSION['students_list_locked'] === 'locked') {
        $lock_school_year = array_key_exists('school_year', $_GET) ? (string) ($_GET['school_year'] ?? '') : $active_school_year_label;
        $_SESSION['students_list_locked_filters'] = [
            'grade' => $_GET['grade'] ?? '',
            'school_year' => $lock_school_year,
            'search' => $_GET['search'] ?? '',
            'view_mode' => $_GET['view_mode'] ?? 'az',
            'page' => $_GET['page'] ?? '1',
        ];
    } else {
        unset($_SESSION['students_list_locked_filters']);
    }
    $lockAction = $_SESSION['students_list_locked'] === 'locked' ? 'Locked student list view filters' : 'Unlocked student list view filters';
    $lockDetails = 'Grade: ' . ($_GET['grade'] ?? '')
        . ' | School Year: ' . (array_key_exists('school_year', $_GET) ? (string) ($_GET['school_year'] ?? '') : $active_school_year_label)
        . ' | Search: ' . ($_GET['search'] ?? '')
        . ' | View Mode: ' . ($_GET['view_mode'] ?? 'az');
    audit_log($conn, $_SESSION['username'] ?? 'unknown', $lockAction, 'Students', $lockDetails, 'INFO');
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

$is_locked = ($_SESSION['students_list_locked'] ?? 'unlocked') === 'locked';
$locked_filters = $_SESSION['students_list_locked_filters'] ?? null;

// If locked, override GET with locked filters
if ($is_locked && $locked_filters) {
    $_GET['grade'] = $locked_filters['grade'];
    $_GET['school_year'] = $locked_filters['school_year'] ?? '';
    $_GET['search'] = $locked_filters['search'];
    $_GET['view_mode'] = $locked_filters['view_mode'] ?? 'az';
    $_GET['page'] = $locked_filters['page'];
}

// Get current role from session
$currentRole = $_SESSION['role'] ?? '';
$can_view   = hasPermission($currentRole, 'student_data', 'view');
$can_add    = hasPermission($currentRole, 'student_data', 'add');
$can_edit   = hasPermission($currentRole, 'student_data', 'edit');
$can_delete = hasPermission($currentRole, 'student_data', 'delete');   
$can_view_registration_queue = hasPermission($currentRole, 'student_registration', 'view');
$show_student_detail_panel = $can_view && (is_super_admin_role($currentRole) || is_administrator_role($currentRole));
if (!$can_view) {
    include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';
    $blockedUser = $_SESSION['username'] ?? 'unknown';
    audit_log(
        $conn,
        $blockedUser,
        'Blocked student list access',
        'Students',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing student_data:view permission',
        'SECURITY'
    );
    admin_session_forbidden();
}
$delete_success = isset($_GET['deleted']) && $_GET['deleted'] === '1';

student_requirements_ensure_table($conn);
registration_ensure_student_strand_column($conn);

// Handle filter/search/sort
$selected_grade = $_GET['grade'] ?? '';
$has_school_year_param = array_key_exists('school_year', $_GET);
$selected_school_year = trim($_GET['school_year'] ?? '');
if (!$is_locked && !$has_school_year_param) {
    $selected_school_year = $active_school_year_label;
}
$search_term = trim($_GET['search'] ?? '');
$view_mode = trim((string) ($_GET['view_mode'] ?? 'az'));
$allowed_view_modes = ['az', 'za', 'missing_lrn', 'no_section', 'incomplete_requirements'];
if (!in_array($view_mode, $allowed_view_modes, true)) {
    $view_mode = 'az';
}
$sort_order = $view_mode === 'za' ? 'za' : 'az';

$page = max(intval($_GET['page'] ?? '1'), 1);
$limit = 60;
$offset = ($page - 1) * $limit;

$grades = [
    "Junior Kindergarten", "Senior Kindergarten", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5",
    "Grade 6", "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"
];
$school_year_options = school_year_filter_options($conn);
$totalRequirementItems = count(student_requirements_catalog($conn));

$where = [];
$params = [];
$types = '';

if ($selected_grade) {
    $where[] = "grade = ?";
    $params[] = $selected_grade;
    $types .= 's';
}
if ($selected_school_year !== '') {
    $where[] = "school_year_label = ?";
    $params[] = $selected_school_year;
    $types .= 's';
}
if ($search_term) {
    $where[] = "(lrn LIKE ? OR CONCAT(COALESCE(lastname,''), ' ', COALESCE(firstname,''), ' ', COALESCE(middlename,'')) LIKE ? OR section LIKE ?)";
    $params[] = "%" . $search_term . "%"; // for LRN
    $params[] = "%" . $search_term . "%"; // for Name
	$params[] = "%" . $search_term . "%"; // for Section
    $types .= 'sss';
}
if ($view_mode === 'missing_lrn') {
    $where[] = "COALESCE(NULLIF(TRIM(lrn), ''), '') = ''";
} elseif ($view_mode === 'no_section') {
    $where[] = "COALESCE(NULLIF(TRIM(section), ''), '') = ''";
} elseif ($view_mode === 'incomplete_requirements' && $totalRequirementItems > 0) {
    $where[] = "(SELECT COUNT(DISTINCT srd.requirement_key) FROM student_requirement_documents srd WHERE srd.student_id = students.id) < ?";
    $params[] = $totalRequirementItems;
    $types .= 'i';
}

$sql_count = "SELECT COUNT(*) FROM students";
if ($where) {
    $sql_count .= " WHERE " . implode(" AND ", $where);
}
$stmt_count = $conn->prepare($sql_count);
if ($params) {
    $stmt_count->bind_param($types, ...$params);
}
$stmt_count->execute();
$stmt_count->bind_result($total_students);
$stmt_count->fetch();
$stmt_count->close();

$total_pages = max(ceil($total_students / $limit), 1);

$sql_total_all = "SELECT COUNT(*) FROM students";
$stmt_total_all = $conn->prepare($sql_total_all);
$stmt_total_all->execute();
$stmt_total_all->bind_result($grand_total_students);
$stmt_total_all->fetch();
$stmt_total_all->close();

registration_ensure_pending_table($conn);
$pending_registration_count = 0;
$pendingCountResult = $conn->query("SELECT COUNT(*) AS pending_count FROM student_registration_pending WHERE status = 'Pending'");
if ($pendingCountResult) {
    $pending_registration_count = (int) ($pendingCountResult->fetch_assoc()['pending_count'] ?? 0);
}

// ADD SECTION TO SQL SELECT!!!
$sql = "SELECT id, lastname, firstname, middlename, lrn, grade, strand, section, date_enrolled, school_year_label, photo FROM students";
if ($where) {
    $sql .= " WHERE " . implode(" AND ", $where);
}
$sql .= " ORDER BY lastname " . ($sort_order === 'az' ? 'ASC' : 'DESC') . ", firstname " . ($sort_order === 'az' ? 'ASC' : 'DESC') . " LIMIT ? OFFSET ?";

$stmt = $conn->prepare($sql);
if ($params) {
    $params[] = $limit;
    $params[] = $offset;
    $types .= 'ii';
    $stmt->bind_param($types, ...$params);
} else {
    $stmt->bind_param('ii', $limit, $offset);
}
$stmt->execute();
$result = $stmt->get_result();
$studentRows = [];
$studentIds = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $studentRows[] = $row;
        $studentIds[] = (int) ($row['id'] ?? 0);
    }
}

$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Official Students | School Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <?php ui_css_link(); ?>
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
            --header-bg: #23395d;
            --header-text: #fff;
            --table-head-bg: #eaf4ff;
            --table-row-hover-bg: #f7fafc;
            --export-blue: #5bb2fc;
            --student-count-blue: #2d7dca;
        }
        body {
            background: var(--main-bg);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
            transition: background 0.6s;
        }
        body.dark-mode {
            --main-bg: #1b232d;
            --card-bg: #23395d;
            --navbar-bg: #161b22;
            --header-bg: #161b22;
            --header-text: #e6edf3;
            color: #e6edf3;
        }
        .navbar {
            background: var(--navbar-bg) !important;
            transition: background 0.6s;
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.08em;
        }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .nav-link.active { border-bottom: 2px solid var(--brand-blue); }
        .theme-toggle-btn {
            background: none;
            border: none;
            color: #fff;
            font-size: 1.45em;
            margin-left: 12px;
            cursor: pointer;
            transition: color 0.3s;
        }
        .dashboard-header {
            background: var(--header-bg);
            color: var(--header-text);
            padding: 30px 0 16px 0;
            border-bottom: 2px solid var(--brand-blue);
            box-shadow: 0 4px 18px rgba(33,57,93,0.10);
            text-align: center;
            margin-bottom: 0;
        }
        .dashboard-header img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            margin-bottom: 8px;
            border: 2px solid #fff;
            box-shadow: 0 2px 8px rgba(33,57,93,0.10);
            background: #fff;
        }
        .dashboard-header h1 {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 0;
            letter-spacing: 1px;
            transition: color 0.6s;
        }
        .student-list-card {
            background: var(--card-bg);
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(33,57,93,0.10);
            width: min(1880px, calc(100vw - 24px));
            max-width: none;
            margin: 32px auto 34px auto;
            padding: 34px 20px;
            transition: background 0.6s, color 0.6s;
            animation: fadeIn .8s forwards;
        }
        .student-list-card h2 {
            color: var(--brand-dark);
            font-size: 1.28em;
            font-weight: 700;
            margin-bottom: 18px;
        }
        .students-table th {
            background: var(--table-head-bg);
            color: var(--brand-dark);
            font-weight: 600;
            font-size: 1em;
        }
        .students-table td {
            font-size: 0.98em;
            color: var(--brand-blue);
        }
        .students-table tr {
            transition: background .3s;
        }
        .students-table tr:hover {
            background: var(--table-row-hover-bg);
        }
        .fa-user-graduate {
            color: var(--brand-blue);
            font-size: 1.3em;
            margin-right: 8px;
            vertical-align: middle;
        }
        .btn-success {
            background: var(--brand-blue);
            border: none;
        }
        .btn-success:hover {
            background: #3a5d87;
        }
        .btn-outline-secondary {
            border-color: var(--brand-blue);
            color: var(--brand-blue);
        }
        .btn-outline-secondary:hover {
            background: var(--brand-blue);
            color: #fff;
        }
        @keyframes fadeIn {
            to { opacity: 1;}
        }
        @media (max-width: 900px) {
            .student-list-card { width: calc(100vw - 14px); padding: 16px 14px;}
        }
        @media (max-width: 576px) {
            .dashboard-header h1 { font-size: 1.01rem;}
            .dashboard-header img { width: 34px; height: 34px;}
            .student-list-card { width: calc(100vw - 8px); padding: 10px 6px; font-size: 0.97em;}
            .students-table th, .students-table td { font-size: 0.92em;}
        }
.view-action-group {
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-end;
            gap: 0.65rem;
            align-items: center;
        }
        .view-action-group .btn,
        .view-utility-actions .utility-chip {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.45rem;
            min-height: 42px;
            padding: 0.58rem 0.95rem;
            border-radius: 12px;
            font-size: 0.92rem;
            font-weight: 600;
            line-height: 1.2;
            box-shadow: 0 8px 18px rgba(35,57,93,0.06);
        }
        .view-utility-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 0.65rem;
            align-items: center;
            padding-left: 0.65rem;
            border-left: 1px solid #d9e3ef;
            margin-left: 0.15rem;
        }
        .utility-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            min-height: 42px;
            padding: 0.58rem 0.95rem;
            border-radius: 12px;
            border: 1px solid #d7e2ef;
            background: #f7fbff;
            color: var(--vw-brand-dark);
            font-size: 0.92rem;
            font-weight: 600;
            text-decoration: none;
            box-shadow: 0 8px 18px rgba(35,57,93,0.06);
            transition: background 0.2s ease, border-color 0.2s ease, color 0.2s ease, transform 0.2s ease;
        }
        .utility-chip:hover {
            background: #eef5fc;
            border-color: #c8d8e9;
            color: var(--vw-brand-dark);
            transform: translateY(-1px);
        }
        .utility-chip-count {
            background: #eef5fc;
            color: var(--vw-brand-mid);
            cursor: default;
        }
        .utility-chip-count:hover {
            background: #eef5fc;
            border-color: #d7e2ef;
            color: var(--vw-brand-mid);
            transform: none;
        }
        .utility-chip-lock.locked {
            background: #fff2f2;
            border-color: #efc2c2;
            color: #b23b3b;
        }
        .utility-chip-lock.unlocked {
            background: #f2fbf4;
            border-color: #c7e4cd;
            color: #247a3d;
        }
        .utility-chip-lock {
            cursor: pointer;
        }
        @media (max-width: 991px) {
            .view-action-group {
                justify-content: flex-start;
            }
            .view-utility-actions {
                padding-left: 0;
                margin-left: 0;
                border-left: 0;
                width: 100%;
            }
        }
        .locked-filter {
            pointer-events: none;
            opacity: 0.4;
        }
.students-table th:nth-child(1), .students-table td:nth-child(1) { width: 64px; min-width: 64px; text-align: center; white-space: nowrap; }
		.students-table th:nth-child(2), .students-table td:nth-child(2) { width: 28%; min-width: 280px; }
		.students-table th:nth-child(3), .students-table td:nth-child(3) { width: 14%; min-width: 150px; text-align: center; }
		.students-table th:nth-child(4), .students-table td:nth-child(4) { width: 16%; min-width: 170px; text-align: center; }
		.students-table th:nth-child(5), .students-table td:nth-child(5) { width: 16%; min-width: 170px; text-align: center; }
        .students-table th:nth-child(6), .students-table td:nth-child(6) { width: 12%; min-width: 150px; text-align: center; }
		.students-table th:nth-child(7), .students-table td:nth-child(7) { width: 14%; min-width: 180px; text-align: center; white-space: nowrap; }
        /* View Wave 1 + 2: shared list view system */
        :root {
            --vw-page-bg: #eef3f9;
            --vw-card-bg: #ffffff;
            --vw-card-border: #d9e3ef;
            --vw-brand-dark: #23395d;
            --vw-brand-mid: #517fa4;
            --vw-brand-soft: #edf4fb;
            --vw-text-soft: #5f7186;
        }
        body {
            background:
                radial-gradient(circle at top left, rgba(81,127,164,0.14), transparent 30%),
                linear-gradient(180deg, #f8fbff 0%, var(--vw-page-bg) 100%);
            color: var(--vw-brand-dark);
        }
        .dashboard-header {
            background: transparent;
            border-bottom: 0;
            box-shadow: none;
            padding-top: 32px;
            padding-bottom: 10px;
        }
        .dashboard-header img {
            width: 72px;
            height: 72px;
            border-radius: 18px;
            padding: 6px;
            border: 0;
            box-shadow: 0 10px 25px rgba(35,57,93,0.12);
        }
        .dashboard-header h1 {
            color: var(--vw-brand-dark);
            font-weight: 800;
        }
        .student-list-card {
            background: var(--vw-card-bg);
            border: 1px solid var(--vw-card-border);
            border-radius: 20px;
            box-shadow: 0 14px 32px rgba(35,57,93,0.07);
        }
        .student-list-card h2 {
            font-weight: 800;
            margin-bottom: 1rem;
        }
        .view-intro {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 14px;
            flex-wrap: wrap;
            margin-bottom: 1rem;
        }
        .view-kicker {
            font-size: 0.78rem;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: var(--vw-text-soft);
            font-weight: 800;
            margin-bottom: 0.3rem;
        }
        .view-title {
            font-size: 1.35rem;
            font-weight: 800;
            color: var(--vw-brand-dark);
            margin-bottom: 0.35rem;
        }
        .view-subtitle {
            color: var(--vw-text-soft);
            margin-bottom: 0;
        }
        .student-list-card > form.row {
            background: #f8fbff;
            border: 1px solid var(--vw-card-border);
            border-radius: 16px;
            padding: 14px 12px;
            margin-bottom: 1rem !important;
        }
        .student-list-card .form-select,
        .student-list-card .form-control {
            border-color: #d7e1ed;
            min-height: 44px;
            box-shadow: none;
        }
        .student-list-card .btn-success,
        .student-list-card .btn-primary {
            background: var(--vw-brand-dark);
            border-color: var(--vw-brand-dark);
            font-weight: 600;
        }
        .student-list-card .btn-success:hover,
        .student-list-card .btn-primary:hover {
            background: #1d2f4a;
            border-color: #1d2f4a;
        }
        .student-list-card .btn-outline-secondary,
        .student-list-card .btn-outline-primary {
            background: #eef3f8;
            border-color: #d7e1ed;
            color: var(--vw-brand-dark);
            font-weight: 600;
        }
        .student-list-card .btn-outline-secondary:hover,
        .student-list-card .btn-outline-primary:hover {
            background: #e1eaf4;
            border-color: #c8d5e4;
            color: var(--vw-brand-dark);
        }
        .students-table {
            margin-bottom: 0;
            width: 100%;
        }
        .students-table th {
            background: var(--vw-brand-soft);
            border-bottom: 1px solid var(--vw-card-border);
            font-weight: 700;
            white-space: nowrap;
        }
        .students-table td {
            color: var(--vw-brand-dark);
            vertical-align: middle;
        }
        .students-table tr:hover {
            background: #f8fbff;
        }
        .students-table .badge {
            border-radius: 999px;
            padding: 0.5rem 0.75rem;
        }
        .student-list-card .alert {
            border-radius: 14px;
        }
        .students-table .btn.btn-sm {
            border-radius: 10px;
            min-width: 40px;
            min-height: 36px;
            font-weight: 700;
            border-width: 1px;
            box-shadow: none;
        }
        .students-table .btn.btn-primary {
            background: #edf4fb;
            border-color: #d7e1ed;
            color: var(--vw-brand-dark);
        }
        .students-table .btn.btn-warning {
            background: #fff4d8;
            border-color: #f0dd9a;
            color: #8a6400;
        }
        .students-table .btn.btn-danger {
            background: #fdecec;
            border-color: #f2c9c9;
            color: #b42318;
        }
        .students-table .btn.btn-sm:hover {
            filter: brightness(0.98);
        }
        .students-table a.text-decoration-none {
            color: var(--vw-brand-dark);
            font-weight: 700;
        }
        .students-table a.text-decoration-none:hover {
            color: var(--vw-brand-mid);
        }
        .app-table-wrap {
            width: 100%;
        }
        .app-table-wrap .table-responsive {
            overflow-x: auto;
        }
        .student-detail-trigger {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            white-space: nowrap;
            max-width: 100%;
        }
        .student-detail-trigger .fa-id-card-clip {
            color: var(--vw-brand-mid);
            font-size: 0.95rem;
        }
        .student-detail-trigger .student-name-text {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            display: inline-block;
            max-width: 100%;
        }
        .bulk-toolbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
            margin-bottom: 0.85rem;
        }
        .bulk-toolbar .selection-note {
            color: var(--vw-text-soft);
            font-weight: 700;
        }
        .bulk-toolbar .btn[disabled] {
            opacity: 0.65;
            cursor: not-allowed;
        }
        .student-wave-shell {
            margin-top: 1.25rem;
            border: 1px solid var(--vw-card-border);
            border-radius: 18px;
            background: #fff;
            box-shadow: 0 12px 28px rgba(35,57,93,0.06);
            overflow: hidden;
        }
        .student-wave-placeholder {
            padding: 1.2rem 1.25rem;
            color: var(--vw-text-soft);
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.9rem;
        }
        .student-wave-placeholder i {
            width: 42px;
            height: 42px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background: var(--vw-brand-soft);
            color: var(--vw-brand-mid);
            flex-shrink: 0;
        }
        .student-panel-notice {
            padding: 1rem 1.25rem 0 1.25rem;
        }
        .student-wave-loading {
            padding: 1rem 1.25rem;
            color: var(--vw-text-soft);
            font-weight: 700;
        }
        .student-wave-panel .card-header {
            background: linear-gradient(135deg, var(--vw-brand-dark), var(--vw-brand-mid));
            color: #fff;
            border: 0;
            padding: 1rem 1.1rem;
        }
        .student-wave-panel .panel-kicker {
            font-size: 0.78rem;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            font-weight: 800;
            opacity: 0.85;
            margin-bottom: 0.35rem;
        }
        .student-wave-panel .panel-title {
            font-size: 1.2rem;
            font-weight: 800;
        }
        .student-wave-panel .panel-subtitle {
            opacity: 0.9;
            margin-top: 0.2rem;
            font-size: 0.92rem;
        }
        .student-wave-panel .panel-block {
            border: 1px solid var(--vw-card-border);
            border-radius: 16px;
            background: #fbfdff;
            padding: 1rem;
        }
        .student-wave-panel .block-title {
            font-size: 0.98rem;
            font-weight: 800;
            color: var(--vw-brand-dark);
            margin-bottom: 0.8rem;
        }
        .student-wave-panel .detail-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 0.75rem 0.9rem;
        }
        .student-wave-panel .detail-grid div {
            display: grid;
            gap: 0.18rem;
            min-width: 0;
        }
        .student-wave-panel .detail-grid strong {
            font-size: 0.8rem;
            letter-spacing: 0.04em;
            text-transform: uppercase;
            color: var(--vw-text-soft);
        }
        .student-wave-panel .summary-chips {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 0.8rem;
        }
        .student-wave-panel .summary-chips.compact-summary {
            align-items: center;
            margin-bottom: 0;
        }
        .student-wave-panel .summary-chip {
            display: inline-flex;
            align-items: center;
            border-radius: 999px;
            background: var(--vw-brand-soft);
            color: var(--vw-brand-dark);
            padding: 0.5rem 0.85rem;
            font-weight: 700;
        }
        .student-wave-panel .snapshot-stats {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 0.8rem;
        }
        .student-wave-panel .snapshot-stat {
            background: #f8fbff;
            border: 1px solid #e1ebf5;
            border-radius: 14px;
            padding: 0.85rem 0.9rem;
            display: grid;
            gap: 0.15rem;
        }
        .student-wave-panel .snapshot-label {
            color: var(--vw-text-soft);
            font-size: 0.78rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-weight: 700;
        }
        .student-wave-panel .snapshot-value {
            color: var(--vw-brand-dark);
            font-size: 1.25rem;
            line-height: 1.1;
            font-weight: 800;
        }
        .student-wave-panel .requirement-select {
            width: 100%;
            min-width: 0;
        }
        .student-wave-panel .requirement-note {
            width: 100%;
            min-width: 0;
        }
        .student-wave-panel .requirement-update-stack {
            width: min(230px, 100%);
            display: grid;
            gap: 0.45rem;
        }
        .student-wave-panel .requirement-activity-list {
            display: grid;
            gap: 0.9rem;
            max-height: 420px;
            overflow-y: auto;
            padding-right: 0.35rem;
        }
        .student-wave-panel .activity-item {
            display: grid;
            grid-template-columns: 34px 1fr;
            gap: 0.85rem;
            align-items: start;
            padding-bottom: 0.9rem;
            border-bottom: 1px solid #e7eef6;
        }
        .student-wave-panel .activity-item:last-child {
            border-bottom: 0;
            padding-bottom: 0;
        }
        .student-wave-panel .activity-dot {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--vw-brand-soft);
            color: var(--vw-brand-mid);
            border: 1px solid #d7e1ed;
            font-size: 0.9rem;
        }
        .student-wave-panel .activity-title {
            color: var(--vw-brand-dark);
            font-weight: 600;
            margin-bottom: 0.2rem;
        }
        .student-wave-panel .activity-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 0.55rem 1rem;
            color: var(--vw-text-soft);
            font-size: 0.85rem;
            margin-bottom: 0.2rem;
        }
        .student-wave-panel .activity-note {
            color: var(--vw-brand-dark);
            font-size: 0.9rem;
            background: #f8fbff;
            border: 1px solid #e1ebf5;
            border-radius: 10px;
            padding: 0.55rem 0.7rem;
        }
        .student-wave-panel .requirement-activity-list::-webkit-scrollbar {
            width: 10px;
        }
        .student-wave-panel .requirement-activity-list::-webkit-scrollbar-track {
            background: #eef3f9;
            border-radius: 999px;
        }
        .student-wave-panel .requirement-activity-list::-webkit-scrollbar-thumb {
            background: #c3d2e2;
            border-radius: 999px;
            border: 2px solid #eef3f9;
        }
        .student-wave-panel .requirement-activity-list::-webkit-scrollbar-thumb:hover {
            background: #aebfd3;
        }
        .student-wave-panel .table th,
        .student-wave-panel .table td {
            vertical-align: top;
        }
        .student-wave-panel .table {
            margin-bottom: 0;
        }
        .student-wave-panel .student-panel-photo {
            width: 180px;
            height: 180px;
            object-fit: cover;
            border-radius: 18px;
            border: 4px solid #e2ebf4;
            background: #f8fbff;
            box-shadow: 0 10px 22px rgba(35,57,93,0.10);
        }
        .student-wave-panel .student-panel-photo-placeholder {
            width: 180px;
            height: 180px;
            margin: 0 auto;
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3.4rem;
            background: linear-gradient(135deg, #edf4fb, #dce9f8);
            color: var(--vw-brand-mid);
            border: 1px solid #d7e1ed;
        }
        .student-detail-active td {
            background: #f8fbff;
        }
        @media (max-width: 991px) {
            .student-wave-panel .detail-grid {
                grid-template-columns: 1fr;
            }
            .student-wave-panel .snapshot-stats {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
<?php render_admin_nav('students', true); ?>

<?php render_school_page_header($schoolName); ?>

<div class="student-list-card app-page">
    <div class="view-intro">
        <div>
            <div class="view-kicker">Student Records</div>
            <div class="view-title"><i class="fas fa-user-graduate me-2"></i>Official Students</div>
            <p class="view-subtitle">Browse official student records, apply school-year filters, and manage registrar work from one place.</p>
        </div>
        <?php if ($can_add || $can_view_registration_queue || $show_student_detail_panel || !is_limited_admin_operator_role($currentRole)): ?>
        <div class="view-action-group">
            <?php if ($can_view_registration_queue): ?>
            <a href="student-registration-pending.php" class="btn btn-outline-primary">
                <i class="fas fa-user-clock"></i> Pending Registration
                <?php if ($pending_registration_count > 0): ?>
                    <span class="badge bg-danger ms-1"><?= $pending_registration_count ?></span>
                <?php endif; ?>
            </a>
            <?php endif; ?>
            <?php if ($can_add): ?>
            <a href="student-add.php" class="btn btn-success">
                <i class="fas fa-plus"></i> Add Official Student
            </a>
            <?php endif; ?>
            <?php if ($show_student_detail_panel): ?>
            <a href="#studentDetailWorkspace" class="btn btn-outline-warning">
                <i class="fas fa-folder-open"></i> Requirements Desk
            </a>
            <?php endif; ?>
            <?php if (can_access_reports_dashboard($currentRole) && !is_accounting_staff_role($currentRole)): ?>
            <a href="/school-admin-dashboard/modules/reports/reports-academic.php?school_year=<?= urlencode($selected_school_year !== '' ? $selected_school_year : $active_school_year_label) ?>" class="btn btn-outline-dark">
                <i class="fas fa-chart-column"></i> Registrar Reports
            </a>
            <?php endif; ?>
            <div class="view-utility-actions">
                <form id="lockForm" method="post" class="m-0">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(admin_csrf_token()) ?>">
                    <input type="hidden" name="lock_state" id="lockStateField" value="<?= $is_locked ? 'locked' : 'unlocked' ?>">
                    <button type="button" class="utility-chip utility-chip-lock <?= $is_locked ? 'locked' : 'unlocked' ?>" id="lockBtn" title="<?= $is_locked ? 'Locked - Cannot change filters' : 'Unlocked - Can change filters' ?>">
                        <i class="fas <?= $is_locked ? 'fa-lock' : 'fa-key' ?>"></i>
                        <span><?= $is_locked ? 'Locked View' : 'Unlocked View' ?></span>
                    </button>
                </form>
                <div class="utility-chip utility-chip-count" id="studentCountBtn" title="Total students (filtered)">
                    <i class="fas fa-users"></i>
                    <span><?= number_format($total_students) ?> Students</span>
                </div>
                <a href="student-list-export.php?grade=<?= urlencode($selected_grade) ?>&school_year=<?= urlencode($selected_school_year) ?>&search=<?= urlencode($search_term) ?>&sort=<?= urlencode($sort_order) ?>&view_mode=<?= urlencode($view_mode) ?>" class="utility-chip" title="Export to Excel">
                    <i class="fas fa-file-excel"></i>
                    <span>Export</span>
                </a>
                <?php if ($_SESSION['role'] == 'Super Administrator'): ?>
                <a href="student-import-list.php" class="utility-chip" title="Import Students">
                    <i class="fas fa-file-import"></i>
                    <span>Import</span>
                </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <form class="row g-2 mb-3 <?= $is_locked ? 'locked-filter' : '' ?>" method="get" action="">
        <div class="col-md-3">
            <select name="grade" class="form-select" <?= $is_locked ? 'disabled' : '' ?> onchange="this.form.submit()">
                <option value="">Filter by Grade Level</option>
                <?php foreach ($grades as $g): ?>
                    <option value="<?= htmlspecialchars($g) ?>" <?= $selected_grade==$g?'selected':'' ?>>
                        <?= htmlspecialchars($g) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3">
            <select name="school_year" class="form-select" <?= $is_locked ? 'disabled' : '' ?> onchange="this.form.submit()">
                <option value="">All School Years</option>
                <?php foreach ($school_year_options as $schoolYearOption): ?>
                    <option value="<?= htmlspecialchars($schoolYearOption) ?>" <?= $selected_school_year === $schoolYearOption ? 'selected' : '' ?>>
                        <?= htmlspecialchars($schoolYearOption) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3">
            <input type="text" name="search" class="form-control" placeholder="Search by Name or LRN or Section" value="<?= htmlspecialchars($search_term) ?>" <?= $is_locked ? 'disabled' : '' ?>>
        </div>
        <div class="col-md-2">
            <select name="view_mode" class="form-select" <?= $is_locked ? 'disabled' : '' ?> onchange="this.form.submit()">
                <option value="az" <?= $view_mode=='az'?'selected':'' ?>>Sort Name: A &rarr; Z</option>
                <option value="za" <?= $view_mode=='za'?'selected':'' ?>>Sort Name: Z &rarr; A</option>
                <option value="missing_lrn" <?= $view_mode=='missing_lrn'?'selected':'' ?>>View: Missing LRN</option>
                <option value="no_section" <?= $view_mode=='no_section'?'selected':'' ?>>View: No Section</option>
                <option value="incomplete_requirements" <?= $view_mode=='incomplete_requirements'?'selected':'' ?>>View: Incomplete Requirements</option>
            </select>
        </div>
        <div class="col-md-2">
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-outline-secondary flex-fill" <?= $is_locked ? 'disabled' : '' ?>>
                    <i class="fas fa-filter"></i> Filter
                </button>
                <a href="student-list.php" class="btn btn-outline-danger flex-fill <?= $is_locked ? 'disabled' : '' ?>" <?= $is_locked ? 'tabindex="-1" aria-disabled="true"' : '' ?>>
                    <i class="fas fa-rotate-left"></i> Clear
                </a>
            </div>
        </div>
    </form>
    <?php if ($is_locked): ?>
        <div class="mb-2">
            <span class="text-danger"><i class="fas fa-lock"></i> <b>Locked view:</b>
                Grade: <strong><?= htmlspecialchars($_GET['grade']) ?></strong>,
                School Year: <strong><?= htmlspecialchars($_GET['school_year'] ?? '') ?></strong>,
                Search: <strong><?= htmlspecialchars($_GET['search']) ?></strong>,
                View: <strong><?= htmlspecialchars($_GET['view_mode'] ?? 'az') ?></strong>,
                Page: <strong><?= htmlspecialchars($_GET['page']) ?></strong>
            </span>
        </div>
    <?php endif; ?>
    <?php if ($delete_success): ?>
        <div class="alert alert-success" role="alert">
            <i class="fas fa-check-circle"></i> Student deleted successfully.
        </div>
    <?php endif; ?>
    <?php if (isset($_GET['bulk_deleted'])): ?>
        <div class="alert alert-success" role="alert">
            <i class="fas fa-check-circle"></i> Deleted <?= number_format((int) $_GET['bulk_deleted']) ?> student record(s).
        </div>
    <?php endif; ?>
    <?php if ($can_delete): ?>
    <div class="bulk-toolbar">
        <div class="selection-note"><span id="studentSelectionCount">0</span> selected</div>
        <div class="d-flex gap-2">
            <button type="button" class="btn btn-outline-secondary btn-sm" id="studentToggleAllBtn">
                <i class="fas fa-check-square"></i> Mark All
            </button>
            <button type="button" class="btn btn-danger btn-sm" id="bulkStudentDeleteBtn" disabled>
                <i class="fas fa-trash"></i> Delete Selected
            </button>
        </div>
    </div>
    <?php endif; ?>
    <form method="post" action="student-bulk-delete.php" id="bulkStudentDeleteForm" class="d-none">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
        <div id="bulkStudentDeleteSelectedIds"></div>
    </form>
    <div class="app-table-wrap">
    <div class="table-responsive">
        <table class="table students-table app-table align-middle">
            <thead>
                <tr>
                    <?php if ($can_delete): ?><th><input type="checkbox" id="studentSelectAll"></th><?php endif; ?>
                    <th>#</th>
                    <th>Full Name</th>
                    <th>LRN</th>
                    <th>Grade</th>
                    <th>Section</th>
                    <th>Date Enrolled</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!empty($studentRows)): ?>
                <?php $i = 1; ?>
                <?php foreach ($studentRows as $row): ?>
                <tr>
                    <?php if ($can_delete): ?><td><input type="checkbox" class="student-row-check" value="<?= (int) $row['id'] ?>"></td><?php endif; ?>
                    <td><?= $i ?></td>
                    <td>
                        <a href="student-view.php?id=<?= $row['id'] ?>" class="text-decoration-none student-detail-trigger d-inline-flex align-items-center gap-2" data-student-id="<?= (int) $row['id'] ?>">
                            <?php if (!empty($row['photo'])): ?>
                                <img
                                    src="<?= htmlspecialchars(student_photo_public_url((string) $row['photo'])) ?>"
                                    alt=""
                                    width="40"
                                    height="40"
                                    style="width:40px;height:40px;object-fit:cover;border-radius:8px;border:1px solid #dee2e6;flex-shrink:0;"
                                    onerror="this.onerror=null;this.src='/school-admin-dashboard/assets/img/default-profile.png';"
                                >
                            <?php else: ?>
                                <span style="width:40px;height:40px;border-radius:8px;border:1px solid #dee2e6;background:#f1f3f5;display:inline-flex;align-items:center;justify-content:center;color:#adb5bd;flex-shrink:0;">
                                    <i class="fas fa-user"></i>
                                </span>
                            <?php endif; ?>
                            <span class="student-name-text"><?= htmlspecialchars($row['lastname'] . ', ' . $row['firstname'] . ' ' . $row['middlename']) ?></span>
                        </a>
                    </td>
                    <td><?= htmlspecialchars($row['lrn']) ?></td>
                    <td>
                        <?= htmlspecialchars($row['grade']) ?><br>
                        <?php if (!empty($row['strand'])): ?>
                            <span class="small text-muted">Strand: <?= htmlspecialchars($row['strand']) ?></span><br>
                        <?php endif; ?>
                        <span class="small text-muted"><?= htmlspecialchars($row['school_year_label'] ?: 'Unassigned') ?></span>
                    </td>
                    <td><?= htmlspecialchars($row['section']) ?></td>
                    <td>
                        <?php if (!empty($row['date_enrolled'])): ?>
                            <?= htmlspecialchars(date('F j, Y', strtotime($row['date_enrolled']))) ?>
                        <?php else: ?>
                            <span class="text-muted"><i>Not set</i></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="btn-group" role="group">
                            <a href="student-view.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-primary" title="View">
                                <i class="fas fa-eye"></i>
                            </a>
                            <?php if ($can_edit): ?>
                            <a href="student-edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning" title="Edit" <?= $is_locked ? 'disabled' : '' ?>>
                                <i class="fas fa-edit"></i>
                            </a>
                            <?php endif; ?>
                            <?php if ($can_delete): ?>
                            <a href="student-delete.php?id=<?= (int) $row['id'] ?>" class="btn btn-sm btn-danger <?= $is_locked ? 'disabled' : '' ?>" title="Open delete confirmation" <?= $is_locked ? 'tabindex="-1" aria-disabled="true"' : '' ?>>
                                <i class="fas fa-trash"></i> Delete
                            </a>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php $i++; ?>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="<?= $can_delete ? 8 : 7 ?>" class="text-center text-muted">No students found.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    </div>
    <?php if ($can_view && $show_student_detail_panel): ?>
    <div class="student-wave-shell" id="studentDetailWorkspace">
        <div id="studentPanelNotice" class="student-panel-notice d-none"></div>
        <div class="student-wave-placeholder" id="studentDetailPlaceholder">
            <i class="fas fa-address-card"></i>
            <div>
                <div class="fw-bold text-dark">Requirements Desk</div>
                <div>Select a student name above to load the student record, requirements, notes, and follow-up status here.</div>
            </div>
        </div>
        <div id="studentDetailPanel"></div>
    </div>
    <?php endif; ?>
    <nav aria-label="Student list pagination" class="mt-3">
        <ul class="pagination justify-content-center <?= $is_locked ? 'locked-filter' : '' ?>">
            <?php
            $query_string = http_build_query(array_filter([
                'grade' => $selected_grade,
                'school_year' => $selected_school_year,
                'search' => $search_term,
                'view_mode' => $view_mode,
            ]));
            $base_url = 'student-list.php' . ($query_string ? '?' . $query_string . '&' : '?');
            ?>
            <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                <a class="page-link" href="<?= $base_url ?>page=<?= $page-1 ?>" aria-label="Previous" <?= $is_locked ? 'tabindex="-1"' : '' ?>>&laquo;</a>
            </li>
            <?php
            $start = max(1, $page - 2);
            $end = min($total_pages, $start + 4);
            if ($end - $start < 4) $start = max(1, $end - 4);
            for ($i = $start; $i <= $end; $i++):
            ?>
            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                <a class="page-link" href="<?= $base_url ?>page=<?= $i ?>" <?= $is_locked ? 'tabindex="-1"' : '' ?>><?= $i ?></a>
            </li>
            <?php endfor; ?>
            <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>">
                <a class="page-link" href="<?= $base_url ?>page=<?= $page+1 ?>" aria-label="Next" <?= $is_locked ? 'tabindex="-1"' : '' ?>>&raquo;</a>
            </li>
        </ul>
    </nav>
</div>

<footer class="text-center py-4 text-muted small">
    &copy; <?= date("Y") ?> <?= $schoolName ?> | School Admin Dashboard
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('themeToggleBtn').addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        this.querySelector('i').classList.toggle('fa-moon');
        this.querySelector('i').classList.toggle('fa-sun');
    });

    var isLocked = <?= $is_locked ? 'true' : 'false' ?>;
    var lockBtn = document.getElementById('lockBtn');
    var lockStateField = document.getElementById('lockStateField');
    lockBtn.addEventListener('click', function() {
        isLocked = !isLocked;
        lockStateField.value = isLocked ? 'locked' : 'unlocked';
        document.getElementById('lockForm').submit();
    });

    const studentChecks = Array.from(document.querySelectorAll('.student-row-check'));
    const studentSelectAll = document.getElementById('studentSelectAll');
    const studentToggleAllBtn = document.getElementById('studentToggleAllBtn');
    const studentSelectionCount = document.getElementById('studentSelectionCount');
    const bulkStudentDeleteBtn = document.getElementById('bulkStudentDeleteBtn');
    const bulkStudentDeleteForm = document.getElementById('bulkStudentDeleteForm');
    const bulkStudentDeleteSelectedIds = document.getElementById('bulkStudentDeleteSelectedIds');
    const studentDetailPanel = document.getElementById('studentDetailPanel');
    const studentDetailPlaceholder = document.getElementById('studentDetailPlaceholder');
    const studentPanelNotice = document.getElementById('studentPanelNotice');
    const studentWaveShell = document.getElementById('studentWaveShell');
    const studentDetailTriggers = Array.from(document.querySelectorAll('.student-detail-trigger'));
    let activeStudentId = null;

    function updateStudentSelectionState() {
        if (!studentSelectionCount || !bulkStudentDeleteBtn) return;
        const checked = studentChecks.filter(cb => cb.checked).length;
        studentSelectionCount.textContent = checked;
        bulkStudentDeleteBtn.disabled = checked === 0;
        if (studentSelectAll) {
            studentSelectAll.checked = studentChecks.length > 0 && checked === studentChecks.length;
        }
        if (studentToggleAllBtn) {
            studentToggleAllBtn.innerHTML = checked === studentChecks.length && checked > 0
                ? '<i class="fas fa-square"></i> Unmark All'
                : '<i class="fas fa-check-square"></i> Mark All';
        }
    }

    if (studentSelectAll) {
        studentSelectAll.addEventListener('change', function() {
            studentChecks.forEach(cb => cb.checked = studentSelectAll.checked);
            updateStudentSelectionState();
        });
    }

    if (studentToggleAllBtn) {
        studentToggleAllBtn.addEventListener('click', function() {
            const allChecked = studentChecks.length > 0 && studentChecks.every(cb => cb.checked);
            studentChecks.forEach(cb => cb.checked = !allChecked);
            if (studentSelectAll) studentSelectAll.checked = !allChecked;
            updateStudentSelectionState();
        });
    }

    if (bulkStudentDeleteBtn && bulkStudentDeleteForm && bulkStudentDeleteSelectedIds) {
        bulkStudentDeleteBtn.addEventListener('click', function() {
            const checkedRows = studentChecks.filter(cb => cb.checked);
            if (checkedRows.length === 0) return;
            bulkStudentDeleteSelectedIds.innerHTML = '';
            checkedRows.forEach(cb => {
                const hiddenInput = document.createElement('input');
                hiddenInput.type = 'hidden';
                hiddenInput.name = 'selected_ids[]';
                hiddenInput.value = cb.value;
                bulkStudentDeleteSelectedIds.appendChild(hiddenInput);
            });
            bulkStudentDeleteForm.submit();
        });
    }

    studentChecks.forEach(cb => cb.addEventListener('change', updateStudentSelectionState));
    updateStudentSelectionState();

    function setActiveStudentRow(studentId) {
        document.querySelectorAll('.students-table tbody tr').forEach(row => row.classList.remove('student-detail-active'));
        if (!studentId) return;
        const trigger = document.querySelector(`.student-detail-trigger[data-student-id="${studentId}"]`);
        const row = trigger ? trigger.closest('tr') : null;
        if (row) {
            row.classList.add('student-detail-active');
        }
    }

    async function loadStudentDetailPanel(studentId, formData = null) {
        if (!studentDetailPanel) return;
        const targetUrl = `student-detail-panel.php?id=${encodeURIComponent(studentId)}`;
        studentDetailPanel.innerHTML = '<div class="student-wave-loading"><i class="fas fa-spinner fa-spin"></i> Loading student details...</div>';
        try {
            const response = await fetch(targetUrl, {
                method: formData ? 'POST' : 'GET',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });
            const html = await response.text();
            studentDetailPanel.innerHTML = html;
            if (studentDetailPlaceholder) {
                studentDetailPlaceholder.style.display = 'none';
            }
            if (studentPanelNotice) {
                studentPanelNotice.classList.add('d-none');
                studentPanelNotice.innerHTML = '';
            }
            activeStudentId = studentId;
            setActiveStudentRow(studentId);
            bindStudentRequirementForm();
            if (formData && studentPanelNotice) {
                const panelAlert = studentDetailPanel.querySelector('.alert');
                if (panelAlert) {
                    studentPanelNotice.innerHTML = panelAlert.outerHTML;
                    studentPanelNotice.classList.remove('d-none');
                } else {
                    studentPanelNotice.innerHTML = '<div class="alert alert-success mb-0"><i class="fas fa-check-circle"></i> Requirement statuses updated.</div>';
                    studentPanelNotice.classList.remove('d-none');
                }
            }
            if (studentWaveShell) {
                studentWaveShell.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        } catch (error) {
            if (studentPanelNotice) {
                studentPanelNotice.innerHTML = '<div class="alert alert-danger mb-0"><i class="fas fa-triangle-exclamation"></i> Could not save or load the student detail panel right now.</div>';
                studentPanelNotice.classList.remove('d-none');
            }
            studentDetailPanel.innerHTML = '<div class="alert alert-danger m-3 mb-0">Could not load the student detail panel right now.</div>';
        }
    }

    window.submitStudentRequirementPanel = function(form) {
        if (!form) return false;
        const studentId = form.dataset.studentId || activeStudentId;
        const saveBtn = form.querySelector('#studentRequirementSaveBtn');
        if (!studentId) return false;
        const confirmed = window.confirm('Save these requirement updates for this student?');
        if (!confirmed) {
            return false;
        }
        if (saveBtn) {
            saveBtn.disabled = true;
            saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
        }
        loadStudentDetailPanel(studentId, new FormData(form));
        return false;
    };

    function bindStudentRequirementForm() {
        const form = document.getElementById('studentRequirementForm');
        if (!form) return;
        form.onsubmit = function() {
            return window.submitStudentRequirementPanel(form);
        };
    }

    studentDetailTriggers.forEach(trigger => {
        trigger.addEventListener('click', function(event) {
            event.preventDefault();
            const studentId = this.dataset.studentId;
            if (!studentId) return;
            loadStudentDetailPanel(studentId);
        });
    });
</script>
<?= admin_session_warning_script() ?>
</body>
</html>
<?php $stmt->close(); $conn->close(); ?>
