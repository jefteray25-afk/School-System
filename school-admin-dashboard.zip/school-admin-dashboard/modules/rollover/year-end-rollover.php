<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require '../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/year-end-rollover-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function money_fmt(float $amount): string
{
    return 'PHP ' . number_format($amount, 2);
}

function rollover_student_matches_search(array $student, string $search): bool
{
    $search = trim($search);
    if ($search === '') {
        return true;
    }

    $haystack = implode(' ', [
        student_full_name_from_row($student),
        (string) ($student['lrn'] ?? ''),
        (string) ($student['grade'] ?? ''),
        (string) ($student['section'] ?? ''),
    ]);

    return stripos($haystack, $search) !== false;
}

function rollover_student_matches_status(array $student, string $status): bool
{
    switch ($status) {
        case 'ready':
            return !$student['next_done'] && !$student['old_done'] && $student['can_roll_next'];
        case 'next_ready':
            return $student['can_roll_next'] && !$student['next_done'];
        case 'old_ready':
            return $student['can_roll_old'] && !$student['old_done'];
        case 'next_done':
            return $student['next_done'] && !$student['old_done'];
        case 'old_done':
            return $student['old_done'] && !$student['next_done'];
        case 'both_done':
            return $student['next_done'] && $student['old_done'];
        case 'graduates':
            return !$student['can_roll_next'];
        case 'needs_review':
            return (!$student['can_roll_next']) || ($student['can_roll_old'] && !$student['old_done'] && $student['outstanding_balance'] > 0);
        case 'all':
        default:
            return true;
    }
}

$currentRole = $_SESSION['role'] ?? '';
$username = $_SESSION['username'] ?? 'unknown';
if (!can_access_year_end_rollover($currentRole)) {
    audit_log(
        $conn,
        $username,
        'Blocked year-end rollover access',
        'Year-End Rollover',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing year-end rollover access',
        'SECURITY'
    );
    admin_session_forbidden();
}

school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
year_end_rollover_ensure_table($conn);
$schemaReady = year_end_rollover_table_exists($conn);

$sourceYear = school_year_get_active_label($conn);
$targetOptions = year_end_rollover_target_options($conn, $sourceYear);
$selectedTargetYear = year_end_rollover_next_target_year($targetOptions, $sourceYear);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['lock_rollover_view'])) {
    $_SESSION['rollover_locked_filters'] = [
        'target_school_year' => $_POST['target_school_year'] ?? $_GET['target_school_year'] ?? '',
        'student_search' => $_POST['student_search'] ?? $_GET['student_search'] ?? '',
        'status_filter' => $_POST['status_filter'] ?? $_GET['status_filter'] ?? 'all',
        'grade_filter' => $_POST['grade_filter'] ?? $_GET['grade_filter'] ?? 'all',
    ];
    header('Location: year-end-rollover.php');
    exit();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['unlock_rollover_view'])) {
    unset($_SESSION['rollover_locked_filters']);
    header('Location: year-end-rollover.php');
    exit();
}

$rolloverFiltersLocked = isset($_SESSION['rollover_locked_filters']);
if ($rolloverFiltersLocked) {
    $_GET['target_school_year'] = $_SESSION['rollover_locked_filters']['target_school_year'] ?? '';
    $_GET['student_search'] = $_SESSION['rollover_locked_filters']['student_search'] ?? '';
    $_GET['status_filter'] = $_SESSION['rollover_locked_filters']['status_filter'] ?? 'all';
    $_GET['grade_filter'] = $_SESSION['rollover_locked_filters']['grade_filter'] ?? 'all';
}

$searchQuery = trim((string) ($_GET['student_search'] ?? $_POST['student_search'] ?? ''));
$statusFilter = trim((string) ($_GET['status_filter'] ?? $_POST['status_filter'] ?? 'all'));
$gradeFilter = trim((string) ($_GET['grade_filter'] ?? $_POST['grade_filter'] ?? 'all'));
$allowedStatusFilters = ['all', 'ready', 'next_ready', 'old_ready', 'next_done', 'old_done', 'both_done', 'graduates', 'needs_review'];
if (!in_array($statusFilter, $allowedStatusFilters, true)) {
    $statusFilter = 'all';
}

$message = '';
$messageType = 'success';
$preview = null;
$selectedNextIds = [];
$selectedOldIds = [];

$students = $selectedTargetYear !== '' ? year_end_rollover_students($conn, $sourceYear, $selectedTargetYear) : [];
$summary = year_end_rollover_summary($students);
$gradeOptions = [];
foreach ($students as $student) {
    $grade = trim((string) ($student['grade'] ?? ''));
    if ($grade !== '') {
        $gradeOptions[$grade] = $grade;
    }
}
ksort($gradeOptions);
if ($gradeFilter !== 'all' && $gradeFilter !== '' && !isset($gradeOptions[$gradeFilter])) {
    $gradeFilter = 'all';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!school_year_verify_csrf($_POST['csrf_token'] ?? '')) {
        $message = 'Invalid request token. Please refresh the page and try again.';
        $messageType = 'danger';
    } elseif ($selectedTargetYear === '') {
        $message = 'Please create or select the next school year first.';
        $messageType = 'danger';
    } else {
        $selectedNextIds = year_end_rollover_selected_ids($_POST['next_ids'] ?? []);
        $selectedOldIds = year_end_rollover_selected_ids($_POST['old_ids'] ?? []);
        $action = trim((string) ($_POST['rollover_action'] ?? 'preview'));

        if (!$selectedNextIds && !$selectedOldIds) {
            $message = 'Select at least one student destination before continuing.';
            $messageType = 'warning';
        } elseif ($action === 'apply') {
            $applyResult = year_end_rollover_apply($conn, $students, $sourceYear, $selectedTargetYear, $selectedNextIds, $selectedOldIds, $username);
            if (!empty($applyResult['success'])) {
                $counts = $applyResult['result'] ?? ['next' => 0, 'old' => 0, 'both' => 0];
                $message = 'Year-End Rollover applied successfully. Next School Year: ' . (int) ($counts['next'] ?? 0)
                    . ' | Old Accounts: ' . (int) ($counts['old'] ?? 0)
                    . ' | Both: ' . (int) ($counts['both'] ?? 0);
                $messageType = 'success';
                audit_log(
                    $conn,
                    $username,
                    'Applied year-end rollover',
                    'Year-End Rollover',
                    'Source Year: ' . $sourceYear
                    . ' | Target Year: ' . $selectedTargetYear
                    . ' | Next School Year: ' . (int) ($counts['next'] ?? 0)
                    . ' | Old Accounts: ' . (int) ($counts['old'] ?? 0)
                    . ' | Both: ' . (int) ($counts['both'] ?? 0)
                );
                $students = year_end_rollover_students($conn, $sourceYear, $selectedTargetYear);
                $summary = year_end_rollover_summary($students);
                $selectedNextIds = [];
                $selectedOldIds = [];
            } else {
                $message = 'Rollover apply failed: ' . h($applyResult['message'] ?? 'Unknown error');
                $messageType = 'danger';
            }
        } else {
            $preview = year_end_rollover_preview($students, $selectedNextIds, $selectedOldIds);
            if (($preview['counts']['next'] ?? 0) === 0 && ($preview['counts']['old'] ?? 0) === 0) {
                $message = 'No valid rollover actions were found in the selected rows.';
                $messageType = 'warning';
            }
        }
    }
}

$filteredStudents = array_values(array_filter($students, static function (array $student) use ($searchQuery, $statusFilter, $gradeFilter): bool {
    if (!rollover_student_matches_search($student, $searchQuery)) {
        return false;
    }
    if (!rollover_student_matches_status($student, $statusFilter)) {
        return false;
    }
    if ($gradeFilter !== 'all' && trim((string) ($student['grade'] ?? '')) !== $gradeFilter) {
        return false;
    }
    return true;
}));
$filteredSummary = year_end_rollover_summary($filteredStudents);
$filteredSourceIds = array_map(static fn(array $student): int => (int) ($student['id'] ?? 0), $filteredStudents);
$filteredSourceLookup = array_fill_keys(array_filter($filteredSourceIds), true);

$nextRows = $selectedTargetYear !== '' ? year_end_rollover_destination_rows($conn, $sourceYear, $selectedTargetYear, 'next') : [];
$oldRows = $selectedTargetYear !== '' ? year_end_rollover_destination_rows($conn, $sourceYear, $selectedTargetYear, 'old') : [];
if ($filteredSourceLookup) {
    $nextRows = array_values(array_filter($nextRows, static fn(array $row): bool => isset($filteredSourceLookup[(int) ($row['source_student_id'] ?? 0)])));
    $oldRows = array_values(array_filter($oldRows, static fn(array $row): bool => isset($filteredSourceLookup[(int) ($row['source_student_id'] ?? 0)])));
} else {
    $nextRows = [];
    $oldRows = [];
}
$csrfToken = school_year_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Year-End Rollover</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --page-bg: #eef4fb;
            --card-bg: #ffffff;
            --navy: #23395d;
            --blue: #2f74c8;
            --soft-blue: #eaf3ff;
            --soft-border: #d7e6f7;
            --text-muted: #68788d;
        }
        body {
            background: radial-gradient(circle at top left, #f8fbff 0, #eef4fb 55%, #e8f0f9 100%);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
            min-height: 100vh;
        }
        .app-navbar {
            background: linear-gradient(90deg, #1f4e79 0%, #275d8c 48%, #2e6a9f 100%);
            border-bottom: 1px solid rgba(255,255,255,0.14);
        }
        .app-navbar .navbar-brand,
        .app-navbar .nav-link,
        .app-navbar .navbar-toggler {
            color: #f7fbff !important;
        }
        .app-navbar .nav-link {
            font-weight: 600;
            opacity: 0.92;
            transition: background-color .18s ease, color .18s ease, opacity .18s ease;
            border-radius: 10px;
            padding: 8px 12px;
        }
        .app-navbar .nav-link:hover,
        .app-navbar .nav-link.active {
            background: rgba(255,255,255,0.15);
            color: #ffffff !important;
            opacity: 1;
        }
        .app-navbar .badge.bg-secondary {
            background: rgba(255,255,255,0.18) !important;
            color: #ffffff;
        }
        .app-navbar .btn-outline-light {
            border-color: rgba(255,255,255,0.55);
            color: #ffffff;
        }
        .app-navbar .btn-outline-light:hover {
            background: rgba(255,255,255,0.16);
            color: #ffffff;
            border-color: rgba(255,255,255,0.72);
        }
        .page-shell {
            max-width: 1700px;
            margin: 0 auto;
            padding: 28px 18px 46px;
        }
        .hero-card,
        .section-card {
            background: rgba(255,255,255,0.96);
            border: 1px solid rgba(215,230,247,0.9);
            border-radius: 24px;
            box-shadow: 0 18px 48px rgba(35,57,93,0.08);
        }
        .hero-card {
            padding: 24px 26px;
            margin-bottom: 22px;
        }
        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            border-radius: 999px;
            padding: 6px 12px;
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: .08em;
            text-transform: uppercase;
            color: var(--blue);
            background: var(--soft-blue);
            border: 1px solid var(--soft-border);
        }
        .hero-title {
            color: var(--navy);
            font-size: 2rem;
            font-weight: 800;
            margin: 14px 0 8px;
        }
        .hero-subtitle {
            color: var(--text-muted);
            max-width: 880px;
            margin: 0;
        }
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 14px;
            margin-top: 20px;
        }
        .summary-tile {
            border-radius: 20px;
            padding: 16px 18px;
            background: linear-gradient(180deg, #fbfdff 0%, #f3f8ff 100%);
            border: 1px solid var(--soft-border);
        }
        .summary-tile .label {
            color: var(--text-muted);
            font-size: .8rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .05em;
        }
        .summary-tile .value {
            color: var(--navy);
            font-size: 1.65rem;
            font-weight: 800;
            margin-top: 6px;
            line-height: 1;
        }
        .section-card {
            padding: 22px;
            margin-bottom: 20px;
        }
        .section-title {
            color: var(--navy);
            font-size: 1.05rem;
            font-weight: 800;
            margin-bottom: 4px;
        }
        .section-note {
            color: var(--text-muted);
            font-size: .93rem;
            margin-bottom: 16px;
        }
        .toolbar {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            align-items: end;
        }
        .toolbar .field {
            min-width: 220px;
        }
        .toolbar .field-wide {
            min-width: 320px;
            flex: 1 1 320px;
        }
        .table-wrap {
            overflow-x: auto;
        }
        .table-rollover {
            min-width: 1220px;
            margin-bottom: 0;
        }
        .table-rollover thead th {
            background: #f3f8ff;
            color: var(--navy);
            font-size: .8rem;
            text-transform: uppercase;
            letter-spacing: .05em;
            border-bottom: 1px solid #d6e4f4;
        }
        .table-rollover td, .table-rollover th {
            vertical-align: middle;
        }
        .student-name {
            font-weight: 700;
            color: var(--navy);
        }
        .student-meta {
            color: var(--text-muted);
            font-size: .87rem;
        }
        .status-chip {
            display: inline-flex;
            align-items: center;
            border-radius: 999px;
            padding: 6px 11px;
            font-size: .78rem;
            font-weight: 700;
            border: 1px solid transparent;
        }
        .chip-ready { background: #eef9f0; color: #157347; border-color: #cce7d3; }
        .chip-warn { background: #fff7e6; color: #9a6700; border-color: #ffe0a3; }
        .chip-done { background: #eaf3ff; color: #0b63c9; border-color: #cfe0fb; }
        .chip-both { background: #eef4ff; color: #4a3fb7; border-color: #d8d4fb; }
        .chip-muted { background: #f3f4f6; color: #556170; border-color: #e3e5ea; }
        .table-rollover tbody tr {
            transition: background-color .18s ease;
        }
        .table-rollover tbody tr:hover {
            background: #f9fbff;
        }
        .grade-pill {
            display: inline-flex;
            align-items: center;
            border-radius: 999px;
            padding: 8px 12px;
            background: #f7faff;
            border: 1px solid #dbe8f8;
            color: var(--navy);
            font-weight: 700;
            font-size: .88rem;
        }
        .grade-pill.current-grade {
            background: linear-gradient(180deg, #ffffff 0%, #f5f9ff 100%);
        }
        .grade-flow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            border-radius: 16px;
            padding: 8px 12px;
            background: #f7fbff;
            border: 1px solid #d6e5f6;
            color: var(--navy);
            font-weight: 700;
            font-size: .88rem;
        }
        .grade-flow .flow-arrow {
            color: #7b8ba1;
            font-size: .78rem;
        }
        .balance-pill {
            display: inline-flex;
            align-items: center;
            border-radius: 16px;
            padding: 9px 12px;
            background: linear-gradient(180deg, #fffdf7 0%, #fff7e9 100%);
            border: 1px solid #f5dfb2;
            color: #8b5a10;
            font-weight: 800;
            font-size: .9rem;
            white-space: nowrap;
        }
        .action-card {
            display: flex;
            flex-direction: column;
            gap: 8px;
            min-width: 180px;
            padding: 10px 12px;
            border-radius: 18px;
            border: 1px solid #dce8f6;
            background: linear-gradient(180deg, #ffffff 0%, #f7fbff 100%);
        }
        .action-card.is-disabled {
            background: #f7f8fb;
            border-color: #e5e9ef;
        }
        .action-card .form-check {
            margin-bottom: 0;
        }
        .action-card .form-check-input {
            margin-top: .2rem;
        }
        .action-card .form-check-label {
            font-size: .92rem;
            font-weight: 700;
            color: var(--navy);
        }
        .action-meta {
            color: var(--text-muted);
            font-size: .78rem;
            line-height: 1.35;
        }
        .status-stack {
            display: inline-flex;
            flex-direction: column;
            gap: 8px;
            align-items: flex-start;
            min-width: 170px;
        }
        .status-helper {
            color: var(--text-muted);
            font-size: .78rem;
            line-height: 1.35;
        }
        .destination-grid {
            display: grid;
            grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
            gap: 18px;
            align-items: start;
        }
        .source-panel {
            grid-column: 1 / -1;
        }
        .panel-card {
            min-width: 0;
        }
        .panel-card {
            overflow: hidden;
            transition: width .22s ease, opacity .18s ease;
        }
        .panel-head {
            display: flex;
            align-items: start;
            justify-content: space-between;
            gap: 14px;
            margin-bottom: 14px;
        }
        .panel-kicker {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border-radius: 999px;
            padding: 5px 10px;
            background: #edf5ff;
            border: 1px solid #d7e7fb;
            color: #1b5eb8;
            font-size: .72rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: .05em;
            margin-bottom: 8px;
        }
        .panel-head-actions {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
        }
        .panel-count {
            min-width: 42px;
            height: 42px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 14px;
            background: linear-gradient(180deg, #f8fbff 0%, #eef5ff 100%);
            border: 1px solid #dbe7f8;
            color: var(--navy);
            font-weight: 800;
        }
        .panel-toggle {
            border-radius: 12px;
            min-width: 42px;
            height: 42px;
            padding: 0;
        }
        .panel-body {
            transition: opacity .18s ease;
        }
        .panel-card.minimized .panel-body {
            display: none;
        }
        .panel-card.minimized {
            padding-bottom: 18px;
        }
        .panel-summary {
            display: none;
            margin-top: 8px;
            color: var(--text-muted);
            font-size: .84rem;
            line-height: 1.45;
        }
        .panel-card.minimized .panel-summary {
            display: block;
        }
        .preview-list {
            margin: 0;
            padding-left: 18px;
            color: var(--navy);
        }
        .preview-actions,
        .selection-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 18px;
        }
        .mini-table {
            min-width: 100%;
        }
        .mini-table thead th {
            background: #f8fbff;
            color: var(--navy);
            font-size: .78rem;
            text-transform: uppercase;
            letter-spacing: .05em;
        }
        .mini-name {
            color: var(--navy);
            font-weight: 700;
        }
        .mini-meta {
            color: var(--text-muted);
            font-size: .82rem;
        }
        .filter-meta {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 14px;
        }
        .filter-pill {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border-radius: 999px;
            padding: 6px 12px;
            font-size: .78rem;
            font-weight: 700;
            color: var(--navy);
            background: #f5f9ff;
            border: 1px solid var(--soft-border);
        }
        .rollover-filter-form.locked-view input,
        .rollover-filter-form.locked-view select,
        .rollover-filter-form.locked-view button[type="submit"]:not(.rollover-lock-btn) {
            pointer-events: none;
            opacity: 0.68;
        }
        .rollover-lock-btn {
            border-radius: 999px;
            font-weight: 700;
            min-height: 42px;
            padding-inline: 1rem;
        }
        .rollover-lock-btn.locked {
            background: #fff1f2;
            color: #9f1239;
            border-color: #f5c2c7;
        }
        @media (max-width: 1200px) {
            .destination-grid {
                grid-template-columns: 1fr;
            }
            .source-panel {
                grid-column: auto;
            }
        }
    </style>
</head>
<body>
<?php render_admin_nav('rollover'); ?>
<div class="page-shell">
    <div class="hero-card">
        <div class="eyebrow"><i class="fas fa-repeat"></i> Year-End Rollover</div>
        <h1 class="hero-title">Carry current students forward without manual re-encoding</h1>
        <p class="hero-subtitle">This workspace uses the active school year as the source, then lets us copy students into the next school year, Old Accounts, or both. Previous records stay intact, while completed destinations become unclickable to prevent duplicates.</p>
        <div class="summary-grid">
            <div class="summary-tile"><div class="label">Current Source Year</div><div class="value" style="font-size:1.15rem;"><?= h($sourceYear) ?></div></div>
            <div class="summary-tile"><div class="label">Current Students</div><div class="value"><?= (int) $summary['total'] ?></div></div>
            <div class="summary-tile"><div class="label">Eligible Next Year</div><div class="value"><?= (int) $summary['eligible_next'] ?></div></div>
            <div class="summary-tile"><div class="label">Eligible Old Accounts</div><div class="value"><?= (int) $summary['eligible_old'] ?></div></div>
            <div class="summary-tile"><div class="label">Next Done</div><div class="value"><?= (int) $summary['next_done'] ?></div></div>
            <div class="summary-tile"><div class="label">Old Done</div><div class="value"><?= (int) $summary['old_done'] ?></div></div>
        </div>
    </div>

    <?php if (!$schemaReady): ?>
        <div class="alert alert-warning">Database schema is not ready for Year-End Rollover yet. Run <code>php tools/migrate.php</code> on the server/admin machine first.</div>
    <?php endif; ?>

    <?php if ($message !== ''): ?>
        <div class="alert alert-<?= h($messageType) ?>"><?= $message ?></div>
    <?php endif; ?>

    <div class="section-card">
        <div class="section-title">Cycle Setup</div>
        <div class="section-note">The active year stays as the source. The target is automatically fixed to the immediate next school year, while the filters below control the view.</div>
        <?php if (empty($targetOptions)): ?>
            <div class="alert alert-warning mb-0">No next school year is available yet. Add the next school year first in <strong>Settings &gt; School Years</strong> before using rollover.</div>
        <?php else: ?>
            <form method="get" class="toolbar rollover-filter-form <?= $rolloverFiltersLocked ? 'locked-view' : '' ?>">
                <div class="field">
                    <label class="form-label fw-semibold">Target Next School Year</label>
                    <input type="text" class="form-control" value="<?= h($selectedTargetYear !== '' ? $selectedTargetYear : 'No next school year available') ?>" readonly>
                    <input type="hidden" name="target_school_year" value="<?= h($selectedTargetYear) ?>">
                    <div class="form-text">Auto-targeted to the immediate next school year from the current source year.</div>
                </div>
                <div class="field field-wide">
                    <label class="form-label fw-semibold">Search Student</label>
                    <input type="text" name="student_search" class="form-control" value="<?= h($searchQuery) ?>" placeholder="Search by name, LRN, grade, or section" <?= $rolloverFiltersLocked ? 'readonly' : '' ?>>
                </div>
                <div class="field">
                    <label class="form-label fw-semibold">Status Filter</label>
                    <select name="status_filter" class="form-select" <?= $rolloverFiltersLocked ? 'disabled' : '' ?>>
                        <option value="all" <?= $statusFilter === 'all' ? 'selected' : '' ?>>All Rows</option>
                        <option value="ready" <?= $statusFilter === 'ready' ? 'selected' : '' ?>>Ready</option>
                        <option value="next_ready" <?= $statusFilter === 'next_ready' ? 'selected' : '' ?>>Next Year Ready</option>
                        <option value="old_ready" <?= $statusFilter === 'old_ready' ? 'selected' : '' ?>>Old Account Ready</option>
                        <option value="next_done" <?= $statusFilter === 'next_done' ? 'selected' : '' ?>>Next Done</option>
                        <option value="old_done" <?= $statusFilter === 'old_done' ? 'selected' : '' ?>>Old Done</option>
                        <option value="both_done" <?= $statusFilter === 'both_done' ? 'selected' : '' ?>>Both Done</option>
                        <option value="graduates" <?= $statusFilter === 'graduates' ? 'selected' : '' ?>>Graduates / No Next Grade</option>
                        <option value="needs_review" <?= $statusFilter === 'needs_review' ? 'selected' : '' ?>>Needs Review</option>
                    </select>
                </div>
                <div class="field">
                    <label class="form-label fw-semibold">Grade Filter</label>
                    <select name="grade_filter" class="form-select" <?= $rolloverFiltersLocked ? 'disabled' : '' ?>>
                        <option value="all">All Grades</option>
                        <?php foreach ($gradeOptions as $gradeOption): ?>
                            <option value="<?= h($gradeOption) ?>" <?= $gradeFilter === $gradeOption ? 'selected' : '' ?>><?= h($gradeOption) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <button type="submit" class="btn btn-outline-primary"><i class="fas fa-sync-alt me-1"></i>Refresh View</button>
                </div>
                <div>
                    <a href="year-end-rollover.php" class="btn btn-outline-secondary <?= $rolloverFiltersLocked ? 'disabled' : '' ?>"><i class="fas fa-rotate-left me-1"></i>Reset Filters</a>
                </div>
                <div>
                    <button type="submit" form="rolloverLockForm" name="<?= $rolloverFiltersLocked ? 'unlock_rollover_view' : 'lock_rollover_view' ?>" class="btn btn-outline-warning rollover-lock-btn <?= $rolloverFiltersLocked ? 'locked' : '' ?>">
                        <i class="fas <?= $rolloverFiltersLocked ? 'fa-lock' : 'fa-key' ?> me-1"></i><?= $rolloverFiltersLocked ? 'Unlock View' : 'Lock View' ?>
                    </button>
                </div>
            </form>
            <form method="post" id="rolloverLockForm" class="d-none">
                <input type="hidden" name="target_school_year" value="<?= h($selectedTargetYear) ?>">
                <input type="hidden" name="student_search" value="<?= h($searchQuery) ?>">
                <input type="hidden" name="status_filter" value="<?= h($statusFilter) ?>">
                <input type="hidden" name="grade_filter" value="<?= h($gradeFilter) ?>">
            </form>
            <div class="filter-meta">
                <?php if ($rolloverFiltersLocked): ?>
                    <span class="filter-pill"><i class="fas fa-lock"></i> View Locked</span>
                <?php endif; ?>
                <span class="filter-pill"><i class="fas fa-list-check"></i> Filtered Rows: <?= count($filteredStudents) ?></span>
                <span class="filter-pill"><i class="fas fa-user-plus"></i> Filtered Next Done: <?= (int) $filteredSummary['next_done'] ?></span>
                <span class="filter-pill"><i class="fas fa-file-invoice-dollar"></i> Filtered Old Done: <?= (int) $filteredSummary['old_done'] ?></span>
                <span class="filter-pill"><i class="fas fa-copy"></i> Filtered Both Done: <?= (int) $filteredSummary['both_done'] ?></span>
            </div>
        <?php endif; ?>
    </div>

    <?php if (!empty($targetOptions) && $selectedTargetYear !== ''): ?>
        <div class="destination-grid">
            <div class="section-card source-panel panel-card" data-panel-key="current-source">
                <div class="panel-head">
                    <div>
                        <div class="panel-kicker"><i class="fas fa-users"></i> Source List</div>
                        <div class="section-title mb-1">Current</div>
                        <div class="section-note mb-0">Source students from <?= h($sourceYear) ?>. We can mark them for <strong><?= h($selectedTargetYear) ?></strong>, <strong>Old Accounts</strong>, or both.</div>
                    </div>
                    <div class="panel-head-actions">
                        <div class="panel-count"><?= count($filteredStudents) ?></div>
                        <button type="button" class="btn btn-outline-secondary panel-toggle" data-panel-toggle aria-expanded="true" title="Minimize panel"><i class="fas fa-minus"></i></button>
                    </div>
                </div>
                <div class="panel-summary">Shows the filtered current-source students available for next-year copy or old-account review.</div>
                <div class="panel-body">
                <form method="post" id="rolloverForm">
                    <input type="hidden" name="csrf_token" value="<?= h($csrfToken) ?>">
                    <input type="hidden" name="target_school_year" value="<?= h($selectedTargetYear) ?>">
                    <input type="hidden" name="student_search" value="<?= h($searchQuery) ?>">
                    <input type="hidden" name="status_filter" value="<?= h($statusFilter) ?>">
                    <input type="hidden" name="grade_filter" value="<?= h($gradeFilter) ?>">
                    <div class="selection-actions">
                        <button type="button" class="btn btn-outline-primary btn-sm" data-bulk-check="next"><i class="fas fa-check-double me-1"></i>Select Visible Next Year</button>
                        <button type="button" class="btn btn-outline-primary btn-sm" data-bulk-check="old"><i class="fas fa-check-double me-1"></i>Select Visible Old Account</button>
                        <button type="button" class="btn btn-outline-secondary btn-sm" data-bulk-clear="next"><i class="fas fa-eraser me-1"></i>Clear Visible Next Year</button>
                        <button type="button" class="btn btn-outline-secondary btn-sm" data-bulk-clear="old"><i class="fas fa-eraser me-1"></i>Clear Visible Old Account</button>
                    </div>
                    <div class="table-wrap">
                        <table class="table table-rollover align-middle">
                            <thead>
                                <tr>
                                    <th>Student</th>
                                    <th>Current Grade</th>
                                    <th>Next Grade</th>
                                    <th>Outstanding Balance</th>
                                    <th>Next School Year</th>
                                    <th>Old Account</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if (!$filteredStudents): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">No students match the current filter. Adjust the search or status filter, then try again.</td>
                                </tr>
                            <?php endif; ?>
                            <?php foreach ($filteredStudents as $student): ?>
                                <?php
                                    $studentId = (int) $student['id'];
                                    $isNextChecked = in_array($studentId, $selectedNextIds, true);
                                    $isOldChecked = in_array($studentId, $selectedOldIds, true);
                                ?>
                                <tr>
                                    <td>
                                        <div class="student-name"><?= h(student_full_name_from_row($student)) ?></div>
                                        <div class="student-meta">LRN: <?= h($student['lrn'] ?: 'No LRN') ?> | Section: <?= h($student['section'] !== '' ? $student['section'] : 'Unassigned') ?></div>
                                    </td>
                                    <td><span class="grade-pill current-grade"><?= h($student['grade']) ?></span></td>
                                    <td>
                                        <?php if (!empty($student['can_roll_next'])): ?>
                                            <span class="grade-flow"><span><?= h($student['grade']) ?></span><span class="flow-arrow">-></span><span><?= h($student['next_grade']) ?></span></span>
                                        <?php else: ?>
                                            <span class="status-chip chip-warn">Graduate / No Next Grade</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><span class="balance-pill"><?= money_fmt((float) $student['outstanding_balance']) ?></span></td>
                                    <td>
                                        <div class="action-card <?= (!$student['can_roll_next'] || $student['next_done']) ? 'is-disabled' : '' ?>">
                                            <div class="form-check">
                                                <input class="form-check-input rollover-next" type="checkbox" name="next_ids[]" value="<?= $studentId ?>" <?= $isNextChecked ? 'checked' : '' ?> <?= !$student['can_roll_next'] || $student['next_done'] ? 'disabled' : '' ?>>
                                                <label class="form-check-label">Copy to <?= h($selectedTargetYear) ?></label>
                                            </div>
                                            <div class="action-meta">
                                                <?php if ($student['next_done']): ?>Already copied into the next school year for this cycle.<?php elseif (!$student['can_roll_next']): ?>No next-grade mapping available for this student.<?php else: ?>Creates the next-year base record and keeps the current year untouched.<?php endif; ?>
                                            </div>
                                            <?php if ($student['next_done']): ?><span class="status-chip chip-done">Locked</span><?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="action-card <?= (!$student['can_roll_old'] || $student['old_done']) ? 'is-disabled' : '' ?>">
                                            <div class="form-check">
                                                <input class="form-check-input rollover-old" type="checkbox" name="old_ids[]" value="<?= $studentId ?>" <?= $isOldChecked ? 'checked' : '' ?> <?= !$student['can_roll_old'] || $student['old_done'] ? 'disabled' : '' ?>>
                                                <label class="form-check-label">Create Old Account Review</label>
                                            </div>
                                            <div class="action-meta">
                                                <?php if ($student['old_done']): ?>Old Account review record already exists for this cycle.<?php elseif (!$student['can_roll_old']): ?>No outstanding balance to carry into review.<?php else: ?>Stages a limited old-account snapshot for manual follow-up review.<?php endif; ?>
                                            </div>
                                            <?php if (!$student['can_roll_old']): ?><span class="status-chip chip-muted">No old balance</span><?php endif; ?>
                                            <?php if ($student['old_done']): ?><span class="status-chip chip-done">Locked</span><?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="status-stack">
                                            <?php if ($student['next_done'] && $student['old_done']): ?>
                                                <span class="status-chip chip-both">Copied to Both</span>
                                                <span class="status-helper">Next-year and old-account review are both already created.</span>
                                            <?php elseif ($student['next_done']): ?>
                                                <span class="status-chip chip-done">Next School Year Done</span>
                                                <span class="status-helper">This row is locked for next-year copy.</span>
                                            <?php elseif ($student['old_done']): ?>
                                                <span class="status-chip chip-done">Old Account Done</span>
                                                <span class="status-helper">Old-account review is already staged.</span>
                                            <?php elseif (!$student['can_roll_next']): ?>
                                                <span class="status-chip chip-warn">Review Graduate</span>
                                                <span class="status-helper">Check if this student should stay out of next-year rollover.</span>
                                            <?php else: ?>
                                                <span class="status-chip chip-ready">Ready</span>
                                                <span class="status-helper">Eligible for next-year copy and can still be reviewed for old balances if needed.</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="preview-actions">
                        <button type="submit" name="rollover_action" value="preview" class="btn btn-primary"><i class="fas fa-eye me-1"></i>Preview Rollover</button>
                        <a href="year-end-rollover.php?student_search=<?= urlencode($searchQuery) ?>&status_filter=<?= urlencode($statusFilter) ?>&grade_filter=<?= urlencode($gradeFilter) ?>" class="btn btn-outline-secondary"><i class="fas fa-rotate-left me-1"></i>Clear Selections</a>
                    </div>
                </form>
            </div>
                </div>

            <div class="section-card panel-card" data-panel-key="next-school-year">
                <div class="panel-head">
                    <div>
                        <div class="panel-kicker"><i class="fas fa-graduation-cap"></i> Next Cycle</div>
                        <div class="section-title mb-1">Next School Year</div>
                        <div class="section-note mb-0">Filtered students already copied into <?= h($selectedTargetYear) ?> for this cycle.</div>
                    </div>
                    <div class="panel-head-actions">
                        <div class="panel-count"><?= count($nextRows) ?></div>
                        <button type="button" class="btn btn-outline-secondary panel-toggle" data-panel-toggle aria-expanded="true" title="Minimize panel"><i class="fas fa-minus"></i></button>
                    </div>
                </div>
                <div class="panel-summary">Shows only the filtered students already copied into the next school year.</div>
                <div class="panel-body">
                    <div class="table-wrap">
                        <table class="table mini-table align-middle mb-0">
                            <thead><tr><th>Student</th><th>Grade</th><th>Section</th></tr></thead>
                            <tbody>
                            <?php if (!$nextRows): ?>
                                <tr><td colspan="3" class="text-muted">No copied students yet.</td></tr>
                            <?php else: ?>
                                <?php foreach ($nextRows as $row): ?>
                                    <tr>
                                        <td>
                                            <div class="mini-name"><?= h(student_full_name_from_row($row)) ?></div>
                                            <div class="mini-meta">Promoted record inside <?= h($selectedTargetYear) ?></div>
                                        </td>
                                        <td><span class="grade-pill"><?= h($row['grade']) ?></span></td>
                                        <td><?= h($row['detail_value'] !== '' ? $row['detail_value'] : 'Unassigned') ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="section-card panel-card" data-panel-key="old-accounts">
                <div class="panel-head">
                    <div>
                        <div class="panel-kicker"><i class="fas fa-file-invoice-dollar"></i> Review Queue</div>
                        <div class="section-title mb-1">Old Accounts</div>
                        <div class="section-note mb-0">Filtered students already staged in Old Accounts from <?= h($sourceYear) ?> for manual balance review in this cycle.</div>
                    </div>
                    <div class="panel-head-actions">
                        <div class="panel-count"><?= count($oldRows) ?></div>
                        <button type="button" class="btn btn-outline-secondary panel-toggle" data-panel-toggle aria-expanded="true" title="Minimize panel"><i class="fas fa-minus"></i></button>
                    </div>
                </div>
                <div class="panel-summary">Shows only the filtered old-account review records created from this rollover cycle.</div>
                <div class="panel-body">
                    <div class="table-wrap">
                        <table class="table mini-table align-middle mb-0">
                            <thead><tr><th>Student</th><th>Status</th><th>Balance Snapshot</th></tr></thead>
                            <tbody>
                            <?php if (!$oldRows): ?>
                                <tr><td colspan="3" class="text-muted">No Old Account review records yet.</td></tr>
                            <?php else: ?>
                                <?php foreach ($oldRows as $row): ?>
                                    <tr>
                                        <td>
                                            <div class="mini-name"><?= h(student_full_name_from_row($row)) ?></div>
                                            <div class="mini-meta">Manual review snapshot from <?= h($sourceYear) ?></div>
                                        </td>
                                        <td><span class="status-chip chip-muted"><?= h($row['grade']) ?></span></td>
                                        <td><span class="balance-pill"><?= money_fmt((float) ($row['detail_value'] ?? 0)) ?></span></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <?php if (is_array($preview)): ?>
            <div class="section-card">
                <div class="section-title">Confirmation Preview</div>
                <div class="section-note">Review the breakdown first before we write any new records.</div>
                <div class="summary-grid mb-3">
                    <div class="summary-tile"><div class="label">To Next School Year</div><div class="value"><?= (int) ($preview['counts']['next'] ?? 0) ?></div></div>
                    <div class="summary-tile"><div class="label">To Old Account Review</div><div class="value"><?= (int) ($preview['counts']['old'] ?? 0) ?></div></div>
                    <div class="summary-tile"><div class="label">To Both</div><div class="value"><?= (int) ($preview['counts']['both'] ?? 0) ?></div></div>
                </div>

                <?php if (!empty($preview['warnings'])): ?>
                    <div class="alert alert-warning">
                        <strong>Review warnings:</strong>
                        <ul class="mb-0 mt-2">
                            <?php foreach ($preview['warnings'] as $warning): ?>
                                <li><?= h($warning) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="row g-4">
                    <div class="col-lg-6">
                        <h6 class="fw-bold text-primary">Next School Year Selection</h6>
                        <ul class="preview-list">
                            <?php if (empty($preview['next'])): ?>
                                <li>No valid Next School Year selections.</li>
                            <?php else: ?>
                                <?php foreach ($preview['next'] as $row): ?>
                                    <li><?= h(student_full_name_from_row($row)) ?> <span class="text-muted">(<?= h($row['grade']) ?> -> <?= h($row['next_grade']) ?>)</span></li>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <div class="col-lg-6">
                        <h6 class="fw-bold text-primary">Old Account Review Selection</h6>
                        <ul class="preview-list">
                            <?php if (empty($preview['old'])): ?>
                                <li>No valid Old Account selections.</li>
                            <?php else: ?>
                                <?php foreach ($preview['old'] as $row): ?>
                                    <li><?= h(student_full_name_from_row($row)) ?> <span class="text-muted">(<?= money_fmt((float) $row['outstanding_balance']) ?>)</span></li>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>

                <form method="post" class="preview-actions">
                    <input type="hidden" name="csrf_token" value="<?= h($csrfToken) ?>">
                    <input type="hidden" name="target_school_year" value="<?= h($selectedTargetYear) ?>">
                    <input type="hidden" name="student_search" value="<?= h($searchQuery) ?>">
                    <input type="hidden" name="status_filter" value="<?= h($statusFilter) ?>">
                    <input type="hidden" name="grade_filter" value="<?= h($gradeFilter) ?>">
                    <?php foreach ($selectedNextIds as $id): ?><input type="hidden" name="next_ids[]" value="<?= (int) $id ?>"><?php endforeach; ?>
                    <?php foreach ($selectedOldIds as $id): ?><input type="hidden" name="old_ids[]" value="<?= (int) $id ?>"><?php endforeach; ?>
                    <button type="submit" name="rollover_action" value="apply" class="btn btn-success"><i class="fas fa-check-circle me-1"></i>Apply Year-End Rollover</button>
                    <a href="year-end-rollover.php?student_search=<?= urlencode($searchQuery) ?>&status_filter=<?= urlencode($statusFilter) ?>&grade_filter=<?= urlencode($gradeFilter) ?>" class="btn btn-outline-secondary"><i class="fas fa-times me-1"></i>Cancel Preview</a>
                </form>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>
<script>
(function () {
    function toggleVisibleCheckboxes(selector, checked) {
        document.querySelectorAll(selector).forEach(function (checkbox) {
            if (!checkbox.disabled) {
                checkbox.checked = checked;
            }
        });
    }

    function syncPanelButton(panel) {
        var button = panel.querySelector('[data-panel-toggle]');
        if (!button) {
            return;
        }
        var minimized = panel.classList.contains('minimized');
        button.setAttribute('aria-expanded', minimized ? 'false' : 'true');
        button.setAttribute('title', minimized ? 'Expand panel' : 'Minimize panel');
        button.innerHTML = minimized ? '<i class="fas fa-plus"></i>' : '<i class="fas fa-minus"></i>';
    }

    document.querySelectorAll('[data-bulk-check="next"]').forEach(function (button) {
        button.addEventListener('click', function () {
            toggleVisibleCheckboxes('.rollover-next', true);
        });
    });

    document.querySelectorAll('[data-bulk-check="old"]').forEach(function (button) {
        button.addEventListener('click', function () {
            toggleVisibleCheckboxes('.rollover-old', true);
        });
    });

    document.querySelectorAll('[data-bulk-clear="next"]').forEach(function (button) {
        button.addEventListener('click', function () {
            toggleVisibleCheckboxes('.rollover-next', false);
        });
    });

    document.querySelectorAll('[data-bulk-clear="old"]').forEach(function (button) {
        button.addEventListener('click', function () {
            toggleVisibleCheckboxes('.rollover-old', false);
        });
    });

    document.querySelectorAll('.panel-card[data-panel-key]').forEach(function (panel) {
        var key = panel.getAttribute('data-panel-key');
        var storageKey = 'rollover-panel-' + key;
        var button = panel.querySelector('[data-panel-toggle]');
        if (!button) {
            return;
        }

        if (window.localStorage && localStorage.getItem(storageKey) === 'minimized') {
            panel.classList.add('minimized');
        }
        syncPanelButton(panel);

        button.addEventListener('click', function () {
            panel.classList.toggle('minimized');
            if (window.localStorage) {
                localStorage.setItem(storageKey, panel.classList.contains('minimized') ? 'minimized' : 'expanded');
            }
            syncPanelButton(panel);
        });
    });
})();
</script>
</script>
</body>
</html>







