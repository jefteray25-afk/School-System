<?php

require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/../old accounts/old-account-followup-helper.php';
require_once __DIR__ . '/../../includes/schema-migration.php';

function year_end_rollover_ensure_table(mysqli $conn): void
{
    static $initialized = false;
    if ($initialized) {
        return;
    }

    if (!schema_migration_mode_enabled()) {
        $initialized = true;
        return;
    }

    schema_migration_attempt($conn, "
        CREATE TABLE IF NOT EXISTS school_year_rollover_log (
            id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            source_student_id INT(11) NOT NULL,
            source_school_year_label VARCHAR(30) NOT NULL,
            target_school_year_label VARCHAR(30) NOT NULL,
            next_student_id INT(11) DEFAULT NULL,
            old_student_id INT(11) DEFAULT NULL,
            next_copied_at DATETIME DEFAULT NULL,
            old_copied_at DATETIME DEFAULT NULL,
            carried_old_balance DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            created_by VARCHAR(100) DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_rollover_cycle (source_student_id, source_school_year_label, target_school_year_label),
            KEY idx_rollover_source_year (source_school_year_label),
            KEY idx_rollover_target_year (target_school_year_label),
            KEY idx_rollover_next_student (next_student_id),
            KEY idx_rollover_old_student (old_student_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");

    $initialized = true;
}

function year_end_rollover_table_exists(mysqli $conn): bool
{
    $result = $conn->query("SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'school_year_rollover_log' LIMIT 1");
    return $result && $result->num_rows > 0;
}

function year_end_rollover_reset_log(mysqli $conn): array
{
    year_end_rollover_ensure_table($conn);
    if (!year_end_rollover_table_exists($conn)) {
        return [
            'success' => false,
            'deleted' => 0,
            'message' => 'Rollover log table is not available.',
        ];
    }

    $existingRows = 0;
    $countResult = $conn->query("SELECT COUNT(*) AS total FROM school_year_rollover_log");
    if ($countResult) {
        $existingRows = (int) (($countResult->fetch_assoc()['total'] ?? 0));
        $countResult->close();
    }

    if ($existingRows === 0) {
        return [
            'success' => true,
            'deleted' => 0,
            'message' => 'Rollover log is already clean. No rows were removed.',
        ];
    }

    if (!$conn->query("DELETE FROM school_year_rollover_log")) {
        return [
            'success' => false,
            'deleted' => 0,
            'message' => 'Failed to reset rollover log: ' . $conn->error,
        ];
    }

    return [
        'success' => true,
        'deleted' => $existingRows,
        'message' => 'Rollover log reset completed.',
    ];
}

function year_end_rollover_log_cycles(mysqli $conn): array
{
    year_end_rollover_ensure_table($conn);
    if (!year_end_rollover_table_exists($conn)) {
        return [];
    }

    $rows = [];
    $result = $conn->query("
        SELECT
            source_school_year_label,
            target_school_year_label,
            COUNT(*) AS total_rows,
            MAX(updated_at) AS last_updated_at
        FROM school_year_rollover_log
        GROUP BY source_school_year_label, target_school_year_label
        ORDER BY source_school_year_label DESC, target_school_year_label DESC
    ");
    if (!$result) {
        return [];
    }

    while ($row = $result->fetch_assoc()) {
        $rows[] = [
            'source_year' => (string) ($row['source_school_year_label'] ?? ''),
            'target_year' => (string) ($row['target_school_year_label'] ?? ''),
            'total_rows' => (int) ($row['total_rows'] ?? 0),
            'last_updated_at' => (string) ($row['last_updated_at'] ?? ''),
        ];
    }
    $result->close();

    return $rows;
}

function year_end_rollover_reset_cycle(mysqli $conn, string $sourceYear, string $targetYear): array
{
    year_end_rollover_ensure_table($conn);
    if (!year_end_rollover_table_exists($conn)) {
        return [
            'success' => false,
            'deleted' => 0,
            'message' => 'Rollover log table is not available.',
        ];
    }

    $sourceYear = trim($sourceYear);
    $targetYear = trim($targetYear);
    if ($sourceYear === '' || $targetYear === '') {
        return [
            'success' => false,
            'deleted' => 0,
            'message' => 'Select both source and target school year before resetting a rollover cycle.',
        ];
    }

    $countStmt = $conn->prepare("
        SELECT COUNT(*) AS total
        FROM school_year_rollover_log
        WHERE source_school_year_label = ? AND target_school_year_label = ?
    ");
    if (!$countStmt) {
        return [
            'success' => false,
            'deleted' => 0,
            'message' => 'Could not prepare rollover cycle count query: ' . $conn->error,
        ];
    }
    $countStmt->bind_param('ss', $sourceYear, $targetYear);
    $countStmt->execute();
    $countStmt->bind_result($existingRows);
    $countStmt->fetch();
    $countStmt->close();

    $existingRows = (int) $existingRows;
    if ($existingRows === 0) {
        return [
            'success' => true,
            'deleted' => 0,
            'message' => 'Selected rollover cycle is already clean. No rows were removed.',
        ];
    }

    $deleteStmt = $conn->prepare("
        DELETE FROM school_year_rollover_log
        WHERE source_school_year_label = ? AND target_school_year_label = ?
    ");
    if (!$deleteStmt) {
        return [
            'success' => false,
            'deleted' => 0,
            'message' => 'Could not prepare rollover cycle reset query: ' . $conn->error,
        ];
    }
    $deleteStmt->bind_param('ss', $sourceYear, $targetYear);
    $ok = $deleteStmt->execute();
    $deleteStmt->close();

    if (!$ok) {
        return [
            'success' => false,
            'deleted' => 0,
            'message' => 'Failed to reset selected rollover cycle: ' . $conn->error,
        ];
    }

    return [
        'success' => true,
        'deleted' => $existingRows,
        'message' => 'Selected rollover cycle reset completed.',
    ];
}

function year_end_rollover_grade_map(): array
{
    return [
        'Junior Kindergarten' => 'Senior Kindergarten',
        'Senior Kindergarten' => 'Grade 1',
        'Grade 1' => 'Grade 2',
        'Grade 2' => 'Grade 3',
        'Grade 3' => 'Grade 4',
        'Grade 4' => 'Grade 5',
        'Grade 5' => 'Grade 6',
        'Grade 6' => 'Grade 7',
        'Grade 7' => 'Grade 8',
        'Grade 8' => 'Grade 9',
        'Grade 9' => 'Grade 10',
        'Grade 10' => 'Grade 11',
        'Grade 11' => 'Grade 12',
    ];
}

function year_end_rollover_next_grade(string $currentGrade): ?string
{
    $map = year_end_rollover_grade_map();
    $grade = trim($currentGrade);
    return $map[$grade] ?? null;
}

function year_end_rollover_label_start_year(string $label): int
{
    if (preg_match('/(\d{4})\s*-\s*(\d{4})/', $label, $matches)) {
        return (int) $matches[1];
    }

    return 0;
}

function year_end_rollover_old_school_year_label(string $label): string
{
    $label = trim($label);
    if (stripos($label, 'SY ') === 0) {
        $label = trim(substr($label, 3));
    }
    return $label;
}

function year_end_rollover_target_options(mysqli $conn, string $activeLabel): array
{
    $rows = school_year_get_all($conn);
    $options = [];
    foreach ($rows as $row) {
        $label = trim((string) ($row['label'] ?? ''));
        if ($label === '' || $label === $activeLabel) {
            continue;
        }
        $options[] = $label;
    }

    $activeStartYear = year_end_rollover_label_start_year($activeLabel);
    usort($options, static function (string $a, string $b) use ($activeStartYear): int {
        $aStart = year_end_rollover_label_start_year($a);
        $bStart = year_end_rollover_label_start_year($b);

        $aIsFuture = $aStart > $activeStartYear;
        $bIsFuture = $bStart > $activeStartYear;

        if ($aIsFuture !== $bIsFuture) {
            return $aIsFuture ? -1 : 1;
        }

        if ($aIsFuture && $bIsFuture && $aStart !== $bStart) {
            return $aStart <=> $bStart;
        }

        if (!$aIsFuture && !$bIsFuture && $aStart !== $bStart) {
            return $bStart <=> $aStart;
        }

        return strcmp($a, $b);
    });

    return array_values(array_unique($options));
}

function year_end_rollover_next_target_year(array $options, string $activeLabel): string
{
    if (empty($options)) {
        return '';
    }

    $activeStartYear = year_end_rollover_label_start_year($activeLabel);
    $immediateNext = $activeStartYear > 0 ? $activeStartYear + 1 : 0;

    foreach ($options as $option) {
        if ($immediateNext > 0 && year_end_rollover_label_start_year($option) === $immediateNext) {
            return $option;
        }
    }

    foreach ($options as $option) {
        if (year_end_rollover_label_start_year($option) > $activeStartYear) {
            return $option;
        }
    }

    return $options[0] ?? '';
}

function year_end_rollover_selected_ids(array $values): array
{
    $ids = [];
    foreach ($values as $value) {
        $id = (int) $value;
        if ($id > 0) {
            $ids[$id] = $id;
        }
    }
    return array_values($ids);
}

function year_end_rollover_students(mysqli $conn, string $sourceYear, string $targetYear): array
{
    year_end_rollover_ensure_table($conn);
    if (!year_end_rollover_table_exists($conn)) {
        return [];
    }

    $oldSourceYear = year_end_rollover_old_school_year_label($sourceYear);

    $sql = "
        SELECT
            s.id,
            s.lastname,
            s.firstname,
            s.middlename,
            s.lrn,
            s.grade,
            COALESCE(s.strand, '') AS strand,
            COALESCE(s.section, '') AS section,
            COALESCE(s.contact, '') AS contact,
            COALESCE(s.birthday, '') AS birthday,
            COALESCE(s.age, 0) AS age,
            COALESCE(s.gender, '') AS gender,
            COALESCE(s.address, '') AS address,
            COALESCE(s.guardian_name, '') AS guardian_name,
            COALESCE(s.guardian_contact, '') AS guardian_contact,
            COALESCE(s.date_enrolled, '') AS date_enrolled,
            COALESCE(s.photo, '') AS photo,
            s.school_year_label,
            COALESCE(SUM(a.balance), 0) AS outstanding_balance,
            r.next_student_id,
            r.old_student_id,
            r.next_copied_at,
            r.old_copied_at,
            ns.id AS verified_next_student_id,
            os.id AS verified_old_student_id
        FROM students s
        LEFT JOIN accounts a
            ON a.student_id = s.id
           AND COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ?
        LEFT JOIN school_year_rollover_log r
            ON r.source_student_id = s.id
           AND r.source_school_year_label = ?
           AND r.target_school_year_label = ?
        LEFT JOIN students ns
            ON ns.id = r.next_student_id
           AND COALESCE(NULLIF(TRIM(ns.school_year_label), ''), ?) = ?
        LEFT JOIN old_students os
            ON os.id = r.old_student_id
           AND COALESCE(NULLIF(TRIM(os.school_year), ''), ?) = ?
        WHERE COALESCE(NULLIF(TRIM(s.school_year_label), ''), ?) = ?
        GROUP BY
            s.id, s.lastname, s.firstname, s.middlename, s.lrn, s.grade, s.strand, s.section, s.contact, s.birthday, s.age, s.gender, s.address, s.guardian_name, s.guardian_contact, s.date_enrolled, s.photo, s.school_year_label,
            r.next_student_id, r.old_student_id, r.next_copied_at, r.old_copied_at,
            ns.id, os.id
        ORDER BY s.lastname ASC, s.firstname ASC, s.middlename ASC
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssssssssss', $sourceYear, $sourceYear, $sourceYear, $targetYear, $targetYear, $targetYear, $oldSourceYear, $oldSourceYear, $sourceYear, $sourceYear);
    $stmt->execute();
    $result = $stmt->get_result();

    $rows = [];
    while ($result && $row = $result->fetch_assoc()) {
        $row['outstanding_balance'] = (float) ($row['outstanding_balance'] ?? 0);
        $row['next_student_id'] = (int) ($row['next_student_id'] ?? 0);
        $row['old_student_id'] = (int) ($row['old_student_id'] ?? 0);
        $row['verified_next_student_id'] = (int) ($row['verified_next_student_id'] ?? 0);
        $row['verified_old_student_id'] = (int) ($row['verified_old_student_id'] ?? 0);
        $row['next_grade'] = year_end_rollover_next_grade((string) ($row['grade'] ?? ''));
        $row['can_roll_next'] = $row['next_grade'] !== null;
        $row['can_roll_old'] = $row['outstanding_balance'] > 0.009;
        $row['next_done'] = $row['verified_next_student_id'] > 0;
        $row['old_done'] = $row['verified_old_student_id'] > 0;
        if (!$row['next_done']) {
            $row['next_student_id'] = 0;
            $row['next_copied_at'] = null;
        }
        if (!$row['old_done']) {
            $row['old_student_id'] = 0;
            $row['old_copied_at'] = null;
        }
        $rows[] = $row;
    }
    $stmt->close();

    return $rows;
}

function year_end_rollover_destination_rows(mysqli $conn, string $sourceYear, string $targetYear, string $mode): array
{
    year_end_rollover_ensure_table($conn);
    if (!year_end_rollover_table_exists($conn)) {
        return [];
    }

    if ($mode === 'next') {
        $sql = "
            SELECT
                r.source_student_id,
                r.source_school_year_label,
                r.target_school_year_label,
                r.next_student_id AS destination_id,
                r.created_at,
                s.lastname,
                s.firstname,
                s.middlename,
                s.grade,
                COALESCE(s.section, '') AS detail_value
            FROM school_year_rollover_log r
            INNER JOIN students s ON s.id = r.next_student_id
            WHERE r.source_school_year_label = ?
              AND r.target_school_year_label = ?
              AND COALESCE(NULLIF(TRIM(s.school_year_label), ''), ?) = ?
              AND r.next_student_id IS NOT NULL
            ORDER BY s.lastname ASC, s.firstname ASC, s.middlename ASC
        ";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ssss', $sourceYear, $targetYear, $targetYear, $targetYear);
    } else {
        $oldSourceYear = year_end_rollover_old_school_year_label($sourceYear);
        $sql = "
            SELECT
                r.source_student_id,
                r.source_school_year_label,
                r.target_school_year_label,
                r.old_student_id AS destination_id,
                r.created_at,
                o.lastname,
                o.firstname,
                o.middlename,
                o.status AS grade,
                COALESCE(r.carried_old_balance, 0) AS detail_value
            FROM school_year_rollover_log r
            INNER JOIN old_students o ON o.id = r.old_student_id
            WHERE r.source_school_year_label = ?
              AND r.target_school_year_label = ?
              AND COALESCE(NULLIF(TRIM(o.school_year), ''), ?) = ?
              AND r.old_student_id IS NOT NULL
            ORDER BY o.lastname ASC, o.firstname ASC, o.middlename ASC
        ";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ssss', $sourceYear, $targetYear, $oldSourceYear, $oldSourceYear);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($result && $row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    $stmt->close();

    return $rows;
}
function year_end_rollover_summary(array $students): array
{
    $summary = [
        'total' => count($students),
        'eligible_next' => 0,
        'eligible_old' => 0,
        'next_done' => 0,
        'old_done' => 0,
        'both_done' => 0,
    ];

    foreach ($students as $student) {
        if (!empty($student['can_roll_next'])) {
            $summary['eligible_next']++;
        }
        if (!empty($student['can_roll_old'])) {
            $summary['eligible_old']++;
        }
        if (!empty($student['next_done'])) {
            $summary['next_done']++;
        }
        if (!empty($student['old_done'])) {
            $summary['old_done']++;
        }
        if (!empty($student['next_done']) && !empty($student['old_done'])) {
            $summary['both_done']++;
        }
    }

    return $summary;
}

function student_full_name_from_row(array $row): string
{
    $parts = [
        trim((string) ($row['lastname'] ?? '')),
        trim((string) ($row['firstname'] ?? '')),
        trim((string) ($row['middlename'] ?? '')),
    ];
    $lastname = array_shift($parts);
    $tail = trim(implode(' ', array_filter($parts, static fn($v): bool => $v !== '')));
    return trim($lastname . ($tail !== '' ? ', ' . $tail : ''));
}

function year_end_rollover_preview(array $students, array $nextIds, array $oldIds): array
{
    $lookup = [];
    foreach ($students as $student) {
        $lookup[(int) $student['id']] = $student;
    }

    $preview = [
        'next' => [],
        'old' => [],
        'both' => [],
        'warnings' => [],
    ];

    foreach ($nextIds as $id) {
        if (!isset($lookup[$id])) {
            continue;
        }
        $student = $lookup[$id];
        if (!$student['can_roll_next']) {
            $preview['warnings'][] = student_full_name_from_row($student) . ' cannot be moved to Next School Year because there is no next-grade mapping.';
            continue;
        }
        if ($student['next_done']) {
            $preview['warnings'][] = student_full_name_from_row($student) . ' is already copied to the selected next school year.';
            continue;
        }
        $preview['next'][$id] = $student;
    }

    foreach ($oldIds as $id) {
        if (!isset($lookup[$id])) {
            continue;
        }
        $student = $lookup[$id];
        if (!$student['can_roll_old']) {
            $preview['warnings'][] = student_full_name_from_row($student) . ' has no outstanding balance to carry into Old Accounts.';
            continue;
        }
        if ($student['old_done']) {
            $preview['warnings'][] = student_full_name_from_row($student) . ' is already copied to Old Accounts for this rollover cycle.';
            continue;
        }
        $preview['old'][$id] = $student;
    }

    foreach ($preview['next'] as $id => $student) {
        if (isset($preview['old'][$id])) {
            $preview['both'][$id] = $student;
        }
    }

    $preview['counts'] = [
        'next' => count($preview['next']),
        'old' => count($preview['old']),
        'both' => count($preview['both']),
    ];

    return $preview;
}

function year_end_rollover_student_copy_columns(mysqli $conn): array
{
    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }

    $result = $conn->query("SHOW COLUMNS FROM students");
    $existing = [];
    while ($result && $row = $result->fetch_assoc()) {
        $existing[] = (string) ($row['Field'] ?? '');
    }
    if ($result) {
        $result->close();
    }

    $preferred = [
        'lastname',
        'firstname',
        'middlename',
        'lrn',
        'grade',
        'strand',
        'section',
        'date_enrolled',
        'photo',
        'birthday',
        'age',
        'gender',
        'address',
        'contact',
        'guardian_name',
        'guardian_contact',
        'school_year_label',
    ];

    $cached = array_values(array_filter($preferred, static fn(string $column): bool => in_array($column, $existing, true)));
    return $cached;
}

function year_end_rollover_find_existing_target_student(mysqli $conn, array $student, string $targetYear): int
{
    $lrn = trim((string) ($student['lrn'] ?? ''));
    if ($lrn !== '') {
        $stmt = $conn->prepare("SELECT id FROM students WHERE school_year_label = ? AND lrn = ? LIMIT 1");
        $stmt->bind_param('ss', $targetYear, $lrn);
        $stmt->execute();
        $stmt->bind_result($existingId);
        $found = $stmt->fetch();
        $stmt->close();
        if ($found) {
            return (int) $existingId;
        }
    }

    $lastname = (string) ($student['lastname'] ?? '');
    $firstname = (string) ($student['firstname'] ?? '');
    $middlename = (string) ($student['middlename'] ?? '');
    $birthday = (string) ($student['birthday'] ?? '');
    $stmt = $conn->prepare("SELECT id FROM students WHERE school_year_label = ? AND lastname = ? AND firstname = ? AND middlename = ? AND birthday = ? LIMIT 1");
    $stmt->bind_param('sssss', $targetYear, $lastname, $firstname, $middlename, $birthday);
    $stmt->execute();
    $stmt->bind_result($existingId);
    $found = $stmt->fetch();
    $stmt->close();

    return $found ? (int) $existingId : 0;
}

function year_end_rollover_copy_student(mysqli $conn, array $student, string $targetYear): int
{
    $existingId = year_end_rollover_find_existing_target_student($conn, $student, $targetYear);
    if ($existingId > 0) {
        return $existingId;
    }

    $columns = year_end_rollover_student_copy_columns($conn);
    $values = [];
    $types = '';

    foreach ($columns as $column) {
        $value = $student[$column] ?? null;
        if ($column === 'grade') {
            $value = $student['next_grade'] ?? $value;
        } elseif ($column === 'school_year_label') {
            $value = $targetYear;
        } elseif ($column === 'section') {
            $value = '';
        } elseif ($column === 'date_enrolled' && ($value === '' || $value === null)) {
            $value = date('Y-m-d');
        } elseif ($column === 'gender' && ($value === '' || $value === null)) {
            $value = 'Unspecified';
        } elseif ($column === 'address' && ($value === null)) {
            $value = '';
        } elseif ($column === 'guardian_name' && ($value === null)) {
            $value = '';
        } elseif ($column === 'guardian_contact' && ($value === null)) {
            $value = '';
        } elseif ($column === 'contact' && ($value === null)) {
            $value = '';
        } elseif ($column === 'age') {
            $value = (int) ($value ?? 0);
        }

        $values[] = $value;
        $types .= $column === 'age' ? 'i' : 's';
    }

    $placeholderSql = implode(', ', array_fill(0, count($columns), '?'));
    $columnSql = implode(', ', $columns);
    $stmt = $conn->prepare("INSERT INTO students ({$columnSql}) VALUES ({$placeholderSql})");
    if (!$stmt) {
        throw new RuntimeException('Could not prepare next-school-year student insert: ' . $conn->error);
    }
    $stmt->bind_param($types, ...$values);
    if (!$stmt->execute()) {
        $error = $stmt->error ?: $conn->error;
        $stmt->close();
        throw new RuntimeException('Could not copy student into next school year: ' . $error);
    }
    $newId = (int) $conn->insert_id;
    $stmt->close();

    if ($newId <= 0) {
        throw new RuntimeException('Next-school-year student copy did not return a valid destination ID.');
    }

    return $newId;
}

function year_end_rollover_find_existing_old_account(mysqli $conn, array $student, string $sourceYear, ?int $linkedStudentId = null): int
{
    $sourceYear = year_end_rollover_old_school_year_label($sourceYear);
    $lastname = (string) ($student['lastname'] ?? '');
    $firstname = (string) ($student['firstname'] ?? '');
    $middlename = (string) ($student['middlename'] ?? '');

    if ($linkedStudentId !== null && $linkedStudentId > 0) {
        $stmt = $conn->prepare("SELECT id FROM old_students WHERE school_year = ? AND lastname = ? AND firstname = ? AND middlename = ? AND linked_student_id = ? LIMIT 1");
        $stmt->bind_param('ssssi', $sourceYear, $lastname, $firstname, $middlename, $linkedStudentId);
    } else {
        $stmt = $conn->prepare("SELECT id FROM old_students WHERE school_year = ? AND lastname = ? AND firstname = ? AND middlename = ? LIMIT 1");
        $stmt->bind_param('ssss', $sourceYear, $lastname, $firstname, $middlename);
    }
    $stmt->execute();
    $stmt->bind_result($existingId);
    $found = $stmt->fetch();
    $stmt->close();

    return $found ? (int) $existingId : 0;
}

function year_end_rollover_copy_old_account(mysqli $conn, array $student, string $sourceYear, ?int $linkedStudentId = null): array
{
    $sourceYear = year_end_rollover_old_school_year_label($sourceYear);
    ensure_old_student_followup_columns($conn);

    $existingId = year_end_rollover_find_existing_old_account($conn, $student, $sourceYear, $linkedStudentId);
    $balance = (float) ($student['outstanding_balance'] ?? 0);
    if ($existingId > 0) {
        return [
            'old_student_id' => $existingId,
            'carried_old_balance' => $balance,
        ];
    }

    $status = 'transferred';
    $note = 'Year-end rollover review snapshot from ' . $sourceYear . ' | Source student ID: ' . (int) ($student['id'] ?? 0) . ' | Outstanding snapshot: PHP ' . number_format($balance, 2);
    $followUpStatus = 'needs_review';
    $followUpNote = 'Created by year-end rollover. Review outstanding balance manually before adding any Old Account fee entries.';
    $contact = (string) ($student['contact'] ?? '');

    $stmt = $conn->prepare("
        INSERT INTO old_students (
            lastname, firstname, middlename, contact, status, school_year, notes, follow_up_status, follow_up_note, linked_student_id
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    if (!$stmt) {
        throw new RuntimeException('Could not prepare old-account review insert: ' . $conn->error);
    }
    $lastname = (string) ($student['lastname'] ?? '');
    $firstname = (string) ($student['firstname'] ?? '');
    $middlename = (string) ($student['middlename'] ?? '');
    $stmt->bind_param(
        'sssssssssi',
        $lastname,
        $firstname,
        $middlename,
        $contact,
        $status,
        $sourceYear,
        $note,
        $followUpStatus,
        $followUpNote,
        $linkedStudentId
    );
    if (!$stmt->execute()) {
        $error = $stmt->error ?: $conn->error;
        $stmt->close();
        throw new RuntimeException('Could not create old-account review record: ' . $error);
    }
    $oldStudentId = (int) $conn->insert_id;
    $stmt->close();

    if ($oldStudentId <= 0) {
        throw new RuntimeException('Old-account review copy did not return a valid destination ID.');
    }

    return [
        'old_student_id' => $oldStudentId,
        'carried_old_balance' => $balance,
    ];
}

function year_end_rollover_upsert_log(mysqli $conn, int $sourceStudentId, string $sourceYear, string $targetYear, string $createdBy): void
{
    $stmt = $conn->prepare("
        INSERT INTO school_year_rollover_log (source_student_id, source_school_year_label, target_school_year_label, created_by)
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE created_by = VALUES(created_by), updated_at = CURRENT_TIMESTAMP
    ");
    $stmt->bind_param('isss', $sourceStudentId, $sourceYear, $targetYear, $createdBy);
    $stmt->execute();
    $stmt->close();
}

function year_end_rollover_apply(mysqli $conn, array $students, string $sourceYear, string $targetYear, array $nextIds, array $oldIds, string $createdBy): array
{
    year_end_rollover_ensure_table($conn);
    if (!year_end_rollover_table_exists($conn)) {
        return ['success' => false, 'message' => schema_migration_missing_schema_message('Year-End Rollover'), 'result' => ['next' => 0, 'old' => 0, 'both' => 0, 'warnings' => []]];
    }

    $lookup = [];
    foreach ($students as $student) {
        $lookup[(int) $student['id']] = $student;
    }

    $preview = year_end_rollover_preview($students, $nextIds, $oldIds);
    $applied = [
        'next' => 0,
        'old' => 0,
        'both' => 0,
        'warnings' => $preview['warnings'],
    ];

    $conn->begin_transaction();
    try {
        foreach (array_keys($preview['next'] + $preview['old']) as $studentId) {
            if (!isset($lookup[$studentId])) {
                continue;
            }
            $student = $lookup[$studentId];
            year_end_rollover_upsert_log($conn, $studentId, $sourceYear, $targetYear, $createdBy);

            $nextStudentId = 0;
            if (isset($preview['next'][$studentId])) {
                $nextStudentId = year_end_rollover_copy_student($conn, $student, $targetYear);
                $nextStmt = $conn->prepare("
                    UPDATE school_year_rollover_log
                    SET next_student_id = ?, next_copied_at = NOW()
                    WHERE source_student_id = ? AND source_school_year_label = ? AND target_school_year_label = ?
                ");
                $nextStmt->bind_param('iiss', $nextStudentId, $studentId, $sourceYear, $targetYear);
                $nextStmt->execute();
                $nextStmt->close();
                $applied['next']++;
            }

            if (isset($preview['old'][$studentId])) {
                $linkedStudentId = $nextStudentId > 0 ? $nextStudentId : null;
                $oldCopy = year_end_rollover_copy_old_account($conn, $student, $sourceYear, $linkedStudentId);
                $oldStudentId = (int) ($oldCopy['old_student_id'] ?? 0);
                $carriedBalance = (float) ($oldCopy['carried_old_balance'] ?? 0);

                $oldStmt = $conn->prepare("
                    UPDATE school_year_rollover_log
                    SET old_student_id = ?, old_copied_at = NOW(), carried_old_balance = ?
                    WHERE source_student_id = ? AND source_school_year_label = ? AND target_school_year_label = ?
                ");
                $oldStmt->bind_param('idiss', $oldStudentId, $carriedBalance, $studentId, $sourceYear, $targetYear);
                $oldStmt->execute();
                $oldStmt->close();
                $applied['old']++;
            }

            if (isset($preview['next'][$studentId]) && isset($preview['old'][$studentId])) {
                $applied['both']++;
            }
        }

        $conn->commit();
        return ['success' => true, 'result' => $applied];
    } catch (Throwable $e) {
        $conn->rollback();
        return ['success' => false, 'message' => $e->getMessage(), 'result' => $applied];
    }
}










