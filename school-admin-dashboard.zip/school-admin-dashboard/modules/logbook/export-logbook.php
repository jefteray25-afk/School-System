<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();

require __DIR__ . '/../../vendor/autoload.php';
require __DIR__ . '/../../config/database.php';
require __DIR__ . '/../settings/settings-permissions-roles.php';
include_once __DIR__ . '/../../includes/includes-receipt-helper.php';
include_once __DIR__ . '/../../includes/schema-migration.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;

$currentRole = $_SESSION['role'] ?? '';
if (!hasPermission($currentRole, 'financial', 'view')) {
    admin_session_forbidden();
}

function detect_payment_mode(string $primary = '', string $secondary = ''): string
{
    $haystack = strtolower(trim($primary . ' ' . $secondary));
    if (strpos($haystack, 'bank transfer') !== false || strpos($haystack, 'banktransfer') !== false) return 'Bank Transfer';
    if (strpos($haystack, 'gcash') !== false) return 'GCash';
    if (preg_match('/\bcash\b/i', $haystack)) return 'Cash';
    return 'Cash';
}

function extract_reference_number(string ...$parts): string
{
    $text = trim(implode(' ', $parts));
    if ($text === '') return '-';
    foreach ([
        '/Ref#:\s*([^\)\]\s,;]+)/i',
        '/Ref\s*#?\s*[:\-]?\s*([^\)\]\s,;]+)/i',
        '/Reference\s*(?:No\.?|Number)?\s*[:\-]?\s*([^\)\]\s,;]+)/i',
    ] as $pattern) {
        if (preg_match($pattern, $text, $matches)) return trim($matches[1]);
    }
    return '-';
}

function extract_old_grade(string $notes = ''): string
{
    return preg_match('/\bGrade\s*\d+\b/i', $notes, $matches) ? trim($matches[0]) : '-';
}

function time_display(?string $dateTime): string
{
    if (!$dateTime) return 'No time';
    $timestamp = strtotime($dateTime);
    return $timestamp === false ? 'No time' : date('g:i A', $timestamp);
}

function shift_filter_sql(string $shiftKey, string $column): string
{
    if ($shiftKey === 'morning') return " AND TIME($column) >= '06:00:00' AND TIME($column) <= '12:00:00'";
    if ($shiftKey === 'afternoon') return " AND TIME($column) >= '12:01:00' AND TIME($column) <= '17:00:00'";
    return '';
}

function ensure_logbook_notes_table(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }

    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS logbook_shift_notes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        log_date DATE NOT NULL,
        shift_key VARCHAR(20) NOT NULL,
        note_text TEXT DEFAULT NULL,
        prepared_by VARCHAR(100) DEFAULT NULL,
        reviewed_by VARCHAR(100) DEFAULT NULL,
        opening_cash DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        deposited_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        turnover_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        cash_deduction DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        is_finalized TINYINT(1) NOT NULL DEFAULT 0,
        finalized_by VARCHAR(100) DEFAULT NULL,
        finalized_at DATETIME DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_logbook_shift (log_date, shift_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
}

ensure_logbook_notes_table($conn);
function ensure_old_payment_datetime_column(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }
    $columnName = 'paid_at_datetime';
    $check = $conn->prepare("
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'old_student_payments'
          AND COLUMN_NAME = ?
        LIMIT 1
    ");
    $check->bind_param('s', $columnName);
    $check->execute();
    $exists = $check->get_result()->num_rows > 0;
    $check->close();
    if (!$exists) {
        schema_migration_attempt($conn, "ALTER TABLE old_student_payments ADD COLUMN paid_at_datetime DATETIME NULL AFTER paid_at");
    }
}
ensure_old_payment_datetime_column($conn);

$columns = [
    'actual_cash_on_hand' => "ALTER TABLE logbook_shift_notes ADD COLUMN actual_cash_on_hand DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER cash_deduction",
    'correction_note' => "ALTER TABLE logbook_shift_notes ADD COLUMN correction_note TEXT DEFAULT NULL AFTER actual_cash_on_hand",
];
if (schema_migration_mode_enabled()) {
    foreach ($columns as $columnName => $alterSql) {
        $check = $conn->prepare("
            SELECT 1
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = 'logbook_shift_notes'
              AND COLUMN_NAME = ?
            LIMIT 1
        ");
        $check->bind_param('s', $columnName);
        $check->execute();
        $exists = $check->get_result()->num_rows > 0;
        $check->close();
        if (!$exists) {
            schema_migration_attempt($conn, $alterSql);
        }
    }
}

$shiftOptions = [
    'morning' => 'Morning Shift (6:00 AM - 12:00 PM)',
    'afternoon' => 'Afternoon Shift (12:01 PM - 5:00 PM)',
    'whole_day' => 'Whole Day',
];

$selectedDate = trim($_GET['log_date'] ?? date('Y-m-d'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate)) $selectedDate = date('Y-m-d');
$selectedShift = trim($_GET['shift'] ?? 'whole_day');
if (!isset($shiftOptions[$selectedShift])) $selectedShift = 'whole_day';

$noteRow = [
    'note_text' => '',
    'prepared_by' => '',
    'reviewed_by' => '',
    'opening_cash' => 0.0,
    'deposited_amount' => 0.0,
    'turnover_amount' => 0.0,
    'cash_deduction' => 0.0,
    'actual_cash_on_hand' => 0.0,
    'correction_note' => '',
    'is_finalized' => 0,
    'finalized_by' => '',
    'finalized_at' => null,
];
$stmt = $conn->prepare('SELECT note_text, prepared_by, reviewed_by, opening_cash, deposited_amount, turnover_amount, cash_deduction, actual_cash_on_hand, correction_note, is_finalized, finalized_by, finalized_at FROM logbook_shift_notes WHERE log_date = ? AND shift_key = ? LIMIT 1');
$stmt->bind_param('ss', $selectedDate, $selectedShift);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) $noteRow = array_merge($noteRow, $row);
$stmt->close();

$transactions = [];
$shiftClause = shift_filter_sql($selectedShift, 'p.date_paid');
$activeSql = "
SELECT p.date_paid AS occurred_at, p.booklet_no, p.receipt_no, p.amount, p.remarks, p.receipt_note,
       COALESCE(at.name, a.type, 'Uncategorized') AS fee_name,
       CONCAT(s.lastname, ', ', s.firstname, CASE WHEN TRIM(COALESCE(s.middlename, '')) <> '' THEN CONCAT(' ', s.middlename) ELSE '' END) AS payee_name,
       COALESCE(NULLIF(TRIM(s.grade), ''), '-') AS grade_level
FROM payments p
LEFT JOIN accounts a ON p.account_id = a.id
LEFT JOIN account_types at ON a.type = at.name
LEFT JOIN students s ON a.student_id = s.id
WHERE DATE(p.date_paid) = ? AND p.booklet_no IS NOT NULL AND p.receipt_no IS NOT NULL $shiftClause
ORDER BY p.date_paid ASC, p.id ASC";
$stmt = $conn->prepare($activeSql);
$stmt->bind_param('s', $selectedDate);
$stmt->execute();
$activeResult = $stmt->get_result();
while ($row = $activeResult->fetch_assoc()) {
    $transactions[] = [
        'source' => 'Active',
        'date_display' => date('n/j/Y', strtotime((string) $row['occurred_at'])),
        'time_display' => time_display((string) $row['occurred_at']),
        'payment_mode' => detect_payment_mode((string) ($row['receipt_note'] ?? ''), (string) ($row['remarks'] ?? '')),
        'reference_no' => extract_reference_number((string) ($row['remarks'] ?? ''), (string) ($row['receipt_note'] ?? '')),
        'booklet_label' => booklet_label_from_stored((int) $row['booklet_no']),
        'receipt_no' => (string) $row['receipt_no'],
        'school_fee' => trim((string) ($row['fee_name'] ?? 'Uncategorized')) ?: 'Uncategorized',
        'payee' => trim((string) ($row['payee_name'] ?? 'Unknown Student')) ?: 'Unknown Student',
        'grade_level' => trim((string) ($row['grade_level'] ?? '-')) ?: '-',
        'amount' => (float) $row['amount'],
    ];
}
$stmt->close();

if ($selectedShift === 'whole_day') {
    $oldSql = "
    SELECT p.paid_at, p.paid_at_datetime, p.booklet_no, p.receipt_no, p.amount, p.note, p.fee_type, s.notes AS student_notes,
           CONCAT(s.lastname, ', ', s.firstname, CASE WHEN TRIM(COALESCE(s.middlename, '')) <> '' THEN CONCAT(' ', s.middlename) ELSE '' END) AS payee_name
    FROM old_student_payments p
    LEFT JOIN old_students s ON p.old_student_id = s.id
    WHERE p.paid_at = ? AND p.booklet_no IS NOT NULL AND p.receipt_no IS NOT NULL AND (p.deleted_at IS NULL OR p.deleted_at = '')
    ORDER BY COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) ASC, p.id ASC";
    $stmt = $conn->prepare($oldSql);
    $stmt->bind_param('s', $selectedDate);
    $stmt->execute();
    $oldResult = $stmt->get_result();
    while ($row = $oldResult->fetch_assoc()) {
        $transactions[] = [
            'source' => 'Old',
            'date_display' => date('n/j/Y', strtotime((string) ($row['paid_at_datetime'] ?: $row['paid_at']))),
            'time_display' => !empty($row['paid_at_datetime']) ? time_display((string) $row['paid_at_datetime']) : 'No time',
            'payment_mode' => detect_payment_mode((string) ($row['note'] ?? '')),
            'reference_no' => extract_reference_number((string) ($row['note'] ?? '')),
            'booklet_label' => booklet_label_from_stored((int) $row['booklet_no']),
            'receipt_no' => (string) $row['receipt_no'],
            'school_fee' => trim((string) ($row['fee_type'] ?? 'Uncategorized')) ?: 'Uncategorized',
            'payee' => trim((string) ($row['payee_name'] ?? 'Unknown Old Student')) ?: 'Unknown Old Student',
            'grade_level' => extract_old_grade((string) ($row['student_notes'] ?? '')),
            'amount' => (float) $row['amount'],
        ];
    }
    $stmt->close();
}

usort($transactions, static function (array $a, array $b): int {
    return strcmp($a['date_display'] . ' ' . $a['time_display'] . ' ' . $a['receipt_no'], $b['date_display'] . ' ' . $b['time_display'] . ' ' . $b['receipt_no']);
});

$modeTotals = ['Cash' => ['amount' => 0.0, 'count' => 0], 'GCash' => ['amount' => 0.0, 'count' => 0], 'Bank Transfer' => ['amount' => 0.0, 'count' => 0]];
$grandTotal = 0.0;
foreach ($transactions as $transaction) {
    $mode = $transaction['payment_mode'];
    if (!isset($modeTotals[$mode])) $modeTotals[$mode] = ['amount' => 0.0, 'count' => 0];
    $modeTotals[$mode]['amount'] += $transaction['amount'];
    $modeTotals[$mode]['count']++;
    $grandTotal += $transaction['amount'];
}
$cashCollected = (float) ($modeTotals['Cash']['amount'] ?? 0.0);
$openingCash = (float) ($noteRow['opening_cash'] ?? 0.0);
$depositedAmount = (float) ($noteRow['deposited_amount'] ?? 0.0);
$turnoverAmount = (float) ($noteRow['turnover_amount'] ?? 0.0);
$cashDeduction = (float) ($noteRow['cash_deduction'] ?? 0.0);
$actualCashOnHand = (float) ($noteRow['actual_cash_on_hand'] ?? 0.0);
$remainingCashOnHand = $openingCash + $cashCollected - $depositedAmount - $turnoverAmount - $cashDeduction;
$shortageOverage = $actualCashOnHand - $remainingCashOnHand;

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Logbook');

$sheet->setCellValue('A1', 'Daily Cashier Logbook');
$sheet->mergeCells('A1:J1');
$sheet->setCellValue('A2', "The Lord's Wisdom Academy Of Caloocan Inc.");
$sheet->mergeCells('A2:J2');
$sheet->setCellValue('A4', 'Date');
$sheet->setCellValue('B4', date('F j, Y', strtotime($selectedDate)));
$sheet->setCellValue('D4', 'Shift');
$sheet->setCellValue('E4', $shiftOptions[$selectedShift] ?? $selectedShift);
$sheet->setCellValue('G4', 'Status');
$sheet->setCellValue('H4', ((int) ($noteRow['is_finalized'] ?? 0) === 1) ? 'Finalized' : 'Draft');

$sheet->setCellValue('A6', 'Cash Total');
$sheet->setCellValue('B6', $modeTotals['Cash']['amount'] ?? 0);
$sheet->setCellValue('C6', 'GCash Total');
$sheet->setCellValue('D6', $modeTotals['GCash']['amount'] ?? 0);
$sheet->setCellValue('E6', 'Bank Transfer Total');
$sheet->setCellValue('F6', $modeTotals['Bank Transfer']['amount'] ?? 0);
$sheet->setCellValue('G6', 'Grand Total');
$sheet->setCellValue('H6', $grandTotal);

$sheet->setCellValue('A8', 'Opening Cash');
$sheet->setCellValue('B8', $openingCash);
$sheet->setCellValue('C8', 'Deposited');
$sheet->setCellValue('D8', $depositedAmount);
$sheet->setCellValue('E8', 'Turnover');
$sheet->setCellValue('F8', $turnoverAmount);
$sheet->setCellValue('G8', 'Cash Deduction');
$sheet->setCellValue('H8', $cashDeduction);
$sheet->setCellValue('I8', 'Remaining Cash');
$sheet->setCellValue('J8', $remainingCashOnHand);
$sheet->setCellValue('A9', 'Actual Cash');
$sheet->setCellValue('B9', $actualCashOnHand);
$sheet->setCellValue('C9', 'Shortage/Overage');
$sheet->setCellValue('D9', $shortageOverage);
$sheet->setCellValue('E9', 'Correction Note');
$sheet->setCellValue('F9', $noteRow['correction_note'] ?: '');
$sheet->mergeCells('F9:J9');

$headerRow = 12;
$headers = ['Date', 'Time', 'Payment', 'Reference No', 'Booklet No', 'Receipt No', 'School Fee', 'Payee', 'Grade Level', 'Amount'];
$col = 'A';
foreach ($headers as $header) {
    $sheet->setCellValue($col . $headerRow, $header);
    $col++;
}

$rowNo = $headerRow + 1;
foreach ($transactions as $transaction) {
    $sheet->setCellValue("A$rowNo", $transaction['date_display']);
    $sheet->setCellValue("B$rowNo", $transaction['time_display']);
    $sheet->setCellValue("C$rowNo", $transaction['payment_mode']);
    $sheet->setCellValue("D$rowNo", $transaction['reference_no']);
    $sheet->setCellValue("E$rowNo", $transaction['booklet_label']);
    $sheet->setCellValue("F$rowNo", $transaction['receipt_no']);
    $sheet->setCellValue("G$rowNo", $transaction['school_fee']);
    $sheet->setCellValue("H$rowNo", $transaction['payee']);
    $sheet->setCellValue("I$rowNo", $transaction['grade_level']);
    $sheet->setCellValue("J$rowNo", $transaction['amount']);
    $rowNo++;
}

$notesRow = max($rowNo + 1, 15);
$sheet->setCellValue("A$notesRow", 'Notes');
$sheet->mergeCells("A$notesRow:B$notesRow");
$sheet->setCellValue("C$notesRow", $noteRow['note_text'] ?: '');
$sheet->mergeCells("C$notesRow:J$notesRow");

$signatureRow = $notesRow + 3;
$sheet->setCellValue("A$signatureRow", 'Prepared By');
$sheet->setCellValue("C$signatureRow", $noteRow['prepared_by'] ?: '');
$sheet->setCellValue("E$signatureRow", 'Reviewed By');
$sheet->setCellValue("G$signatureRow", $noteRow['reviewed_by'] ?: '');
$sheet->setCellValue("I$signatureRow", 'Finalized By');
$sheet->setCellValue("J$signatureRow", $noteRow['finalized_by'] ?: '');

$lastDataRow = max($signatureRow, $rowNo - 1);

$sheet->getStyle('A1:J1')->getFont()->setBold(true)->setSize(18);
$sheet->getStyle('A2:J2')->getFont()->setBold(true)->setSize(13);
$sheet->getStyle('A1:J2')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
$sheet->getStyle("A{$headerRow}:J{$headerRow}")->applyFromArray([
    'font' => ['bold' => true],
    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'D9EAF7']],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER],
]);
$sheet->getStyle("A4:J8")->getFont()->setBold(true);
$sheet->getStyle("B6:B9")->getNumberFormat()->setFormatCode('#,##0.00');
$sheet->getStyle("D6:D9")->getNumberFormat()->setFormatCode('#,##0.00');
$sheet->getStyle("F6:F8")->getNumberFormat()->setFormatCode('#,##0.00');
$sheet->getStyle("H6:H8")->getNumberFormat()->setFormatCode('#,##0.00');
$sheet->getStyle("J8")->getNumberFormat()->setFormatCode('#,##0.00');
if ($rowNo > $headerRow + 1) {
    $sheet->getStyle("J" . ($headerRow + 1) . ":J" . ($rowNo - 1))->getNumberFormat()->setFormatCode('#,##0.00');
}
$sheet->getStyle("A{$headerRow}:J{$lastDataRow}")->applyFromArray([
    'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => '333333']]],
]);
$sheet->freezePane("A" . ($headerRow + 1));
foreach (range('A', 'J') as $column) {
    $sheet->getColumnDimension($column)->setAutoSize(true);
}

$safeShift = preg_replace('/[^A-Za-z0-9_-]+/', '_', $selectedShift);
while (ob_get_level() > 0) {
    ob_end_clean();
}
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="logbook_' . $selectedDate . '_' . $safeShift . '.xlsx"');
header('Cache-Control: max-age=0');
header('Pragma: public');
$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
