<?php

require_once __DIR__ . '/../../includes/schema-migration.php';

function ensure_logbook_notes_table(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }

    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS logbook_shift_notes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        log_date DATE NOT NULL,
        shift_key VARCHAR(20) NOT NULL,
        note_text TEXT DEFAULT NULL,
        prepared_by VARCHAR(100) DEFAULT NULL,
        reviewed_by VARCHAR(100) DEFAULT NULL,
        opening_cash DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        deposited_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        turnover_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        cash_deduction DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_logbook_shift (log_date, shift_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

    $columns = [
        'opening_cash' => "ALTER TABLE logbook_shift_notes ADD COLUMN opening_cash DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER reviewed_by",
        'deposited_amount' => "ALTER TABLE logbook_shift_notes ADD COLUMN deposited_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER opening_cash",
        'turnover_amount' => "ALTER TABLE logbook_shift_notes ADD COLUMN turnover_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER deposited_amount",
        'cash_deduction' => "ALTER TABLE logbook_shift_notes ADD COLUMN cash_deduction DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER turnover_amount",
        'actual_cash_on_hand' => "ALTER TABLE logbook_shift_notes ADD COLUMN actual_cash_on_hand DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER cash_deduction",
        'correction_note' => "ALTER TABLE logbook_shift_notes ADD COLUMN correction_note TEXT DEFAULT NULL AFTER actual_cash_on_hand",
        'is_finalized' => "ALTER TABLE logbook_shift_notes ADD COLUMN is_finalized TINYINT(1) NOT NULL DEFAULT 0 AFTER cash_deduction",
        'finalized_by' => "ALTER TABLE logbook_shift_notes ADD COLUMN finalized_by VARCHAR(100) DEFAULT NULL AFTER is_finalized",
        'finalized_at' => "ALTER TABLE logbook_shift_notes ADD COLUMN finalized_at DATETIME DEFAULT NULL AFTER finalized_by",
    ];
    foreach ($columns as $columnName => $alterSql) {
        $check = $conn->prepare("
            SELECT 1
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = 'logbook_shift_notes'
              AND COLUMN_NAME = ?
            LIMIT 1
        ");
        if (!$check) {
            continue;
        }
        $check->bind_param('s', $columnName);
        $check->execute();
        $exists = $check->get_result()->num_rows > 0;
        $check->close();
        if (!$exists) {
            schema_migration_attempt($conn, $alterSql);
        }
    }
}

function ensure_logbook_audit_table(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }

    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS logbook_audit_trail (
        id INT AUTO_INCREMENT PRIMARY KEY,
        log_date DATE NOT NULL,
        shift_key VARCHAR(20) NOT NULL,
        action_type VARCHAR(40) NOT NULL,
        action_details TEXT DEFAULT NULL,
        changed_by VARCHAR(100) DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_logbook_audit (log_date, shift_key, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
}

function ensure_logbook_day_close_table(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }

    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS logbook_day_close (
        id INT AUTO_INCREMENT PRIMARY KEY,
        log_date DATE NOT NULL UNIQUE,
        deposit_total DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        turnover_total DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        retained_cash DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        reviewed_by VARCHAR(100) DEFAULT NULL,
        closing_note TEXT DEFAULT NULL,
        is_closed TINYINT(1) NOT NULL DEFAULT 0,
        closed_by VARCHAR(100) DEFAULT NULL,
        closed_at DATETIME DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
}

function ensure_logbook_day_close_audit(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }

    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS logbook_day_close_audit (
        id INT AUTO_INCREMENT PRIMARY KEY,
        log_date DATE NOT NULL,
        action_type VARCHAR(40) NOT NULL,
        action_details TEXT DEFAULT NULL,
        changed_by VARCHAR(100) DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_day_close_audit (log_date, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
}
