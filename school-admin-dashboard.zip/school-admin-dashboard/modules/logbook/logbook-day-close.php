<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../settings/settings-security.php';
require_once __DIR__ . '/../../includes/schema-migration.php';

$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$canView = hasPermission($role, 'financial', 'view');
$canEdit = hasPermission($role, 'financial', 'edit');
if (!$canView) {
    admin_session_forbidden();
}

function day_close_money(float $amount): string
{
    return 'PHP ' . number_format($amount, 2);
}

function ensure_logbook_day_close_table(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }

    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS logbook_day_close (
        id INT AUTO_INCREMENT PRIMARY KEY,
        log_date DATE NOT NULL UNIQUE,
        deposit_total DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        turnover_total DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        retained_cash DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        reviewed_by VARCHAR(100) DEFAULT NULL,
        closing_note TEXT DEFAULT NULL,
        is_closed TINYINT(1) NOT NULL DEFAULT 0,
        closed_by VARCHAR(100) DEFAULT NULL,
        closed_at DATETIME DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
}

function ensure_logbook_day_close_audit(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }

    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS logbook_day_close_audit (
        id INT AUTO_INCREMENT PRIMARY KEY,
        log_date DATE NOT NULL,
        action_type VARCHAR(40) NOT NULL,
        action_details TEXT DEFAULT NULL,
        changed_by VARCHAR(100) DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_day_close_audit (log_date, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
}

function logbook_day_close_audit(mysqli $conn, string $logDate, string $actionType, string $changedBy, string $details): void
{
    $stmt = $conn->prepare("INSERT INTO logbook_day_close_audit (log_date, action_type, action_details, changed_by) VALUES (?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param('ssss', $logDate, $actionType, $details, $changedBy);
        $stmt->execute();
        $stmt->close();
    }
}

ensure_logbook_day_close_table($conn);
ensure_logbook_day_close_audit($conn);
admin_csrf_token();

$selectedDate = trim($_GET['log_date'] ?? date('Y-m-d'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate)) {
    $selectedDate = date('Y-m-d');
}

$message = '';
$errorMessage = '';
$dayClose = [
    'deposit_total' => 0.0,
    'turnover_total' => 0.0,
    'retained_cash' => 0.0,
    'reviewed_by' => '',
    'closing_note' => '',
    'is_closed' => 0,
    'closed_by' => '',
    'closed_at' => null,
];

$summary = [
    'morning_finalized' => 0,
    'afternoon_finalized' => 0,
    'total_collections' => 0.0,
    'cash_collections' => 0.0,
    'gcash_collections' => 0.0,
    'bank_collections' => 0.0,
    'transactions' => 0,
];

$summaryStmt = $conn->prepare("SELECT
    SUM(CASE WHEN shift_key = 'morning' AND is_finalized = 1 THEN 1 ELSE 0 END) AS morning_finalized,
    SUM(CASE WHEN shift_key = 'afternoon' AND is_finalized = 1 THEN 1 ELSE 0 END) AS afternoon_finalized
    FROM logbook_shift_notes
    WHERE log_date = ?");
if ($summaryStmt) {
    $summaryStmt->bind_param('s', $selectedDate);
    $summaryStmt->execute();
    $row = $summaryStmt->get_result()->fetch_assoc() ?: [];
    $summary['morning_finalized'] = (int) ($row['morning_finalized'] ?? 0);
    $summary['afternoon_finalized'] = (int) ($row['afternoon_finalized'] ?? 0);
    $summaryStmt->close();
}

$activeStmt = $conn->prepare("SELECT amount, receipt_note, remarks FROM payments WHERE DATE(date_paid) = ?");
if ($activeStmt) {
    $activeStmt->bind_param('s', $selectedDate);
    $activeStmt->execute();
    $result = $activeStmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $mode = 'Cash';
        $haystack = strtolower(trim((string) ($row['receipt_note'] ?? '') . ' ' . (string) ($row['remarks'] ?? '')));
        if (strpos($haystack, 'gcash') !== false) $mode = 'GCash';
        elseif (strpos($haystack, 'bank transfer') !== false || strpos($haystack, 'banktransfer') !== false) $mode = 'Bank Transfer';
        $summary['total_collections'] += (float) $row['amount'];
        $summary['transactions']++;
        if ($mode === 'GCash') $summary['gcash_collections'] += (float) $row['amount'];
        elseif ($mode === 'Bank Transfer') $summary['bank_collections'] += (float) $row['amount'];
        else $summary['cash_collections'] += (float) $row['amount'];
    }
    $activeStmt->close();
}

$oldStmt = $conn->prepare("SELECT amount_paid, note FROM old_student_payments WHERE DATE(COALESCE(paid_at_datetime, CONCAT(paid_at, ' 00:00:00'))) = ? AND (deleted_at IS NULL OR deleted_at = '')");
if ($oldStmt) {
    $oldStmt->bind_param('s', $selectedDate);
    $oldStmt->execute();
    $result = $oldStmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $mode = 'Cash';
        $haystack = strtolower(trim((string) ($row['note'] ?? '')));
        if (strpos($haystack, 'gcash') !== false) $mode = 'GCash';
        elseif (strpos($haystack, 'bank transfer') !== false || strpos($haystack, 'banktransfer') !== false) $mode = 'Bank Transfer';
        $summary['total_collections'] += (float) $row['amount_paid'];
        $summary['transactions']++;
        if ($mode === 'GCash') $summary['gcash_collections'] += (float) $row['amount_paid'];
        elseif ($mode === 'Bank Transfer') $summary['bank_collections'] += (float) $row['amount_paid'];
        else $summary['cash_collections'] += (float) $row['amount_paid'];
    }
    $oldStmt->close();
}

$loadStmt = $conn->prepare("SELECT deposit_total, turnover_total, retained_cash, reviewed_by, closing_note, is_closed, closed_by, closed_at FROM logbook_day_close WHERE log_date = ? LIMIT 1");
if ($loadStmt) {
    $loadStmt->bind_param('s', $selectedDate);
    $loadStmt->execute();
    $row = $loadStmt->get_result()->fetch_assoc();
    if ($row) {
        $dayClose = array_merge($dayClose, $row);
    }
    $loadStmt->close();
}

$isClosed = (int) ($dayClose['is_closed'] ?? 0) === 1;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_day_close'])) {
    if (!$canEdit) {
        $errorMessage = 'Wala kang permission para mag-save ng day close.';
    } elseif (!admin_csrf_validate($_POST['csrf_token'] ?? '')) {
        $errorMessage = 'Invalid CSRF token.';
    } elseif ($isClosed) {
        $errorMessage = 'Closed na ang day-end record na ito. I-reopen muna bago baguhin.';
    } else {
        $depositTotal = max(0, (float) ($_POST['deposit_total'] ?? 0));
        $turnoverTotal = max(0, (float) ($_POST['turnover_total'] ?? 0));
        $retainedCash = max(0, (float) ($_POST['retained_cash'] ?? 0));
        $reviewedBy = trim($_POST['reviewed_by'] ?? '');
        $closingNote = trim($_POST['closing_note'] ?? '');
        $stmt = $conn->prepare("INSERT INTO logbook_day_close
            (log_date, deposit_total, turnover_total, retained_cash, reviewed_by, closing_note)
            VALUES (?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
            deposit_total = VALUES(deposit_total),
            turnover_total = VALUES(turnover_total),
            retained_cash = VALUES(retained_cash),
            reviewed_by = VALUES(reviewed_by),
            closing_note = VALUES(closing_note)");
        $stmt->bind_param('sdddss', $selectedDate, $depositTotal, $turnoverTotal, $retainedCash, $reviewedBy, $closingNote);
        if ($stmt->execute()) {
            $message = 'Day close draft saved successfully.';
            logbook_day_close_audit($conn, $selectedDate, 'save', $username, "DepositTotal={$depositTotal}; TurnoverTotal={$turnoverTotal}; RetainedCash={$retainedCash}");
            $dayClose = array_merge($dayClose, [
                'deposit_total' => $depositTotal,
                'turnover_total' => $turnoverTotal,
                'retained_cash' => $retainedCash,
                'reviewed_by' => $reviewedBy,
                'closing_note' => $closingNote,
            ]);
        } else {
            $errorMessage = 'Failed to save day close.';
        }
        $stmt->close();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['close_day'])) {
    if (!$canEdit) {
        $errorMessage = 'Wala kang permission para mag-close ng day-end workflow.';
    } elseif (!admin_csrf_validate($_POST['csrf_token'] ?? '')) {
        $errorMessage = 'Invalid CSRF token.';
    } elseif ($summary['morning_finalized'] === 0 || $summary['afternoon_finalized'] === 0) {
        $errorMessage = 'Finalize muna ang morning at afternoon logbook bago i-close ang araw na ito.';
    } else {
        $depositTotal = max(0, (float) ($_POST['deposit_total'] ?? 0));
        $turnoverTotal = max(0, (float) ($_POST['turnover_total'] ?? 0));
        $retainedCash = max(0, (float) ($_POST['retained_cash'] ?? 0));
        $reviewedBy = trim($_POST['reviewed_by'] ?? '');
        $closingNote = trim($_POST['closing_note'] ?? '');
        $stmt = $conn->prepare("INSERT INTO logbook_day_close
            (log_date, deposit_total, turnover_total, retained_cash, reviewed_by, closing_note, is_closed, closed_by, closed_at)
            VALUES (?, ?, ?, ?, ?, ?, 1, ?, NOW())
            ON DUPLICATE KEY UPDATE
            deposit_total = VALUES(deposit_total),
            turnover_total = VALUES(turnover_total),
            retained_cash = VALUES(retained_cash),
            reviewed_by = VALUES(reviewed_by),
            closing_note = VALUES(closing_note),
            is_closed = 1,
            closed_by = VALUES(closed_by),
            closed_at = NOW()");
        $stmt->bind_param('sddddss', $selectedDate, $depositTotal, $turnoverTotal, $retainedCash, $reviewedBy, $closingNote, $username);
        if ($stmt->execute()) {
            $message = 'Day-end workflow closed successfully.';
            logbook_day_close_audit($conn, $selectedDate, 'close', $username, "DepositTotal={$depositTotal}; TurnoverTotal={$turnoverTotal}; RetainedCash={$retainedCash}");
            $isClosed = true;
            $dayClose = array_merge($dayClose, [
                'deposit_total' => $depositTotal,
                'turnover_total' => $turnoverTotal,
                'retained_cash' => $retainedCash,
                'reviewed_by' => $reviewedBy,
                'closing_note' => $closingNote,
                'is_closed' => 1,
                'closed_by' => $username,
                'closed_at' => date('Y-m-d H:i:s'),
            ]);
        } else {
            $errorMessage = 'Failed to close day-end workflow.';
        }
        $stmt->close();
    }
}

$auditEntries = [];
$auditStmt = $conn->prepare("SELECT action_type, action_details, changed_by, created_at FROM logbook_day_close_audit WHERE log_date = ? ORDER BY created_at DESC");
if ($auditStmt) {
    $auditStmt->bind_param('s', $selectedDate);
    $auditStmt->execute();
    $auditEntries = $auditStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $auditStmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logbook Day Close | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background:#f5f8fc; font-family:'Segoe UI','Roboto','Arial',sans-serif; color:#23395d; }
        .navbar { background:#23395d !important; }
        .navbar-brand, .navbar-nav .nav-link { color:#fff !important; }
        .page-wrap { max-width:1120px; margin:34px auto 32px; padding:0 12px; }
        .hero, .panel { background:#fff; border:1px solid #dce8f7; border-radius:18px; box-shadow:0 8px 24px rgba(33,57,93,.08); }
        .hero { padding:22px 24px; margin-bottom:18px; }
        .summary-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:14px; }
        .summary-card { background:#f8fbff; border:1px solid #dce8f7; border-radius:16px; padding:16px; }
        .summary-label { font-size:.8rem; text-transform:uppercase; letter-spacing:.05em; color:#607388; font-weight:700; }
        .summary-value { font-size:1.4rem; font-weight:800; }
        .audit-item { border:1px solid #e3ebf5; border-radius:12px; padding:12px 14px; background:#fafcff; margin-bottom:10px; }
    </style>
</head>
<body>
<?php render_admin_nav('logbook', true); ?>

<div class="page-wrap">
    <div class="hero">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">
            <div>
                <h2 class="h4 mb-1"><i class="fas fa-calendar-check me-2"></i>Day-End Close Workflow</h2>
                <div class="text-muted">Use this after both shifts are reviewed to summarize deposits, turnover, retained cash, and final day notes.</div>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <a href="/school-admin-dashboard/modules/logbook/logbook.php?log_date=<?= urlencode($selectedDate) ?>&shift=whole_day" class="btn btn-outline-secondary"><i class="fas fa-arrow-left me-1"></i>Back to Logbook</a>
            </div>
        </div>
        <form method="get" class="mt-3">
            <label class="form-label fw-semibold">Log Date</label>
            <div class="d-flex gap-2 flex-wrap">
                <input type="date" name="log_date" class="form-control" style="max-width: 220px;" value="<?= htmlspecialchars($selectedDate) ?>">
                <button type="submit" class="btn btn-primary"><i class="fas fa-filter me-1"></i>Load Date</button>
            </div>
        </form>
    </div>

    <div class="summary-grid mb-4">
        <div class="summary-card"><div class="summary-label">Morning Finalized</div><div class="summary-value"><?= number_format($summary['morning_finalized']) ?></div></div>
        <div class="summary-card"><div class="summary-label">Afternoon Finalized</div><div class="summary-value"><?= number_format($summary['afternoon_finalized']) ?></div></div>
        <div class="summary-card"><div class="summary-label">Total Collections</div><div class="summary-value"><?= htmlspecialchars(day_close_money($summary['total_collections'])) ?></div></div>
        <div class="summary-card"><div class="summary-label">Cash Collections</div><div class="summary-value"><?= htmlspecialchars(day_close_money($summary['cash_collections'])) ?></div></div>
        <div class="summary-card"><div class="summary-label">GCash + Bank</div><div class="summary-value"><?= htmlspecialchars(day_close_money($summary['gcash_collections'] + $summary['bank_collections'])) ?></div></div>
    </div>

    <div class="panel p-4 mb-4">
        <?php if ($message !== ''): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        <?php if ($errorMessage !== ''): ?><div class="alert alert-danger"><?= htmlspecialchars($errorMessage) ?></div><?php endif; ?>
        <form method="post" class="row g-3">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(admin_csrf_token()) ?>">
            <div class="col-md-4">
                <label class="form-label fw-semibold">Deposited Total</label>
                <input type="number" min="0" step="0.01" name="deposit_total" class="form-control" value="<?= htmlspecialchars(number_format((float) $dayClose['deposit_total'], 2, '.', '')) ?>" <?= $isClosed ? 'readonly' : '' ?>>
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold">Turnover Total</label>
                <input type="number" min="0" step="0.01" name="turnover_total" class="form-control" value="<?= htmlspecialchars(number_format((float) $dayClose['turnover_total'], 2, '.', '')) ?>" <?= $isClosed ? 'readonly' : '' ?>>
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold">Retained Cash</label>
                <input type="number" min="0" step="0.01" name="retained_cash" class="form-control" value="<?= htmlspecialchars(number_format((float) $dayClose['retained_cash'], 2, '.', '')) ?>" <?= $isClosed ? 'readonly' : '' ?>>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold">Reviewed By</label>
                <input type="text" name="reviewed_by" class="form-control" value="<?= htmlspecialchars((string) $dayClose['reviewed_by']) ?>" <?= $isClosed ? 'readonly' : '' ?>>
            </div>
            <div class="col-md-6">
                <label class="form-label fw-semibold">Close Status</label>
                <input type="text" class="form-control" value="<?= $isClosed ? 'Closed' : 'Draft' ?><?= $isClosed && !empty($dayClose['closed_at']) ? ' | ' . date('M j, Y g:i A', strtotime((string) $dayClose['closed_at'])) : '' ?>" readonly>
            </div>
            <div class="col-12">
                <label class="form-label fw-semibold">Closing Note</label>
                <textarea name="closing_note" rows="4" class="form-control" <?= $isClosed ? 'readonly' : '' ?>><?= htmlspecialchars((string) $dayClose['closing_note']) ?></textarea>
            </div>
            <?php if (!$isClosed): ?>
                <div class="col-12 d-flex gap-2 flex-wrap">
                    <button type="submit" name="save_day_close" class="btn btn-success"><i class="fas fa-save me-1"></i>Save Day Close Draft</button>
                    <button type="submit" name="close_day" class="btn btn-dark"><i class="fas fa-lock me-1"></i>Close Day-End Workflow</button>
                </div>
            <?php else: ?>
                <div class="col-12">
                    <div class="alert alert-light border mb-0">Closed by <strong><?= htmlspecialchars((string) ($dayClose['closed_by'] ?: 'Unknown')) ?></strong>.</div>
                </div>
            <?php endif; ?>
        </form>
    </div>

    <div class="panel p-4">
        <h3 class="h6 mb-3"><i class="fas fa-clock-rotate-left me-2"></i>Day Close Audit</h3>
        <?php if (!$auditEntries): ?>
            <div class="text-muted">No day-close audit entries yet for this date.</div>
        <?php else: ?>
            <?php foreach ($auditEntries as $entry): ?>
                <div class="audit-item">
                    <div class="d-flex justify-content-between gap-2 flex-wrap">
                        <strong><?= htmlspecialchars(ucfirst((string) $entry['action_type'])) ?></strong>
                        <span class="small text-muted"><?= htmlspecialchars(date('n/j/Y g:i A', strtotime((string) $entry['created_at']))) ?></span>
                    </div>
                    <div class="small text-muted"><?= htmlspecialchars((string) ($entry['changed_by'] ?: 'Unknown user')) ?></div>
                    <?php if (!empty($entry['action_details'])): ?><div class="small mt-2"><?= htmlspecialchars((string) $entry['action_details']) ?></div><?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
<?php $conn->close(); ?>
