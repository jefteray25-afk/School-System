<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require_once __DIR__ . '/../../includes/ui.php';
require __DIR__ . '/../../config/database.php';
require __DIR__ . '/../settings/settings-permissions-roles.php';
require_once __DIR__ . '/../audit/audit-helper.php';
include_once __DIR__ . '/../../includes/includes-receipt-helper.php';

$currentRole = $_SESSION['role'] ?? '';
if (!hasPermission($currentRole, 'financial', 'view')) {
    header('Location: /school-admin-dashboard/dashboard.php?error=logbook_denied');
    exit();
}

$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$schoolName = "The Lord's Wisdom Academy Of Caloocan Inc.";
$canEditLogbook = hasPermission($currentRole, 'financial', 'edit') || hasPermission($currentRole, 'financial', 'add');

admin_csrf_token();

function h($value): string { return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8'); }
function money_format(float $value): string { return 'PHP ' . number_format($value, 2); }
function money_input_value($value): float {
    $normalized = str_replace(',', '', trim((string) $value));
    return ($normalized === '' || !is_numeric($normalized)) ? 0.0 : round((float) $normalized, 2);
}
function current_shift_key(): string {
    $current = date('H:i:s');
    if ($current >= '06:00:00' && $current <= '12:00:00') return 'morning';
    if ($current >= '12:01:00' && $current <= '17:00:00') return 'afternoon';
    return 'whole_day';
}
function detect_payment_mode(string $primary = '', string $secondary = ''): string {
    $haystack = strtolower(trim($primary . ' ' . $secondary));
    if (strpos($haystack, 'bank transfer') !== false || strpos($haystack, 'banktransfer') !== false) return 'Bank Transfer';
    if (strpos($haystack, 'gcash') !== false) return 'GCash';
    if (preg_match('/\bcash\b/i', $haystack)) return 'Cash';
    return 'Cash';
}
function extract_reference_number(string ...$parts): string {
    $text = trim(implode(' ', $parts));
    if ($text === '') return '-';
    foreach ([
        '/Ref#:\s*([^\)\]\s,;]+)/i',
        '/Ref\s*#?\s*[:\-]?\s*([^\)\]\s,;]+)/i',
        '/Reference\s*(?:No\.?|Number)?\s*[:\-]?\s*([^\)\]\s,;]+)/i',
    ] as $pattern) {
        if (preg_match($pattern, $text, $matches)) return trim($matches[1]);
    }
    return '-';
}
function extract_old_grade(string $notes = ''): string {
    return preg_match('/\bGrade\s*\d+\b/i', $notes, $matches) ? trim($matches[0]) : '-';
}
function time_display(?string $dateTime): string {
    if (!$dateTime) return 'No time';
    $timestamp = strtotime($dateTime);
    return $timestamp === false ? 'No time' : date('g:i A', $timestamp);
}
function classify_shift_from_datetime(?string $dateTime): string {
    if (!$dateTime) return 'whole_day';
    $timestamp = strtotime($dateTime);
    if ($timestamp === false) return 'whole_day';
    $time = date('H:i:s', $timestamp);
    if ($time >= '06:00:00' && $time <= '12:00:00') return 'morning';
    if ($time >= '12:01:00' && $time <= '17:00:00') return 'afternoon';
    return 'whole_day';
}
function shift_filter_sql(string $shiftKey, string $column): string {
    if ($shiftKey === 'morning') return " AND TIME($column) >= '06:00:00' AND TIME($column) <= '12:00:00'";
    if ($shiftKey === 'afternoon') return " AND TIME($column) >= '12:01:00' AND TIME($column) <= '17:00:00'";
    return '';
}
function ensure_logbook_notes_table(mysqli $conn): void {
    require_once __DIR__ . '/../../includes/schema-migration.php';
    if (!schema_migration_mode_enabled()) {
        return;
    }

    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS logbook_shift_notes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        log_date DATE NOT NULL,
        shift_key VARCHAR(20) NOT NULL,
        note_text TEXT DEFAULT NULL,
        prepared_by VARCHAR(100) DEFAULT NULL,
        reviewed_by VARCHAR(100) DEFAULT NULL,
        opening_cash DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        deposited_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        turnover_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        cash_deduction DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_logbook_shift (log_date, shift_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

    $columns = [
        'opening_cash' => "ALTER TABLE logbook_shift_notes ADD COLUMN opening_cash DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER reviewed_by",
        'deposited_amount' => "ALTER TABLE logbook_shift_notes ADD COLUMN deposited_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER opening_cash",
        'turnover_amount' => "ALTER TABLE logbook_shift_notes ADD COLUMN turnover_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER deposited_amount",
        'cash_deduction' => "ALTER TABLE logbook_shift_notes ADD COLUMN cash_deduction DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER turnover_amount",
        'actual_cash_on_hand' => "ALTER TABLE logbook_shift_notes ADD COLUMN actual_cash_on_hand DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER cash_deduction",
        'correction_note' => "ALTER TABLE logbook_shift_notes ADD COLUMN correction_note TEXT DEFAULT NULL AFTER actual_cash_on_hand",
        'is_finalized' => "ALTER TABLE logbook_shift_notes ADD COLUMN is_finalized TINYINT(1) NOT NULL DEFAULT 0 AFTER cash_deduction",
        'finalized_by' => "ALTER TABLE logbook_shift_notes ADD COLUMN finalized_by VARCHAR(100) DEFAULT NULL AFTER is_finalized",
        'finalized_at' => "ALTER TABLE logbook_shift_notes ADD COLUMN finalized_at DATETIME DEFAULT NULL AFTER finalized_by",
    ];
    foreach ($columns as $columnName => $alterSql) {
        $check = $conn->prepare("
            SELECT 1
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = 'logbook_shift_notes'
              AND COLUMN_NAME = ?
            LIMIT 1
        ");
        $check->bind_param('s', $columnName);
        $check->execute();
        $exists = $check->get_result()->num_rows > 0;
        $check->close();
        if (!$exists) {
            schema_migration_attempt($conn, $alterSql);
        }
    }
}

function ensure_logbook_audit_table(mysqli $conn): void
{
    require_once __DIR__ . '/../../includes/schema-migration.php';
    if (!schema_migration_mode_enabled()) {
        return;
    }

    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS logbook_audit_trail (
        id INT AUTO_INCREMENT PRIMARY KEY,
        log_date DATE NOT NULL,
        shift_key VARCHAR(20) NOT NULL,
        action_type VARCHAR(40) NOT NULL,
        action_details TEXT DEFAULT NULL,
        changed_by VARCHAR(100) DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_logbook_audit (log_date, shift_key, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
}

function logbook_audit(mysqli $conn, string $logDate, string $shiftKey, string $actionType, string $changedBy, string $details): void
{
    $stmt = $conn->prepare("INSERT INTO logbook_audit_trail (log_date, shift_key, action_type, action_details, changed_by) VALUES (?, ?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param('sssss', $logDate, $shiftKey, $actionType, $details, $changedBy);
        $stmt->execute();
        $stmt->close();
    }
}

function logbook_audit_log(mysqli $conn, string $username, string $role, string $action, string $logDate, string $shiftKey, string $details, string $level = 'INFO'): void
{
    $auditDetails = 'Role: ' . ($role !== '' ? $role : 'unknown')
        . ' | Log Date: ' . $logDate
        . ' | Shift: ' . $shiftKey
        . ($details !== '' ? ' | ' . $details : '');
    audit_log($conn, $username !== '' ? $username : 'unknown', $action, 'Logbook', $auditDetails, $level);
}

function parse_logbook_audit_details(string $details): array
{
    $details = trim($details);
    if ($details === '' || strpos($details, '=') === false) {
        return [];
    }

    $labelMap = [
        'OpeningCash' => 'Opening Cash',
        'CashCollected' => 'Cash Collected',
        'Deposited' => 'Deposited',
        'Turnover' => 'Turnover',
        'CashDeduction' => 'Cash Deduction',
        'ExpectedCash' => 'Expected Cash On Hand',
        'ActualCash' => 'Actual Cash',
        'Variance' => 'Shortage / Overage',
        'CorrectionNote' => 'Correction Note',
        'ReopenReason' => 'Reopen Reason',
    ];

    $parsed = [];
    foreach (explode(';', $details) as $part) {
        $part = trim($part);
        if ($part === '' || strpos($part, '=') === false) {
            continue;
        }

        [$key, $value] = explode('=', $part, 2);
        $key = trim($key);
        $value = trim($value);
        $label = $labelMap[$key] ?? $key;

        if (in_array($key, ['OpeningCash', 'CashCollected', 'Deposited', 'Turnover', 'CashDeduction', 'ExpectedCash', 'ActualCash', 'Variance'], true)) {
            $numericValue = is_numeric($value) ? (float) $value : 0.0;
            $value = money_format($numericValue);
        } elseif ($key === 'CorrectionNote' && $value === '') {
            $value = 'None';
        }

        $parsed[] = [
            'label' => $label,
            'value' => $value === '' ? 'None' : $value,
        ];
    }

    return $parsed;
}
function load_logbook_note(mysqli $conn, string $logDate, string $shiftKey, array $defaults): array
{
    $stmt = $conn->prepare('SELECT note_text, prepared_by, reviewed_by, opening_cash, deposited_amount, turnover_amount, cash_deduction, actual_cash_on_hand, correction_note, is_finalized, finalized_by, finalized_at FROM logbook_shift_notes WHERE log_date = ? AND shift_key = ? LIMIT 1');
    if (!$stmt) {
        return $defaults;
    }

    $stmt->bind_param('ss', $logDate, $shiftKey);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result ? $result->fetch_assoc() : null;
    $stmt->close();

    return $row ? array_merge($defaults, $row) : $defaults;
}

function logbook_form_payload(array $source, string $defaultDate, string $defaultShift, string $defaultPreparedBy): array
{
    $preparedBy = trim((string) ($source['prepared_by'] ?? ''));
    if ($preparedBy === '') {
        $preparedBy = $defaultPreparedBy;
    }

    return [
        'log_date' => trim((string) ($source['log_date'] ?? $defaultDate)),
        'shift_key' => trim((string) ($source['shift'] ?? $defaultShift)),
        'note_text' => trim((string) ($source['note_text'] ?? '')),
        'prepared_by' => $preparedBy,
        'reviewed_by' => trim((string) ($source['reviewed_by'] ?? '')),
        'opening_cash' => money_input_value($source['opening_cash'] ?? '0'),
        'deposited_amount' => money_input_value($source['deposited_amount'] ?? '0'),
        'turnover_amount' => money_input_value($source['turnover_amount'] ?? '0'),
        'cash_deduction' => money_input_value($source['cash_deduction'] ?? '0'),
        'actual_cash_on_hand' => money_input_value($source['actual_cash_on_hand'] ?? '0'),
        'correction_note' => trim((string) ($source['correction_note'] ?? '')),
    ];
}

function logbook_payload_error(array $payload, array $shiftOptions): string
{
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $payload['log_date']) || !isset($shiftOptions[$payload['shift_key']])) {
        return 'Invalid logbook date or shift.';
    }

    foreach (['opening_cash', 'deposited_amount', 'turnover_amount', 'cash_deduction', 'actual_cash_on_hand'] as $key) {
        if ((float) $payload[$key] < 0) {
            return 'Cash handling values cannot be negative.';
        }
    }

    return '';
}

function logbook_cash_collected(mysqli $conn, string $logDate, string $shiftKey): float
{
    $cashTotal = 0.0;
    $shiftClause = shift_filter_sql($shiftKey, 'p.date_paid');
    $activeSql = "SELECT p.amount, p.remarks, p.receipt_note
        FROM payments p
        WHERE DATE(p.date_paid) = ?
          AND p.booklet_no IS NOT NULL
          AND p.receipt_no IS NOT NULL {$shiftClause}";
    $stmt = $conn->prepare($activeSql);
    if ($stmt) {
        $stmt->bind_param('s', $logDate);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            if (detect_payment_mode((string) ($row['receipt_note'] ?? ''), (string) ($row['remarks'] ?? '')) === 'Cash') {
                $cashTotal += (float) ($row['amount'] ?? 0);
            }
        }
        $stmt->close();
    }

    if ($shiftKey === 'whole_day') {
        $oldSql = "SELECT amount_paid, note
            FROM old_student_payments
            WHERE DATE(COALESCE(paid_at_datetime, CONCAT(paid_at, ' 00:00:00'))) = ?
              AND (deleted_at IS NULL OR deleted_at = '')";
        $stmt = $conn->prepare($oldSql);
        if ($stmt) {
            $stmt->bind_param('s', $logDate);
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()) {
                if (detect_payment_mode((string) ($row['note'] ?? '')) === 'Cash') {
                    $cashTotal += (float) ($row['amount_paid'] ?? 0);
                }
            }
            $stmt->close();
        }
    }

    return round($cashTotal, 2);
}

function logbook_remaining_cash(array $payload, float $cashCollected): float
{
    return round(
        (float) $payload['opening_cash']
        + $cashCollected
        - (float) $payload['deposited_amount']
        - (float) $payload['turnover_amount']
        - (float) $payload['cash_deduction'],
        2
    );
}

function logbook_cash_variance(array $payload, float $cashCollected): float
{
    return round((float) $payload['actual_cash_on_hand'] - logbook_remaining_cash($payload, $cashCollected), 2);
}

function logbook_finalize_error(array $payload, float $cashCollected): string
{
    $remainingCash = logbook_remaining_cash($payload, $cashCollected);
    if ($remainingCash < -0.009) {
        return 'Hindi puwedeng i-finalize habang negative ang remaining cash on hand. I-review muna ang opening cash, deposits, turnover, o deductions.';
    }

    $variance = logbook_cash_variance($payload, $cashCollected);
    if (abs($variance) > 0.009 && trim((string) ($payload['correction_note'] ?? '')) === '') {
        return 'Required ang correction note bago mag-finalize kapag may shortage o overage.';
    }

    return '';
}

function ensure_old_payment_datetime_column(mysqli $conn): void
{
    $columnName = 'paid_at_datetime';
    $check = $conn->prepare("
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'old_student_payments'
          AND COLUMN_NAME = ?
        LIMIT 1
    ");
    $check->bind_param('s', $columnName);
    $check->execute();
    $exists = $check->get_result()->num_rows > 0;
    $check->close();
    if (!$exists) {
        $conn->query("ALTER TABLE old_student_payments ADD COLUMN paid_at_datetime DATETIME NULL AFTER paid_at");
    }
}

ensure_logbook_notes_table($conn);
ensure_logbook_audit_table($conn);
ensure_old_payment_datetime_column($conn);

$shiftOptions = [
    'morning' => 'Morning Shift (6:00 AM - 12:00 PM)',
    'afternoon' => 'Afternoon Shift (12:01 PM - 5:00 PM)',
    'whole_day' => 'Whole Day',
];
$selectedDate = trim($_GET['log_date'] ?? date('Y-m-d'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate)) $selectedDate = date('Y-m-d');
$selectedShift = trim($_GET['shift'] ?? 'whole_day');
if (!isset($shiftOptions[$selectedShift])) $selectedShift = current_shift_key();

$saveMessage = '';
$errorMessage = '';
$finalizeMessage = '';
$existingNote = [
    'note_text' => '',
    'prepared_by' => $username,
    'reviewed_by' => '',
    'opening_cash' => 0.0,
    'deposited_amount' => 0.0,
    'turnover_amount' => 0.0,
    'cash_deduction' => 0.0,
    'actual_cash_on_hand' => 0.0,
    'correction_note' => '',
    'is_finalized' => 0,
    'finalized_by' => '',
    'finalized_at' => null,
];
$existingNote = load_logbook_note($conn, $selectedDate, $selectedShift, $existingNote);

$isFinalized = (int) ($existingNote['is_finalized'] ?? 0) === 1;
$canFinalizeLogbook = $canEditLogbook;
$canReopenLogbook = ($role === 'Super Administrator');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_logbook_note'])) {
    if (!$canEditLogbook) {
        $errorMessage = 'Wala kang permission para mag-save ng logbook notes.';
    } elseif ($isFinalized) {
        $errorMessage = 'Finalized na ang logbook na ito. Hindi na puwedeng i-edit maliban kung i-reopen muna.';
    } elseif (!admin_csrf_validate($_POST['csrf_token'] ?? '')) {
        $errorMessage = 'Invalid CSRF token.';
    } else {
        $payload = logbook_form_payload($_POST, $selectedDate, $selectedShift, $username);
        $validationError = logbook_payload_error($payload, $shiftOptions);
        if ($validationError !== '') {
            $errorMessage = $validationError;
        } else {
            $selectedDate = $payload['log_date'];
            $selectedShift = $payload['shift_key'];
            $stmt = $conn->prepare("INSERT INTO logbook_shift_notes
                (log_date, shift_key, note_text, prepared_by, reviewed_by, opening_cash, deposited_amount, turnover_amount, cash_deduction, actual_cash_on_hand, correction_note)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                note_text = VALUES(note_text),
                prepared_by = VALUES(prepared_by),
                reviewed_by = VALUES(reviewed_by),
                opening_cash = VALUES(opening_cash),
                deposited_amount = VALUES(deposited_amount),
                turnover_amount = VALUES(turnover_amount),
                cash_deduction = VALUES(cash_deduction),
                actual_cash_on_hand = VALUES(actual_cash_on_hand),
                correction_note = VALUES(correction_note)");
            $stmt->bind_param(
                'sssssddddds',
                $selectedDate,
                $selectedShift,
                $payload['note_text'],
                $payload['prepared_by'],
                $payload['reviewed_by'],
                $payload['opening_cash'],
                $payload['deposited_amount'],
                $payload['turnover_amount'],
                $payload['cash_deduction'],
                $payload['actual_cash_on_hand'],
                $payload['correction_note']
            );
            if ($stmt->execute()) {
                $saveMessage = 'Logbook note and cash handling details saved successfully.';
                $auditDetails = "OpeningCash={$payload['opening_cash']}; Deposited={$payload['deposited_amount']}; Turnover={$payload['turnover_amount']}; CashDeduction={$payload['cash_deduction']}; ActualCash={$payload['actual_cash_on_hand']}; CorrectionNote={$payload['correction_note']}";
                logbook_audit($conn, $selectedDate, $selectedShift, 'save', $username, $auditDetails);
                logbook_audit_log(
                    $conn,
                    $username,
                    $role,
                    'Saved logbook details',
                    $selectedDate,
                    $selectedShift,
                    'Prepared By: ' . ($payload['prepared_by'] !== '' ? $payload['prepared_by'] : 'unknown')
                    . ' | Reviewed By: ' . ($payload['reviewed_by'] !== '' ? $payload['reviewed_by'] : 'None')
                    . ' | Opening Cash: ' . number_format((float) $payload['opening_cash'], 2)
                    . ' | Deposited: ' . number_format((float) $payload['deposited_amount'], 2)
                    . ' | Turnover: ' . number_format((float) $payload['turnover_amount'], 2)
                    . ' | Cash Deduction: ' . number_format((float) $payload['cash_deduction'], 2)
                    . ' | Actual Cash: ' . number_format((float) $payload['actual_cash_on_hand'], 2)
                );
            }
            else $errorMessage = 'Failed to save logbook details.';
            $stmt->close();
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['finalize_logbook'])) {
    if (!$canFinalizeLogbook) {
        $errorMessage = 'Wala kang permission para mag-finalize ng logbook.';
    } elseif (!admin_csrf_validate($_POST['csrf_token'] ?? '')) {
        $errorMessage = 'Invalid CSRF token.';
    } elseif ($isFinalized) {
        $errorMessage = 'Finalized na ang logbook na ito.';
    } else {
        $payload = logbook_form_payload($_POST, $selectedDate, $selectedShift, $username);
        $validationError = logbook_payload_error($payload, $shiftOptions);
        if ($validationError !== '') {
            $errorMessage = $validationError;
        } else {
            $selectedDate = $payload['log_date'];
            $selectedShift = $payload['shift_key'];
            $cashCollectedForFinalize = logbook_cash_collected($conn, $selectedDate, $selectedShift);
            $finalizeError = logbook_finalize_error($payload, $cashCollectedForFinalize);
            if ($finalizeError !== '') {
                $errorMessage = $finalizeError;
            } else {
                $expectedCashOnHand = logbook_remaining_cash($payload, $cashCollectedForFinalize);
                $variance = logbook_cash_variance($payload, $cashCollectedForFinalize);
                $stmt = $conn->prepare("INSERT INTO logbook_shift_notes
                    (log_date, shift_key, note_text, prepared_by, reviewed_by, opening_cash, deposited_amount, turnover_amount, cash_deduction, actual_cash_on_hand, correction_note, is_finalized, finalized_by, finalized_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, NOW())
                    ON DUPLICATE KEY UPDATE
                    note_text = VALUES(note_text),
                    prepared_by = VALUES(prepared_by),
                    reviewed_by = VALUES(reviewed_by),
                    opening_cash = VALUES(opening_cash),
                    deposited_amount = VALUES(deposited_amount),
                    turnover_amount = VALUES(turnover_amount),
                    cash_deduction = VALUES(cash_deduction),
                    actual_cash_on_hand = VALUES(actual_cash_on_hand),
                    correction_note = VALUES(correction_note),
                    is_finalized = 1,
                    finalized_by = VALUES(finalized_by),
                    finalized_at = NOW()");
                $finalizedBy = $username;
                $stmt->bind_param(
                    'sssssdddddss',
                    $selectedDate,
                    $selectedShift,
                    $payload['note_text'],
                    $payload['prepared_by'],
                    $payload['reviewed_by'],
                    $payload['opening_cash'],
                    $payload['deposited_amount'],
                    $payload['turnover_amount'],
                    $payload['cash_deduction'],
                    $payload['actual_cash_on_hand'],
                    $payload['correction_note'],
                    $finalizedBy
                );
                if ($stmt->execute()) {
                    $finalizeMessage = 'Logbook finalized successfully.';
                    $isFinalized = true;
                    $auditDetails = "OpeningCash={$payload['opening_cash']}; CashCollected={$cashCollectedForFinalize}; Deposited={$payload['deposited_amount']}; Turnover={$payload['turnover_amount']}; CashDeduction={$payload['cash_deduction']}; ExpectedCash={$expectedCashOnHand}; ActualCash={$payload['actual_cash_on_hand']}; Variance={$variance}; CorrectionNote={$payload['correction_note']}";
                    logbook_audit($conn, $selectedDate, $selectedShift, 'finalize', $username, $auditDetails);
                    logbook_audit_log(
                        $conn,
                        $username,
                        $role,
                        'Finalized logbook',
                        $selectedDate,
                        $selectedShift,
                        'Prepared By: ' . ($payload['prepared_by'] !== '' ? $payload['prepared_by'] : 'unknown')
                        . ' | Reviewed By: ' . ($payload['reviewed_by'] !== '' ? $payload['reviewed_by'] : 'None')
                        . ' | Cash Collected: ' . number_format($cashCollectedForFinalize, 2)
                        . ' | Expected Cash: ' . number_format($expectedCashOnHand, 2)
                        . ' | Actual Cash: ' . number_format((float) $payload['actual_cash_on_hand'], 2)
                        . ' | Variance: ' . number_format($variance, 2)
                    );
                } else {
                    $errorMessage = 'Failed to finalize logbook.';
                }
                $stmt->close();
            }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reopen_logbook'])) {
    if (!$canReopenLogbook) {
        $errorMessage = 'Super Administrator lang ang puwedeng mag-reopen ng finalized logbook.';
    } elseif (!admin_csrf_validate($_POST['csrf_token'] ?? '')) {
        $errorMessage = 'Invalid CSRF token.';
    } elseif (!$isFinalized) {
        $errorMessage = 'Draft pa ang logbook na ito.';
    } else {
        $reopenReason = trim($_POST['reopen_reason'] ?? '');
        if ($reopenReason === '') {
            $errorMessage = 'Required ang reopen reason bago i-reopen ang finalized logbook.';
        }
    }
    if ($errorMessage === '') {
        $stmt = $conn->prepare("UPDATE logbook_shift_notes
            SET is_finalized = 0, finalized_by = NULL, finalized_at = NULL
            WHERE log_date = ? AND shift_key = ?");
        $stmt->bind_param('ss', $selectedDate, $selectedShift);
        if ($stmt->execute()) {
            $finalizeMessage = 'Logbook reopened successfully.';
            $isFinalized = false;
            logbook_audit($conn, $selectedDate, $selectedShift, 'reopen', $username, 'ReopenReason=' . $reopenReason);
            logbook_audit_log(
                $conn,
                $username,
                $role,
                'Reopened finalized logbook',
                $selectedDate,
                $selectedShift,
                'Reopen Reason: ' . $reopenReason,
                'WARNING'
            );
        } else {
            $errorMessage = 'Failed to reopen logbook.';
        }
        $stmt->close();
    }
}

$existingNote = load_logbook_note($conn, $selectedDate, $selectedShift, $existingNote);
$isFinalized = (int) ($existingNote['is_finalized'] ?? 0) === 1;

$transactions = [];
$shiftClause = shift_filter_sql($selectedShift, 'p.date_paid');
$activeSql = "
SELECT p.date_paid AS occurred_at, p.booklet_no, p.receipt_no, p.amount, p.remarks, p.receipt_note,
       COALESCE(at.name, a.type, 'Uncategorized') AS fee_name,
       CONCAT(s.lastname, ', ', s.firstname, CASE WHEN TRIM(COALESCE(s.middlename, '')) <> '' THEN CONCAT(' ', s.middlename) ELSE '' END) AS payee_name,
       COALESCE(NULLIF(TRIM(s.grade), ''), '-') AS grade_level
FROM payments p
LEFT JOIN accounts a ON p.account_id = a.id
LEFT JOIN account_types at ON a.type = at.name
LEFT JOIN students s ON a.student_id = s.id
WHERE DATE(p.date_paid) = ? AND p.booklet_no IS NOT NULL AND p.receipt_no IS NOT NULL $shiftClause
ORDER BY p.date_paid ASC, p.id ASC";
$stmt = $conn->prepare($activeSql);
$stmt->bind_param('s', $selectedDate);
$stmt->execute();
$activeResult = $stmt->get_result();
while ($row = $activeResult->fetch_assoc()) {
    $transactions[] = [
        'source' => 'Active',
        'date_display' => date('n/j/Y', strtotime((string) $row['occurred_at'])),
        'time_display' => time_display((string) $row['occurred_at']),
        'payment_mode' => detect_payment_mode((string) ($row['receipt_note'] ?? ''), (string) ($row['remarks'] ?? '')),
        'reference_no' => extract_reference_number((string) ($row['remarks'] ?? ''), (string) ($row['receipt_note'] ?? '')),
        'booklet_no' => (int) $row['booklet_no'],
        'booklet_label' => booklet_label_from_stored((int) $row['booklet_no']),
        'receipt_no' => (string) $row['receipt_no'],
        'school_fee' => trim((string) ($row['fee_name'] ?? 'Uncategorized')) ?: 'Uncategorized',
        'payee' => trim((string) ($row['payee_name'] ?? 'Unknown Student')) ?: 'Unknown Student',
        'grade_level' => trim((string) ($row['grade_level'] ?? '-')) ?: '-',
        'amount' => (float) $row['amount'],
        'sort_at' => (string) $row['occurred_at'],
    ];
}
$stmt->close();

$oldRowsSkippedForShift = false;
if ($selectedShift === 'whole_day') {
    $oldSql = "
    SELECT p.paid_at, p.paid_at_datetime, p.booklet_no, p.receipt_no, p.amount, p.note, p.fee_type, s.notes AS student_notes,
           CONCAT(s.lastname, ', ', s.firstname, CASE WHEN TRIM(COALESCE(s.middlename, '')) <> '' THEN CONCAT(' ', s.middlename) ELSE '' END) AS payee_name
    FROM old_student_payments p
    LEFT JOIN old_students s ON p.old_student_id = s.id
    WHERE p.paid_at = ? AND p.booklet_no IS NOT NULL AND p.receipt_no IS NOT NULL AND (p.deleted_at IS NULL OR p.deleted_at = '')
    ORDER BY COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) ASC, p.id ASC";
    $stmt = $conn->prepare($oldSql);
    $stmt->bind_param('s', $selectedDate);
    $stmt->execute();
    $oldResult = $stmt->get_result();
    while ($row = $oldResult->fetch_assoc()) {
        $transactions[] = [
            'source' => 'Old',
            'date_display' => date('n/j/Y', strtotime((string) ($row['paid_at_datetime'] ?: $row['paid_at']))),
            'time_display' => !empty($row['paid_at_datetime']) ? time_display((string) $row['paid_at_datetime']) : 'No time',
            'payment_mode' => detect_payment_mode((string) ($row['note'] ?? '')),
            'reference_no' => extract_reference_number((string) ($row['note'] ?? '')),
            'booklet_no' => (int) $row['booklet_no'],
            'booklet_label' => booklet_label_from_stored((int) $row['booklet_no']),
            'receipt_no' => (string) $row['receipt_no'],
            'school_fee' => trim((string) ($row['fee_type'] ?? 'Uncategorized')) ?: 'Uncategorized',
            'payee' => trim((string) ($row['payee_name'] ?? 'Unknown Old Student')) ?: 'Unknown Old Student',
            'grade_level' => extract_old_grade((string) ($row['student_notes'] ?? '')),
            'amount' => (float) $row['amount'],
            'sort_at' => !empty($row['paid_at_datetime']) ? (string) $row['paid_at_datetime'] : ((string) $row['paid_at'] . ' 00:00:00'),
        ];
    }
    $stmt->close();
} else {
    $oldRowsSkippedForShift = true;
}

usort($transactions, static function (array $a, array $b): int {
    $timeA = (string) ($a['sort_at'] ?? ($a['date_display'] . ' ' . $a['time_display']));
    $timeB = (string) ($b['sort_at'] ?? ($b['date_display'] . ' ' . $b['time_display']));
    $comparison = strcmp($timeB, $timeA);
    if ($comparison !== 0) {
        return $comparison;
    }
    return strcmp((string) $b['receipt_no'], (string) $a['receipt_no']);
});

$groupedTransactions = [];
foreach ($transactions as $transaction) {
    $groupKeyParts = [
        (string) ($transaction['source'] ?? ''),
        (string) ($transaction['booklet_no'] ?? ''),
        (string) ($transaction['receipt_no'] ?? ''),
    ];
    $groupKey = implode('|', $groupKeyParts);
    if (!isset($groupedTransactions[$groupKey])) {
        $groupedTransactions[$groupKey] = $transaction;
        $groupedTransactions[$groupKey]['amount'] = 0.0;
        $groupedTransactions[$groupKey]['items'] = [];
        $groupedTransactions[$groupKey]['items_count'] = 0;
        $groupedTransactions[$groupKey]['sort_at'] = (string) ($transaction['sort_at'] ?? '');
    } else {
        $existingSort = (string) ($groupedTransactions[$groupKey]['sort_at'] ?? '');
        $incomingSort = (string) ($transaction['sort_at'] ?? '');
        if ($existingSort === '' || ($incomingSort !== '' && strcmp($incomingSort, $existingSort) < 0)) {
            $groupedTransactions[$groupKey]['sort_at'] = $incomingSort;
            $groupedTransactions[$groupKey]['date_display'] = $transaction['date_display'];
            $groupedTransactions[$groupKey]['time_display'] = $transaction['time_display'];
        }
    }
    $groupedTransactions[$groupKey]['amount'] += (float) $transaction['amount'];
    $groupedTransactions[$groupKey]['items'][] = [
        'fee' => (string) ($transaction['school_fee'] ?? 'Uncategorized'),
        'amount' => (float) $transaction['amount'],
    ];
    $groupedTransactions[$groupKey]['items_count']++;
}
$transactions = array_values($groupedTransactions);

usort($transactions, static function (array $a, array $b): int {
    $timeA = (string) ($a['sort_at'] ?? ($a['date_display'] . ' ' . $a['time_display']));
    $timeB = (string) ($b['sort_at'] ?? ($b['date_display'] . ' ' . $b['time_display']));
    $comparison = strcmp($timeB, $timeA);
    if ($comparison !== 0) {
        return $comparison;
    }
    return strcmp((string) $b['receipt_no'], (string) $a['receipt_no']);
});

$modeTotals = ['Cash' => ['amount' => 0.0, 'count' => 0], 'GCash' => ['amount' => 0.0, 'count' => 0], 'Bank Transfer' => ['amount' => 0.0, 'count' => 0]];
$grandTotal = 0.0;
foreach ($transactions as $transaction) {
    $mode = $transaction['payment_mode'];
    if (!isset($modeTotals[$mode])) $modeTotals[$mode] = ['amount' => 0.0, 'count' => 0];
    $modeTotals[$mode]['amount'] += $transaction['amount'];
    $modeTotals[$mode]['count']++;
    $grandTotal += $transaction['amount'];
}
$totalTransactions = count($transactions);
$cashCollected = (float) ($modeTotals['Cash']['amount'] ?? 0.0);
$openingCash = (float) $existingNote['opening_cash'];
$depositedAmount = (float) $existingNote['deposited_amount'];
$turnoverAmount = (float) $existingNote['turnover_amount'];
$cashDeduction = (float) $existingNote['cash_deduction'];
$actualCashOnHand = (float) $existingNote['actual_cash_on_hand'];
$remainingCashOnHand = $openingCash + $cashCollected - $depositedAmount - $turnoverAmount - $cashDeduction;
$shortageOverage = $actualCashOnHand - $remainingCashOnHand;
$finalizeWarnings = [];
if (!$isFinalized && $remainingCashOnHand < -0.009) {
    $finalizeWarnings[] = 'Finalize is blocked while remaining cash on hand is negative.';
}
if (!$isFinalized && abs($shortageOverage) > 0.009 && trim((string) ($existingNote['correction_note'] ?? '')) === '') {
    $finalizeWarnings[] = 'Add a correction note before finalizing a logbook with shortage or overage.';
}

$ownerShiftTotals = [
    'morning' => ['amount' => 0.0, 'count' => 0],
    'afternoon' => ['amount' => 0.0, 'count' => 0],
    'whole_day' => ['amount' => 0.0, 'count' => 0],
];
$ownerUniquePayees = [];
$legacyNoTimeCount = 0;

$activeWholeDaySql = "
SELECT p.date_paid AS occurred_at, p.amount,
       CONCAT(s.lastname, ', ', s.firstname, CASE WHEN TRIM(COALESCE(s.middlename, '')) <> '' THEN CONCAT(' ', s.middlename) ELSE '' END) AS payee_name
FROM payments p
LEFT JOIN accounts a ON p.account_id = a.id
LEFT JOIN students s ON a.student_id = s.id
WHERE DATE(p.date_paid) = ? AND p.booklet_no IS NOT NULL AND p.receipt_no IS NOT NULL";
$stmt = $conn->prepare($activeWholeDaySql);
$stmt->bind_param('s', $selectedDate);
$stmt->execute();
$activeWholeDayResult = $stmt->get_result();
while ($row = $activeWholeDayResult->fetch_assoc()) {
    $shiftKey = classify_shift_from_datetime((string) $row['occurred_at']);
    if (isset($ownerShiftTotals[$shiftKey])) {
        $ownerShiftTotals[$shiftKey]['amount'] += (float) $row['amount'];
        $ownerShiftTotals[$shiftKey]['count']++;
    }
    $ownerShiftTotals['whole_day']['amount'] += (float) $row['amount'];
    $ownerShiftTotals['whole_day']['count']++;
    $ownerUniquePayees[trim((string) ($row['payee_name'] ?? ''))] = true;
}
$stmt->close();

$oldWholeDaySql = "
SELECT p.paid_at, p.paid_at_datetime, p.amount,
       CONCAT(s.lastname, ', ', s.firstname, CASE WHEN TRIM(COALESCE(s.middlename, '')) <> '' THEN CONCAT(' ', s.middlename) ELSE '' END) AS payee_name
FROM old_student_payments p
LEFT JOIN old_students s ON p.old_student_id = s.id
WHERE p.paid_at = ? AND p.booklet_no IS NOT NULL AND p.receipt_no IS NOT NULL AND (p.deleted_at IS NULL OR p.deleted_at = '')";
$stmt = $conn->prepare($oldWholeDaySql);
$stmt->bind_param('s', $selectedDate);
$stmt->execute();
$oldWholeDayResult = $stmt->get_result();
while ($row = $oldWholeDayResult->fetch_assoc()) {
    $dateTimeValue = !empty($row['paid_at_datetime']) ? (string) $row['paid_at_datetime'] : null;
    $shiftKey = classify_shift_from_datetime($dateTimeValue);
    if ($dateTimeValue === null) {
        $legacyNoTimeCount++;
    } elseif (isset($ownerShiftTotals[$shiftKey])) {
        $ownerShiftTotals[$shiftKey]['amount'] += (float) $row['amount'];
        $ownerShiftTotals[$shiftKey]['count']++;
    }
    $ownerShiftTotals['whole_day']['amount'] += (float) $row['amount'];
    $ownerShiftTotals['whole_day']['count']++;
    $ownerUniquePayees[trim((string) ($row['payee_name'] ?? ''))] = true;
}
$stmt->close();

$ownerUniquePayeeCount = count(array_filter(array_keys($ownerUniquePayees), static fn($name) => $name !== ''));
$averagePayment = $ownerShiftTotals['whole_day']['count'] > 0 ? ($ownerShiftTotals['whole_day']['amount'] / $ownerShiftTotals['whole_day']['count']) : 0.0;
$reviewFlags = [];
if (!$isFinalized) {
    $reviewFlags[] = ['label' => 'Draft Logbook', 'class' => 'flag-review'];
}
if (abs($shortageOverage) > 0.009) {
    $reviewFlags[] = ['label' => ($shortageOverage < 0 ? 'Cash Shortage' : 'Cash Overage'), 'class' => 'flag-danger'];
}
if ($legacyNoTimeCount > 0) {
    $reviewFlags[] = ['label' => $legacyNoTimeCount . ' Legacy Old Record(s)', 'class' => 'flag-muted'];
}
if ($selectedShift !== 'whole_day') {
    $reviewFlags[] = ['label' => ucfirst($selectedShift) . ' Shift View', 'class' => 'flag-info'];
}
if (trim((string) $existingNote['reviewed_by']) === '') {
    $reviewFlags[] = ['label' => 'Needs Reviewer Name', 'class' => 'flag-review'];
}

$auditEntries = [];
$stmt = $conn->prepare('SELECT action_type, action_details, changed_by, created_at FROM logbook_audit_trail WHERE log_date = ? AND shift_key = ? ORDER BY created_at DESC, id DESC LIMIT 12');
$stmt->bind_param('ss', $selectedDate, $selectedShift);
$stmt->execute();
$auditResult = $stmt->get_result();
while ($row = $auditResult->fetch_assoc()) {
    $auditEntries[] = $row;
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Logbook | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <?php ui_css_link(); ?>
    <style>
        :root {
            --page-bg: #eef4fb;
            --surface: #ffffff;
            --surface-soft: #f7fafc;
            --line: #dbe6f0;
            --ink: #223248;
            --muted: #6d7c8c;
            --cash: #2f7d5a;
            --gcash: #2463a6;
            --bank: #9a6a19;
            --turnover: #6f5aa7;
            --danger: #b42318;
            --navbar-bg: #23395d;
        }
        body {
            background: linear-gradient(180deg, #f8fbff 0%, var(--page-bg) 100%);
            color: var(--ink);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        }
        body.dark-mode {
            --page-bg: #1b232d;
            --surface: #233140;
            --surface-soft: #1f2a37;
            --line: #33465a;
            --ink: #e6edf3;
            --muted: #b2bfcc;
            --navbar-bg: #161b22;
        }
        .navbar { background:var(--navbar-bg)!important; box-shadow:0 2px 12px rgba(33,57,93,.08); }
        .navbar-brand,.navbar-nav .nav-link { color:#fff!important; }
        .theme-toggle-btn { background:none; border:none; color:#fff; cursor:pointer; font-size:1.45em; margin-left:12px; }
        .dashboard-header { margin:28px auto 12px; text-align:center; }
        .dashboard-header img { height:70px; margin-bottom:8px; object-fit:contain; width:70px; }
        .dashboard-header h1 { color:var(--ink); font-size:1.25rem; font-weight:850; letter-spacing:0; margin-bottom:.25rem; }
        .dashboard-header p,.note-help,.summary-card .meta,.summary-card .label,.footer-note { color:var(--muted); }
        .logbook-shell { max-width:1320px; }
        .filter-card,.summary-card,.table-card,.note-card,.cash-block,.audit-block,.owner-block {
            background:var(--surface);
            border:1px solid var(--line);
            border-radius:8px;
            box-shadow:0 14px 30px rgba(34,50,72,.07);
        }
        .filter-card,.table-card,.note-card,.cash-block,.audit-block,.owner-block { padding:18px; }
        .filter-card { overflow:hidden; position:relative; }
        .filter-card::before { background:linear-gradient(90deg,var(--cash),var(--gcash),var(--bank)); content:""; height:3px; left:0; position:absolute; right:0; top:0; }
        .filter-card .form-label,.note-card .form-label { color:var(--ink); font-size:.8rem; font-weight:850!important; margin-bottom:5px; }
        .filter-card .form-control,.filter-card .form-select,.note-card .form-control,.note-card .form-select,.note-card textarea { border-color:var(--line); border-radius:8px; min-height:42px; }
        .filter-card .btn,.note-card .btn { border-radius:8px; font-weight:800; min-height:40px; }
        .summary-card { height:100%; overflow:hidden; padding:15px 16px; position:relative; }
        .summary-card::before { background:var(--gcash); content:""; height:3px; left:0; position:absolute; right:0; top:0; }
        .cash-card::before { background:var(--cash); }
        .gcash-card::before { background:var(--gcash); }
        .bank-card::before { background:var(--bank); }
        .turnover-card::before { background:var(--turnover); }
        .summary-card .label { font-size:.74rem; font-weight:850; letter-spacing:.05em; text-transform:uppercase; }
        .summary-card .value { color:var(--ink); font-size:clamp(1.12rem,1.45vw,1.42rem); font-weight:900; letter-spacing:0; margin-top:.18rem; }
        .cash-card .value { color:var(--cash); } .gcash-card .value { color:var(--gcash); } .bank-card .value { color:var(--bank); } .turnover-card .value { color:var(--turnover); }
        .remaining-negative .value,.variance-short .value { color:var(--danger); }
        .variance-over .value { color:var(--cash); }
        .owner-block { background:var(--surface); }
        .mini-summary { background:var(--surface-soft); border:1px solid var(--line); border-radius:8px; height:100%; padding:.95rem 1rem; }
        .mini-summary .label { color:var(--muted); font-size:.76rem; font-weight:850; letter-spacing:.05em; text-transform:uppercase; }
        .mini-summary .value { color:var(--ink); font-size:1.26rem; font-weight:900; letter-spacing:0; margin-top:.15rem; }
        .flag-wrap { display:flex; flex-wrap:wrap; gap:.55rem; }
        .review-flag { align-items:center; border:1px solid transparent; border-radius:999px; display:inline-flex; font-size:.84rem; font-weight:800; gap:.45rem; padding:.42rem .78rem; }
        .flag-danger { background:rgba(180,35,24,.08); border-color:rgba(180,35,24,.18); color:var(--danger); }
        .flag-review { background:rgba(154,106,25,.1); border-color:rgba(154,106,25,.2); color:#7a5416; }
        .flag-info { background:rgba(36,99,166,.09); border-color:rgba(36,99,166,.18); color:var(--gcash); }
        .flag-muted { background:var(--surface-soft); border-color:var(--line); color:var(--ink); }
        .section-title { color:var(--ink); font-size:1.02rem; font-weight:900; letter-spacing:0; margin-bottom:1rem; }
        .mode-badge,.booklet-badge { border:1px solid transparent; border-radius:999px; display:inline-block; font-size:.78rem; font-weight:850; padding:.34rem .62rem; white-space:nowrap; }
        .mode-cash { background:rgba(47,125,90,.11); border-color:rgba(47,125,90,.2); color:var(--cash); }
        .mode-gcash { background:rgba(36,99,166,.1); border-color:rgba(36,99,166,.2); color:var(--gcash); }
        .mode-bank { background:rgba(154,106,25,.11); border-color:rgba(154,106,25,.2); color:var(--bank); }
        .booklet-badge { background:var(--surface-soft); border-color:var(--line); color:var(--ink); }
        .formula-box { background:var(--surface-soft); border:1px solid var(--line); border-radius:8px; color:var(--ink); font-size:.92rem; padding:.9rem 1rem; }
        .audit-item { background:var(--surface-soft); border:1px solid var(--line); border-left:3px solid var(--gcash); border-radius:8px; margin-bottom:.65rem; padding:.72rem .85rem; }
        .audit-scroll { max-height:430px; overflow-y:auto; padding-right:.35rem; }
        .transaction-scroll { max-height:760px; overflow:auto; }
        .transaction-scroll table { min-width:1180px; }
        .transaction-scroll thead th { background:#f3f7fb; color:#526477; font-size:.74rem; font-weight:900; letter-spacing:.04em; position:sticky; text-transform:uppercase; top:0; white-space:nowrap; z-index:1; }
        .table td,.table th { border-color:#e7eef6; vertical-align:middle; }
        .table-striped>tbody>tr:nth-of-type(odd)>* { --bs-table-bg-type:#fbfdff; }
        .table-hover tbody tr:hover td { background-color:#f7fbff; }
        .row-mode td { border-left:3px solid transparent; }
        .row-cash td { border-left-color:var(--cash); }
        .row-gcash td { border-left-color:var(--gcash); }
        .row-bank td { border-left-color:var(--bank); }
        .status-pill { align-items:center; border:1px solid transparent; border-radius:999px; display:inline-flex; font-size:.88rem; font-weight:850; gap:.45rem; padding:.42rem .78rem; }
        .status-draft { background:rgba(154,106,25,.1); border-color:rgba(154,106,25,.2); color:#7a5416; }
        .status-finalized { background:rgba(47,125,90,.12); border-color:rgba(47,125,90,.22); color:var(--cash); }
        .signature-box { border-top:1px solid var(--line); margin-top:1.5rem; padding-top:1.2rem; }
        .signature-line { border-top:1px solid #778595; color:var(--muted); font-size:.92rem; margin-top:2.5rem; padding-top:.35rem; text-align:center; }
        .print-summary { background:var(--surface-soft); border:1px solid var(--line); border-radius:8px; padding:1rem; }
        .collapse-toggle { align-items:center; background:transparent; border:0; display:flex; gap:1rem; padding:0; text-align:left; width:100%; }
        .collapse-toggle:focus { outline:none; }
        .toggle-icon { color:var(--muted); transition:transform .2s ease; }
        .collapse-toggle[aria-expanded="true"] .toggle-icon { transform:rotate(180deg); }
        .quick-jump { align-items:center; background:var(--surface-soft); border:1px solid var(--line); border-radius:8px; display:flex; flex-wrap:wrap; gap:.55rem; padding:.68rem .75rem; }
        .quick-jump-label { color:var(--ink); font-size:.84rem; font-weight:850; }
        .quick-jump-spacer { flex:1 1 auto; min-width:20px; }
        .quick-jump-btn { background:var(--surface); border:1px solid var(--line); border-radius:999px; color:var(--ink); font-size:.84rem; font-weight:800; padding:.32rem .68rem; transition:all .15s ease; }
        .quick-jump-btn:hover { background:#edf5ff; border-color:#c9ddf2; color:var(--gcash); }
        .quick-jump-btn.quick-jump-alt { background:#eef4fb; border-color:#d2e2f6; }
        .section-divider { display:none; }
        .note-help { font-size:.88rem; line-height:1.5; }
        .footer-note { color:var(--muted); }
        @media (max-width:768px) {
            .filter-card,.table-card,.note-card,.cash-block,.audit-block,.owner-block { padding:14px; }
            .transaction-scroll table { min-width:1080px; }
        }
        @media print {
            .navbar,.filter-card .btn,.theme-toggle-btn,.alert,.footer-note,.quick-jump { display:none!important; }
            body { background:#fff; }
            .filter-card,.summary-card,.table-card,.note-card,.cash-block { box-shadow:none!important; border:1px solid #d8dde5; }
            .filter-card { padding-bottom:.5rem; }
        }
    </style>
</head>
<body>
<?php render_admin_nav('logbook', true); ?>

<?php render_school_page_header($schoolName, '/school-admin-dashboard/uploads/logo1.png', 'Daily cashier logbook with shift totals, turnover notes, and cash-on-hand tracking.', 'dashboard-header', 'rounded shadow-sm'); ?>

<div class="container logbook-shell pb-5">
    <div class="filter-card mb-4">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
            <div>
                <div class="section-title mb-1"><i class="fas fa-book me-2"></i>Daily Cashier Logbook</div>
                <div class="note-help">Operational view for shift collections, cash movement, and owner review.</div>
            </div>
            <div class="d-flex flex-wrap gap-2">
                <a href="/school-admin-dashboard/modules/logbook/export-logbook.php?log_date=<?= urlencode($selectedDate) ?>&shift=<?= urlencode($selectedShift) ?>" class="btn btn-outline-success">
                    <i class="fas fa-file-excel me-1"></i> Export Excel
                </a>
                <button type="button" class="btn btn-outline-secondary" onclick="window.print()"><i class="fas fa-print me-1"></i> Print / Save PDF</button>
            </div>
        </div>
        <form method="get" class="row g-3 align-items-end">
            <div class="col-md-4"><label class="form-label fw-semibold">Date</label><input type="date" name="log_date" class="form-control" value="<?= h($selectedDate) ?>"></div>
            <div class="col-md-5"><label class="form-label fw-semibold">Shift</label><select name="shift" class="form-select"><?php foreach ($shiftOptions as $shiftKey => $shiftLabel): ?><option value="<?= h($shiftKey) ?>" <?= $selectedShift === $shiftKey ? 'selected' : '' ?>><?= h($shiftLabel) ?></option><?php endforeach; ?></select></div>
            <div class="col-md-3 d-grid"><button type="submit" class="btn btn-primary"><i class="fas fa-filter me-1"></i> Apply Filter</button></div>
        </form>
        <div class="quick-jump mt-3">
            <span class="quick-jump-label">Quick Jump:</span>
            <button type="button" class="quick-jump-btn" data-target="#ownerSummarySection">Owner Summary</button>
            <button type="button" class="quick-jump-btn" data-target="#cashHandlingSection">Cash Handling</button>
            <button type="button" class="quick-jump-btn" data-target="#transactionLogSection">Transaction Log</button>
            <button type="button" class="quick-jump-btn" data-target="#shiftNoteSection">Shift Notes</button>
            <button type="button" class="quick-jump-btn" data-target="#auditHistorySection">Audit History</button>
            <span class="quick-jump-spacer"></span>
            <button type="button" class="quick-jump-btn quick-jump-alt" id="expandAllBtn">Expand All</button>
            <button type="button" class="quick-jump-btn quick-jump-alt" id="collapseAllBtn">Collapse All</button>
        </div>
        <?php if ($oldRowsSkippedForShift): ?><div class="alert alert-warning mt-3 mb-0">Some older old-account payments for this date may not appear in Morning/Afternoon because those older records were saved without an exact time. They will still appear in <strong>Whole Day</strong> view.</div><?php endif; ?>
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mt-3">
            <div class="status-pill <?= $isFinalized ? 'status-finalized' : 'status-draft' ?>">
                <i class="fas <?= $isFinalized ? 'fa-lock' : 'fa-pen-to-square' ?>"></i>
                <?= $isFinalized ? 'Finalized' : 'Draft' ?>
            </div>
            <div class="small text-muted text-end">
                <?php if ($isFinalized && !empty($existingNote['finalized_at'])): ?>
                    Finalized by <strong><?= h($existingNote['finalized_by']) ?></strong> on <?= h(date('n/j/Y g:i A', strtotime((string) $existingNote['finalized_at']))) ?>
                <?php else: ?>
                    Draft logbooks can still be updated and reviewed.
                <?php endif; ?>
            </div>
        </div>
        <div class="print-summary mt-3">
            <div class="row g-2">
                <div class="col-md-3"><strong>Date:</strong> <?= h(date('F j, Y', strtotime($selectedDate))) ?></div>
                <div class="col-md-3"><strong>Shift:</strong> <?= h($shiftOptions[$selectedShift] ?? $selectedShift) ?></div>
                <div class="col-md-3"><strong>Status:</strong> <?= $isFinalized ? 'Finalized' : 'Draft' ?></div>
                <div class="col-md-3"><strong>Total Transactions:</strong> <?= (int) $totalTransactions ?></div>
            </div>
        </div>
        </div>
    </div>

    <div class="owner-block mb-4">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3 collapse-toggle" role="button" data-bs-toggle="collapse" data-bs-target="#ownerSummarySection" aria-expanded="false" aria-controls="ownerSummarySection">
            <div>
                <div class="section-title mb-1"><i class="fas fa-chart-line me-2"></i>Owner Summary</div>
                <div class="note-help">Quick daily snapshot so one look shows today’s collections, coverage, and review flags.</div>
            </div>
            <div class="small text-muted text-end">
                Handled by <strong><?= h($existingNote['prepared_by'] ?: $username) ?></strong><br>
                <?= $isFinalized ? 'Ready for owner review' : 'Still open for shift updates' ?>
            </div>
            <i class="fas fa-chevron-down toggle-icon ms-3"></i>
        </div>
        <div id="ownerSummarySection" class="collapse mt-3">
        <div class="row g-3 mb-3">
            <div class="col-md-3"><div class="mini-summary"><div class="label">Morning Total</div><div class="value"><?= money_format((float) $ownerShiftTotals['morning']['amount']) ?></div><div class="meta"><?= (int) $ownerShiftTotals['morning']['count'] ?> transaction(s)</div></div></div>
            <div class="col-md-3"><div class="mini-summary"><div class="label">Afternoon Total</div><div class="value"><?= money_format((float) $ownerShiftTotals['afternoon']['amount']) ?></div><div class="meta"><?= (int) $ownerShiftTotals['afternoon']['count'] ?> transaction(s)</div></div></div>
            <div class="col-md-3"><div class="mini-summary"><div class="label">Whole Day Total</div><div class="value"><?= money_format((float) $ownerShiftTotals['whole_day']['amount']) ?></div><div class="meta"><?= (int) $ownerShiftTotals['whole_day']['count'] ?> transaction(s)</div></div></div>
            <div class="col-md-3"><div class="mini-summary"><div class="label">Unique Payees</div><div class="value"><?= (int) $ownerUniquePayeeCount ?></div><div class="meta">Avg payment <?= money_format($averagePayment) ?></div></div></div>
        </div>
        <div class="section-title mb-2" style="font-size:.98rem;">Key Review Flags</div>
        <div class="flag-wrap">
            <?php if (empty($reviewFlags)): ?>
                <span class="review-flag flag-info"><i class="fas fa-circle-check"></i> No immediate review flags</span>
            <?php else: ?>
                <?php foreach ($reviewFlags as $flag): ?>
                    <span class="review-flag <?= h($flag['class']) ?>"><i class="fas fa-flag"></i> <?= h($flag['label']) ?></span>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        </div>
    </div>

    <div class="section-divider"></div>

    <div class="row g-3 mb-4">
        <div class="col-md-3"><div class="summary-card cash-card"><div class="label">Cash Total</div><div class="value"><?= money_format((float) ($modeTotals['Cash']['amount'] ?? 0)) ?></div><div class="meta"><?= (int) ($modeTotals['Cash']['count'] ?? 0) ?> transaction(s)</div></div></div>
        <div class="col-md-3"><div class="summary-card gcash-card"><div class="label">GCash Total</div><div class="value"><?= money_format((float) ($modeTotals['GCash']['amount'] ?? 0)) ?></div><div class="meta"><?= (int) ($modeTotals['GCash']['count'] ?? 0) ?> transaction(s)</div></div></div>
        <div class="col-md-3"><div class="summary-card bank-card"><div class="label">Bank Transfer</div><div class="value"><?= money_format((float) ($modeTotals['Bank Transfer']['amount'] ?? 0)) ?></div><div class="meta"><?= (int) ($modeTotals['Bank Transfer']['count'] ?? 0) ?> transaction(s)</div></div></div>
        <div class="col-md-3"><div class="summary-card"><div class="label">Grand Total</div><div class="value"><?= money_format($grandTotal) ?></div><div class="meta"><?= $totalTransactions ?> total transaction(s)</div></div></div>
    </div>

    <div class="section-divider"></div>

    <div class="cash-block mb-4">
        <div class="section-title collapse-toggle" role="button" data-bs-toggle="collapse" data-bs-target="#cashHandlingSection" aria-expanded="false" aria-controls="cashHandlingSection">
            <i class="fas fa-money-bill-transfer me-2"></i>Cash Handling Summary
            <i class="fas fa-chevron-down toggle-icon ms-auto"></i>
        </div>
        <div id="cashHandlingSection" class="collapse mt-3">
        <div class="row g-3 mb-3">
            <div class="col-md-3"><div class="summary-card"><div class="label">Opening Cash</div><div class="value"><?= money_format($openingCash) ?></div><div class="meta">Beginning cash for this shift</div></div></div>
            <div class="col-md-3"><div class="summary-card"><div class="label">Deposited</div><div class="value"><?= money_format($depositedAmount) ?></div><div class="meta">Cash deposited during shift</div></div></div>
            <div class="col-md-3"><div class="summary-card turnover-card"><div class="label">Turnover</div><div class="value"><?= money_format($turnoverAmount) ?></div><div class="meta">Cash endorsed to next shift</div></div></div>
            <div class="col-md-3"><div class="summary-card <?= $remainingCashOnHand < 0 ? 'remaining-negative' : '' ?>"><div class="label">Remaining Cash On Hand</div><div class="value"><?= money_format($remainingCashOnHand) ?></div><div class="meta">After deposits, turnover, and deductions</div></div></div>
        </div>
        <div class="row g-3 mb-3">
            <div class="col-md-6"><div class="summary-card"><div class="label">Actual Cash On Hand</div><div class="value"><?= money_format($actualCashOnHand) ?></div><div class="meta">Manual actual cash count for this shift</div></div></div>
            <div class="col-md-6"><div class="summary-card <?= $shortageOverage < 0 ? 'variance-short' : 'variance-over' ?>"><div class="label">Shortage / Overage</div><div class="value"><?= money_format($shortageOverage) ?></div><div class="meta"><?= $shortageOverage < 0 ? 'Negative means shortage' : 'Positive means overage' ?></div></div></div>
        </div>
        <div class="formula-box"><strong>Formula:</strong> Opening Cash + Cash Collected - Deposited - Turnover - Cash Deduction = Remaining Cash On Hand<br><span class="text-muted">Current computation:</span> <?= money_format($openingCash) ?> + <?= money_format($cashCollected) ?> - <?= money_format($depositedAmount) ?> - <?= money_format($turnoverAmount) ?> - <?= money_format($cashDeduction) ?> = <strong><?= money_format($remainingCashOnHand) ?></strong></div>
        <?php if ($remainingCashOnHand < 0): ?><div class="alert alert-danger mt-3 mb-0">Remaining cash on hand is negative. Please review the opening cash, deposits, turnover, or deduction values.</div><?php endif; ?>
        </div>
    </div>

    <div class="section-divider"></div>

    <div class="table-card mb-4">
        <div class="section-title collapse-toggle" role="button" data-bs-toggle="collapse" data-bs-target="#transactionLogSection" aria-expanded="true" aria-controls="transactionLogSection">
            <i class="fas fa-list me-2"></i>Transaction Log (<?= (int) $totalTransactions ?>)
            <i class="fas fa-chevron-down toggle-icon ms-auto"></i>
        </div>
        <div id="transactionLogSection" class="collapse show mt-3">
        <div class="table-responsive transaction-scroll">
            <table class="table table-hover table-striped align-middle">
                <thead class="table-light">
                    <tr><th>Date</th><th>Time</th><th>Payment</th><th>Reference No</th><th>Booklet No</th><th>Receipt No</th><th>School Fee</th><th>Payee</th><th>Grade Level</th><th class="text-end">Amount</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($transactions)): ?>
                        <tr><td colspan="10" class="text-center text-muted py-4">No transactions found for the selected date and shift.</td></tr>
                    <?php else: ?>
                        <?php $rowIndex = 0; ?>
                        <?php foreach ($transactions as $transaction): ?>
                            <?php $modeClass = $transaction['payment_mode'] === 'GCash' ? 'mode-gcash' : ($transaction['payment_mode'] === 'Bank Transfer' ? 'mode-bank' : 'mode-cash'); ?>
                            <?php $rowIndex++; ?>
                            <?php $collapseId = 'logbook-breakdown-' . $rowIndex; ?>
                            <tr class="row-mode <?= h($transaction['payment_mode'] === 'GCash' ? 'row-gcash' : ($transaction['payment_mode'] === 'Bank Transfer' ? 'row-bank' : 'row-cash')) ?>">
                                <td><?= h($transaction['date_display']) ?></td>
                                <td><?= h($transaction['time_display']) ?></td>
                                <td><span class="mode-badge <?= h($modeClass) ?>"><?= h($transaction['payment_mode']) ?></span></td>
                                <td><?= h($transaction['reference_no']) ?></td>
                                <td><span class="booklet-badge"><?= h($transaction['booklet_label']) ?></span></td>
                                <td><?= h($transaction['receipt_no']) ?></td>
                                <td>
                                    <?php if (($transaction['items_count'] ?? 0) > 1): ?>
                                        <div class="d-flex align-items-center justify-content-between gap-2">
                                            <span><?= h($transaction['items_count']) ?> items</span>
                                            <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="collapse" data-bs-target="#<?= h($collapseId) ?>" aria-expanded="false" aria-controls="<?= h($collapseId) ?>">
                                                View breakdown
                                            </button>
                                        </div>
                                    <?php else: ?>
                                        <?= h($transaction['school_fee']) ?>
                                    <?php endif; ?>
                                </td>
                                <td><?= h($transaction['payee']) ?><div class="small text-muted"><?= h($transaction['source']) ?> record</div></td>
                                <td><?= h($transaction['grade_level']) ?></td>
                                <td class="text-end fw-semibold"><?= money_format((float) $transaction['amount']) ?></td>
                            </tr>
                            <?php if (($transaction['items_count'] ?? 0) > 1): ?>
                                <tr class="collapse" id="<?= h($collapseId) ?>">
                                    <td colspan="10" class="bg-light">
                                        <div class="p-2">
                                            <div class="fw-semibold mb-2">Receipt Breakdown</div>
                                            <div class="table-responsive">
                                                <table class="table table-sm mb-0">
                                                    <thead>
                                                        <tr><th>Fee Type</th><th class="text-end">Amount</th></tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach (($transaction['items'] ?? []) as $item): ?>
                                                            <tr>
                                                                <td><?= h($item['fee'] ?? 'Uncategorized') ?></td>
                                                                <td class="text-end"><?= money_format((float) ($item['amount'] ?? 0)) ?></td>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        </div>
    </div>

    <div class="section-divider"></div>

    <div class="note-card">
        <div class="section-title collapse-toggle" role="button" data-bs-toggle="collapse" data-bs-target="#shiftNoteSection" aria-expanded="false" aria-controls="shiftNoteSection">
            <i class="fas fa-note-sticky me-2"></i>Shift Note And Cash Controls
            <i class="fas fa-chevron-down toggle-icon ms-auto"></i>
        </div>
        <div id="shiftNoteSection" class="collapse mt-3">
        <p class="note-help">Use this section for deposits, turnover notes, cash reductions, and any shift-level remarks you want saved with the logbook.</p>
        <?php if ($saveMessage !== ''): ?><div class="alert alert-success"><?= h($saveMessage) ?></div><?php endif; ?>
        <?php if ($finalizeMessage !== ''): ?><div class="alert alert-success"><?= h($finalizeMessage) ?></div><?php endif; ?>
        <?php if ($errorMessage !== ''): ?><div class="alert alert-danger"><?= h($errorMessage) ?></div><?php endif; ?>
        <form method="post" class="row g-3">
            <input type="hidden" name="csrf_token" value="<?= h(admin_csrf_token()) ?>">
            <input type="hidden" name="log_date" value="<?= h($selectedDate) ?>">
            <input type="hidden" name="shift" value="<?= h($selectedShift) ?>">
            <div class="col-md-6"><label class="form-label fw-semibold">Prepared By</label><input type="text" name="prepared_by" class="form-control" value="<?= h($existingNote['prepared_by']) ?>" <?= ($canEditLogbook && !$isFinalized) ? '' : 'readonly' ?>></div>
            <div class="col-md-6"><label class="form-label fw-semibold">Reviewed By</label><input type="text" name="reviewed_by" class="form-control" value="<?= h($existingNote['reviewed_by']) ?>" <?= ($canEditLogbook && !$isFinalized) ? '' : 'readonly' ?>></div>
            <div class="col-md-3"><label class="form-label fw-semibold">Opening Cash</label><input type="number" min="0" step="0.01" name="opening_cash" class="form-control" value="<?= h(number_format($openingCash, 2, '.', '')) ?>" <?= ($canEditLogbook && !$isFinalized) ? '' : 'readonly' ?>></div>
            <div class="col-md-3"><label class="form-label fw-semibold">Deposited Amount</label><input type="number" min="0" step="0.01" name="deposited_amount" class="form-control" value="<?= h(number_format($depositedAmount, 2, '.', '')) ?>" <?= ($canEditLogbook && !$isFinalized) ? '' : 'readonly' ?>></div>
            <div class="col-md-3"><label class="form-label fw-semibold">Turnover Amount</label><input type="number" min="0" step="0.01" name="turnover_amount" class="form-control" value="<?= h(number_format($turnoverAmount, 2, '.', '')) ?>" <?= ($canEditLogbook && !$isFinalized) ? '' : 'readonly' ?>></div>
            <div class="col-md-3"><label class="form-label fw-semibold">Cash Deduction</label><input type="number" min="0" step="0.01" name="cash_deduction" class="form-control" value="<?= h(number_format($cashDeduction, 2, '.', '')) ?>" <?= ($canEditLogbook && !$isFinalized) ? '' : 'readonly' ?>></div>
            <div class="col-md-6"><label class="form-label fw-semibold">Actual Cash On Hand</label><input type="number" min="0" step="0.01" name="actual_cash_on_hand" class="form-control" value="<?= h(number_format($actualCashOnHand, 2, '.', '')) ?>" <?= ($canEditLogbook && !$isFinalized) ? '' : 'readonly' ?>><div class="form-text">Enter the actual counted cash to compute shortage or overage.</div></div>
            <div class="col-md-6"><label class="form-label fw-semibold">Correction Note</label><input type="text" name="correction_note" class="form-control" value="<?= h($existingNote['correction_note']) ?>" <?= ($canEditLogbook && !$isFinalized) ? '' : 'readonly' ?>><div class="form-text">Use this for explanations of variance, corrections, or adjustments.</div></div>
            <div class="col-12"><label class="form-label fw-semibold">Notes</label><textarea name="note_text" rows="5" class="form-control" <?= ($canEditLogbook && !$isFinalized) ? '' : 'readonly' ?>><?= h($existingNote['note_text']) ?></textarea><div class="form-text">Example: Morning cash deposited to bank, remaining petty cash retained, or turnover remarks for the next cashier.</div></div>
            <?php if ($finalizeWarnings): ?><div class="col-12"><div class="alert alert-warning mb-0"><?= h(implode(' ', $finalizeWarnings)) ?></div></div><?php endif; ?>
            <?php if ($canEditLogbook && !$isFinalized): ?><div class="col-12 d-flex justify-content-between flex-wrap gap-2"><div class="d-flex gap-2 flex-wrap"><button type="submit" name="save_logbook_note" class="btn btn-success"><i class="fas fa-save me-1"></i> Save Logbook Details</button><button type="submit" name="finalize_logbook" class="btn btn-dark"><i class="fas fa-lock me-1"></i> Finalize Logbook</button></div><a href="/school-admin-dashboard/modules/logbook/logbook-day-close.php?log_date=<?= urlencode($selectedDate) ?>" class="btn btn-outline-primary"><i class="fas fa-calendar-check me-1"></i> Day Close</a></div><?php endif; ?>
            <?php if ($isFinalized && $canReopenLogbook): ?><div class="col-md-8"><label class="form-label fw-semibold">Reopen Reason</label><input type="text" name="reopen_reason" class="form-control" placeholder="Explain why this finalized logbook needs to be reopened."></div><div class="col-md-4 d-flex align-items-end justify-content-end"><button type="submit" name="reopen_logbook" class="btn btn-outline-danger w-100"><i class="fas fa-unlock me-1"></i> Reopen Logbook</button></div><?php endif; ?>
        </form>

        <div class="signature-box">
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="signature-line"><?= h($existingNote['prepared_by'] ?: 'Prepared By') ?></div>
                </div>
                <div class="col-md-4">
                    <div class="signature-line"><?= h($existingNote['reviewed_by'] ?: 'Reviewed By') ?></div>
                </div>
                <div class="col-md-4">
                    <div class="signature-line"><?= h($isFinalized ? ($existingNote['finalized_by'] ?: 'Finalized By') : 'Finalized By') ?></div>
                </div>
            </div>
        </div>
        </div>
    </div>

    <div class="section-divider"></div>

    <div class="audit-block mt-4">
        <div class="section-title collapse-toggle" role="button" data-bs-toggle="collapse" data-bs-target="#auditHistorySection" aria-expanded="false" aria-controls="auditHistorySection">
            <i class="fas fa-clock-rotate-left me-2"></i>Turnover And Audit History (<?= count($auditEntries) ?>)
            <i class="fas fa-chevron-down toggle-icon ms-auto"></i>
        </div>
        <div id="auditHistorySection" class="collapse mt-3">
        <?php if (empty($auditEntries)): ?>
            <div class="text-muted">No audit history yet for this logbook shift.</div>
        <?php else: ?>
            <div class="audit-scroll">
                <?php foreach ($auditEntries as $entry): ?>
                    <div class="audit-item">
                        <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                            <div>
                                <strong><?= h(ucfirst(str_replace('_', ' ', (string) $entry['action_type']))) ?></strong>
                                <div class="small text-muted"><?= h($entry['changed_by'] ?: 'Unknown user') ?></div>
                            </div>
                            <div class="small text-muted"><?= h(date('n/j/Y g:i A', strtotime((string) $entry['created_at']))) ?></div>
                        </div>
                        <?php $parsedDetails = parse_logbook_audit_details((string) ($entry['action_details'] ?? '')); ?>
                        <?php if (!empty($parsedDetails)): ?>
                            <div class="small mt-2">
                                <?php foreach ($parsedDetails as $detail): ?>
                                    <div><strong><?= h($detail['label']) ?>:</strong> <?= h($detail['value']) ?></div>
                                <?php endforeach; ?>
                            </div>
                        <?php elseif (!empty($entry['action_details'])): ?>
                            <div class="small mt-2"><?= h($entry['action_details']) ?></div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        </div>
    </div>

    <div class="footer-note text-center mt-4 small">The logbook now supports shift operations, owner-friendly summary review, actual cash validation, shortage or overage tracking, and turnover audit history.</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('themeToggleBtn').addEventListener('click', function() {
    document.body.classList.toggle('dark-mode');
    this.querySelector('i').classList.toggle('fa-moon');
    this.querySelector('i').classList.toggle('fa-sun');
});

document.querySelectorAll('.quick-jump-btn').forEach(function(button) {
    if (button.id === 'expandAllBtn' || button.id === 'collapseAllBtn') return;
    button.addEventListener('click', function() {
        var target = document.querySelector(button.getAttribute('data-target'));
        if (!target) return;
        var collapseInstance = bootstrap.Collapse.getOrCreateInstance(target, { toggle: false });
        collapseInstance.show();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
});

var collapsibleSections = [
    '#ownerSummarySection',
    '#cashHandlingSection',
    '#transactionLogSection',
    '#shiftNoteSection',
    '#auditHistorySection'
];

var expandAll = document.getElementById('expandAllBtn');
var collapseAll = document.getElementById('collapseAllBtn');

if (expandAll) {
    expandAll.addEventListener('click', function() {
        collapsibleSections.forEach(function(selector) {
            var target = document.querySelector(selector);
            if (!target) return;
            var instance = bootstrap.Collapse.getOrCreateInstance(target, { toggle: false });
            instance.show();
        });
    });
}

if (collapseAll) {
    collapseAll.addEventListener('click', function() {
        collapsibleSections.forEach(function(selector) {
            var target = document.querySelector(selector);
            if (!target) return;
            var instance = bootstrap.Collapse.getOrCreateInstance(target, { toggle: false });
            instance.hide();
        });
    });
}
</script>
</body>
</html>
