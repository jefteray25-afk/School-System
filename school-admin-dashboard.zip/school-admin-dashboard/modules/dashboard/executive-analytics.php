<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';

$role = $_SESSION['role'] ?? '';
if (!is_super_admin_role($role)) {
    admin_session_forbidden();
}

$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
$activeSchoolYearLabel = school_year_get_active_label($conn);

$collectionTrend = [];
$gradeTrend = [];
$pendingTrend = [];

for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-{$i} days"));
    $label = date('M j', strtotime($date));
    $total = 0.0;

    $activeStmt = $conn->prepare("SELECT COALESCE(SUM(p.amount), 0) AS total_amount
        FROM payments p
        INNER JOIN accounts a ON a.id = p.account_id
        WHERE DATE(p.date_paid) = ?
          AND COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ?
          AND COALESCE(NULLIF(TRIM(p.school_year_label), ''), ?) = ?");
    if ($activeStmt) {
        $activeStmt->bind_param('sssss', $date, $activeSchoolYearLabel, $activeSchoolYearLabel, $activeSchoolYearLabel, $activeSchoolYearLabel);
        $activeStmt->execute();
        $total += (float) (($activeStmt->get_result()->fetch_assoc()['total_amount'] ?? 0));
        $activeStmt->close();
    }

    $oldStmt = $conn->prepare("SELECT COALESCE(SUM(p.amount_paid), 0) AS total_amount
        FROM old_student_payments p
        INNER JOIN old_students s ON s.id = p.old_student_id
        WHERE DATE(COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00'))) = ?
          AND COALESCE(NULLIF(TRIM(s.school_year), ''), ?) = ?");
    if ($oldStmt) {
        $oldStmt->bind_param('sss', $date, $activeSchoolYearLabel, $activeSchoolYearLabel);
        $oldStmt->execute();
        $total += (float) (($oldStmt->get_result()->fetch_assoc()['total_amount'] ?? 0));
        $oldStmt->close();
    }

    $pendingStmt = $conn->prepare("SELECT COUNT(*) AS total_count FROM student_registration_pending WHERE DATE(submitted_at) = ? AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?");
    $pendingCount = 0;
    if ($pendingStmt) {
        $pendingStmt->bind_param('sss', $date, $activeSchoolYearLabel, $activeSchoolYearLabel);
        $pendingStmt->execute();
        $pendingCount = (int) (($pendingStmt->get_result()->fetch_assoc()['total_count'] ?? 0));
        $pendingStmt->close();
    }

    $collectionTrend[] = ['label' => $label, 'amount' => $total];
    $pendingTrend[] = ['label' => $label, 'count' => $pendingCount];
}

$gradeStmt = $conn->prepare("SELECT grade, COUNT(*) AS total_students
    FROM students
    WHERE COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?
    GROUP BY grade
    ORDER BY total_students DESC, grade ASC
    LIMIT 8");
if ($gradeStmt) {
    $gradeStmt->bind_param('ss', $activeSchoolYearLabel, $activeSchoolYearLabel);
    $gradeStmt->execute();
    $result = $gradeStmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $gradeTrend[] = [
            'grade' => (string) ($row['grade'] ?? 'Unknown'),
            'count' => (int) ($row['total_students'] ?? 0),
        ];
    }
    $gradeStmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Executive Analytics | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background:#f5f8fc; font-family:'Segoe UI','Roboto','Arial',sans-serif; color:#23395d; }
        .navbar { background:#23395d !important; }
        .navbar-brand, .navbar-nav .nav-link { color:#fff !important; }
        .page-wrap { max-width:1200px; margin:34px auto 32px; padding:0 12px; }
        .hero, .panel { background:#fff; border:1px solid #dce8f7; border-radius:18px; box-shadow:0 8px 24px rgba(33,57,93,.08); }
        .hero { padding:24px 26px; margin-bottom:18px; }
        .panel { padding:18px; }
        .chart-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(320px,1fr)); gap:16px; }
    </style>
</head>
<body>
<?php render_admin_nav('dashboard', true); ?>

<div class="page-wrap">
    <div class="hero">
        <h2 class="h4 mb-1"><i class="fas fa-chart-line me-2"></i>Executive Analytics</h2>
        <div class="text-muted">Simple trend view for collections, registrations, and grade distribution under <strong><?= htmlspecialchars($activeSchoolYearLabel) ?></strong>.</div>
    </div>

    <div class="chart-grid">
        <div class="panel">
            <h3 class="h6 mb-3">Collections Trend (Last 7 Days)</h3>
            <canvas id="collectionsChart" height="180"></canvas>
        </div>
        <div class="panel">
            <h3 class="h6 mb-3">Registration Submissions (Last 7 Days)</h3>
            <canvas id="pendingChart" height="180"></canvas>
        </div>
        <div class="panel">
            <h3 class="h6 mb-3">Top Grade Distribution</h3>
            <canvas id="gradeChart" height="180"></canvas>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const collectionTrend = <?= json_encode($collectionTrend, JSON_UNESCAPED_SLASHES) ?>;
const pendingTrend = <?= json_encode($pendingTrend, JSON_UNESCAPED_SLASHES) ?>;
const gradeTrend = <?= json_encode($gradeTrend, JSON_UNESCAPED_SLASHES) ?>;

new Chart(document.getElementById('collectionsChart'), {
    type: 'line',
    data: {
        labels: collectionTrend.map(item => item.label),
        datasets: [{ label: 'Collections', data: collectionTrend.map(item => item.amount), borderColor: '#23395d', backgroundColor: 'rgba(81,127,164,0.18)', fill: true, tension: 0.3 }]
    },
    options: { responsive: true, plugins: { legend: { display: false } } }
});

new Chart(document.getElementById('pendingChart'), {
    type: 'bar',
    data: {
        labels: pendingTrend.map(item => item.label),
        datasets: [{ label: 'Registrations', data: pendingTrend.map(item => item.count), backgroundColor: '#517fa4' }]
    },
    options: { responsive: true, plugins: { legend: { display: false } } }
});

new Chart(document.getElementById('gradeChart'), {
    type: 'doughnut',
    data: {
        labels: gradeTrend.map(item => item.grade),
        datasets: [{ data: gradeTrend.map(item => item.count), backgroundColor: ['#23395d','#517fa4','#75a3ca','#9cc2e5','#dce8f7','#f8d98b','#9bd3ae','#f3a7a7'] }]
    },
    options: { responsive: true }
});
</script>
</body>
</html>
<?php $conn->close(); ?>
