<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../settings/school-year-helper.php';
require_once __DIR__ . '/../settings/backup-settings-helper.php';
require_once __DIR__ . '/../students/student-registration-helper.php';
require_once __DIR__ . '/../settings/settings-permissions-roles.php';

$role = $_SESSION['role'] ?? '';
if (!is_super_admin_role($role)) {
    admin_session_forbidden();
}

school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
registration_ensure_pending_table($conn);
backup_settings_ensure_table($conn);

$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$activeSchoolYear = school_year_get_active($conn);
$activeSchoolYearLabel = $activeSchoolYear['label'] ?? school_year_default_label();
$enrollmentOpen = (int) ($activeSchoolYear['enrollment_open'] ?? 0) === 1;

$pendingCount = 0;
$todayCollections = 0.0;
$todayTransactions = 0;
$currentOutstandingBalance = 0.0;
$currentUnpaidStudents = 0;
$todayLogbookFinalized = 0;
$todayLogbookDraft = 0;
$lastBackup = backup_settings_get($conn);

$pendingStmt = $conn->prepare("SELECT COUNT(*) AS count FROM student_registration_pending WHERE status = 'Pending' AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?");
if ($pendingStmt) {
    $pendingStmt->bind_param('ss', $activeSchoolYearLabel, $activeSchoolYearLabel);
    $pendingStmt->execute();
    $pendingCount = (int) (($pendingStmt->get_result()->fetch_assoc()['count'] ?? 0));
    $pendingStmt->close();
}

$activeCollectionsStmt = $conn->prepare("SELECT COALESCE(SUM(p.amount), 0) AS total_amount, COUNT(*) AS txn_count
    FROM payments p
    INNER JOIN accounts a ON a.id = p.account_id
    WHERE DATE(p.date_paid) = CURDATE()
      AND COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ?
      AND COALESCE(NULLIF(TRIM(p.school_year_label), ''), ?) = ?");
if ($activeCollectionsStmt) {
    $activeCollectionsStmt->bind_param('ssss', $activeSchoolYearLabel, $activeSchoolYearLabel, $activeSchoolYearLabel, $activeSchoolYearLabel);
    $activeCollectionsStmt->execute();
    $row = $activeCollectionsStmt->get_result()->fetch_assoc() ?: [];
    $todayCollections += (float) ($row['total_amount'] ?? 0);
    $todayTransactions += (int) ($row['txn_count'] ?? 0);
    $activeCollectionsStmt->close();
}

$oldCollectionsStmt = $conn->prepare("SELECT COALESCE(SUM(p.amount_paid), 0) AS total_amount, COUNT(*) AS txn_count
    FROM old_student_payments p
    INNER JOIN old_students s ON s.id = p.old_student_id
    WHERE DATE(COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00'))) = CURDATE()
      AND COALESCE(NULLIF(TRIM(s.school_year_label), ''), ?) = ?");
if ($oldCollectionsStmt) {
    $oldCollectionsStmt->bind_param('ss', $activeSchoolYearLabel, $activeSchoolYearLabel);
    $oldCollectionsStmt->execute();
    $row = $oldCollectionsStmt->get_result()->fetch_assoc() ?: [];
    $todayCollections += (float) ($row['total_amount'] ?? 0);
    $todayTransactions += (int) ($row['txn_count'] ?? 0);
    $oldCollectionsStmt->close();
}

$balanceStmt = $conn->prepare("SELECT
    COUNT(DISTINCT CASE WHEN balance > 0 THEN student_id END) AS unpaid_students,
    COALESCE(SUM(balance), 0) AS outstanding_balance
    FROM accounts
    WHERE COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?");
if ($balanceStmt) {
    $balanceStmt->bind_param('ss', $activeSchoolYearLabel, $activeSchoolYearLabel);
    $balanceStmt->execute();
    $row = $balanceStmt->get_result()->fetch_assoc() ?: [];
    $currentUnpaidStudents = (int) ($row['unpaid_students'] ?? 0);
    $currentOutstandingBalance = (float) ($row['outstanding_balance'] ?? 0);
    $balanceStmt->close();
}

$logbookStmt = $conn->prepare("SELECT
    SUM(CASE WHEN is_finalized = 1 THEN 1 ELSE 0 END) AS finalized_count,
    SUM(CASE WHEN is_finalized = 0 THEN 1 ELSE 0 END) AS draft_count
    FROM logbook_shift_notes
    WHERE log_date = CURDATE()");
if ($logbookStmt) {
    $logbookStmt->execute();
    $row = $logbookStmt->get_result()->fetch_assoc() ?: [];
    $todayLogbookFinalized = (int) ($row['finalized_count'] ?? 0);
    $todayLogbookDraft = (int) ($row['draft_count'] ?? 0);
    $logbookStmt->close();
}

function owner_money(float $amount): string
{
    return 'PHP ' . number_format($amount, 2);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Owner Dashboard | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --main-bg:#f4f8fd; --card-bg:#fff; --brand-dark:#23395d; --brand-blue:#517fa4; }
        body { background: var(--main-bg); font-family:'Segoe UI','Roboto','Arial',sans-serif; color: var(--brand-dark); }
        .navbar { background: var(--brand-dark) !important; }
        .navbar-brand, .navbar-nav .nav-link { color: #fff !important; }
        .page-wrap { max-width: 1180px; margin: 34px auto 32px; padding: 0 12px; }
        .hero { background: linear-gradient(135deg, #23395d 0%, #517fa4 100%); color: #fff; border-radius: 22px; box-shadow: 0 14px 30px rgba(33,57,93,0.16); padding: 26px 28px; margin-bottom: 22px; }
        .hero h1 { font-size: 1.5rem; font-weight: 800; margin-bottom: .35rem; }
        .hero p { opacity: .92; margin-bottom: 0; }
        .meta-row { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 14px; }
        .meta-chip { display: inline-flex; align-items: center; gap: 6px; border-radius: 999px; background: rgba(255,255,255,.16); border: 1px solid rgba(255,255,255,.2); padding: 8px 12px; font-size: .9rem; }
        .summary-grid, .action-grid { display:grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px; }
        .summary-card, .action-card { background: var(--card-bg); border: 1px solid #dce8f7; border-radius: 18px; box-shadow: 0 8px 24px rgba(33,57,93,0.08); }
        .summary-card { padding: 18px 18px 16px; }
        .summary-label { font-size: .8rem; text-transform: uppercase; letter-spacing: .05em; color: #607388; font-weight: 700; margin-bottom: .3rem; }
        .summary-value { font-size: 1.5rem; font-weight: 800; color: var(--brand-dark); margin-bottom: .35rem; }
        .summary-note { font-size: .93rem; color: #607388; }
        .section-title { font-size: 1.05rem; font-weight: 800; margin: 26px 0 12px; }
        .action-card { display: block; text-decoration: none; color: inherit; padding: 18px; transition: transform .15s ease, box-shadow .15s ease; }
        .action-card:hover { transform: translateY(-2px); box-shadow: 0 12px 24px rgba(33,57,93,0.12); }
        .action-card i { color: var(--brand-blue); font-size: 1.35rem; margin-bottom: .6rem; }
        .action-title { font-weight: 800; margin-bottom: .3rem; color: var(--brand-dark); }
        .action-note { color: #607388; font-size: .93rem; }
    </style>
</head>
<body>
<?php render_admin_nav('dashboard', true); ?>

<div class="page-wrap">
    <div class="hero">
        <h1><i class="fas fa-chart-pie me-2"></i>Owner Dashboard</h1>
        <p>A simplified daily view of collections, balances, pending work, logbook status, and backup health.</p>
        <div class="meta-row">
            <span class="meta-chip"><i class="fas fa-calendar-days"></i><?= htmlspecialchars($activeSchoolYearLabel) ?></span>
            <span class="meta-chip"><i class="fas fa-door-open"></i><?= $enrollmentOpen ? 'Enrollment Open' : 'Enrollment Closed' ?></span>
            <span class="meta-chip"><i class="fas fa-clock"></i><?= htmlspecialchars(date('F j, Y')) ?></span>
        </div>
    </div>

    <div class="summary-grid">
        <div class="summary-card">
            <div class="summary-label">Today's Collections</div>
            <div class="summary-value"><?= htmlspecialchars(owner_money($todayCollections)) ?></div>
            <div class="summary-note"><?= number_format($todayTransactions) ?> payment transaction(s) recorded today.</div>
        </div>
        <div class="summary-card">
            <div class="summary-label">Outstanding Balance</div>
            <div class="summary-value"><?= htmlspecialchars(owner_money($currentOutstandingBalance)) ?></div>
            <div class="summary-note"><?= number_format($currentUnpaidStudents) ?> student(s) still have unpaid balances this school year.</div>
        </div>
        <div class="summary-card">
            <div class="summary-label">Pending Registrations</div>
            <div class="summary-value"><?= number_format($pendingCount) ?></div>
            <div class="summary-note">Applications still waiting in the approval queue.</div>
        </div>
        <div class="summary-card">
            <div class="summary-label">Today's Logbook</div>
            <div class="summary-value"><?= number_format($todayLogbookFinalized) ?> finalized</div>
            <div class="summary-note"><?= number_format($todayLogbookDraft) ?> draft shift record(s) still open.</div>
        </div>
        <div class="summary-card">
            <div class="summary-label">Last Backup</div>
            <div class="summary-value"><?= htmlspecialchars((string) ($lastBackup['last_backup_status'] ?? 'Never Run')) ?></div>
            <div class="summary-note">
                <?= !empty($lastBackup['last_backup_at']) ? htmlspecialchars(date('M j, Y g:i A', strtotime((string) $lastBackup['last_backup_at']))) : 'No backup run recorded yet.' ?>
            </div>
        </div>
    </div>

    <div class="section-title">Owner Quick Actions</div>
    <div class="action-grid">
        <a class="action-card" href="/school-admin-dashboard/modules/invoice/daily-collection-report.php">
            <i class="fas fa-cash-register"></i>
            <div class="action-title">Daily Collection Report</div>
            <div class="action-note">Review the detailed collection rows and totals for a selected date.</div>
        </a>
        <a class="action-card" href="/school-admin-dashboard/modules/logbook/logbook.php">
            <i class="fas fa-book"></i>
            <div class="action-title">Logbook</div>
            <div class="action-note">Check shift notes, cash handling, and finalized logbook entries.</div>
        </a>
        <a class="action-card" href="/school-admin-dashboard/modules/settings/settings-receipt-registry.php">
            <i class="fas fa-receipt"></i>
            <div class="action-title">Receipt Registry</div>
            <div class="action-note">Monitor booklet flow, used receipts, and reusable voided entries.</div>
        </a>
        <a class="action-card" href="/school-admin-dashboard/modules/dashboard/executive-analytics.php">
            <i class="fas fa-chart-line"></i>
            <div class="action-title">Executive Analytics</div>
            <div class="action-note">Open weekly trend charts for collections, registrations, and grade distribution.</div>
        </a>
        <a class="action-card" href="/school-admin-dashboard/modules/settings/settings-pilot-test.php">
            <i class="fas fa-clipboard-check"></i>
            <div class="action-title">Pilot Checklist</div>
            <div class="action-note">Run or review the final pilot and go-live readiness checklist.</div>
        </a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
