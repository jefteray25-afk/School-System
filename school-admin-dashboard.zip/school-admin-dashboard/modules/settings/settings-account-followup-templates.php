<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require '../../config/database.php';
require_once 'settings-permissions-roles.php';
require_once 'school-info-helper.php';
require_once __DIR__ . '/../accounts/account-followup-helper.php';
include_once __DIR__ . '/../audit/audit-helper.php';

$role = (string) ($_SESSION['role'] ?? '');
$username = (string) ($_SESSION['username'] ?? '');
if (!can_access_settings_page($role, 'account_followup_templates')) {
    header('Location: /school-admin-dashboard/modules/settings/settings-dashboard.php?error=settings_denied');
    exit();
}

account_followup_ensure_tables($conn);
$csrfToken = admin_csrf_token();

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);

$pageMessage = '';
$pageMessageType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_require_post_csrf();
    $action = (string) ($_POST['template_action'] ?? '');
    if ($action === 'save_template') {
        if (account_followup_save_template($conn, $_POST, $username)) {
            $pageMessage = !empty($_POST['id']) ? 'Checklist template updated.' : 'Checklist template added.';
            audit_log($conn, $username, 'Saved account follow-up template', 'Settings', 'Template: ' . (string) ($_POST['title'] ?? ''), 'INFO');
        } else {
            $pageMessage = 'Checklist template could not be saved. Title and content are required.';
            $pageMessageType = 'danger';
        }
    } elseif ($action === 'delete_template') {
        $templateId = (int) ($_POST['id'] ?? 0);
        if ($templateId > 0 && account_followup_delete_template($conn, $templateId, $username)) {
            $pageMessage = 'Checklist template was disabled.';
            audit_log($conn, $username, 'Disabled account follow-up template', 'Settings', 'Template ID: ' . $templateId, 'WARNING');
        } else {
            $pageMessage = 'Checklist template could not be disabled.';
            $pageMessageType = 'danger';
        }
    }
}

$tablesReady = account_followup_tables_ready($conn);
$templates = $tablesReady ? account_followup_templates($conn, false) : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Follow-up Templates - School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body { background: var(--main-bg); font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif; }
        .navbar { background: var(--navbar-bg) !important; box-shadow: 0 2px 12px rgba(33,57,93,0.08); }
        .navbar-brand, .navbar-nav .nav-link { color: #fff !important; }
        .dashboard-header { text-align: center; margin-top: 36px; margin-bottom: 18px; }
        .dashboard-header img { width: 70px; height: 70px; object-fit: contain; margin-bottom: 6px; }
        .dashboard-header h1 { font-size: 1.3rem; color: var(--brand-dark); font-weight: 700; margin-bottom: 0; }
        .section-card {
            background: var(--card-bg);
            border: 1px solid rgba(81, 127, 164, 0.15);
            border-radius: 1rem;
            box-shadow: 0 4px 18px rgba(33, 57, 93, 0.07);
            margin-bottom: 1.25rem;
        }
        .page-title { color: var(--brand-dark); font-weight: 700; }
        textarea.form-control { min-height: 130px; }
    </style>
</head>
<body>
<?php render_admin_nav('settings'); ?>
<?php render_school_page_header($schoolName, $schoolLogo); ?>

<div class="container pb-5">
    <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-4">
        <div>
            <h2 class="page-title mb-1"><i class="fas fa-clipboard-list me-2"></i>Account Follow-up Templates</h2>
            <p class="text-muted mb-0">Manage global checklist buttons shown in the Payment Desk follow-up notes panel.</p>
        </div>
        <a href="/school-admin-dashboard/modules/settings/settings-dashboard.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back to Settings
        </a>
    </div>

    <?php if ($pageMessage !== ''): ?>
        <div class="alert alert-<?= htmlspecialchars($pageMessageType) ?>"><?= htmlspecialchars($pageMessage) ?></div>
    <?php endif; ?>

    <?php if (!$tablesReady): ?>
        <div class="alert alert-warning">Account follow-up schema is not ready. Run the migration tool first.</div>
    <?php else: ?>
        <div class="section-card p-4">
            <h5 class="mb-3">Add New Template</h5>
            <form method="post" class="row g-3">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                <input type="hidden" name="template_action" value="save_template">
                <div class="col-md-5">
                    <label class="form-label">Button Title</label>
                    <input type="text" class="form-control" name="title" maxlength="120" required placeholder="Example: Books Follow-up">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Sort Order</label>
                    <input type="number" class="form-control" name="sort_order" value="50">
                </div>
                <div class="col-md-4">
                    <label class="form-label d-block">Status</label>
                    <div class="form-check mt-2">
                        <input class="form-check-input" type="checkbox" name="is_enabled" value="1" id="newEnabled" checked>
                        <label class="form-check-label" for="newEnabled">Enabled in Payment Desk</label>
                    </div>
                </div>
                <div class="col-12">
                    <label class="form-label">Checklist / Reminder Content</label>
                    <textarea class="form-control" name="content" required placeholder="Write the reminder steps staff should follow."></textarea>
                </div>
                <div class="col-12 text-end">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-plus me-1"></i>Add Template</button>
                </div>
            </form>
        </div>

        <div class="section-card p-4">
            <h5 class="mb-3">Current Templates</h5>
            <?php if ($templates): ?>
                <div class="accordion" id="templateAccordion">
                    <?php foreach ($templates as $template): ?>
                        <?php $templateId = (int) $template['id']; ?>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="templateHeading<?= $templateId ?>">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#templateCollapse<?= $templateId ?>" aria-expanded="false">
                                    <span class="fw-bold me-2"><?= htmlspecialchars((string) $template['title']) ?></span>
                                    <span class="badge <?= !empty($template['is_enabled']) ? 'text-bg-success' : 'text-bg-secondary' ?>">
                                        <?= !empty($template['is_enabled']) ? 'Enabled' : 'Disabled' ?>
                                    </span>
                                </button>
                            </h2>
                            <div id="templateCollapse<?= $templateId ?>" class="accordion-collapse collapse" data-bs-parent="#templateAccordion">
                                <div class="accordion-body">
                                    <form method="post" class="row g-3">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                        <input type="hidden" name="template_action" value="save_template">
                                        <input type="hidden" name="id" value="<?= $templateId ?>">
                                        <div class="col-md-5">
                                            <label class="form-label">Button Title</label>
                                            <input type="text" class="form-control" name="title" maxlength="120" required value="<?= htmlspecialchars((string) $template['title']) ?>">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label">Sort Order</label>
                                            <input type="number" class="form-control" name="sort_order" value="<?= (int) $template['sort_order'] ?>">
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label d-block">Status</label>
                                            <div class="form-check mt-2">
                                                <input class="form-check-input" type="checkbox" name="is_enabled" value="1" id="enabled<?= $templateId ?>" <?= !empty($template['is_enabled']) ? 'checked' : '' ?>>
                                                <label class="form-check-label" for="enabled<?= $templateId ?>">Enabled in Payment Desk</label>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label">Checklist / Reminder Content</label>
                                            <textarea class="form-control" name="content" required><?= htmlspecialchars((string) $template['content']) ?></textarea>
                                        </div>
                                        <div class="col-12">
                                            <button type="submit" class="btn btn-primary"><i class="fas fa-save me-1"></i>Save Template</button>
                                        </div>
                                    </form>
                                    <form method="post" class="mt-2" onsubmit="return confirm('Disable this checklist template?');">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                        <input type="hidden" name="template_action" value="delete_template">
                                        <input type="hidden" name="id" value="<?= $templateId ?>">
                                        <button type="submit" class="btn btn-outline-danger"><i class="fas fa-ban me-1"></i>Disable</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-info mb-0">No templates yet.</div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
