<?php
require_once __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/backup-settings-helper.php';
require_once __DIR__ . '/settings-permissions-roles.php';
require_once 'settings-security.php';

if (!isset($conn) || !($conn instanceof mysqli)) {
    $conn = database_open_connection();
}

if (!can_manage_backups()) {
    admin_session_forbidden();
}

$filename = sanitize_backup_filename($_GET['file'] ?? '');
if ($filename === '' || pathinfo($filename, PATHINFO_EXTENSION) !== 'sql') {
    http_response_code(404);
    exit('Backup not found.');
}

$backupSettings = backup_settings_get($conn);
$backupDir = backup_settings_resolved_dir($backupSettings);

$backupPath = rtrim($backupDir, '/\\') . '/' . $filename;
if (!is_file($backupPath)) {
    http_response_code(404);
    exit('Backup not found.');
}

header('Content-Type: application/sql');
header('Content-Disposition: attachment; filename="' . rawurlencode($filename) . '"');
header('Content-Length: ' . filesize($backupPath));
header('X-Content-Type-Options: nosniff');
readfile($backupPath);
exit();
