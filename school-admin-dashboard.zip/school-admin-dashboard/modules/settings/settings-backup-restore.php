<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once 'settings-permissions-roles.php';
require_once 'settings-security.php';
require_once 'school-info-helper.php';
require_once 'backup-settings-helper.php';
include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');
require '../../config/database.php';

$user_role = $_SESSION['role'] ?? '';
$username = $_SESSION['username'] ?? '';
$canManualBackup = can_access_settings_page($user_role, 'backup');
$canRestore = is_super_admin_role($user_role);
$isBackupOnlyStaff = is_registrar_staff_role($user_role) || is_accounting_staff_role($user_role);
if (!$canManualBackup) {
    header('Location: /school-admin-dashboard/modules/settings/settings-dashboard.php?error=restricted');
    exit();
}

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$user_id = (int) ($_SESSION['user_id'] ?? 0);
$db_host = $db_host ?? 'localhost';
$db_user = $db_user ?? 'root';
$db_pass = $db_pass ?? '';
$db_name = $db_name ?? 'school_admin';
$mysqldump_path = 'C:/xampp/mysql/bin/mysqldump.exe';
$mysql_path = 'C:/xampp/mysql/bin/mysql.exe';
backup_settings_ensure_table($conn);
$backupSettings = backup_settings_get($conn);
$backup_dir = backup_settings_resolved_dir($backupSettings);
if (!is_dir($backup_dir)) {
    mkdir($backup_dir, 0775, true);
}

$backup_message = '';
$restore_message = '';
$auto_backup_message = '';
$automaticBackupSummary = !empty($backupSettings['enabled'])
    ? 'Every hour while the server PC is running'
    : 'Disabled';
$backup_scheduler_batch = 'C:\xampp\htdocs\school-admin-dashboard\backups\backup-script.bat';
$backup_scheduler_setup = 'C:\xampp\htdocs\school-admin-dashboard\backups\install-backup-schedule.ps1';

function get_next_backup_filename(string $dir, string $base_name): string
{
    $i = 1;
    $file = $base_name . '.sql';
    while (file_exists($dir . '/' . $file)) {
        $file = $base_name . '(' . $i . ').sql';
        $i++;
    }
    return $file;
}

function backup_filename_prefix(string $db_name): string
{
    $prefix = strtolower(trim($db_name));
    $prefix = preg_replace('/[^a-z0-9]+/', '_', $prefix);
    $prefix = trim((string) $prefix, '_');

    return $prefix !== '' ? $prefix : 'school_admin';
}

function build_backup_file_base(string $db_name, string $mode): string
{
    $mode = strtolower(trim($mode));
    if ($mode !== 'auto') {
        $mode = 'manual';
    }

    return backup_filename_prefix($db_name) . '_' . $mode . '_' . date('Y-m-d_H-i-s');
}

function perform_backup(string $backup_dir, string $db_host, string $db_user, string $db_pass, string $db_name, string $mysqldump_path, string $file_base): array
{
    $backup_file = get_next_backup_filename($backup_dir, $file_base);
    $backup_path = $backup_dir . '/' . $backup_file;

    if (!is_dir($backup_dir) || !is_writable($backup_dir)) {
        return [false, $backup_file, $backup_path];
    }

    $command = escapeshellarg($mysqldump_path)
        . ' --host=' . escapeshellarg($db_host)
        . ' --user=' . escapeshellarg($db_user);

    if ($db_pass !== '') {
        $command .= ' --password=' . escapeshellarg($db_pass);
    }

    $command .= ' ' . escapeshellarg($db_name) . ' > ' . escapeshellarg($backup_path);
    shell_exec($command);

    $is_valid_backup = file_exists($backup_path) && filesize($backup_path) > 100;
    return [$is_valid_backup, $backup_file, $backup_path];
}

function restore_backup_file(string $tmp_name, string $db_host, string $db_user, string $db_pass, string $db_name, string $mysql_path): bool
{
    if (!is_file($tmp_name) || filesize($tmp_name) <= 0) {
        return false;
    }
    $command = escapeshellarg($mysql_path)
        . ' --host=' . escapeshellarg($db_host)
        . ' --user=' . escapeshellarg($db_user);

    if ($db_pass !== '') {
        $command .= ' --password=' . escapeshellarg($db_pass);
    }

    $command .= ' ' . escapeshellarg($db_name) . ' < ' . escapeshellarg($tmp_name);
    $output = [];
    $exitCode = 1;
    exec($command . ' 2>&1', $output, $exitCode);
    return $exitCode === 0;
}

function backup_restore_audit_details(string $username, string $userRole, string $filename, string $status, string $extra = ''): string
{
    $details = 'User: ' . $username
        . ' | Role: ' . $userRole
        . ' | File: ' . $filename
        . ' | Status: ' . $status;
    if ($extra !== '') {
        $details .= ' | ' . $extra;
    }
    return $details;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['backup']) && $canManualBackup) {
    admin_require_post_csrf();
    $file_base = build_backup_file_base($db_name, 'manual');
    [$is_valid_backup, $backup_file, $backup_path] = perform_backup($backup_dir, $db_host, $db_user, $db_pass, $db_name, $mysqldump_path, $file_base);

    if ($is_valid_backup) {
        $downloadUrl = '/school-admin-dashboard/modules/settings/settings-download-backup.php?file=' . rawurlencode($backup_file);
        $backup_message = 'Backup created successfully: <strong>' . htmlspecialchars($backup_file) . '</strong>.<br><a href="' . htmlspecialchars($downloadUrl) . '">Download</a>';
        $deletedFiles = backup_settings_prune_old_files($backup_dir, (int) ($backupSettings['retention_count'] ?? 122));
        $statusMessage = 'Manual backup created successfully.';
        if (!empty($deletedFiles)) {
            $statusMessage .= ' Pruned: ' . implode(', ', $deletedFiles);
        }
        backup_settings_record_run($conn, 'Success', $statusMessage, $backup_file);
        audit_log(
            $conn,
            $username,
            'Created manual backup',
            'Settings',
            backup_restore_audit_details($username, $user_role, $backup_file, 'Success', !empty($deletedFiles) ? 'Pruned: ' . implode(', ', $deletedFiles) : ''),
            'INFO'
        );
    } else {
        if (file_exists($backup_path)) {
            unlink($backup_path);
        }
        $reason = (!is_dir($backup_dir) || !is_writable($backup_dir))
            ? 'Backup directory is missing or not writable: ' . $backup_dir
            : 'mysqldump did not produce a valid file.';
        $backup_message = 'Backup failed. ' . htmlspecialchars($reason);
        backup_settings_record_run($conn, 'Failed', 'Manual backup failed. ' . $reason, '');
        audit_log(
            $conn,
            $username,
            'Manual backup failed',
            'Settings',
            backup_restore_audit_details($username, $user_role, $backup_file, 'Failed', $reason),
            'ERROR'
        );
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['run_auto_backup']) && $canRestore) {
    admin_require_post_csrf();
    $file_base = build_backup_file_base($db_name, 'auto');
    [$is_valid_backup, $backup_file, $backup_path] = perform_backup($backup_dir, $db_host, $db_user, $db_pass, $db_name, $mysqldump_path, $file_base);

    if ($is_valid_backup) {
        $downloadUrl = '/school-admin-dashboard/modules/settings/settings-download-backup.php?file=' . rawurlencode($backup_file);
        $auto_backup_message = 'Automatic backup created: <strong>' . htmlspecialchars($backup_file) . '</strong>.<br><a href="' . htmlspecialchars($downloadUrl) . '">Download</a>';
        $deletedFiles = backup_settings_prune_old_files($backup_dir, (int) ($backupSettings['retention_count'] ?? 122));
        $statusMessage = 'Automatic backup created successfully.';
        if (!empty($deletedFiles)) {
            $statusMessage .= ' Pruned: ' . implode(', ', $deletedFiles);
        }
        backup_settings_record_run($conn, 'Success', $statusMessage, $backup_file);
        audit_log(
            $conn,
            $username,
            'Created automatic backup',
            'Settings',
            backup_restore_audit_details($username, $user_role, $backup_file, 'Success', !empty($deletedFiles) ? 'Pruned: ' . implode(', ', $deletedFiles) : ''),
            'INFO'
        );
    } else {
        if (file_exists($backup_path)) {
            unlink($backup_path);
        }
        $reason = (!is_dir($backup_dir) || !is_writable($backup_dir))
            ? 'Backup directory is missing or not writable: ' . $backup_dir
            : 'mysqldump did not produce a valid file.';
        $auto_backup_message = 'Automatic backup failed. ' . htmlspecialchars($reason);
        backup_settings_record_run($conn, 'Failed', 'Automatic backup failed. ' . $reason, '');
        audit_log(
            $conn,
            $username,
            'Automatic backup failed',
            'Settings',
            backup_restore_audit_details($username, $user_role, $backup_file, 'Failed', $reason),
            'ERROR'
        );
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['restore']) && $canRestore) {
    admin_require_post_csrf();
    $restore_password = $_POST['restore_password'] ?? '';
    $restore_phrase = trim((string) ($_POST['restore_phrase'] ?? ''));

    try {
        $pdo = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $pdo->prepare('SELECT password FROM admins WHERE id = ?');
        $stmt->execute([$user_id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (Exception $ex) {
        $row = null;
    }

    if ($restore_phrase !== 'RESTORE') {
        $restore_message = "<span class='text-danger'>Restore failed: Type RESTORE to confirm the action.</span>";
        audit_log(
            $conn,
            $username,
            'Backup restore blocked',
            'Settings',
            backup_restore_audit_details($username, $user_role, 'N/A', 'Blocked', 'Reason: Missing typed RESTORE confirmation.'),
            'WARNING'
        );
    } elseif (!$row || !password_verify($restore_password, $row['password'])) {
        $restore_message = "<span class='text-danger'>Restore failed: Incorrect password.</span>";
        audit_log(
            $conn,
            $username,
            'Backup restore failed',
            'Settings',
            backup_restore_audit_details($username, $user_role, 'N/A', 'Failed', 'Reason: Incorrect restore password.'),
            'SECURITY'
        );
    } elseif (isset($_FILES['restore_file']) && $_FILES['restore_file']['error'] === UPLOAD_ERR_OK) {
        $tmp_name = $_FILES['restore_file']['tmp_name'];
        $filename = sanitize_backup_filename($_FILES['restore_file']['name']);
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if ($ext !== 'sql') {
            $restore_message = 'Invalid file type. Only .sql files are allowed.';
            audit_log(
                $conn,
                $username,
                'Backup restore failed',
                'Settings',
                backup_restore_audit_details($username, $user_role, $filename, 'Failed', 'Reason: Invalid file type.'),
                'WARNING'
            );
        } elseif (filesize($tmp_name) <= 0) {
            $restore_message = 'Uploaded file is empty.';
            audit_log(
                $conn,
                $username,
                'Backup restore failed',
                'Settings',
                backup_restore_audit_details($username, $user_role, $filename, 'Failed', 'Reason: Uploaded SQL file was empty.'),
                'WARNING'
            );
        } else {
            if (restore_backup_file($tmp_name, $db_host, $db_user, $db_pass, $db_name, $mysql_path)) {
                $restore_message = 'Restore completed from <strong>' . htmlspecialchars($filename) . '</strong>. Please verify the data in the app.';
                audit_log(
                    $conn,
                    $username,
                    'Restored database backup',
                    'Settings',
                    backup_restore_audit_details($username, $user_role, $filename, 'Success'),
                    'WARNING'
                );
            } else {
                $restore_message = 'Restore failed while importing the SQL backup.';
                audit_log(
                    $conn,
                    $username,
                    'Backup restore failed',
                    'Settings',
                    backup_restore_audit_details($username, $user_role, $filename, 'Failed', 'Reason: MySQL import command failed.'),
                    'ERROR'
                );
            }
        }
    } else {
        $restore_message = 'Upload error. Please select a valid .sql file.';
        audit_log(
            $conn,
            $username,
            'Backup restore failed',
            'Settings',
            backup_restore_audit_details($username, $user_role, 'N/A', 'Failed', 'Reason: Restore upload did not complete successfully.'),
            'WARNING'
        );
    }
}

$recent_backups = glob($backup_dir . '/*.sql') ?: [];
natsort($recent_backups);
$recent_backups = array_reverse($recent_backups);
$recent_backups = array_slice($recent_backups, 0, 5);
ensure_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Backup & Restore - School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f5f8fc; font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif; }
        .navbar { background: #23395d !important; }
        .navbar-brand, .navbar-nav .nav-link { color: #fff !important; }
        .page-header { text-align: center; margin: 32px 0 24px; }
        .page-header img { width: 64px; height: 64px; object-fit: contain; margin-bottom: 8px; }
        .page-header h1 { font-size: 1.25rem; color: #23395d; font-weight: 700; margin-bottom: 0; }
        .page-header p { margin-bottom: 0; }
        .section-card { box-shadow: 0 2px 14px rgba(33,57,93,0.08); border-radius: 1rem; margin-bottom: 1.5rem; border: none; }
        .section-card .card-header { background: linear-gradient(90deg,#517fa4 0,#23395d 100%); color: #fff; font-size: 1.05rem; font-weight: 600; }
        .dir-note { display: none; font-size: 0.98em; color: #6c757d; margin-top: 7px; margin-bottom: 0; }
        .eye-btn { background: none; border: none; color: #517fa4; font-size: 1.35em; cursor: pointer; outline: none; vertical-align: middle; }
        .eye-btn:active, .eye-btn:focus { color: #23395d; }
        .checklist li { margin-bottom: 0.55rem; }
        .mini-note { font-size: 0.93rem; color: #6c757d; }
        .risk-box { border-left: 4px solid #dc3545; background: #fff7f7; padding: 0.9rem 1rem; border-radius: 0.5rem; }
        .safe-box { border-left: 4px solid #198754; background: #f4fff8; padding: 0.9rem 1rem; border-radius: 0.5rem; }
    </style>
</head>
<body>
<?php render_admin_nav('settings'); ?>

<div class="container pb-4">
    <div class="page-header">
        <img src="<?= htmlspecialchars($schoolLogo) ?>" alt="School Logo" class="rounded shadow-sm">
        <h1><?= htmlspecialchars($schoolName) ?></h1>
        <p class="text-muted">Use this page for actual backup operations and as the school’s restore checklist.</p>
    </div>

    <?php if ($isBackupOnlyStaff): ?>
        <div class="alert alert-info">
            <i class="fas fa-shield-alt me-1"></i>
            This role can create and download backups only. Restore, backup schedule changes, and server backup policy remain under Super Admin control.
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <div class="col-12 col-xl-7">
            <div class="card section-card">
                <div class="card-header"><i class="fas fa-download me-2"></i>Backup Database</div>
                <div class="card-body">
                    <form method="post">
                        <?= csrf_input() ?>
                        <button type="submit" name="backup" class="btn btn-primary">
                            <i class="fas fa-file-export me-1"></i>Create Backup
                        </button>
                    </form>
                    <?php if ($backup_message): ?>
                        <div class="alert alert-info mt-3 mb-2"><?= $backup_message ?></div>
                    <?php endif; ?>
                    <div class="mt-3">
                        <button type="button" class="eye-btn" id="showDirBtn" title="Show backup directory">
                            <i class="fas fa-eye"></i>
                        </button>
                        <span style="vertical-align:middle; color:#888; font-size:1em; margin-left:7px;">Show backup directory</span>
                        <div class="dir-note" id="dirNote">
                            <i class="fas fa-folder-open me-1"></i>
                            Database backups are stored in <code><?= htmlspecialchars($backup_dir) ?></code>.
                        </div>
                    </div>
                    <p class="mini-note mt-3 mb-0">After creating a backup, download a copy and save another copy on external storage or another trusted PC.</p>
                </div>
            </div>

            <div class="card section-card">
                <div class="card-header"><i class="fas fa-clock me-2"></i>Scheduled and Recent Backups</div>
                <div class="card-body">
                        <p class="mb-2"><strong>Current schedule:</strong> <?= htmlspecialchars($automaticBackupSummary) ?>.</p>
                    <?php if ($canRestore): ?>
                        <p class="mb-2"><strong>Configured policy:</strong> <?= !empty($backupSettings['enabled']) ? 'Enabled' : 'Disabled' ?> | Retention <?= (int) ($backupSettings['retention_count'] ?? 122) ?> backups | <a href="/school-admin-dashboard/modules/settings/settings-backup-schedule.php">Backup Schedule Settings</a></p>
                        <div class="safe-box mb-3">
                            <strong>Automatic mode uses Windows Task Scheduler.</strong> After setup, the server will create a backup at the next top-of-hour and continue hourly while the PC stays on.
                        </div>
                        <form method="post" class="mb-3">
                            <?= csrf_input() ?>
                            <button type="submit" name="run_auto_backup" value="1" class="btn btn-info text-white">
                                <i class="fas fa-bolt me-1"></i>Run Automatic Backup Now
                            </button>
                        </form>
                    <?php else: ?>
                        <p class="mb-2"><strong>Configured policy:</strong> <?= !empty($backupSettings['enabled']) ? 'Enabled' : 'Disabled' ?> | Retention <?= (int) ($backupSettings['retention_count'] ?? 122) ?> backups | Backup Schedule Settings (Super Admin only)</p>
                    <?php endif; ?>
                    <?php if ($auto_backup_message): ?>
                        <div class="alert alert-info mt-3"><?= $auto_backup_message ?></div>
                    <?php endif; ?>
                    <div class="mini-note mb-3">
                        <div><strong>Last backup status:</strong> <?= htmlspecialchars((string) ($backupSettings['last_backup_status'] ?? 'Never Run')) ?></div>
                        <div><strong>Last backup file:</strong> <?= htmlspecialchars((string) ($backupSettings['last_backup_file'] ?? '-')) ?></div>
                        <div><strong>Last backup at:</strong> <?= htmlspecialchars((string) ($backupSettings['last_backup_at'] ?? '-')) ?></div>
                    </div>
                    <h6 class="mt-3">Recent Backup Files</h6>
                    <ul class="mb-0">
                        <?php if ($recent_backups): ?>
                            <?php foreach ($recent_backups as $file): ?>
                                <?php
                                $file_name = basename($file);
                                $file_size = round(filesize($file) / 1024, 1);
                                $downloadUrl = '/school-admin-dashboard/modules/settings/settings-download-backup.php?file=' . rawurlencode($file_name);
                                ?>
                                <li>
                                    <a href="<?= htmlspecialchars($downloadUrl) ?>"><?= htmlspecialchars($file_name) ?></a>
                                    <span class="text-muted">(<?= htmlspecialchars((string) $file_size) ?> KB)</span>
                                </li>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <li class="text-muted">No backups found.</li>
                        <?php endif; ?>
                    </ul>
                    <?php if ($canRestore): ?>
                        <div class="mt-3 mini-note">
                            <div><strong>Scheduler batch:</strong> <code><?= htmlspecialchars($backup_scheduler_batch) ?></code></div>
                            <div><strong>Scheduler setup script:</strong> <code><?= htmlspecialchars($backup_scheduler_setup) ?></code></div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($canRestore): ?>
            <div class="card section-card">
                <div class="card-header"><i class="fas fa-upload me-2"></i>Restore Database</div>
                <div class="card-body">
                    <div class="risk-box mb-3">
                        <strong>Restore is a high-risk action.</strong> It can overwrite current live data. Only restore after making a fresh backup of the current system first.
                    </div>
                    <form method="post" enctype="multipart/form-data">
                        <?= csrf_input() ?>
                        <div class="input-group mb-3">
                            <input type="file" name="restore_file" accept=".sql" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="restore_password" class="form-label">Enter your password to confirm restore</label>
                            <input type="password" name="restore_password" id="restore_password" class="form-control" required autocomplete="current-password">
                        </div>
                        <div class="mb-3">
                            <label for="restore_phrase" class="form-label">Type <code>RESTORE</code> to continue</label>
                            <input type="text" name="restore_phrase" id="restore_phrase" class="form-control" required autocomplete="off">
                        </div>
                        <button type="submit" name="restore" class="btn btn-warning">
                            <i class="fas fa-file-import me-1"></i>Restore Backup
                        </button>
                    </form>
                    <?php if ($restore_message): ?>
                        <div class="alert alert-info mt-3 mb-0"><?= $restore_message ?></div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <div class="col-12 col-xl-5">
            <div class="card section-card">
                <div class="card-header"><i class="fas fa-list-check me-2"></i>School Backup Checklist</div>
                <div class="card-body">
                    <h6>Daily</h6>
                    <ul class="checklist">
                        <li>Confirm at least one hourly automatic backup ran while the server PC was operating.</li>
                        <li>Create or verify at least one SQL backup for the day.</li>
                        <li>Download one copy of the newest backup file.</li>
                        <li>Store one copy outside the server PC if possible.</li>
                    </ul>
                    <h6>Before major changes</h6>
                    <ul class="checklist">
                        <li>Run a fresh backup before imports, cleanup tasks, or settings changes.</li>
                        <li>Confirm who is responsible for the change and who will verify after.</li>
                        <li>Do not restore or import while multiple admins are actively encoding.</li>
                    </ul>
                    <h6>Weekly</h6>
                    <ul class="checklist mb-0">
                        <li>Check that recent backup files can still be downloaded.</li>
                        <li>Copy the latest backup set to external drive or another trusted machine.</li>
                        <li>Review storage space on the backup directory.</li>
                    </ul>
                </div>
            </div>

            <div class="card section-card">
                <div class="card-header"><i class="fas fa-box-archive me-2"></i>What To Back Up</div>
                <div class="card-body">
                    <div class="safe-box mb-3">
                        <strong>Minimum safe set:</strong> database SQL backup, project files, uploads folder, and config files.
                    </div>
                    <ul class="checklist mb-0">
                        <li>Database: generated <code>.sql</code> backup from this page.</li>
                        <li>Project folder: <code>C:\xampp\htdocs\school-admin-dashboard</code></li>
                        <li>Uploads folder inside the project, especially logos and user-uploaded files.</li>
                        <li>Server-specific settings like XAMPP and trusted admin IP rules if changed later.</li>
                    </ul>
                </div>
            </div>

            <?php if ($canRestore): ?>
            <div class="card section-card">
                <div class="card-header"><i class="fas fa-rotate-left me-2"></i>Safe Restore Procedure</div>
                <div class="card-body">
                    <ol class="mb-0">
                        <li>Make a fresh backup of the current live database first.</li>
                        <li>Ask users to stop using the system during restore.</li>
                        <li>Upload the correct <code>.sql</code> file and confirm with your password.</li>
                        <li>After restore, log in and verify students, accounts, fees, and pending registrations.</li>
                        <li>Check the latest audit logs and confirm no unexpected errors appear.</li>
                    </ol>
                </div>
            </div>
            <?php endif; ?>

            <div class="card section-card">
                <div class="card-header"><i class="fas fa-server me-2"></i>Before Moving To School Server</div>
                <div class="card-body">
                    <ul class="checklist mb-0">
                        <li>Create a final backup on your current PC before migration.</li>
                        <li>Copy the project files and uploads to the school server PC.</li>
                        <li>Restore the latest SQL backup on the school server database.</li>
                        <li>Run the backup schedule setup script on the school server PC so hourly automatic backups work there too.</li>
                        <li>Update trusted admin IP rules on the school server if needed.</li>
                        <li>Test admin login, public registration, pending approval, and audit logs before go-live.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
document.getElementById('showDirBtn').addEventListener('click', function() {
    var note = document.getElementById('dirNote');
    var eyeIcon = this.querySelector('i');
    if (note.style.display === 'none' || !note.style.display) {
        note.style.display = 'block';
        eyeIcon.classList.remove('fa-eye');
        eyeIcon.classList.add('fa-eye-slash');
    } else {
        note.style.display = 'none';
        eyeIcon.classList.remove('fa-eye-slash');
        eyeIcon.classList.add('fa-eye');
    }
});
</script>
<?= admin_session_warning_script() ?>
</body>
</html>
