<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require_once __DIR__ . '/../../includes/ui.php';
require '../../config/database.php';
require_once 'settings-permissions-roles.php';
require_once 'school-info-helper.php';
require_once 'school-year-helper.php';
require_once 'backup-settings-helper.php';
require_once 'upload-storage-helper.php';
require_once 'section-location-helper.php';
require_once '../../includes/includes-receipt-helper.php';
require_once '../../tools/smoke-core.php';
require_once __DIR__ . '/../students/student-registration-helper.php';
require_once __DIR__ . '/../rollover/year-end-rollover-helper.php';
require_once __DIR__ . '/../audit/audit-helper.php';

function settings_verify_current_admin_password(mysqli $conn, string $username, string $password): bool
{
    $username = trim($username);
    if ($username === '' || $password === '') {
        return false;
    }

    $stmt = $conn->prepare("SELECT password FROM admins WHERE username = ? LIMIT 1");
    if (!$stmt) {
        return false;
    }

    $stmt->bind_param('s', $username);
    $stmt->execute();
    $stmt->bind_result($passwordHash);
    $found = $stmt->fetch();
    $stmt->close();

    return $found && is_string($passwordHash) && password_verify($password, $passwordHash);
}

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$canViewSettings = can_view_settings_module($role);
$canManageUsers = can_access_user_management_settings($role);
$isSuperAdmin = is_super_admin_role($role);
$canAccessSchoolInformation = can_access_school_information_settings($role);
$canAccessFeeGrades = can_access_fee_grade_settings($role);
$canAccessRequirements = can_access_requirements_settings($role);
$canAccessSchoolYears = can_access_school_year_settings($role);
$canAccessSections = can_access_section_settings($role);
$canAccessSectionLocations = can_access_section_location_settings($role);
$canAccessReceiptRegistry = can_access_receipt_registry_settings($role);
$canAccessAccountFollowupTemplates = can_access_account_followup_template_settings($role);
$canAccessFinanceAdjustments = can_access_finance_adjustment_settings($role);
$canAccessBackupSettings = can_access_backup_settings($role);
$canAccessBackupSchedule = can_access_backup_schedule_settings($role);
$canAccessUploadStorage = can_access_upload_storage_settings($role);
$canAccessBulkPhotoAttachment = can_access_bulk_photo_attachment($role);
$canAccessAuditSettings = can_access_audit_settings($role);
$canAccessDuplicateCleanup = can_access_duplicate_cleanup_settings($role);
$isLimitedAdminOperator = is_limited_admin_operator_role($role);
$isRegistrarStaff = is_registrar_staff_role($role);
$isAccountingStaff = is_accounting_staff_role($role);
$isBackupOnlyStaff = $isRegistrarStaff || $isAccountingStaff;
if (!$canViewSettings) {
    header('Location: /school-admin-dashboard/dashboard.php?error=settings_denied');
    exit();
}

$settingsActionMessage = '';
$settingsActionType = 'success';
$selectedRolloverCycle = trim((string) ($_POST['rollover_cycle'] ?? ''));
$selectedRolloverSourceYear = '';
$selectedRolloverTargetYear = '';
if ($selectedRolloverCycle !== '' && strpos($selectedRolloverCycle, '|') !== false) {
    [$selectedRolloverSourceYear, $selectedRolloverTargetYear] = array_map('trim', explode('|', $selectedRolloverCycle, 2));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['reset_rollover_cycle']) || isset($_POST['reset_rollover_log']))) {
    if (!$isSuperAdmin) {
        $settingsActionMessage = 'Only Super Admin can reset the Year-End Rollover log.';
        $settingsActionType = 'danger';
    } elseif (!school_year_verify_csrf($_POST['csrf_token'] ?? '')) {
        $settingsActionMessage = 'Invalid request token. Please refresh the page and try again.';
        $settingsActionType = 'danger';
    } elseif (!settings_verify_current_admin_password($conn, $username, (string) ($_POST['confirm_admin_password'] ?? ''))) {
        $settingsActionMessage = 'Password confirmation failed. Enter your current Super Admin password to reset the Year-End Rollover log.';
        $settingsActionType = 'danger';
        audit_log(
            $conn,
            $username,
            'Blocked Year-End Rollover log reset',
            'Settings',
            'Reason: invalid Super Admin password confirmation',
            'SECURITY'
        );
    } else {
        if (isset($_POST['reset_rollover_cycle'])) {
            $resetResult = year_end_rollover_reset_cycle($conn, $selectedRolloverSourceYear, $selectedRolloverTargetYear);
        } else {
            $resetResult = year_end_rollover_reset_log($conn);
        }
        if (!empty($resetResult['success'])) {
            $deletedRows = (int) ($resetResult['deleted'] ?? 0);
            if (isset($_POST['reset_rollover_cycle'])) {
                $settingsActionMessage = $deletedRows > 0
                    ? 'Selected Year-End Rollover cycle was reset successfully. Removed ' . number_format($deletedRows) . ' row(s) for ' . $selectedRolloverSourceYear . ' -> ' . $selectedRolloverTargetYear . '.'
                    : 'Selected rollover cycle is already clean. No rows were removed.';
            } else {
                $settingsActionMessage = $deletedRows > 0
                    ? 'Year-End Rollover log was reset successfully. Removed ' . number_format($deletedRows) . ' stale row(s).'
                    : 'Year-End Rollover log is already clean. No rows were removed.';
            }
            $settingsActionType = 'success';
            audit_log(
                $conn,
                $username,
                isset($_POST['reset_rollover_cycle']) ? 'Reset Year-End Rollover cycle log' : 'Reset Year-End Rollover log',
                'Settings',
                'Role: ' . $role
                    . ' | Deleted rows: ' . $deletedRows
                    . ' | Tool: ' . (isset($_POST['reset_rollover_cycle']) ? 'year_end_rollover_cycle_reset' : 'year_end_rollover_log_reset')
                    . ' | Source: ' . ($selectedRolloverSourceYear !== '' ? $selectedRolloverSourceYear : 'ALL')
                    . ' | Target: ' . ($selectedRolloverTargetYear !== '' ? $selectedRolloverTargetYear : 'ALL'),
                'WARNING'
            );
        } else {
            $settingsActionMessage = (string) ($resetResult['message'] ?? 'Failed to reset the Year-End Rollover log.');
            $settingsActionType = 'danger';
        }
    }
}

backup_settings_ensure_table($conn);
upload_storage_ensure_table($conn);
ensure_receipt_booklet_registry($conn);

$activeSchoolYear = school_year_get_active($conn);
$backupSettings = backup_settings_get($conn);
$uploadSettings = upload_storage_get($conn);
$smokeChecks = school_admin_smoke_checks($conn);
$failedChecks = school_admin_smoke_failed_checks($smokeChecks);
$receiptSummary = receipt_booklet_registry_payment_summary($conn);
$rolloverCycles = year_end_rollover_log_cycles($conn);
$rolloverCycleOptions = [];
$rolloverCycleCounts = [];
foreach ($rolloverCycles as $cycle) {
    $cycleKey = (string) ($cycle['source_year'] ?? '') . '|' . (string) ($cycle['target_year'] ?? '');
    $rolloverCycleOptions[] = [
        'key' => $cycleKey,
        'label' => (string) ($cycle['source_year'] ?? '') . ' -> ' . (string) ($cycle['target_year'] ?? ''),
        'total_rows' => (int) ($cycle['total_rows'] ?? 0),
        'last_updated_at' => (string) ($cycle['last_updated_at'] ?? ''),
    ];
    $rolloverCycleCounts[$cycleKey] = [
        'total_rows' => (int) ($cycle['total_rows'] ?? 0),
        'last_updated_at' => (string) ($cycle['last_updated_at'] ?? ''),
    ];
}
$selectedRolloverCycleKey = $selectedRolloverSourceYear . '|' . $selectedRolloverTargetYear;
$selectedRolloverCycleMeta = $rolloverCycleCounts[$selectedRolloverCycleKey] ?? ['total_rows' => 0, 'last_updated_at' => ''];
$selectedRolloverCycleRows = (int) ($selectedRolloverCycleMeta['total_rows'] ?? 0);

$photoDirReady = is_dir($uploadSettings['student_photo_dir']) && is_writable($uploadSettings['student_photo_dir']);
$requirementDirReady = is_dir($uploadSettings['requirement_document_dir']) && is_writable($uploadSettings['requirement_document_dir']);
$uploadReady = $photoDirReady && $requirementDirReady;
$backupDirReady = is_dir($backupSettings['backup_dir']) && is_writable($backupSettings['backup_dir']);
$backupHealthy = strtolower((string) ($backupSettings['last_backup_status'] ?? '')) === 'success';
$receiptReady = ((int) ($receiptSummary['total_visible'] ?? 0) > 0);
$requirementsConfigured = 0;
$requirementsCountResult = $conn->query("SELECT COUNT(*) AS total FROM requirement_settings");
if ($requirementsCountResult) {
    $requirementsConfigured = (int) (($requirementsCountResult->fetch_assoc()['total'] ?? 0));
    $requirementsCountResult->close();
}

$settingsAlerts = [];
if (empty($activeSchoolYear['label'])) {
    $settingsAlerts[] = 'No active school year is set.';
}
if (!$backupDirReady) {
    $settingsAlerts[] = 'Backup directory is missing or not writable.';
}
if (!$backupHealthy) {
    $settingsAlerts[] = 'Last backup did not finish with Success status.';
}
if (!$isBackupOnlyStaff && !$uploadReady) {
    $settingsAlerts[] = 'One or more upload folders need attention.';
}
if (!$isBackupOnlyStaff && !$receiptReady) {
    $settingsAlerts[] = 'No active receipt booklet is currently visible in payment entry.';
}
if (!$isBackupOnlyStaff && count($failedChecks) > 0) {
    $settingsAlerts[] = 'Smoke check has ' . count($failedChecks) . ' failed item(s).';
}
if (!$isBackupOnlyStaff && $requirementsConfigured === 0) {
    $settingsAlerts[] = 'No requirement settings are configured yet.';
}

$backupLastRunText = !empty($backupSettings['last_backup_at'])
    ? date('M j, Y g:i A', strtotime((string) $backupSettings['last_backup_at']))
    : 'No run yet';
$settingsCsrfToken = school_year_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Settings - School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <?php ui_css_link(); ?>
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body {
            background: var(--main-bg);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        }
        body.dark-mode {
            --main-bg: #1b232d;
            --card-bg: #23395d;
            --navbar-bg: #161b22;
            color: #e6edf3;
        }
        .navbar {
            background: var(--navbar-bg) !important;
            box-shadow: 0 2px 12px rgba(33,57,93,0.08);
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.08em;
        }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .theme-toggle-btn {
            background: none;
            border: none;
            color: #fff;
            font-size: 1.45em;
            margin-left: 12px;
            cursor: pointer;
        }
        .dashboard-header {
            text-align: center;
            margin-top: 36px;
            margin-bottom: 18px;
        }
        .dashboard-header img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            margin-bottom: 6px;
        }
        .dashboard-header h1 {
            font-size: 1.3rem;
            color: var(--brand-dark);
            font-weight: 700;
            margin-bottom: 0;
            letter-spacing: 0.02em;
        }
        .settings-header {
            text-align: center;
            margin: 36px 0 28px 0;
        }
        .settings-header h2 {
            font-weight: bold;
            color: var(--brand-dark);
            letter-spacing: 1px;
        }
        .bulletin-board {
            background: #fbfcfe;
            border: 1px solid rgba(81,127,164,0.18);
            border-radius: 1.15rem;
            box-shadow: 0 8px 24px rgba(33,57,93,0.06);
            padding: 1.1rem 1.15rem 1.2rem;
            margin-bottom: 1.4rem;
        }
        .bulletin-title {
            font-size: 0.92rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #607388;
            font-weight: 700;
            margin-bottom: 0.9rem;
        }
        .bulletin-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 0.8rem;
        }
        .bulletin-card {
            background: #fff;
            border: 1px solid rgba(81,127,164,0.14);
            border-radius: 0.95rem;
            padding: 0.9rem 1rem;
        }
        .bulletin-label {
            font-size: 0.74rem;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #6c757d;
            font-weight: 700;
            margin-bottom: 0.35rem;
        }
        .bulletin-value {
            font-size: 1rem;
            font-weight: 700;
            color: var(--brand-dark);
        }
        .bulletin-note {
            font-size: 0.84rem;
            color: #607388;
            margin-top: 0.18rem;
        }
        .bulletin-list {
            margin: 0;
            padding-left: 1rem;
            color: #607388;
        }
        .bulletin-list li + li {
            margin-top: 0.35rem;
        }
        .bulletin-ok {
            color: #157347;
        }
        .bulletin-warn {
            color: #9a6700;
        }
        .settings-group {
            background: rgba(255,255,255,0.86);
            border: 1px solid rgba(81,127,164,0.15);
            border-radius: 1.15rem;
            box-shadow: 0 10px 26px rgba(33,57,93,0.08);
            padding: 1.25rem 1.25rem 1.4rem;
            margin-bottom: 1.4rem;
        }
        .settings-group-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
            margin-bottom: 1rem;
            padding-bottom: 0.8rem;
            border-bottom: 1px solid rgba(81,127,164,0.14);
        }
        .settings-group-title {
            display: flex;
            align-items: center;
            gap: 0.7rem;
            font-size: 1.08rem;
            font-weight: 700;
            color: var(--brand-dark);
            margin: 0;
        }
        .settings-group-title i {
            color: var(--brand-blue);
        }
        .settings-group-note {
            font-size: 0.93rem;
            color: #6c757d;
            margin: 0;
        }
        .card-hover:hover {
            box-shadow: 0 0 8px var(--brand-blue);
            border-color: var(--brand-blue);
            transition: 0.2s;
        }
        .settings-card-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--brand-dark);
        }
        .settings-card-icon {
            font-size: 2.1rem;
            color: var(--brand-blue);
            margin-bottom: 8px;
        }
        .static-card {
            cursor: not-allowed;
            pointer-events: none;
            opacity: 0.7;
        }
        .dashboard-btn-bottom {
            position: fixed;
            left: 28px;
            bottom: 28px;
            z-index: 1060;
            background: #e7f0fd;
            color: var(--brand-blue);
            border: 2px solid #bcdfff;
            box-shadow: 0 5px 16px rgba(33,57,93,0.13);
            border-radius: 50%;
            width: 58px;
            height: 58px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.55em;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
            text-decoration: none;
        }
        .dashboard-btn-bottom:hover, .dashboard-btn-bottom:focus {
            background: #fff2b3;
            color: var(--brand-blue);
            border-color: #ffe599;
        }
        @media (max-width: 900px) {
            .dashboard-header img { width: 40px; height: 40px;}
            .dashboard-header h1 { font-size: 1.1rem;}
        }
        @media (max-width: 600px) {
            .settings-header h2 { font-size: 1.06rem; }
            .dashboard-header h1 { font-size: 0.93rem;}
            .settings-header { margin: 18px 0 16px 0;}
        }
    </style>
</head>
<body>
<?php render_admin_nav('settings', true); ?>
<?php render_school_page_header($schoolName, $schoolLogo); ?>
<div class="container">
    <div class="settings-header">
        <h2><i class="fas fa-cogs"></i> Settings</h2>
        <p class="text-muted mb-0"><?= $isBackupOnlyStaff ? 'Backup access only for this role. Other settings stay under Super Admin control.' : 'Manage system configurations and preferences' ?></p>
    </div>

    <?php if ($settingsActionMessage !== ''): ?>
    <div class="alert alert-<?= htmlspecialchars($settingsActionType) ?> border-0 shadow-sm">
        <?= htmlspecialchars($settingsActionMessage) ?>
    </div>
    <?php endif; ?>

    <section class="bulletin-board">
        <div class="bulletin-title">Command Center</div>
        <div class="bulletin-grid mb-3">
            <div class="bulletin-card">
                <div class="bulletin-label">Active School Year</div>
                <div class="bulletin-value"><?= htmlspecialchars($activeSchoolYear['label'] ?? 'Not Set') ?></div>
                <div class="bulletin-note">Current academic scope</div>
            </div>
            <div class="bulletin-card">
                <div class="bulletin-label">Last Backup</div>
                <div class="bulletin-value <?= $backupHealthy ? 'bulletin-ok' : 'bulletin-warn' ?>"><?= htmlspecialchars((string) ($backupSettings['last_backup_status'] ?? 'Never Run')) ?></div>
                <div class="bulletin-note"><?= htmlspecialchars($backupLastRunText) ?></div>
            </div>
            <?php if (!$isBackupOnlyStaff): ?>
            <div class="bulletin-card">
                <div class="bulletin-label">Upload Storage</div>
                <div class="bulletin-value <?= $uploadReady ? 'bulletin-ok' : 'bulletin-warn' ?>"><?= $uploadReady ? 'Ready' : 'Needs Review' ?></div>
                <div class="bulletin-note">Photos and requirement folders</div>
            </div>
            <div class="bulletin-card">
                <div class="bulletin-label">Smoke Check</div>
                <div class="bulletin-value <?= count($failedChecks) === 0 ? 'bulletin-ok' : 'bulletin-warn' ?>"><?= count($failedChecks) === 0 ? 'Healthy' : 'Needs Review' ?></div>
                <div class="bulletin-note"><?= number_format(count($failedChecks)) ?> failed item(s)</div>
            </div>
            <div class="bulletin-card">
                <div class="bulletin-label">Receipt Registry</div>
                <div class="bulletin-value <?= $receiptReady ? 'bulletin-ok' : 'bulletin-warn' ?>"><?= (int) ($receiptSummary['total_visible'] ?? 0) ?> active booklet(s)</div>
                <div class="bulletin-note">Visible in payment entry</div>
            </div>
            <div class="bulletin-card">
                <div class="bulletin-label">Requirements</div>
                <div class="bulletin-value"><?= number_format($requirementsConfigured) ?> configured</div>
                <div class="bulletin-note">Student checklist items</div>
            </div>
            <?php endif; ?>
        </div>
        <div class="bulletin-card">
            <div class="bulletin-label">Needs Attention</div>
            <?php if ($settingsAlerts): ?>
                <ul class="bulletin-list">
                    <?php foreach ($settingsAlerts as $alert): ?>
                        <li><?= htmlspecialchars($alert) ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <div class="bulletin-value bulletin-ok">All key settings look ready.</div>
                <div class="bulletin-note">No immediate settings issue is flagged right now.</div>
            <?php endif; ?>
        </div>
    </section>

    <?php if ($canAccessBulkPhotoAttachment): ?>
    <section class="settings-group">
        <div class="settings-group-header">
            <div>
                <h3 class="settings-group-title"><i class="fas fa-images"></i> Student Photos</h3>
                <p class="settings-group-note">Review photo matches by school year, grade, and section before any attachment is applied.</p>
            </div>
        </div>
        <div class="row g-4">
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-bulk-photo-attachment.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-images"></i></div>
                        <div class="settings-card-title">Bulk Photo Attachment</div>
                        <div class="text-muted">Scan the configured inbox and review student photo matches. Preview mode only for now.</div>
                    </div>
                </a>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!$isBackupOnlyStaff && ($canAccessSchoolInformation || (!$isLimitedAdminOperator && $canAccessRequirements) || $canAccessFeeGrades || $canAccessSchoolYears || $canAccessSections || $canAccessSectionLocations)): ?>
    <?php if (!$isBackupOnlyStaff): ?>
    <section class="settings-group">
        <div class="settings-group-header">
            <div>
                <h3 class="settings-group-title"><i class="fas fa-school"></i> Academic</h3>
                <p class="settings-group-note">School identity, academic setup, and student-facing configuration.</p>
            </div>
        </div>
        <div class="row g-4">
            <?php if ($canAccessSchoolInformation): ?>
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-school-info.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-school"></i></div>
                        <div class="settings-card-title">School Information</div>
                        <div class="text-muted">Edit school profile, signatories, mission, and receipt footer details.</div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!$isLimitedAdminOperator && $canAccessRequirements): ?>
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-requirements.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-list-check"></i></div>
                        <div class="settings-card-title">Requirements Settings</div>
                        <div class="text-muted">Manage the student requirements checklist used by the detail panel.</div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
            <?php if ($canAccessFeeGrades): ?>
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-fee-grades.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-layer-group"></i></div>
                        <div class="settings-card-title">Fee Grade Settings</div>
                        <div class="text-muted">Manage the grade catalog used by the Fee module from Junior Kindergarten to Grade 12.</div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
            <?php if ($canAccessSchoolYears): ?>
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-school-years.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-calendar-days"></i></div>
                        <div class="settings-card-title">School Years</div>
                        <div class="text-muted">Set the active school year for new registrations and student records.</div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
            <?php if ($canAccessSections): ?>
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-sections.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-diagram-project"></i></div>
                        <div class="settings-card-title">Section Management</div>
                        <div class="text-muted">Manage active sections per grade level and school year for student assignment.</div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
        </div>
    </section>
    <?php endif; ?>

    <section class="settings-group">
        <div class="settings-group-header">
            <div>
                <h3 class="settings-group-title"><i class="fas fa-clipboard-check"></i> Readiness</h3>
                <p class="settings-group-note">Pilot rollout checks, go-live validation, and operational sign-off support.</p>
            </div>
        </div>
        <div class="row g-4">
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-pilot-test.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-clipboard-check"></i></div>
                        <div class="settings-card-title">Pilot Test Checklist</div>
                        <div class="text-muted">Run the final pilot pass with live readiness metrics, checklist steps, and issue notes.</div>
                    </div>
                </a>
            </div>
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-smoke-check.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-heart-pulse"></i></div>
                        <div class="settings-card-title">Smoke Check</div>
                        <div class="text-muted">Run a quick system health check for core tables, columns, and readiness signals.</div>
                    </div>
                </a>
            </div>
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-deployment-readiness.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-server"></i></div>
                        <div class="settings-card-title">Deployment Readiness</div>
                        <div class="text-muted">Check environment mode, config source, backup path, and final go-live reminders.</div>
                    </div>
                </a>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if ($canAccessReceiptRegistry || $canAccessAccountFollowupTemplates || $canAccessFinanceAdjustments || $canAccessBackupSettings || $canAccessUploadStorage): ?>
    <section class="settings-group">
        <div class="settings-group-header">
            <div>
                <h3 class="settings-group-title"><i class="fas fa-coins"></i> <?= $isBackupOnlyStaff ? 'Backup Access' : 'Finance' ?></h3>
                <p class="settings-group-note"><?= $isBackupOnlyStaff ? 'Create manual backups, download recent files, and review the latest backup status without touching restore or schedule settings.' : 'Receipt control, backup operations, file storage, and finance-adjacent system safeguards.' ?></p>
            </div>
        </div>
        <div class="row g-4">
            <?php if (!$isBackupOnlyStaff && $canAccessReceiptRegistry): ?>
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-receipt-registry.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-receipt"></i></div>
                        <div class="settings-card-title">Receipt Registry</div>
                        <div class="text-muted">Track booklet ranges, used receipts, and voided entries.</div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
            <?php if ($canAccessSectionLocations): ?>
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-section-locations.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-location-dot"></i></div>
                        <div class="settings-card-title">Section Locations</div>
                        <div class="text-muted">Assign adviser, building, floor, and room for each grade section.</div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!$isBackupOnlyStaff && $canAccessAccountFollowupTemplates): ?>
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-account-followup-templates.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-clipboard-list"></i></div>
                        <div class="settings-card-title">Account Follow-up Templates</div>
                        <div class="text-muted">Manage checklist buttons shown in the Payment Desk reminder panel.</div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!$isBackupOnlyStaff && $canAccessFinanceAdjustments): ?>
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-finance-adjustments.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-tags"></i></div>
                        <div class="settings-card-title">Finance Adjustment Templates</div>
                        <div class="text-muted">Manage voucher, subsidy, discount, and grant shortcuts for student finance exceptions.</div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
            <?php if ($canAccessBackupSettings): ?>
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-backup-restore.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-database"></i></div>
                        <div class="settings-card-title">Backup & Restore</div>
                        <div class="text-muted">Backup or restore data.</div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
            <?php if ($canAccessBackupSchedule): ?>
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-backup-schedule.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-clock"></i></div>
                        <div class="settings-card-title">Backup Schedule Settings</div>
                        <div class="text-muted">Manage backup timing, retention, and last-run status.</div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
            <?php if (!$isBackupOnlyStaff && $canAccessUploadStorage): ?>
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-upload-storage.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-folder-tree"></i></div>
                        <div class="settings-card-title">Upload Storage</div>
                        <div class="text-muted">Manage student photo and requirement-document folders, file-size rules, and photo optimization.</div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!$isBackupOnlyStaff && !$isLimitedAdminOperator && ($canManageUsers || $canAccessAuditSettings)): ?>
    <section class="settings-group">
        <div class="settings-group-header">
            <div>
                <h3 class="settings-group-title"><i class="fas fa-shield-halved"></i> Security</h3>
                <p class="settings-group-note">User access, permissions, audit oversight, and system accountability.</p>
            </div>
        </div>
        <div class="row g-4">
            <?php if ($canManageUsers): ?>
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-roles.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-user-shield"></i></div>
                        <div class="settings-card-title">User Roles & Permissions</div>
                        <div class="text-muted">Assign roles and manage access.</div>
                    </div>
                </a>
            </div>
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-admin-users.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-users-cog"></i></div>
                        <div class="settings-card-title">Admin & User Management</div>
                        <div class="text-muted">Manage admin accounts and users.</div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
            <?php if ($canAccessAuditSettings): ?>
            <div class="col-12 col-md-6 col-lg-4">
                <a href="../audit/settings-security-audit.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-shield-alt"></i></div>
                        <div class="settings-card-title">Audit & Security</div>
                        <div class="text-muted">Login history, security settings.</div>
                    </div>
                </a>
            </div>
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-audit-retention.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-hourglass-half"></i></div>
                        <div class="settings-card-title">Audit Retention Settings</div>
                        <div class="text-muted">Manage live audit retention, archive review frequency, and default archive cutoff.</div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!$isBackupOnlyStaff && $canAccessDuplicateCleanup): ?>
    <section class="settings-group">
        <div class="settings-group-header">
            <div>
                <h3 class="settings-group-title"><i class="fas fa-screwdriver-wrench"></i> Maintenance</h3>
                <p class="settings-group-note">Controlled cleanup tools for exceptional data repair and historical fixes.</p>
            </div>
        </div>
        <div class="row g-4">
            <div class="col-12 col-md-6 col-lg-4">
                <a href="settings-maintenance.php" class="card card-hover text-decoration-none text-dark h-100">
                    <div class="card-body text-center">
                        <div class="settings-card-icon"><i class="fas fa-screwdriver-wrench"></i></div>
                        <div class="settings-card-title">Maintenance Tools</div>
                        <div class="text-muted">Open controlled cleanup and repair tools in a separate maintenance workspace.</div>
                    </div>
                </a>
            </div>
            <?php if ($isSuperAdmin): ?>
            <div class="col-12 col-md-6 col-lg-4">
                <div class="card h-100 border-warning-subtle shadow-sm">
                    <div class="card-body text-center d-flex flex-column">
                        <button
                            type="button"
                            class="btn w-100 text-start p-0 border-0 bg-transparent shadow-none"
                            data-bs-toggle="collapse"
                            data-bs-target="#rolloverResetCardBody"
                            aria-expanded="false"
                            aria-controls="rolloverResetCardBody"
                        >
                            <div class="d-flex align-items-start justify-content-between gap-3">
                                <div>
                                    <div class="settings-card-icon text-warning"><i class="fas fa-rotate-left"></i></div>
                                    <div class="settings-card-title">Reset Year-End Rollover Log</div>
                                    <div class="text-muted mb-1">Clear stale rollover tracking rows when you upload an older database and want the rollover status back to zero.</div>
                                    <div class="small text-muted">This resets the log table only. It does not delete actual student or old account records.</div>
                                </div>
                                <span class="text-warning pt-2"><i class="fas fa-chevron-down"></i></span>
                            </div>
                        </button>

                        <div id="rolloverResetCardBody" class="collapse w-100 text-start mt-3">
                        <div class="border rounded-4 p-3 bg-light-subtle text-start mb-3">
                            <div class="fw-semibold text-dark mb-2">Reset Selected Cycle</div>
                            <div class="small text-muted mb-3">Use this when only one source-to-target rollover pair needs to go back to zero.</div>
                            <form method="post" onsubmit="return confirm('Reset the selected Year-End Rollover cycle now? This removes only the chosen source and target log rows.');">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($settingsCsrfToken) ?>">
                                <label for="rollover_cycle" class="form-label small text-muted fw-semibold">Recorded Rollover Cycle</label>
                                <select id="rollover_cycle" name="rollover_cycle" class="form-select mb-2" required <?= $rolloverCycleOptions ? '' : 'disabled' ?>>
                                    <option value=""><?= $rolloverCycleOptions ? 'Select rollover cycle' : 'No recorded cycles available' ?></option>
                                    <?php foreach ($rolloverCycleOptions as $cycleOption): ?>
                                    <option value="<?= htmlspecialchars($cycleOption['key']) ?>" <?= $selectedRolloverCycle === $cycleOption['key'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($cycleOption['label']) ?> (<?= number_format((int) $cycleOption['total_rows']) ?> rows)
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                                <label for="confirm_admin_password_cycle" class="form-label small text-muted fw-semibold">Confirm Super Admin Password</label>
                                <input
                                    type="password"
                                    id="confirm_admin_password_cycle"
                                    name="confirm_admin_password"
                                    class="form-control mb-2"
                                    autocomplete="current-password"
                                    required
                                    placeholder="Enter your current password"
                                >
                                <?php if (!$rolloverCycleOptions): ?>
                                <div class="alert alert-secondary small py-2 px-3 mb-3">
                                    No recorded rollover cycles exist in the log yet, so there is nothing to reset by cycle right now.
                                </div>
                                <?php endif; ?>
                                <div class="small text-muted mb-1">
                                    Matching log rows for this recorded cycle:
                                    <strong><?= number_format((int) ($selectedRolloverCycleMeta['total_rows'] ?? 0)) ?></strong>
                                </div>
                                <?php if (!empty($selectedRolloverCycleMeta['last_updated_at'])): ?>
                                <div class="small text-muted mb-3">
                                    Last updated: <?= htmlspecialchars(date('M j, Y g:i A', strtotime((string) $selectedRolloverCycleMeta['last_updated_at']))) ?>
                                </div>
                                <?php else: ?>
                                <div class="small text-muted mb-3">Select a recorded rollover cycle to view how many log rows will be affected.</div>
                                <?php endif; ?>
                                <?php if ($selectedRolloverCycle !== '' && $selectedRolloverCycleRows === 0): ?>
                                <div class="alert alert-secondary small py-2 px-3 mb-3">
                                    Nothing to reset for this recorded cycle right now. The button stays disabled until log rows exist for the selected rollover pair.
                                </div>
                                <?php endif; ?>
                                <button type="submit" name="reset_rollover_cycle" value="1" class="btn btn-outline-warning w-100" <?= (!$rolloverCycleOptions || $selectedRolloverCycleRows === 0) ? 'disabled' : '' ?>>
                                    <i class="fas fa-rotate-left me-2"></i>Reset Selected Cycle
                                </button>
                            </form>
                        </div>

                        <div class="border rounded-4 p-3 text-start mt-auto">
                            <div class="fw-semibold text-dark mb-2">Full Reset All Logs</div>
                            <div class="small text-muted mb-3">Use this only when the whole rollover log should be wiped, such as after loading a fully older database snapshot.</div>
                            <form method="post" onsubmit="return confirm('Reset the entire Year-End Rollover log now? This will remove all rollover tracking rows for every school-year cycle.');">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($settingsCsrfToken) ?>">
                                <label for="confirm_admin_password_all" class="form-label small text-muted fw-semibold">Confirm Super Admin Password</label>
                                <input
                                    type="password"
                                    id="confirm_admin_password_all"
                                    name="confirm_admin_password"
                                    class="form-control mb-2"
                                    autocomplete="current-password"
                                    required
                                    placeholder="Enter your current password"
                                >
                                <button type="submit" name="reset_rollover_log" value="1" class="btn btn-outline-danger w-100">
                                    <i class="fas fa-triangle-exclamation me-2"></i>Reset All Rollover Logs
                                </button>
                            </form>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </section>
    <?php endif; ?>
</div>
<footer class="text-center py-4 text-muted small">
    &copy; <?= date("Y") ?> <?= htmlspecialchars($schoolName) ?> | School Admin Dashboard
</footer>
<a href="/school-admin-dashboard/dashboard.php" class="dashboard-btn-bottom" title="Go to Dashboard">
    <i class="fas fa-tachometer-alt"></i>
</a>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Theme toggle
    document.getElementById('themeToggleBtn').addEventListener('click', function() {
        document.body.classList.toggle('dark-mode');
        this.querySelector('i').classList.toggle('fa-moon');
        this.querySelector('i').classList.toggle('fa-sun');
    });
</script>
<?= admin_session_warning_script() ?>
</body>
</html>
<?php $conn->close(); ?>
