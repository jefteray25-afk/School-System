<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require '../../config/database.php';
require_once 'settings-permissions-roles.php';
require_once 'settings-security.php';
require_once 'school-info-helper.php';
require_once 'upload-storage-helper.php';
include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');

$userRole = $_SESSION['role'] ?? '';
$username = $_SESSION['username'] ?? '';
if (!can_access_settings_page($userRole, 'upload_storage')) {
    header('Location: /school-admin-dashboard/modules/settings/settings-dashboard.php?error=restricted');
    exit();
}

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);

upload_storage_ensure_table($conn);
upload_storage_ensure_directories($conn);
ensure_csrf_token();

$bulkPhotoSchemaReady = upload_storage_bulk_photo_schema_ready($conn);

$message = '';
$messageType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_upload_storage'])) {
    admin_require_post_csrf();
    $confirmPhrase = trim((string) ($_POST['critical_confirm_phrase'] ?? ''));
    if ($confirmPhrase !== 'CONFIRM') {
        $message = 'Type CONFIRM before saving upload storage settings.';
        $messageType = 'danger';
    } elseif (!$bulkPhotoSchemaReady) {
        $message = 'Bulk Photo Attachment storage is not ready yet. Run the server migration before saving these settings.';
        $messageType = 'danger';
    } else {
    $payload = [
        'student_photo_dir' => $_POST['student_photo_dir'] ?? '',
        'bulk_photo_inbox_dir' => $_POST['bulk_photo_inbox_dir'] ?? '',
        'bulk_photo_staging_dir' => $_POST['bulk_photo_staging_dir'] ?? '',
        'bulk_photo_quarantine_dir' => $_POST['bulk_photo_quarantine_dir'] ?? '',
        'bulk_photo_source_max_mb' => $_POST['bulk_photo_source_max_mb'] ?? 5,
        'bulk_photo_source_max_width' => $_POST['bulk_photo_source_max_width'] ?? 5000,
        'bulk_photo_source_max_height' => $_POST['bulk_photo_source_max_height'] ?? 5000,
        'requirement_document_dir' => $_POST['requirement_document_dir'] ?? '',
        'student_photo_max_mb' => $_POST['student_photo_max_mb'] ?? 2,
        'requirement_document_max_mb' => $_POST['requirement_document_max_mb'] ?? 10,
        'student_photo_max_width' => $_POST['student_photo_max_width'] ?? 1600,
        'student_photo_max_height' => $_POST['student_photo_max_height'] ?? 1600,
        'student_photo_jpeg_quality' => $_POST['student_photo_jpeg_quality'] ?? 85,
    ];

    if (upload_storage_save($conn, $payload)) {
        $message = 'Upload storage settings updated successfully.';
        audit_log(
            $conn,
            $username,
            'Updated upload storage settings',
            'Settings',
            'Photo dir: ' . trim((string) $payload['student_photo_dir']) . ' | Bulk inbox: ' . trim((string) $payload['bulk_photo_inbox_dir']) . ' | Bulk source max: ' . (int) $payload['bulk_photo_source_max_mb'] . 'MB | Requirement dir: ' . trim((string) $payload['requirement_document_dir']) . ' | Photo max: ' . (int) $payload['student_photo_max_mb'] . 'MB | Requirement max: ' . (int) $payload['requirement_document_max_mb'] . 'MB',
            'INFO'
        );
    } else {
        $message = 'Upload storage settings could not be saved.';
        $messageType = 'danger';
    }
    }
}

$settings = upload_storage_get($conn);
$photoDirReady = is_dir($settings['student_photo_dir']) && is_writable($settings['student_photo_dir']);
$bulkInboxReady = is_dir($settings['bulk_photo_inbox_dir']) && is_writable($settings['bulk_photo_inbox_dir']);
$bulkStagingReady = is_dir($settings['bulk_photo_staging_dir']) && is_writable($settings['bulk_photo_staging_dir']);
$bulkQuarantineReady = is_dir($settings['bulk_photo_quarantine_dir']) && is_writable($settings['bulk_photo_quarantine_dir']);
$requirementDirReady = is_dir($settings['requirement_document_dir']) && is_writable($settings['requirement_document_dir']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Storage Settings - School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body { background: var(--main-bg); font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif; }
        .navbar { background: var(--navbar-bg) !important; box-shadow: 0 2px 12px rgba(33,57,93,0.08); }
        .navbar-brand, .navbar-nav .nav-link { color: #fff !important; font-size: 1.08em; }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .dashboard-header { text-align: center; margin-top: 36px; margin-bottom: 18px; }
        .dashboard-header img { width: 70px; height: 70px; object-fit: contain; margin-bottom: 6px; }
        .dashboard-header h1 { font-size: 1.3rem; color: var(--brand-dark); font-weight: 700; margin-bottom: 0; }
        .page-title { color: var(--brand-dark); font-weight: 700; }
        .section-card {
            background: var(--card-bg);
            border: 1px solid rgba(81, 127, 164, 0.15);
            border-radius: 1rem;
            box-shadow: 0 4px 18px rgba(33, 57, 93, 0.07);
            margin-bottom: 1.25rem;
        }
        .summary-stat {
            background: #f8fbff;
            border: 1px solid rgba(81, 127, 164, 0.16);
            border-radius: 1rem;
            padding: 1rem 1.1rem;
            height: 100%;
        }
        .summary-stat .label { text-transform: uppercase; font-size: 0.74rem; color: #6c757d; font-weight: 700; }
        .summary-stat .value { font-size: 1.05rem; font-weight: 700; color: var(--brand-dark); word-break: break-word; }
        .note-box {
            border-left: 4px solid #0d6efd;
            background: #f8fbff;
            padding: 0.9rem 1rem;
            border-radius: 0.5rem;
        }
    </style>
</head>
<body>
<?php render_admin_nav('settings'); ?>

<?php render_school_page_header($schoolName, $schoolLogo); ?>

<div class="container pb-5">
    <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-4">
        <div>
            <h2 class="page-title mb-1"><i class="fas fa-folder-tree me-2"></i>Upload Storage Settings</h2>
            <p class="text-muted mb-0">Control where student photos and requirement documents are stored, plus the size and optimization rules used during upload.</p>
        </div>
        <a href="/school-admin-dashboard/modules/settings/settings-dashboard.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back to Settings
        </a>
    </div>

    <?php if ($message !== ''): ?>
        <div class="alert alert-<?= htmlspecialchars($messageType) ?>"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <?php if (!$bulkPhotoSchemaReady): ?>
        <div class="alert alert-warning">
            <strong>Bulk Photo Attachment foundation is waiting for migration.</strong>
            Run <code>php tools/migrate.php</code> on the server before saving bulk-photo directory settings. Existing student photo uploads remain unchanged.
        </div>
    <?php endif; ?>

    <div class="row g-3 mb-4">
        <div class="col-12 col-md-3">
            <div class="summary-stat">
                <div class="label">Student Photo Folder</div>
                <div class="value"><?= $photoDirReady ? 'Ready' : 'Needs Attention' ?></div>
            </div>
        </div>
        <div class="col-12 col-md-3">
            <div class="summary-stat">
                <div class="label">Requirement Folder</div>
                <div class="value"><?= $requirementDirReady ? 'Ready' : 'Needs Attention' ?></div>
            </div>
        </div>
        <div class="col-12 col-md-3">
            <div class="summary-stat">
                <div class="label">Photo Limit</div>
                <div class="value"><?= (int) $settings['student_photo_max_mb'] ?> MB</div>
            </div>
        </div>
        <div class="col-12 col-md-3">
            <div class="summary-stat">
                <div class="label">Requirement Limit</div>
                <div class="value"><?= (int) $settings['requirement_document_max_mb'] ?> MB</div>
            </div>
        </div>
        <div class="col-12 col-md-4">
            <div class="summary-stat">
                <div class="label">Bulk Photo Inbox</div>
                <div class="value"><?= $bulkInboxReady ? 'Ready' : 'Needs Attention' ?></div>
            </div>
        </div>
        <div class="col-12 col-md-4">
            <div class="summary-stat">
                <div class="label">Bulk Photo Staging</div>
                <div class="value"><?= $bulkStagingReady ? 'Ready' : 'Needs Attention' ?></div>
            </div>
        </div>
        <div class="col-12 col-md-4">
            <div class="summary-stat">
                <div class="label">Bulk Photo Quarantine</div>
                <div class="value"><?= $bulkQuarantineReady ? 'Ready' : 'Needs Attention' ?></div>
            </div>
        </div>
    </div>

    <div class="section-card p-4">
        <h5 class="mb-3">Storage Policy</h5>
        <form method="post">
            <?= csrf_input() ?>
            <input type="hidden" name="save_upload_storage" value="1">
            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label" for="student_photo_dir">Student photo directory</label>
                    <input type="text" class="form-control" name="student_photo_dir" id="student_photo_dir" value="<?= htmlspecialchars($settings['student_photo_dir']) ?>">
                    <div class="form-text">You can point this to another SSD. Existing photos should be copied to the same relative folders if you change this path.</div>
                </div>
                <div class="col-12"><hr class="my-1"></div>
                <div class="col-12">
                    <h6 class="mb-1">Bulk Photo Attachment Storage</h6>
                    <div class="form-text mt-0">For privacy, configure these folders outside the web root, for example <code>D:\School Admin Storage\</code>. The future Bulk Photo Attachment page will scan the inbox, stage files for review, and isolate uncertain files in quarantine.</div>
                </div>
                <div class="col-12">
                    <label class="form-label" for="bulk_photo_inbox_dir">Bulk photo inbox directory</label>
                    <input type="text" class="form-control" name="bulk_photo_inbox_dir" id="bulk_photo_inbox_dir" value="<?= htmlspecialchars($settings['bulk_photo_inbox_dir']) ?>" <?= !$bulkPhotoSchemaReady ? 'disabled' : '' ?>>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="bulk_photo_staging_dir">Bulk photo staging directory</label>
                    <input type="text" class="form-control" name="bulk_photo_staging_dir" id="bulk_photo_staging_dir" value="<?= htmlspecialchars($settings['bulk_photo_staging_dir']) ?>" <?= !$bulkPhotoSchemaReady ? 'disabled' : '' ?>>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="bulk_photo_quarantine_dir">Bulk photo quarantine directory</label>
                    <input type="text" class="form-control" name="bulk_photo_quarantine_dir" id="bulk_photo_quarantine_dir" value="<?= htmlspecialchars($settings['bulk_photo_quarantine_dir']) ?>" <?= !$bulkPhotoSchemaReady ? 'disabled' : '' ?>>
                </div>
                <div class="col-md-4">
                    <label class="form-label" for="bulk_photo_source_max_mb">Bulk source max size (MB)</label>
                    <input type="number" class="form-control" name="bulk_photo_source_max_mb" id="bulk_photo_source_max_mb" min="1" max="25" value="<?= (int) $settings['bulk_photo_source_max_mb'] ?>" <?= !$bulkPhotoSchemaReady ? 'disabled' : '' ?>>
                </div>
                <div class="col-md-4">
                    <label class="form-label" for="bulk_photo_source_max_width">Bulk source max width</label>
                    <input type="number" class="form-control" name="bulk_photo_source_max_width" id="bulk_photo_source_max_width" min="600" max="8000" value="<?= (int) $settings['bulk_photo_source_max_width'] ?>" <?= !$bulkPhotoSchemaReady ? 'disabled' : '' ?>>
                </div>
                <div class="col-md-4">
                    <label class="form-label" for="bulk_photo_source_max_height">Bulk source max height</label>
                    <input type="number" class="form-control" name="bulk_photo_source_max_height" id="bulk_photo_source_max_height" min="600" max="8000" value="<?= (int) $settings['bulk_photo_source_max_height'] ?>" <?= !$bulkPhotoSchemaReady ? 'disabled' : '' ?>>
                </div>
                <div class="col-12">
                    <label class="form-label" for="requirement_document_dir">Requirement document directory</label>
                    <input type="text" class="form-control" name="requirement_document_dir" id="requirement_document_dir" value="<?= htmlspecialchars($settings['requirement_document_dir']) ?>">
                    <div class="form-text">Requirement files are served through the app, so this can also live outside the web root.</div>
                </div>
                <div class="col-md-3">
                    <label class="form-label" for="student_photo_max_mb">Student photo max size (MB)</label>
                    <input type="number" class="form-control" name="student_photo_max_mb" id="student_photo_max_mb" min="1" max="10" value="<?= (int) $settings['student_photo_max_mb'] ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label" for="requirement_document_max_mb">Requirement file max size (MB)</label>
                    <input type="number" class="form-control" name="requirement_document_max_mb" id="requirement_document_max_mb" min="1" max="25" value="<?= (int) $settings['requirement_document_max_mb'] ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label" for="student_photo_max_width">Photo max width</label>
                    <input type="number" class="form-control" name="student_photo_max_width" id="student_photo_max_width" min="600" max="5000" value="<?= (int) $settings['student_photo_max_width'] ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label" for="student_photo_max_height">Photo max height</label>
                    <input type="number" class="form-control" name="student_photo_max_height" id="student_photo_max_height" min="600" max="5000" value="<?= (int) $settings['student_photo_max_height'] ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label" for="student_photo_jpeg_quality">JPEG quality</label>
                    <input type="number" class="form-control" name="student_photo_jpeg_quality" id="student_photo_jpeg_quality" min="60" max="95" value="<?= (int) $settings['student_photo_jpeg_quality'] ?>">
                </div>
                <div class="col-12">
                    <label class="form-label" for="critical_confirm_phrase">Type CONFIRM to proceed</label>
                    <input type="text" class="form-control" name="critical_confirm_phrase" id="critical_confirm_phrase" placeholder="CONFIRM" autocomplete="off">
                    <div class="form-text text-danger">Required because changing upload paths can affect student photos and requirement files across the whole system.</div>
                </div>
            </div>
            <div class="text-end mt-3">
                <button type="submit" class="btn btn-primary" onclick="return confirm('Save upload storage settings?');">
                    <i class="fas fa-save me-1"></i>Save Upload Storage
                </button>
            </div>
        </form>
    </div>

    <div class="section-card p-4">
        <h5 class="mb-3">Behavior Notes</h5>
        <div class="row g-3">
            <div class="col-12 col-lg-6">
                <div class="note-box h-100">
                    <div class="fw-semibold mb-2">Student photos</div>
                    <div class="small text-muted">Photos are the only uploads that get optimized on save. Large images are resized to the configured width and height while keeping aspect ratio, which helps save storage without hurting profile-view quality.</div>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div class="note-box h-100">
                    <div class="fw-semibold mb-2">Requirement documents</div>
                    <div class="small text-muted">Requirement files keep their original clarity so scanned forms and IDs stay readable. The app enforces the size limit, but it does not downscale those documents automatically.</div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
