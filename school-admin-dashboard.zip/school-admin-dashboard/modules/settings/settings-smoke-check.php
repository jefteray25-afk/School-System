<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/app-env.php';
require_once __DIR__ . '/settings-permissions-roles.php';
require_once __DIR__ . '/school-info-helper.php';
require_once __DIR__ . '/../../tools/smoke-core.php';

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';

if (!can_view_settings_module($role)) {
    header('Location: /school-admin-dashboard/dashboard.php?error=settings_denied');
    exit();
}
if (is_specialized_staff_role($role)) {
    header('Location: /school-admin-dashboard/modules/settings/settings-dashboard.php?error=restricted');
    exit();
}

$checks = school_admin_smoke_checks($conn);
$failedChecks = school_admin_smoke_failed_checks($checks);
$passCount = count($checks) - count($failedChecks);
$reportText = school_admin_smoke_report_text($checks);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smoke Check | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background:#f5f8fc; font-family:'Segoe UI','Roboto','Arial',sans-serif; }
        .navbar { background:#23395d !important; }
        .navbar-brand, .navbar-nav .nav-link { color:#fff !important; }
        .page-wrap { max-width:1100px; margin:30px auto; padding:0 12px; }
        .hero, .panel { background:#fff; border:1px solid #dce8f7; border-radius:18px; box-shadow:0 8px 24px rgba(33,57,93,.08); }
        .hero { padding:22px 24px; margin-bottom:18px; }
        .panel { padding:18px; }
        .summary-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:14px; margin-bottom:18px; }
        .summary-card { background:#fff; border:1px solid #dce8f7; border-radius:16px; padding:16px; box-shadow:0 8px 24px rgba(33,57,93,.06); }
        .summary-label { font-size:.78rem; text-transform:uppercase; letter-spacing:.05em; color:#607388; font-weight:700; }
        .summary-value { font-size:1.45rem; font-weight:800; color:#23395d; }
        .check-row { display:flex; justify-content:space-between; gap:12px; align-items:flex-start; padding:10px 0; border-bottom:1px solid #edf3fb; }
        .check-row:last-child { border-bottom:none; }
        .status-pass { color:#198754; font-weight:700; }
        .status-fail { color:#dc3545; font-weight:700; }
        pre { white-space:pre-wrap; word-break:break-word; }
    </style>
</head>
<body>
<?php render_admin_nav('settings'); ?>

<div class="page-wrap">
    <div class="hero">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
            <div>
                <h1 class="h4 mb-1"><i class="fas fa-heart-pulse me-2"></i>System Smoke Check</h1>
                <div class="text-muted">Quick health check for the current deployment before pilot or go-live review.</div>
                <div class="small text-muted mt-2"><?= htmlspecialchars($schoolName) ?></div>
            </div>
            <a href="/school-admin-dashboard/tools/smoke-core.php" class="btn btn-outline-primary btn-sm" target="_blank">
                <i class="fas fa-terminal me-1"></i>Open Plain Report
            </a>
        </div>
    </div>

    <div class="summary-grid">
        <div class="summary-card">
            <div class="summary-label">Passed</div>
            <div class="summary-value"><?= number_format($passCount) ?></div>
        </div>
        <div class="summary-card">
            <div class="summary-label">Failed</div>
            <div class="summary-value"><?= number_format(count($failedChecks)) ?></div>
        </div>
        <div class="summary-card">
            <div class="summary-label">Environment</div>
            <div class="summary-value"><?= htmlspecialchars(app_env_label()) ?></div>
        </div>
        <div class="summary-card">
            <div class="summary-label">Readiness</div>
            <div class="summary-value"><?= count($failedChecks) === 0 ? 'Healthy' : 'Needs Review' ?></div>
        </div>
    </div>

    <div class="panel mb-3">
        <h2 class="h6 mb-3">Check Results</h2>
        <?php foreach ($checks as $check): ?>
            <div class="check-row">
                <div>
                    <div class="fw-semibold"><?= htmlspecialchars($check['label']) ?></div>
                    <?php if ($check['details'] !== ''): ?>
                        <div class="small text-muted"><?= htmlspecialchars($check['details']) ?></div>
                    <?php endif; ?>
                </div>
                <div class="<?= $check['ok'] ? 'status-pass' : 'status-fail' ?>">
                    <?= $check['ok'] ? 'PASS' : 'FAIL' ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="panel">
        <h2 class="h6 mb-3">Plain Report</h2>
        <pre class="mb-0 small"><?= htmlspecialchars($reportText) ?></pre>
    </div>
</div>
</body>
</html>
<?php $conn->close(); ?>
