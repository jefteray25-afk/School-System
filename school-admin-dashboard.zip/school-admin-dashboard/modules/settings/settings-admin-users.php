<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();

include __DIR__ . '/../../config/database.php';
require_once 'settings-security.php';
require_once 'settings-permissions-roles.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

$currentUsername = $_SESSION['username'] ?? '';
$currentRole = $_SESSION['role'] ?? '';
if (!can_access_user_management_settings($currentRole)) {
    audit_log(
        $conn,
        $currentUsername !== '' ? $currentUsername : 'unknown',
        'Blocked settings admin users access',
        'Settings',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing user management settings permission',
        'SECURITY'
    );
    header('Location: /school-admin-dashboard/dashboard.php?error=settings_denied');
    exit();
}

$users = [];
$sql = 'SELECT id, username, role, email FROM admins';
if ($result = $conn->query($sql)) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
    $result->free();
} else {
    die('Database query failed: ' . $conn->error);
}

ensure_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin & User Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        .header { margin: 36px 0 28px 0; text-align: center; }
        .header h2 { font-weight: bold; color: #23395d; }
        .table-responsive { margin-top: 24px; }
        .btn-action { margin-right: 6px; }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h2><i class="fas fa-users-cog"></i> Admin & User Management</h2>
        <p class="text-muted">Manage admin and user accounts</p>
    </div>
    <div class="mb-3 text-end">
        <?php if ($currentRole === 'Super Administrator'): ?>
            <a href="settings-add-new.php" class="btn btn-success"><i class="fas fa-user-plus"></i> Add New User</a>
            <a href="settings-roles.php" class="btn btn-warning ms-2"><i class="fas fa-id-badge"></i> User Roles & Permissions</a>
        <?php endif; ?>
    </div>
    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-primary">
                <tr>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <?php
                    if (($currentRole === 'Administrator 1' || $currentRole === 'Administrator 2') && $user['role'] === 'Super Administrator') {
                        continue;
                    }
                    ?>
                    <tr>
                        <td><?= htmlspecialchars($user['username']) ?></td>
                        <td>
                            <?= htmlspecialchars($user['role']) ?>
                            <?php if ($user['role'] === 'Super Administrator'): ?>
                                <span class="badge bg-warning text-dark ms-1">Master</span>
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($user['email']) ?></td>
                        <td><span class="text-muted">Hidden</span></td>
                        <td>
                            <?php if ($currentRole === 'Super Administrator'): ?>
                                <a href="settings-edit.php?id=<?= urlencode((string) $user['id']) ?>" class="btn btn-sm btn-primary btn-action"><i class="fas fa-edit"></i> Edit / Reset</a>
                                <?php if ($user['username'] !== $currentUsername): ?>
                                    <a href="settings-delete.php?id=<?= urlencode((string) $user['id']) ?>" class="btn btn-sm btn-danger btn-action"><i class="fas fa-trash"></i> Delete</a>
                                <?php else: ?>
                                    <span class="text-muted">Protected</span>
                                <?php endif; ?>
                            <?php elseif ($currentRole === 'Administrator 1' || $currentRole === 'Administrator 2'): ?>
                                <?php if ($user['username'] === $currentUsername): ?>
                                    <a href="settings-edit.php?id=<?= urlencode((string) $user['id']) ?>" class="btn btn-sm btn-primary btn-action"><i class="fas fa-edit"></i> Edit</a>
                                <?php else: ?>
                                    <span class="text-muted">No Access</span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="mt-5">
        <a href="settings-dashboard.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Settings</a>
    </div>
</div>
</body>
</html>
