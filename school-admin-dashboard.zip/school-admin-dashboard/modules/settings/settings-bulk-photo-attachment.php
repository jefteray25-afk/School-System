<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/settings-permissions-roles.php';
require_once __DIR__ . '/school-info-helper.php';
require_once __DIR__ . '/school-year-helper.php';
require_once __DIR__ . '/section-management-helper.php';
require_once __DIR__ . '/upload-storage-helper.php';
require_once __DIR__ . '/../students/student-photo-bulk-helper.php';
require_once __DIR__ . '/../audit/audit-helper.php';

function bulk_photo_section_name($item): string
{
    return is_array($item) ? trim((string) ($item['section_name'] ?? '')) : trim((string) $item);
}

function bulk_photo_sections_by_grade(mysqli $conn, string $schoolYear): array
{
    $map = section_management_get_sections_by_grade($conn, $schoolYear, true);
    foreach (section_management_grade_options() as $grade) {
        $map[$grade] = $map[$grade] ?? [];
    }

    $defaultYear = school_year_default_label();
    $stmt = $conn->prepare(
        "SELECT DISTINCT grade, section
         FROM students
         WHERE COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?
           AND TRIM(COALESCE(grade, '')) <> ''
           AND TRIM(COALESCE(section, '')) <> ''
         ORDER BY grade ASC, section ASC"
    );
    if (!$stmt) {
        return $map;
    }
    $stmt->bind_param('ss', $defaultYear, $schoolYear);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    foreach ($rows as $row) {
        $grade = trim((string) ($row['grade'] ?? ''));
        $section = trim((string) ($row['section'] ?? ''));
        if (!in_array($grade, section_management_grade_options(), true) || $section === '') {
            continue;
        }
        $known = array_map(static fn($item): string => bulk_photo_section_name($item), $map[$grade]);
        if (!in_array($section, $known, true)) {
            $map[$grade][] = ['section_name' => $section, 'is_active' => 1];
        }
    }

    foreach ($map as &$sections) {
        usort($sections, static fn($a, $b): int => strcasecmp(bulk_photo_section_name($a), bulk_photo_section_name($b)));
    }
    unset($sections);
    return $map;
}

$role = (string) ($_SESSION['role'] ?? '');
if (!can_access_bulk_photo_attachment($role)) {
    admin_session_forbidden();
}

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$schemaReady = upload_storage_bulk_photo_schema_ready($conn);
$settings = upload_storage_get($conn);
$schoolYears = school_year_get_all($conn);
$activeSchoolYear = school_year_get_active_label($conn);
$grades = section_management_grade_options();
$sectionsByGrade = bulk_photo_sections_by_grade($conn, $activeSchoolYear);

$selectedYear = $activeSchoolYear;
$selectedGrade = '';
$selectedSection = '';
$sections = [];
$preview = null;
$scanResult = null;
$batch = null;
$applyResult = null;
$message = '';
$messageType = 'info';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['apply_batch'])) {
    admin_require_post_csrf();
    $batchToken = trim((string) ($_POST['batch_token'] ?? ''));
    if (!$schemaReady || !student_photo_bulk_tables_ready($conn)) {
        $message = 'Bulk photo tables are not ready. Run the server migration first.';
        $messageType = 'danger';
    } else {
        $applyResult = student_photo_bulk_apply_batch(
            $conn,
            $settings,
            $batchToken,
            is_array($_POST['selected_item_ids'] ?? null) ? $_POST['selected_item_ids'] : [],
            is_array($_POST['replacement_item_ids'] ?? null) ? $_POST['replacement_item_ids'] : [],
            (string) ($_SESSION['username'] ?? 'unknown')
        );
        $successCount = count($applyResult['success'] ?? []);
        $errorCount = count($applyResult['errors'] ?? []);
        $message = $successCount . ' photo attachment(s) applied' . ($errorCount ? '; ' . $errorCount . ' item(s) need review.' : '.') ;
        $messageType = $errorCount ? ($successCount ? 'warning' : 'danger') : 'success';
        audit_log($conn, (string) ($_SESSION['username'] ?? 'unknown'), 'Applied bulk student photos', 'Students', 'Batch: ' . $batchToken . ' | Success: ' . $successCount . ' | Errors: ' . $errorCount, $errorCount ? 'WARNING' : 'INFO');
        $batch = student_photo_bulk_load_batch($conn, $batchToken);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['preview_scan'])) {
    admin_require_post_csrf();
    $selectedYear = trim((string) ($_POST['school_year_label'] ?? $activeSchoolYear));
    $selectedGrade = trim((string) ($_POST['grade'] ?? ''));
    $selectedSection = trim((string) ($_POST['section'] ?? ''));
    $sectionsByGrade = bulk_photo_sections_by_grade($conn, $selectedYear);
    $sections = $selectedGrade !== ''
        ? array_values(array_map(static fn($item): string => bulk_photo_section_name($item), $sectionsByGrade[$selectedGrade] ?? []))
        : [];

    if (!$schemaReady) {
        $message = 'Bulk Photo Attachment storage is not ready. Run the server migration first.';
        $messageType = 'warning';
    } elseif ($selectedYear === '' || !in_array($selectedGrade, $grades, true) || $selectedSection === '') {
        $message = 'Choose a school year, grade level, and section before scanning.';
        $messageType = 'warning';
    } elseif ($selectedSection !== '__unassigned__' && !in_array($selectedSection, $sections, true)) {
        $message = 'Choose an active section for the selected school year and grade.';
        $messageType = 'warning';
    } else {
        $defaultYear = school_year_default_label();
        $isUnassignedScope = $selectedSection === '__unassigned__';
        $studentSql = "SELECT id, lastname, firstname, middlename, lrn, grade, section, school_year_label, photo
             FROM students
             WHERE COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?
               AND grade = ?";
        $studentSql .= $isUnassignedScope
            ? " AND TRIM(COALESCE(section, '')) = ''"
            : ' AND section = ?';
        $studentSql .= ' ORDER BY lastname ASC, firstname ASC, middlename ASC';
        $stmt = $conn->prepare($studentSql);
        $students = [];
        if ($stmt) {
            if ($isUnassignedScope) {
                $stmt->bind_param('sss', $defaultYear, $selectedYear, $selectedGrade);
            } else {
                $stmt->bind_param('ssss', $defaultYear, $selectedYear, $selectedGrade, $selectedSection);
            }
            $stmt->execute();
            $students = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
        }

        $scanResult = student_photo_bulk_scan_scope($settings, $selectedYear, $selectedGrade, $selectedSection);
        $preview = student_photo_bulk_preview($students, $scanResult['files'], $selectedGrade);
        if (($scanResult['error'] ?? '') !== '') {
            $message = $scanResult['error'] . ' Expected folder: ' . $scanResult['directory'];
            $messageType = 'warning';
        } elseif (!$students) {
            $message = 'No students were found in this selected scope. The inbox was scanned but nothing can be matched.';
            $messageType = 'warning';
        } else {
            $batchToken = student_photo_bulk_create_preview_batch($conn, $selectedYear, $selectedGrade, $selectedSection, $preview, (string) ($_SESSION['username'] ?? 'unknown'));
            if ($batchToken === null) {
                $message = 'The preview could not be staged. Confirm that the bulk-photo migration was completed.';
                $messageType = 'danger';
            } else {
                header('Location: settings-bulk-photo-attachment.php?batch=' . rawurlencode($batchToken));
                exit();
            }
        }
    }
}

if ($batch === null && isset($_GET['batch'])) {
    $requestedToken = trim((string) $_GET['batch']);
    $batch = $requestedToken !== '' ? student_photo_bulk_load_batch($conn, $requestedToken) : null;
    if ($batch) {
        $selectedYear = (string) $batch['school_year_label'];
        $selectedGrade = (string) $batch['grade'];
        $selectedSection = (string) ($batch['section'] ?? '');
    }
}

if ($selectedGrade !== '' && !$sections) {
    $sections = array_values(array_map(static fn($item): string => bulk_photo_section_name($item), $sectionsByGrade[$selectedGrade] ?? []));
}

$summary = ['total' => 0, 'matched' => 0, 'missing' => 0, 'duplicate' => 0, 'replacement' => 0, 'unknown' => 0, 'invalid' => 0];
if (is_array($batch)) {
    foreach ($batch['items'] as $item) {
        $status = (string) ($item['match_status'] ?? '');
        if (in_array($status, ['matched', 'missing', 'duplicate', 'replacement_candidate', 'already_attached'], true)) { $summary['total']++; }
        if ($status === 'matched') { $summary['matched']++; }
        if ($status === 'missing') { $summary['missing']++; }
        if ($status === 'duplicate') { $summary['duplicate']++; }
        if ($status === 'replacement_candidate') { $summary['replacement']++; }
        if ($status === 'invalid') { $summary['invalid']++; }
        if ($status === 'unknown') { $summary['unknown']++; }
    }
}

function bulk_photo_status_badge(string $status): string
{
    $map = [
        'matched' => 'success', 'replacement_candidate' => 'warning', 'missing' => 'secondary',
        'duplicate' => 'danger', 'already_attached' => 'primary', 'unknown' => 'dark', 'invalid' => 'danger',
    ];
    return $map[$status] ?? 'secondary';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bulk Photo Attachment - School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --bg:#eef4fb; --ink:#23395d; --muted:#65788d; --line:#d9e5f1; --brand:#517fa4; }
        body { background:var(--bg); font-family:'Segoe UI','Roboto',Arial,sans-serif; color:var(--ink); }
        .dashboard-header { text-align:center; margin:20px 0 16px; }
        .dashboard-header img { width:58px; height:58px; object-fit:contain; margin-bottom:6px; }
        .dashboard-header h1 { margin:0; font-size:1.05rem; font-weight:750; color:var(--ink); }
        .bulk-card { border:1px solid var(--line); border-radius:18px; box-shadow:0 10px 26px rgba(35,57,93,.08); background:#fff; }
        .summary-card { background:#fff; border:1px solid var(--line); border-radius:15px; padding:1rem; height:100%; }
        .summary-label { color:var(--muted); font-size:.73rem; font-weight:700; letter-spacing:.04em; text-transform:uppercase; }
        .summary-value { font-size:1.55rem; font-weight:800; color:var(--ink); }
        .scan-overlay { position:fixed; inset:0; display:none; align-items:center; justify-content:center; padding:1rem; z-index:3000; background:rgba(238,244,251,.75); backdrop-filter:blur(5px); }
        .scan-active .scan-overlay { display:flex; }
        .scan-active main, .scan-active .app-topbar, .scan-active .app-sidebar { filter:blur(2px); pointer-events:none; user-select:none; }
        .scan-card { width:min(420px,100%); padding:1.25rem; border:1px solid var(--line); border-radius:18px; background:rgba(255,255,255,.96); box-shadow:0 22px 55px rgba(35,57,93,.18); }
        .scan-track { height:8px; overflow:hidden; border-radius:999px; background:#e6eef7; margin-top:1rem; }
        .scan-bar { width:42%; height:100%; border-radius:inherit; background:linear-gradient(90deg,#2f74c8,#2f8aa3,#2f7d5a); animation:scan-slide 1.05s ease-in-out infinite; }
        @keyframes scan-slide { 0%{transform:translateX(-110%)}55%{transform:translateX(80%)}100%{transform:translateX(245%)} }
        .filename { font-family:Consolas,monospace; font-size:.8rem; overflow-wrap:anywhere; }
        .table td { vertical-align:middle; }
    </style>
</head>
<body>
<?php render_admin_nav('settings'); ?>
<?php render_school_page_header($schoolName, $schoolLogo); ?>
<main class="container pb-5">
    <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-4">
        <div><h2 class="mb-1"><i class="fas fa-images me-2"></i>Bulk Photo Attachment</h2><p class="text-muted mb-0">Scan, review, and safely apply only the student photo matches you confirm.</p></div>
        <a href="settings-dashboard.php" class="btn btn-outline-secondary"><i class="fas fa-arrow-left me-1"></i>Back to Settings</a>
    </div>
    <?php if (!$schemaReady): ?><div class="alert alert-warning"><strong>Migration required.</strong> Run <code>php tools/migrate.php</code> on the server before using the bulk photo preview.</div><?php endif; ?>
    <?php if ($message !== ''): ?><div class="alert alert-<?= htmlspecialchars($messageType) ?>"><?= htmlspecialchars($message) ?></div><?php endif; ?>
    <section class="bulk-card p-4 mb-4">
        <h5 class="mb-3">1. Select student scope and scan the inbox</h5>
        <form method="post" id="bulkPhotoScanForm">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(admin_csrf_token()) ?>"><input type="hidden" name="preview_scan" value="1">
            <div class="row g-3 align-items-end">
                <div class="col-md-4"><label class="form-label">School Year</label><select class="form-select" name="school_year_label" required><?php foreach ($schoolYears as $year): $label=(string)($year['label']??''); ?><option value="<?= htmlspecialchars($label) ?>" <?= $label===$selectedYear?'selected':'' ?>><?= htmlspecialchars($label) ?></option><?php endforeach; ?></select></div>
                <div class="col-md-4"><label class="form-label">Grade Level</label><select class="form-select" name="grade" id="bulkPhotoGrade" required><option value="">Select grade</option><?php foreach ($grades as $grade): ?><option value="<?= htmlspecialchars($grade) ?>" <?= $grade===$selectedGrade?'selected':'' ?>><?= htmlspecialchars($grade) ?> (<?= htmlspecialchars(student_photo_grade_code($grade)) ?>)</option><?php endforeach; ?></select></div>
                <div class="col-md-4"><label class="form-label">Section</label><select class="form-select" name="section" id="bulkPhotoSection" required><option value="">Select section</option><option value="__unassigned__" <?= $selectedSection==='__unassigned__'?'selected':'' ?>>Unassigned / No Section</option><?php foreach ($sectionsByGrade as $gradeName => $gradeSections): if (!$gradeSections) { continue; } ?><optgroup label="<?= htmlspecialchars($gradeName) ?>"><?php foreach ($gradeSections as $sectionRow): $sectionName=bulk_photo_section_name($sectionRow); ?><option value="<?= htmlspecialchars($sectionName) ?>" <?= $sectionName===$selectedSection?'selected':'' ?>><?= htmlspecialchars($sectionName) ?></option><?php endforeach; ?></optgroup><?php endforeach; ?></select><div class="form-text">Choose the section under the same grade group you selected above.</div></div>
                <div class="col-12"><div class="form-text">Expected inbox layout: <code>{Inbox}/{School-Year}/{Grade-Code}/{Section}/</code>. Example: <code>photo-inbox/SY-2026-2027/jr/a/</code>.</div></div>
                <div class="col-12 text-end"><button type="submit" class="btn btn-primary" <?= !$schemaReady?'disabled':'' ?>><i class="fas fa-magnifying-glass me-1"></i>Scan and Preview</button></div>
            </div>
        </form>
    </section>
    <?php if (is_array($batch)): ?>
        <div class="row g-3 mb-4">
            <?php foreach (['total'=>'Students','matched'=>'Matched','replacement'=>'Replacement review','missing'=>'Missing','duplicate'=>'Duplicate','unknown'=>'Unknown','invalid'=>'Invalid'] as $key=>$label): ?><div class="col-6 col-md-3 col-lg"><div class="summary-card"><div class="summary-label"><?= $label ?></div><div class="summary-value"><?= number_format($summary[$key]) ?></div></div></div><?php endforeach; ?>
        </div>
        <section class="bulk-card p-4 mb-4">
            <div class="d-flex justify-content-between gap-3 flex-wrap"><div><h5 class="mb-1">2. Review and confirm matches</h5><p class="text-muted small mb-0">Matched photos are preselected. Existing photos stay unchanged unless you explicitly approve a replacement.</p></div><span class="badge text-bg-<?= $batch['status']==='staged'?'primary':'secondary' ?> align-self-start"><?= htmlspecialchars(ucwords((string)$batch['status'])) ?></span></div>
            <form method="post" id="bulkPhotoApplyForm" class="mt-3">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(admin_csrf_token()) ?>"><input type="hidden" name="apply_batch" value="1"><input type="hidden" name="batch_token" value="<?= htmlspecialchars((string)$batch['batch_token']) ?>">
                <div class="table-responsive"><table class="table table-hover align-middle"><thead><tr><th>Apply</th><th>Preview</th><th>Student / File</th><th>Detected filename</th><th>Status</th></tr></thead><tbody>
                <?php foreach ($batch['items'] as $item): $status=(string)$item['match_status']; $isEligible=in_array($status,['matched','replacement_candidate'],true); $isReplacement=$status==='replacement_candidate'; $filename=(string)$item['original_filename']; ?>
                    <tr>
                        <td><?php if ($isEligible && $batch['status']==='staged'): ?><input class="form-check-input bulk-item-check" type="checkbox" name="selected_item_ids[]" value="<?= (int)$item['id'] ?>" <?= (int)$item['is_selected']===1?'checked':'' ?> <?= $isReplacement?'data-replacement-item="1"':'' ?>><div class="small text-muted mt-1"><?= $isReplacement?'Review replacement':'' ?></div><?php else: ?>—<?php endif; ?></td>
                        <td><?php if ($filename !== ''): $previewUrl='/school-admin-dashboard/modules/students/student-photo-bulk-preview-file.php?school_year='.rawurlencode($selectedYear).'&grade='.rawurlencode($selectedGrade).'&section='.rawurlencode($selectedSection).'&file='.rawurlencode($filename); ?><img src="<?= htmlspecialchars($previewUrl) ?>" alt="Photo preview" width="52" height="52" class="rounded border" style="object-fit:cover" loading="lazy"><?php else: ?><div class="rounded border bg-light d-inline-flex align-items-center justify-content-center text-muted" style="width:52px;height:52px"><i class="fas fa-user"></i></div><?php endif; ?></td>
                        <td><?php if (!empty($item['student_id'])): ?><strong><?= htmlspecialchars((string)$item['lastname']) ?>, <?= htmlspecialchars((string)$item['firstname']) ?></strong><div class="small text-muted">LRN: <?= htmlspecialchars((string)($item['lrn']?:'Not set')) ?></div><div class="filename mt-1">Expected: <?= htmlspecialchars(student_photo_expected_source_filename(['grade'=>$selectedGrade,'lrn'=>$item['lrn'],'lastname'=>$item['lastname'],'firstname'=>$item['firstname'],'middlename'=>$item['middlename']])) ?></div><?php else: ?><strong>Unmatched inbox file</strong><?php endif; ?></td>
                        <td class="filename"><?= $filename!==''?htmlspecialchars($filename):'—' ?><div class="small text-muted"><?= htmlspecialchars((string)$item['notes']) ?></div></td>
                        <td><span class="badge text-bg-<?= bulk_photo_status_badge($status) ?>"><?= htmlspecialchars(ucwords(str_replace('_',' ',$status))) ?></span><?php if ($isReplacement && $batch['status']==='staged'): ?><div class="form-check small mt-2"><input class="form-check-input replacement-confirm" type="checkbox" name="replacement_item_ids[]" value="<?= (int)$item['id'] ?>" id="replace<?= (int)$item['id'] ?>"><label class="form-check-label" for="replace<?= (int)$item['id'] ?>">Replace current photo</label></div><?php endif; ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody></table></div>
                <?php if ($batch['status']==='staged'): ?><div class="border rounded-4 p-3 bg-light-subtle d-flex justify-content-between align-items-center flex-wrap gap-3"><div><strong>Final confirmation required</strong><div class="small text-muted">Only checked matched photos will be saved. Inbox files stay untouched; final copies are stored privately.</div></div><button type="submit" class="btn btn-success"><i class="fas fa-check-circle me-1"></i>Apply Confirmed Attachments</button></div><?php endif; ?>
            </form>
        </section>
        <?php if ($applyResult): ?><section class="bulk-card p-4"><h5 class="mb-3">Apply result</h5><div class="small text-muted mb-2">Batch status: <?= htmlspecialchars((string)$applyResult['batch_status']) ?></div><?php if ($applyResult['success']): ?><div class="alert alert-success mb-2"><?= count($applyResult['success']) ?> student photo attachment(s) were saved.</div><?php endif; ?><?php if ($applyResult['errors']): ?><div class="alert alert-warning mb-0"><strong>Items needing review:</strong><ul class="mb-0 mt-2"><?php foreach ($applyResult['errors'] as $error): ?><li><?= htmlspecialchars((string)$error) ?></li><?php endforeach; ?></ul></div><?php endif; ?></section><?php endif; ?>
    <?php endif; ?>
    <?php if (is_array($preview) && !is_array($batch)): ?>
        <div class="row g-3 mb-4">
            <?php foreach (['total'=>'Students','matched'=>'Matched','replacement'=>'Replacement review','missing'=>'Missing','duplicate'=>'Duplicate','unknown'=>'Unknown','invalid'=>'Invalid'] as $key=>$label): ?><div class="col-6 col-md-3 col-lg"><div class="summary-card"><div class="summary-label"><?= $label ?></div><div class="summary-value"><?= number_format($summary[$key]) ?></div></div></div><?php endforeach; ?>
        </div>
        <section class="bulk-card p-4 mb-4"><h5 class="mb-1">2. Preview results</h5><p class="text-muted small">This is read-only. Wave 3 will add controlled confirmation and Apply actions.</p><div class="table-responsive"><table class="table table-hover align-middle"><thead><tr><th>Preview</th><th>Student</th><th>Expected filename</th><th>Detected filename</th><th>Status</th></tr></thead><tbody><?php foreach ($preview['rows'] as $row): $student=$row['student']; $match=$row['matches'][0]??null; $status=(string)$row['status']; ?><tr><td><?php if ($match): $previewUrl='/school-admin-dashboard/modules/students/student-photo-bulk-preview-file.php?school_year='.rawurlencode($selectedYear).'&grade='.rawurlencode($selectedGrade).'&section='.rawurlencode($selectedSection).'&file='.rawurlencode((string)$match['filename']); ?><img src="<?= htmlspecialchars($previewUrl) ?>" alt="Photo preview" width="52" height="52" class="rounded border" style="object-fit:cover" loading="lazy"><?php else: ?><div class="rounded border bg-light d-inline-flex align-items-center justify-content-center text-muted" style="width:52px;height:52px"><i class="fas fa-user"></i></div><?php endif; ?></td><td><strong><?= htmlspecialchars((string)$student['lastname']) ?>, <?= htmlspecialchars((string)$student['firstname']) ?></strong><div class="small text-muted">LRN: <?= htmlspecialchars((string)($student['lrn']?:'Not set')) ?></div></td><td class="filename"><?= htmlspecialchars($row['expected_filename']) ?></td><td><?php if ($match): ?><div class="filename"><?= htmlspecialchars((string)$match['filename']) ?></div><div class="small text-muted"><?= htmlspecialchars((string)$match['match_type']) ?></div><?php else: ?>—<?php endif; ?></td><td><span class="badge text-bg-<?= bulk_photo_status_badge($status) ?>"><?= htmlspecialchars(ucwords(str_replace('_',' ',$status))) ?></span><div class="small text-muted mt-1"><?= htmlspecialchars((string)$row['message']) ?></div></td></tr><?php endforeach; ?></tbody></table></div></section>
        <?php if ($preview['unmatched_files']): ?><section class="bulk-card p-4"><h5 class="mb-3">Files needing review</h5><div class="table-responsive"><table class="table table-sm"><thead><tr><th>Filename</th><th>Status</th><th>Reason</th></tr></thead><tbody><?php foreach ($preview['unmatched_files'] as $file): ?><tr><td class="filename"><?= htmlspecialchars((string)$file['filename']) ?></td><td><span class="badge text-bg-<?= bulk_photo_status_badge((string)$file['status']) ?>"><?= htmlspecialchars((string)$file['status']) ?></span></td><td><?= htmlspecialchars((string)$file['message']) ?></td></tr><?php endforeach; ?></tbody></table></div></section><?php endif; ?>
    <?php endif; ?>
</main>
<div class="scan-overlay" role="status" aria-live="polite"><div class="scan-card"><div class="fw-bold"><i class="fas fa-images me-2"></i>Scanning student photos…</div><p class="text-muted small mb-0 mt-2">Checking filenames, image limits, and student matches. Please do not close or go back.</p><div class="scan-track"><div class="scan-bar"></div></div></div></div>
<script>
(function () {
    const body = document.body;
    document.getElementById('bulkPhotoScanForm')?.addEventListener('submit', function () { body.classList.add('scan-active'); });
    document.getElementById('bulkPhotoApplyForm')?.addEventListener('submit', function (event) {
        const selectedReplacements = Array.from(document.querySelectorAll('.bulk-item-check[data-replacement-item="1"]:checked'));
        const unconfirmed = selectedReplacements.filter((checkbox) => !document.getElementById('replace' + checkbox.value)?.checked);
        if (unconfirmed.length) { event.preventDefault(); alert('Confirm “Replace current photo” for every selected replacement candidate.'); return; }
        if (!confirm('Apply the selected student photo attachments now? Existing photos are only replaced where you explicitly confirmed a replacement.')) { event.preventDefault(); return; }
        body.classList.add('scan-active');
    });
})();
</script>
</body>
</html>
