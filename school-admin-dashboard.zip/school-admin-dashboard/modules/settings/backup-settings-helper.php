<?php

require_once __DIR__ . '/../../includes/schema-migration.php';

if (!function_exists('get_secure_backup_dir')) {
    function get_secure_backup_dir(): string
    {
        return 'C:/xampp/secure-school-admin-backups';
    }
}

function backup_settings_normalize_dir(string $dir): string
{
    $dir = trim($dir);
    $dir = str_replace('\\', '/', $dir);
    $dir = rtrim($dir, "/ \t\n\r\0\x0B");

    return $dir !== '' ? $dir : get_secure_backup_dir();
}

function backup_settings_is_valid_dir(string $dir): bool
{
    $dir = backup_settings_normalize_dir($dir);
    if ($dir === '') {
        return false;
    }

    if (!preg_match('/^[A-Za-z]:\/[^:*?"<>|]+$/', $dir)) {
        return false;
    }

    $normalized = strtolower($dir);
    $blockedRoots = [
        'c:/xampp/htdocs',
        'c:/windows',
        'c:/program files',
        'c:/program files (x86)',
    ];

    foreach ($blockedRoots as $blockedRoot) {
        if ($normalized === $blockedRoot || str_starts_with($normalized, $blockedRoot . '/')) {
            return false;
        }
    }

    return true;
}

function backup_settings_prepare_dir(string $dir): array
{
    $dir = backup_settings_normalize_dir($dir);
    if (!backup_settings_is_valid_dir($dir)) {
        return [false, $dir, 'Use an absolute Windows path outside the web folder, for example D:/school-admin-backups.'];
    }

    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) {
        return [false, $dir, 'Backup directory could not be created. Check the drive letter and folder permissions.'];
    }

    if (!is_writable($dir)) {
        return [false, $dir, 'Backup directory is not writable. Check folder permissions.'];
    }

    return [true, $dir, ''];
}

function backup_settings_resolved_dir(array $settings): string
{
    $configuredDir = backup_settings_normalize_dir((string) ($settings['backup_dir'] ?? ''));
    return backup_settings_is_valid_dir($configuredDir) ? $configuredDir : get_secure_backup_dir();
}

function backup_settings_default_values(): array
{
    return [
        'enabled' => 1,
        'preferred_time' => '00:00',
        'retention_count' => 122,
        'schedule_label' => 'Hourly Automatic',
        'backup_dir' => get_secure_backup_dir(),
        'last_backup_at' => null,
        'last_backup_file' => '',
        'last_backup_status' => 'Never Run',
        'last_backup_message' => '',
    ];
}

function backup_settings_ensure_table(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }

    $sql = "CREATE TABLE IF NOT EXISTS backup_schedule_settings (
        id TINYINT NOT NULL PRIMARY KEY,
        enabled TINYINT(1) NOT NULL DEFAULT 1,
        preferred_time VARCHAR(5) NOT NULL DEFAULT '00:00',
        retention_count INT NOT NULL DEFAULT 122,
        schedule_label VARCHAR(32) NOT NULL DEFAULT 'Hourly Automatic',
        backup_dir VARCHAR(255) NOT NULL,
        last_backup_at DATETIME NULL,
        last_backup_file VARCHAR(255) NULL,
        last_backup_status VARCHAR(32) NOT NULL DEFAULT 'Never Run',
        last_backup_message TEXT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    schema_migration_attempt($conn, $sql);

    $countResult = $conn->query("SELECT COUNT(*) AS total FROM backup_schedule_settings");
    $count = $countResult ? (int) (($countResult->fetch_assoc()['total'] ?? 0)) : 0;
    if ($countResult) {
        $countResult->close();
    }

    if ($count === 0) {
        $defaults = backup_settings_default_values();
        $stmt = $conn->prepare(
            "INSERT INTO backup_schedule_settings
            (id, enabled, preferred_time, retention_count, schedule_label, backup_dir, last_backup_status, last_backup_message)
            VALUES (1, ?, ?, ?, ?, ?, ?, ?)"
        );
        if ($stmt) {
            $stmt->bind_param(
                'isissss',
                $defaults['enabled'],
                $defaults['preferred_time'],
                $defaults['retention_count'],
                $defaults['schedule_label'],
                $defaults['backup_dir'],
                $defaults['last_backup_status'],
                $defaults['last_backup_message']
            );
            $stmt->execute();
            $stmt->close();
        }
    }
}

function backup_settings_get(mysqli $conn): array
{
    backup_settings_ensure_table($conn);
    $defaults = backup_settings_default_values();
    $result = $conn->query("SELECT * FROM backup_schedule_settings WHERE id = 1 LIMIT 1");
    if ($result && $row = $result->fetch_assoc()) {
        $result->close();
        return [
            'enabled' => (int) ($row['enabled'] ?? $defaults['enabled']),
            'preferred_time' => (string) ($row['preferred_time'] ?? $defaults['preferred_time']),
            'retention_count' => max(1, (int) ($row['retention_count'] ?? $defaults['retention_count'])),
            'schedule_label' => (string) ($row['schedule_label'] ?? $defaults['schedule_label']),
            'backup_dir' => backup_settings_resolved_dir($row),
            'last_backup_at' => $row['last_backup_at'] ?? null,
            'last_backup_file' => (string) ($row['last_backup_file'] ?? ''),
            'last_backup_status' => (string) ($row['last_backup_status'] ?? $defaults['last_backup_status']),
            'last_backup_message' => (string) ($row['last_backup_message'] ?? ''),
        ];
    }

    return $defaults;
}

function backup_settings_save(mysqli $conn, array $payload): bool
{
    backup_settings_ensure_table($conn);

    $enabled = !empty($payload['enabled']) ? 1 : 0;
    $preferredTime = trim((string) ($payload['preferred_time'] ?? '00:00'));
    if (!preg_match('/^\d{2}:\d{2}$/', $preferredTime)) {
        $preferredTime = '00:00';
    }
    $retentionCount = max(1, min(365, (int) ($payload['retention_count'] ?? 122)));
    $scheduleLabel = trim((string) ($payload['schedule_label'] ?? 'Hourly Automatic'));
    if ($scheduleLabel === '') {
        $scheduleLabel = 'Hourly Automatic';
    }
    $backupDir = backup_settings_normalize_dir((string) ($payload['backup_dir'] ?? get_secure_backup_dir()));
    if (!backup_settings_is_valid_dir($backupDir)) {
        return false;
    }

    $stmt = $conn->prepare(
        "UPDATE backup_schedule_settings
         SET enabled = ?, preferred_time = ?, retention_count = ?, schedule_label = ?, backup_dir = ?
         WHERE id = 1"
    );
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('isiss', $enabled, $preferredTime, $retentionCount, $scheduleLabel, $backupDir);
    $success = $stmt->execute();
    $stmt->close();
    return $success;
}

function backup_settings_record_run(mysqli $conn, string $status, string $message = '', string $fileName = ''): void
{
    backup_settings_ensure_table($conn);
    $normalizedStatus = trim($status) !== '' ? trim($status) : 'Unknown';
    $stmt = $conn->prepare(
        "UPDATE backup_schedule_settings
         SET last_backup_at = NOW(), last_backup_file = ?, last_backup_status = ?, last_backup_message = ?
         WHERE id = 1"
    );
    if ($stmt) {
        $stmt->bind_param('sss', $fileName, $normalizedStatus, $message);
        $stmt->execute();
        $stmt->close();
    }
}

function backup_settings_prune_old_files(string $backupDir, int $retentionCount): array
{
    $retentionCount = max(1, $retentionCount);
    $backups = glob(rtrim($backupDir, '/\\') . '/*.sql') ?: [];
    usort($backups, static function (string $a, string $b): int {
        return filemtime($b) <=> filemtime($a);
    });

    $deleted = [];
    $toDelete = array_slice($backups, $retentionCount);
    foreach ($toDelete as $filePath) {
        if (@unlink($filePath)) {
            $deleted[] = basename($filePath);
        }
    }

    return $deleted;
}
