<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require_once __DIR__ . '/../../includes/ui.php';

require '../../config/database.php';
require_once 'settings-permissions-roles.php';
require_once 'settings-security.php';
require_once 'school-info-helper.php';

$role = $_SESSION['role'] ?? '';
$username = $_SESSION['username'] ?? '';
if (!can_access_school_information_settings($role)) {
    header('Location: /school-admin-dashboard/modules/settings/settings-dashboard.php?error=restricted');
    exit();
}

ensure_csrf_token();
ensure_school_information_table($conn);

$pageMessage = '';
$pageError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_school_information'])) {
    admin_require_post_csrf();

    $payload = [
        'school_name' => $_POST['school_name'] ?? '',
        'school_short_name' => $_POST['school_short_name'] ?? '',
        'owner_name' => $_POST['owner_name'] ?? '',
        'principal_name' => $_POST['principal_name'] ?? '',
        'registrar_name' => $_POST['registrar_name'] ?? '',
        'cashier_name' => $_POST['cashier_name'] ?? '',
        'address' => $_POST['address'] ?? '',
        'contact_number' => $_POST['contact_number'] ?? '',
        'email' => $_POST['email'] ?? '',
        'mission' => $_POST['mission'] ?? '',
        'vision' => $_POST['vision'] ?? '',
        'core_values' => $_POST['core_values'] ?? '',
        'about_text' => $_POST['about_text'] ?? '',
        'receipt_footer_note' => $_POST['receipt_footer_note'] ?? '',
        'logo_path' => $_POST['logo_path'] ?? '',
    ];

    if (trim((string) $payload['school_name']) === '') {
        $pageError = 'School name is required.';
    } elseif (save_school_information($conn, $payload)) {
        $pageMessage = 'School information updated successfully.';
    } else {
        $pageError = 'School information could not be saved.';
    }
}

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$schoolContactLine = school_info_contact_line($schoolInfo);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School Information - School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <?php ui_css_link(); ?>
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body {
            background: var(--main-bg);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        }
        body.dark-mode {
            --main-bg: #1b232d;
            --card-bg: #23395d;
            --navbar-bg: #161b22;
            color: #e6edf3;
        }
        .navbar {
            background: var(--navbar-bg) !important;
            box-shadow: 0 2px 12px rgba(33,57,93,0.08);
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #fff !important;
            font-size: 1.08em;
        }
        .navbar-brand {
            font-weight: 700;
            letter-spacing: 1px;
        }
        .theme-toggle-btn {
            background: none;
            border: none;
            color: #fff;
            font-size: 1.45em;
            margin-left: 12px;
            cursor: pointer;
        }
        .dashboard-header {
            text-align: center;
            margin-top: 36px;
            margin-bottom: 18px;
        }
        .dashboard-header img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            margin-bottom: 6px;
        }
        .dashboard-header h1 {
            font-size: 1.3rem;
            color: var(--brand-dark);
            font-weight: 700;
            margin-bottom: 0;
            letter-spacing: 0.02em;
        }
        body.dark-mode .dashboard-header h1,
        body.dark-mode .page-title,
        body.dark-mode .section-title {
            color: #e6edf3;
        }
        .page-title {
            color: var(--brand-dark);
            font-weight: 700;
        }
        .section-card {
            background: var(--card-bg);
            border: 1px solid rgba(81, 127, 164, 0.15);
            border-radius: 1rem;
            box-shadow: 0 4px 18px rgba(33, 57, 93, 0.07);
            margin-bottom: 1.25rem;
        }
        .section-title {
            color: var(--brand-dark);
            font-size: 1rem;
            font-weight: 700;
            margin-bottom: 1rem;
        }
        .form-label {
            font-weight: 600;
        }
        .preview-card {
            background: linear-gradient(135deg, #f8fbff 0%, #eef5ff 100%);
            border: 1px solid rgba(81, 127, 164, 0.16);
            border-radius: 1rem;
            padding: 1.25rem;
        }
        body.dark-mode .preview-card {
            background: rgba(255, 255, 255, 0.04);
        }
        .preview-logo {
            width: 72px;
            height: 72px;
            object-fit: contain;
            border-radius: 12px;
            background: #fff;
            padding: 0.4rem;
            box-shadow: 0 4px 14px rgba(33,57,93,0.08);
        }
        .dashboard-btn-bottom {
            position: fixed;
            left: 28px;
            bottom: 28px;
            z-index: 1060;
            background: #e7f0fd;
            color: var(--brand-blue);
            border: 2px solid #bcdfff;
            box-shadow: 0 5px 16px rgba(33,57,93,0.13);
            border-radius: 50%;
            width: 58px;
            height: 58px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.55em;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
            text-decoration: none;
        }
        .dashboard-btn-bottom:hover,
        .dashboard-btn-bottom:focus {
            background: #fff2b3;
            color: var(--brand-blue);
            border-color: #ffe599;
        }
    </style>
</head>
<body>
<?php render_admin_nav('settings', true); ?>
<?php render_school_page_header($schoolName, $schoolLogo, $schoolContactLine); ?>

<div class="container py-3">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
        <div>
            <h2 class="page-title mb-1"><i class="fas fa-school"></i> School Information</h2>
            <p class="text-muted mb-0">Manage the school profile details used in settings, receipts, and account pages.</p>
        </div>
    </div>

    <?php if ($pageMessage !== ''): ?>
        <div class="alert alert-success"><?= htmlspecialchars($pageMessage) ?></div>
    <?php endif; ?>
    <?php if ($pageError !== ''): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($pageError) ?></div>
    <?php endif; ?>

    <form method="post" class="row g-4">
        <?= csrf_input() ?>
        <div class="col-12 col-lg-8">
            <div class="section-card p-4">
                <div class="section-title">Basic Information</div>
                <div class="row g-3">
                    <div class="col-md-8">
                        <label class="form-label">School Name</label>
                        <input type="text" name="school_name" class="form-control" value="<?= htmlspecialchars((string) $schoolInfo['school_name']) ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Short Name</label>
                        <input type="text" name="school_short_name" class="form-control" value="<?= htmlspecialchars((string) $schoolInfo['school_short_name']) ?>">
                    </div>
                    <div class="col-12">
                        <label class="form-label">Address</label>
                        <textarea name="address" class="form-control" rows="2"><?= htmlspecialchars((string) $schoolInfo['address']) ?></textarea>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Contact Number</label>
                        <input type="text" name="contact_number" class="form-control" value="<?= htmlspecialchars((string) $schoolInfo['contact_number']) ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" value="<?= htmlspecialchars((string) $schoolInfo['email']) ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Logo Path</label>
                        <input type="text" name="logo_path" class="form-control" value="<?= htmlspecialchars((string) $schoolInfo['logo_path']) ?>" placeholder="/school-admin-dashboard/uploads/logo1.png">
                    </div>
                </div>
            </div>

            <div class="section-card p-4">
                <div class="section-title">Leadership & Signatories</div>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Owner / Director</label>
                        <input type="text" name="owner_name" class="form-control" value="<?= htmlspecialchars((string) $schoolInfo['owner_name']) ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Principal</label>
                        <input type="text" name="principal_name" class="form-control" value="<?= htmlspecialchars((string) $schoolInfo['principal_name']) ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Registrar</label>
                        <input type="text" name="registrar_name" class="form-control" value="<?= htmlspecialchars((string) $schoolInfo['registrar_name']) ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Cashier</label>
                        <input type="text" name="cashier_name" class="form-control" value="<?= htmlspecialchars((string) $schoolInfo['cashier_name']) ?>">
                    </div>
                </div>
            </div>

            <div class="section-card p-4">
                <div class="section-title">Identity & Messaging</div>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Mission</label>
                        <textarea name="mission" class="form-control" rows="4"><?= htmlspecialchars((string) $schoolInfo['mission']) ?></textarea>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Vision</label>
                        <textarea name="vision" class="form-control" rows="4"><?= htmlspecialchars((string) $schoolInfo['vision']) ?></textarea>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Core Values</label>
                        <textarea name="core_values" class="form-control" rows="4"><?= htmlspecialchars((string) $schoolInfo['core_values']) ?></textarea>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">School Background / About</label>
                        <textarea name="about_text" class="form-control" rows="4"><?= htmlspecialchars((string) $schoolInfo['about_text']) ?></textarea>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Receipt Footer Note</label>
                        <textarea name="receipt_footer_note" class="form-control" rows="3"><?= htmlspecialchars((string) $schoolInfo['receipt_footer_note']) ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-lg-4">
            <div class="preview-card sticky-top" style="top: 1rem;">
                <div class="d-flex align-items-center gap-3 mb-3">
                    <img src="<?= htmlspecialchars($schoolLogo) ?>" alt="School Logo" class="preview-logo">
                    <div>
                        <div class="fw-bold"><?= htmlspecialchars($schoolName) ?></div>
                        <div class="text-muted small"><?= htmlspecialchars((string) ($schoolInfo['school_short_name'] ?: 'School profile preview')) ?></div>
                    </div>
                </div>
                <div class="small text-muted mb-2">Receipt / header preview data</div>
                <div class="mb-2"><strong>Contact:</strong> <?= htmlspecialchars($schoolContactLine !== '' ? $schoolContactLine : 'Not set') ?></div>
                <div class="mb-2"><strong>Owner:</strong> <?= htmlspecialchars((string) ($schoolInfo['owner_name'] ?: 'Not set')) ?></div>
                <div class="mb-2"><strong>Principal:</strong> <?= htmlspecialchars((string) ($schoolInfo['principal_name'] ?: 'Not set')) ?></div>
                <div class="mb-2"><strong>Registrar:</strong> <?= htmlspecialchars((string) ($schoolInfo['registrar_name'] ?: 'Not set')) ?></div>
                <div class="mb-2"><strong>Cashier:</strong> <?= htmlspecialchars((string) ($schoolInfo['cashier_name'] ?: 'Not set')) ?></div>
                <div class="mb-3"><strong>Receipt Note:</strong> <?= htmlspecialchars((string) ($schoolInfo['receipt_footer_note'] ?: 'Default receipt footer note will be used.')) ?></div>
                <div class="d-grid">
                    <button type="submit" name="save_school_information" class="btn btn-primary btn-lg">
                        <i class="fas fa-save"></i> Save School Information
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>

<footer class="text-center py-4 text-muted small">
    &copy; <?= date('Y') ?> <?= htmlspecialchars($schoolName) ?> | School Admin Dashboard
</footer>
<a href="/school-admin-dashboard/modules/settings/settings-dashboard.php" class="dashboard-btn-bottom" title="Back to Settings">
    <i class="fas fa-arrow-left"></i>
</a>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('themeToggleBtn').addEventListener('click', function() {
    document.body.classList.toggle('dark-mode');
    this.querySelector('i').classList.toggle('fa-moon');
    this.querySelector('i').classList.toggle('fa-sun');
});
</script>
</body>
</html>
<?php
$conn->close();
?>
