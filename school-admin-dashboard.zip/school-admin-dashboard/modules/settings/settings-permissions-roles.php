<?php
// Centralized roles and permissions configuration for your admin system

$rolePermissions = [
    'Super Administrator' => [
        'student_data'   => ['view', 'add', 'edit', 'delete', 'export'],
        'student_registration' => ['view', 'approve', 'reject', 'import'],
        'account_mgmt'   => ['view', 'add', 'edit', 'delete', 'export'],
        'financial'      => ['view', 'add', 'edit', 'delete', 'export'],
        'documents'      => ['view', 'upload', 'edit', 'delete', 'export'],
        'reports'        => ['view', 'generate', 'export'],
        'audit_logs'     => ['view', 'export'],
        'settings'       => ['view', 'edit'],
    ],
    'Administrator 1' => [
        'student_data'   => ['view', 'add', 'edit', 'export'], // <-- can add, edit, export, but not delete
        'student_registration' => ['view', 'approve', 'reject', 'import'],
        'account_mgmt'   => ['view', 'add', 'edit', 'export'],
        'financial'      => ['view', 'add', 'edit', 'delete', 'export'],
        'documents'      => ['view'],
        'reports'        => ['view'],
        'audit_logs'     => ['view'],
        'settings'       => ['view_own', 'edit_own'],
    ],
    'Administrator 2' => [
        'student_data'   => ['view', 'add', 'edit', 'export'],
        'student_registration' => ['view', 'approve', 'reject', 'import'],
        'account_mgmt'   => ['view', 'add', 'edit', 'export'],
        'financial'      => ['view', 'add', 'edit', 'delete', 'export'],
        'documents'      => ['view', 'upload', 'edit', 'export'],
        'reports'        => ['view'],
        'audit_logs'     => ['view'],
        'settings'       => ['view_own'],
    ],
    'Staff' => [
        'student_data'   => ['view'],
        'student_registration' => ['view'],
        'account_mgmt'   => ['view'],
        'financial'      => ['view'],
        'documents'      => ['view'],
        'reports'        => ['view'],
        'audit_logs'     => ['view'],
        'settings'       => [],
    ],
    'Registrar Staff' => [
        'student_data'   => ['view', 'add', 'edit', 'export'],
        'student_registration' => ['view', 'approve', 'reject'],
        'account_mgmt'   => [],
        'financial'      => [],
        'documents'      => ['view', 'upload', 'edit', 'export'],
        'reports'        => [],
        'audit_logs'     => [],
        'settings'       => ['view_backup'],
    ],
    'Accounting Staff' => [
        'student_data'   => [],
        'student_registration' => [],
        'account_mgmt'   => ['view', 'add', 'edit', 'export'],
        'financial'      => ['view', 'add', 'edit', 'delete', 'export'],
        'documents'      => [],
        'reports'        => ['view'],
        'audit_logs'     => [],
        'settings'       => ['view_backup'],
    ],
    'View Staff' => [
        'student_data'   => ['view', 'export'],
        'student_registration' => ['view'],
        'account_mgmt'   => ['view', 'export'],
        'financial'      => ['view', 'export'],
        'documents'      => ['view', 'export'],
        'reports'        => ['view', 'export'],
        'audit_logs'     => [],
        'settings'       => [],
    ]
];

// Permission check helper
function hasPermission($role, $module, $action) {
    global $rolePermissions;
    if (!isset($rolePermissions[$role])) return false;
    if (!isset($rolePermissions[$role][$module])) return false;
    return in_array($action, $rolePermissions[$role][$module]);
}

function managed_admin_roles(): array {
    return ['Administrator 1', 'Administrator 2', 'Staff', 'Registrar Staff', 'Accounting Staff', 'View Staff'];
}

function can_view_settings_module(string $role): bool {
    return hasPermission($role, 'settings', 'view')
        || hasPermission($role, 'settings', 'view_own')
        || hasPermission($role, 'settings', 'edit')
        || hasPermission($role, 'settings', 'edit_own')
        || hasPermission($role, 'settings', 'view_backup')
        || is_specialized_staff_role($role);
}

function is_super_admin_role(string $role): bool {
    return $role === 'Super Administrator';
}

function is_administrator_role(string $role): bool {
    return in_array($role, ['Administrator 1', 'Administrator 2'], true);
}

function is_registrar_staff_role(string $role): bool {
    return $role === 'Registrar Staff';
}

function is_accounting_staff_role(string $role): bool {
    return $role === 'Accounting Staff';
}

function is_view_staff_role(string $role): bool {
    return $role === 'View Staff';
}

function is_specialized_staff_role(string $role): bool {
    return is_registrar_staff_role($role) || is_accounting_staff_role($role);
}

function can_access_school_information_settings(string $role): bool {
    return is_super_admin_role($role) || is_administrator_role($role);
}

function can_access_requirements_settings(string $role): bool {
    return is_super_admin_role($role) || is_administrator_role($role);
}

function can_access_fee_grade_settings(string $role): bool {
    return is_super_admin_role($role) || is_administrator_role($role);
}

function can_access_school_year_settings(string $role): bool {
    return is_super_admin_role($role) || is_administrator_role($role);
}

function can_access_year_end_rollover(string $role): bool {
    return can_access_school_year_settings($role);
}

function can_access_section_settings(string $role): bool {
    return is_super_admin_role($role) || is_administrator_role($role);
}

function can_access_section_location_settings(string $role): bool {
    return is_super_admin_role($role) || is_administrator_role($role);
}

function can_access_user_management_settings(string $role): bool {
    return is_super_admin_role($role);
}

function can_access_backup_settings(string $role): bool {
    return is_super_admin_role($role) || is_administrator_role($role) || is_specialized_staff_role($role);
}

function can_access_backup_schedule_settings(string $role): bool {
    return is_super_admin_role($role);
}

function can_access_upload_storage_settings(string $role): bool {
    return is_super_admin_role($role);
}

function can_access_bulk_photo_attachment(string $role): bool {
    return is_super_admin_role($role)
        || is_administrator_role($role)
        || is_registrar_staff_role($role);
}

function can_access_audit_settings(string $role): bool {
    return is_super_admin_role($role);
}

function can_access_receipt_registry_settings(string $role): bool {
    return is_super_admin_role($role);
}

function can_access_account_followup_template_settings(string $role): bool {
    return is_super_admin_role($role) || is_administrator_role($role);
}

function can_access_finance_adjustment_settings(string $role): bool {
    return is_super_admin_role($role) || is_administrator_role($role);
}

function can_access_duplicate_cleanup_settings(string $role): bool {
    return is_super_admin_role($role);
}

function can_edit_own_admin_profile(string $role): bool {
    return is_administrator_role($role);
}

function can_access_reports_dashboard(string $role): bool {
    if (is_registrar_staff_role($role)) {
        return false;
    }

    return hasPermission($role, 'reports', 'view');
}

function can_access_academic_reports(string $role): bool {
    if (is_registrar_staff_role($role) || is_accounting_staff_role($role)) {
        return false;
    }

    return hasPermission($role, 'reports', 'view');
}

function can_export_academic_reports(string $role): bool {
    return can_access_academic_reports($role)
        && (hasPermission($role, 'reports', 'export') || is_administrator_role($role));
}

function can_access_invoice_total(string $role): bool {
    if (is_registrar_staff_role($role)) {
        return false;
    }

    return hasPermission($role, 'financial', 'view');
}

function can_access_settlement_module(string $role): bool {
    return is_super_admin_role($role)
        || is_administrator_role($role)
        || is_registrar_staff_role($role)
        || is_accounting_staff_role($role)
        || is_view_staff_role($role);
}

function can_access_settlement_add(string $role): bool {
    return is_super_admin_role($role)
        || is_administrator_role($role)
        || is_registrar_staff_role($role);
}

function can_access_settlement_settle(string $role): bool {
    return is_super_admin_role($role)
        || is_administrator_role($role)
        || is_accounting_staff_role($role);
}

function can_export_settlement_records(string $role): bool {
    return is_super_admin_role($role)
        || is_administrator_role($role)
        || is_view_staff_role($role)
        || is_accounting_staff_role($role);
}

function can_access_admin_edit_page(string $role, bool $isEditingSelf): bool {
    return can_access_user_management_settings($role) || ($isEditingSelf && can_edit_own_admin_profile($role));
}

function settings_page_access_map(): array {
    return [
        'school_information' => 'can_access_school_information_settings',
        'requirements' => 'can_access_requirements_settings',
        'fee_grades' => 'can_access_fee_grade_settings',
        'school_years' => 'can_access_school_year_settings',
        'year_end_rollover' => 'can_access_year_end_rollover',
        'year_end_rollover' => 'can_access_year_end_rollover',
        'sections' => 'can_access_section_settings',
        'section_locations' => 'can_access_section_location_settings',
        'user_management' => 'can_access_user_management_settings',
        'backup' => 'can_access_backup_settings',
        'backup_schedule' => 'can_access_backup_schedule_settings',
        'upload_storage' => 'can_access_upload_storage_settings',
        'bulk_photo_attachment' => 'can_access_bulk_photo_attachment',
        'audit_retention' => 'can_access_audit_settings',
        'receipt_registry' => 'can_access_receipt_registry_settings',
        'account_followup_templates' => 'can_access_account_followup_template_settings',
        'finance_adjustments' => 'can_access_finance_adjustment_settings',
        'maintenance' => 'can_access_duplicate_cleanup_settings',
        'duplicate_cleanup' => 'can_access_duplicate_cleanup_settings',
    ];
}

function can_access_settings_page(string $role, string $pageKey): bool {
    $map = settings_page_access_map();
    $resolver = $map[$pageKey] ?? null;
    if (!$resolver || !function_exists($resolver)) {
        return false;
    }

    return (bool) $resolver($role);
}
