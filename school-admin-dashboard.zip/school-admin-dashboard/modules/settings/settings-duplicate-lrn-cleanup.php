<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require '../../config/database.php';
require __DIR__ . '/../students/student-registration-helper.php';
require __DIR__ . '/settings-permissions-roles.php';
include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');
require_once 'school-info-helper.php';

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$canAccessDuplicateCleanup = can_access_duplicate_cleanup_settings($role);

if (!$canAccessDuplicateCleanup) {
    admin_session_forbidden();
}

registration_ensure_pending_table($conn);
$csrfToken = registration_csrf_token();
$message = '';
$messageType = 'success';

function cleanup_duplicate_groups(mysqli $conn, string $tableName) {
    $allowed = ['students', 'student_registration_pending'];
    if (!in_array($tableName, $allowed, true)) {
        return [];
    }

    $dateColumn = $tableName === 'students' ? 'created_at' : 'submitted_at';
    $schoolYearColumn = $tableName === 'students' ? 'school_year_label' : 'school_year_label';
    $groupSql = "SELECT lrn, COALESCE(NULLIF(TRIM({$schoolYearColumn}), ''), '') AS school_year_label, COUNT(*) AS duplicate_count
        FROM {$tableName}
        WHERE lrn IS NOT NULL AND TRIM(lrn) <> ''
        GROUP BY lrn, COALESCE(NULLIF(TRIM({$schoolYearColumn}), ''), '')
        HAVING COUNT(*) > 1
        ORDER BY lrn, school_year_label";
    $groupResult = $conn->query($groupSql);
    if (!$groupResult) {
        return [];
    }

    $groups = [];
    while ($group = $groupResult->fetch_assoc()) {
        $lrn = $group['lrn'];
        $schoolYearLabel = (string) ($group['school_year_label'] ?? '');
        $stmt = $conn->prepare("SELECT id, lastname, firstname, middlename, grade, section, guardian_name, COALESCE(NULLIF(TRIM({$schoolYearColumn}), ''), '') AS school_year_label, {$dateColumn} AS relevant_date FROM {$tableName} WHERE lrn = ? AND COALESCE(NULLIF(TRIM({$schoolYearColumn}), ''), '') = ? ORDER BY id ASC");
        $stmt->bind_param('ss', $lrn, $schoolYearLabel);
        $stmt->execute();
        $records = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        $groups[] = [
            'lrn' => $lrn,
            'school_year_label' => $schoolYearLabel,
            'duplicate_count' => (int) $group['duplicate_count'],
            'records' => $records,
        ];
    }

    return $groups;
}

function cleanup_allowed_table(string $tableName): string
{
    $allowed = [
        'students' => 'students',
        'student_registration_pending' => 'student_registration_pending',
    ];

    return $allowed[$tableName] ?? '';
}

function cleanup_summary(mysqli $conn) {
    $studentsGroups = $conn->query("SELECT COUNT(*) AS c FROM (SELECT lrn, COALESCE(NULLIF(TRIM(school_year_label), ''), '') AS school_year_label FROM students WHERE lrn IS NOT NULL AND TRIM(lrn) <> '' GROUP BY lrn, COALESCE(NULLIF(TRIM(school_year_label), ''), '') HAVING COUNT(*) > 1) t")->fetch_assoc()['c'] ?? 0;
    $studentsRows = $conn->query("SELECT COUNT(*) AS c FROM students s INNER JOIN (SELECT lrn, COALESCE(NULLIF(TRIM(school_year_label), ''), '') AS school_year_label FROM students WHERE lrn IS NOT NULL AND TRIM(lrn) <> '' GROUP BY lrn, COALESCE(NULLIF(TRIM(school_year_label), ''), '') HAVING COUNT(*) > 1) d ON d.lrn = s.lrn AND d.school_year_label = COALESCE(NULLIF(TRIM(s.school_year_label), ''), '')")->fetch_assoc()['c'] ?? 0;
    $pendingGroups = $conn->query("SELECT COUNT(*) AS c FROM (SELECT lrn, COALESCE(NULLIF(TRIM(school_year_label), ''), '') AS school_year_label FROM student_registration_pending WHERE lrn IS NOT NULL AND TRIM(lrn) <> '' GROUP BY lrn, COALESCE(NULLIF(TRIM(school_year_label), ''), '') HAVING COUNT(*) > 1) t")->fetch_assoc()['c'] ?? 0;
    $pendingRows = $conn->query("SELECT COUNT(*) AS c FROM student_registration_pending p INNER JOIN (SELECT lrn, COALESCE(NULLIF(TRIM(school_year_label), ''), '') AS school_year_label FROM student_registration_pending WHERE lrn IS NOT NULL AND TRIM(lrn) <> '' GROUP BY lrn, COALESCE(NULLIF(TRIM(school_year_label), ''), '') HAVING COUNT(*) > 1) d ON d.lrn = p.lrn AND d.school_year_label = COALESCE(NULLIF(TRIM(p.school_year_label), ''), '')")->fetch_assoc()['c'] ?? 0;

    return [
        'students_groups' => (int) $studentsGroups,
        'students_rows' => (int) $studentsRows,
        'pending_groups' => (int) $pendingGroups,
        'pending_rows' => (int) $pendingRows,
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!registration_verify_csrf($_POST['csrf_token'] ?? '')) {
        $message = 'Invalid request token. Please refresh the page and try again.';
        $messageType = 'danger';
    } elseif (($_POST['action'] ?? '') === 'resolve_duplicate_lrn') {
        $tableKey = $_POST['table_key'] ?? '';
        $tableName = $tableKey === 'pending' ? 'student_registration_pending' : ($tableKey === 'students' ? 'students' : '');
        $tableName = cleanup_allowed_table($tableName);
        $lrn = registration_normalize_lrn_value($_POST['lrn'] ?? '');
        $schoolYearLabel = trim((string) ($_POST['school_year_label'] ?? ''));
        $keepId = (int) ($_POST['keep_id'] ?? 0);
        $confirmPhrase = trim((string) ($_POST['confirm_phrase'] ?? ''));

        if ($tableName === '' || $lrn === null || $keepId <= 0) {
            $message = 'Invalid cleanup request.';
            $messageType = 'danger';
        } elseif ($confirmPhrase !== 'CLEANUP') {
            $message = 'Type CLEANUP before resolving duplicate LRN records.';
            $messageType = 'danger';
        } else {
            if (!is_super_admin_role($role)) {
                $message = 'Cleanup blocked. Only Super Administrator can apply data repairs.';
                $messageType = 'danger';
                goto cleanup_end;
            }
            $stmt = $conn->prepare("SELECT id FROM {$tableName} WHERE lrn = ? AND COALESCE(NULLIF(TRIM(school_year_label), ''), '') = ? ORDER BY id ASC");
            $stmt->bind_param('ss', $lrn, $schoolYearLabel);
            $stmt->execute();
            $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();

            $ids = array_map(static fn($row) => (int) $row['id'], $rows);
            if (count($ids) < 2 || !in_array($keepId, $ids, true)) {
                $message = 'This duplicate group is no longer available or the keeper is invalid.';
                $messageType = 'warning';
            } else {
                $clearIds = array_values(array_filter($ids, static fn($id) => $id !== $keepId));
                $conn->begin_transaction();
                try {
                    if ($clearIds) {
                        $placeholders = implode(',', array_fill(0, count($clearIds), '?'));
                        $types = str_repeat('i', count($clearIds)) . 'ss';
                        $params = array_merge($clearIds, [$lrn, $schoolYearLabel]);
                        $sql = "UPDATE {$tableName} SET lrn = NULL WHERE id IN ({$placeholders}) AND lrn = ? AND COALESCE(NULLIF(TRIM(school_year_label), ''), '') = ?";
                        $updateStmt = $conn->prepare($sql);
                        $updateStmt->bind_param($types, ...$params);
                        $updateStmt->execute();
                        $updatedRows = $updateStmt->affected_rows;
                        $updateStmt->close();
                    } else {
                        $updatedRows = 0;
                    }

                    $conn->commit();
                    $message = 'Cleanup applied. Kept LRN on record #' . $keepId . ' and cleared it from ' . $updatedRows . ' duplicate record(s).';
                    $messageType = 'success';
                    audit_log($conn, $username, 'Resolved duplicate historical LRN', 'Settings', 'Table: ' . $tableName . ' | LRN: ' . $lrn . ' | School Year: ' . ($schoolYearLabel !== '' ? $schoolYearLabel : '[blank]') . ' | Kept ID: ' . $keepId . ' | Cleared IDs: ' . implode(',', $clearIds));
                } catch (Throwable $e) {
                    $conn->rollback();
                    $message = 'Cleanup failed: ' . $e->getMessage();
                    $messageType = 'danger';
                }
            }
        }
    }
}
cleanup_end:

$summary = cleanup_summary($conn);
$studentDuplicateGroups = cleanup_duplicate_groups($conn, 'students');
$pendingDuplicateGroups = cleanup_duplicate_groups($conn, 'student_registration_pending');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Duplicate LRN Cleanup</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body {
            background: var(--main-bg);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        }
        .navbar { background: var(--navbar-bg) !important; }
        .navbar-brand, .navbar-nav .nav-link { color: #fff !important; }
        .dashboard-header {
            text-align: center;
            margin-top: 36px;
            margin-bottom: 18px;
        }
        .dashboard-header img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            margin-bottom: 6px;
        }
        .dashboard-header h1 {
            font-size: 1.3rem;
            color: var(--brand-dark);
            font-weight: 700;
            margin-bottom: 0;
        }
        .cleanup-card {
            background: var(--card-bg);
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(33,57,93,0.10);
            max-width: 1280px;
            margin: 24px auto;
            padding: 28px 24px;
        }
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 14px;
            margin-bottom: 24px;
        }
        .summary-box {
            background: #f7fbff;
            border: 1px solid #d6e9fb;
            border-radius: 14px;
            padding: 16px 18px;
        }
        .summary-box .label { color: var(--brand-blue); font-weight: 600; }
        .summary-box .value { color: var(--brand-dark); font-size: 1.4rem; font-weight: 700; }
        .duplicate-group {
            border: 1px solid #dce8f5;
            border-radius: 14px;
            padding: 18px;
            margin-bottom: 18px;
            background: #fff;
        }
        .table td, .table th { vertical-align: middle; }
        .warning-note {
            background: #fff6df;
            border: 1px solid #f2d88e;
            color: #6e5611;
            border-radius: 12px;
            padding: 12px 14px;
            margin-bottom: 16px;
        }
    </style>
</head>
<body>
<?php render_admin_nav('settings'); ?>

<div class="dashboard-header">
    <img src="<?= htmlspecialchars($schoolLogo) ?>" alt="School Logo" class="mb-2 rounded shadow-sm">
    <h1><?= htmlspecialchars($schoolName) ?></h1>
</div>

<div class="cleanup-card">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <div>
            <h2 class="mb-1"><i class="fas fa-broom text-primary me-2"></i>Duplicate Historical LRN Cleanup</h2>
            <div class="text-muted">Review duplicate LRN groups and keep the correct record. Cleanup clears the LRN on the wrong rows instead of deleting data.</div>
        </div>
        <a href="/school-admin-dashboard/modules/settings/settings-dashboard.php" class="btn btn-outline-secondary"><i class="fas fa-arrow-left"></i> Back to Settings</a>
    </div>

    <div class="warning-note">
        <i class="fas fa-triangle-exclamation me-2"></i>
        Use this only after reviewing the correct keeper record. The selected keeper keeps the LRN, and all other rows in the same duplicate group will have their LRN cleared to `NULL`.
    </div>

    <?php if ($message !== ''): ?>
        <div class="alert alert-<?= htmlspecialchars($messageType) ?>"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <div class="summary-grid">
        <div class="summary-box">
            <div class="label">Student Duplicate Groups</div>
            <div class="value"><?= $summary['students_groups'] ?></div>
        </div>
        <div class="summary-box">
            <div class="label">Student Rows Affected</div>
            <div class="value"><?= $summary['students_rows'] ?></div>
        </div>
        <div class="summary-box">
            <div class="label">Pending Duplicate Groups</div>
            <div class="value"><?= $summary['pending_groups'] ?></div>
        </div>
        <div class="summary-box">
            <div class="label">Pending Rows Affected</div>
            <div class="value"><?= $summary['pending_rows'] ?></div>
        </div>
    </div>

    <h3 class="h5 mb-3">Student Records</h3>
    <?php if (!$studentDuplicateGroups): ?>
        <div class="alert alert-success">No duplicate non-empty LRNs remain in the student master table.</div>
    <?php else: ?>
        <?php foreach ($studentDuplicateGroups as $group): ?>
            <div class="duplicate-group">
                <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
                    <div>
                        <strong>LRN:</strong> <?= htmlspecialchars($group['lrn']) ?>
                        <span class="text-muted ms-2">| School Year: <?= htmlspecialchars($group['school_year_label'] !== '' ? $group['school_year_label'] : 'Blank') ?></span>
                        <span class="badge bg-warning text-dark ms-2"><?= (int) $group['duplicate_count'] ?> duplicates</span>
                    </div>
                </div>
                <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                    <input type="hidden" name="action" value="resolve_duplicate_lrn">
                    <input type="hidden" name="table_key" value="students">
                    <input type="hidden" name="lrn" value="<?= htmlspecialchars($group['lrn']) ?>">
                    <input type="hidden" name="school_year_label" value="<?= htmlspecialchars($group['school_year_label']) ?>">
                    <div class="table-responsive">
                        <table class="table table-sm align-middle">
                            <thead>
                                <tr>
                                    <th>Keep</th>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>School Year</th>
                                    <th>Grade</th>
                                    <th>Section</th>
                                    <th>Guardian</th>
                                    <th>Created</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($group['records'] as $index => $record): ?>
                                <tr>
                                    <td><input type="radio" name="keep_id" value="<?= (int) $record['id'] ?>" <?= $index === 0 ? 'checked' : '' ?> required></td>
                                    <td><?= (int) $record['id'] ?></td>
                                    <td><?= htmlspecialchars(trim($record['lastname'] . ', ' . $record['firstname'] . ' ' . $record['middlename'])) ?></td>
                                    <td><?= htmlspecialchars($record['school_year_label'] !== '' ? $record['school_year_label'] : 'Blank') ?></td>
                                    <td><?= htmlspecialchars($record['grade'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($record['section'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($record['guardian_name'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($record['relevant_date'] ?? '') ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="mb-3" style="max-width: 260px;">
                        <label class="form-label small fw-semibold">Type CLEANUP to confirm</label>
                        <input type="text" name="confirm_phrase" class="form-control form-control-sm" required autocomplete="off">
                    </div>
                    <button type="submit" class="btn btn-outline-danger btn-sm">
                        <i class="fas fa-broom"></i> Keep Selected Record and Clear Duplicate LRNs
                    </button>
                </form>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <h3 class="h5 mb-3 mt-4">Pending Registrations</h3>
    <?php if (!$pendingDuplicateGroups): ?>
        <div class="alert alert-success">No duplicate non-empty LRNs remain in the pending registration table.</div>
    <?php else: ?>
        <?php foreach ($pendingDuplicateGroups as $group): ?>
            <div class="duplicate-group">
                <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
                    <div>
                        <strong>LRN:</strong> <?= htmlspecialchars($group['lrn']) ?>
                        <span class="text-muted ms-2">| School Year: <?= htmlspecialchars($group['school_year_label'] !== '' ? $group['school_year_label'] : 'Blank') ?></span>
                        <span class="badge bg-warning text-dark ms-2"><?= (int) $group['duplicate_count'] ?> duplicates</span>
                    </div>
                </div>
                <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                    <input type="hidden" name="action" value="resolve_duplicate_lrn">
                    <input type="hidden" name="table_key" value="pending">
                    <input type="hidden" name="lrn" value="<?= htmlspecialchars($group['lrn']) ?>">
                    <input type="hidden" name="school_year_label" value="<?= htmlspecialchars($group['school_year_label']) ?>">
                    <div class="table-responsive">
                        <table class="table table-sm align-middle">
                            <thead>
                                <tr>
                                    <th>Keep</th>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>School Year</th>
                                    <th>Grade</th>
                                    <th>Section</th>
                                    <th>Guardian</th>
                                    <th>Submitted</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($group['records'] as $index => $record): ?>
                                <tr>
                                    <td><input type="radio" name="keep_id" value="<?= (int) $record['id'] ?>" <?= $index === 0 ? 'checked' : '' ?> required></td>
                                    <td><?= (int) $record['id'] ?></td>
                                    <td><?= htmlspecialchars(trim($record['lastname'] . ', ' . $record['firstname'] . ' ' . $record['middlename'])) ?></td>
                                    <td><?= htmlspecialchars($record['school_year_label'] !== '' ? $record['school_year_label'] : 'Blank') ?></td>
                                    <td><?= htmlspecialchars($record['grade'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($record['section'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($record['guardian_name'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($record['relevant_date'] ?? '') ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <button type="submit" class="btn btn-outline-danger btn-sm">
                        <i class="fas fa-broom"></i> Keep Selected Record and Clear Duplicate LRNs
                    </button>
                </form>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<?= admin_session_warning_script() ?>
</body>
</html>
<?php $conn->close(); ?>
