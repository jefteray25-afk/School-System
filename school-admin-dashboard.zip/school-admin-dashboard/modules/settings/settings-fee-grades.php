<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/ui.php';
require '../../config/database.php';
require_once 'settings-permissions-roles.php';
require_once 'settings-security.php';
require_once 'school-info-helper.php';
require_once 'fee-grade-settings-helper.php';
include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$canAccessFeeGradeSettings = can_access_settings_page($role, 'fee_grades');

if (!$canAccessFeeGradeSettings) {
    header('Location: /school-admin-dashboard/modules/settings/settings-dashboard.php?error=settings_denied');
    exit();
}

fee_grade_settings_ensure_table($conn);
ensure_csrf_token();
$pageMessage = '';
$pageMessageType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_require_post_csrf();
    try {
        if (($_POST['fee_grade_action'] ?? '') === 'save_existing') {
            $rows = is_array($_POST['grades'] ?? null) ? $_POST['grades'] : [];
            $result = fee_grade_update_settings($conn, $rows);
            $pageMessage = 'Fee grade settings updated (' . (int) ($result['updated'] ?? 0) . ' rows processed).';
            audit_log($conn, $username, 'Updated fee grade settings', 'Settings', 'Role: ' . $role . ' | Updated rows: ' . (int) ($result['updated'] ?? 0), 'INFO');
        } elseif (($_POST['fee_grade_action'] ?? '') === 'add_grade') {
            $gradeCode = (int) ($_POST['new_grade_code'] ?? 0);
            $label = trim((string) ($_POST['new_grade_label'] ?? ''));
            $studentGradeValue = trim((string) ($_POST['new_student_grade_value'] ?? ''));
            $sortOrder = (int) ($_POST['new_sort_order'] ?? 0);
            $isActive = !empty($_POST['new_is_active']);
            fee_grade_add_setting($conn, $gradeCode, $label, $studentGradeValue, $sortOrder, $isActive);
            $pageMessage = 'New fee grade added successfully.';
            audit_log($conn, $username, 'Added fee grade setting', 'Settings', 'Role: ' . $role . ' | Grade code: ' . $gradeCode, 'INFO');
        }
    } catch (Throwable $e) {
        $pageMessage = $e->getMessage();
        $pageMessageType = 'danger';
    }
}

$gradeRows = fee_grade_catalog_rows($conn, true);
$activeCount = 0;
foreach ($gradeRows as $row) {
    if (!empty($row['is_active'])) {
        $activeCount++;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fee Grade Settings - School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <?php ui_css_link(); ?>
    <style>
        :root { --main-bg:#f5f8fc; --card-bg:#fff; --navbar-bg:#23395d; --brand-dark:#23395d; }
        body { background:var(--main-bg); font-family:'Segoe UI','Roboto','Arial',sans-serif; }
        .navbar { background:var(--navbar-bg) !important; box-shadow:0 2px 12px rgba(33,57,93,0.08); }
        .navbar-brand, .navbar-nav .nav-link { color:#fff !important; }
        .dashboard-header { text-align:center; margin-top:36px; margin-bottom:18px; }
        .dashboard-header img { width:70px; height:70px; object-fit:contain; margin-bottom:6px; }
        .dashboard-header h1 { font-size:1.3rem; color:var(--brand-dark); font-weight:700; margin-bottom:0; }
        .page-title { color:var(--brand-dark); font-weight:700; }
        .section-card { background:var(--card-bg); border:1px solid rgba(81,127,164,0.15); border-radius:1rem; box-shadow:0 4px 18px rgba(33,57,93,0.07); margin-bottom:1.25rem; }
        .summary-stat { background:#f8fbff; border:1px solid rgba(81,127,164,0.16); border-radius:1rem; padding:1rem 1.1rem; height:100%; }
        .summary-stat .label { text-transform:uppercase; font-size:0.74rem; color:#6c757d; font-weight:700; }
        .summary-stat .value { font-size:1.45rem; font-weight:700; color:var(--brand-dark); }
    </style>
</head>
<body>
<?php render_admin_nav('settings'); ?>

<div class="dashboard-header">
    <img src="<?= htmlspecialchars($schoolLogo) ?>" alt="School Logo" class="mb-2 rounded shadow-sm">
    <h1><?= htmlspecialchars($schoolName) ?></h1>
</div>

<div class="container pb-5">
    <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-4">
        <div>
            <h2 class="page-title mb-1"><i class="fas fa-layer-group me-2"></i>Fee Grade Settings</h2>
            <p class="text-muted mb-0">Manage the official grade catalog used by the Fee module. This is the source of truth for fee grade labels and grade matching.</p>
        </div>
        <a href="/school-admin-dashboard/modules/settings/settings-dashboard.php" class="btn btn-outline-secondary"><i class="fas fa-arrow-left me-1"></i>Back to Settings</a>
    </div>

    <?php if ($pageMessage !== ''): ?>
        <div class="alert alert-<?= htmlspecialchars($pageMessageType) ?>"><?= htmlspecialchars($pageMessage) ?></div>
    <?php endif; ?>

    <div class="row g-3 mb-4">
        <div class="col-12 col-md-4"><div class="summary-stat"><div class="label">Total Grade Rows</div><div class="value"><?= number_format(count($gradeRows)) ?></div></div></div>
        <div class="col-12 col-md-4"><div class="summary-stat"><div class="label">Active Grade Rows</div><div class="value"><?= number_format($activeCount) ?></div></div></div>
        <div class="col-12 col-md-4"><div class="summary-stat"><div class="label">Fee Module Use</div><div class="value" style="font-size:1rem;">Fee add, edit, and list</div></div></div>
    </div>

    <div class="section-card p-4">
        <h5 class="mb-3">Current Grade Catalog</h5>
        <p class="text-muted">`Label` is what appears in the fee screens. `Student grade match` is the exact student grade value used when auto-creating accounts for that fee setup.</p>
        <form method="post">
            <?= csrf_input() ?>
            <input type="hidden" name="fee_grade_action" value="save_existing">
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Grade Code</th>
                            <th>Display Label</th>
                            <th>Student Grade Match</th>
                            <th>Order</th>
                            <th>Active</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($gradeRows as $row): ?>
                        <tr>
                            <td>
                                <div class="fw-semibold"><?= (int) $row['grade_code'] ?></div>
                                <input type="hidden" name="grades[<?= (int) $row['grade_code'] ?>][grade_code]" value="<?= (int) $row['grade_code'] ?>">
                            </td>
                            <td><input type="text" class="form-control" name="grades[<?= (int) $row['grade_code'] ?>][label]" value="<?= htmlspecialchars($row['label']) ?>" maxlength="120"></td>
                            <td><input type="text" class="form-control" name="grades[<?= (int) $row['grade_code'] ?>][student_grade_value]" value="<?= htmlspecialchars($row['student_grade_value']) ?>" maxlength="120"></td>
                            <td style="width:120px;"><input type="number" class="form-control" name="grades[<?= (int) $row['grade_code'] ?>][sort_order]" value="<?= (int) $row['sort_order'] ?>"></td>
                            <td style="width:120px;">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="grades[<?= (int) $row['grade_code'] ?>][is_active]" value="1" <?= !empty($row['is_active']) ? 'checked' : '' ?>>
                                    <label class="form-check-label">Active</label>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="text-end">
                <button type="submit" class="btn btn-primary" onclick="return confirm('Save fee grade settings changes?');"><i class="fas fa-save me-1"></i>Save Fee Grade Settings</button>
            </div>
        </form>
    </div>

    <div class="section-card p-4">
        <h5 class="mb-3">Add New Grade Row</h5>
        <form method="post" class="row g-3 align-items-end">
            <?= csrf_input() ?>
            <input type="hidden" name="fee_grade_action" value="add_grade">
            <div class="col-md-2">
                <label class="form-label">Grade Code</label>
                <input type="number" class="form-control" name="new_grade_code" required>
            </div>
            <div class="col-md-3">
                <label class="form-label">Display Label</label>
                <input type="text" class="form-control" name="new_grade_label" required maxlength="120">
            </div>
            <div class="col-md-3">
                <label class="form-label">Student Grade Match</label>
                <input type="text" class="form-control" name="new_student_grade_value" required maxlength="120">
            </div>
            <div class="col-md-2">
                <label class="form-label">Order</label>
                <input type="number" class="form-control" name="new_sort_order" value="<?= (count($gradeRows) + 1) * 10 ?>">
            </div>
            <div class="col-md-1">
                <div class="form-check mt-4 pt-2">
                    <input class="form-check-input" type="checkbox" name="new_is_active" value="1" checked>
                    <label class="form-check-label">Active</label>
                </div>
            </div>
            <div class="col-md-1 text-end">
                <button type="submit" class="btn btn-outline-primary w-100" onclick="return confirm('Add this fee grade row?');"><i class="fas fa-plus"></i></button>
            </div>
        </form>
    </div>
</div>
</body>
</html>
