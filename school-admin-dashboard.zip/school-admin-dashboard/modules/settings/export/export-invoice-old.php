<?php
require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();

// Use correct path for config and vendor from export/ directory
require __DIR__ . '/../../../config/database.php';
require __DIR__ . '/../../../vendor/autoload.php';
include_once __DIR__ . '/../../../includes/includes-receipt-helper.php';
include_once __DIR__ . '/../../../includes/schema-migration.php';
require __DIR__ . '/../settings-permissions-roles.php';

$role = $_SESSION['role'] ?? '';
if (!hasPermission($role, 'financial', 'export')) {
    admin_session_forbidden();
}

function ensure_old_payment_datetime_column(mysqli $conn): void {
    if (!schema_migration_mode_enabled()) {
        return;
    }
    $columnName = 'paid_at_datetime';
    $check = $conn->prepare("
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'old_student_payments'
          AND COLUMN_NAME = ?
        LIMIT 1
    ");
    $check->bind_param('s', $columnName);
    $check->execute();
    $exists = $check->get_result()->num_rows > 0;
    $check->close();

    if (!$exists) {
        schema_migration_attempt($conn, "ALTER TABLE old_student_payments ADD COLUMN paid_at_datetime DATETIME NULL AFTER paid_at");
    }
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    $conn = database_open_connection();
}
ensure_old_payment_datetime_column($conn);

// Get all fee types dynamically (only those that exist in payment records)
$fee_types = [];
$res_types = $conn->query("SELECT DISTINCT fee_type FROM old_student_payments ORDER BY fee_type ASC");
while ($row = $res_types->fetch_assoc()) {
    $fee_types[] = $row['fee_type'];
}

// Get all old student receipts/payments (not deleted)
$sql = "
SELECT 
    p.id AS payment_id,
    p.paid_at,
    p.paid_at_datetime,
    p.booklet_no,
    p.receipt_no,
    p.amount,
    CONCAT(s.lastname, ', ', s.firstname, ' ', s.middlename) AS student_name,
    p.fee_type,
    p.note
FROM old_student_payments p
INNER JOIN receipts_registry rr
    ON rr.receipt_no = p.receipt_no
    AND rr.booklet_no = p.booklet_no
    AND rr.voided = 0
    AND rr.used_by = 'old_student_payments'
LEFT JOIN old_students s ON p.old_student_id = s.id
WHERE p.booklet_no IS NOT NULL 
  AND p.receipt_no IS NOT NULL 
  AND (p.deleted_at IS NULL OR p.deleted_at = '')
ORDER BY COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00')) DESC, p.id DESC
";
$res = $conn->query($sql);

// Group data by receipt number
$receipts = [];
if ($res && $res->num_rows > 0) {
    while ($row = $res->fetch_assoc()) {
        $rid = $row['booklet_no'] . '-' . $row['receipt_no'];
        if (!isset($receipts[$rid])) {
            $receipts[$rid] = [
                'student_name' => $row['student_name'],
                'paid_at' => $row['paid_at'],
                'paid_at_full' => $row['paid_at_datetime'] ?: ($row['paid_at'] ? $row['paid_at'] . ' 00:00:00' : ''),
                'booklet_no' => $row['booklet_no'],
                'booklet_label' => booklet_label_from_stored((int) $row['booklet_no']),
                'receipt_no' => $row['receipt_no'],
                'amounts' => [],
                'notes' => [],
            ];
        }
        // Only show amounts actually paid per receipt per fee_type
        $receipts[$rid]['amounts'][$row['fee_type']] = $row['amount'];
        $receipts[$rid]['notes'][$row['fee_type']] = $row['note'];
    }
}

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Header: static columns then dynamic fee types
$headers = [
    'A1' => 'Name',
    'B1' => 'Date',
    'C1' => 'Booklet No',
    'D1' => 'Receipt No'
];
$colNum = 5; // E
$typeCols = [];
foreach ($fee_types as $fee_type) {
    $colLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($colNum);
    $headers["{$colLetter}1"] = $fee_type;
    $typeCols[$fee_type] = $colLetter;
    $colNum++;
}
foreach ($headers as $cell => $text) { $sheet->setCellValue($cell, $text); }

// Compute last column letter for styling and merging (fix for empty dynamic columns)
$lastCol = 'D';
if (!empty($typeCols)) {
    // Get last column letter safely
    $typeCols_keys = array_keys($typeCols);
    $lastCol = $typeCols[end($typeCols_keys)];
}

// Fill data rows
$rowNum = 2;
$summary = [];
foreach ($receipts as $receipt) {
    $sheet->setCellValue("A$rowNum", $receipt['student_name']);
    $sheet->setCellValue("B$rowNum", $receipt['paid_at_full'] ? date('n/j/Y', strtotime($receipt['paid_at_full'])) : '');
    $sheet->setCellValueExplicit("C$rowNum", (string) ($receipt['booklet_label'] ?? ''), DataType::TYPE_STRING);
    $sheet->setCellValueExplicit("D$rowNum", (string) ($receipt['receipt_no'] ?? ''), DataType::TYPE_STRING);
    foreach ($typeCols as $fee_type => $colLetter) {
        $val = isset($receipt['amounts'][$fee_type]) ? $receipt['amounts'][$fee_type] : '';
        $note = isset($receipt['notes'][$fee_type]) ? $receipt['notes'][$fee_type] : '';
        $cellValue = $val !== '' ? (float) $val : '';
        $sheet->setCellValue("{$colLetter}{$rowNum}", $cellValue);
        if ($val !== '' && $note && !in_array($note, ['Outstanding', 'Fully Paid', 'Low Balance'])) {
            $sheet->getComment("{$colLetter}{$rowNum}")
                ->getText()
                ->createTextRun((string) $note);
        }

        // Add to summary
        if (!isset($summary[$fee_type])) $summary[$fee_type] = 0;
        if ($val !== '') $summary[$fee_type] += $val;
    }
    $rowNum++;
}

// Add summary row
$summaryRow = $rowNum;
$sheet->setCellValue("A$summaryRow", "Total Old Receipts:");
$sheet->setCellValue("B$summaryRow", count($receipts));
foreach ($typeCols as $fee_type => $colLetter) {
    $sheet->setCellValue("{$colLetter}{$summaryRow}", !empty($summary[$fee_type]) ? (float) $summary[$fee_type] : '');
}
$sheet->mergeCells("A$summaryRow:D$summaryRow");
$sheet->getStyle("A$summaryRow:$lastCol$summaryRow")->applyFromArray([
    'font' => ['bold' => true, 'size' => 18],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_RIGHT],
    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'FFFACD']]
]);

// Styling
$lastDataRow = $summaryRow;
$dataRange = "A1:$lastCol$lastDataRow";
$sheet->getStyle($dataRange)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
$sheet->getStyle("A2:$lastCol" . ($summaryRow - 1))->getFont()->setName('Arial')->setSize(16);
$sheet->getStyle("A2:A$lastDataRow")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_LEFT);
$sheet->getStyle("A2:A$lastDataRow")->getAlignment()->setWrapText(true);
$sheet->getStyle("C2:D$lastDataRow")->getNumberFormat()->setFormatCode('@');
if (!empty($typeCols)) {
    $firstAmountCol = reset($typeCols);
    $lastAmountCol = end($typeCols);
    $sheet->getStyle("{$firstAmountCol}2:{$lastAmountCol}{$lastDataRow}")
        ->getNumberFormat()
        ->setFormatCode('"PHP" #,##0.00');
}

$headerStyle = [
    'font' => ['bold' => true, 'size' => 20, 'name' => 'Arial'],
    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'BFEFFF']],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER]
];
$sheet->getStyle("A1:$lastCol" . "1")->applyFromArray($headerStyle);

$sheet->freezePane('A2');
$borderStyle = [
    'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => '333333']]]
];
$sheet->getStyle($dataRange)->applyFromArray($borderStyle);

// Autosize columns
$headerColCount = count($headers);
$maxColNum = $headerColCount + count($typeCols);
foreach (range('A', \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($maxColNum)) as $col) {
    $sheet->getColumnDimension($col)->setAutoSize(true);
}
$sheet->getColumnDimension('A')->setWidth(32);
$sheet->getColumnDimension('B')->setWidth(14);
$sheet->getColumnDimension('C')->setWidth(16);
$sheet->getColumnDimension('D')->setWidth(16);
for ($r = 1; $r <= $lastDataRow; $r++) {
    $sheet->getRowDimension($r)->setRowHeight(26);
}
$sheet->setAutoFilter("A1:$lastCol" . "1");

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="invoice_old.xlsx"');
header('Cache-Control: max-age=0');
$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
?>
