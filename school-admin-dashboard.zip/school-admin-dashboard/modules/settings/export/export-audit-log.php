<?php
require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();

// Correct config and vendor path from export/ directory
require __DIR__ . '/../../../config/database.php';
require __DIR__ . '/../../../vendor/autoload.php';
require __DIR__ . '/../settings-permissions-roles.php';

$role = $_SESSION['role'] ?? '';
if (!hasPermission($role, 'audit_logs', 'export')) {
    admin_session_forbidden();
}

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;

if (!isset($conn) || !($conn instanceof mysqli)) {
    $conn = database_open_connection();
}

// Get audit logs from 'audit_logs'
$sql = "SELECT id, log_date, user, action, module, details FROM audit_logs ORDER BY log_date DESC";
$result = $conn->query($sql);

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$headers = [
    'A1' => 'No.',
    'B1' => 'Date',
    'C1' => 'User',
    'D1' => 'Action',
    'E1' => 'Module',
    'F1' => 'Details'
];
foreach ($headers as $cell => $text) { $sheet->setCellValue($cell, $text); }
$row = 2; $num = 1;
while ($data = $result->fetch_assoc()) {
    $sheet->setCellValue("A$row", $num);
    $sheet->setCellValue("B$row", date('Y-m-d H:i:s', strtotime($data['log_date'])));
    $sheet->setCellValue("C$row", $data['user']);
    $sheet->setCellValue("D$row", $data['action']);
    $sheet->setCellValue("E$row", $data['module']);
    $sheet->setCellValue("F$row", $data['details']);
    $row++; $num++;
}
$conn->close();

$lastDataRow = $row - 1;
$dataRange = "A1:F" . $lastDataRow;
$sheet->getStyle($dataRange)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
$sheet->getStyle("A2:F" . $lastDataRow)->getFont()->setName('Arial')->setSize(16);
$headerStyle = [
    'font' => ['bold' => true, 'size' => 20, 'name' => 'Arial'],
    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'BFEFFF']],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER]
];
$sheet->getStyle('A1:F1')->applyFromArray($headerStyle);
$sheet->freezePane('A2');
$borderStyle = [
    'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => '333333']]]
];
$sheet->getStyle($dataRange)->applyFromArray($borderStyle);
foreach (range('A', 'F') as $col) { $sheet->getColumnDimension($col)->setAutoSize(true); }
for ($r = 1; $r <= $lastDataRow; $r++) { $sheet->getRowDimension($r)->setRowHeight(26); }
$sheet->setAutoFilter("A1:F1");

// Use a simple clean filename (no __ or extra underscores)
$filename = "audit_logs.xlsx";
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="' . $filename . '"');
header('Cache-Control: max-age=0');
$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
?>
