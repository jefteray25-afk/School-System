<?php
require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();

// Correct path from export/ to root
require __DIR__ . '/../../../config/database.php';
require __DIR__ . '/../../../vendor/autoload.php';
include __DIR__ . '/../../../modules/settings/settings-permissions-roles.php';
include_once __DIR__ . '/../../../includes/includes-receipt-helper.php';
require_once __DIR__ . '/../../../modules/settings/school-year-helper.php';
ensure_receipts_registry_schema($conn);

$currentRole = $_SESSION['role'] ?? '';
if (!hasPermission($currentRole, 'financial', 'view')) admin_session_forbidden();

school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
$active_school_year_label = school_year_get_active_label($conn);
$selected_school_year = trim($_GET['school_year'] ?? '');
if ($selected_school_year === '') {
    $selected_school_year = $active_school_year_label;
}

// Get all account types for dynamic columns (ordered by priority then name)
$account_types = [];
$res_types = $conn->query("SELECT id, name FROM account_types ORDER BY priority ASC, name ASC");
while ($row = $res_types->fetch_assoc()) {
    $account_types[$row['id']] = $row['name'];
}

// Get all receipts/payments with official OR info
$sql = "
SELECT 
    p.id AS payment_id,
    p.date_paid,
    p.booklet_no,
    p.receipt_no,
    p.amount,
    s.lrn,
    s.grade,
    CONCAT(s.lastname, ', ', s.firstname, ' ', s.middlename) AS student_name,
    at.id AS account_type_id,
    at.name AS account_type_name
FROM payments p
INNER JOIN receipts_registry rr
    ON rr.receipt_no = p.receipt_no
    AND rr.booklet_no = p.booklet_no
    AND rr.voided = 0
    AND rr.used_by IN ('payments', 'other_payment')
LEFT JOIN accounts a ON p.account_id = a.id
LEFT JOIN account_types at ON a.type = at.name
LEFT JOIN students s ON a.student_id = s.id
WHERE p.booklet_no IS NOT NULL AND p.receipt_no IS NOT NULL
  AND COALESCE(NULLIF(TRIM(p.school_year_label), ''), NULLIF(TRIM(a.school_year_label), ''), NULLIF(TRIM(s.school_year_label), '')) = ?
ORDER BY p.date_paid DESC, p.id DESC
";
$stmt = $conn->prepare($sql);
$res = false;
if ($stmt) {
    $stmt->bind_param('s', $selected_school_year);
    $stmt->execute();
    $res = $stmt->get_result();
    $stmt->close();
}

// Group data by receipt
$receipts = [];
if ($res && $res->num_rows > 0) {
    while ($row = $res->fetch_assoc()) {
        $rid = $row['booklet_no'] . '-' . $row['receipt_no'];
        if (!isset($receipts[$rid])) {
            $receipts[$rid] = [
                'student_name' => $row['student_name'],
                'grade' => $row['grade'],
                'lrn' => $row['lrn'],
                'date_paid' => $row['date_paid'],
                'booklet_no' => $row['booklet_no'],
                'booklet_label' => booklet_label_from_stored((int) $row['booklet_no']),
                'receipt_no' => $row['receipt_no'],
                'amounts' => []
            ];
        }
        if ($row['account_type_id']) {
            $receipts[$rid]['amounts'][$row['account_type_id']] = $row['amount'];
        }
    }
}

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Build header: static columns, then dynamic account types
$headers = [
    'A1' => 'Name',
    'B1' => 'Grade',
    'C1' => 'LRN',
    'D1' => 'Date',
    'E1' => 'Booklet No',
    'F1' => 'Receipt No'
];
$colNum = 7; // Start from column G
$typeCols = [];
foreach ($account_types as $type_id => $type_name) {
    $colLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($colNum);
    $headers["{$colLetter}1"] = $type_name;
    $typeCols[$type_id] = $colLetter;
    $colNum++;
}
foreach ($headers as $cell => $text) { $sheet->setCellValue($cell, $text); }

// Fill data rows
$rowNum = 2;
$summary = [];
foreach ($receipts as $receipt) {
    $sheet->setCellValue("A$rowNum", $receipt['student_name']);
    $sheet->setCellValue("B$rowNum", $receipt['grade']);
    $sheet->setCellValueExplicit("C$rowNum", (string) ($receipt['lrn'] ?? ''), DataType::TYPE_STRING);
    $sheet->setCellValue("D$rowNum", $receipt['date_paid'] ? date('n/j/Y', strtotime($receipt['date_paid'])) : '');
    $sheet->setCellValueExplicit("E$rowNum", (string) ($receipt['booklet_label'] ?? ''), DataType::TYPE_STRING);
    $sheet->setCellValueExplicit("F$rowNum", (string) ($receipt['receipt_no'] ?? ''), DataType::TYPE_STRING);
    foreach ($typeCols as $type_id => $colLetter) {
        $val = isset($receipt['amounts'][$type_id]) ? $receipt['amounts'][$type_id] : '';
        $sheet->setCellValue("{$colLetter}{$rowNum}", $val !== '' ? (float) $val : '');
        // Add to summary
        if (!isset($summary[$type_id])) $summary[$type_id] = 0;
        if ($val !== '') $summary[$type_id] += $val;
    }
    $rowNum++;
}

// Add summary row
$summaryRow = $rowNum;
$sheet->setCellValue("A$summaryRow", "Total Receipts:");
$sheet->setCellValue("B$summaryRow", count($receipts));
foreach ($typeCols as $type_id => $colLetter) {
    $sheet->setCellValue("{$colLetter}{$summaryRow}", !empty($summary[$type_id]) ? (float) $summary[$type_id] : '');
}
$sheet->mergeCells("A$summaryRow:F$summaryRow");
$sheet->getStyle("A$summaryRow:" . end($typeCols) . "$summaryRow")->applyFromArray([
    'font' => ['bold' => true, 'size' => 18],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_RIGHT],
    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'FFFACD']]
]);

// Styling
$lastDataRow = $summaryRow;
$dataRange = "A1:" . end($typeCols) . $lastDataRow;
$sheet->getStyle($dataRange)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
$sheet->getStyle("A2:" . end($typeCols) . ($summaryRow - 1))->getFont()->setName('Arial')->setSize(16);
$sheet->getStyle("A2:A$lastDataRow")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_LEFT);
$sheet->getStyle("A2:A$lastDataRow")->getAlignment()->setWrapText(true);
$sheet->getStyle("C2:C$lastDataRow")->getNumberFormat()->setFormatCode('@');
$sheet->getStyle("E2:F$lastDataRow")->getNumberFormat()->setFormatCode('@');
if (!empty($typeCols)) {
    $firstAmountCol = reset($typeCols);
    $lastAmountCol = end($typeCols);
    $sheet->getStyle("{$firstAmountCol}2:{$lastAmountCol}{$lastDataRow}")
        ->getNumberFormat()
        ->setFormatCode('"PHP" #,##0.00');
}

$headerStyle = [
    'font' => ['bold' => true, 'size' => 20, 'name' => 'Arial'],
    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'BFEFFF']],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER]
];
$sheet->getStyle('A1:' . end($typeCols) . '1')->applyFromArray($headerStyle);

$sheet->freezePane('A2');
$borderStyle = [
    'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => '333333']]]
];
$sheet->getStyle($dataRange)->applyFromArray($borderStyle);

foreach (range('A', end($typeCols)) as $col) {
    $sheet->getColumnDimension($col)->setAutoSize(true);
}
$sheet->getColumnDimension('A')->setWidth(32);
$sheet->getColumnDimension('C')->setWidth(18);
$sheet->getColumnDimension('D')->setWidth(14);
$sheet->getColumnDimension('E')->setWidth(16);
$sheet->getColumnDimension('F')->setWidth(16);
for ($r = 1; $r <= $lastDataRow; $r++) {
    $sheet->getRowDimension($r)->setRowHeight(26);
}
$sheet->setAutoFilter('A1:' . end($typeCols) . '1');

// Output
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="invoice_compilation_' . preg_replace('/[^A-Za-z0-9_-]+/', '_', $selected_school_year ?: 'all') . '.xlsx"');
header('Cache-Control: max-age=0');
$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
?>
