<?php
require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();

// Correct path from export/ to root
require __DIR__ . '/../../../config/database.php';
require __DIR__ . '/../../../vendor/autoload.php';
include __DIR__ . '/../../../modules/settings/settings-permissions-roles.php';

$role = $_SESSION['role'] ?? '';
if (!hasPermission($role, 'student_data', 'export')) {
    admin_session_forbidden();
}

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;

if (!isset($conn) || !($conn instanceof mysqli)) {
    $conn = database_open_connection();
}

// Fetch student data

$sql = "SELECT lrn, firstname, middlename, lastname, grade, birthday, age, gender, address, contact, guardian_name, guardian_contact, date_enrolled FROM students ORDER BY lastname ASC, firstname ASC";
$result = $conn->query($sql);

// Create spreadsheet
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Set headers (start at B1, A1 is for numbering)
$headers = [
    'A1' => 'No.',
    'B1' => 'LRN',
    'C1' => 'First Name',
    'D1' => 'Middle Name',
    'E1' => 'Last Name',
    'F1' => 'Grade',
    'G1' => 'Birthday',
    'H1' => 'Age',
    'I1' => 'Gender',
    'J1' => 'Address',
    'K1' => 'Contact',
    'L1' => 'Guardian Name',
    'M1' => 'Guardian Contact',
    'N1' => 'Date Enrolled'
];
foreach ($headers as $cell => $text) {
    $sheet->setCellValue($cell, $text);
}

// Fill data
$row = 2;
$num = 1;
while ($student = $result->fetch_assoc()) {
    $sheet->setCellValue("A$row", $num); // numbering
    $sheet->setCellValue("B$row", $student['lrn']);
    $sheet->setCellValue("C$row", $student['firstname']);
    $sheet->setCellValue("D$row", $student['middlename']);
    $sheet->setCellValue("E$row", $student['lastname']);
    $sheet->setCellValue("F$row", $student['grade']);
    // Format birthday mm-dd-yyyy
    $birthday = $student['birthday'] ? date('m-d-Y', strtotime($student['birthday'])) : '';
    $sheet->setCellValue("G$row", $birthday);
    $sheet->setCellValue("H$row", $student['age']);
    $sheet->setCellValue("I$row", $student['gender']);
    $sheet->setCellValue("J$row", $student['address']);
    $sheet->setCellValue("K$row", $student['contact']);
    $sheet->setCellValue("L$row", $student['guardian_name']);
    $sheet->setCellValue("M$row", $student['guardian_contact']);
    // Format date_enrolled mm-dd-yyyy
    $dateEnrolled = $student['date_enrolled'] ? date('m-d-Y', strtotime($student['date_enrolled'])) : '';
    $sheet->setCellValue("N$row", $dateEnrolled);

    // Gender-based color highlight (soft pink for female, soft blue for male)
    $rowRange = "A$row:N$row";
    if (strtolower($student['gender']) == 'female') {
        $sheet->getStyle($rowRange)->getFill()->setFillType(Fill::FILL_SOLID)
            ->getStartColor()->setRGB('FFE3F1'); // Soft pink
    } elseif (strtolower($student['gender']) == 'male') {
        $sheet->getStyle($rowRange)->getFill()->setFillType(Fill::FILL_SOLID)
            ->getStartColor()->setRGB('E3F0FF'); // Soft blue
    }

    $row++;
    $num++;
}

$conn->close();

// Styling variables
$lastDataRow = $row - 1;
$dataRange = "A1:N" . $lastDataRow;

// Center all columns and set font for all data (including headers)
$sheet->getStyle($dataRange)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
$sheet->getStyle("A2:N" . $lastDataRow)->getFont()->setName('Arial')->setSize(16);

// Header row: font size 20, bold, light blue fill
$headerStyle = [
    'font' => [
        'bold' => true,
        'size' => 20,
        'name' => 'Arial'
    ],
    'fill' => [
        'fillType' => Fill::FILL_SOLID,
        'startColor' => ['rgb' => 'BFEFFF'] // Light blue shade
    ],
    'alignment' => [
        'horizontal' => Alignment::HORIZONTAL_CENTER,
        'vertical' => Alignment::VERTICAL_CENTER
    ]
];
$sheet->getStyle('A1:N1')->applyFromArray($headerStyle);

// Freeze header row
$sheet->freezePane('A2');

// Apply borders to all cells
$borderStyle = [
    'borders' => [
        'allBorders' => [
            'borderStyle' => Border::BORDER_THIN,
            'color' => ['rgb' => '333333']
        ]
    ]
];
$sheet->getStyle($dataRange)->applyFromArray($borderStyle);

// Auto-size columns
foreach (range('A', 'N') as $col) {
    $sheet->getColumnDimension($col)->setAutoSize(true);
}

// Add row height "gap" (e.g. 26px for extra spacing)
for ($r = 1; $r <= $lastDataRow; $r++) {
    $sheet->getRowDimension($r)->setRowHeight(26);
}

// Add autofilter to header
$sheet->setAutoFilter("A1:N1");

// Output Excel file for download
$filename = "students.xlsx"; // No extra underscores or quotes
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="' . $filename . '"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
?>
