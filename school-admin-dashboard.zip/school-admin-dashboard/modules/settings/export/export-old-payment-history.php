<?php
require_once __DIR__ . '/../../../config/app-env.php';
ini_set('display_errors', '0');
error_reporting(E_ALL);

require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();

require __DIR__ . '/../../../config/database.php';
require __DIR__ . '/../../../vendor/autoload.php';
require_once __DIR__ . '/../../settings/settings-permissions-roles.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/includes-receipt-helper.php';
include_once __DIR__ . '/../../../modules/audit/audit-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/includes/schema-migration.php';
require_once __DIR__ . '/../../old accounts/old-payments-schema-helper.php';

$role = $_SESSION['role'] ?? '';
if (!hasPermission($role, 'financial', 'export')) {
    admin_session_forbidden();
}

function ensure_old_payment_datetime_column(mysqli $conn): void {
    if (!schema_migration_mode_enabled()) {
        return;
    }
    $columnName = 'paid_at_datetime';
    $check = $conn->prepare("
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'old_student_payments'
          AND COLUMN_NAME = ?
        LIMIT 1
    ");
    $check->bind_param('s', $columnName);
    $check->execute();
    $exists = $check->get_result()->num_rows > 0;
    $check->close();
    if (!$exists) {
        schema_migration_attempt($conn, "ALTER TABLE old_student_payments ADD COLUMN paid_at_datetime DATETIME NULL AFTER paid_at");
    }
}

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;

if (!isset($conn) || !($conn instanceof mysqli)) {
    $conn = database_open_connection();
}
ensure_old_payment_datetime_column($conn);

function old_payment_history_export_flush_xlsx(string $filename, Xlsx $writer): void {
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: max-age=0, no-cache, must-revalidate');
    header('Pragma: public');
    header('Expires: 0');

    $writer->save('php://output');
}

function old_export_extract_ref_from_note(?string $note): string
{
    $note = (string) ($note ?? '');
    if (preg_match('/Ref#:\s*([A-Za-z0-9\-_]+)/', $note, $m)) {
        return (string) $m[1];
    }
    return '';
}

function old_export_extract_note_from_status(?string $status): string
{
    $status = (string) ($status ?? '');
    if (preg_match('/\(Note:\s*(.*?)\)\s*$/i', $status, $m)) {
        return trim((string) $m[1]);
    }
    return '';
}

function old_export_infer_method(string $status, string $reference): string
{
    $s = strtolower($status);
    if (strpos($s, 'gcash') !== false) {
        return 'GCash';
    }
    if (strpos($s, 'bank transfer') !== false || strpos($s, 'banktransfer') !== false) {
        return 'Bank Transfer';
    }
    if ($reference !== '') {
        return 'Digital';
    }
    return '-';
}

$student_id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($student_id <= 0) {
    die('Invalid old student ID.');
}

$stmt = $conn->prepare("SELECT * FROM old_students WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$student) {
    die('Old student not found.');
}

$fee_rows = [];
$stmt = $conn->prepare("SELECT fee_type, balance FROM old_student_fees WHERE old_student_id = ? ORDER BY fee_type ASC");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$fee_result = $stmt->get_result();
while ($row = $fee_result->fetch_assoc()) {
    $fee_rows[] = $row;
}
$stmt->close();

$payments = [];
$stmt = $conn->prepare("SELECT *, COALESCE(paid_at_datetime, CONCAT(paid_at, ' 00:00:00')) AS paid_at_full FROM old_student_payments WHERE old_student_id = ? AND deleted_at IS NULL ORDER BY COALESCE(paid_at_datetime, CONCAT(paid_at, ' 00:00:00')) DESC, id DESC");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$payment_result = $stmt->get_result();
while ($row = $payment_result->fetch_assoc()) {
    $receipt_no = (int) ($row['receipt_no'] ?? 0);
    $booklet_no = (int) ($row['booklet_no'] ?? 0);
    $receipt_entry = ($receipt_no > 0) ? get_receipt_registry_entry($conn, $receipt_no, $booklet_no) : null;
    if ($receipt_entry && (int) ($receipt_entry['voided'] ?? 0) === 1) {
        $row['receipt_state'] = 'Voided';
    } elseif ($receipt_entry) {
        $row['receipt_state'] = 'Linked';
    } else {
        $row['receipt_state'] = 'Missing';
    }
    $payments[] = $row;
}
$stmt->close();

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Old Payment History');

$student_name = trim(($student['lastname'] ?? '') . ', ' . ($student['firstname'] ?? '') . ' ' . ($student['middlename'] ?? ''));
$sheet->setCellValue('A1', 'Old Student Payment History');
$sheet->mergeCells('A1:L1');
$sheet->setCellValue('A2', 'Student');
$sheet->setCellValue('B2', $student_name);
$sheet->setCellValue('D2', 'School Year');
$sheet->setCellValue('E2', $student['school_year'] ?? '');
$sheet->setCellValue('G2', 'Status');
$sheet->setCellValue('H2', ucfirst((string) ($student['status'] ?? '')));
$sheet->setCellValue('J2', 'Generated On');
$sheet->setCellValue('K2', date('F j, Y g:i A'));
$sheet->setCellValue('A3', 'Contact');
$sheet->setCellValue('B3', $student['contact'] ?? '');
$sheet->setCellValue('D3', 'Notes');
$sheet->setCellValue('E3', $student['notes'] ?? '');

$sheet->setCellValue('A5', 'Fee Type');
$sheet->setCellValue('B5', 'Balance');
$fee_row_no = 6;
foreach ($fee_rows as $fee_row) {
    $sheet->setCellValue("A$fee_row_no", $fee_row['fee_type']);
    $sheet->setCellValue("B$fee_row_no", (float) ($fee_row['balance'] ?? 0));
    $fee_row_no++;
}

$payment_start_row = max(8, $fee_row_no + 2);
$payment_headers = [
    "A$payment_start_row" => 'Date Paid',
    "B$payment_start_row" => 'Time Paid',
    "C$payment_start_row" => 'Booklet No',
    "D$payment_start_row" => 'Receipt No',
    "E$payment_start_row" => 'Receipt State',
    "F$payment_start_row" => 'Fee Type',
    "G$payment_start_row" => 'Amount',
    "H$payment_start_row" => 'Payment Method',
    "I$payment_start_row" => 'Reference No.',
    "J$payment_start_row" => 'Payment Note',
    "K$payment_start_row" => 'Status',
];
foreach ($payment_headers as $cell => $text) {
    $sheet->setCellValue($cell, $text);
}

$row = $payment_start_row + 1;
foreach ($payments as $payment) {
    $dt = !empty($payment['paid_at_full']) ? new DateTime($payment['paid_at_full']) : null;
    $statusText = (string) ($payment['note'] ?? '');
    $method = (string) ($payment['payment_method'] ?? '');
    $reference = (string) ($payment['reference_number'] ?? '');
    $paymentNote = (string) ($payment['payment_note'] ?? '');
    if ($reference === '' && $statusText !== '') {
        $reference = old_export_extract_ref_from_note($statusText);
    }
    if ($paymentNote === '' && $statusText !== '') {
        $paymentNote = old_export_extract_note_from_status($statusText);
    }
    if ($method === '' && $statusText !== '') {
        $method = old_export_infer_method($statusText, $reference);
    }

    $sheet->setCellValue("A$row", $dt ? $dt->format('m-d-Y') : '');
    $sheet->setCellValue("B$row", $dt ? $dt->format('h:i A') : '');
    $sheet->setCellValue("C$row", booklet_label_from_stored((int) ($payment['booklet_no'] ?? 0)));
    $sheet->setCellValue("D$row", (int) ($payment['receipt_no'] ?? 0));
    $sheet->setCellValue("E$row", $payment['receipt_state']);
    $sheet->setCellValue("F$row", $payment['fee_type'] ?? '');
    $sheet->setCellValue("G$row", (float) ($payment['amount'] ?? 0));
    $sheet->setCellValue("H$row", $method !== '' ? $method : '-');
    $sheet->setCellValue("I$row", $reference !== '' ? $reference : '-');
    $sheet->setCellValue("J$row", $paymentNote !== '' ? $paymentNote : '-');
    $sheet->setCellValue("K$row", $statusText !== '' ? $statusText : '-');
    $row++;
}

$lastDataRow = max($payment_start_row, $row - 1);

$sheet->getStyle('A1:L1')->getFont()->setBold(true)->setSize(18)->setName('Segoe UI');
$sheet->getStyle('A1:L1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
$sheet->getStyle('A2:K3')->getFont()->setName('Segoe UI')->setSize(10);
$sheet->getStyle("A5:B5")->applyFromArray([
    'font' => ['bold' => true, 'name' => 'Segoe UI'],
    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'F4E1C1']],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER],
]);
$sheet->getStyle("A$payment_start_row:K$payment_start_row")->applyFromArray([
    'font' => ['bold' => true, 'name' => 'Segoe UI'],
    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'D9EAF7']],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER],
]);
$sheet->getStyle("B6:B" . max(6, $fee_row_no - 1))->getNumberFormat()->setFormatCode('#,##0.00');
$sheet->getStyle("G" . ($payment_start_row + 1) . ":G$lastDataRow")->getNumberFormat()->setFormatCode('#,##0.00');
$sheet->getStyle("A5:B" . max(5, $fee_row_no - 1))->applyFromArray([
    'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => '333333']]],
]);
$sheet->getStyle("A$payment_start_row:K$lastDataRow")->applyFromArray([
    'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => '333333']]],
]);
$sheet->getStyle("A" . ($payment_start_row + 1) . ":K$lastDataRow")->getFont()->setName('Segoe UI')->setSize(10);
$sheet->freezePane("A" . ($payment_start_row + 1));
foreach (range('A', 'L') as $col) {
    $sheet->getColumnDimension($col)->setAutoSize(true);
}

$safe_name = preg_replace('/[^A-Za-z0-9_-]+/', '_', $student_name);
$exportedBy = $_SESSION['username'] ?? 'unknown';
$studentSummary = 'Old Student ID: ' . $student_id
    . ' | Student: ' . ($student_name !== '' ? $student_name : 'Unknown')
    . ' | Fee Rows: ' . count($fee_rows)
    . ' | Payment Rows: ' . count($payments);
audit_log($conn, $exportedBy, 'Exported old payment history Excel', 'Old Accounts', $studentSummary);
$conn->close();

$writer = new Xlsx($spreadsheet);
$spreadsheet->setActiveSheetIndex(0);
old_payment_history_export_flush_xlsx('old_payment_history_' . $safe_name . '.xlsx', $writer);
exit;
