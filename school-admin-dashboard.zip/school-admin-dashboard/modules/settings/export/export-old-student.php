<?php
require_once __DIR__ . '/../../../config/app-env.php';
ini_set('display_errors', '0');
error_reporting(E_ALL);

require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();

// Correct config and vendor path from export/ directory
require __DIR__ . '/../../../config/database.php';
require __DIR__ . '/../../../vendor/autoload.php';
require __DIR__ . '/../settings-permissions-roles.php';
include_once __DIR__ . '/../../../modules/audit/audit-helper.php';

$role = $_SESSION['role'] ?? '';
if (!hasPermission($role, 'student_data', 'export')) {
    admin_session_forbidden();
}

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;

if (!isset($conn) || !($conn instanceof mysqli)) {
    $conn = database_open_connection();
}

function old_students_export_flush_xlsx(string $filename, Xlsx $writer): void {
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: max-age=0, no-cache, must-revalidate');
    header('Pragma: public');
    header('Expires: 0');

    $writer->save('php://output');
}

$name_filter = trim((string) ($_GET['name'] ?? ''));
$school_year_filter = trim((string) ($_GET['school_year'] ?? ''));
$status_filter = trim((string) ($_GET['status'] ?? ''));
$sort_order = (($_GET['sort'] ?? 'az') === 'za') ? 'DESC' : 'ASC';

$sql = "SELECT id, lastname, firstname, middlename, contact, status, school_year, notes FROM old_students";
$where_clauses = [];
$params = [];
$types = '';

if ($school_year_filter !== '') {
    $where_clauses[] = "school_year = ?";
    $params[] = $school_year_filter;
    $types .= 's';
}
if ($status_filter !== '') {
    $where_clauses[] = "status = ?";
    $params[] = $status_filter;
    $types .= 's';
}
if ($name_filter !== '') {
    $where_clauses[] = "(lastname LIKE ? OR firstname LIKE ? OR middlename LIKE ?)";
    $like = '%' . $name_filter . '%';
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $types .= 'sss';
}
if ($where_clauses) {
    $sql .= " WHERE " . implode(" AND ", $where_clauses);
}
$sql .= " ORDER BY lastname $sort_order, firstname $sort_order";

if ($where_clauses) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($sql);
}

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setCellValue('A1', 'Old Students Export');
$sheet->mergeCells('A1:H1');
$sheet->setCellValue('A2', 'Name Filter');
$sheet->setCellValue('B2', $name_filter !== '' ? $name_filter : 'All');
$sheet->setCellValue('D2', 'School Year');
$sheet->setCellValue('E2', $school_year_filter !== '' ? $school_year_filter : 'All');
$sheet->setCellValue('G2', 'Status');
$sheet->setCellValue('H2', $status_filter !== '' ? ucfirst($status_filter) : 'All');

$headers = [
    'A4' => 'No.',
    'B4' => 'Last Name',
    'C4' => 'First Name',
    'D4' => 'Middle Name',
    'E4' => 'School Year',
    'F4' => 'Status',
    'G4' => 'Contact',
    'H4' => 'Reason/Notes'
];
foreach ($headers as $cell => $text) { $sheet->setCellValue($cell, $text); }
$row = 5; $num = 1;
while ($data = $result->fetch_assoc()) {
    $sheet->setCellValue("A$row", $num);
    $sheet->setCellValue("B$row", $data['lastname']);
    $sheet->setCellValue("C$row", $data['firstname']);
    $sheet->setCellValue("D$row", $data['middlename']);
    $sheet->setCellValue("E$row", $data['school_year']);
    $sheet->setCellValue("F$row", $data['status']);
    $sheet->setCellValue("G$row", $data['contact']);
    $sheet->setCellValue("H$row", $data['notes']);
    $row++; $num++;
}
if (isset($stmt) && $stmt instanceof mysqli_stmt) {
    $stmt->close();
}

$lastDataRow = $row - 1;
$dataRange = "A4:H" . $lastDataRow;
$sheet->getStyle('A1:H1')->getFont()->setBold(true)->setSize(18)->setName('Arial');
$sheet->getStyle('A1:H1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
$sheet->getStyle($dataRange)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
$sheet->getStyle("A5:H" . $lastDataRow)->getFont()->setName('Arial')->setSize(16);
$headerStyle = [
    'font' => ['bold' => true, 'size' => 20, 'name' => 'Arial'],
    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'BFEFFF']],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER]
];
$sheet->getStyle('A4:H4')->applyFromArray($headerStyle);
$sheet->freezePane('A5');
$borderStyle = [
    'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => '333333']]]
];
$sheet->getStyle($dataRange)->applyFromArray($borderStyle);
foreach (range('A', 'H') as $col) { $sheet->getColumnDimension($col)->setAutoSize(true); }
for ($r = 1; $r <= $lastDataRow; $r++) { $sheet->getRowDimension($r)->setRowHeight(26); }
$sheet->setAutoFilter("A4:H4");

$exportedBy = $_SESSION['username'] ?? 'unknown';
$filterSummary = 'Name: ' . ($name_filter !== '' ? $name_filter : 'All')
    . ' | School Year: ' . ($school_year_filter !== '' ? $school_year_filter : 'All')
    . ' | Status: ' . ($status_filter !== '' ? $status_filter : 'All')
    . ' | Rows: ' . max(0, $lastDataRow - 4);
audit_log($conn, $exportedBy, 'Exported old students Excel', 'Old Accounts', $filterSummary);
$conn->close();

$writer = new Xlsx($spreadsheet);
$spreadsheet->setActiveSheetIndex(0);
old_students_export_flush_xlsx('old_students.xlsx', $writer);
exit;
?>
