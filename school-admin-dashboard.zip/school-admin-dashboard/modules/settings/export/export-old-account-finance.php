<?php
require_once __DIR__ . '/../../../config/app-env.php';
ini_set('display_errors', '0');
error_reporting(E_ALL);

require __DIR__ . '/../../../includes/admin-session.php';
admin_session_require_login();

require __DIR__ . '/../../../config/database.php';
require __DIR__ . '/../../../vendor/autoload.php';
include_once __DIR__ . '/../../old accounts/old-account-followup-helper.php';
require __DIR__ . '/../settings-permissions-roles.php';
include_once __DIR__ . '/../../../modules/audit/audit-helper.php';

$role = $_SESSION['role'] ?? '';
if (!hasPermission($role, 'financial', 'export')) {
    admin_session_forbidden();
}

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;

if (!isset($conn) || !($conn instanceof mysqli)) {
    $conn = database_open_connection();
}
ensure_old_student_followup_columns($conn);

function old_account_finance_export_flush_xlsx(string $filename, Xlsx $writer): void {
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: max-age=0, no-cache, must-revalidate');
    header('Pragma: public');
    header('Expires: 0');

    $writer->save('php://output');
}

$name_filter = trim((string) ($_GET['name'] ?? ''));
$school_year_filter = trim((string) ($_GET['school_year'] ?? ''));
$status_filter = trim((string) ($_GET['status'] ?? ''));
$follow_up_filter = trim((string) ($_GET['follow_up'] ?? ''));
$sort_order = (($_GET['sort'] ?? 'az') === 'za') ? 'DESC' : 'ASC';

$sql = "
    SELECT
        os.id,
        os.lastname,
        os.firstname,
        os.middlename,
        os.school_year,
        os.status,
        os.follow_up_status,
        os.follow_up_note,
        os.contact,
        os.notes,
        COALESCE(fee_summary.fee_rows, 0) AS fee_rows,
        COALESCE(fee_summary.total_balance, 0) AS total_balance,
        COALESCE(payment_summary.payment_rows, 0) AS payment_rows,
        COALESCE(payment_summary.total_paid, 0) AS total_paid
    FROM old_students os
    LEFT JOIN (
        SELECT old_student_id, COUNT(*) AS fee_rows, SUM(balance) AS total_balance
        FROM old_student_fees
        GROUP BY old_student_id
    ) fee_summary ON fee_summary.old_student_id = os.id
    LEFT JOIN (
        SELECT old_student_id, COUNT(*) AS payment_rows, SUM(amount) AS total_paid
        FROM old_student_payments
        WHERE deleted_at IS NULL
        GROUP BY old_student_id
    ) payment_summary ON payment_summary.old_student_id = os.id
";

$where_clauses = [];
$params = [];
$types = '';

if ($school_year_filter !== '') {
    $where_clauses[] = "os.school_year = ?";
    $params[] = $school_year_filter;
    $types .= 's';
}

if ($status_filter !== '') {
    $where_clauses[] = "os.status = ?";
    $params[] = $status_filter;
    $types .= 's';
}
if ($follow_up_filter !== '') {
    $where_clauses[] = "os.follow_up_status = ?";
    $params[] = $follow_up_filter;
    $types .= 's';
}

if ($name_filter !== '') {
    $where_clauses[] = "(os.lastname LIKE ? OR os.firstname LIKE ? OR os.middlename LIKE ?)";
    $like = '%' . $name_filter . '%';
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $types .= 'sss';
}

if ($where_clauses) {
    $sql .= " WHERE " . implode(" AND ", $where_clauses);
}

$sql .= " ORDER BY os.lastname $sort_order, os.firstname $sort_order";

if ($where_clauses) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($sql);
}

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Old Account Finance');

$sheet->setCellValue('A1', 'Old Account Finance Summary');
$sheet->mergeCells('A1:L1');
$sheet->setCellValue('A2', 'Name Filter');
$sheet->setCellValue('B2', $name_filter !== '' ? $name_filter : 'All');
$sheet->setCellValue('D2', 'School Year');
$sheet->setCellValue('E2', $school_year_filter !== '' ? $school_year_filter : 'All');
$sheet->setCellValue('G2', 'Status');
$sheet->setCellValue('H2', $status_filter !== '' ? ucfirst($status_filter) : 'All');
$sheet->setCellValue('J2', 'Sort: ' . (($sort_order === 'DESC') ? 'Z-A' : 'A-Z'));

$headers = [
    'A4' => 'No.',
    'B4' => 'Student Name',
    'C4' => 'School Year',
    'D4' => 'Status',
    'E4' => 'Follow-up',
    'F4' => 'Contact',
    'G4' => 'Fee Rows',
    'H4' => 'Payment Rows',
    'I4' => 'Total Paid',
    'J4' => 'Total Balance',
    'K4' => 'Notes',
    'L4' => 'Follow-up Note',
];
foreach ($headers as $cell => $text) {
    $sheet->setCellValue($cell, $text);
}

$row = 5;
$num = 1;
while ($data = $result->fetch_assoc()) {
    $student_name = trim(($data['lastname'] ?? '') . ', ' . ($data['firstname'] ?? '') . ' ' . ($data['middlename'] ?? ''));
    $sheet->setCellValue("A$row", $num);
    $sheet->setCellValue("B$row", $student_name);
    $sheet->setCellValue("C$row", $data['school_year']);
    $sheet->setCellValue("D$row", ucfirst((string) ($data['status'] ?? '')));
    $sheet->setCellValue("E$row", old_account_followup_label($data['follow_up_status'] ?? 'record_only'));
    $sheet->setCellValue("F$row", $data['contact']);
    $sheet->setCellValue("G$row", (int) ($data['fee_rows'] ?? 0));
    $sheet->setCellValue("H$row", (int) ($data['payment_rows'] ?? 0));
    $sheet->setCellValue("I$row", (float) ($data['total_paid'] ?? 0));
    $sheet->setCellValue("J$row", (float) ($data['total_balance'] ?? 0));
    $sheet->setCellValue("K$row", $data['notes']);
    $sheet->setCellValue("L$row", $data['follow_up_note']);
    $row++;
    $num++;
}

if (isset($stmt) && $stmt instanceof mysqli_stmt) {
    $stmt->close();
}

$lastDataRow = max(4, $row - 1);
$dataRange = "A4:L" . $lastDataRow;

$sheet->getStyle('A1:L1')->getFont()->setBold(true)->setSize(18)->setName('Arial');
$sheet->getStyle('A1:L1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
$sheet->getStyle('A2:J2')->getFont()->setBold(true);
$sheet->getStyle('A4:L4')->applyFromArray([
    'font' => ['bold' => true, 'size' => 12, 'name' => 'Arial'],
    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'D9EAF7']],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER],
]);
$sheet->getStyle("A5:H$lastDataRow")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
$sheet->getStyle("I5:J$lastDataRow")->getNumberFormat()->setFormatCode('#,##0.00');
$sheet->getStyle($dataRange)->applyFromArray([
    'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => '333333']]],
]);
$sheet->freezePane('A5');
$sheet->setAutoFilter('A4:L4');
foreach (range('A', 'L') as $col) {
    $sheet->getColumnDimension($col)->setAutoSize(true);
}

$exportedBy = $_SESSION['username'] ?? 'unknown';
$filterSummary = 'Name: ' . ($name_filter !== '' ? $name_filter : 'All')
    . ' | School Year: ' . ($school_year_filter !== '' ? $school_year_filter : 'All')
    . ' | Status: ' . ($status_filter !== '' ? $status_filter : 'All')
    . ' | Follow-up: ' . ($follow_up_filter !== '' ? $follow_up_filter : 'All')
    . ' | Rows: ' . max(0, $lastDataRow - 4);
audit_log($conn, $exportedBy, 'Exported old account finance summary Excel', 'Old Accounts', $filterSummary);
$conn->close();

$writer = new Xlsx($spreadsheet);
$spreadsheet->setActiveSheetIndex(0);
old_account_finance_export_flush_xlsx('old_account_finance_summary.xlsx', $writer);
exit;
