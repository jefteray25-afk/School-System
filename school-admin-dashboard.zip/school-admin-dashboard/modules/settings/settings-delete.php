<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once 'settings-permissions-roles.php';
if (!can_access_settings_page((string) ($_SESSION['role'] ?? ''), 'user_management')) {
    header('Location: /Admin.php');
    exit();
}

include __DIR__ . '/../../config/database.php';
require_once 'settings-security.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

function log_admin_action($conn, $action, $targetUsername, $actorUsername) {
    $stmt = $conn->prepare('INSERT INTO admin_logs (action, target_username, actor_username, timestamp) VALUES (?, ?, ?, NOW())');
    $stmt->bind_param('sss', $action, $targetUsername, $actorUsername);
    $stmt->execute();
    $stmt->close();
}

if (!isset($_GET['id'])) {
    header('Location: settings-admin-users.php');
    exit();
}

$id = (int) $_GET['id'];
$stmt = $conn->prepare('SELECT username, role FROM admins WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$stmt->bind_result($username, $role);
$stmt->fetch();
$stmt->close();

if (!$username) {
    header('Location: settings-admin-users.php?error=notfound');
    exit();
}

if ($username === ($_SESSION['username'] ?? '') || $role === 'Super Administrator') {
    $error = 'You cannot delete this account.';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
    admin_require_post_csrf();
    $stmt = $conn->prepare('DELETE FROM admins WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();

    log_admin_action($conn, 'delete_user', $username, $_SESSION['username']);
    audit_log(
        $conn,
        $_SESSION['username'] ?? 'unknown',
        'Deleted admin user',
        'Settings',
        'Target Username: ' . $username . ' | Target Role: ' . $role,
        'WARNING'
    );
    header('Location: settings-admin-users.php?deleted=1');
    exit();
}

ensure_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="mt-5 mb-3">
        <h3><i class="fas fa-trash"></i> Delete User</h3>
        <hr>
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <a href="settings-admin-users.php" class="btn btn-secondary">Back to User List</a>
        <?php else: ?>
            <div class="alert alert-danger">
                <strong>Warning:</strong> This action is <u>irreversible</u> and will permanently delete the user <strong><?= htmlspecialchars($username) ?></strong> (<?= htmlspecialchars($role) ?>).<br>
                All data associated with this user will be lost. You cannot undo this operation.
                <br><br>
                <span class="text-danger">Are you absolutely sure you want to proceed?</span>
            </div>
            <form method="post">
                <?= csrf_input() ?>
                <button type="submit" name="confirm_delete" class="btn btn-danger">
                    <i class="fas fa-trash"></i> Yes, Delete Permanently
                </button>
                <a href="settings-admin-users.php" class="btn btn-secondary ms-2">Cancel</a>
            </form>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
