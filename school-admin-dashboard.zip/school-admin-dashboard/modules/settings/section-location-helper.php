<?php
require_once __DIR__ . '/../../includes/schema-migration.php';

function section_location_table_exists(mysqli $conn): bool
{
    $result = $conn->query("SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'section_room_assignments' LIMIT 1");
    return $result && $result->num_rows > 0;
}

function section_location_ensure_table(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }
    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS section_room_assignments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        school_year_label VARCHAR(30) NOT NULL,
        grade_level VARCHAR(40) NOT NULL,
        section_name VARCHAR(100) NOT NULL,
        adviser_name VARCHAR(150) NOT NULL DEFAULT '',
        building_name VARCHAR(150) NOT NULL DEFAULT '',
        floor_name VARCHAR(100) NOT NULL DEFAULT '',
        room_name VARCHAR(100) NOT NULL DEFAULT '',
        updated_by VARCHAR(100) NOT NULL DEFAULT '',
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_section_room_assignment (school_year_label, grade_level, section_name),
        INDEX idx_section_room_lookup (school_year_label, grade_level, section_name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
}

function section_location_get(mysqli $conn, string $schoolYear, string $grade, string $section): ?array
{
    if (!section_location_table_exists($conn)) {
        return null;
    }
    $stmt = $conn->prepare('SELECT id, school_year_label, grade_level, section_name, adviser_name, building_name, floor_name, room_name, updated_by, updated_at FROM section_room_assignments WHERE school_year_label = ? AND grade_level = ? AND section_name = ? LIMIT 1');
    if (!$stmt) {
        return null;
    }
    $stmt->bind_param('sss', $schoolYear, $grade, $section);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();
    return $row;
}

function section_location_list(mysqli $conn, string $schoolYear): array
{
    if (!section_location_table_exists($conn)) {
        return [];
    }
    $stmt = $conn->prepare('SELECT id, school_year_label, grade_level, section_name, adviser_name, building_name, floor_name, room_name, updated_by, updated_at FROM section_room_assignments WHERE school_year_label = ? ORDER BY grade_level ASC, section_name ASC');
    if (!$stmt) {
        return [];
    }
    $stmt->bind_param('s', $schoolYear);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}

function section_location_save(mysqli $conn, array $input, string $username): bool
{
    $schoolYear = trim((string) ($input['school_year_label'] ?? ''));
    $grade = trim((string) ($input['grade_level'] ?? ''));
    $section = trim((string) ($input['section_name'] ?? ''));
    if ($schoolYear === '' || $grade === '' || $section === '') {
        return false;
    }
    $adviser = trim((string) ($input['adviser_name'] ?? ''));
    $building = trim((string) ($input['building_name'] ?? ''));
    $floor = trim((string) ($input['floor_name'] ?? ''));
    $room = trim((string) ($input['room_name'] ?? ''));
    $stmt = $conn->prepare("INSERT INTO section_room_assignments (school_year_label, grade_level, section_name, adviser_name, building_name, floor_name, room_name, updated_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE adviser_name=VALUES(adviser_name), building_name=VALUES(building_name), floor_name=VALUES(floor_name), room_name=VALUES(room_name), updated_by=VALUES(updated_by)");
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('ssssssss', $schoolYear, $grade, $section, $adviser, $building, $floor, $room, $username);
    $success = $stmt->execute();
    $stmt->close();
    return $success;
}
