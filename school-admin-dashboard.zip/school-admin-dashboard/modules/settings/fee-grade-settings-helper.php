<?php

require_once __DIR__ . '/../../includes/schema-migration.php';

function fee_grade_default_rows(): array
{
    return [
        ['grade_code' => 101, 'label' => 'Junior Kindergarten', 'student_grade_value' => 'Junior Kindergarten', 'sort_order' => 10, 'is_active' => 1],
        ['grade_code' => 102, 'label' => 'Senior Kindergarten', 'student_grade_value' => 'Senior Kindergarten', 'sort_order' => 20, 'is_active' => 1],
        ['grade_code' => 1, 'label' => 'Grade 1', 'student_grade_value' => 'Grade 1', 'sort_order' => 30, 'is_active' => 1],
        ['grade_code' => 2, 'label' => 'Grade 2', 'student_grade_value' => 'Grade 2', 'sort_order' => 40, 'is_active' => 1],
        ['grade_code' => 3, 'label' => 'Grade 3', 'student_grade_value' => 'Grade 3', 'sort_order' => 50, 'is_active' => 1],
        ['grade_code' => 4, 'label' => 'Grade 4', 'student_grade_value' => 'Grade 4', 'sort_order' => 60, 'is_active' => 1],
        ['grade_code' => 5, 'label' => 'Grade 5', 'student_grade_value' => 'Grade 5', 'sort_order' => 70, 'is_active' => 1],
        ['grade_code' => 6, 'label' => 'Grade 6', 'student_grade_value' => 'Grade 6', 'sort_order' => 80, 'is_active' => 1],
        ['grade_code' => 7, 'label' => 'Grade 7', 'student_grade_value' => 'Grade 7', 'sort_order' => 90, 'is_active' => 1],
        ['grade_code' => 8, 'label' => 'Grade 8', 'student_grade_value' => 'Grade 8', 'sort_order' => 100, 'is_active' => 1],
        ['grade_code' => 9, 'label' => 'Grade 9', 'student_grade_value' => 'Grade 9', 'sort_order' => 110, 'is_active' => 1],
        ['grade_code' => 10, 'label' => 'Grade 10', 'student_grade_value' => 'Grade 10', 'sort_order' => 120, 'is_active' => 1],
        ['grade_code' => 11, 'label' => 'Grade 11', 'student_grade_value' => 'Grade 11', 'sort_order' => 130, 'is_active' => 1],
        ['grade_code' => 12, 'label' => 'Grade 12', 'student_grade_value' => 'Grade 12', 'sort_order' => 140, 'is_active' => 1],
    ];
}

function fee_grade_settings_ensure_table(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }
    $sql = "CREATE TABLE IF NOT EXISTS fee_grade_settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        grade_code INT NOT NULL,
        label VARCHAR(120) NOT NULL,
        student_grade_value VARCHAR(120) NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_fee_grade_code (grade_code),
        KEY idx_fee_grade_sort (sort_order),
        KEY idx_fee_grade_active (is_active)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    schema_migration_attempt($conn, $sql);

    $existingCodes = [];
    $result = $conn->query("SELECT grade_code FROM fee_grade_settings");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $existingCodes[] = (int) ($row['grade_code'] ?? 0);
        }
        $result->close();
    }

    $stmt = $conn->prepare(
        "INSERT INTO fee_grade_settings (grade_code, label, student_grade_value, sort_order, is_active)
         VALUES (?, ?, ?, ?, ?)"
    );
    if (!$stmt) {
        return;
    }

    foreach (fee_grade_default_rows() as $row) {
        if (in_array((int) $row['grade_code'], $existingCodes, true)) {
            continue;
        }
        $gradeCode = (int) $row['grade_code'];
        $label = (string) $row['label'];
        $studentGradeValue = (string) $row['student_grade_value'];
        $sortOrder = (int) $row['sort_order'];
        $isActive = (int) $row['is_active'];
        $stmt->bind_param('issii', $gradeCode, $label, $studentGradeValue, $sortOrder, $isActive);
        $stmt->execute();
    }
    $stmt->close();
}

function fee_grade_catalog_rows(mysqli $conn, bool $includeInactive = false): array
{
    fee_grade_settings_ensure_table($conn);
    $rows = [];
    $sql = "SELECT grade_code, label, student_grade_value, sort_order, is_active
        FROM fee_grade_settings";
    if (!$includeInactive) {
        $sql .= " WHERE is_active = 1";
    }
    $sql .= " ORDER BY sort_order ASC, grade_code ASC";
    $result = $conn->query($sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $rows[] = [
                'grade_code' => (int) ($row['grade_code'] ?? 0),
                'label' => (string) ($row['label'] ?? ''),
                'student_grade_value' => (string) ($row['student_grade_value'] ?? ''),
                'sort_order' => (int) ($row['sort_order'] ?? 0),
                'is_active' => (int) ($row['is_active'] ?? 1),
            ];
        }
        $result->close();
    }

    return $rows;
}

function fee_grade_label_map(mysqli $conn, bool $includeInactive = false): array
{
    $map = [];
    foreach (fee_grade_catalog_rows($conn, $includeInactive) as $row) {
        $map[(int) $row['grade_code']] = (string) $row['label'];
    }
    return $map;
}

function fee_grade_student_value_for_code(mysqli $conn, int $gradeCode): string
{
    fee_grade_settings_ensure_table($conn);
    $stmt = $conn->prepare("SELECT student_grade_value FROM fee_grade_settings WHERE grade_code = ? LIMIT 1");
    if (!$stmt) {
        return '';
    }
    $stmt->bind_param('i', $gradeCode);
    $stmt->execute();
    $stmt->bind_result($studentGradeValue);
    $value = $stmt->fetch() ? (string) $studentGradeValue : '';
    $stmt->close();
    return $value;
}

function fee_grade_update_settings(mysqli $conn, array $rows): array
{
    fee_grade_settings_ensure_table($conn);
    $updated = 0;
    $stmt = $conn->prepare(
        "UPDATE fee_grade_settings
         SET label = ?, student_grade_value = ?, sort_order = ?, is_active = ?
         WHERE grade_code = ?"
    );
    if (!$stmt) {
        throw new RuntimeException('Could not prepare fee grade settings update.');
    }

    foreach ($rows as $row) {
        $gradeCode = (int) ($row['grade_code'] ?? 0);
        if ($gradeCode === 0) {
            continue;
        }
        $label = trim((string) ($row['label'] ?? ''));
        $studentGradeValue = trim((string) ($row['student_grade_value'] ?? ''));
        if ($label === '' || $studentGradeValue === '') {
            continue;
        }
        $sortOrder = (int) ($row['sort_order'] ?? 0);
        $isActive = !empty($row['is_active']) ? 1 : 0;
        $stmt->bind_param('ssiii', $label, $studentGradeValue, $sortOrder, $isActive, $gradeCode);
        if ($stmt->execute()) {
            $updated++;
        }
    }
    $stmt->close();

    return ['updated' => $updated];
}

function fee_grade_add_setting(mysqli $conn, int $gradeCode, string $label, string $studentGradeValue, int $sortOrder = 0, bool $isActive = true): void
{
    fee_grade_settings_ensure_table($conn);
    if ($gradeCode === 0) {
        throw new RuntimeException('Grade code is required.');
    }
    $label = trim($label);
    $studentGradeValue = trim($studentGradeValue);
    if ($label === '' || $studentGradeValue === '') {
        throw new RuntimeException('Grade label and student-grade match value are required.');
    }

    $check = $conn->prepare("SELECT id FROM fee_grade_settings WHERE grade_code = ? LIMIT 1");
    if (!$check) {
        throw new RuntimeException('Could not validate duplicate grade code.');
    }
    $check->bind_param('i', $gradeCode);
    $check->execute();
    $exists = $check->get_result()->num_rows > 0;
    $check->close();
    if ($exists) {
        throw new RuntimeException('That grade code already exists.');
    }

    $isActiveInt = $isActive ? 1 : 0;
    $stmt = $conn->prepare(
        "INSERT INTO fee_grade_settings (grade_code, label, student_grade_value, sort_order, is_active)
         VALUES (?, ?, ?, ?, ?)"
    );
    if (!$stmt) {
        throw new RuntimeException('Could not prepare new fee grade insert.');
    }
    $stmt->bind_param('issii', $gradeCode, $label, $studentGradeValue, $sortOrder, $isActiveInt);
    if (!$stmt->execute()) {
        $stmt->close();
        throw new RuntimeException('Could not add fee grade setting.');
    }
    $stmt->close();
}
