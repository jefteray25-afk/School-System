<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();

include __DIR__ . '/../../config/database.php';
require_once 'settings-security.php';
require_once 'settings-permissions-roles.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

$currentUsername = $_SESSION['username'] ?? '';
$currentRole = $_SESSION['role'] ?? '';
if (!can_view_settings_module($currentRole)) {
    audit_log(
        $conn,
        $currentUsername !== '' ? $currentUsername : 'unknown',
        'Blocked settings edit access',
        'Settings',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing settings:view permission',
        'SECURITY'
    );
    header('Location: /school-admin-dashboard/dashboard.php?error=settings_denied');
    exit();
}
if (is_specialized_staff_role($currentRole)) {
    audit_log(
        $conn,
        $currentUsername !== '' ? $currentUsername : 'unknown',
        'Blocked settings edit access',
        'Settings',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: specialized staff role restriction',
        'SECURITY'
    );
    header('Location: /school-admin-dashboard/modules/settings/settings-dashboard.php?error=restricted');
    exit();
}

if (!isset($_GET['id'])) {
    header('Location: settings-admin-users.php');
    exit();
}

$id = (int) $_GET['id'];
$stmt = $conn->prepare('SELECT username, role, email, password FROM admins WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$stmt->bind_result($username, $role, $email, $hashedPassword);
$stmt->fetch();
$stmt->close();

$isEditingSelf = ($username === $currentUsername);

if (!can_access_admin_edit_page($currentRole, $isEditingSelf)) {
    audit_log(
        $conn,
        $currentUsername !== '' ? $currentUsername : 'unknown',
        'Blocked admin user edit access',
        'Settings',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Target Admin ID: ' . $id . ' | Is Editing Self: ' . ($isEditingSelf ? 'yes' : 'no') . ' | Reason: page-level admin edit restriction',
        'SECURITY'
    );
    header('Location: settings-admin-users.php?error=unauthorized');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_require_post_csrf();
    $newEmail = trim($_POST['email'] ?? '');
    $newPassword = trim($_POST['new_password'] ?? '');
    $currentPassword = trim($_POST['current_password'] ?? '');
    $newRole = trim($_POST['role'] ?? $role);

    if ($isEditingSelf && !password_verify($currentPassword, $hashedPassword)) {
        $error = 'Current password is incorrect.';
    }

    $passwordChanged = false;
    if ($error === '') {
        if ($currentRole === 'Super Administrator') {
            if (!in_array($newRole, array_merge(['Super Administrator'], managed_admin_roles()), true)) {
                $error = 'Invalid role selected.';
            }
        } else {
            $newRole = $role;
        }

        if ($error !== '') {
            // no-op, keep going to error display
        }
        if ($newPassword !== '') {
            if (strlen($newPassword) < 8 || !preg_match('/[A-Z]/', $newPassword) || !preg_match('/[a-z]/', $newPassword) || !preg_match('/[0-9]/', $newPassword)) {
                $error = 'New password must be at least 8 characters, and contain uppercase, lowercase, and a number.';
            } else {
                $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $stmt = $conn->prepare('UPDATE admins SET email = ?, role = ?, password = ? WHERE id = ?');
                $stmt->bind_param('sssi', $newEmail, $newRole, $hashedNewPassword, $id);
                $passwordChanged = true;
            }
        } else {
            $stmt = $conn->prepare('UPDATE admins SET email = ?, role = ? WHERE id = ?');
            $stmt->bind_param('ssi', $newEmail, $newRole, $id);
        }

        if ($error === '' && $stmt->execute()) {
            $stmt->close();
            $actor = $_SESSION['username'] ?? 'unknown';
            $auditDetails = 'Target Username: ' . $username . ' | New Role: ' . $newRole . ' | New Email: ' . $newEmail;
            if ($passwordChanged) {
                $auditDetails .= ' | Password reset/changed: yes';
            }
            audit_log($conn, $actor, 'Updated admin user', 'Settings', $auditDetails, 'INFO');
            if ($isEditingSelf && $passwordChanged) {
                session_destroy();
                header('Location: /Admin.php?msg=Password updated. Please login again.');
                exit();
            }
            header('Location: settings-admin-users.php?success=updated');
            exit();
        } elseif ($error === '') {
            $error = 'Update failed: ' . $conn->error;
            $stmt->close();
        }
    }
}

ensure_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="mt-5 mb-3">
        <h3><i class="fas fa-edit"></i> Edit User</h3>
        <hr>
        <?php if ($error !== ''): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="post">
            <?= csrf_input() ?>
            <div class="mb-3">
                <label class="form-label">Username</label>
                <input type="text" class="form-control" value="<?= htmlspecialchars($username) ?>" disabled>
            </div>
            <div class="mb-3">
                <label class="form-label">Role</label>
                <?php if ($currentRole === 'Super Administrator'): ?>
                    <select name="role" class="form-select" required>
                        <option value="Super Administrator" <?= $role === 'Super Administrator' ? 'selected' : '' ?>>Super Administrator</option>
                        <?php foreach (managed_admin_roles() as $managedRole): ?>
                            <option value="<?= htmlspecialchars($managedRole) ?>" <?= $role === $managedRole ? 'selected' : '' ?>><?= htmlspecialchars($managedRole) ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php else: ?>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($role) ?>" disabled>
                <?php endif; ?>
            </div>
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($email) ?>" required>
            </div>
            <?php if ($isEditingSelf && $currentRole !== 'Super Administrator'): ?>
            <div class="mb-3">
                <label class="form-label">Current Password <span class="text-danger">*</span></label>
                <input type="password" name="current_password" class="form-control" required placeholder="Enter your current password">
            </div>
            <?php endif; ?>
            <div class="mb-3">
                <label class="form-label"><?= $currentRole === 'Super Administrator' ? 'New Password / Reset Password' : 'New Password (leave blank to keep current)' ?></label>
                <input type="password" name="new_password" class="form-control" placeholder="New Password">
                <div class="form-text">At least 8 characters, includes uppercase, lowercase, and number.</div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
            <a href="settings-admin-users.php" class="btn btn-secondary ms-2">Cancel</a>
        </form>
    </div>
</div>
</body>
</html>
