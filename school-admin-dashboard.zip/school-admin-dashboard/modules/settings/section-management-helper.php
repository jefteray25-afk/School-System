<?php
require_once __DIR__ . '/school-year-helper.php';
require_once __DIR__ . '/../../includes/schema-migration.php';

function section_management_grade_options(): array
{
    return [
        'Junior Kindergarten',
        'Senior Kindergarten',
        'Grade 1',
        'Grade 2',
        'Grade 3',
        'Grade 4',
        'Grade 5',
        'Grade 6',
        'Grade 7',
        'Grade 8',
        'Grade 9',
        'Grade 10',
        'Grade 11',
        'Grade 12',
    ];
}

function section_management_is_valid_grade(string $grade): bool
{
    return in_array($grade, section_management_grade_options(), true);
}

function section_management_normalize_name(string $name): string
{
    $name = preg_replace('/\s+/', ' ', trim($name));
    return (string) $name;
}

function section_management_table_exists(mysqli $conn, string $tableName): bool
{
    $stmt = $conn->prepare("
        SELECT 1
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = ?
        LIMIT 1
    ");
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('s', $tableName);
    $stmt->execute();
    $exists = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    return $exists;
}

function section_management_ensure_table(mysqli $conn): void
{
    school_year_ensure_table($conn);
    if (!schema_migration_mode_enabled()) {
        return;
    }

    schema_migration_attempt($conn, "CREATE TABLE IF NOT EXISTS grade_sections (
        id INT AUTO_INCREMENT PRIMARY KEY,
        school_year_label VARCHAR(20) NOT NULL,
        grade_level VARCHAR(40) NOT NULL,
        section_name VARCHAR(100) NOT NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_grade_section (school_year_label, grade_level, section_name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
}

function section_management_name_exists(mysqli $conn, string $schoolYearLabel, string $gradeLevel, string $sectionName, ?int $excludeId = null): bool
{
    $sql = "SELECT id FROM grade_sections WHERE school_year_label = ? AND grade_level = ? AND section_name = ?";
    if ($excludeId !== null) {
        $sql .= " AND id <> ?";
    }
    $sql .= " LIMIT 1";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return false;
    }
    if ($excludeId !== null) {
        $stmt->bind_param('sssi', $schoolYearLabel, $gradeLevel, $sectionName, $excludeId);
    } else {
        $stmt->bind_param('sss', $schoolYearLabel, $gradeLevel, $sectionName);
    }
    $stmt->execute();
    $exists = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    return $exists;
}

function section_management_get_sections(mysqli $conn, string $schoolYearLabel, string $gradeLevel = '', bool $activeOnly = false): array
{
    section_management_ensure_table($conn);

    $sql = "SELECT id, school_year_label, grade_level, section_name, is_active, created_at, updated_at
        FROM grade_sections
        WHERE school_year_label = ?";
    $types = 's';
    $params = [$schoolYearLabel];

    if ($gradeLevel !== '') {
        $sql .= " AND grade_level = ?";
        $types .= 's';
        $params[] = $gradeLevel;
    }

    if ($activeOnly) {
        $sql .= " AND is_active = 1";
    }

    $sql .= " ORDER BY grade_level ASC, section_name ASC";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return [];
    }
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    $sections = [];
    while ($row = $result->fetch_assoc()) {
        $row['id'] = (int) ($row['id'] ?? 0);
        $row['is_active'] = (int) ($row['is_active'] ?? 0);
        $sections[] = $row;
    }
    $stmt->close();

    return $sections;
}

function section_management_get_sections_by_grade(mysqli $conn, string $schoolYearLabel, bool $activeOnly = true): array
{
    $rows = section_management_get_sections($conn, $schoolYearLabel, '', $activeOnly);
    $map = [];
    foreach (section_management_grade_options() as $grade) {
        $map[$grade] = [];
    }
    foreach ($rows as $row) {
        $grade = (string) ($row['grade_level'] ?? '');
        $name = (string) ($row['section_name'] ?? '');
        if ($grade !== '' && $name !== '') {
            $map[$grade][] = $name;
        }
    }
    return $map;
}

function section_management_get_section_names(mysqli $conn, string $schoolYearLabel, string $gradeLevel, bool $activeOnly = true): array
{
    $rows = section_management_get_sections($conn, $schoolYearLabel, $gradeLevel, $activeOnly);
    return array_values(array_map(static fn(array $row): string => (string) $row['section_name'], $rows));
}

function section_management_usage_count(mysqli $conn, string $schoolYearLabel, string $gradeLevel, string $sectionName): int
{
    $details = section_management_usage_details($conn, $schoolYearLabel, $gradeLevel, $sectionName);
    return (int) ($details['total'] ?? 0);
}

function section_management_usage_details(mysqli $conn, string $schoolYearLabel, string $gradeLevel, string $sectionName): array
{
    $details = [
        'students' => 0,
        'pending' => 0,
        'total' => 0,
    ];

    if (section_management_table_exists($conn, 'students')) {
        $stmt = $conn->prepare("SELECT COUNT(*) AS total_count
            FROM students
            WHERE COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?
              AND grade = ?
              AND section = ?");
        if ($stmt) {
            $stmt->bind_param('ssss', $schoolYearLabel, $schoolYearLabel, $gradeLevel, $sectionName);
            $stmt->execute();
            $details['students'] = (int) (($stmt->get_result()->fetch_assoc()['total_count'] ?? 0));
            $stmt->close();
        }
    }

    if (section_management_table_exists($conn, 'student_registration_pending')) {
        $stmt = $conn->prepare("SELECT COUNT(*) AS total_count
            FROM student_registration_pending
            WHERE status = 'Pending'
              AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?
              AND grade = ?
              AND section = ?");
        if ($stmt) {
            $stmt->bind_param('ssss', $schoolYearLabel, $schoolYearLabel, $gradeLevel, $sectionName);
            $stmt->execute();
            $details['pending'] = (int) (($stmt->get_result()->fetch_assoc()['total_count'] ?? 0));
            $stmt->close();
        }
    }

    $details['total'] = (int) $details['students'] + (int) $details['pending'];

    return $details;
}
