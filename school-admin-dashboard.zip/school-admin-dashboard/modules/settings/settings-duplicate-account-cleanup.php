<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require '../../config/database.php';
require __DIR__ . '/../students/student-registration-helper.php';
require __DIR__ . '/settings-permissions-roles.php';
include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');
require_once 'school-info-helper.php';

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$canAccessDuplicateCleanup = can_access_duplicate_cleanup_settings($role);

if (!$canAccessDuplicateCleanup) {
    admin_session_forbidden();
}

registration_ensure_pending_table($conn);
$csrfToken = registration_csrf_token();
$message = '';
$messageType = 'success';

if (!is_super_admin_role($role)) {
    admin_session_forbidden();
}

function account_duplicate_cleanup_groups(mysqli $conn): array
{
    $groups = [];
    $sql = "
        SELECT
            a.student_id,
            s.lastname,
            s.firstname,
            s.middlename,
            s.grade,
            COALESCE(NULLIF(TRIM(s.school_year_label), ''), 'Unassigned') AS student_school_year,
            a.type,
            COALESCE(NULLIF(TRIM(a.school_year_label), ''), 'Unassigned') AS account_school_year,
            COUNT(*) AS duplicate_count
        FROM accounts a
        JOIN students s ON s.id = a.student_id
        GROUP BY
            a.student_id,
            a.type,
            COALESCE(NULLIF(TRIM(a.school_year_label), ''), 'Unassigned')
        HAVING COUNT(*) > 1
        ORDER BY s.lastname ASC, s.firstname ASC, a.type ASC
    ";
    $result = $conn->query($sql);
    if (!$result) {
        return [];
    }

    while ($group = $result->fetch_assoc()) {
        $studentId = (int) $group['student_id'];
        $type = (string) $group['type'];
        $accountYear = (string) $group['account_school_year'];

        if ($accountYear === 'Unassigned') {
            $detailSql = "
                SELECT
                    a.id,
                    a.type,
                    a.balance,
                    a.notes,
                    a.school_year_label,
                    a.created_at,
                    COUNT(p.id) AS payment_count
                FROM accounts a
                LEFT JOIN payments p ON p.account_id = a.id
                WHERE a.student_id = ?
                  AND a.type = ?
                  AND (a.school_year_label IS NULL OR TRIM(a.school_year_label) = '')
                GROUP BY a.id, a.type, a.balance, a.notes, a.school_year_label, a.created_at
                ORDER BY a.id ASC
            ";
            $detailStmt = $conn->prepare($detailSql);
            $detailStmt->bind_param('is', $studentId, $type);
        } else {
            $detailSql = "
                SELECT
                    a.id,
                    a.type,
                    a.balance,
                    a.notes,
                    a.school_year_label,
                    a.created_at,
                    COUNT(p.id) AS payment_count
                FROM accounts a
                LEFT JOIN payments p ON p.account_id = a.id
                WHERE a.student_id = ?
                  AND a.type = ?
                  AND COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ?
                GROUP BY a.id, a.type, a.balance, a.notes, a.school_year_label, a.created_at
                ORDER BY a.id ASC
            ";
            $detailStmt = $conn->prepare($detailSql);
            $detailStmt->bind_param('isss', $studentId, $type, $accountYear, $accountYear);
        }

        $detailStmt->execute();
        $records = $detailStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $detailStmt->close();

        $groups[] = [
            'student_id' => $studentId,
            'student_name' => trim($group['lastname'] . ', ' . $group['firstname'] . ' ' . $group['middlename']),
            'grade' => $group['grade'] ?? '',
            'student_school_year' => $group['student_school_year'],
            'account_school_year' => $accountYear,
            'type' => $type,
            'duplicate_count' => (int) $group['duplicate_count'],
            'records' => $records,
        ];
    }

    return $groups;
}

function account_duplicate_cleanup_summary(mysqli $conn): array
{
    $groupsSql = "
        SELECT COUNT(*) AS total_groups
        FROM (
            SELECT a.student_id
            FROM accounts a
            GROUP BY a.student_id, a.type, COALESCE(NULLIF(TRIM(a.school_year_label), ''), 'Unassigned')
            HAVING COUNT(*) > 1
        ) t
    ";
    $rowsSql = "
        SELECT COALESCE(SUM(duplicate_count), 0) AS total_rows
        FROM (
            SELECT COUNT(*) AS duplicate_count
            FROM accounts a
            GROUP BY a.student_id, a.type, COALESCE(NULLIF(TRIM(a.school_year_label), ''), 'Unassigned')
            HAVING COUNT(*) > 1
        ) t
    ";
    $paymentLinkedSql = "
        SELECT COUNT(*) AS linked_rows
        FROM accounts a
        WHERE EXISTS (SELECT 1 FROM payments p WHERE p.account_id = a.id)
          AND EXISTS (
              SELECT 1
              FROM accounts a2
              WHERE a2.student_id = a.student_id
                AND a2.type = a.type
                AND COALESCE(NULLIF(TRIM(a2.school_year_label), ''), 'Unassigned') = COALESCE(NULLIF(TRIM(a.school_year_label), ''), 'Unassigned')
                AND a2.id <> a.id
          )
    ";

    $groups = (int) (($conn->query($groupsSql)->fetch_assoc()['total_groups'] ?? 0));
    $rows = (int) (($conn->query($rowsSql)->fetch_assoc()['total_rows'] ?? 0));
    $linkedRows = (int) (($conn->query($paymentLinkedSql)->fetch_assoc()['linked_rows'] ?? 0));

    return [
        'duplicate_groups' => $groups,
        'duplicate_rows' => $rows,
        'payment_linked_rows' => $linkedRows,
        'clean_rows' => max(0, $rows - $linkedRows),
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!registration_verify_csrf($_POST['csrf_token'] ?? '')) {
        $message = 'Invalid request token. Please refresh the page and try again.';
        $messageType = 'danger';
    } elseif (($_POST['action'] ?? '') === 'resolve_duplicate_accounts') {
        $studentId = (int) ($_POST['student_id'] ?? 0);
        $accountType = trim((string) ($_POST['account_type'] ?? ''));
        $accountYear = trim((string) ($_POST['account_year'] ?? ''));
        $keepId = (int) ($_POST['keep_id'] ?? 0);
        $confirmPhrase = trim((string) ($_POST['confirm_phrase'] ?? ''));

        if ($studentId <= 0 || $accountType === '' || $keepId <= 0) {
            $message = 'Invalid cleanup request.';
            $messageType = 'danger';
        } elseif ($confirmPhrase !== 'CLEANUP') {
            $message = 'Type CLEANUP before resolving duplicate account records.';
            $messageType = 'danger';
        } else {
            if ($accountYear === 'Unassigned') {
                $sql = "
                    SELECT a.id, a.balance, a.school_year_label, COUNT(p.id) AS payment_count
                    FROM accounts a
                    LEFT JOIN payments p ON p.account_id = a.id
                    WHERE a.student_id = ?
                      AND a.type = ?
                      AND (a.school_year_label IS NULL OR TRIM(a.school_year_label) = '')
                    GROUP BY a.id, a.balance, a.school_year_label
                    ORDER BY a.id ASC
                ";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param('is', $studentId, $accountType);
            } else {
                $sql = "
                    SELECT a.id, a.balance, a.school_year_label, COUNT(p.id) AS payment_count
                    FROM accounts a
                    LEFT JOIN payments p ON p.account_id = a.id
                    WHERE a.student_id = ?
                      AND a.type = ?
                      AND COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ?
                    GROUP BY a.id, a.balance, a.school_year_label
                    ORDER BY a.id ASC
                ";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param('isss', $studentId, $accountType, $accountYear, $accountYear);
            }

            $stmt->execute();
            $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();

            $ids = array_map(static fn($row) => (int) $row['id'], $rows);
            $hasAnyLinkedPayment = false;
            foreach ($rows as $row) {
                if ((int) ($row['payment_count'] ?? 0) > 0) {
                    $hasAnyLinkedPayment = true;
                    break;
                }
            }
            if (count($ids) < 2 || !in_array($keepId, $ids, true)) {
                $message = 'This duplicate group is no longer available or the keeper is invalid.';
                $messageType = 'warning';
            } elseif ($hasAnyLinkedPayment) {
                $message = 'Cleanup blocked. This duplicate group has one or more rows with linked payments. Manual review is required (no rows were deleted).';
                $messageType = 'warning';
            } else {
                $deleteIds = [];
                $blockedIds = [];
                foreach ($rows as $row) {
                    $rowId = (int) $row['id'];
                    if ($rowId === $keepId) {
                        continue;
                    }
                    if ((int) $row['payment_count'] > 0) {
                        $blockedIds[] = $rowId;
                    } else {
                        $deleteIds[] = $rowId;
                    }
                }

                if (!$deleteIds && $blockedIds) {
                    $message = 'Cleanup blocked. All duplicate rows in this group already have linked payments and need manual review.';
                    $messageType = 'warning';
                } else {
                    $conn->begin_transaction();
                    try {
                        $deletedRows = 0;
                        if ($deleteIds) {
                            $placeholders = implode(',', array_fill(0, count($deleteIds), '?'));
                            $types = str_repeat('i', count($deleteIds));
                            $deleteStmt = $conn->prepare("DELETE FROM accounts WHERE id IN ({$placeholders})");
                            $deleteStmt->bind_param($types, ...$deleteIds);
                            $deleteStmt->execute();
                            $deletedRows = $deleteStmt->affected_rows;
                            $deleteStmt->close();
                        }

                        $conn->commit();
                        $message = 'Cleanup applied. Kept account #' . $keepId . ', removed ' . $deletedRows . ' duplicate account(s).';
                        if ($blockedIds) {
                            $message .= ' Some duplicates were not removed because they already have linked payments: #' . implode(', #', $blockedIds) . '.';
                            $messageType = 'warning';
                        } else {
                            $messageType = 'success';
                        }

                        audit_log(
                            $conn,
                            $username,
                            'Resolved duplicate account records',
                            'Settings',
                            'Student ID: ' . $studentId
                            . ' | Fee Type: ' . $accountType
                            . ' | School Year: ' . $accountYear
                            . ' | Kept Account ID: ' . $keepId
                            . ' | Deleted IDs: ' . implode(',', $deleteIds)
                            . ' | Blocked IDs: ' . implode(',', $blockedIds)
                        );
                    } catch (Throwable $e) {
                        $conn->rollback();
                        $message = 'Cleanup failed: ' . $e->getMessage();
                        $messageType = 'danger';
                    }
                }
            }
        }
    }
}

$summary = account_duplicate_cleanup_summary($conn);
$duplicateGroups = account_duplicate_cleanup_groups($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Duplicate Account Cleanup</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body { background: var(--main-bg); font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif; }
        .navbar { background: var(--navbar-bg) !important; }
        .navbar-brand, .navbar-nav .nav-link { color: #fff !important; }
        .dashboard-header { text-align: center; margin-top: 36px; margin-bottom: 18px; }
        .dashboard-header img { width: 70px; height: 70px; object-fit: contain; margin-bottom: 6px; }
        .dashboard-header h1 { font-size: 1.3rem; color: var(--brand-dark); font-weight: 700; margin-bottom: 0; }
        .cleanup-card { background: var(--card-bg); border-radius: 16px; box-shadow: 0 2px 12px rgba(33,57,93,0.10); max-width: 1320px; margin: 24px auto; padding: 28px 24px; }
        .summary-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 14px; margin-bottom: 24px; }
        .summary-box { background: #f7fbff; border: 1px solid #d6e9fb; border-radius: 14px; padding: 16px 18px; }
        .summary-box .label { color: var(--brand-blue); font-weight: 600; }
        .summary-box .value { color: var(--brand-dark); font-size: 1.4rem; font-weight: 700; }
        .duplicate-group { border: 1px solid #dce8f5; border-radius: 14px; padding: 18px; margin-bottom: 18px; background: #fff; }
        .table td, .table th { vertical-align: middle; }
        .warning-note { background: #fff6df; border: 1px solid #f2d88e; color: #6e5611; border-radius: 12px; padding: 12px 14px; margin-bottom: 16px; }
        .badge-soft { background: #eef6ff; color: #234; border: 1px solid #d5e6fb; }
    </style>
</head>
<body>
<?php render_admin_nav('settings'); ?>

<div class="dashboard-header">
    <img src="<?= htmlspecialchars($schoolLogo) ?>" alt="School Logo" class="mb-2 rounded shadow-sm">
    <h1><?= htmlspecialchars($schoolName) ?></h1>
</div>

<div class="cleanup-card">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <div>
            <h2 class="mb-1"><i class="fas fa-layer-group text-primary me-2"></i>Duplicate Account Cleanup</h2>
            <div class="text-muted">Review duplicate fee-account records and keep the correct row. Cleanup removes only safe duplicates with no linked payments.</div>
        </div>
        <a href="/school-admin-dashboard/modules/settings/settings-dashboard.php" class="btn btn-outline-secondary"><i class="fas fa-arrow-left"></i> Back to Settings</a>
    </div>

    <div class="warning-note">
        <i class="fas fa-triangle-exclamation me-2"></i>
        This tool scans the whole accounts table for duplicate fee-type rows per student and school year. Cleanup is done one group at a time. If a duplicate row already has linked payments, it will be blocked from deletion and left for manual review.
    </div>

    <?php if ($message !== ''): ?>
        <div class="alert alert-<?= htmlspecialchars($messageType) ?>"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <div class="summary-grid">
        <div class="summary-box">
            <div class="label">Duplicate Groups</div>
            <div class="value"><?= $summary['duplicate_groups'] ?></div>
        </div>
        <div class="summary-box">
            <div class="label">Duplicate Rows</div>
            <div class="value"><?= $summary['duplicate_rows'] ?></div>
        </div>
        <div class="summary-box">
            <div class="label">Payment-Linked Rows</div>
            <div class="value"><?= $summary['payment_linked_rows'] ?></div>
        </div>
        <div class="summary-box">
            <div class="label">Safe Removable Rows</div>
            <div class="value"><?= $summary['clean_rows'] ?></div>
        </div>
    </div>

    <h3 class="h5 mb-3">Duplicate Account Groups</h3>
    <?php if (!$duplicateGroups): ?>
        <div class="alert alert-success">No duplicate fee-account groups were found.</div>
    <?php else: ?>
        <?php foreach ($duplicateGroups as $group): ?>
            <div class="duplicate-group">
                <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
                    <div>
                        <strong>Student:</strong> <?= htmlspecialchars($group['student_name']) ?>
                        <span class="badge badge-soft ms-2">ID <?= (int) $group['student_id'] ?></span>
                        <span class="badge bg-info text-dark ms-2"><?= htmlspecialchars($group['grade']) ?></span>
                    </div>
                    <div class="text-end">
                        <div><strong>Fee Type:</strong> <?= htmlspecialchars($group['type']) ?></div>
                        <div><strong>Account School Year:</strong> <?= htmlspecialchars($group['account_school_year']) ?></div>
                    </div>
                </div>
                <div class="mb-2 text-muted">
                    Student School Year: <?= htmlspecialchars($group['student_school_year']) ?> |
                    Duplicate Rows: <?= (int) $group['duplicate_count'] ?>
                </div>

                <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                    <input type="hidden" name="action" value="resolve_duplicate_accounts">
                    <input type="hidden" name="student_id" value="<?= (int) $group['student_id'] ?>">
                    <input type="hidden" name="account_type" value="<?= htmlspecialchars($group['type']) ?>">
                    <input type="hidden" name="account_year" value="<?= htmlspecialchars($group['account_school_year']) ?>">
                    <div class="table-responsive">
                        <table class="table table-sm align-middle">
                            <thead>
                                <tr>
                                    <th>Keep</th>
                                    <th>Account ID</th>
                                    <th>Balance</th>
                                    <th>Account Year</th>
                                    <th>Notes</th>
                                    <th>Created</th>
                                    <th>Linked Payments</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($group['records'] as $index => $record): ?>
                                <tr>
                                    <td><input type="radio" name="keep_id" value="<?= (int) $record['id'] ?>" <?= $index === 0 ? 'checked' : '' ?> required></td>
                                    <td><?= (int) $record['id'] ?></td>
                                    <td><?= number_format((float) $record['balance'], 2) ?></td>
                                    <td><?= htmlspecialchars(trim((string) ($record['school_year_label'] ?? '')) !== '' ? (string) $record['school_year_label'] : 'Unassigned') ?></td>
                                    <td><?= htmlspecialchars((string) ($record['notes'] ?? '')) ?></td>
                                    <td><?= htmlspecialchars((string) ($record['created_at'] ?? '')) ?></td>
                                    <td>
                                        <?php $paymentCount = (int) ($record['payment_count'] ?? 0); ?>
                                        <?php if ($paymentCount > 0): ?>
                                            <span class="badge bg-warning text-dark"><?= $paymentCount ?> linked</span>
                                        <?php else: ?>
                                            <span class="badge bg-success">0 linked</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-muted small mb-2">
                        Safety rule: if any row in this duplicate group has linked payments, cleanup will be blocked and no rows will be deleted.
                    </div>
                    <div class="mb-3" style="max-width: 260px;">
                        <label class="form-label small fw-semibold">Type CLEANUP to confirm</label>
                        <input type="text" name="confirm_phrase" class="form-control form-control-sm" required autocomplete="off">
                    </div>
                    <button type="submit" class="btn btn-outline-danger btn-sm">
                        <i class="fas fa-broom"></i> Keep Selected Account and Remove Safe Duplicates
                    </button>
                </form>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<?= admin_session_warning_script() ?>
</body>
</html>
<?php $conn->close(); ?>
