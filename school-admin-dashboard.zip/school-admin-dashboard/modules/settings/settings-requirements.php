<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require '../../config/database.php';
require_once 'settings-permissions-roles.php';
require_once 'school-info-helper.php';
require_once __DIR__ . '/../students/student-requirements-helper.php';
include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$canAccessRequirementsSettings = can_access_settings_page($role, 'requirements');

if (!$canAccessRequirementsSettings) {
    header('Location: /school-admin-dashboard/modules/settings/settings-dashboard.php?error=settings_denied');
    exit();
}

student_requirements_ensure_settings_table($conn);
$csrfToken = admin_csrf_token();

$pageMessage = '';
$pageMessageType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postedToken = $_POST['csrf_token'] ?? '';
    if (!admin_csrf_validate($postedToken)) {
        $pageMessage = 'Security validation failed. Please refresh and try again.';
        $pageMessageType = 'danger';
    } else {
        try {
            if (($_POST['requirements_action'] ?? '') === 'save_existing') {
                $rows = is_array($_POST['requirements'] ?? null) ? $_POST['requirements'] : [];
                $result = student_requirements_update_settings($conn, $rows);
                $pageMessage = 'Requirement settings updated (' . (int) ($result['updated'] ?? 0) . ' rows processed).';
                audit_log($conn, $username, 'Updated requirement settings', 'Settings', 'Role: ' . $role . ' | Updated rows: ' . (int) ($result['updated'] ?? 0), 'INFO');
            } elseif (($_POST['requirements_action'] ?? '') === 'add_requirement') {
                $label = trim((string) ($_POST['new_requirement_label'] ?? ''));
                $sortOrder = (int) ($_POST['new_requirement_sort_order'] ?? 0);
                $isRequired = !empty($_POST['new_requirement_is_required']);
                $isActive = !empty($_POST['new_requirement_is_active']);
                $newKey = student_requirements_add_setting($conn, $label, $sortOrder, $isRequired, $isActive);
                $pageMessage = 'New requirement added successfully.';
                audit_log($conn, $username, 'Added requirement setting', 'Settings', 'Role: ' . $role . ' | Requirement key: ' . $newKey, 'INFO');
            }
        } catch (Throwable $e) {
            $pageMessage = $e->getMessage();
            $pageMessageType = 'danger';
        }
    }
}

$requirementRows = student_requirements_catalog_rows($conn, true);
$activeCount = 0;
$requiredCount = 0;
foreach ($requirementRows as $row) {
    if (!empty($row['is_active'])) {
        $activeCount++;
    }
    if (!empty($row['is_required'])) {
        $requiredCount++;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Requirements Settings - School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body { background: var(--main-bg); font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif; }
        .navbar { background: var(--navbar-bg) !important; box-shadow: 0 2px 12px rgba(33,57,93,0.08); }
        .navbar-brand, .navbar-nav .nav-link { color: #fff !important; font-size: 1.08em; }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .dashboard-header { text-align: center; margin-top: 36px; margin-bottom: 18px; }
        .dashboard-header img { width: 70px; height: 70px; object-fit: contain; margin-bottom: 6px; }
        .dashboard-header h1 { font-size: 1.3rem; color: var(--brand-dark); font-weight: 700; margin-bottom: 0; }
        .section-card {
            background: var(--card-bg);
            border: 1px solid rgba(81, 127, 164, 0.15);
            border-radius: 1rem;
            box-shadow: 0 4px 18px rgba(33, 57, 93, 0.07);
            margin-bottom: 1.25rem;
        }
        .page-title { color: var(--brand-dark); font-weight: 700; }
        .summary-stat {
            background: #f8fbff;
            border: 1px solid rgba(81, 127, 164, 0.16);
            border-radius: 1rem;
            padding: 1rem 1.1rem;
            height: 100%;
        }
        .summary-stat .label { text-transform: uppercase; font-size: 0.74rem; color: #6c757d; font-weight: 700; }
        .summary-stat .value { font-size: 1.65rem; font-weight: 700; color: var(--brand-dark); }
    </style>
</head>
<body>
<?php render_admin_nav('settings'); ?>
<?php render_school_page_header($schoolName, $schoolLogo); ?>

<div class="container pb-5">
    <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-4">
        <div>
            <h2 class="page-title mb-1"><i class="fas fa-list-check me-2"></i>Requirements Settings</h2>
            <p class="text-muted mb-0">Manage the student requirement checklist used by the Student Detail Panel. Changes here affect the live checklist order and labels.</p>
        </div>
        <a href="/school-admin-dashboard/modules/settings/settings-dashboard.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back to Settings
        </a>
    </div>

    <?php if ($pageMessage !== ''): ?>
        <div class="alert alert-<?= htmlspecialchars($pageMessageType) ?>"><?= htmlspecialchars($pageMessage) ?></div>
    <?php endif; ?>

    <div class="row g-3 mb-4">
        <div class="col-12 col-md-4">
            <div class="summary-stat">
                <div class="label">Total Requirement Items</div>
                <div class="value"><?= number_format(count($requirementRows)) ?></div>
            </div>
        </div>
        <div class="col-12 col-md-4">
            <div class="summary-stat">
                <div class="label">Active Items</div>
                <div class="value"><?= number_format($activeCount) ?></div>
            </div>
        </div>
        <div class="col-12 col-md-4">
            <div class="summary-stat">
                <div class="label">Required Items</div>
                <div class="value"><?= number_format($requiredCount) ?></div>
            </div>
        </div>
    </div>

    <div class="section-card p-4">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
            <div>
                <h5 class="mb-1">Current Checklist</h5>
                <p class="text-muted mb-0">Adjust labels, order, required flags, and active status. Deactivate items instead of removing them so old history stays readable.</p>
            </div>
        </div>

        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
            <input type="hidden" name="requirements_action" value="save_existing">
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Requirement Key</th>
                            <th>Label</th>
                            <th>Order</th>
                            <th>Required</th>
                            <th>Active</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($requirementRows as $row): ?>
                        <tr>
                            <td>
                                <div class="fw-semibold"><?= htmlspecialchars($row['requirement_key']) ?></div>
                                <input type="hidden" name="requirements[<?= htmlspecialchars($row['requirement_key']) ?>][requirement_key]" value="<?= htmlspecialchars($row['requirement_key']) ?>">
                            </td>
                            <td>
                                <input type="text" class="form-control" name="requirements[<?= htmlspecialchars($row['requirement_key']) ?>][label]" value="<?= htmlspecialchars($row['label']) ?>" maxlength="120">
                            </td>
                            <td style="width: 130px;">
                                <input type="number" class="form-control" name="requirements[<?= htmlspecialchars($row['requirement_key']) ?>][sort_order]" value="<?= (int) $row['sort_order'] ?>">
                            </td>
                            <td style="width: 120px;">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="requirements[<?= htmlspecialchars($row['requirement_key']) ?>][is_required]" value="1" <?= !empty($row['is_required']) ? 'checked' : '' ?>>
                                    <label class="form-check-label">Required</label>
                                </div>
                            </td>
                            <td style="width: 120px;">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="requirements[<?= htmlspecialchars($row['requirement_key']) ?>][is_active]" value="1" <?= !empty($row['is_active']) ? 'checked' : '' ?>>
                                    <label class="form-check-label">Active</label>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="text-end">
                <button type="submit" class="btn btn-primary" onclick="return confirm('Save requirement settings changes?');">
                    <i class="fas fa-save me-1"></i>Save Requirement Settings
                </button>
            </div>
        </form>
    </div>

    <div class="section-card p-4">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
            <div>
                <h5 class="mb-1">Add New Requirement</h5>
                <p class="text-muted mb-0">Use this for school-specific checklist items like Parent ID, ESC Voucher, or Medical Record.</p>
            </div>
        </div>

        <form method="post" class="row g-3 align-items-end">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
            <input type="hidden" name="requirements_action" value="add_requirement">
            <div class="col-md-5">
                <label class="form-label">Requirement Label</label>
                <input type="text" class="form-control" name="new_requirement_label" maxlength="120" required>
            </div>
            <div class="col-md-2">
                <label class="form-label">Order</label>
                <input type="number" class="form-control" name="new_requirement_sort_order" value="<?= (count($requirementRows) + 1) * 10 ?>">
            </div>
            <div class="col-md-2">
                <div class="form-check mt-4 pt-2">
                    <input class="form-check-input" type="checkbox" name="new_requirement_is_required" value="1">
                    <label class="form-check-label">Required</label>
                </div>
            </div>
            <div class="col-md-1">
                <div class="form-check mt-4 pt-2">
                    <input class="form-check-input" type="checkbox" name="new_requirement_is_active" value="1" checked>
                    <label class="form-check-label">Active</label>
                </div>
            </div>
            <div class="col-md-2 text-end">
                <button type="submit" class="btn btn-outline-primary w-100" onclick="return confirm('Add this requirement item?');">
                    <i class="fas fa-plus me-1"></i>Add Item
                </button>
            </div>
        </form>
    </div>
</div>
</body>
</html>
