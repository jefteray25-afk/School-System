<?php

if (!function_exists('school_year_session_start')) {

function school_year_session_start(): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
}

function school_year_csrf_token(): string
{
    school_year_session_start();
    if (empty($_SESSION['school_year_csrf_token'])) {
        $_SESSION['school_year_csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['school_year_csrf_token'];
}

function school_year_verify_csrf(?string $token): bool
{
    school_year_session_start();
    $sessionToken = $_SESSION['school_year_csrf_token'] ?? '';
    return is_string($token) && $sessionToken !== '' && hash_equals($sessionToken, $token);
}

function school_year_default_label(): string
{
    $year = (int) date('Y');
    $month = (int) date('n');
    $startYear = $month >= 6 ? $year : ($year - 1);
    return 'SY ' . $startYear . '-' . ($startYear + 1);
}

function school_year_prepared_range_labels(int $startYear = 2025, int $endStartYear = 2039): array
{
    $labels = [];
    for ($year = $startYear; $year <= $endStartYear; $year++) {
        $labels[] = 'SY ' . $year . '-' . ($year + 1);
    }
    return $labels;
}

function school_year_seed_prepared_range(mysqli $conn, int $startYear = 2025, int $endStartYear = 2039): void
{
    $stmt = $conn->prepare("INSERT IGNORE INTO school_years (label, is_active, enrollment_open) VALUES (?, 0, 1)");
    if (!$stmt) {
        return;
    }

    foreach (school_year_prepared_range_labels($startYear, $endStartYear) as $label) {
        $stmt->bind_param('s', $label);
        $stmt->execute();
    }

    $stmt->close();
}

function school_year_normalize_label(string $label): string
{
    $label = trim(preg_replace('/\s+/', ' ', $label));
    return mb_substr($label, 0, 30);
}

function school_year_ensure_table(mysqli $conn): bool
{
    $sql = "CREATE TABLE IF NOT EXISTS school_years (
        id INT AUTO_INCREMENT PRIMARY KEY,
        label VARCHAR(30) NOT NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 0,
        enrollment_open TINYINT(1) NOT NULL DEFAULT 1,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_school_year_label (label)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    require_once __DIR__ . '/../../includes/schema-migration.php';
    if (schema_migration_mode_enabled()) {
        if (!schema_migration_attempt($conn, $sql)) {
            return false;
        }
    }

    school_year_ensure_record_defaults($conn);
    school_year_ensure_registration_columns($conn);
    return true;
}

function school_year_ensure_record_defaults(mysqli $conn): void
{
    school_year_seed_prepared_range($conn, 2025, 2039);

    $activeResult = $conn->query("SELECT id FROM school_years WHERE is_active = 1 ORDER BY id ASC LIMIT 1");
    $hasActive = $activeResult && $activeResult->num_rows > 0;
    if (!$hasActive) {
        $defaultLabel = school_year_default_label();
        $stmt = $conn->prepare("UPDATE school_years SET is_active = 1 WHERE label = ? LIMIT 1");
        if ($stmt) {
            $conn->query("UPDATE school_years SET is_active = 0");
            $stmt->bind_param('s', $defaultLabel);
            $stmt->execute();
            $activated = $stmt->affected_rows;
            $stmt->close();
            if ($activated > 0) {
                return;
            }
        }

        $firstResult = $conn->query("SELECT id FROM school_years ORDER BY id ASC LIMIT 1");
        $firstId = $firstResult ? (int) (($firstResult->fetch_assoc()['id'] ?? 0)) : 0;
        if ($firstId > 0) {
            $conn->query("UPDATE school_years SET is_active = 0");
            $stmt = $conn->prepare("UPDATE school_years SET is_active = 1 WHERE id = ?");
            if ($stmt) {
                $stmt->bind_param('i', $firstId);
                $stmt->execute();
                $stmt->close();
            }
        }
    }
}

function school_year_column_exists(mysqli $conn, string $table, string $column): bool
{
    $safeTable = $conn->real_escape_string($table);
    $safeColumn = $conn->real_escape_string($column);
    $sql = "SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = '{$safeTable}'
          AND COLUMN_NAME = '{$safeColumn}'";
    $result = $conn->query($sql);
    return $result && $result->num_rows > 0;
}

function school_year_index_exists(mysqli $conn, string $table, string $indexName): bool
{
    $safeTable = $conn->real_escape_string($table);
    $safeIndex = $conn->real_escape_string($indexName);
    $sql = "SELECT 1
        FROM INFORMATION_SCHEMA.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = '{$safeTable}'
          AND INDEX_NAME = '{$safeIndex}'
        LIMIT 1";
    $result = $conn->query($sql);
    return $result && $result->num_rows > 0;
}

function school_year_ensure_registration_columns(mysqli $conn): void
{
    require_once __DIR__ . '/../../includes/schema-migration.php';
    if (!schema_migration_mode_enabled()) {
        return;
    }
    $targets = [
        'students' => "ALTER TABLE students ADD COLUMN school_year_label VARCHAR(30) DEFAULT NULL AFTER date_enrolled",
        'student_registration_pending' => "ALTER TABLE student_registration_pending ADD COLUMN school_year_label VARCHAR(30) DEFAULT NULL AFTER date_enrolled",
    ];

    foreach ($targets as $table => $sql) {
        if (!school_year_column_exists($conn, $table, 'school_year_label')) {
            @schema_migration_attempt($conn, $sql);
        }
    }
}

function school_year_ensure_finance_columns(mysqli $conn): void
{
    require_once __DIR__ . '/../../includes/schema-migration.php';
    if (!schema_migration_mode_enabled()) {
        return;
    }
    $targets = [
        'fee' => "ALTER TABLE fee ADD COLUMN school_year_label VARCHAR(30) DEFAULT NULL AFTER notes",
        'accounts' => "ALTER TABLE accounts ADD COLUMN school_year_label VARCHAR(30) DEFAULT NULL AFTER notes",
        'payments' => "ALTER TABLE payments ADD COLUMN school_year_label VARCHAR(30) DEFAULT NULL AFTER receipt_note",
    ];

    foreach ($targets as $table => $sql) {
        if (!school_year_column_exists($conn, $table, 'school_year_label')) {
            @schema_migration_attempt($conn, $sql);
        }
    }

    if (!school_year_index_exists($conn, 'fee', 'uniq_fee_grade_year')) {
        @schema_migration_attempt($conn, "ALTER TABLE fee ADD UNIQUE KEY uniq_fee_grade_year (fee_type_id, grade_level, school_year_label)");
    }
}

function school_year_get_all(mysqli $conn): array
{
    school_year_ensure_table($conn);
    school_year_ensure_finance_columns($conn);
    $rows = [];
    $result = $conn->query("SELECT id, label, is_active, enrollment_open, created_at FROM school_years ORDER BY id DESC");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
        $result->close();
    }
    return $rows;
}

function school_year_get_active(mysqli $conn): ?array
{
    school_year_ensure_table($conn);
    school_year_ensure_finance_columns($conn);
    $result = $conn->query("SELECT id, label, is_active, enrollment_open FROM school_years WHERE is_active = 1 ORDER BY id DESC LIMIT 1");
    if ($result && ($row = $result->fetch_assoc())) {
        $result->close();
        return $row;
    }
    return null;
}

function school_year_get_active_label(mysqli $conn): string
{
    $active = school_year_get_active($conn);
    return $active['label'] ?? school_year_default_label();
}

function school_year_add(mysqli $conn, string $label): array
{
    $label = school_year_normalize_label($label);
    if ($label === '') {
        return ['success' => false, 'message' => 'School year label is required.'];
    }

    school_year_ensure_table($conn);
    $stmt = $conn->prepare("INSERT INTO school_years (label, is_active, enrollment_open) VALUES (?, 0, 1)");
    if (!$stmt) {
        return ['success' => false, 'message' => 'Could not prepare school year record.'];
    }

    try {
        $stmt->bind_param('s', $label);
        $stmt->execute();
        $stmt->close();
        return ['success' => true, 'message' => 'School year added successfully.'];
    } catch (Throwable $e) {
        $stmt->close();
        return ['success' => false, 'message' => 'School year label already exists or could not be saved.'];
    }
}

function school_year_set_active(mysqli $conn, int $schoolYearId): array
{
    school_year_ensure_table($conn);
    $conn->begin_transaction();
    try {
        $conn->query("UPDATE school_years SET is_active = 0");
        $stmt = $conn->prepare("UPDATE school_years SET is_active = 1 WHERE id = ?");
        if (!$stmt) {
            throw new RuntimeException('Could not prepare active school year update.');
        }
        $stmt->bind_param('i', $schoolYearId);
        $stmt->execute();
        if ($stmt->affected_rows < 1) {
            $stmt->close();
            throw new RuntimeException('School year not found.');
        }
        $stmt->close();
        $conn->commit();
        return ['success' => true, 'message' => 'Active school year updated.'];
    } catch (Throwable $e) {
        $conn->rollback();
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

function school_year_set_enrollment_open(mysqli $conn, int $schoolYearId, bool $isOpen): array
{
    school_year_ensure_table($conn);
    $open = $isOpen ? 1 : 0;
    $stmt = $conn->prepare("UPDATE school_years SET enrollment_open = ? WHERE id = ?");
    if (!$stmt) {
        return ['success' => false, 'message' => 'Could not update enrollment status.'];
    }
    $stmt->bind_param('ii', $open, $schoolYearId);
    $stmt->execute();
    $affected = $stmt->affected_rows;
    $stmt->close();
    if ($affected < 1) {
        return ['success' => false, 'message' => 'School year not found or status unchanged.'];
    }
    return ['success' => true, 'message' => $isOpen ? 'Enrollment opened for this school year.' : 'Enrollment closed for this school year.'];
}

function school_year_filter_options(mysqli $conn): array
{
    school_year_ensure_table($conn);
    school_year_ensure_finance_columns($conn);
    $options = [];
    $result = $conn->query("SELECT label FROM school_years ORDER BY id DESC");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $options[] = $row['label'];
        }
        $result->close();
    }
    return $options;
}

function school_year_finance_options(mysqli $conn, string $table): array
{
    school_year_ensure_table($conn);
    school_year_ensure_finance_columns($conn);

    $allowedTables = ['fee', 'accounts', 'payments'];
    if (!in_array($table, $allowedTables, true)) {
        return school_year_filter_options($conn);
    }

    $options = [];
    $result = $conn->query("SELECT DISTINCT school_year_label FROM {$table} WHERE school_year_label IS NOT NULL AND TRIM(school_year_label) <> '' ORDER BY school_year_label DESC");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $options[] = $row['school_year_label'];
        }
        $result->close();
    }

    foreach (school_year_filter_options($conn) as $label) {
        if (!in_array($label, $options, true)) {
            $options[] = $label;
        }
    }

    return $options;
}

function school_year_count_unassigned(mysqli $conn, string $table): int
{
    school_year_ensure_table($conn);
    school_year_ensure_finance_columns($conn);
    $allowedTables = ['students', 'student_registration_pending', 'fee', 'accounts', 'payments'];
    if (!in_array($table, $allowedTables, true)) {
        return 0;
    }

    $result = $conn->query("SELECT COUNT(*) AS total FROM {$table} WHERE school_year_label IS NULL OR TRIM(school_year_label) = ''");
    if ($result) {
        $row = $result->fetch_assoc();
        $result->close();
        return (int) ($row['total'] ?? 0);
    }

    return 0;
}

function school_year_finance_health_summary(mysqli $conn): array
{
    school_year_ensure_table($conn);
    school_year_ensure_finance_columns($conn);

    $summary = [
        'unassigned_fees' => school_year_count_unassigned($conn, 'fee'),
        'unassigned_accounts' => school_year_count_unassigned($conn, 'accounts'),
        'unassigned_payments' => school_year_count_unassigned($conn, 'payments'),
        'mismatched_accounts' => 0,
        'mismatched_payments' => 0,
        'active_year_fees' => 0,
        'active_year_accounts' => 0,
        'active_year_payments' => 0,
        'active_label' => school_year_get_active_label($conn),
        'is_ready' => false,
    ];

    $accountMismatchSql = "SELECT COUNT(*) AS total
        FROM accounts a
        INNER JOIN students s ON a.student_id = s.id
        WHERE NULLIF(TRIM(a.school_year_label), '') IS NOT NULL
          AND NULLIF(TRIM(s.school_year_label), '') IS NOT NULL
          AND TRIM(a.school_year_label) <> TRIM(s.school_year_label)";
    $accountMismatchRes = $conn->query($accountMismatchSql);
    if ($accountMismatchRes) {
        $summary['mismatched_accounts'] = (int) (($accountMismatchRes->fetch_assoc()['total'] ?? 0));
        $accountMismatchRes->close();
    }

    $paymentMismatchSql = "SELECT COUNT(*) AS total
        FROM payments p
        INNER JOIN accounts a ON p.account_id = a.id
        WHERE NULLIF(TRIM(p.school_year_label), '') IS NOT NULL
          AND NULLIF(TRIM(a.school_year_label), '') IS NOT NULL
          AND TRIM(p.school_year_label) <> TRIM(a.school_year_label)";
    $paymentMismatchRes = $conn->query($paymentMismatchSql);
    if ($paymentMismatchRes) {
        $summary['mismatched_payments'] = (int) (($paymentMismatchRes->fetch_assoc()['total'] ?? 0));
        $paymentMismatchRes->close();
    }

    $activeLabel = $summary['active_label'];
    $feeStmt = $conn->prepare("SELECT COUNT(*) AS total FROM fee WHERE COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?");
    if ($feeStmt) {
        $feeStmt->bind_param('ss', $activeLabel, $activeLabel);
        $feeStmt->execute();
        $summary['active_year_fees'] = (int) (($feeStmt->get_result()->fetch_assoc()['total'] ?? 0));
        $feeStmt->close();
    }

    $accountStmt = $conn->prepare("SELECT COUNT(*) AS total FROM accounts WHERE COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?");
    if ($accountStmt) {
        $accountStmt->bind_param('ss', $activeLabel, $activeLabel);
        $accountStmt->execute();
        $summary['active_year_accounts'] = (int) (($accountStmt->get_result()->fetch_assoc()['total'] ?? 0));
        $accountStmt->close();
    }

    $paymentStmt = $conn->prepare("SELECT COUNT(*) AS total FROM payments WHERE COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?");
    if ($paymentStmt) {
        $paymentStmt->bind_param('ss', $activeLabel, $activeLabel);
        $paymentStmt->execute();
        $summary['active_year_payments'] = (int) (($paymentStmt->get_result()->fetch_assoc()['total'] ?? 0));
        $paymentStmt->close();
    }

    $summary['is_ready'] =
        $summary['unassigned_fees'] === 0 &&
        $summary['unassigned_accounts'] === 0 &&
        $summary['unassigned_payments'] === 0 &&
        $summary['mismatched_accounts'] === 0 &&
        $summary['mismatched_payments'] === 0;

    return $summary;
}

function school_year_assign_existing_records(mysqli $conn, string $label, string $scope): array
{
    school_year_ensure_table($conn);
    $label = school_year_normalize_label($label);
    $allowedScopes = ['students', 'pending', 'both'];
    if ($label === '') {
        return ['success' => false, 'message' => 'Please choose a school year first.', 'updated_students' => 0, 'updated_pending' => 0];
    }
    if (!in_array($scope, $allowedScopes, true)) {
        return ['success' => false, 'message' => 'Invalid assignment scope.', 'updated_students' => 0, 'updated_pending' => 0];
    }

    $stmtCheck = $conn->prepare("SELECT id FROM school_years WHERE label = ? LIMIT 1");
    if (!$stmtCheck) {
        return ['success' => false, 'message' => 'Could not verify the selected school year.', 'updated_students' => 0, 'updated_pending' => 0];
    }
    $stmtCheck->bind_param('s', $label);
    $stmtCheck->execute();
    $exists = $stmtCheck->get_result()->num_rows > 0;
    $stmtCheck->close();
    if (!$exists) {
        return ['success' => false, 'message' => 'Selected school year does not exist.', 'updated_students' => 0, 'updated_pending' => 0];
    }

    $updatedStudents = 0;
    $updatedPending = 0;

    $conn->begin_transaction();
    try {
        if ($scope === 'students' || $scope === 'both') {
            $stmtStudents = $conn->prepare("UPDATE students SET school_year_label = ? WHERE school_year_label IS NULL OR TRIM(school_year_label) = ''");
            if (!$stmtStudents) {
                throw new RuntimeException('Could not prepare student backfill update.');
            }
            $stmtStudents->bind_param('s', $label);
            $stmtStudents->execute();
            $updatedStudents = $stmtStudents->affected_rows;
            $stmtStudents->close();
        }

        if ($scope === 'pending' || $scope === 'both') {
            $stmtPending = $conn->prepare("UPDATE student_registration_pending SET school_year_label = ? WHERE school_year_label IS NULL OR TRIM(school_year_label) = ''");
            if (!$stmtPending) {
                throw new RuntimeException('Could not prepare pending backfill update.');
            }
            $stmtPending->bind_param('s', $label);
            $stmtPending->execute();
            $updatedPending = $stmtPending->affected_rows;
            $stmtPending->close();
        }

        $conn->commit();
        $parts = [];
        if ($scope === 'students' || $scope === 'both') {
            $parts[] = $updatedStudents . ' student record(s)';
        }
        if ($scope === 'pending' || $scope === 'both') {
            $parts[] = $updatedPending . ' pending record(s)';
        }

        return [
            'success' => true,
            'message' => 'Assigned ' . implode(' and ', $parts) . ' to ' . $label . '.',
            'updated_students' => $updatedStudents,
            'updated_pending' => $updatedPending,
        ];
    } catch (Throwable $e) {
        $conn->rollback();
        return ['success' => false, 'message' => $e->getMessage(), 'updated_students' => 0, 'updated_pending' => 0];
    }
}

function school_year_assign_existing_finance(mysqli $conn, string $label, string $scope): array
{
    school_year_ensure_table($conn);
    school_year_ensure_finance_columns($conn);
    $label = school_year_normalize_label($label);
    $allowedScopes = ['fees', 'accounts', 'payments', 'all'];
    if ($label === '') {
        return ['success' => false, 'message' => 'Please choose a school year first.', 'updated_fees' => 0, 'updated_accounts' => 0, 'updated_payments' => 0];
    }
    if (!in_array($scope, $allowedScopes, true)) {
        return ['success' => false, 'message' => 'Invalid finance assignment scope.', 'updated_fees' => 0, 'updated_accounts' => 0, 'updated_payments' => 0];
    }

    $updatedFees = 0;
    $updatedAccounts = 0;
    $updatedPayments = 0;

    $conn->begin_transaction();
    try {
        if ($scope === 'fees' || $scope === 'all') {
            $feesStmt = $conn->prepare("UPDATE fee SET school_year_label = ? WHERE school_year_label IS NULL OR TRIM(school_year_label) = ''");
            if (!$feesStmt) {
                throw new RuntimeException('Could not prepare fee backfill update.');
            }
            $feesStmt->bind_param('s', $label);
            $feesStmt->execute();
            $updatedFees = $feesStmt->affected_rows;
            $feesStmt->close();
        }

        if ($scope === 'accounts' || $scope === 'all') {
            $accountSql = "UPDATE accounts a
                LEFT JOIN students s ON a.student_id = s.id
                SET a.school_year_label = COALESCE(NULLIF(TRIM(s.school_year_label), ''), ?)
                WHERE a.school_year_label IS NULL OR TRIM(a.school_year_label) = ''";
            $accountsStmt = $conn->prepare($accountSql);
            if (!$accountsStmt) {
                throw new RuntimeException('Could not prepare account backfill update.');
            }
            $accountsStmt->bind_param('s', $label);
            $accountsStmt->execute();
            $updatedAccounts = $accountsStmt->affected_rows;
            $accountsStmt->close();
        }

        if ($scope === 'payments' || $scope === 'all') {
            $paymentSql = "UPDATE payments p
                LEFT JOIN accounts a ON p.account_id = a.id
                LEFT JOIN students s ON a.student_id = s.id
                SET p.school_year_label = COALESCE(NULLIF(TRIM(p.school_year_label), ''), NULLIF(TRIM(a.school_year_label), ''), NULLIF(TRIM(s.school_year_label), ''), ?)
                WHERE p.school_year_label IS NULL OR TRIM(p.school_year_label) = ''";
            $paymentsStmt = $conn->prepare($paymentSql);
            if (!$paymentsStmt) {
                throw new RuntimeException('Could not prepare payment backfill update.');
            }
            $paymentsStmt->bind_param('s', $label);
            $paymentsStmt->execute();
            $updatedPayments = $paymentsStmt->affected_rows;
            $paymentsStmt->close();
        }

        $conn->commit();
        return [
            'success' => true,
            'message' => 'Finance school year backfill completed.',
            'updated_fees' => $updatedFees,
            'updated_accounts' => $updatedAccounts,
            'updated_payments' => $updatedPayments,
        ];
    } catch (Throwable $e) {
        $conn->rollback();
        return ['success' => false, 'message' => $e->getMessage(), 'updated_fees' => 0, 'updated_accounts' => 0, 'updated_payments' => 0];
    }
}

function school_year_fee_copy_preview(mysqli $conn, string $sourceLabel, string $targetLabel): array
{
    school_year_ensure_table($conn);
    school_year_ensure_finance_columns($conn);
    $sourceLabel = school_year_normalize_label($sourceLabel);
    $targetLabel = school_year_normalize_label($targetLabel);

    if ($sourceLabel === '' || $targetLabel === '') {
        return ['success' => false, 'message' => 'Please choose both source and target school years.', 'source_count' => 0, 'target_count' => 0, 'duplicate_count' => 0, 'copyable_count' => 0];
    }

    $sourceStmt = $conn->prepare("SELECT COUNT(*) AS total FROM fee WHERE school_year_label = ?");
    $sourceStmt->bind_param('s', $sourceLabel);
    $sourceStmt->execute();
    $sourceStmt->bind_result($sourceCount);
    $sourceStmt->fetch();
    $sourceStmt->close();

    $targetStmt = $conn->prepare("SELECT COUNT(*) AS total FROM fee WHERE school_year_label = ?");
    $targetStmt->bind_param('s', $targetLabel);
    $targetStmt->execute();
    $targetStmt->bind_result($targetCount);
    $targetStmt->fetch();
    $targetStmt->close();

    $duplicateSql = "SELECT COUNT(*) AS total
        FROM fee source_fee
        INNER JOIN fee target_fee
            ON target_fee.fee_type_id = source_fee.fee_type_id
           AND target_fee.grade_level = source_fee.grade_level
           AND target_fee.school_year_label = ?
        WHERE source_fee.school_year_label = ?";
    $duplicateStmt = $conn->prepare($duplicateSql);
    $duplicateStmt->bind_param('ss', $targetLabel, $sourceLabel);
    $duplicateStmt->execute();
    $duplicateStmt->bind_result($duplicateCount);
    $duplicateStmt->fetch();
    $duplicateStmt->close();

    return [
        'success' => true,
        'message' => 'Preview ready.',
        'source_count' => (int) $sourceCount,
        'target_count' => (int) $targetCount,
        'duplicate_count' => (int) $duplicateCount,
        'copyable_count' => max(0, (int) $sourceCount - (int) $duplicateCount),
    ];
}

function school_year_copy_fee_setup(mysqli $conn, string $sourceLabel, string $targetLabel): array
{
    school_year_ensure_table($conn);
    school_year_ensure_finance_columns($conn);
    $sourceLabel = school_year_normalize_label($sourceLabel);
    $targetLabel = school_year_normalize_label($targetLabel);

    if ($sourceLabel === '' || $targetLabel === '') {
        return ['success' => false, 'message' => 'Please choose both source and target school years.', 'copied_count' => 0, 'skipped_count' => 0];
    }
    if ($sourceLabel === $targetLabel) {
        return ['success' => false, 'message' => 'Source and target school year must be different.', 'copied_count' => 0, 'skipped_count' => 0];
    }

    $preview = school_year_fee_copy_preview($conn, $sourceLabel, $targetLabel);
    if (!$preview['success']) {
        return ['success' => false, 'message' => $preview['message'], 'copied_count' => 0, 'skipped_count' => 0];
    }
    if (($preview['source_count'] ?? 0) === 0) {
        return ['success' => false, 'message' => 'There are no fee setups to copy from the selected source year.', 'copied_count' => 0, 'skipped_count' => 0];
    }

    $copiedCount = 0;
    $skippedCount = 0;
    $conn->begin_transaction();
    try {
        $sourceRowsStmt = $conn->prepare("SELECT fee_type_id, grade_level, amount, notes FROM fee WHERE school_year_label = ? ORDER BY grade_level ASC, fee_type_id ASC");
        if (!$sourceRowsStmt) {
            throw new RuntimeException('Could not prepare source fee query.');
        }
        $sourceRowsStmt->bind_param('s', $sourceLabel);
        $sourceRowsStmt->execute();
        $result = $sourceRowsStmt->get_result();

        $existsStmt = $conn->prepare("SELECT id FROM fee WHERE fee_type_id = ? AND grade_level = ? AND school_year_label = ? LIMIT 1");
        $insertStmt = $conn->prepare("INSERT INTO fee (fee_type_id, grade_level, amount, notes, school_year_label) VALUES (?, ?, ?, ?, ?)");
        if (!$existsStmt || !$insertStmt) {
            throw new RuntimeException('Could not prepare fee copy statements.');
        }

        while ($row = $result->fetch_assoc()) {
            $feeTypeId = (int) $row['fee_type_id'];
            $gradeLevel = (int) $row['grade_level'];
            $amount = (float) $row['amount'];
            $notes = (string) ($row['notes'] ?? '');

            $existsStmt->bind_param('iis', $feeTypeId, $gradeLevel, $targetLabel);
            $existsStmt->execute();
            $existsResult = $existsStmt->get_result();
            $exists = $existsResult && $existsResult->num_rows > 0;
            if ($exists) {
                $skippedCount++;
                continue;
            }

            $insertStmt->bind_param('iidss', $feeTypeId, $gradeLevel, $amount, $notes, $targetLabel);
            if (!$insertStmt->execute()) {
                throw new RuntimeException('Failed to copy one or more fee rows.');
            }
            $copiedCount++;
        }

        $existsStmt->close();
        $insertStmt->close();
        $sourceRowsStmt->close();
        $conn->commit();

        return [
            'success' => true,
            'message' => 'Fee copy completed successfully.',
            'copied_count' => $copiedCount,
            'skipped_count' => $skippedCount,
        ];
    } catch (Throwable $e) {
        $conn->rollback();
        return ['success' => false, 'message' => $e->getMessage(), 'copied_count' => 0, 'skipped_count' => 0];
    }
}

}
