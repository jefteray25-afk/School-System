<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/app-env.php';
require_once __DIR__ . '/settings-permissions-roles.php';
require_once __DIR__ . '/school-info-helper.php';
require_once __DIR__ . '/backup-settings-helper.php';
require_once __DIR__ . '/../../tools/smoke-core.php';
require_once __DIR__ . '/../audit/audit-helper.php';

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';

if (!can_view_settings_module($role)) {
    audit_log(
        $conn,
        $username !== '' ? $username : 'unknown',
        'Blocked deployment readiness access',
        'Settings',
        'Role: ' . ($role !== '' ? $role : 'unknown') . ' | Reason: missing settings:view permission',
        'SECURITY'
    );
    header('Location: /school-admin-dashboard/dashboard.php?error=settings_denied');
    exit();
}
if (is_specialized_staff_role($role)) {
    audit_log(
        $conn,
        $username !== '' ? $username : 'unknown',
        'Blocked deployment readiness access',
        'Settings',
        'Role: ' . ($role !== '' ? $role : 'unknown') . ' | Reason: specialized staff role restriction',
        'SECURITY'
    );
    header('Location: /school-admin-dashboard/modules/settings/settings-dashboard.php?error=restricted');
    exit();
}

backup_settings_ensure_table($conn);
$backupSettings = backup_settings_get($conn);
$checks = school_admin_smoke_checks($conn);
$failedChecks = school_admin_smoke_failed_checks($checks);

$databaseLocalPath = __DIR__ . '/../../config/database.local.php';
$databaseLocalExists = is_file($databaseLocalPath);
$envSource = getenv('SCHOOL_APP_ENV') ? 'Environment variable' : 'Default local mode';
$dbSource = $databaseLocalExists ? 'database.local.php override' : 'Shared config defaults / env vars';
$backupDir = backup_settings_resolved_dir($backupSettings);
$backupDirReady = is_dir($backupDir) && is_writable($backupDir);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deployment Readiness | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background:#f5f8fc; font-family:'Segoe UI','Roboto','Arial',sans-serif; }
        .navbar { background:#23395d !important; }
        .navbar-brand, .navbar-nav .nav-link { color:#fff !important; }
        .page-wrap { max-width:1120px; margin:30px auto; padding:0 12px; }
        .hero, .panel { background:#fff; border:1px solid #dce8f7; border-radius:18px; box-shadow:0 8px 24px rgba(33,57,93,.08); }
        .hero { padding:22px 24px; margin-bottom:18px; }
        .panel { padding:18px; }
        .summary-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:14px; }
        .summary-card { background:#fff; border:1px solid #dce8f7; border-radius:16px; padding:16px; box-shadow:0 8px 24px rgba(33,57,93,.06); }
        .summary-label { font-size:.78rem; text-transform:uppercase; letter-spacing:.05em; color:#607388; font-weight:700; }
        .summary-value { font-size:1.2rem; font-weight:800; color:#23395d; }
        .checklist li { margin-bottom:8px; }
    </style>
</head>
<body>
<?php render_admin_nav('settings'); ?>

<div class="page-wrap">
    <div class="hero">
        <h1 class="h4 mb-1"><i class="fas fa-server me-2"></i>Deployment Readiness</h1>
        <div class="text-muted">Quick environment and deployment view for <strong><?= htmlspecialchars($schoolName) ?></strong>.</div>
    </div>

    <div class="summary-grid mb-3">
        <div class="summary-card">
            <div class="summary-label">Application Environment</div>
            <div class="summary-value"><?= htmlspecialchars(app_env_label()) ?></div>
            <div class="small text-muted"><?= htmlspecialchars($envSource) ?></div>
        </div>
        <div class="summary-card">
            <div class="summary-label">Database Config Source</div>
            <div class="summary-value"><?= $databaseLocalExists ? 'Local Override' : 'Default / Env' ?></div>
            <div class="small text-muted"><?= htmlspecialchars($dbSource) ?></div>
        </div>
        <div class="summary-card">
            <div class="summary-label">Backup Directory</div>
            <div class="summary-value"><?= $backupDirReady ? 'Ready' : 'Needs Attention' ?></div>
            <div class="small text-muted"><?= htmlspecialchars($backupDir) ?></div>
        </div>
        <div class="summary-card">
            <div class="summary-label">Smoke Result</div>
            <div class="summary-value"><?= count($failedChecks) === 0 ? 'Healthy' : 'Needs Review' ?></div>
            <div class="small text-muted"><?= number_format(count($failedChecks)) ?> failed check(s)</div>
        </div>
    </div>

    <div class="panel mb-3">
        <h2 class="h6 mb-3">Deployment Notes</h2>
        <ul class="checklist mb-0">
            <li>Switch to a dedicated MySQL user and password before wider live rollout.</li>
            <li>Keep <code>config/database.local.php</code> only on the live server, not inside shared exports.</li>
            <li>Set <code>SCHOOL_APP_ENV=production</code> on the live machine when you are ready to hide local-style debug behavior.</li>
            <li>Run the smoke check after any DB migration, backup restore, or major module change.</li>
        </ul>
    </div>

    <div class="panel">
        <h2 class="h6 mb-3">Last Backup Snapshot</h2>
        <div class="small text-muted mb-2">Status: <strong><?= htmlspecialchars((string) ($backupSettings['last_backup_status'] ?? 'Never Run')) ?></strong></div>
        <div class="small text-muted mb-2">Last run: <?= !empty($backupSettings['last_backup_at']) ? htmlspecialchars(date('M j, Y g:i A', strtotime((string) $backupSettings['last_backup_at']))) : 'No backup run recorded yet.' ?></div>
        <div class="small text-muted">File: <?= htmlspecialchars((string) ($backupSettings['last_backup_file'] ?? 'No backup file recorded')) ?></div>
    </div>
</div>
</body>
</html>
<?php $conn->close(); ?>
