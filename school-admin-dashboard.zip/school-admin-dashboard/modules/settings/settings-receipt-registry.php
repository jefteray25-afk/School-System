<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';

require '../../config/database.php';
require_once 'settings-permissions-roles.php';
require_once 'settings-security.php';
require_once '../../includes/includes-receipt-helper.php';
require_once 'school-info-helper.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

$currentRole = $_SESSION['role'] ?? '';
if (!can_access_settings_page($currentRole, 'receipt_registry')) {
    $blockedUser = $_SESSION['username'] ?? 'unknown';
    audit_log(
        $conn,
        $blockedUser,
        'Blocked settings receipt registry access',
        'Settings',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing receipt_registry permission',
        'SECURITY'
    );
    header('Location: /school-admin-dashboard/modules/settings/settings-dashboard.php?error=restricted');
    exit();
}

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';
$selectedReceiptNo = isset($_GET['receipt_no']) ? (int) $_GET['receipt_no'] : 0;
$selectedBookletNo = parse_booklet_input_to_storage($_GET['booklet_no'] ?? '') ?? 0;
$pageMessage = '';
$pageError = '';

ensure_csrf_token();
ensure_receipt_history_table($conn);
ensure_receipt_booklet_registry($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_booklet_registry_submit'])) {
    admin_require_post_csrf();

    $newBookletType = trim((string) ($_POST['new_booklet_type'] ?? ''));
    $newDisplayNumber = (int) ($_POST['new_display_number'] ?? 0);
    $newBookletStatus = trim((string) ($_POST['new_booklet_status'] ?? 'active'));
    $newBookletActive = isset($_POST['new_booklet_active']) ? 1 : 0;
    $newBookletNotes = trim((string) ($_POST['new_booklet_notes'] ?? ''));

    $createResult = receipt_booklet_registry_create($conn, $newBookletType, $newDisplayNumber, $newBookletStatus, $newBookletActive, $newBookletNotes);
    if (!$createResult['success']) {
        $pageError = (string) ($createResult['message'] ?? 'Failed to register the booklet.');
    } else {
        $pageMessage = (string) ($createResult['message'] ?? 'New booklet registered successfully.');
        $user = $_SESSION['username'] ?? 'unknown';
        $details = 'Booklet: ' . ($createResult['booklet_code'] ?? '')
            . ' | Type: ' . ($createResult['booklet_type'] ?? '')
            . ' | Range: ' . number_format((int) ($createResult['range_start'] ?? 0)) . ' - ' . number_format((int) ($createResult['range_end'] ?? 0))
            . ' | Status: ' . ($createResult['status'] ?? '')
            . ' | Visible In Payment: ' . (((int) ($createResult['is_active'] ?? 0) === 1) ? 'Yes' : 'No')
            . ' | Notes: ' . (($createResult['notes'] ?? '') !== '' ? $createResult['notes'] : 'None');
        audit_log($conn, $user, 'Registered receipt booklet', 'Receipt Registry', $details);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark_full_booklet_submit'])) {
    admin_require_post_csrf();

    $storageNumber = (int) ($_POST['smart_storage_number'] ?? 0);
    $markFullResult = receipt_booklet_registry_mark_full($conn, $storageNumber);
    if (!$markFullResult['success']) {
        $pageError = (string) ($markFullResult['message'] ?? 'Failed to mark the booklet as full.');
    } else {
        $pageMessage = (string) ($markFullResult['message'] ?? 'Booklet marked as full.');
        if (!empty($markFullResult['changed'])) {
            $user = $_SESSION['username'] ?? 'unknown';
            $details = 'Booklet: ' . ($markFullResult['booklet_code'] ?? $storageNumber)
                . ' | Type: ' . ($markFullResult['booklet_type'] ?? 'unknown')
                . ' | Status: ' . ($markFullResult['old_status'] ?? 'unknown') . ' -> full'
                . ' | Visible In Payment: ' . (((int) ($markFullResult['old_active'] ?? 0) === 1) ? 'Yes' : 'No') . ' -> No';
            audit_log($conn, $user, 'Marked receipt booklet full', 'Receipt Registry', $details);
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['activate_next_booklet_submit'])) {
    admin_require_post_csrf();

    $storageNumber = (int) ($_POST['smart_storage_number'] ?? 0);
    $activateResult = receipt_booklet_registry_activate_next($conn, $storageNumber);
    if (!$activateResult['success']) {
        $pageError = (string) ($activateResult['message'] ?? 'Failed to activate the next booklet.');
    } else {
        $pageMessage = (string) ($activateResult['message'] ?? 'Next booklet activated successfully.');
        if (!empty($activateResult['changed'])) {
            $user = $_SESSION['username'] ?? 'unknown';
            $details = 'Current Booklet: ' . ($activateResult['current_booklet_code'] ?? 'unknown')
                . ' | Activated Booklet: ' . ($activateResult['booklet_code'] ?? 'unknown')
                . ' | Type: ' . ($activateResult['booklet_type'] ?? 'unknown')
                . ' | Status: ' . ($activateResult['old_status'] ?? 'unknown') . ' -> active'
                . ' | Visible In Payment: ' . (((int) ($activateResult['old_active'] ?? 0) === 1) ? 'Yes' : 'No') . ' -> Yes';
            audit_log($conn, $user, 'Activated next receipt booklet', 'Receipt Registry', $details);
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_visible_booklet_submit'])) {
    admin_require_post_csrf();

    $storageNumber = (int) ($_POST['smart_storage_number'] ?? 0);
    $setVisibleResult = receipt_booklet_registry_set_visible_booklet($conn, $storageNumber);
    if (!$setVisibleResult['success']) {
        $pageError = (string) ($setVisibleResult['message'] ?? 'Failed to update the visible payment booklet.');
    } else {
        $pageMessage = (string) ($setVisibleResult['message'] ?? 'Visible payment booklet updated successfully.');
        if (!empty($setVisibleResult['changed'])) {
            $user = $_SESSION['username'] ?? 'unknown';
            $details = 'Booklet: ' . ($setVisibleResult['booklet_code'] ?? 'unknown')
                . ' | Type: ' . ($setVisibleResult['booklet_type'] ?? 'unknown')
                . ' | Status: ' . ($setVisibleResult['old_status'] ?? 'unknown') . ' -> active'
                . ' | Visible Before: ' . (!empty($setVisibleResult['visible_before']) ? implode(', ', $setVisibleResult['visible_before']) : 'None')
                . ' | Visible After: ' . (!empty($setVisibleResult['visible_after']) ? implode(', ', $setVisibleResult['visible_after']) : 'None');
            audit_log($conn, $user, 'Set preferred visible receipt booklet', 'Receipt Registry', $details);
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_booklet_registry_submit'])) {
    admin_require_post_csrf();

    $storageNumbers = $_POST['storage_numbers'] ?? [];
    $bookletStatuses = $_POST['booklet_status'] ?? [];
    $bookletActives = $_POST['booklet_active'] ?? [];
    $bookletNotes = $_POST['booklet_notes'] ?? [];

    if (!is_array($storageNumbers) || !$storageNumbers) {
        $pageError = 'No booklet rows were submitted.';
    } else {
        $changedCount = 0;
        $processedCount = 0;
        $errors = [];
        $user = $_SESSION['username'] ?? 'unknown';

        foreach ($storageNumbers as $storageNumberRaw) {
            $storageNumber = (int) $storageNumberRaw;
            if ($storageNumber <= 0) {
                continue;
            }

            $processedCount++;
            $status = trim((string) ($bookletStatuses[$storageNumber] ?? ''));
            $active = isset($bookletActives[$storageNumber]) ? 1 : 0;
            $notes = trim((string) ($bookletNotes[$storageNumber] ?? ''));

            $updateResult = receipt_booklet_registry_update($conn, $storageNumber, $status, $active, $notes);
            if (!$updateResult['success']) {
                $errors[] = ($updateResult['booklet_code'] ?? $storageNumber) . ': ' . ($updateResult['message'] ?? 'Update failed.');
                continue;
            }

            if (!empty($updateResult['changed'])) {
                $changedCount++;
                $details = 'Booklet: ' . ($updateResult['booklet_code'] ?? $storageNumber)
                    . ' | Type: ' . ($updateResult['booklet_type'] ?? 'unknown')
                    . ' | Status: ' . ($updateResult['old_status'] ?? 'unknown') . ' -> ' . ($updateResult['new_status'] ?? 'unknown')
                    . ' | Visible In Payment: ' . (((int) ($updateResult['old_active'] ?? 0) === 1) ? 'Yes' : 'No') . ' -> ' . (((int) ($updateResult['new_active'] ?? 0) === 1) ? 'Yes' : 'No')
                    . ' | Notes: ' . (($updateResult['new_notes'] ?? '') !== '' ? $updateResult['new_notes'] : 'None');
                audit_log($conn, $user, 'Updated receipt booklet settings', 'Receipt Registry', $details);
            }
        }

        if ($errors) {
            $pageError = implode(' | ', $errors);
            if ($changedCount > 0) {
                $pageMessage = $changedCount . ' booklet setting(s) were updated before the errors occurred.';
            }
        } else {
            $pageMessage = $changedCount > 0
                ? $changedCount . ' booklet setting(s) updated successfully.'
                : ($processedCount > 0 ? 'No booklet changes were needed.' : 'No booklet rows were processed.');
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['void_receipt_submit'])) {
    admin_require_post_csrf();
    if ($currentRole !== 'Super Administrator') {
        $pageError = 'Only Super Administrators can void receipts.';
    } else {
        $receiptNo = (int) ($_POST['receipt_no'] ?? 0);
        $bookletNo = parse_booklet_input_to_storage($_POST['booklet_no'] ?? '') ?? 0;
        $voidReason = trim($_POST['void_reason'] ?? '');
        $voidedBy = (int) ($_SESSION['user_id'] ?? 0);

        if ($receiptNo <= 0 || $voidReason === '') {
            $pageError = 'Receipt number and void reason are required.';
        } elseif (void_receipt($conn, $receiptNo, $voidReason, $voidedBy, $bookletNo > 0 ? $bookletNo : null)) {
$pageMessage = 'Receipt #' . number_format($receiptNo) . ' has been voided and remains reusable with history recorded.';

            $user = $_SESSION['username'] ?? 'unknown';
            $action = 'Voided receipt in registry';
            $module = 'Receipt Registry';
            $details = 'Role: ' . ($_SESSION['role'] ?? 'unknown')
                . ' | Receipt No: ' . $receiptNo
                . ' | Booklet: ' . ($bookletNo > 0 ? booklet_label_from_stored($bookletNo) : 'any')
                . ' | Reason: ' . $voidReason
                . ' | Voided by: ' . $user;
            audit_log($conn, $user, $action, $module, $details);
        } else {
            $pageError = 'Receipt could not be voided. It may already be voided or not exist.';
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['repair_missing_registry_submit'])) {
    admin_require_post_csrf();
    $receiptNo = (int) ($_POST['receipt_no'] ?? 0);
    $bookletNo = parse_booklet_input_to_storage($_POST['booklet_no'] ?? '') ?? 0;

    if ($receiptNo <= 0 || $bookletNo <= 0) {
        $pageError = 'Receipt cleanup requires both receipt number and booklet number.';
    } else {
        $existingRegistry = get_receipt_registry_entry($conn, $receiptNo, $bookletNo);
        if ($existingRegistry && (int) $existingRegistry['voided'] === 0) {
            $pageError = 'That receipt already has an active registry entry.';
        } else {
            $candidateSql = "
                SELECT p.id,
                       EXISTS(SELECT 1 FROM other_payments op WHERE op.payment_id = p.id) AS is_other_payment
                FROM payments p
                LEFT JOIN receipts_registry rr
                    ON rr.receipt_no = p.receipt_no
                    AND rr.booklet_no = p.booklet_no
                    AND rr.voided = 0
                    AND rr.used_by IN ('payments', 'other_payment')
                WHERE p.booklet_no = ?
                  AND p.receipt_no = ?
                  AND rr.receipt_no IS NULL
                ORDER BY p.id ASC
            ";
            $candidateStmt = $conn->prepare($candidateSql);
            $candidateStmt->bind_param("ii", $bookletNo, $receiptNo);
            $candidateStmt->execute();
            $candidateRes = $candidateStmt->get_result();
            $candidates = [];
            while ($row = $candidateRes->fetch_assoc()) {
                $candidates[] = $row;
            }
            $candidateStmt->close();

            if (count($candidates) !== 1) {
                $pageError = 'This mismatch is not safe for one-click repair because multiple payment rows share the same booklet and receipt.';
            } else {
                $paymentId = (int) $candidates[0]['id'];
                $usedBy = ((int) $candidates[0]['is_other_payment'] === 1) ? 'other_payment' : 'payments';

                $conn->begin_transaction();
                $reserve = reserve_or_reuse_receipt(
                    $conn,
                    $receiptNo,
                    $bookletNo,
                    $usedBy,
                    'Registry cleanup repair for missing active registry entry'
                );

                if (!$reserve['success']) {
                    $conn->rollback();
                    $pageError = $reserve['message'] ?: 'Failed to recreate the missing registry entry.';
                } elseif (!attach_receipt_to_payment($conn, $receiptNo, $paymentId, $bookletNo)) {
                    $conn->rollback();
                    $pageError = 'Failed to relink the recreated registry entry to the payment.';
                } else {
                    $conn->commit();
                    $pageMessage = 'Missing registry entry repaired for ' . booklet_label_from_stored($bookletNo) . ' / ' . number_format($receiptNo) . '.';

                    $user = $_SESSION['username'] ?? 'unknown';
                    audit_log(
                        $conn,
                        $user,
                        'Repaired missing receipt registry entry',
                        'Receipt Registry',
                        'Booklet: ' . booklet_label_from_stored($bookletNo)
                        . ' | Receipt No: ' . $receiptNo
                        . ' | Payment ID: ' . $paymentId
                        . ' | Used By: ' . $usedBy
                    );
                }
            }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['void_orphan_registry_submit'])) {
    admin_require_post_csrf();
    $receiptNo = (int) ($_POST['receipt_no'] ?? 0);
    $bookletNo = parse_booklet_input_to_storage($_POST['booklet_no'] ?? '') ?? 0;
    $voidedBy = (int) ($_SESSION['user_id'] ?? 0);

    if ($receiptNo <= 0 || $bookletNo <= 0) {
        $pageError = 'Orphan cleanup requires both receipt number and booklet number.';
    } elseif (void_receipt($conn, $receiptNo, 'Registry cleanup: linked payment record is missing', $voidedBy, $bookletNo)) {
        $pageMessage = 'Orphan registry entry voided for ' . booklet_label_from_stored($bookletNo) . ' / ' . number_format($receiptNo) . '.';

        $user = $_SESSION['username'] ?? 'unknown';
        audit_log(
            $conn,
            $user,
            'Voided orphan receipt registry entry',
            'Receipt Registry',
            'Booklet: ' . booklet_label_from_stored($bookletNo)
            . ' | Receipt No: ' . $receiptNo
            . ' | Reason: Registry cleanup: linked payment record is missing'
        );
    } else {
        $pageError = 'Orphan registry entry could not be voided. It may already be resolved.';
    }
}

$summarySql = "
SELECT
    COUNT(*) AS total_registry,
    SUM(CASE WHEN voided = 0 THEN 1 ELSE 0 END) AS active_receipts,
    SUM(CASE WHEN voided = 1 THEN 1 ELSE 0 END) AS voided_receipts,
    COUNT(DISTINCT CASE WHEN voided = 0 THEN booklet_no END) AS active_booklets
FROM receipts_registry
";
$summaryRow = $conn->query($summarySql)->fetch_assoc() ?: [];

$specialSummarySql = "
SELECT
    COUNT(*) AS total_entries,
    SUM(CASE WHEN voided = 0 THEN 1 ELSE 0 END) AS active_receipts,
    SUM(CASE WHEN voided = 1 THEN 1 ELSE 0 END) AS voided_receipts,
    COUNT(DISTINCT CASE WHEN voided = 0 THEN booklet_no END) AS active_booklets
FROM receipts_registry
WHERE booklet_no >= " . (SPECIAL_BOOKLET_STORAGE_OFFSET + SPECIAL_BOOKLET_MIN) . "
  AND booklet_no <= " . (SPECIAL_BOOKLET_STORAGE_OFFSET + SPECIAL_BOOKLET_MAX);
$specialSummary = $conn->query($specialSummarySql)->fetch_assoc() ?: [];

$regularSummarySql = "
SELECT
    COUNT(*) AS total_entries,
    SUM(CASE WHEN voided = 0 THEN 1 ELSE 0 END) AS active_receipts,
    SUM(CASE WHEN voided = 1 THEN 1 ELSE 0 END) AS voided_receipts,
    COUNT(DISTINCT CASE WHEN voided = 0 THEN booklet_no END) AS active_booklets
FROM receipts_registry
WHERE booklet_no >= " . REGULAR_BOOKLET_MIN . "
  AND booklet_no <= " . REGULAR_BOOKLET_MAX;
$regularSummary = $conn->query($regularSummarySql)->fetch_assoc() ?: [];
$bookletRegistrySummary = receipt_booklet_registry_summary($conn);
$paymentVisibleBookletSummary = receipt_booklet_registry_payment_summary($conn);
$voidedSummary = receipt_registry_voided_summary($conn);
$bookletCatalogRows = receipt_booklet_registry_rows($conn);
$bookletMonitoringMap = receipt_booklet_monitoring_map($conn, $bookletCatalogRows);
$bookletMonitoringSummary = receipt_booklet_monitoring_summary($bookletMonitoringMap);
$regularActiveSnapshot = receipt_booklet_registry_active_snapshot($conn, 'regular');
$specialActiveSnapshot = receipt_booklet_registry_active_snapshot($conn, 'special');
$nextBookletByStorage = [];
foreach (['regular', 'special'] as $family) {
    $familyRows = array_values(array_filter($bookletCatalogRows, static function ($row) use ($family) {
        return ($row['booklet_type'] ?? '') === $family;
    }));
    $familyCount = count($familyRows);
    for ($i = 0; $i < $familyCount; $i++) {
        $storageNumber = (int) ($familyRows[$i]['storage_number'] ?? 0);
        $nextBookletByStorage[$storageNumber] = $familyRows[$i + 1] ?? null;
    }
}
$regularBookletCatalogRows = array_values(array_filter($bookletCatalogRows, static function ($row) {
    return ($row['booklet_type'] ?? '') === 'regular';
}));
$specialBookletCatalogRows = array_values(array_filter($bookletCatalogRows, static function ($row) {
    return ($row['booklet_type'] ?? '') === 'special';
}));
$bookletCatalogLookup = [];
foreach ($bookletCatalogRows as $catalogRow) {
    $bookletCatalogLookup[$catalogRow['booklet_code']] = true;
}

$bookletRows = [];
$regularBookletRows = [];
$specialBookletRows = [];
$bookletSummarySql = "
SELECT
    booklet_no,
    SUM(CASE WHEN voided = 0 THEN 1 ELSE 0 END) AS used_count,
    SUM(CASE WHEN voided = 1 THEN 1 ELSE 0 END) AS voided_count,
    MAX(used_at) AS last_used_at
FROM receipts_registry
GROUP BY booklet_no
ORDER BY booklet_no ASC
";
$bookletResult = $conn->query($bookletSummarySql);
if ($bookletResult) {
    while ($row = $bookletResult->fetch_assoc()) {
        $bookletNo = (int) $row['booklet_no'];
        [$startReceipt, $endReceipt] = receipt_window_for_booklet($bookletNo);
        [$usedReceipts, $nextAvailable] = get_receipts_for_booklet($conn, $bookletNo);
        $capacity = ($endReceipt - $startReceipt) + 1;
        $activeCount = count($usedReceipts);
        $availableCount = max(0, $capacity - $activeCount);

        $bookletRows[] = [
            'booklet_no' => $bookletNo,
            'booklet_label' => booklet_label_from_stored($bookletNo),
            'booklet_family' => is_special_booklet_storage_number($bookletNo) ? 'special' : 'regular',
            'range_label' => $startReceipt . ' - ' . $endReceipt,
            'used_count' => $activeCount,
            'voided_count' => (int) $row['voided_count'],
            'available_count' => $availableCount,
            'next_available' => $nextAvailable,
            'last_used_at' => $row['last_used_at'],
        ];

        if (is_special_booklet_storage_number($bookletNo)) {
            $specialBookletRows[] = end($bookletRows);
        } else {
            $regularBookletRows[] = end($bookletRows);
        }
    }
}
$observedBookletLabels = [];
foreach ($bookletRows as $row) {
    $observedBookletLabels[$row['booklet_label']] = true;
}
$observedBookletCount = count($observedBookletLabels);
$catalogObservedCount = 0;
foreach (array_keys($observedBookletLabels) as $bookletLabel) {
    if (isset($bookletCatalogLookup[$bookletLabel])) {
        $catalogObservedCount++;
    }
}
$catalogUnmatchedCount = max(0, $observedBookletCount - $catalogObservedCount);

$recentActivity = [];
$recentSql = "
SELECT receipt_no, booklet_no, used_by, used_id, used_at, voided, void_reason, voided_at
FROM receipts_registry
ORDER BY used_at DESC, receipt_no DESC
LIMIT 250
";
$recentResult = $conn->query($recentSql);
if ($recentResult) {
    while ($row = $recentResult->fetch_assoc()) {
        $row['booklet_label'] = booklet_label_from_stored((int) $row['booklet_no']);
        $row['booklet_family'] = is_special_booklet_storage_number((int) $row['booklet_no']) ? 'special' : 'regular';
        $recentActivity[] = $row;
    }
}

$currentReceiptState = $recentActivity;
$recentActivity = get_receipt_history($conn, null, 250);
$receiptHistory = get_receipt_history($conn, $selectedReceiptNo ?: null, 150, $selectedBookletNo > 0 ? $selectedBookletNo : null);
$selectedReceiptEntry = null;
if ($selectedReceiptNo > 0) {
    $selectedReceiptEntry = get_receipt_registry_entry($conn, $selectedReceiptNo, $selectedBookletNo > 0 ? $selectedBookletNo : null);
    if (!$selectedReceiptEntry && $selectedBookletNo > 0) {
        $selectedReceiptEntry = get_receipt_registry_entry($conn, $selectedReceiptNo, null);
    }
}
$selectedReceiptHasVoidHistory = false;
foreach ($receiptHistory as $historyRow) {
    if (($historyRow['action_type'] ?? '') === 'voided') {
        $selectedReceiptHasVoidHistory = true;
        break;
    }
}
$nextRegularReceipt = get_next_regular_receipt_no($conn);
$nextSpecialReceipt = get_next_special_receipt_no($conn);

$legacyMigrationRows = [];
$legacyMigrationSummary = [
    'legacy_count' => 0,
    'ready_count' => 0,
    'blocked_count' => 0,
];

$validationSummary = [
    'active_payments_missing_registry' => 0,
    'registry_missing_payment' => 0,
    'old_payments_missing_registry' => 0,
    'registry_missing_old_payment' => 0,
];
$validationRows = [];

$legacySpecialSql = "
SELECT rr.receipt_no, rr.booklet_no, rr.used_by, rr.used_id, rr.used_at, rr.voided
FROM receipts_registry rr
WHERE rr.booklet_no BETWEEN " . (SPECIAL_BOOKLET_STORAGE_OFFSET + SPECIAL_BOOKLET_MIN) . " AND " . (SPECIAL_BOOKLET_STORAGE_OFFSET + SPECIAL_BOOKLET_MAX) . "
ORDER BY rr.booklet_no ASC, rr.receipt_no ASC
";
$legacySpecialResult = $conn->query($legacySpecialSql);
if ($legacySpecialResult) {
    $suggestedByBooklet = [];
    while ($row = $legacySpecialResult->fetch_assoc()) {
        $bookletNo = (int) $row['booklet_no'];
        [$expectedStart, $expectedEnd] = receipt_window_for_booklet($bookletNo);
        $receiptNo = (int) $row['receipt_no'];

        if ($receiptNo >= $expectedStart && $receiptNo <= $expectedEnd) {
            continue;
        }

        $legacyMigrationSummary['legacy_count']++;
        if (!isset($suggestedByBooklet[$bookletNo])) {
            [$usedReceipts] = get_receipts_for_booklet($conn, $bookletNo);
            $suggestedByBooklet[$bookletNo] = $usedReceipts;
        }

        $suggestedReceipt = null;
        for ($candidate = $expectedStart; $candidate <= $expectedEnd; $candidate++) {
            if (!in_array($candidate, $suggestedByBooklet[$bookletNo], true)) {
                $suggestedReceipt = $candidate;
                $suggestedByBooklet[$bookletNo][] = $candidate;
                break;
            }
        }

        $status = $suggestedReceipt === null ? 'Blocked' : 'Ready for Guided Migration';
        if ($suggestedReceipt === null) {
            $legacyMigrationSummary['blocked_count']++;
        } else {
            $legacyMigrationSummary['ready_count']++;
        }

        $legacyMigrationRows[] = [
            'booklet_no' => $bookletNo,
            'booklet_label' => booklet_label_from_stored($bookletNo),
            'current_receipt_no' => $receiptNo,
            'expected_range' => $expectedStart . ' - ' . $expectedEnd,
            'suggested_receipt_no' => $suggestedReceipt,
            'status' => $status,
            'used_by' => $row['used_by'],
            'used_id' => (int) $row['used_id'],
            'used_at' => $row['used_at'],
            'voided' => (int) $row['voided'],
        ];
    }
}

$validationQueries = [
    'active_payments_missing_registry' => "
        SELECT MIN(p.id) AS record_id, p.booklet_no, p.receipt_no, MAX(p.date_paid) AS event_at,
               COUNT(*) AS payment_count,
               COUNT(DISTINCT a.student_id) AS student_count,
               MAX(CASE WHEN op.payment_id IS NOT NULL THEN 1 ELSE 0 END) AS has_other_payment,
               'Active payment without active registry entry' AS issue_label,
               'Review payment row and recreate or relink its receipt registry entry.' AS recommendation
        FROM payments p
        LEFT JOIN accounts a ON a.id = p.account_id
        LEFT JOIN other_payments op ON op.payment_id = p.id
        LEFT JOIN receipts_registry rr
            ON rr.receipt_no = p.receipt_no
            AND rr.booklet_no = p.booklet_no
            AND rr.voided = 0
            AND rr.used_by IN ('payments', 'other_payment')
        WHERE p.booklet_no IS NOT NULL
          AND p.receipt_no IS NOT NULL
          AND rr.receipt_no IS NULL
        GROUP BY p.booklet_no, p.receipt_no
        ORDER BY MAX(p.date_paid) DESC
        LIMIT 20
    ",
    'registry_missing_payment' => "
        SELECT rr.used_id AS record_id, rr.booklet_no, rr.receipt_no, rr.used_at AS event_at,
               0 AS payment_count,
               0 AS student_count,
               0 AS has_other_payment,
               'Registry entry linked to missing payment row' AS issue_label,
               'Review whether the payment was deleted and whether the registry entry should be voided or relinked.' AS recommendation
        FROM receipts_registry rr
        LEFT JOIN payments p ON p.id = rr.used_id
        WHERE rr.used_by IN ('payments', 'other_payment')
          AND rr.voided = 0
          AND rr.used_id > 0
          AND p.id IS NULL
        ORDER BY rr.used_at DESC
        LIMIT 20
    ",
    'old_payments_missing_registry' => "
        SELECT p.id AS record_id, p.booklet_no, p.receipt_no, p.paid_at AS event_at,
               0 AS payment_count,
               0 AS student_count,
               0 AS has_other_payment,
               'Old payment without active registry entry' AS issue_label,
               'Review old payment row and recreate or relink its receipt registry entry.' AS recommendation
        FROM old_student_payments p
        LEFT JOIN receipts_registry rr
            ON rr.receipt_no = p.receipt_no
            AND rr.booklet_no = p.booklet_no
            AND rr.voided = 0
            AND rr.used_by = 'old_student_payments'
        WHERE (p.deleted_at IS NULL OR p.deleted_at = '')
          AND p.booklet_no IS NOT NULL
          AND p.receipt_no IS NOT NULL
          AND rr.receipt_no IS NULL
        ORDER BY p.paid_at DESC
        LIMIT 20
    ",
    'registry_missing_old_payment' => "
        SELECT rr.used_id AS record_id, rr.booklet_no, rr.receipt_no, rr.used_at AS event_at,
               0 AS payment_count,
               0 AS student_count,
               0 AS has_other_payment,
               'Registry entry linked to missing old payment row' AS issue_label,
               'Review whether the old payment was deleted and whether the registry entry should be voided or relinked.' AS recommendation
        FROM receipts_registry rr
        LEFT JOIN old_student_payments p ON p.id = rr.used_id
        WHERE rr.used_by = 'old_student_payments'
          AND rr.voided = 0
          AND rr.used_id > 0
          AND p.id IS NULL
        ORDER BY rr.used_at DESC
        LIMIT 20
    ",
];

$validationCountQueries = [
    'active_payments_missing_registry' => "
        SELECT COUNT(*) AS c
        FROM payments p
        LEFT JOIN receipts_registry rr
            ON rr.receipt_no = p.receipt_no
            AND rr.booklet_no = p.booklet_no
            AND rr.voided = 0
            AND rr.used_by IN ('payments', 'other_payment')
        WHERE p.booklet_no IS NOT NULL
          AND p.receipt_no IS NOT NULL
          AND rr.receipt_no IS NULL
    ",
    'registry_missing_payment' => "
        SELECT COUNT(*) AS c
        FROM receipts_registry rr
        LEFT JOIN payments p ON p.id = rr.used_id
        WHERE rr.used_by IN ('payments', 'other_payment')
          AND rr.voided = 0
          AND rr.used_id > 0
          AND p.id IS NULL
    ",
    'old_payments_missing_registry' => "
        SELECT COUNT(*) AS c
        FROM old_student_payments p
        LEFT JOIN receipts_registry rr
            ON rr.receipt_no = p.receipt_no
            AND rr.booklet_no = p.booklet_no
            AND rr.voided = 0
            AND rr.used_by = 'old_student_payments'
        WHERE (p.deleted_at IS NULL OR p.deleted_at = '')
          AND p.booklet_no IS NOT NULL
          AND p.receipt_no IS NOT NULL
          AND rr.receipt_no IS NULL
    ",
    'registry_missing_old_payment' => "
        SELECT COUNT(*) AS c
        FROM receipts_registry rr
        LEFT JOIN old_student_payments p ON p.id = rr.used_id
        WHERE rr.used_by = 'old_student_payments'
          AND rr.voided = 0
          AND rr.used_id > 0
          AND p.id IS NULL
    ",
];

foreach ($validationQueries as $key => $sql) {
    $countResult = $conn->query($validationCountQueries[$key]);
    if ($countResult) {
        $validationSummary[$key] = (int) (($countResult->fetch_assoc()['c'] ?? 0));
    }

    $result = $conn->query($sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $row['booklet_label'] = booklet_label_from_stored((int) $row['booklet_no']);
            $row['issue_key'] = $key;
            $row['repairable'] = false;
            $row['repair_action_label'] = '';
            if ($key === 'active_payments_missing_registry' && (int) ($row['payment_count'] ?? 0) === 1) {
                $row['repairable'] = true;
                $row['repair_action_label'] = 'Repair Registry';
                $row['recommendation'] = 'Safe one-click repair is available because this booklet/receipt pair has exactly one payment row.';
            } elseif ($key === 'active_payments_missing_registry') {
                $row['recommendation'] = 'Blocked from one-click repair because multiple payment rows share this booklet/receipt pair.';
            } elseif ($key === 'registry_missing_payment') {
                $row['repairable'] = true;
                $row['repair_action_label'] = 'Void Orphan';
                $row['recommendation'] = 'Safe one-click orphan cleanup is available because the linked payment row no longer exists.';
            }
            $validationRows[] = $row;
        }
    }
}

$validationNeedsReview = array_sum($validationSummary) > 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Receipt Registry Dashboard | School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
            --summary-blue: #eaf4ff;
            --summary-green: #e8f7ef;
            --summary-gold: #fff6db;
            --summary-red: #fdeaea;
        }
        body { background: var(--main-bg); font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif; }
        body.dark-mode {
            --main-bg: #1b232d;
            --card-bg: #23395d;
            --navbar-bg: #161b22;
            --summary-blue: #2c4e78;
            --summary-green: #275b46;
            --summary-gold: #635224;
            --summary-red: #6a3131;
            color: #e6edf3;
        }
        .navbar { background: var(--navbar-bg) !important; box-shadow: 0 2px 12px rgba(33,57,93,0.08); }
        .navbar-brand, .navbar-nav .nav-link { color: #fff !important; font-size: 1.08em; }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .theme-toggle-btn { background: none; border: none; color: #fff; font-size: 1.45em; margin-left: 12px; cursor: pointer; }
        .dashboard-header { text-align: center; margin-top: 36px; margin-bottom: 18px; }
        .dashboard-header img { width: 70px; height: 70px; object-fit: contain; margin-bottom: 6px; }
        .dashboard-header h1 { font-size: 1.3rem; color: var(--brand-dark); font-weight: 700; margin-bottom: 0; letter-spacing: 0.02em; }
        body.dark-mode .dashboard-header h1 { color: #e6edf3; }
        .report-header { text-align: center; margin-bottom: 1.5rem; }
        .report-header .lead { max-width: 760px; margin: .35rem auto 0; font-size: .98rem; line-height: 1.5; }
        .summary-card { background: var(--card-bg); border: 1px solid rgba(81, 127, 164, 0.12); border-radius: .85rem; box-shadow: 0 4px 18px rgba(33, 57, 93, 0.07); padding: .7rem .85rem; height: 100%; min-height: 84px; }
        .summary-card.blue { background: var(--summary-blue); }
        .summary-card.green { background: var(--summary-green); }
        .summary-card.gold { background: var(--summary-gold); }
        .summary-card.red { background: var(--summary-red); }
        .summary-card.special { background: #eef7ff; }
        .summary-card.regular { background: #eef9f0; }
        .summary-label { font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.05em; color: #5d728b; margin-bottom: 0.18rem; line-height: 1.25; }
        .summary-value { font-size: 1.15rem; font-weight: 700; color: var(--brand-dark); line-height: 1.2; }
        .summary-meta { font-size: .72rem; color: #718398; margin-top: .2rem; }
        body.dark-mode .summary-label { color: #d0dae6; }
        body.dark-mode .summary-value { color: #e6edf3; }
        body.dark-mode .summary-meta { color: #c3cfdb; }
        .summary-section { margin-bottom: 1rem; }
        .summary-section-header { display:flex; align-items:center; justify-content:space-between; gap:.75rem; margin-bottom:.55rem; }
        .summary-section-title { font-size: .95rem; font-weight: 700; color: var(--brand-dark); margin: 0; }
        body.dark-mode .summary-section-title { color: #e6edf3; }
        .summary-section-note { font-size: .78rem; color: #6c7d90; margin: 0; }
        body.dark-mode .summary-section-note { color: #c3cfdb; }
        .overview-shell {
            display: grid;
            gap: 1rem;
        }
        .overview-hero {
            background: linear-gradient(180deg, rgba(255,255,255,0.94), rgba(247,250,253,0.96));
            border: 1px solid rgba(81,127,164,0.14);
            border-radius: 1rem;
            padding: 1rem 1.05rem;
            box-shadow: 0 8px 22px rgba(33,57,93,0.04);
        }
        .overview-eyebrow {
            font-size: .72rem;
            font-weight: 800;
            letter-spacing: .08em;
            text-transform: uppercase;
            color: #517fa4;
            margin-bottom: .35rem;
        }
        .overview-title {
            font-size: 1.08rem;
            font-weight: 800;
            color: var(--brand-dark);
            margin-bottom: .3rem;
        }
        .overview-note {
            font-size: .9rem;
            color: #60758b;
            line-height: 1.5;
            margin: 0;
        }
        .overview-flow {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: .7rem;
            margin-top: .95rem;
        }
        .overview-step {
            background: rgba(240,246,252,0.92);
            border: 1px solid rgba(81,127,164,0.12);
            border-radius: .9rem;
            padding: .8rem .85rem;
        }
        .overview-step-no {
            font-size: .72rem;
            font-weight: 800;
            letter-spacing: .06em;
            text-transform: uppercase;
            color: #517fa4;
            margin-bottom: .25rem;
        }
        .overview-step-title {
            font-size: .9rem;
            font-weight: 700;
            color: var(--brand-dark);
            margin-bottom: .2rem;
        }
        .overview-step-note {
            font-size: .8rem;
            color: #6b7d91;
            line-height: 1.4;
            margin: 0;
        }
        .overview-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: .95rem;
        }
        .overview-panel {
            background: rgba(255,255,255,0.92);
            border: 1px solid rgba(81,127,164,0.14);
            border-radius: 1rem;
            box-shadow: 0 8px 22px rgba(33,57,93,0.04);
            padding: 1rem;
        }
        .overview-panel-head {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: .75rem;
            margin-bottom: .85rem;
        }
        .overview-panel-title {
            font-size: .96rem;
            font-weight: 800;
            color: var(--brand-dark);
            margin: 0 0 .2rem;
        }
        .overview-panel-note {
            font-size: .82rem;
            color: #6b7d91;
            line-height: 1.45;
            margin: 0;
        }
        .overview-status-pill {
            flex: 0 0 auto;
            border-radius: 999px;
            padding: .28rem .6rem;
            font-size: .74rem;
            font-weight: 700;
            background: #eef3f8;
            color: #516273;
            border: 1px solid rgba(81,127,164,0.12);
        }
        .overview-status-pill.ok {
            background: #eaf6ef;
            color: #21613b;
        }
        .overview-status-pill.warn {
            background: #fff4db;
            color: #8a6500;
        }
        .overview-status-pill.alert {
            background: #fdeaea;
            color: #8a2930;
        }
        .overview-kpis {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: .7rem;
            margin-bottom: .9rem;
        }
        .overview-kpi {
            background: #f7fafd;
            border: 1px solid rgba(81,127,164,0.08);
            border-radius: .85rem;
            padding: .8rem .85rem;
        }
        .overview-kpi-label {
            font-size: .72rem;
            font-weight: 800;
            letter-spacing: .05em;
            text-transform: uppercase;
            color: #6b7d91;
            margin-bottom: .2rem;
        }
        .overview-kpi-value {
            font-size: 1.18rem;
            font-weight: 800;
            color: var(--brand-dark);
            line-height: 1.2;
        }
        .overview-kpi-meta {
            font-size: .76rem;
            color: #718398;
            margin-top: .2rem;
        }
        .overview-list {
            display: grid;
            gap: .55rem;
        }
        .overview-list-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: .75rem;
            padding: .55rem 0;
            border-top: 1px solid rgba(81,127,164,0.08);
        }
        .overview-list-row:first-child {
            border-top: 0;
            padding-top: 0;
        }
        .overview-list-label {
            font-size: .84rem;
            color: #5f7389;
        }
        .overview-list-value {
            text-align: right;
            font-size: .86rem;
            font-weight: 700;
            color: var(--brand-dark);
        }
        body.dark-mode .overview-hero,
        body.dark-mode .overview-panel,
        body.dark-mode .overview-step,
        body.dark-mode .overview-kpi {
            background: rgba(35,57,93,0.9);
            border-color: rgba(255,255,255,0.08);
        }
        body.dark-mode .overview-title,
        body.dark-mode .overview-step-title,
        body.dark-mode .overview-panel-title,
        body.dark-mode .overview-kpi-value,
        body.dark-mode .overview-list-value {
            color: #e6edf3;
        }
        body.dark-mode .overview-note,
        body.dark-mode .overview-step-note,
        body.dark-mode .overview-panel-note,
        body.dark-mode .overview-kpi-meta,
        body.dark-mode .overview-list-label,
        body.dark-mode .overview-kpi-label {
            color: #c3cfdb;
        }
        body.dark-mode .overview-status-pill {
            background: rgba(255,255,255,0.08);
            color: #d8e2ec;
            border-color: rgba(255,255,255,0.08);
        }
        @media (max-width: 768px) {
            .overview-kpis {
                grid-template-columns: 1fr;
            }
            .overview-panel-head,
            .overview-list-row {
                align-items: flex-start;
            }
            .overview-list-row {
                flex-direction: column;
            }
            .overview-list-value {
                text-align: left;
            }
        }
        .section-chip { display:inline-flex; align-items:center; gap:.45rem; padding:.35rem .7rem; border-radius:999px; font-size:.85rem; font-weight:600; }
        .section-chip.regular { background:#e8f7ef; color:#21613b; }
        .section-chip.special { background:#eaf4ff; color:#23517a; }
        .booklet-family-badge { font-size:.74rem; border-radius:999px; padding:.18rem .5rem; font-weight:700; }
        .booklet-family-badge.regular { background:#e8f7ef; color:#21613b; }
        .booklet-family-badge.special { background:#eaf4ff; color:#23517a; }
        .migration-status.ready { background:#e8f7ef; color:#21613b; }
        .migration-status.blocked { background:#fdeaea; color:#8a2930; }
        th { background: #eaf4ff; text-align: center; }
        td { vertical-align: middle; }
        .table-responsive { font-size: 0.94rem; line-height: 1.4; }
        .action-bar { margin-bottom: 1rem; display: flex; gap: 0.7rem; align-items: center; flex-wrap: wrap; padding: .8rem .9rem; background: rgba(255,255,255,0.72); border: 1px solid rgba(81, 127, 164, 0.12); border-radius: .9rem; }
        .action-bar .form-control, .action-bar .form-select { max-width: 240px; display: inline-block; }
        .foundation-note { background: #eef6ff; border: 1px solid rgba(81, 127, 164, 0.18); border-radius: 1rem; padding: .9rem 1rem; color: #36536f; line-height: 1.5; }
        .catalog-status-badge { font-size: .74rem; border-radius: 999px; padding: .18rem .55rem; font-weight: 700; text-transform: uppercase; letter-spacing: .03em; }
        .catalog-status-badge.active { background: #e8f7ef; color: #21613b; }
        .catalog-status-badge.non-active { background: #eef1f6; color: #536273; }
        .catalog-status-badge.full { background: #fff4db; color: #8a6500; }
        .catalog-status-badge.archived { background: #f3ebff; color: #6a44ad; }
        .catalog-visibility { font-size: .78rem; font-weight: 700; }
        .catalog-visibility.active { color: #21613b; }
        .catalog-visibility.inactive { color: #7a8796; }
        .catalog-form { min-width: 430px; }
        .catalog-form .form-select, .catalog-form .form-control { min-width: 0; }
        .catalog-save { white-space: nowrap; }
        .catalog-batch-tools { display:flex; gap:.5rem; align-items:center; flex-wrap:wrap; }
        .catalog-lock-badge { font-size:.72rem; border-radius:999px; padding:.18rem .5rem; font-weight:700; background:#fdeaea; color:#8a2930; display:none; }
        .catalog-lock-badge.active { display:inline-flex; align-items:center; gap:.3rem; }
        .catalog-row-locked { background: rgba(253, 234, 234, 0.45); }
        .catalog-tab-btn.active { box-shadow: inset 0 -2px 0 rgba(255,255,255,0.55); }
        .catalog-panel { display: none; }
        .catalog-panel.active { display: block; }
        .registry-scroll { max-height: 520px; overflow: auto; }
        .activity-scroll { max-height: 560px; overflow: auto; }
        .void-form textarea { min-height: 110px; }
        .void-hero {
            background: linear-gradient(135deg, #fff4f4, #fff9f2);
            border: 1px solid rgba(180, 35, 24, 0.14);
            border-radius: .95rem;
            padding: .95rem 1rem;
            margin-bottom: 1rem;
        }
        .void-hero-title {
            font-size: 1rem;
            font-weight: 700;
            color: #9f1f1f;
            margin-bottom: .2rem;
        }
        .void-hero-note {
            font-size: .86rem;
            color: #7d4a4a;
            margin: 0;
            line-height: 1.45;
        }
        .void-form .form-label { font-weight: 700; color: var(--brand-dark); }
        .void-inline-note { font-size: .78rem; color: #6f7f90; margin-top: .35rem; }
        .void-submit-wrap { display: flex; align-items: end; }
        .void-submit-wrap .btn { min-height: 44px; }
        body.dark-mode .void-hero {
            background: rgba(122, 40, 40, 0.28);
            border-color: rgba(255,255,255,0.08);
        }
        body.dark-mode .void-hero-title { color: #ffd0d0; }
        body.dark-mode .void-hero-note,
        body.dark-mode .void-inline-note { color: #dec6c6; }
        .workspace-switcher { display: none; 
            display: flex;
            gap: .65rem;
            flex-wrap: wrap;
            margin-bottom: 1.25rem;
            padding: .85rem;
            background: rgba(255,255,255,0.82);
            border: 1px solid rgba(81, 127, 164, 0.16);
            border-radius: 1rem;
            box-shadow: 0 8px 22px rgba(33,57,93,0.05);
            backdrop-filter: blur(8px);
            position: sticky;
            top: 76px;
            z-index: 20;
        }
        .workspace-btn {
            border: 1px solid rgba(81, 127, 164, 0.22);
            background: #fff;
            color: var(--brand-dark);
            border-radius: 999px;
            padding: .7rem 1rem;
            min-width: 220px;
            text-align: left;
            transition: .18s ease;
            box-shadow: 0 4px 12px rgba(33,57,93,0.04);
        }
        .workspace-btn:hover,
        .workspace-btn:focus {
            border-color: rgba(81, 127, 164, 0.42);
            box-shadow: 0 8px 18px rgba(33,57,93,0.08);
        }
        .workspace-btn.active {
            background: linear-gradient(135deg, #355c7d, #517fa4);
            color: #fff;
            border-color: transparent;
            box-shadow: 0 10px 24px rgba(33,57,93,0.18);
        }
        .workspace-btn-title {
            display: block;
            font-size: .9rem;
            font-weight: 700;
            line-height: 1.2;
            margin-bottom: .15rem;
        }
        .workspace-btn-note {
            display: block;
            font-size: .76rem;
            opacity: .82;
            line-height: 1.25;
        }
        .workspace-panel { display: block; }
        .workspace-panel.active { display: block; }
        .section-card {
            background: rgba(255,255,255,0.92);
            border: 1px solid rgba(81, 127, 164, 0.14);
            border-radius: 1rem;
            box-shadow: 0 8px 22px rgba(33,57,93,0.05);
            overflow: hidden;
        }
        .section-card .card-header {
            border-bottom: 1px solid rgba(81, 127, 164, 0.12);
            font-weight: 700;
            letter-spacing: .01em;
        }
        .workspace-intro {
            background: linear-gradient(135deg, #eff6fd, #f9fbff);
            border: 1px solid rgba(81, 127, 164, 0.14);
            border-radius: 1rem;
            padding: .95rem 1.05rem;
            color: #3e5770;
            margin-bottom: 1rem;
        }
        .workspace-intro-title {
            font-size: 1rem;
            font-weight: 700;
            color: var(--brand-dark);
            margin-bottom: .25rem;
        }
        .workspace-intro-note {
            font-size: .87rem;
            color: #60758b;
            margin: 0;
        }
        .summary-cluster {
            background: rgba(255,255,255,0.5);
            border: 1px solid rgba(81, 127, 164, 0.08);
            border-radius: 1rem;
            padding: .95rem;
            margin-bottom: 1.1rem;
        }
        .summary-cluster:last-child { margin-bottom: 0; }
        body.dark-mode .workspace-switcher,
        body.dark-mode .section-card,
        body.dark-mode .summary-cluster,
        body.dark-mode .workspace-btn {
            background: rgba(35,57,93,0.92);
            color: #e6edf3;
            border-color: rgba(255,255,255,0.08);
        }
        body.dark-mode .workspace-btn.active {
            background: linear-gradient(135deg, #32506d, #517fa4);
        }
        body.dark-mode .workspace-intro {
            background: rgba(44,78,120,0.35);
            color: #d8e2ec;
            border-color: rgba(255,255,255,0.08);
        }
        body.dark-mode .workspace-intro-title { color: #e6edf3; }
        body.dark-mode .workspace-intro-note { color: #c3cfdb; }
        body.dark-mode .action-bar { background: rgba(35,57,93,0.48); border-color: rgba(255,255,255,0.08); }
        .section-block { margin-bottom: 1.8rem; }
        .section-block:last-of-type { margin-bottom: 0; }
        .section-block-head { margin-bottom: .85rem; }
        .section-block-note { max-width: 900px; line-height: 1.5; }
        .card-body.table-responsive { padding: 1rem; }
        .table > :not(caption) > * > * { padding: .72rem .65rem; }
        .toolbar-note { font-size: .82rem; color: #60758b; margin: 0 0 .55rem; }
        .table-focus-title { font-size: .84rem; font-weight: 700; letter-spacing: .03em; text-transform: uppercase; color: #517fa4; margin-bottom: .45rem; }
        .card-header-collapsible { padding: 0; }
        .card-collapse-toggle {
            width: 100%;
            border: 0;
            background: transparent;
            color: inherit;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: .9rem;
            text-align: left;
            padding: .9rem 1rem;
            font: inherit;
        }
        .card-collapse-toggle:focus-visible {
            outline: 2px solid rgba(255,255,255,0.65);
            outline-offset: -2px;
        }
        .card-header-label {
            display: inline-flex;
            align-items: center;
            gap: .45rem;
            flex: 1 1 auto;
        }
        .collapse-indicator {
            flex: 0 0 auto;
            transition: transform .18s ease;
            opacity: .9;
        }
        .card-collapse-toggle[aria-expanded="true"] .collapse-indicator {
            transform: rotate(180deg);
        }
        body.dark-mode .toolbar-note { color: #c3cfdb; }
        body.dark-mode .table-focus-title { color: #9fc1e3; }
        @media (max-width: 768px) {
            .action-bar { padding: .7rem; }
            .action-bar .form-control, .action-bar .form-select { max-width: 100%; width: 100%; }
            .registry-scroll, .activity-scroll { max-height: none; }
            .card-body.table-responsive { padding: .85rem; }
        }
        .dashboard-btn-bottom { position: fixed; left: 28px; bottom: 28px; z-index: 1060; background: #e7f0fd; color: #517fa4; border: 2px solid #bcdfff; box-shadow: 0 5px 16px rgba(33,57,93,0.13); border-radius: 50%; width: 58px; height: 58px; display: flex; align-items: center; justify-content: center; font-size: 1.55em; cursor: pointer; transition: background 0.2s, color 0.2s; text-decoration: none; }
        .dashboard-btn-bottom:hover, .dashboard-btn-bottom:focus { background: #fff2b3; color: #517fa4; border-color: #ffe599; }
        @media print { .action-bar, .navbar, .dashboard-header, .dashboard-btn-bottom, .footer, .void-form { display: none !important; } }
    </style>
</head>
<body>
<?php render_admin_nav('settings', true); ?>

<div class="dashboard-header">
    <img src="<?= htmlspecialchars($schoolLogo) ?>" alt="School Logo" class="mb-2 rounded shadow-sm">
    <h1><?= htmlspecialchars($schoolName) ?></h1>
</div>

<div class="container-fluid py-4">
    <div class="report-header">
        <h2><i class="fas fa-receipt"></i> Receipt & Booklet Registry Dashboard</h2>
        <div class="lead text-muted">Operational view of official receipt usage, void reasons, and reusable receipt history.</div>
    </div>

    <?php if ($pageMessage !== ''): ?><div class="alert alert-success"><?= htmlspecialchars($pageMessage) ?></div><?php endif; ?>
    <?php if ($pageError !== ''): ?><div class="alert alert-danger"><?= htmlspecialchars($pageError) ?></div><?php endif; ?>

    <div class="section-block">
        <div class="section-block-head">
            <div>
                <div class="section-block-kicker">Start Here</div>
                <h3 class="section-block-title">Overview</h3>
                <p class="section-block-note">Quick totals, current booklet pulse, next receipt numbers, and warning signals in one place.</p>
            </div>
        </div>
        <div class="section-stack overview-shell">

    <div class="overview-hero">
        <div class="overview-eyebrow">Quick Read</div>
        <div class="overview-title">Start with the next receipt, then confirm the active booklet, then review warnings.</div>
        <p class="overview-note">This overview is meant to answer three questions fast: what number gets used next, which booklet is currently live, and whether anything needs correction before payment work continues.</p>
        <div class="overview-flow">
            <div class="overview-step">
                <div class="overview-step-no">Step 1</div>
                <div class="overview-step-title">Check next receipt</div>
                <p class="overview-step-note">Use the next regular and S receipt numbers as the first cashier reference.</p>
            </div>
            <div class="overview-step">
                <div class="overview-step-no">Step 2</div>
                <div class="overview-step-title">Confirm active booklet</div>
                <p class="overview-step-note">Make sure the current live booklet matches the receipt family you are about to use.</p>
            </div>
            <div class="overview-step">
                <div class="overview-step-no">Step 3</div>
                <div class="overview-step-title">Review warnings</div>
                <p class="overview-step-note">Only go deeper when there are voids, mismatches, legacy migration rows, or blocked states.</p>
            </div>
        </div>
    </div>

    <div class="overview-grid">
        <div class="overview-panel">
            <div class="overview-panel-head">
                <div>
                    <h3 class="overview-panel-title">1. Live Receipts</h3>
                    <p class="overview-panel-note">These are the numbers your team will feel immediately during payment entry.</p>
                </div>
                <span class="overview-status-pill">Live</span>
            </div>
            <div class="overview-kpis">
                <div class="overview-kpi">
                    <div class="overview-kpi-label">Next Regular Receipt</div>
                    <div class="overview-kpi-value"><?= number_format((int) $nextRegularReceipt) ?></div>
                    <div class="overview-kpi-meta">Use this for the next regular OR.</div>
                </div>
                <div class="overview-kpi">
                    <div class="overview-kpi-label">Next S Receipt</div>
                    <div class="overview-kpi-value"><?= number_format((int) $nextSpecialReceipt) ?></div>
                    <div class="overview-kpi-meta">Use this for the next special OR.</div>
                </div>
            </div>
            <div class="overview-list">
                <div class="overview-list-row"><div class="overview-list-label">Registry entries recorded</div><div class="overview-list-value"><?= number_format((int) ($summaryRow['total_registry'] ?? 0)) ?></div></div>
                <div class="overview-list-row"><div class="overview-list-label">Active receipts still live</div><div class="overview-list-value"><?= number_format((int) ($summaryRow['active_receipts'] ?? 0)) ?></div></div>
                <div class="overview-list-row"><div class="overview-list-label">Voided but reusable receipts</div><div class="overview-list-value"><?= number_format((int) ($summaryRow['voided_receipts'] ?? 0)) ?></div></div>
            </div>
        </div>

        <div class="overview-panel">
            <div class="overview-panel-head">
                <div>
                    <h3 class="overview-panel-title">2. Active Booklets</h3>
                    <p class="overview-panel-note">This is the quick booklet checkpoint before you manage visibility or switch to the next range.</p>
                </div>
                <span class="overview-status-pill <?= ((int) ($bookletMonitoringSummary['near_full_count'] ?? 0) > 0 || (int) ($bookletMonitoringSummary['full_count'] ?? 0) > 0) ? 'warn' : 'ok' ?>"><?= ((int) ($bookletMonitoringSummary['near_full_count'] ?? 0) > 0 || (int) ($bookletMonitoringSummary['full_count'] ?? 0) > 0) ? 'Check' : 'Ready' ?></span>
            </div>
            <div class="overview-kpis">
                <div class="overview-kpi">
                    <div class="overview-kpi-label">Current Regular Booklet</div>
                    <div class="overview-kpi-value"><?= htmlspecialchars($regularActiveSnapshot['current']['display_label'] ?? 'N/A') ?></div>
                    <div class="overview-kpi-meta">Next receipt: <?= !empty($regularActiveSnapshot['current']['next_receipt']) ? number_format((int) $regularActiveSnapshot['current']['next_receipt']) : 'Full' ?></div>
                </div>
                <div class="overview-kpi">
                    <div class="overview-kpi-label">Current S Booklet</div>
                    <div class="overview-kpi-value"><?= htmlspecialchars($specialActiveSnapshot['current']['display_label'] ?? 'N/A') ?></div>
                    <div class="overview-kpi-meta">Next receipt: <?= !empty($specialActiveSnapshot['current']['next_receipt']) ? number_format((int) $specialActiveSnapshot['current']['next_receipt']) : 'Full' ?></div>
                </div>
            </div>
            <div class="overview-list">
                <div class="overview-list-row"><div class="overview-list-label">Next regular booklet queued</div><div class="overview-list-value"><?= htmlspecialchars($regularActiveSnapshot['next']['display_label'] ?? 'N/A') ?></div></div>
                <div class="overview-list-row"><div class="overview-list-label">Next S booklet queued</div><div class="overview-list-value"><?= htmlspecialchars($specialActiveSnapshot['next']['display_label'] ?? 'N/A') ?></div></div>
                <div class="overview-list-row"><div class="overview-list-label">Payment-visible booklets</div><div class="overview-list-value"><?= number_format((int) ($paymentVisibleBookletSummary['total_visible'] ?? 0)) ?></div></div>
                <div class="overview-list-row"><div class="overview-list-label">Booklets near full / fully used</div><div class="overview-list-value"><?= number_format((int) ($bookletMonitoringSummary['near_full_count'] ?? 0)) ?> near full, <?= number_format((int) ($bookletMonitoringSummary['full_count'] ?? 0)) ?> full</div></div>
                <div class="overview-list-row"><div class="overview-list-label">Observed live booklets matched to catalog</div><div class="overview-list-value"><?= number_format((int) $catalogObservedCount) ?> matched, <?= number_format((int) $catalogUnmatchedCount) ?> unmatched</div></div>
            </div>
        </div>

        <div class="overview-panel">
            <div class="overview-panel-head">
                <div>
                    <h3 class="overview-panel-title">3. Exceptions & Review</h3>
                    <p class="overview-panel-note">Only drill into Review & Repair below when one of these numbers stops looking normal.</p>
                </div>
                <span class="overview-status-pill <?= $validationNeedsReview ? 'alert' : 'ok' ?>"><?= $validationNeedsReview ? 'Needs Review' : 'Clean' ?></span>
            </div>
            <div class="overview-kpis">
                <div class="overview-kpi">
                    <div class="overview-kpi-label">Reusable Voided</div>
                    <div class="overview-kpi-value"><?= number_format((int) ($voidedSummary['total_voided'] ?? 0)) ?></div>
                    <div class="overview-kpi-meta">Last void: <?= !empty($voidedSummary['last_voided_at']) ? htmlspecialchars(date('n/j/Y g:i A', strtotime($voidedSummary['last_voided_at']))) : 'N/A' ?></div>
                </div>
                <div class="overview-kpi">
                    <div class="overview-kpi-label">Payment Mismatches</div>
                    <div class="overview-kpi-value"><?= number_format((int) $validationSummary['active_payments_missing_registry']) ?></div>
                    <div class="overview-kpi-meta">Registry missing payment: <?= number_format((int) $validationSummary['registry_missing_payment']) ?></div>
                </div>
            </div>
            <div class="overview-list">
                <div class="overview-list-row"><div class="overview-list-label">Voided regular / S receipts</div><div class="overview-list-value"><?= number_format((int) ($voidedSummary['regular_voided'] ?? 0)) ?> regular, <?= number_format((int) ($voidedSummary['special_voided'] ?? 0)) ?> S</div></div>
                <div class="overview-list-row"><div class="overview-list-label">Legacy S receipts waiting for cleanup</div><div class="overview-list-value"><?= number_format((int) ($legacyMigrationSummary['legacy_count'] ?? 0)) ?></div></div>
                <div class="overview-list-row"><div class="overview-list-label">Guided migration ready / blocked</div><div class="overview-list-value"><?= number_format((int) ($legacyMigrationSummary['ready_count'] ?? 0)) ?> ready, <?= number_format((int) ($legacyMigrationSummary['blocked_count'] ?? 0)) ?> blocked</div></div>
                <div class="overview-list-row"><div class="overview-list-label">Old-payment registry mismatches</div><div class="overview-list-value"><?= number_format((int) $validationSummary['old_payments_missing_registry']) ?> missing registry, <?= number_format((int) $validationSummary['registry_missing_old_payment']) ?> missing payment</div></div>
            </div>
        </div>
    </div>

</div>
    </div>

    <div class="section-block">
        <div class="section-block-head">
            <div>
                <div class="section-block-kicker">Daily Operations</div>
                <h3 class="section-block-title">Booklet Management</h3>
                <p class="section-block-note">Register new booklets, manage visibility, and monitor regular and S booklet usage without touching the registry history flow.</p>
            </div>
        </div>
        <div class="card shadow-sm mb-4 section-card">
            <div class="card-header bg-primary text-light"><i class="fas fa-layer-group"></i> Booklet Management</div>
        <div class="card-body">
            <div class="foundation-note mb-4">
                This page now manages the booklet lifecycle directly. Status and payment visibility changes here immediately affect which booklets appear in payment entry, while receipt history and registry records remain preserved.
            </div>
            <div class="card border-0 shadow-sm mb-4" style="background:#f8fbff;">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
                        <div>
                            <div class="fw-semibold text-primary">Add New Booklet Safely</div>
                            <div class="text-muted small">Register a future booklet without touching existing receipt history. New booklets can stay hidden until needed.</div>
                        </div>
                    </div>
                    <form method="post" class="row g-3 align-items-end" onsubmit="return confirm('Register this new receipt booklet?');">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
                        <div class="col-md-2">
                            <label class="form-label fw-semibold">Type</label>
                            <select name="new_booklet_type" class="form-select" required>
                                <option value="regular">Regular</option>
                                <option value="special">S</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label fw-semibold">Number</label>
                            <input type="number" name="new_display_number" class="form-control" min="1" required>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label fw-semibold">Status</label>
                            <select name="new_booklet_status" class="form-select" required>
                                <?php foreach (receipt_booklet_registry_status_options() as $statusValue => $statusLabel): ?>
                                    <option value="<?= htmlspecialchars($statusValue) ?>" <?= $statusValue === 'active' ? 'selected' : '' ?>><?= htmlspecialchars($statusLabel) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <div class="form-check mt-4">
                                <input class="form-check-input" type="checkbox" name="new_booklet_active" value="1" id="new_booklet_active" checked>
                                <label class="form-check-label" for="new_booklet_active">Show in payment</label>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Notes</label>
                            <input type="text" name="new_booklet_notes" class="form-control" maxlength="255" placeholder="Optional note">
                        </div>
                        <div class="col-md-1 d-grid">
                            <button type="submit" name="create_booklet_registry_submit" class="btn btn-primary">Add</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="foundation-note mb-3">
                The top `Overview` section already carries the booklet totals. This workspace stays focused on actions: monitoring, status changes, payment visibility, and next-booklet handoff. `Near Full` means 10 or fewer usable receipt numbers remain in that booklet.
            </div>
            <div class="action-bar">
                <button type="button" class="btn btn-primary btn-sm catalog-tab-btn active" data-tab-target="regular">Regular Booklets</button>
                <button type="button" class="btn btn-primary btn-sm catalog-tab-btn" data-tab-target="special">S Booklets</button>
            </div>

            <?php
            $catalogPanels = [
                'regular' => ['label' => 'Regular Booklets', 'rows' => $regularBookletCatalogRows],
                'special' => ['label' => 'S Booklets', 'rows' => $specialBookletCatalogRows],
            ];
            ?>
            <?php foreach ($catalogPanels as $panelKey => $panelMeta): ?>
                <div class="catalog-panel <?= $panelKey === 'regular' ? 'active' : '' ?>" data-catalog-panel="<?= htmlspecialchars($panelKey) ?>">
                    <div class="action-bar">
                        <input type="text" class="form-control" data-catalog-search="<?= htmlspecialchars($panelKey) ?>" placeholder="Search <?= htmlspecialchars($panelMeta['label']) ?> or range">
                        <select class="form-select" data-catalog-status="<?= htmlspecialchars($panelKey) ?>">
                            <option value="">Status: All</option>
                            <option value="active">Active</option>
                            <option value="non_active">Non-active</option>
                            <option value="full">Full</option>
                            <option value="archived">Archived</option>
                        </select>
                    </div>
                    <form method="post" data-catalog-form="<?= htmlspecialchars($panelKey) ?>" onsubmit="return confirm('Save all <?= htmlspecialchars($panelMeta['label'], ENT_QUOTES) ?> changes now?');">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
                            <div class="catalog-batch-tools">
                                <button type="button" class="btn btn-primary btn-sm" data-catalog-check-all="<?= htmlspecialchars($panelKey) ?>">Select Visible</button>
                                <button type="button" class="btn btn-danger btn-sm" data-catalog-lock-checked="<?= htmlspecialchars($panelKey) ?>">Lock Selected</button>
                                <button type="button" class="btn btn-outline-secondary btn-sm" data-catalog-unlock-all="<?= htmlspecialchars($panelKey) ?>">Unlock Rows</button>
                            </div>
                            <div class="d-flex align-items-center gap-2">
                                <span class="badge bg-info text-dark" data-catalog-changed-count="<?= htmlspecialchars($panelKey) ?>">0 changed</span>
                                <button type="submit" name="update_booklet_registry_submit" class="btn btn-primary catalog-save">Save <?= htmlspecialchars($panelMeta['label']) ?></button>
                            </div>
                        </div>
                        <div class="table-responsive registry-scroll">
                            <table class="table table-bordered table-hover align-middle">
                                <thead>
                                    <tr>
                                        <th>Type</th>
                                        <th>Booklet</th>
                                        <th>Receipt Range</th>
                                        <th>Monitoring</th>
                                        <th>Status</th>
                                        <th>Visible In Payment</th>
                                        <th>Storage No</th>
                                        <th>Manage</th>
                                    </tr>
                                </thead>
                                <tbody data-catalog-body="<?= htmlspecialchars($panelKey) ?>">
                                    <?php if ($panelMeta['rows']): ?>
                                        <?php foreach ($panelMeta['rows'] as $catalogRow): ?>
                                            <?php
                                            $catalogStatus = (string) ($catalogRow['status'] ?? 'active');
                                            $catalogStatusClass = str_replace('_', '-', $catalogStatus);
                                            $storageNumber = (int) $catalogRow['storage_number'];
                                            $monitoring = $bookletMonitoringMap[$storageNumber] ?? [];
                                            $nextBooklet = $nextBookletByStorage[$storageNumber] ?? null;
                                            $remainingCount = (int) ($monitoring['remaining_count'] ?? 0);
                                            $nextAvailable = $monitoring['next_available'] ?? null;
                                            $lastUsedReceipt = $monitoring['last_used_receipt'] ?? null;
                                            $lastUsedAt = $monitoring['last_used_at'] ?? null;
                                            $monitorStateClass = !empty($monitoring['fully_used'])
                                                ? 'danger'
                                                : (!empty($monitoring['near_full']) ? 'warning text-dark' : 'success');
                                            $monitorStateLabel = !empty($monitoring['fully_used'])
                                                ? 'Full'
                                                : (!empty($monitoring['near_full']) ? 'Near Full' : 'Healthy');
                                            ?>
                                            <tr data-catalog-status="<?= htmlspecialchars($catalogStatus) ?>" data-locked="0">
                                                <td class="text-center">
                                                    <span class="booklet-family-badge <?= htmlspecialchars((string) $catalogRow['booklet_type']) ?>">
                                                        <?= ($catalogRow['booklet_type'] ?? '') === 'special' ? 'S' : 'Regular' ?>
                                                    </span>
                                                </td>
                                                <td class="text-center fw-semibold"><?= htmlspecialchars((string) $catalogRow['booklet_code']) ?></td>
                                                <td class="text-center"><?= number_format((int) $catalogRow['range_start']) ?> - <?= number_format((int) $catalogRow['range_end']) ?></td>
                                                <td>
                                                    <div class="small fw-semibold mb-1">
                                                        <span class="badge bg-<?= $monitorStateClass ?>"><?= htmlspecialchars($monitorStateLabel) ?></span>
                                                        <span class="ms-2 text-muted">Remaining: <?= number_format($remainingCount) ?></span>
                                                    </div>
                                                    <div class="small text-muted">Next: <?= $nextAvailable !== null ? number_format((int) $nextAvailable) : 'None' ?></div>
                                                    <div class="small text-muted">Last: <?= $lastUsedReceipt !== null ? number_format((int) $lastUsedReceipt) : 'None' ?></div>
                                                    <div class="small text-muted"><?= $lastUsedAt ? htmlspecialchars(date('n/j/Y g:i A', strtotime((string) $lastUsedAt))) : 'No usage yet' ?></div>
                                                    <div class="d-flex flex-wrap gap-2 mt-2">
                                                        <?php if ($catalogStatus !== 'full' && $catalogStatus !== 'archived'): ?>
                                                            <form method="post" class="d-inline" onsubmit="return confirm('Mark booklet <?= htmlspecialchars((string) $catalogRow['booklet_code'], ENT_QUOTES) ?> as full and hide it from payment entry?');">
                                                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
                                                                <input type="hidden" name="smart_storage_number" value="<?= $storageNumber ?>">
                                                                <button type="submit" name="mark_full_booklet_submit" class="btn btn-sm btn-outline-danger">Mark Full</button>
                                                            </form>
                                                        <?php endif; ?>
                                                        <?php if ($nextBooklet): ?>
                                                            <form method="post" class="d-inline" onsubmit="return confirm('Activate next booklet <?= htmlspecialchars((string) ($nextBooklet['booklet_code'] ?? ''), ENT_QUOTES) ?> for payment entry?');">
                                                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
                                                                <input type="hidden" name="smart_storage_number" value="<?= $storageNumber ?>">
                                                                <button type="submit" name="activate_next_booklet_submit" class="btn btn-sm btn-outline-primary">Activate Next</button>
                                                            </form>
                                                        <?php endif; ?>
                                                        <?php if ($catalogStatus !== 'full' && $catalogStatus !== 'archived'): ?>
                                                            <form method="post" class="d-inline" onsubmit="return confirm('Make booklet <?= htmlspecialchars((string) $catalogRow['booklet_code'], ENT_QUOTES) ?> the visible payment booklet for this type? Other visible <?= ($catalogRow['booklet_type'] ?? '') === 'special' ? 'S' : 'regular' ?> booklets will be hidden.');">
                                                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
                                                                <input type="hidden" name="smart_storage_number" value="<?= $storageNumber ?>">
                                                                <button type="submit" name="set_visible_booklet_submit" class="btn btn-sm btn-outline-success">Make Preferred</button>
                                                            </form>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                <td class="text-center"><span class="catalog-status-badge <?= htmlspecialchars($catalogStatusClass) ?>"><?= htmlspecialchars(ucwords(str_replace('_', ' ', $catalogStatus))) ?></span></td>
                                                <td class="text-center">
                                                    <span class="catalog-visibility <?= (int) ($catalogRow['is_active'] ?? 0) === 1 ? 'active' : 'inactive' ?>">
                                                        <?= (int) ($catalogRow['is_active'] ?? 0) === 1 ? 'Visible' : 'Hidden' ?>
                                                    </span>
                                                </td>
                                                <td class="text-center"><?= number_format($storageNumber) ?></td>
                                                <td>
                                                    <input type="hidden" name="storage_numbers[]" value="<?= $storageNumber ?>" data-storage-number>
                                                    <div class="row g-2 align-items-center catalog-form">
                                                        <div class="col-12 col-md-4">
                                                            <select name="booklet_status[<?= $storageNumber ?>]" class="form-select form-select-sm" data-booklet-status required>
                                                                <?php foreach (receipt_booklet_registry_status_options() as $statusValue => $statusLabel): ?>
                                                                    <option value="<?= htmlspecialchars($statusValue) ?>" <?= $catalogStatus === $statusValue ? 'selected' : '' ?>><?= htmlspecialchars($statusLabel) ?></option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-12 col-md-3">
                                                            <div class="form-check small">
                                                                <input class="form-check-input" type="checkbox" name="booklet_active[<?= $storageNumber ?>]" value="1" id="booklet_active_<?= $storageNumber ?>" data-booklet-active <?= (int) ($catalogRow['is_active'] ?? 0) === 1 ? 'checked' : '' ?>>
                                                                <label class="form-check-label" for="booklet_active_<?= $storageNumber ?>">Show</label>
                                                            </div>
                                                        </div>
                                                        <div class="col-12 col-md-5">
                                                            <input type="text" name="booklet_notes[<?= $storageNumber ?>]" class="form-control form-control-sm" maxlength="255" placeholder="Note or reason" data-booklet-notes value="<?= htmlspecialchars((string) ($catalogRow['notes'] ?? '')) ?>">
                                                        </div>
                                                        <div class="col-12">
                                                            <span class="catalog-lock-badge" data-lock-badge><i class="fas fa-lock"></i> Locked from Check All</span>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr><td colspan="7" class="text-center text-muted">No <?= htmlspecialchars($panelMeta['label']) ?> found.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="d-flex justify-content-end mt-3">
                            <div class="d-flex align-items-center gap-2">
                                <span class="badge bg-info text-dark" data-catalog-changed-count="<?= htmlspecialchars($panelKey) ?>">0 changed</span>
                                <button type="submit" name="update_booklet_registry_submit" class="btn btn-primary catalog-save">Save <?= htmlspecialchars($panelMeta['label']) ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    </div>

    <div class="section-block">
        <div class="section-block-head">
            <div>
                <div class="section-block-kicker">Admin Review</div>
                <h3 class="section-block-title">Review & Repair</h3>
                <p class="section-block-note">Legacy cleanup, mismatch review, and controlled correction tools live here so they stay separate from normal daily booklet work.</p>
            </div>
        </div>
        <div class="workspace-intro">
            <div class="workspace-intro-title">Quick correction first, deeper review after.</div>
            <p class="workspace-intro-note">If you already know a live receipt must be voided, use the top action card below. Integrity review and legacy cleanup stay available right under it for follow-up checking.</p>
        </div>

        <?php if ($currentRole === 'Super Administrator'): ?>
        <div class="summary-cluster">
            <div class="summary-section-header">
                <h3 class="summary-section-title">Controlled Admin Action</h3>
                <p class="summary-section-note">Use this first only when the live receipt entry itself needs correction and the history must stay preserved.</p>
            </div>
            <div class="card section-card mb-4 void-form">
                <div class="card-header bg-danger text-light">
                    <i class="fas fa-ban"></i> Void Receipt
                </div>
                <div class="card-body">
                    <div class="void-hero">
                        <div class="void-hero-title">Fast correction for a single receipt</div>
                        <p class="void-hero-note">Enter the receipt number, add the booklet if needed, then write a clear reason so the reuse trail stays understandable later.</p>
                    </div>
                    <form method="post" class="row g-3">
                        <?= csrf_input() ?>
                        <div class="col-lg-4 col-md-6">
                            <label class="form-label">Receipt No</label>
                            <input type="number" name="receipt_no" class="form-control form-control-lg" min="1" value="" placeholder="Enter receipt number" required>
                            <div class="void-inline-note">Required. Use the exact OR number you want to void.</div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <label class="form-label">Booklet No</label>
                            <input type="text" name="booklet_no" class="form-control form-control-lg" value="" placeholder="230 or S1">
                            <div class="void-inline-note">Optional if the receipt number is unique. Add it for faster matching.</div>
                        </div>
                        <div class="col-lg-4 void-submit-wrap">
                            <button type="submit" name="void_receipt_submit" class="btn btn-danger btn-lg w-100">
                                <i class="fas fa-ban"></i> Void Receipt Now
                            </button>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Void Reason</label>
                            <textarea name="void_reason" class="form-control" placeholder="Example: kulang ang payment entry, corrected and reused later" required></textarea>
                            <div class="void-inline-note">State what happened and why the receipt is being reopened for safe reuse.</div>
                        </div>
                    </form>
                    <div class="form-text mt-3">Voided receipts remain reusable in your current workflow, but the void reason and reuse history are preserved.</div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="summary-cluster">
            <div class="summary-section-header">
                <h3 class="summary-section-title">Integrity Review</h3>
                <p class="summary-section-note">Check mismatches here before running any repair or orphan-void action on live receipt records.</p>
            </div>
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-danger text-light"><i class="fas fa-triangle-exclamation"></i> Validation & Repair Review</div>
                <div class="card-body table-responsive registry-scroll">
                    <p class="text-muted mb-3">These are detected receipt integrity issues. This panel is intentionally review-first. It flags what needs attention before any manual repair work is done.</p>
                    <div class="mb-3 d-flex gap-2 flex-wrap">
                        <span class="section-chip regular"><i class="fas fa-link-slash"></i> Active payment rows missing registry: <?= number_format((int) $validationSummary['active_payments_missing_registry']) ?></span>
                        <span class="section-chip special"><i class="fas fa-unlink"></i> Registry rows missing payment: <?= number_format((int) $validationSummary['registry_missing_payment']) ?></span>
                        <span class="section-chip regular"><i class="fas fa-archive"></i> Old payment rows missing registry: <?= number_format((int) $validationSummary['old_payments_missing_registry']) ?></span>
                        <span class="section-chip special"><i class="fas fa-box-open"></i> Registry rows missing old payment: <?= number_format((int) $validationSummary['registry_missing_old_payment']) ?></span>
                    </div>
                    <table class="table table-bordered table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Issue</th>
                                <th>Booklet</th>
                                <th>Receipt No</th>
                                <th>Record ID</th>
                                <th>Rows</th>
                                <th>When</th>
                                <th>Recommendation</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($validationRows): ?>
                                <?php foreach ($validationRows as $issue): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($issue['issue_label']) ?></td>
                                        <td class="text-center"><?= htmlspecialchars($issue['booklet_label']) ?></td>
                                        <td class="text-center"><?= number_format((int) $issue['receipt_no']) ?></td>
                                        <td class="text-center"><?= number_format((int) $issue['record_id']) ?></td>
                                        <td class="text-center"><?= (int) ($issue['payment_count'] ?? 0) > 0 ? number_format((int) $issue['payment_count']) : '<span class="text-muted">-</span>' ?></td>
                                        <td class="text-center"><?= !empty($issue['event_at']) ? htmlspecialchars(date('n/j/Y g:i A', strtotime($issue['event_at']))) : '<span class="text-muted">-</span>' ?></td>
                                        <td><?= htmlspecialchars($issue['recommendation']) ?></td>
                                        <td class="text-center">
                                            <?php if (!empty($issue['repairable'])): ?>
                                                <form method="post" class="d-inline">
                                                    <?= csrf_input() ?>
                                                    <input type="hidden" name="receipt_no" value="<?= (int) $issue['receipt_no'] ?>">
                                                    <input type="hidden" name="booklet_no" value="<?= htmlspecialchars($issue['booklet_label']) ?>">
                                                    <?php if ($issue['issue_key'] === 'active_payments_missing_registry'): ?>
                                                        <button type="submit" name="repair_missing_registry_submit" class="btn btn-sm btn-success">Repair</button>
                                                    <?php elseif ($issue['issue_key'] === 'registry_missing_payment'): ?>
                                                        <button type="submit" name="void_orphan_registry_submit" class="btn btn-sm btn-warning">Void Orphan</button>
                                                    <?php endif; ?>
                                                </form>
                                            <?php else: ?>
                                                <span class="text-muted">Manual Review</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="8" class="text-center text-muted">No validation anomalies detected.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="summary-cluster">
            <div class="summary-section-header">
                <h3 class="summary-section-title">Guided Cleanup</h3>
                <p class="summary-section-note">Legacy special-booklet rows stay separate here so historical cleanup does not get mixed with live payment corrections.</p>
            </div>
            <div class="card shadow-sm mb-4 section-card">
                <div class="card-header bg-warning text-dark"><i class="fas fa-shuffle"></i> Legacy S Receipt Migration Assistant</div>
            <div class="card-body table-responsive registry-scroll">
                <p class="text-muted mb-3">This panel shows special-booklet records that still use an old receipt range outside the current expected window. It does not migrate anything automatically. It gives you the safe target number the system would use for a guided cleanup later.</p>
                <table class="table table-bordered table-hover align-middle">
                    <thead>
                        <tr>
                            <th>Booklet</th>
                            <th>Current Receipt</th>
                            <th>Expected Range</th>
                            <th>Suggested Receipt</th>
                            <th>Status</th>
                            <th>Source</th>
                            <th>Used ID</th>
                            <th>Used At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($legacyMigrationRows): ?>
                            <?php foreach ($legacyMigrationRows as $legacy): ?>
                                <tr>
                                    <td class="text-center fw-semibold"><?= htmlspecialchars($legacy['booklet_label']) ?></td>
                                    <td class="text-center"><?= number_format((int) $legacy['current_receipt_no']) ?></td>
                                    <td class="text-center"><?= htmlspecialchars($legacy['expected_range']) ?></td>
                                    <td class="text-center">
                                        <?= $legacy['suggested_receipt_no'] !== null ? number_format((int) $legacy['suggested_receipt_no']) : '<span class="text-muted">No open slot</span>' ?>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge migration-status <?= $legacy['suggested_receipt_no'] !== null ? 'ready' : 'blocked' ?>">
                                            <?= htmlspecialchars($legacy['status']) ?>
                                        </span>
                                    </td>
                                    <td class="text-center"><?= htmlspecialchars((string) $legacy['used_by']) ?></td>
                                    <td class="text-center"><?= number_format((int) $legacy['used_id']) ?></td>
                                    <td class="text-center"><?= !empty($legacy['used_at']) ? htmlspecialchars(date('n/j/Y g:i A', strtotime($legacy['used_at']))) : '<span class="text-muted">-</span>' ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="8" class="text-center text-muted">No legacy special receipt rows need migration.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        </div>

    </div>

    <div class="section-block">
        <div class="section-block-head">
            <div>
                <div class="section-block-kicker">Trace & History</div>
                <h3 class="section-block-title">Registry Activity</h3>
                <p class="section-block-note">Review live booklet usage, registry state, and full receipt lifecycle history in one audit-friendly area.</p>
            </div>
        </div>
        <div class="card shadow-sm mb-4 section-card">
            <div class="card-header bg-info text-light"><i class="fas fa-book"></i> Booklet Activity Table</div>
        <div class="card-body table-responsive registry-scroll">
            <div class="table-focus-title">Booklet-level usage view</div>
            <p class="toolbar-note">Use this table for quick range lookup and last-use tracing. Detailed row state stays in the live register below.</p>
            <div class="action-bar"><input type="text" class="form-control" id="bookletSearchInput" placeholder="Search booklet code or receipt range"></div>
            <table class="table table-bordered table-hover align-middle" id="bookletTable">
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>Booklet</th>
                        <th>Receipt Range</th>
                        <th>Used</th>
                        <th>Voided</th>
                        <th>Available</th>
                        <th>Next Available</th>
                        <th>Last Used</th>
                    </tr>
                </thead>
                <tbody id="bookletTableBody">
                    <?php if ($bookletRows): ?>
                        <?php foreach ($bookletRows as $row): ?>
                            <tr data-booklet-family="<?= htmlspecialchars($row['booklet_family']) ?>">
                                <td class="text-center">
                                    <span class="booklet-family-badge <?= htmlspecialchars($row['booklet_family']) ?>">
                                        <?= $row['booklet_family'] === 'special' ? 'S' : 'Regular' ?>
                                    </span>
                                </td>
                                <td class="text-center fw-semibold"><?= htmlspecialchars($row['booklet_label']) ?></td>
                                <td class="text-center"><?= htmlspecialchars($row['range_label']) ?></td>
                                <td class="text-center"><?= number_format($row['used_count']) ?></td>
                                <td class="text-center"><?= number_format($row['voided_count']) ?></td>
                                <td class="text-center"><?= number_format($row['available_count']) ?></td>
                                <td class="text-center"><?= $row['next_available'] ? number_format((int) $row['next_available']) : '<span class="text-muted">Full</span>' ?></td>
                                <td class="text-center"><?= $row['last_used_at'] ? htmlspecialchars(date('n/j/Y g:i A', strtotime($row['last_used_at']))) : '<span class="text-muted">-</span>' ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="8" class="text-center text-muted">No receipt registry activity found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card shadow-sm mb-4">
        <div class="card-header bg-primary text-light"><i class="fas fa-clock-rotate-left"></i> Live Receipt Register</div>
        <div class="card-body table-responsive registry-scroll">
            <div class="table-focus-title">Receipt-level live state</div>
            <p class="toolbar-note">This is the main live register. Filter here when tracing active versus voided receipt rows across payment sources.</p>
            <div class="action-bar">
                <input type="text" class="form-control" id="activitySearchInput" placeholder="Search receipt no, booklet, or source">
                <select class="form-select" id="activityStatusFilter">
                    <option value="">Status: All</option>
                    <option value="active">Active</option>
                    <option value="voided">Voided</option>
                </select>
                <select class="form-select" id="activitySourceFilter">
                    <option value="">Source: All</option>
                    <option value="payments">payments</option>
                    <option value="old_student_payments">old_student_payments</option>
                    <option value="other_payment">other_payment</option>
                </select>
                <select class="form-select" id="activityBookletFamilyFilter">
                    <option value="">Type: All</option>
                    <option value="regular">Regular</option>
                    <option value="special">S</option>
                </select>
            </div>
            <table class="table table-bordered table-hover align-middle" id="activityTable">
                <thead>
                    <tr>
                        <th>Receipt No</th>
                        <th>Booklet</th>
                        <th>Source</th>
                        <th>Used ID</th>
                        <th>Status</th>
                        <th>Used At</th>
                        <th>Void Info</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="activityTableBody">
                    <?php if ($currentReceiptState): ?>
                        <?php foreach ($currentReceiptState as $entry): ?>
                            <tr data-status="<?= $entry['voided'] ? 'voided' : 'active' ?>" data-source="<?= htmlspecialchars($entry['used_by']) ?>" data-booklet-family="<?= htmlspecialchars($entry['booklet_family']) ?>">
                                <td class="text-center fw-semibold"><?= number_format((int) $entry['receipt_no']) ?></td>
                                <td class="text-center"><?= htmlspecialchars($entry['booklet_label']) ?></td>
                                <td class="text-center"><?= htmlspecialchars($entry['used_by']) ?></td>
                                <td class="text-center"><?= number_format((int) $entry['used_id']) ?></td>
                                <td class="text-center">
                                    <?php if ((int) $entry['voided'] === 1): ?>
                                        <span class="badge bg-danger">Voided</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center"><?= htmlspecialchars(date('n/j/Y g:i A', strtotime($entry['used_at']))) ?></td>
                                <td>
                                    <?php if ((int) $entry['voided'] === 1): ?>
                                        <?= htmlspecialchars((string) $entry['void_reason']) ?>
                                        <?php if (!empty($entry['voided_at'])): ?>
                                            <div class="text-muted small"><?= htmlspecialchars(date('n/j/Y g:i A', strtotime($entry['voided_at']))) ?></div>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <a href="?receipt_no=<?= (int) $entry['receipt_no'] ?>&booklet_no=<?= (int) $entry['booklet_no'] ?>#receipt-history-card" class="btn btn-sm btn-outline-primary">View History</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="8" class="text-center text-muted">No registry entries found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card shadow-sm" id="receipt-history-card">
        <div class="card-header bg-secondary text-light">
            <i class="fas fa-timeline"></i> <?= $selectedReceiptNo > 0 ? 'History for Receipt #' . number_format($selectedReceiptNo) . ($selectedBookletNo > 0 ? ' (' . htmlspecialchars(booklet_label_from_stored($selectedBookletNo)) . ')' : '') : 'Receipt Lifecycle Activity' ?>
        </div>
        <div class="card-body">
            <?php if ($selectedReceiptNo > 0): ?>
                <?php
                $historyStateLabel = 'Not found in live registry';
                $historyStateBadge = 'secondary';
                $historyStateNote = 'This receipt currently has no live registry row. History below may be from an older process or a repaired record.';
                if ($selectedReceiptEntry) {
                    if ((int) ($selectedReceiptEntry['voided'] ?? 0) === 1) {
                        $historyStateLabel = 'Currently voided';
                        $historyStateBadge = 'danger';
                        $historyStateNote = $selectedReceiptHasVoidHistory
                            ? 'The receipt is voided in the live registry, and the timeline below includes the recorded void event.'
                            : 'The receipt is voided in the live registry, but no explicit void event was recorded in history. This usually means the void happened before history logging covered that step.';
                    } else {
                        $historyStateLabel = 'Currently active';
                        $historyStateBadge = 'success';
                        $historyStateNote = 'This receipt is still active in the live registry. If there is no void event below, it has not been voided yet.';
                    }
                }
                ?>
                <div class="alert alert-light border d-flex flex-wrap justify-content-between align-items-start gap-3 mb-3" role="status">
                    <div>
                        <div class="text-uppercase text-muted small fw-semibold mb-1">Current Receipt State</div>
                        <div class="d-flex flex-wrap align-items-center gap-2 mb-1">
                            <span class="badge bg-<?= $historyStateBadge ?>"><?= htmlspecialchars($historyStateLabel) ?></span>
                            <?php if ($selectedReceiptEntry): ?>
                                <span class="text-muted small">Source: <?= htmlspecialchars((string) ($selectedReceiptEntry['used_by'] ?? '-')) ?></span>
                                <?php if ((int) ($selectedReceiptEntry['used_id'] ?? 0) > 0): ?>
                                    <span class="text-muted small">Linked ID: <?= number_format((int) $selectedReceiptEntry['used_id']) ?></span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <div class="text-muted small"><?= htmlspecialchars($historyStateNote) ?></div>
                    </div>
                    <?php if ($selectedReceiptEntry && (int) ($selectedReceiptEntry['voided'] ?? 0) === 1 && !empty($selectedReceiptEntry['voided_at'])): ?>
                        <div class="text-muted small text-md-end">
                            <div class="fw-semibold text-dark">Last voided</div>
                            <div><?= htmlspecialchars(date('n/j/Y g:i A', strtotime((string) $selectedReceiptEntry['voided_at']))) ?></div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <div class="table-responsive activity-scroll">
            <table class="table table-bordered table-hover align-middle">
                <thead>
                    <tr>
                        <th>Receipt No</th>
                        <th>Booklet</th>
                        <th>Action</th>
                        <th>Source</th>
                        <th>Used ID</th>
                        <th>State</th>
                        <th>Reason / Notes</th>
                        <th>Actor</th>
                        <th>When</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($receiptHistory): ?>
                        <?php foreach ($receiptHistory as $history): ?>
                            <?php
                            $stateLabel = 'Recorded';
                            $stateBadge = 'secondary';
                            if (($history['action_type'] ?? '') === 'voided') {
                                $stateLabel = 'Voided';
                                $stateBadge = 'danger';
                            } elseif (in_array(($history['action_type'] ?? ''), ['issued', 'linked', 'reused'], true)) {
                                $stateLabel = 'Active Flow';
                                $stateBadge = 'success';
                            }
                            ?>
                            <tr>
                                <td class="text-center"><?= number_format((int) $history['receipt_no']) ?></td>
                                <td class="text-center"><?= htmlspecialchars(booklet_label_from_stored((int) $history['booklet_no'])) ?></td>
                                <td class="text-center text-uppercase fw-semibold"><?= htmlspecialchars($history['action_type']) ?></td>
                                <td class="text-center"><?= htmlspecialchars((string) $history['used_by']) ?></td>
                                <td class="text-center"><?= number_format((int) ($history['used_id'] ?? 0)) ?></td>
                                <td class="text-center"><span class="badge bg-<?= $stateBadge ?>"><?= htmlspecialchars($stateLabel) ?></span></td>
                                <td><?= htmlspecialchars((string) ($history['reason'] ?? '-')) ?></td>
                                <td class="text-center"><?= htmlspecialchars((string) ($history['actor_username'] ?? '-')) ?></td>
                                <td class="text-center"><?= htmlspecialchars(date('n/j/Y g:i A', strtotime($history['created_at']))) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="9" class="text-center text-muted">No receipt history records found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>

    </div>

    <footer class="footer text-center py-4 text-muted small">&copy; <?= date('Y') ?> <?= htmlspecialchars($schoolName) ?> | School Admin Dashboard</footer>
    <a href="/school-admin-dashboard/modules/settings/settings-dashboard.php" class="dashboard-btn-bottom" title="Back to Settings"><i class="fas fa-arrow-left"></i></a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function initializeRegistryCardCollapse() {
    const cardHeaders = Array.from(document.querySelectorAll('.card > .card-header'));
    cardHeaders.forEach((header, index) => {
        const body = header.nextElementSibling;
        if (!body || !body.classList.contains('card-body')) {
            return;
        }
        if (header.querySelector('.card-collapse-toggle')) {
            return;
        }

        const collapseId = `receiptRegistryCardCollapse${index + 1}`;
        const headerHtml = header.innerHTML.trim();
        header.classList.add('card-header-collapsible');
        body.classList.add('collapse');
        body.id = collapseId;
        header.innerHTML = `
            <button type="button" class="card-collapse-toggle" data-bs-toggle="collapse" data-bs-target="#${collapseId}" aria-expanded="true" aria-controls="${collapseId}">
                <span class="card-header-label">${headerHtml}</span>
                <i class="fas fa-chevron-down collapse-indicator" aria-hidden="true"></i>
            </button>
        `;
    });
}

initializeRegistryCardCollapse();

function expandTargetedHistoryCard() {
    if (!window.location.hash) {
        return;
    }

    const target = document.querySelector(window.location.hash);
    if (!target) {
        return;
    }

    const collapseBody = target.querySelector('.card-body.collapse');
    if (collapseBody) {
        bootstrap.Collapse.getOrCreateInstance(collapseBody, { toggle: false }).show();
    }

    window.setTimeout(() => {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 120);
}

expandTargetedHistoryCard();

const catalogPanels = Array.from(document.querySelectorAll('[data-catalog-panel]'));
const bookletRows = Array.from(document.querySelectorAll('#bookletTableBody tr'));
const activityRows = Array.from(document.querySelectorAll('#activityTableBody tr'));
const registryPageContainer = document.querySelector('.container-fluid.py-4');

function catalogRowInputs(row) {
    return {
        storage: row.querySelector('[data-storage-number]'),
        status: row.querySelector('[data-booklet-status]'),
        active: row.querySelector('[data-booklet-active]'),
        notes: row.querySelector('[data-booklet-notes]'),
    };
}

function normalizeCatalogRowState(row) {
    const inputs = catalogRowInputs(row);
    return {
        status: inputs.status ? inputs.status.value : '',
        active: inputs.active ? (inputs.active.checked ? '1' : '0') : '0',
        notes: inputs.notes ? inputs.notes.value.trim() : '',
    };
}

function primeCatalogRowState(row) {
    row.dataset.initialStatus = normalizeCatalogRowState(row).status;
    row.dataset.initialActive = normalizeCatalogRowState(row).active;
    row.dataset.initialNotes = normalizeCatalogRowState(row).notes;
}

function catalogRowChanged(row) {
    const state = normalizeCatalogRowState(row);
    return state.status !== (row.dataset.initialStatus || '')
        || state.active !== (row.dataset.initialActive || '0')
        || state.notes !== (row.dataset.initialNotes || '');
}

function setCatalogRowSubmission(row, enabled) {
    const inputs = catalogRowInputs(row);
    [inputs.storage, inputs.status, inputs.active, inputs.notes].forEach((input) => {
        if (input) {
            input.disabled = !enabled;
        }
    });
}

function updateCatalogChangedCount(panelKey) {
    const changedCount = panelCatalogRows(panelKey).filter((row) => catalogRowChanged(row)).length;
    document.querySelectorAll(`[data-catalog-changed-count="${panelKey}"]`).forEach((badge) => {
        badge.textContent = `${changedCount} changed`;
        badge.classList.toggle('bg-info', changedCount === 0);
        badge.classList.toggle('bg-warning', changedCount > 0);
    });
}

function setCatalogRowLock(row, locked) {
    row.dataset.locked = locked ? '1' : '0';
    row.classList.toggle('catalog-row-locked', locked);
    const badge = row.querySelector('[data-lock-badge]');
    if (badge) {
        badge.classList.toggle('active', locked);
    }
}

function panelCatalogRows(panelKey) {
    const body = document.querySelector(`[data-catalog-body="${panelKey}"]`);
    return body ? Array.from(body.querySelectorAll('tr')) : [];
}

function visibleCatalogRows(panelKey) {
    return panelCatalogRows(panelKey).filter((row) => row.style.display !== 'none');
}

function filterCatalogPanel(panelKey) {
    const searchInput = document.querySelector(`[data-catalog-search="${panelKey}"]`);
    const statusInput = document.querySelector(`[data-catalog-status="${panelKey}"]`);
    if (!searchInput || !statusInput) {
        return;
    }

    const search = searchInput.value.trim().toLowerCase();
    const status = statusInput.value;

    panelCatalogRows(panelKey).forEach((row) => {
        const matchesSearch = row.textContent.toLowerCase().includes(search);
        const matchesStatus = !status || row.dataset.catalogStatus === status;
        row.style.display = matchesSearch && matchesStatus ? '' : 'none';
    });
}

document.querySelectorAll('.catalog-tab-btn').forEach((button) => {
    button.addEventListener('click', function () {
        const target = this.dataset.tabTarget;
        document.querySelectorAll('.catalog-tab-btn').forEach((btn) => btn.classList.toggle('active', btn === this));
        catalogPanels.forEach((panel) => panel.classList.toggle('active', panel.dataset.catalogPanel === target));
    });
});

['regular', 'special'].forEach((panelKey) => {
    panelCatalogRows(panelKey).forEach((row) => {
        primeCatalogRowState(row);
        setCatalogRowSubmission(row, true);
        const inputs = catalogRowInputs(row);
        [inputs.status, inputs.active, inputs.notes].forEach((input) => {
            if (input) {
                input.addEventListener('input', function () {
                    updateCatalogChangedCount(panelKey);
                });
                input.addEventListener('change', function () {
                    updateCatalogChangedCount(panelKey);
                });
            }
        });
    });
    updateCatalogChangedCount(panelKey);

    const searchInput = document.querySelector(`[data-catalog-search="${panelKey}"]`);
    const statusInput = document.querySelector(`[data-catalog-status="${panelKey}"]`);
    const checkAllBtn = document.querySelector(`[data-catalog-check-all="${panelKey}"]`);
    const lockCheckedBtn = document.querySelector(`[data-catalog-lock-checked="${panelKey}"]`);
    const unlockAllBtn = document.querySelector(`[data-catalog-unlock-all="${panelKey}"]`);
    const form = document.querySelector(`[data-catalog-form="${panelKey}"]`);

    if (searchInput) {
        searchInput.addEventListener('input', function () {
            filterCatalogPanel(panelKey);
        });
    }
    if (statusInput) {
        statusInput.addEventListener('change', function () {
            filterCatalogPanel(panelKey);
        });
    }

    if (checkAllBtn) {
        checkAllBtn.addEventListener('click', function () {
            const rows = visibleCatalogRows(panelKey);
            const unlockedRows = rows.filter((row) => row.dataset.locked !== '1');
            if (!unlockedRows.length) {
                return;
            }

            const shouldCheck = unlockedRows.some((row) => {
                const checkbox = row.querySelector('input[type="checkbox"][name^="booklet_active["]');
                return checkbox && !checkbox.checked;
            });

            unlockedRows.forEach((row) => {
                const checkbox = row.querySelector('input[type="checkbox"][name^="booklet_active["]');
                if (checkbox) {
                    checkbox.checked = shouldCheck;
                }
            });
        });
    }

    if (lockCheckedBtn) {
        lockCheckedBtn.addEventListener('click', function () {
            visibleCatalogRows(panelKey).forEach((row) => {
                const checkbox = row.querySelector('input[type="checkbox"][name^="booklet_active["]');
                if (checkbox && checkbox.checked) {
                    setCatalogRowLock(row, true);
                }
            });
        });
    }

    if (unlockAllBtn) {
        unlockAllBtn.addEventListener('click', function () {
            panelCatalogRows(panelKey).forEach((row) => setCatalogRowLock(row, false));
        });
    }

    if (form) {
        form.addEventListener('submit', function (event) {
            const rows = panelCatalogRows(panelKey);
            let changedCount = 0;

            rows.forEach((row) => {
                const changed = catalogRowChanged(row);
                setCatalogRowSubmission(row, changed);
                if (changed) {
                    changedCount++;
                }
            });

            if (!changedCount) {
                rows.forEach((row) => setCatalogRowSubmission(row, true));
                event.preventDefault();
                window.alert('No booklet changes were selected in this tab.');
            }
        });
    }
});

document.getElementById('bookletSearchInput').addEventListener('input', function () {
    const search = this.value.trim().toLowerCase();
    bookletRows.forEach((row) => {
        row.style.display = row.textContent.toLowerCase().includes(search) ? '' : 'none';
    });
});

function filterActivity() {
    const search = document.getElementById('activitySearchInput').value.trim().toLowerCase();
    const status = document.getElementById('activityStatusFilter').value;
    const source = document.getElementById('activitySourceFilter').value;
    const bookletFamily = document.getElementById('activityBookletFamilyFilter').value;

    activityRows.forEach((row) => {
        const matchesSearch = row.textContent.toLowerCase().includes(search);
        const matchesStatus = !status || row.dataset.status === status;
        const matchesSource = !source || row.dataset.source === source;
        const matchesBookletFamily = !bookletFamily || row.dataset.bookletFamily === bookletFamily;
        row.style.display = matchesSearch && matchesStatus && matchesSource && matchesBookletFamily ? '' : 'none';
    });
}

document.getElementById('activitySearchInput').addEventListener('input', filterActivity);
document.getElementById('activityStatusFilter').addEventListener('change', filterActivity);
document.getElementById('activitySourceFilter').addEventListener('change', filterActivity);
document.getElementById('activityBookletFamilyFilter').addEventListener('change', filterActivity);

document.getElementById('themeToggleBtn').addEventListener('click', function() {
    document.body.classList.toggle('dark-mode');
    this.querySelector('i').classList.toggle('fa-moon');
    this.querySelector('i').classList.toggle('fa-sun');
});
</script>
</body>
</html>
<?php $conn->close(); ?>














