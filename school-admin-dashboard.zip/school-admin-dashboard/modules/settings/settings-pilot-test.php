<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require '../../config/database.php';
require_once 'settings-permissions-roles.php';
require_once 'school-year-helper.php';
require_once 'backup-settings-helper.php';
require_once __DIR__ . '/../students/student-registration-helper.php';

$role = $_SESSION['role'] ?? '';
if (!can_view_settings_module($role)) {
    header('Location: /school-admin-dashboard/dashboard.php?error=settings_denied');
    exit();
}
if (is_specialized_staff_role($role)) {
    header('Location: /school-admin-dashboard/modules/settings/settings-dashboard.php?error=restricted');
    exit();
}

school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);
registration_ensure_pending_table($conn);
backup_settings_ensure_table($conn);

$activeSchoolYear = school_year_get_active($conn);
$activeSchoolYearLabel = $activeSchoolYear['label'] ?? school_year_default_label();
$enrollmentOpen = (int) ($activeSchoolYear['enrollment_open'] ?? 0) === 1;
$pendingRegistrations = 0;
$todayCollections = 0.0;
$todayTransactions = 0;
$todayLogbookFinalized = 0;
$todayLogbookDraft = 0;
$lastBackup = backup_settings_get($conn);
$username = $_SESSION['username'] ?? '';

$pendingStmt = $conn->prepare("SELECT COUNT(*) AS count FROM student_registration_pending WHERE status = 'Pending' AND COALESCE(NULLIF(TRIM(school_year_label), ''), ?) = ?");
if ($pendingStmt) {
    $pendingStmt->bind_param('ss', $activeSchoolYearLabel, $activeSchoolYearLabel);
    $pendingStmt->execute();
    $pendingRegistrations = (int) (($pendingStmt->get_result()->fetch_assoc()['count'] ?? 0));
    $pendingStmt->close();
}

$activeCollectionStmt = $conn->prepare("SELECT COALESCE(SUM(p.amount), 0) AS total_amount, COUNT(*) AS txn_count
    FROM payments p
    INNER JOIN accounts a ON a.id = p.account_id
    WHERE DATE(p.date_paid) = CURDATE()
      AND COALESCE(NULLIF(TRIM(a.school_year_label), ''), ?) = ?
      AND COALESCE(NULLIF(TRIM(p.school_year_label), ''), ?) = ?");
if ($activeCollectionStmt) {
    $activeCollectionStmt->bind_param('ssss', $activeSchoolYearLabel, $activeSchoolYearLabel, $activeSchoolYearLabel, $activeSchoolYearLabel);
    $activeCollectionStmt->execute();
    $row = $activeCollectionStmt->get_result()->fetch_assoc() ?: [];
    $todayCollections += (float) ($row['total_amount'] ?? 0);
    $todayTransactions += (int) ($row['txn_count'] ?? 0);
    $activeCollectionStmt->close();
}

$oldCollectionStmt = $conn->prepare("SELECT COALESCE(SUM(p.amount_paid), 0) AS total_amount, COUNT(*) AS txn_count
    FROM old_student_payments p
    INNER JOIN old_students s ON s.id = p.old_student_id
    WHERE DATE(COALESCE(p.paid_at_datetime, CONCAT(p.paid_at, ' 00:00:00'))) = CURDATE()
      AND COALESCE(NULLIF(TRIM(s.school_year_label), ''), ?) = ?");
if ($oldCollectionStmt) {
    $oldCollectionStmt->bind_param('ss', $activeSchoolYearLabel, $activeSchoolYearLabel);
    $oldCollectionStmt->execute();
    $row = $oldCollectionStmt->get_result()->fetch_assoc() ?: [];
    $todayCollections += (float) ($row['total_amount'] ?? 0);
    $todayTransactions += (int) ($row['txn_count'] ?? 0);
    $oldCollectionStmt->close();
}

$logbookStmt = $conn->prepare("SELECT
    SUM(CASE WHEN is_finalized = 1 THEN 1 ELSE 0 END) AS finalized_count,
    SUM(CASE WHEN is_finalized = 0 THEN 1 ELSE 0 END) AS draft_count
    FROM logbook_shift_notes
    WHERE log_date = CURDATE()");
if ($logbookStmt) {
    $logbookStmt->execute();
    $row = $logbookStmt->get_result()->fetch_assoc() ?: [];
    $todayLogbookFinalized = (int) ($row['finalized_count'] ?? 0);
    $todayLogbookDraft = (int) ($row['draft_count'] ?? 0);
    $logbookStmt->close();
}

function pilot_money(float $amount): string
{
    return 'PHP ' . number_format($amount, 2);
}

$checkSections = [
    'Core Access' => [
        'Login works with the correct admin role.',
        'Dashboard loads without PHP or database errors.',
        'Navbar links open the correct module pages.',
        'Session timeout warning appears normally when idle.'
    ],
    'Admissions And Enrollment' => [
        'Student add flow saves a record correctly.',
        'Student import preview shows valid and skipped rows correctly.',
        'Finalize Import creates students and linked accounts correctly.',
        'Pending registration queue can approve and reject records.'
    ],
    'Payments And Receipts' => [
        'Active account payment saves correctly.',
        'Old account payment saves correctly.',
        'Receipt number does not duplicate across active and old flows.',
        'Receipt print/download opens the correct record.'
    ],
    'Reports And Logbook' => [
        'Invoice Active, Old, and Total pages load correctly.',
        'Daily Collection Report totals match actual transactions.',
        'Logbook save, finalize, and reopen flow works correctly.',
        'Statement of Account prints correctly.'
    ],
    'Backup And Security' => [
        'Backup settings page opens correctly.',
        'Create Backup completes without error.',
        'Sensitive actions still require confirmation or CSRF-protected submit.',
        'Login lockout triggers after repeated failed attempts.'
    ],
    'Network And Multi-PC' => [
        'System opens from the main PC and at least one client PC.',
        'Two users can work without broken saves or page errors.',
        'Shared data appears correctly after refresh on another PC.',
        'Pilot issue notes are recorded before go-live.'
    ],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pilot Test Checklist | School Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --main-bg:#f5f8fc; --card-bg:#fff; --brand-dark:#23395d; --brand-blue:#517fa4; --soft:#eef5fd; --ok:#eaf7ef; --warn:#fff6df; }
        body { background: var(--main-bg); font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif; color: var(--brand-dark); }
        .navbar { background: var(--brand-dark) !important; }
        .navbar-brand, .navbar-nav .nav-link { color: #fff !important; }
        .header-wrap { max-width: 1180px; margin: 34px auto 20px; text-align: center; }
        .header-wrap h1 { font-size: 1.45rem; font-weight: 800; margin-bottom: .3rem; }
        .header-wrap p { color: #5f7186; margin-bottom: 0; }
        .section-wrap { max-width: 1180px; margin: 0 auto 24px; }
        .snapshot-grid, .section-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px; }
        .snapshot-card, .panel-card { background: var(--card-bg); border: 1px solid #dce8f7; border-radius: 18px; box-shadow: 0 8px 24px rgba(33,57,93,0.08); }
        .snapshot-card { padding: 18px 18px 16px; }
        .snapshot-label { font-size: .8rem; font-weight: 700; text-transform: uppercase; letter-spacing: .05em; color: #63778e; margin-bottom: .35rem; }
        .snapshot-value { font-size: 1.45rem; font-weight: 800; color: var(--brand-dark); margin-bottom: .35rem; }
        .snapshot-note { color: #607388; font-size: .92rem; }
        .panel-card { padding: 20px; }
        .panel-title { font-size: 1.05rem; font-weight: 800; margin-bottom: 1rem; color: var(--brand-dark); }
        .section-card { background: var(--card-bg); border: 1px solid #dce8f7; border-radius: 18px; box-shadow: 0 8px 24px rgba(33,57,93,0.08); padding: 18px; }
        .section-title { font-size: 1rem; font-weight: 800; margin-bottom: .85rem; color: var(--brand-dark); }
        .form-check { background: #f9fbfe; border: 1px solid #e6edf7; border-radius: 12px; padding: .75rem .9rem  .75rem 2.2rem; margin-bottom: .65rem; }
        .form-check-label { color: #40556f; font-size: .95rem; }
        .ready-chip { display: inline-flex; align-items: center; gap: 6px; border-radius: 999px; padding: 7px 12px; font-size: .82rem; font-weight: 700; }
        .ready-chip.ok { background: var(--ok); color: #1c6a44; }
        .ready-chip.warn { background: var(--warn); color: #926400; }
        .notes-box { min-height: 170px; resize: vertical; }
        .quick-links { display: flex; flex-wrap: wrap; gap: 10px; }
        @media print {
            .navbar, .btn, .quick-links, .footer-note { display: none !important; }
            body { background: #fff; }
            .snapshot-card, .panel-card, .section-card { box-shadow: none !important; }
        }
    </style>
</head>
<body>
<?php render_admin_nav('settings'); ?>

<div class="header-wrap">
    <h1><i class="fas fa-clipboard-check me-2"></i>Pilot Test Checklist</h1>
    <p>Use this page to run the final pilot pass before wider school deployment.</p>
</div>

<div class="section-wrap">
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <div>
            <div class="panel-title mb-0">Live Readiness Snapshot</div>
            <div class="text-muted small">Pulled from the current system state so the pilot check starts with real data.</div>
        </div>
        <div class="quick-links">
            <button class="btn btn-outline-secondary btn-sm" type="button" onclick="window.print()"><i class="fas fa-print me-1"></i>Print Checklist</button>
            <a class="btn btn-primary btn-sm" href="/school-admin-dashboard/modules/settings/settings-dashboard.php"><i class="fas fa-arrow-left me-1"></i>Back to Settings</a>
        </div>
    </div>
    <div class="snapshot-grid">
        <div class="snapshot-card">
            <div class="snapshot-label">Active School Year</div>
            <div class="snapshot-value"><?= htmlspecialchars($activeSchoolYearLabel) ?></div>
            <div class="snapshot-note"><?= $enrollmentOpen ? 'Enrollment is currently open.' : 'Enrollment is currently closed.' ?></div>
        </div>
        <div class="snapshot-card">
            <div class="snapshot-label">Pending Registrations</div>
            <div class="snapshot-value"><?= number_format($pendingRegistrations) ?></div>
            <div class="snapshot-note">Pending queue entries still waiting for review.</div>
        </div>
        <div class="snapshot-card">
            <div class="snapshot-label">Today's Collections</div>
            <div class="snapshot-value"><?= htmlspecialchars(pilot_money($todayCollections)) ?></div>
            <div class="snapshot-note"><?= number_format($todayTransactions) ?> transaction(s) recorded today.</div>
        </div>
        <div class="snapshot-card">
            <div class="snapshot-label">Today's Logbook</div>
            <div class="snapshot-value"><?= number_format($todayLogbookFinalized) ?> finalized</div>
            <div class="snapshot-note"><?= number_format($todayLogbookDraft) ?> draft shift record(s) still open.</div>
        </div>
        <div class="snapshot-card">
            <div class="snapshot-label">Last Backup Status</div>
            <div class="snapshot-value"><?= htmlspecialchars((string) ($lastBackup['last_backup_status'] ?? 'Never Run')) ?></div>
            <div class="snapshot-note">
                <?= !empty($lastBackup['last_backup_at']) ? htmlspecialchars(date('M j, Y g:i A', strtotime((string) $lastBackup['last_backup_at']))) : 'No backup run recorded yet.' ?>
            </div>
        </div>
    </div>
</div>

<div class="section-wrap">
    <div class="panel-card mb-4">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
            <div>
                <div class="panel-title mb-1">Pilot Progress</div>
                <div class="text-muted small">Check each item while testing. Progress is saved in this browser using local storage.</div>
            </div>
            <div>
                <span class="ready-chip ok" id="pilotProgressChip"><i class="fas fa-check-circle"></i>0 completed</span>
                <span class="ready-chip warn" id="pilotRemainingChip"><i class="fas fa-hourglass-half"></i>0 remaining</span>
            </div>
        </div>
    </div>

    <div class="section-grid">
        <?php $checkIndex = 0; ?>
        <?php foreach ($checkSections as $sectionName => $items): ?>
            <div class="section-card">
                <div class="section-title"><?= htmlspecialchars($sectionName) ?></div>
                <?php foreach ($items as $item): ?>
                    <div class="form-check">
                        <input class="form-check-input pilot-check" type="checkbox" value="1" id="pilotCheck<?= $checkIndex ?>" data-key="pilot_check_<?= $checkIndex ?>">
                        <label class="form-check-label" for="pilotCheck<?= $checkIndex ?>">
                            <?= htmlspecialchars($item) ?>
                        </label>
                    </div>
                    <?php $checkIndex++; ?>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="section-wrap">
    <div class="panel-card">
        <div class="panel-title">Issue Log And Go-Live Notes</div>
        <div class="row g-3">
            <div class="col-lg-6">
                <label for="pilotIssueLog" class="form-label fw-semibold">Pilot Issue Log</label>
                <textarea id="pilotIssueLog" class="form-control notes-box" placeholder="Example: PC 2 receipt print was slow at 10:15 AM. Re-tested after refresh and it worked."></textarea>
            </div>
            <div class="col-lg-6">
                <label for="pilotGoLiveNotes" class="form-label fw-semibold">Go-Live Decision Notes</label>
                <textarea id="pilotGoLiveNotes" class="form-control notes-box" placeholder="Example: Ready for controlled rollout. Need final DB user/password switch before full deployment."></textarea>
            </div>
        </div>
        <div class="mt-3 d-flex gap-2 flex-wrap">
            <button type="button" class="btn btn-success" id="savePilotNotesBtn"><i class="fas fa-save me-1"></i>Save Notes</button>
            <button type="button" class="btn btn-outline-secondary" id="clearPilotNotesBtn"><i class="fas fa-rotate-left me-1"></i>Clear Notes</button>
        </div>
        <div class="footer-note text-muted small mt-3">Recommended final step: run this checklist on the main PC, then repeat the high-risk items from at least one connected client PC.</div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
const checks = Array.from(document.querySelectorAll('.pilot-check'));
const issueLog = document.getElementById('pilotIssueLog');
const goLiveNotes = document.getElementById('pilotGoLiveNotes');
const progressChip = document.getElementById('pilotProgressChip');
const remainingChip = document.getElementById('pilotRemainingChip');

function refreshPilotProgress() {
    const completed = checks.filter((checkbox) => checkbox.checked).length;
    const remaining = checks.length - completed;
    progressChip.innerHTML = `<i class="fas fa-check-circle"></i>${completed} completed`;
    remainingChip.innerHTML = `<i class="fas fa-hourglass-half"></i>${remaining} remaining`;
}

checks.forEach((checkbox) => {
    const key = checkbox.dataset.key;
    checkbox.checked = localStorage.getItem(key) === '1';
    checkbox.addEventListener('change', () => {
        localStorage.setItem(key, checkbox.checked ? '1' : '0');
        refreshPilotProgress();
    });
});

issueLog.value = localStorage.getItem('pilot_issue_log') || '';
goLiveNotes.value = localStorage.getItem('pilot_go_live_notes') || '';

document.getElementById('savePilotNotesBtn').addEventListener('click', () => {
    localStorage.setItem('pilot_issue_log', issueLog.value);
    localStorage.setItem('pilot_go_live_notes', goLiveNotes.value);
    alert('Pilot notes saved in this browser.');
});

document.getElementById('clearPilotNotesBtn').addEventListener('click', () => {
    if (!confirm('Clear saved pilot notes in this browser?')) {
        return;
    }
    issueLog.value = '';
    goLiveNotes.value = '';
    localStorage.removeItem('pilot_issue_log');
    localStorage.removeItem('pilot_go_live_notes');
});

refreshPilotProgress();
</script>
<?= admin_session_warning_script() ?>
</body>
</html>
<?php $conn->close(); ?>
