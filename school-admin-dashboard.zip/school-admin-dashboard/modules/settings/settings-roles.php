<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();

include __DIR__ . '/../../config/database.php';
require_once 'settings-security.php';
require_once 'settings-permissions-roles.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

$currentRole = $_SESSION['role'] ?? '';
if (!can_access_user_management_settings($currentRole)) {
    audit_log(
        $conn,
        $_SESSION['username'] ?? 'unknown',
        'Blocked settings roles access',
        'Settings',
        'Role: ' . ($currentRole !== '' ? $currentRole : 'unknown') . ' | Reason: missing user management settings permission',
        'SECURITY'
    );
    header('Location: /school-admin-dashboard/dashboard.php?error=settings_denied');
    exit();
}

$roles = [
    [
        'id' => 0,
        'name' => 'Super Administrator',
        'description' => 'Full access to all system features, settings, user management, backups, and imports/exports.',
        'permissions' => [
            'View, add, edit, and delete all users and admins',
            'Manage all roles and permissions',
            'Access all settings including backup, restore (import), and export',
            'Can restore backups (import data/files) and export files',
            'Can create backups and export files (Excel, CSV, etc.)',
            'Full access to student, accounts, fees, documents, and old accounts tabs',
            'Can add, edit, and delete students from all tabs',
            'Can add, edit, and delete fees and payments',
            'Can delete or edit old accounts',
            'No restrictions on any delete/edit actions'
        ]
    ],
    [
        'id' => 1,
        'name' => 'Administrator 1',
        'description' => 'Operational admin with limited settings access and no delete privileges on core student/account data.',
        'permissions' => [
            'Can view, add, and edit students',
            'Can view own settings profile only',
            'Can add and edit account entries allowed by the current permission map',
            'Cannot manage user roles',
            'Cannot add or remove admin users',
            'Cannot access full settings tools'
        ]
    ],
    [
        'id' => 2,
        'name' => 'Administrator 2',
        'description' => 'Operational admin with wider student, registration, and finance permissions but still no full settings management.',
        'permissions' => [
            'Can view, add, and edit students',
            'Can approve registration queue',
            'Can add, edit, and delete finance-side records allowed by the permission map',
            'Cannot manage user roles',
            'Cannot add or remove admin users',
            'Cannot access full settings tools'
        ]
    ],
    [
        'id' => 3,
        'name' => 'Staff',
        'description' => 'View-only role. Can review records but cannot add, edit, delete, or access settings.',
        'permissions' => [
            'View-only access to allowed modules',
            'Cannot add records',
            'Cannot edit records',
            'Cannot delete records',
            'Cannot access settings dashboard or settings tools'
        ]
    ],
    [
        'id' => 4,
        'name' => 'Registrar Staff',
        'description' => 'Registrar-focused operational role with student, pending registration, export, and limited backup access only.',
        'permissions' => [
            'Can view, add, and edit official student records allowed by registrar safeguards',
            'Can open and process pending registration records',
            'Can export student lists and registrar-side records',
            'Can access Settings only for manual backup creation and download',
            'Cannot import students',
            'Cannot delete student records',
            'Cannot access finance, invoice, fees, or restore tools'
        ]
    ],
    [
        'id' => 5,
        'name' => 'Accounting Staff',
        'description' => 'Accounting-focused operational role with finance, logbook, invoice, finance reports, and limited backup access only.',
        'permissions' => [
            'Can view and manage finance records allowed by the finance permission map',
            'Can access logbook, invoice pages, and finance reports',
            'Can access Settings only for manual backup creation and download',
            'Cannot access registrar student intake and pending registration pages',
            'Cannot access restore tools, user management, or full system settings',
            'Cannot manage fees or delete admin accounts'
        ]
    ],
    [
        'id' => 6,
        'name' => 'View Staff',
        'description' => 'Cross-module checker role with view and export access only for validation, reconciliation, and reporting back to the Super Administrator.',
        'permissions' => [
            'Can view registrar, finance, old accounts, logbook, invoice, and report pages allowed by the permission map',
            'Can download or export available reports and reference files',
            'Cannot add, edit, post, void, or delete records',
            'Cannot access fees setup, settings tools, or user management',
            'Intended for double-checking system data against exports and manual notes'
        ]
    ]
];

if ($currentRole === 'Super Administrator' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'], $_POST['role'])) {
    admin_require_post_csrf();
    $userId = (int) $_POST['user_id'];
    $newRole = $_POST['role'];
    if (in_array($newRole, managed_admin_roles(), true)) {
        $stmt = $conn->prepare('UPDATE admins SET role = ? WHERE id = ?');
        $stmt->bind_param('si', $newRole, $userId);
        if ($stmt->execute()) {
            audit_log(
                $conn,
                $_SESSION['username'] ?? 'unknown',
                'Changed admin user role',
                'Settings',
                'Target User ID: ' . $userId . ' | New Role: ' . $newRole,
                'INFO'
            );
            $success = 'User role updated!';
        } else {
            $error = 'Failed to update role: ' . $conn->error;
        }
        $stmt->close();
    }
}

$users = [];
$sql = "SELECT id, username, role, email FROM admins WHERE role != 'Super Administrator'";
if ($result = $conn->query($sql)) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
    $result->free();
} else {
    die('Database query failed: ' . $conn->error);
}

ensure_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Roles & Permissions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        .header { margin: 36px 0 28px 0; text-align: center; }
        .header h2 { font-weight: bold; color: #23395d; }
        .role-card { margin-bottom: 32px; }
        .role-title { font-size: 1.1em; font-weight: bold; color: #204080; }
        .role-perm { margin-bottom: 0.4em; }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h2><i class="fas fa-shield-alt"></i> User Roles & Permissions</h2>
        <p class="text-muted">Assign roles to existing users and see role permissions</p>
    </div>
    <?php if (!empty($success)): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php elseif (!empty($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <h4 class="mb-3"><i class="fas fa-users"></i> Existing Users</h4>
    <div class="table-responsive mb-5">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-primary">
                <tr>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Current Role</th>
                    <?php if ($currentRole === 'Super Administrator'): ?>
                        <th>Change Role</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= htmlspecialchars($user['username']) ?></td>
                    <td><?= htmlspecialchars($user['email']) ?></td>
                    <td class="role-title"><?= htmlspecialchars($user['role']) ?></td>
                    <?php if ($currentRole === 'Super Administrator'): ?>
                        <td>
                            <form method="post" style="display:inline-block;">
                                <?= csrf_input() ?>
                                <input type="hidden" name="user_id" value="<?= (int) $user['id'] ?>">
                                <select name="role" class="form-select form-select-sm d-inline" style="width:auto;display:inline-block;" required>
                                    <?php foreach (managed_admin_roles() as $managedRole): ?>
                                        <option value="<?= htmlspecialchars($managedRole) ?>" <?= $user['role'] === $managedRole ? 'selected' : '' ?>><?= htmlspecialchars($managedRole) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" class="btn btn-sm btn-primary ms-2"><i class="fas fa-sync"></i> Update</button>
                            </form>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <h4 class="mb-3"><i class="fas fa-id-card-alt"></i> Role Definitions</h4>
    <?php foreach ($roles as $role): ?>
        <div class="card role-card">
            <div class="card-header bg-primary text-white role-title">
                <i class="fas fa-user-shield me-2"></i> <?= htmlspecialchars($role['name']) ?>
            </div>
            <div class="card-body">
                <p><?= htmlspecialchars($role['description']) ?></p>
                <ul>
                    <?php foreach ($role['permissions'] as $perm): ?>
                        <li class="role-perm"><i class="fas fa-check text-success me-1"></i> <?= htmlspecialchars($perm) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    <?php endforeach; ?>
    <div class="mt-5">
        <a href="settings-dashboard.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Settings</a>
    </div>
</div>
</body>
</html>
