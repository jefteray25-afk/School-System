<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require '../../config/database.php';
require_once 'settings-permissions-roles.php';
require_once 'settings-security.php';
require_once 'school-info-helper.php';
require_once 'backup-settings-helper.php';
include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');

$userRole = $_SESSION['role'] ?? '';
$username = $_SESSION['username'] ?? '';
if (!can_access_settings_page($userRole, 'backup_schedule')) {
    audit_log(
        $conn,
        $username !== '' ? $username : 'unknown',
        'Blocked settings backup schedule access',
        'Settings',
        'Role: ' . ($userRole !== '' ? $userRole : 'unknown') . ' | Reason: missing backup_schedule permission',
        'SECURITY'
    );
    header('Location: /school-admin-dashboard/modules/settings/settings-dashboard.php?error=restricted');
    exit();
}

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);

backup_settings_ensure_table($conn);
ensure_csrf_token();
$settings = backup_settings_get($conn);
$scheduleMessage = '';
$scheduleMessageType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_backup_schedule'])) {
    admin_require_post_csrf();
    $confirmPhrase = trim((string) ($_POST['critical_confirm_phrase'] ?? ''));
    if ($confirmPhrase !== 'CONFIRM') {
        $scheduleMessage = 'Type CONFIRM before saving backup schedule settings.';
        $scheduleMessageType = 'danger';
    } else {
        [$backupDirReady, $backupDir, $backupDirMessage] = backup_settings_prepare_dir((string) ($_POST['backup_dir'] ?? $settings['backup_dir']));
        $payload = [
            'enabled' => !empty($_POST['enabled']) ? 1 : 0,
            'preferred_time' => '00:00',
            'retention_count' => $_POST['retention_count'] ?? 122,
            'schedule_label' => $_POST['schedule_label'] ?? 'Hourly Automatic',
            'backup_dir' => $backupDir,
        ];

        if (!$backupDirReady) {
            $scheduleMessage = $backupDirMessage;
            $scheduleMessageType = 'danger';
        } elseif (backup_settings_save($conn, $payload)) {
            $scheduleMessage = 'Backup schedule settings updated successfully.';
            $settings = backup_settings_get($conn);
            audit_log(
                $conn,
                $username,
                'Updated backup schedule settings',
                'Settings',
                'Enabled: ' . (!empty($payload['enabled']) ? 'Yes' : 'No') . ' | Mode: Hourly Automatic | Retention: ' . (int) $payload['retention_count'] . ' | Backup Dir: ' . $backupDir,
                'INFO'
            );
        } else {
            $scheduleMessage = 'Backup schedule settings could not be saved.';
            $scheduleMessageType = 'danger';
        }
    }
}

$schedulerBatch = 'C:\xampp\htdocs\school-admin-dashboard\backups\backup-script.bat';
$schedulerSetup = 'C:\xampp\htdocs\school-admin-dashboard\backups\install-backup-schedule.ps1';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Backup Schedule Settings - School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body { background: var(--main-bg); font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif; }
        .navbar { background: var(--navbar-bg) !important; box-shadow: 0 2px 12px rgba(33,57,93,0.08); }
        .navbar-brand, .navbar-nav .nav-link { color: #fff !important; font-size: 1.08em; }
        .navbar-brand { font-weight: 700; letter-spacing: 1px; }
        .dashboard-header { text-align: center; margin-top: 36px; margin-bottom: 18px; }
        .dashboard-header img { width: 70px; height: 70px; object-fit: contain; margin-bottom: 6px; }
        .dashboard-header h1 { font-size: 1.3rem; color: var(--brand-dark); font-weight: 700; margin-bottom: 0; }
        .page-title { color: var(--brand-dark); font-weight: 700; }
        .section-card {
            background: var(--card-bg);
            border: 1px solid rgba(81, 127, 164, 0.15);
            border-radius: 1rem;
            box-shadow: 0 4px 18px rgba(33, 57, 93, 0.07);
            margin-bottom: 1.25rem;
        }
        .summary-stat {
            background: #f8fbff;
            border: 1px solid rgba(81, 127, 164, 0.16);
            border-radius: 1rem;
            padding: 1rem 1.1rem;
            height: 100%;
        }
        .summary-stat .label { text-transform: uppercase; font-size: 0.74rem; color: #6c757d; font-weight: 700; }
        .summary-stat .value { font-size: 1.3rem; font-weight: 700; color: var(--brand-dark); }
        .note-box {
            border-left: 4px solid #0d6efd;
            background: #f8fbff;
            padding: 0.9rem 1rem;
            border-radius: 0.5rem;
        }
    </style>
</head>
<body>
<?php render_admin_nav('settings'); ?>
<?php render_school_page_header($schoolName, $schoolLogo); ?>

<div class="container pb-5">
    <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-4">
        <div>
            <h2 class="page-title mb-1"><i class="fas fa-clock me-2"></i>Backup Schedule Settings</h2>
            <p class="text-muted mb-0">Define the hourly automatic backup policy used by the server backup runner. This controls retention, enable/disable state, and last-run visibility.</p>
        </div>
        <a href="/school-admin-dashboard/modules/settings/settings-dashboard.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i>Back to Settings
        </a>
    </div>

    <?php if ($scheduleMessage !== ''): ?>
        <div class="alert alert-<?= htmlspecialchars($scheduleMessageType) ?>"><?= htmlspecialchars($scheduleMessage) ?></div>
    <?php endif; ?>

    <div class="row g-3 mb-4">
        <div class="col-12 col-md-3">
            <div class="summary-stat">
                <div class="label">Automatic Backup</div>
                <div class="value"><?= !empty($settings['enabled']) ? 'Enabled' : 'Disabled' ?></div>
            </div>
        </div>
        <div class="col-12 col-md-3">
            <div class="summary-stat">
                <div class="label">Backup Mode</div>
                <div class="value">Hourly</div>
            </div>
        </div>
        <div class="col-12 col-md-3">
            <div class="summary-stat">
                <div class="label">Retention Count</div>
                <div class="value"><?= number_format((int) $settings['retention_count']) ?></div>
            </div>
        </div>
        <div class="col-12 col-md-3">
            <div class="summary-stat">
                <div class="label">Last Backup Status</div>
                <div class="value"><?= htmlspecialchars((string) $settings['last_backup_status']) ?></div>
            </div>
        </div>
    </div>

    <div class="section-card p-4">
        <h5 class="mb-3">Schedule Policy</h5>
        <form method="post">
            <?= csrf_input() ?>
            <input type="hidden" name="save_backup_schedule" value="1">
            <div class="row g-3">
                <div class="col-md-3">
                    <div class="form-check mt-4 pt-2">
                        <input class="form-check-input" type="checkbox" name="enabled" value="1" id="enabled" <?= !empty($settings['enabled']) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="enabled">Enable automatic backups</label>
                    </div>
                </div>
                <div class="col-md-3">
                    <label class="form-label" for="hourly_mode">Automatic backup timing</label>
                    <input type="text" class="form-control" id="hourly_mode" value="Every hour on the hour while the server PC is running" readonly>
                    <div class="form-text">Example: if the server opens at 5:01 AM, the next automatic backup runs at 6:00 AM.</div>
                </div>
                <div class="col-md-3">
                    <label class="form-label" for="retention_count">Retention count</label>
                    <input type="number" class="form-control" name="retention_count" id="retention_count" min="1" max="365" value="<?= (int) $settings['retention_count'] ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label" for="schedule_label">Schedule mode</label>
                    <input type="text" class="form-control" id="schedule_label" value="Hourly Automatic" readonly>
                    <input type="hidden" name="schedule_label" value="Hourly Automatic">
                    <div class="form-text">Manual backup remains available anytime; it does not need a separate automatic mode.</div>
                </div>
                <div class="col-12">
                    <label class="form-label" for="backup_dir">Backup directory</label>
                    <input type="text" class="form-control" name="backup_dir" id="backup_dir" value="<?= htmlspecialchars((string) $settings['backup_dir']) ?>" placeholder="D:/school-admin-backups">
                    <div class="form-text">Use an absolute Windows path outside the web folder. The folder will be created if possible.</div>
                </div>
                <div class="col-12">
                    <label class="form-label" for="critical_confirm_phrase">Type CONFIRM to proceed</label>
                    <input type="text" class="form-control" name="critical_confirm_phrase" id="critical_confirm_phrase" placeholder="CONFIRM" autocomplete="off">
                    <div class="form-text text-danger">Required because changing backup schedule or backup path affects whole-system recovery behavior.</div>
                </div>
            </div>
            <div class="text-end mt-3">
                <button type="submit" class="btn btn-primary" onclick="return confirm('Save backup schedule settings?');">
                    <i class="fas fa-save me-1"></i>Save Backup Schedule
                </button>
            </div>
        </form>
    </div>

    <div class="section-card p-4">
        <h5 class="mb-3">Status and Runner Details</h5>
        <div class="row g-3">
            <div class="col-12 col-lg-6">
                <div class="note-box h-100">
                    <div class="fw-semibold mb-2">Last Backup Result</div>
                    <div class="small text-muted mb-1">Last backup time: <strong class="text-dark"><?= htmlspecialchars((string) ($settings['last_backup_at'] ?? '-')) ?></strong></div>
                    <div class="small text-muted mb-1">Last file: <strong class="text-dark"><?= htmlspecialchars((string) ($settings['last_backup_file'] ?: '-')) ?></strong></div>
                    <div class="small text-muted">Message: <strong class="text-dark"><?= htmlspecialchars((string) ($settings['last_backup_message'] ?: '-')) ?></strong></div>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div class="note-box h-100">
                    <div class="fw-semibold mb-2">Windows Scheduler Integration</div>
                    <div class="small text-muted mb-1">Batch runner: <code><?= htmlspecialchars($schedulerBatch) ?></code></div>
                    <div class="small text-muted mb-1">Setup script: <code><?= htmlspecialchars($schedulerSetup) ?></code></div>
                    <div class="small text-muted">This page defines the policy used by the backup runner, but Windows Task Scheduler still needs to run the batch file every hour on the server PC.</div>
                </div>
            </div>
        </div>
    </div>

    <div class="section-card p-4">
        <h5 class="mb-3">Windows Task Scheduler Guide</h5>
        <div class="accordion" id="backupSchedulerGuide">
            <div class="accordion-item">
                <h2 class="accordion-header" id="guideHeadingOne">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#guideCollapseOne" aria-expanded="true" aria-controls="guideCollapseOne">
                        Setup steps after system update
                    </button>
                </h2>
                <div id="guideCollapseOne" class="accordion-collapse collapse show" aria-labelledby="guideHeadingOne" data-bs-parent="#backupSchedulerGuide">
                    <div class="accordion-body">
                        <ol class="mb-0">
                            <li>Open PowerShell as Administrator on the server PC.</li>
                            <li>Go to the project folder and run the scheduler setup script.</li>
                            <li>Confirm that hourly tasks named <code>SchoolAdminBackup-Hourly-*</code> appear in Windows Task Scheduler.</li>
                            <li>Leave the server PC on past the next top-of-hour and confirm a new SQL file appears in the secure backup folder.</li>
                        </ol>
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header" id="guideHeadingTwo">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#guideCollapseTwo" aria-expanded="false" aria-controls="guideCollapseTwo">
                        How hourly automatic backup behaves
                    </button>
                </h2>
                <div id="guideCollapseTwo" class="accordion-collapse collapse" aria-labelledby="guideHeadingTwo" data-bs-parent="#backupSchedulerGuide">
                    <div class="accordion-body">
                        <ul class="mb-0">
                            <li>If the server starts at 5:01 AM, the next backup runs at 6:00 AM.</li>
                            <li>If the server starts at 4:30 PM, the next backup runs at 5:00 PM.</li>
                            <li>Each run creates a new SQL file and does not overwrite the older files.</li>
                            <li>Old files are pruned automatically once the retention limit is exceeded.</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header" id="guideHeadingThree">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#guideCollapseThree" aria-expanded="false" aria-controls="guideCollapseThree">
                        Recommended admin reminders
                    </button>
                </h2>
                <div id="guideCollapseThree" class="accordion-collapse collapse" aria-labelledby="guideHeadingThree" data-bs-parent="#backupSchedulerGuide">
                    <div class="accordion-body">
                        <ul class="mb-0">
                            <li>Keep retention at <strong>122</strong> unless you intentionally want fewer or more backup files.</li>
                            <li>Copy important SQL backups to another folder or external drive before manually cleaning old files.</li>
                            <li>Use manual backup before major imports, cleanup, restore, or school-year-end operations.</li>
                            <li>Confirm automation by checking that the latest backup file and last backup time update after the next top-of-hour.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
