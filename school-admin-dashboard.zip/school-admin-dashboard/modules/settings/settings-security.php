<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (!function_exists('ensure_csrf_token')) {
    function ensure_csrf_token(): string
    {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }

        return $_SESSION['csrf_token'];
    }
}

if (!function_exists('csrf_input')) {
    function csrf_input(): string
    {
        return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(ensure_csrf_token(), ENT_QUOTES, 'UTF-8') . '">';
    }
}

if (!function_exists('verify_csrf_or_die')) {
    function verify_csrf_or_die(): void
    {
        $sessionToken = $_SESSION['csrf_token'] ?? '';
        $requestToken = $_POST['csrf_token'] ?? '';

        if (!$sessionToken || !$requestToken || !hash_equals($sessionToken, $requestToken)) {
            http_response_code(403);
            die('Invalid CSRF token.');
        }
    }
}

if (!function_exists('csrf_validate')) {
    function csrf_validate(?string $token): bool
    {
        $sessionToken = $_SESSION['csrf_token'] ?? '';
        $requestToken = (string) ($token ?? '');

        return $sessionToken !== '' && $requestToken !== '' && hash_equals($sessionToken, $requestToken);
    }
}

if (!function_exists('get_secure_backup_dir')) {
    function get_secure_backup_dir(): string
    {
        return 'C:/xampp/secure-school-admin-backups';
    }
}

if (!function_exists('ensure_secure_backup_dir')) {
    function ensure_secure_backup_dir(): string
    {
        $dir = get_secure_backup_dir();
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }

        return $dir;
    }
}

if (!function_exists('is_super_admin')) {
    function is_super_admin(): bool
    {
        return (($_SESSION['role'] ?? '') === 'Super Administrator');
    }
}

if (!function_exists('can_manage_backups')) {
    function can_manage_backups(): bool
    {
        if (empty($_SESSION['loggedin'])) {
            return false;
        }

        if (function_exists('can_access_backup_settings')) {
            return can_access_backup_settings((string) ($_SESSION['role'] ?? ''));
        }

        return true;
    }
}

if (!function_exists('can_restore_backups')) {
    function can_restore_backups(): bool
    {
        return is_super_admin();
    }
}

if (!function_exists('sanitize_backup_filename')) {
    function sanitize_backup_filename(string $filename): string
    {
        return preg_replace('/[^A-Za-z0-9._()-]/', '', basename($filename));
    }
}
