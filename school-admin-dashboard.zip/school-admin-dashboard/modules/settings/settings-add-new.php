<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once 'settings-permissions-roles.php';
if (!can_access_settings_page((string) ($_SESSION['role'] ?? ''), 'user_management')) {
    header('Location: /Admin.php');
    exit();
}

include __DIR__ . '/../../config/database.php';
require_once 'settings-security.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_require_post_csrf();
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $role = trim($_POST['role'] ?? '');
    $email = trim($_POST['email'] ?? '');

    if ($username === '' || $password === '' || $role === '' || $email === '') {
        $error = 'All fields are required.';
    } elseif (!in_array($role, managed_admin_roles(), true)) {
        $error = 'Invalid role selected.';
    } elseif (strlen($password) < 8 || !preg_match('/[A-Z]/', $password) || !preg_match('/[a-z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $error = 'Password must be at least 8 characters long and contain uppercase, lowercase, and a number.';
    } else {
        $stmt = $conn->prepare('SELECT id FROM admins WHERE username = ?');
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = 'Username already exists.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare('INSERT INTO admins (username, password, role, email) VALUES (?, ?, ?, ?)');
            $stmt->bind_param('ssss', $username, $hash, $role, $email);
            if ($stmt->execute()) {
                audit_log(
                    $conn,
                    $_SESSION['username'] ?? 'unknown',
                    'Created admin user',
                    'Settings',
                    'Username: ' . $username . ' | Role: ' . $role . ' | Email: ' . $email,
                    'INFO'
                );
                header('Location: settings-admin-users.php?added=1');
                exit();
            }
            $error = 'Failed to add user: ' . $conn->error;
        }
        $stmt->close();
    }
}

ensure_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        .card { max-width: 430px; margin: 45px auto; border-radius: 16px; box-shadow: 0 5px 18px rgba(0,0,0,.10); border: none; }
        .card-title { color: #23395d; font-weight: bold; }
    </style>
</head>
<body>
<div class="container">
    <div class="card mt-5">
        <div class="card-body">
            <h4 class="card-title mb-4"><i class="fas fa-user-plus"></i> Add New User</h4>
            <?php if ($error !== ''): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="post" action="">
                <?= csrf_input() ?>
                <div class="mb-3">
                    <label for="username" class="form-label">Username:</label>
                    <input type="text" name="username" id="username" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password:</label>
                    <input type="password" name="password" id="password" class="form-control" required>
                    <div class="form-text">At least 8 characters, includes uppercase, lowercase, and number.</div>
                </div>
                <div class="mb-3">
                    <label for="role" class="form-label">Role:</label>
                    <select name="role" id="role" class="form-select" required>
                        <option value="">Select Role</option>
                        <option value="Administrator 1">Administrator 1</option>
                        <option value="Administrator 2">Administrator 2</option>
                        <option value="Staff">Staff</option>
                        <option value="Registrar Staff">Registrar Staff</option>
                        <option value="Accounting Staff">Accounting Staff</option>
                        <option value="View Staff">View Staff</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email:</label>
                    <input type="email" name="email" id="email" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-success w-100">
                    <i class="fas fa-user-plus"></i> Add User
                </button>
                <a href="settings-admin-users.php" class="btn btn-secondary w-100 mt-2">
                    <i class="fas fa-arrow-left"></i> Back to User List
                </a>
            </form>
        </div>
    </div>
</div>
</body>
</html>
