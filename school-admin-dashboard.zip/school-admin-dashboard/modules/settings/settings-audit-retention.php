<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require '../../config/database.php';
require_once 'settings-permissions-roles.php';
require_once 'settings-security.php';
require_once 'school-info-helper.php';
require_once __DIR__ . '/../audit/audit-retention-helper.php';
include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');

$userRole = $_SESSION['role'] ?? '';
$username = $_SESSION['username'] ?? '';
if (!can_access_settings_page($userRole, 'audit_retention')) {
    header('Location: /school-admin-dashboard/modules/settings/settings-dashboard.php?error=restricted');
    exit();
}

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
audit_retention_ensure_table($conn);
ensure_csrf_token();

$pageMessage = '';
$pageMessageType = 'success';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_audit_retention'])) {
    admin_require_post_csrf();
    $payload = [
        'live_retention_months' => $_POST['live_retention_months'] ?? 12,
        'review_frequency' => $_POST['review_frequency'] ?? 'Monthly',
        'archive_enabled' => !empty($_POST['archive_enabled']) ? 1 : 0,
        'archive_deletion_policy' => $_POST['archive_deletion_policy'] ?? 'Keep Archive',
        'notes' => $_POST['notes'] ?? '',
    ];

    if (audit_retention_save($conn, $payload)) {
        $pageMessage = 'Audit retention settings updated successfully.';
        audit_log(
            $conn,
            $username,
            'Updated audit retention settings',
            'Settings',
            'Retention months: ' . (int) $payload['live_retention_months'] . ' | Review: ' . (string) $payload['review_frequency'],
            'INFO'
        );
    } else {
        $pageMessage = 'Audit retention settings could not be saved.';
        $pageMessageType = 'danger';
    }
}

$retention = audit_retention_status($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audit Retention Settings - School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --main-bg:#f5f8fc; --card-bg:#fff; --navbar-bg:#23395d; --brand-dark:#23395d; }
        body { background: var(--main-bg); font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif; }
        .navbar { background: var(--navbar-bg) !important; box-shadow: 0 2px 12px rgba(33,57,93,0.08); }
        .navbar-brand, .navbar-nav .nav-link { color:#fff !important; }
        .dashboard-header { text-align:center; margin-top:36px; margin-bottom:18px; }
        .dashboard-header img { width:70px; height:70px; object-fit:contain; margin-bottom:6px; }
        .dashboard-header h1 { font-size:1.3rem; color:var(--brand-dark); font-weight:700; margin-bottom:0; }
        .page-title { color: var(--brand-dark); font-weight:700; }
        .section-card { background:var(--card-bg); border:1px solid rgba(81,127,164,0.15); border-radius:1rem; box-shadow:0 4px 18px rgba(33,57,93,0.07); margin-bottom:1.25rem; }
        .summary-stat { background:#f8fbff; border:1px solid rgba(81,127,164,0.16); border-radius:1rem; padding:1rem 1.1rem; height:100%; }
        .summary-stat .label { text-transform:uppercase; font-size:0.74rem; color:#6c757d; font-weight:700; }
        .summary-stat .value { font-size:1.3rem; font-weight:700; color:var(--brand-dark); }
    </style>
</head>
<body>
<?php render_admin_nav('settings'); ?>

<div class="dashboard-header">
    <img src="<?= htmlspecialchars($schoolLogo) ?>" alt="School Logo" class="mb-2 rounded shadow-sm">
    <h1><?= htmlspecialchars($schoolName) ?></h1>
</div>

<div class="container pb-5">
    <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-4">
        <div>
            <h2 class="page-title mb-1"><i class="fas fa-hourglass-half me-2"></i>Audit Retention Settings</h2>
            <p class="text-muted mb-0">Define how long audit logs stay in the live table before archive becomes the expected next step.</p>
        </div>
        <a href="/school-admin-dashboard/modules/settings/settings-dashboard.php" class="btn btn-outline-secondary"><i class="fas fa-arrow-left me-1"></i>Back to Settings</a>
    </div>

    <?php if ($pageMessage !== ''): ?>
        <div class="alert alert-<?= htmlspecialchars($pageMessageType) ?>"><?= htmlspecialchars($pageMessage) ?></div>
    <?php endif; ?>

    <div class="row g-3 mb-4">
        <div class="col-12 col-md-3"><div class="summary-stat"><div class="label">Live Retention</div><div class="value"><?= number_format((int) $retention['live_retention_months']) ?> mo</div></div></div>
        <div class="col-12 col-md-3"><div class="summary-stat"><div class="label">Default Cutoff</div><div class="value" style="font-size:1.05rem;"><?= htmlspecialchars((string) $retention['cutoff_date']) ?></div></div></div>
        <div class="col-12 col-md-3"><div class="summary-stat"><div class="label">Eligible To Archive</div><div class="value"><?= number_format((int) $retention['eligible_total']) ?></div></div></div>
        <div class="col-12 col-md-3"><div class="summary-stat"><div class="label">Review Frequency</div><div class="value" style="font-size:1.05rem;"><?= htmlspecialchars((string) $retention['review_frequency']) ?></div></div></div>
    </div>

    <div class="section-card p-4">
        <h5 class="mb-3">Retention Policy</h5>
        <form method="post">
            <?= csrf_input() ?>
            <input type="hidden" name="save_audit_retention" value="1">
            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Live retention months</label>
                    <input type="number" class="form-control" name="live_retention_months" min="1" max="60" value="<?= (int) $retention['live_retention_months'] ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Review frequency</label>
                    <select class="form-select" name="review_frequency">
                        <?php foreach (['Monthly', 'Quarterly', 'Manual Review'] as $option): ?>
                            <option value="<?= htmlspecialchars($option) ?>" <?= $retention['review_frequency'] === $option ? 'selected' : '' ?>><?= htmlspecialchars($option) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Archive deletion policy</label>
                    <select class="form-select" name="archive_deletion_policy">
                        <?php foreach (['Keep Archive', 'Manual Cleanup Later'] as $option): ?>
                            <option value="<?= htmlspecialchars($option) ?>" <?= $retention['archive_deletion_policy'] === $option ? 'selected' : '' ?>><?= htmlspecialchars($option) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <div class="form-check mt-4 pt-2">
                        <input class="form-check-input" type="checkbox" name="archive_enabled" value="1" id="archive_enabled" <?= !empty($retention['archive_enabled']) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="archive_enabled">Archive mode enabled</label>
                    </div>
                </div>
                <div class="col-12">
                    <label class="form-label">Operational notes</label>
                    <textarea class="form-control" name="notes" rows="4"><?= htmlspecialchars((string) $retention['notes']) ?></textarea>
                </div>
            </div>
            <div class="text-end mt-3">
                <button type="submit" class="btn btn-primary" onclick="return confirm('Save audit retention settings?');">
                    <i class="fas fa-save me-1"></i>Save Audit Retention
                </button>
            </div>
        </form>
    </div>

    <div class="section-card p-4">
        <h5 class="mb-3">Current Live Audit State</h5>
        <div class="row g-3">
            <div class="col-md-6">
                <div class="small text-muted mb-1">Oldest live audit log</div>
                <div class="fw-semibold"><?= htmlspecialchars((string) ($retention['oldest_live_log'] ?? '-')) ?></div>
            </div>
            <div class="col-md-6">
                <div class="small text-muted mb-1">Latest live audit log</div>
                <div class="fw-semibold"><?= htmlspecialchars((string) ($retention['latest_live_log'] ?? '-')) ?></div>
            </div>
        </div>
        <div class="mt-3 text-muted small">
            The audit archive tool now uses this retention window as its default cutoff. You can still override the date manually when archiving.
        </div>
    </div>
</div>
</body>
</html>
