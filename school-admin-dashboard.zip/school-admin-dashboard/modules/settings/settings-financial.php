<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/settings-permissions-roles.php';

$role = $_SESSION['role'] ?? '';
if (!can_view_settings_module($role)) {
    header('Location: /school-admin-dashboard/dashboard.php?error=settings_denied');
    exit();
}
if (is_specialized_staff_role($role)) {
    header('Location: /school-admin-dashboard/modules/settings/settings-dashboard.php?error=restricted');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Settings - Financial</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h4><i class="fas fa-coins"></i> Settings - Financial</h4>
        </div>
        <div class="card-body">
            <p>Configure currency, payment options, and fee settings.</p>
        </div>
    </div>
</div>
</body>
</html>
