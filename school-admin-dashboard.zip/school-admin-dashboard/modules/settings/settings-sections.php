<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require '../../config/database.php';
require_once 'settings-permissions-roles.php';
require_once 'settings-security.php';
require_once 'school-info-helper.php';
require_once 'school-year-helper.php';
require_once 'section-management-helper.php';

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$username = $_SESSION['username'] ?? '';
$role = $_SESSION['role'] ?? '';

if (!can_access_section_settings($role)) {
    header('Location: /school-admin-dashboard/dashboard.php?error=settings_denied');
    exit();
}

ensure_csrf_token();
section_management_ensure_table($conn);
school_year_ensure_table($conn);

$schoolYearOptions = school_year_filter_options($conn);
$activeSchoolYearLabel = school_year_get_active_label($conn);
$selectedSchoolYear = trim($_GET['school_year'] ?? $activeSchoolYearLabel);
if ($selectedSchoolYear === '') {
    $selectedSchoolYear = $activeSchoolYearLabel;
}
$statusFilter = trim((string) ($_GET['status_filter'] ?? 'active'));
if (!in_array($statusFilter, ['all', 'active', 'inactive'], true)) {
    $statusFilter = 'active';
}
$gradeOptions = section_management_grade_options();
$message = '';
$errorMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_require_post_csrf();

    $action = trim((string) ($_POST['section_action'] ?? ''));
    $sectionId = max(0, (int) ($_POST['section_id'] ?? 0));
    $formSchoolYear = trim((string) ($_POST['school_year_label'] ?? $selectedSchoolYear));
    $formGrade = trim((string) ($_POST['grade_level'] ?? ''));
    $formName = section_management_normalize_name((string) ($_POST['section_name'] ?? ''));

    if ($formSchoolYear === '') {
        $formSchoolYear = $activeSchoolYearLabel;
    }

    if ($action === 'add') {
        if (!in_array($formSchoolYear, $schoolYearOptions, true)) {
            $errorMessage = 'Please select a valid school year before adding a section.';
        } elseif (!section_management_is_valid_grade($formGrade)) {
            $errorMessage = 'Please choose a valid grade level.';
        } elseif ($formName === '') {
            $errorMessage = 'Enter a section name first, like Maple or Mahogany.';
        } elseif (section_management_name_exists($conn, $formSchoolYear, $formGrade, $formName)) {
            $errorMessage = sprintf('%s is already listed under %s for %s.', $formName, $formGrade, $formSchoolYear);
        } else {
            $stmt = $conn->prepare("INSERT INTO grade_sections (school_year_label, grade_level, section_name, is_active) VALUES (?, ?, ?, 1)");
            if ($stmt) {
                $stmt->bind_param('sss', $formSchoolYear, $formGrade, $formName);
                $stmt->execute();
                $stmt->close();
                $message = sprintf('Added %s under %s for %s.', $formName, $formGrade, $formSchoolYear);
                $selectedSchoolYear = $formSchoolYear;
            } else {
                $errorMessage = 'Could not add the section right now. Please try again.';
            }
        }
    } elseif (in_array($action, ['rename', 'toggle', 'delete'], true) && $sectionId > 0) {
        $loadStmt = $conn->prepare("SELECT id, school_year_label, grade_level, section_name, is_active FROM grade_sections WHERE id = ? LIMIT 1");
        $loadedSection = null;
        if ($loadStmt) {
            $loadStmt->bind_param('i', $sectionId);
            $loadStmt->execute();
            $loadedSection = $loadStmt->get_result()->fetch_assoc() ?: null;
            $loadStmt->close();
        }

        if (!$loadedSection) {
            $errorMessage = 'The selected section could not be found anymore.';
        } else {
            $selectedSchoolYear = (string) ($loadedSection['school_year_label'] ?? $selectedSchoolYear);
            $usageDetails = section_management_usage_details(
                $conn,
                (string) ($loadedSection['school_year_label'] ?? ''),
                (string) ($loadedSection['grade_level'] ?? ''),
                (string) ($loadedSection['section_name'] ?? '')
            );
            $usageCount = (int) ($usageDetails['total'] ?? 0);

            if ($action === 'rename') {
                if ($formName === '') {
                    $errorMessage = 'Enter the new section name first.';
                } elseif (section_management_name_exists($conn, (string) $loadedSection['school_year_label'], (string) $loadedSection['grade_level'], $formName, $sectionId)) {
                    $errorMessage = sprintf('%s already exists under %s for %s.', $formName, (string) $loadedSection['grade_level'], (string) $loadedSection['school_year_label']);
                } elseif ($usageCount > 0) {
                    $errorMessage = sprintf(
                        'Cannot rename %s because it is already used in %d student record(s) and %d pending registration(s). Deactivate it instead.',
                        (string) $loadedSection['section_name'],
                        (int) ($usageDetails['students'] ?? 0),
                        (int) ($usageDetails['pending'] ?? 0)
                    );
                } else {
                    $stmt = $conn->prepare("UPDATE grade_sections SET section_name = ? WHERE id = ?");
                    if ($stmt) {
                        $stmt->bind_param('si', $formName, $sectionId);
                        $stmt->execute();
                        $stmt->close();
                        $message = sprintf('Renamed %s to %s.', (string) $loadedSection['section_name'], $formName);
                    }
                }
            } elseif ($action === 'toggle') {
                $newActive = (int) (($loadedSection['is_active'] ?? 0) ? 0 : 1);
                $stmt = $conn->prepare("UPDATE grade_sections SET is_active = ? WHERE id = ?");
                if ($stmt) {
                    $stmt->bind_param('ii', $newActive, $sectionId);
                    $stmt->execute();
                    $stmt->close();
                    $message = $newActive === 1
                        ? sprintf('Reactivated %s for %s.', (string) $loadedSection['section_name'], (string) $loadedSection['grade_level'])
                        : sprintf('Deactivated %s for %s. Existing student records stay untouched.', (string) $loadedSection['section_name'], (string) $loadedSection['grade_level']);
                }
            } elseif ($action === 'delete') {
                if ($usageCount > 0) {
                    $errorMessage = sprintf(
                        'Cannot delete %s because it is already used in %d student record(s) and %d pending registration(s). Deactivate it instead.',
                        (string) $loadedSection['section_name'],
                        (int) ($usageDetails['students'] ?? 0),
                        (int) ($usageDetails['pending'] ?? 0)
                    );
                } else {
                    $stmt = $conn->prepare("DELETE FROM grade_sections WHERE id = ? LIMIT 1");
                    if ($stmt) {
                        $stmt->bind_param('i', $sectionId);
                        $stmt->execute();
                        $stmt->close();
                        $message = sprintf('Deleted unused section %s.', (string) $loadedSection['section_name']);
                    }
                }
            }
        }
    }
}

$sections = section_management_get_sections($conn, $selectedSchoolYear, '', false);
$groupedSections = [];
foreach ($gradeOptions as $grade) {
    $groupedSections[$grade] = [];
}
foreach ($sections as $row) {
    $row['usage_details'] = section_management_usage_details(
        $conn,
        (string) $row['school_year_label'],
        (string) $row['grade_level'],
        (string) $row['section_name']
    );
    $row['usage_count'] = (int) ($row['usage_details']['total'] ?? 0);

    if ($statusFilter === 'active' && (int) ($row['is_active'] ?? 0) !== 1) {
        continue;
    }
    if ($statusFilter === 'inactive' && (int) ($row['is_active'] ?? 0) !== 0) {
        continue;
    }

    $groupedSections[(string) $row['grade_level']][] = $row;
}

$summaryTotal = count($sections);
$summaryActive = count(array_filter($sections, static fn(array $row): bool => (int) ($row['is_active'] ?? 0) === 1));
$summaryInactive = $summaryTotal - $summaryActive;
$summaryGradesConfigured = count(array_filter($groupedSections, static fn(array $rows): bool => count($rows) > 0));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Section Management - School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background:#f5f8fc; font-family:'Segoe UI','Roboto','Arial',sans-serif; }
        .navbar { background:#23395d !important; }
        .navbar-brand, .navbar-nav .nav-link { color:#fff !important; font-size:1.08em; }
        .navbar-brand { font-weight:700; letter-spacing:1px; }
        .dashboard-header { text-align:center; margin-top:36px; margin-bottom:18px; }
        .dashboard-header img { width:70px; height:70px; object-fit:contain; margin-bottom:6px; }
        .dashboard-header h1 { font-size:1.3rem; color:#23395d; font-weight:700; margin-bottom:0; }
        .panel { background:#fff; border-radius:1rem; box-shadow:0 4px 18px rgba(33,57,93,.09); padding:1.25rem; margin-bottom:1rem; }
        .section-table td, .section-table th { vertical-align:middle; }
    </style>
</head>
<body>
<?php render_admin_nav('settings'); ?>
<div class="dashboard-header">
    <img src="<?= htmlspecialchars($schoolLogo) ?>" alt="School Logo" class="mb-2 rounded shadow-sm">
    <h1><?= htmlspecialchars($schoolName) ?></h1>
</div>

<div class="container">
    <div class="panel">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
            <div>
                <h2 class="h5 mb-1"><i class="fas fa-diagram-project me-2"></i>Section Management</h2>
                <div class="text-muted small">Manage grade sections per school year. Deactivate instead of deleting when the section was already used.</div>
            </div>
            <form method="get" class="d-flex flex-wrap align-items-center gap-2">
                <label class="small text-muted">School Year</label>
                <select name="school_year" class="form-select form-select-sm" onchange="this.form.submit()">
                    <?php foreach ($schoolYearOptions as $option): ?>
                        <option value="<?= htmlspecialchars($option) ?>" <?= $selectedSchoolYear === $option ? 'selected' : '' ?>><?= htmlspecialchars($option) ?></option>
                    <?php endforeach; ?>
                </select>
                <label class="small text-muted">Status</label>
                <select name="status_filter" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="active" <?= $statusFilter === 'active' ? 'selected' : '' ?>>Active only</option>
                    <option value="inactive" <?= $statusFilter === 'inactive' ? 'selected' : '' ?>>Inactive only</option>
                    <option value="all" <?= $statusFilter === 'all' ? 'selected' : '' ?>>All sections</option>
                </select>
            </form>
        </div>

        <div class="row g-3 mb-3">
            <div class="col-12 col-md-3">
                <div class="border rounded p-3 bg-light">
                    <div class="small text-muted text-uppercase">Visible Sections</div>
                    <div class="fw-bold fs-5"><?= number_format(array_sum(array_map('count', $groupedSections))) ?></div>
                </div>
            </div>
            <div class="col-12 col-md-3">
                <div class="border rounded p-3 bg-light">
                    <div class="small text-muted text-uppercase">Active</div>
                    <div class="fw-bold fs-5"><?= number_format($summaryActive) ?></div>
                </div>
            </div>
            <div class="col-12 col-md-3">
                <div class="border rounded p-3 bg-light">
                    <div class="small text-muted text-uppercase">Inactive</div>
                    <div class="fw-bold fs-5"><?= number_format($summaryInactive) ?></div>
                </div>
            </div>
            <div class="col-12 col-md-3">
                <div class="border rounded p-3 bg-light">
                    <div class="small text-muted text-uppercase">Grades Configured</div>
                    <div class="fw-bold fs-5"><?= number_format($summaryGradesConfigured) ?></div>
                </div>
            </div>
        </div>

        <?php if ($message !== ''): ?>
            <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        <?php if ($errorMessage !== ''): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($errorMessage) ?></div>
        <?php endif; ?>

        <form method="post" class="row g-3 align-items-end">
            <?= csrf_input() ?>
            <input type="hidden" name="section_action" value="add">
            <input type="hidden" name="school_year_label" value="<?= htmlspecialchars($selectedSchoolYear) ?>">
            <div class="col-md-4">
                <label class="form-label">Grade Level</label>
                <select name="grade_level" class="form-select" required>
                    <option value="">Select Grade</option>
                    <?php foreach ($gradeOptions as $grade): ?>
                        <option value="<?= htmlspecialchars($grade) ?>"><?= htmlspecialchars($grade) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-5">
                <label class="form-label">Section Name</label>
                <input type="text" name="section_name" class="form-control" placeholder="e.g. Maple" required>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary w-100"><i class="fas fa-plus me-1"></i>Add Section</button>
            </div>
        </form>
    </div>

    <?php foreach ($groupedSections as $grade => $rows): ?>
        <div class="panel">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h3 class="h6 mb-0"><?= htmlspecialchars($grade) ?></h3>
                <span class="badge text-bg-light"><?= count($rows) ?> section(s)</span>
            </div>

            <?php if (!$rows): ?>
                <div class="text-muted small">No sections configured yet for this grade in <?= htmlspecialchars($selectedSchoolYear) ?>.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-sm section-table align-middle">
                        <thead>
                            <tr>
                                <th>Section</th>
                                <th>Status</th>
                                <th>Usage Details</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rows as $row): ?>
                                <tr>
                                    <td>
                                        <form method="post" class="d-flex gap-2">
                                            <?= csrf_input() ?>
                                            <input type="hidden" name="section_action" value="rename">
                                            <input type="hidden" name="section_id" value="<?= (int) $row['id'] ?>">
                                            <input type="hidden" name="school_year_label" value="<?= htmlspecialchars($selectedSchoolYear) ?>">
                                            <input type="text" name="section_name" class="form-control form-control-sm" value="<?= htmlspecialchars((string) $row['section_name']) ?>">
                                            <button type="submit" class="btn btn-outline-primary btn-sm">Rename</button>
                                        </form>
                                    </td>
                                    <td>
                                        <span class="badge <?= ((int) $row['is_active'] === 1) ? 'text-bg-success' : 'text-bg-secondary' ?>">
                                            <?= ((int) $row['is_active'] === 1) ? 'Active' : 'Inactive' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="small">
                                            <div><strong>Total:</strong> <?= number_format((int) ($row['usage_count'] ?? 0)) ?></div>
                                            <div><strong>Students:</strong> <?= number_format((int) (($row['usage_details']['students'] ?? 0))) ?></div>
                                            <div><strong>Pending:</strong> <?= number_format((int) (($row['usage_details']['pending'] ?? 0))) ?></div>
                                        </div>
                                    </td>
                                    <td class="text-end">
                                        <div class="d-flex justify-content-end gap-2">
                                            <form method="post">
                                                <?= csrf_input() ?>
                                                <input type="hidden" name="section_action" value="toggle">
                                                <input type="hidden" name="section_id" value="<?= (int) $row['id'] ?>">
                                                <button type="submit" class="btn btn-outline-warning btn-sm">
                                                    <?= ((int) $row['is_active'] === 1) ? 'Deactivate' : 'Activate' ?>
                                                </button>
                                            </form>
                                            <?php if ((int) ($row['usage_count'] ?? 0) === 0): ?>
                                                <form method="post" onsubmit="return confirm('Delete this unused section?');">
                                                    <?= csrf_input() ?>
                                                    <input type="hidden" name="section_action" value="delete">
                                                    <input type="hidden" name="section_id" value="<?= (int) $row['id'] ?>">
                                                    <button type="submit" class="btn btn-outline-danger btn-sm">Delete</button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>
</body>
</html>
<?php $conn->close(); ?>
