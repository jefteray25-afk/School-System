<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/settings-permissions-roles.php';

$role = $_SESSION['role'] ?? '';
if (!can_access_settings_page($role, 'backup')) {
    header('Location: /school-admin-dashboard/modules/settings/settings-dashboard.php?error=restricted');
    exit();
}

// This legacy stub page is kept for compatibility; send users to the real page.
header('Location: /school-admin-dashboard/modules/settings/settings-backup-restore.php');
exit();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Settings - Backup & Restore</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h4><i class="fas fa-database"></i> Settings - Backup & Restore</h4>
        </div>
        <div class="card-body">
            <p>Settings - Backup and restore system data.</p>
        </div>
    </div>
</div>
</body>
</html>
