<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/admin-page-header.php';
require '../../config/database.php';
require_once 'settings-permissions-roles.php';
require_once 'settings-security.php';
require_once 'school-info-helper.php';
require_once 'school-year-helper.php';
require_once 'fee-grade-settings-helper.php';
require_once __DIR__ . '/../accounts/finance-adjustment-helper.php';
include_once __DIR__ . '/../audit/audit-helper.php';

$role = (string) ($_SESSION['role'] ?? '');
$username = (string) ($_SESSION['username'] ?? '');
if (!can_access_settings_page($role, 'finance_adjustments')) {
    header('Location: /school-admin-dashboard/modules/settings/settings-dashboard.php?error=settings_denied');
    exit();
}

finance_adjustment_ensure_tables($conn);
school_year_ensure_table($conn);
school_year_ensure_finance_columns($conn);

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$csrfToken = admin_csrf_token();
$pageMessage = '';
$pageMessageType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_require_post_csrf();
    $action = (string) ($_POST['adjustment_action'] ?? '');
    if ($action === 'save_template') {
        if (finance_adjustment_save_template($conn, $_POST, $username)) {
            $pageMessage = !empty($_POST['id']) ? 'Finance adjustment template updated.' : 'Finance adjustment template added.';
            audit_log($conn, $username, 'Saved finance adjustment template', 'Settings', 'Template: ' . (string) ($_POST['name'] ?? ''), 'INFO');
        } else {
            $pageMessage = 'Template could not be saved. Check name, school year, grades, and at least one fee type amount.';
            $pageMessageType = 'danger';
        }
    } elseif ($action === 'disable_template') {
        $templateId = (int) ($_POST['id'] ?? 0);
        if (finance_adjustment_disable_template($conn, $templateId, $username)) {
            $pageMessage = 'Finance adjustment template was disabled.';
            audit_log($conn, $username, 'Disabled finance adjustment template', 'Settings', 'Template ID: ' . $templateId, 'WARNING');
        } else {
            $pageMessage = 'Template could not be disabled.';
            $pageMessageType = 'danger';
        }
    }
}

$tablesReady = finance_adjustment_tables_ready($conn);
$templates = $tablesReady ? finance_adjustment_templates($conn, false) : [];
$gradeRows = fee_grade_catalog_rows($conn, false);
$accountTypes = finance_adjustment_account_type_options($conn);
$schoolYearOptions = school_year_finance_options($conn, 'fee');
$activeSchoolYear = school_year_get_active_label($conn);
if ($activeSchoolYear !== '' && !in_array($activeSchoolYear, $schoolYearOptions, true)) {
    array_unshift($schoolYearOptions, $activeSchoolYear);
}

function adjustment_template_form(
    array $template,
    array $gradeRows,
    array $accountTypes,
    array $schoolYearOptions,
    string $csrfToken,
    string $prefix
): void {
    $templateId = (int) ($template['id'] ?? 0);
    $selectedGrades = $template['grade_codes_list'] ?? [];
    $feeAmountMap = $template['fee_amounts_map'] ?? [];
    if (!is_array($feeAmountMap)) {
        $feeAmountMap = [];
    }
    $type = (string) ($template['adjustment_type'] ?? 'voucher');
    ?>
    <form method="post" class="template-form">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
        <input type="hidden" name="adjustment_action" value="save_template">
        <input type="hidden" name="rule_type" value="per_fee_amount">
        <input type="hidden" name="amount" value="0">
        <?php if ($templateId > 0): ?>
            <input type="hidden" name="id" value="<?= $templateId ?>">
        <?php endif; ?>
        <div class="form-grid">
        <div>
            <label class="form-label">Label / Name</label>
            <input type="text" name="name" class="form-control" maxlength="140" required value="<?= htmlspecialchars((string) ($template['name'] ?? '')) ?>" placeholder="Example: SHS Voucher">
        </div>
        <div>
            <label class="form-label">Type</label>
            <select name="adjustment_type" class="form-select">
                <?php foreach (finance_adjustment_types() as $value => $label): ?>
                    <option value="<?= htmlspecialchars($value) ?>" <?= $type === $value ? 'selected' : '' ?>><?= htmlspecialchars($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label class="form-label">School Year</label>
            <select name="school_year_label" class="form-select" required>
                <option value="">Select school year</option>
                <?php foreach ($schoolYearOptions as $schoolYear): ?>
                    <option value="<?= htmlspecialchars($schoolYear) ?>" <?= (string) ($template['school_year_label'] ?? '') === $schoolYear ? 'selected' : '' ?>><?= htmlspecialchars($schoolYear) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label class="form-label">Sort Order</label>
            <input type="number" name="sort_order" class="form-control" value="<?= (int) ($template['sort_order'] ?? 50) ?>">
        </div>
        <div>
            <label class="form-label d-block">Status</label>
            <div class="form-check status-toggle">
                <input class="form-check-input" type="checkbox" name="is_enabled" value="1" id="<?= htmlspecialchars($prefix) ?>Enabled" <?= !empty($template['is_enabled']) || $templateId === 0 ? 'checked' : '' ?>>
                <label class="form-check-label" for="<?= htmlspecialchars($prefix) ?>Enabled">Active / Available</label>
            </div>
        </div>
        <div>
            <label class="form-label">Notes</label>
            <input type="text" name="notes" class="form-control" maxlength="250" value="<?= htmlspecialchars((string) ($template['notes'] ?? '')) ?>" placeholder="Internal instruction">
        </div>
        </div>
        <div class="choice-grid">
        <div>
            <label class="form-label">Applicable Grades</label>
            <div class="option-box">
                <?php foreach ($gradeRows as $grade): ?>
                    <?php $gradeCode = (string) ($grade['grade_code'] ?? ''); ?>
                    <label class="form-check option-check">
                        <input class="form-check-input" type="checkbox" name="grade_codes[]" value="<?= htmlspecialchars($gradeCode) ?>" <?= in_array($gradeCode, $selectedGrades, true) ? 'checked' : '' ?>>
                        <span class="form-check-label"><?= htmlspecialchars((string) ($grade['label'] ?? '')) ?></span>
                    </label>
                <?php endforeach; ?>
            </div>
        </div>
        <div>
            <label class="form-label">Fee Type Amounts</label>
            <div class="fee-safety-note mb-2">
                <i class="fas fa-shield-alt me-1"></i>
                Only fee types that exist in the student's grade fee setup will apply. Missing fee rows are skipped, not created.
            </div>
            <div class="fee-amount-box">
                <?php foreach ($accountTypes as $feeType): ?>
                    <?php $feeAmount = $feeAmountMap[$feeType] ?? ''; ?>
                    <div class="fee-amount-row">
                        <label for="<?= htmlspecialchars($prefix) ?>Fee<?= md5($feeType) ?>"><?= htmlspecialchars($feeType) ?></label>
                        <input
                            id="<?= htmlspecialchars($prefix) ?>Fee<?= md5($feeType) ?>"
                            type="number"
                            step="0.01"
                            min="0"
                            name="fee_amounts[<?= htmlspecialchars($feeType) ?>]"
                            class="form-control"
                            value="<?= $feeAmount !== '' ? htmlspecialchars((string) $feeAmount) : '' ?>"
                            placeholder="As-is"
                        >
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="form-text">Blank or zero means this fee type stays as-is. Amount greater than zero applies to that fee type only.</div>
        </div>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-primary"><i class="fas fa-save me-1"></i><?= $templateId > 0 ? 'Save Template' : 'Add Template' ?></button>
        </div>
    </form>
    <?php
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance Adjustment Templates - School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg:#f5f8fc;
            --card-bg:#fff;
            --navbar-bg:#23395d;
            --brand-blue:#517fa4;
            --brand-dark:#23395d;
            --line:#d9e3ef;
            --soft:#edf4fb;
            --muted:#62748a;
        }
        body { background:var(--main-bg); font-family:'Segoe UI','Roboto','Arial',sans-serif; color:var(--brand-dark); }
        .navbar { background:var(--navbar-bg) !important; box-shadow:0 2px 12px rgba(33,57,93,0.08); }
        .navbar-brand, .navbar-nav .nav-link { color:#fff !important; }
        .dashboard-header {
            text-align:center;
            padding:1.5rem 1rem .75rem;
        }
        .dashboard-header img {
            width:78px;
            height:78px;
            object-fit:contain;
            background:#fff;
            border:1px solid var(--line);
            padding:5px;
        }
        .dashboard-header h1 {
            font-size:1.25rem;
            font-weight:800;
            margin:.5rem 0 0;
            color:var(--brand-dark);
        }
        .settings-shell {
            max-width:1120px;
        }
        .page-title { color:var(--brand-dark); font-weight:800; }
        .section-card {
            background:var(--card-bg);
            border:1px solid rgba(81,127,164,.18);
            border-radius:12px;
            box-shadow:0 8px 24px rgba(33,57,93,.06);
            margin-bottom:1.25rem;
        }
        .section-card h5 {
            font-weight:800;
            color:var(--brand-dark);
        }
        .template-form {
            display:grid;
            gap:1rem;
        }
        .form-grid {
            display:grid;
            grid-template-columns:minmax(220px,1.35fr) repeat(3,minmax(150px,1fr));
            gap:.9rem;
            align-items:start;
        }
        .choice-grid {
            display:grid;
            grid-template-columns:minmax(260px,.9fr) minmax(360px,1.35fr);
            gap:1rem;
        }
        .form-label {
            font-size:.82rem;
            font-weight:800;
            color:#42556b;
            margin-bottom:.35rem;
        }
        .form-control, .form-select {
            border-color:var(--line);
            border-radius:10px;
            min-height:38px;
        }
        .form-control:focus, .form-select:focus {
            border-color:var(--brand-blue);
            box-shadow:0 0 0 .2rem rgba(81,127,164,.14);
        }
        .form-text {
            color:var(--muted);
            font-size:.76rem;
        }
        .status-toggle {
            border:1px solid var(--line);
            border-radius:10px;
            min-height:38px;
            display:flex;
            align-items:center;
            padding:.45rem .75rem .45rem 2.15rem;
            background:#fbfdff;
        }
        .option-box {
            max-height:240px;
            overflow:auto;
            border:1px solid var(--line);
            border-radius:12px;
            background:#fbfdff;
            padding:.55rem;
        }
        .option-check {
            margin:.1rem 0;
            padding:.42rem .5rem .42rem 1.95rem;
            border-radius:8px;
            min-height:34px;
        }
        .option-check:hover { background:var(--soft); }
        .fee-amount-box {
            max-height:280px;
            overflow:auto;
            border:1px solid var(--line);
            border-radius:12px;
            background:#fbfdff;
            padding:.55rem;
            display:grid;
            gap:.45rem;
        }
        .fee-amount-row {
            display:grid;
            grid-template-columns:minmax(130px,1fr) minmax(120px,150px);
            gap:.7rem;
            align-items:center;
            border:1px solid transparent;
            border-radius:10px;
            padding:.45rem .5rem;
        }
        .fee-amount-row:hover {
            background:var(--soft);
            border-color:#dbe7f3;
        }
        .fee-amount-row label {
            font-size:.88rem;
            font-weight:700;
            color:#34465b;
            margin:0;
        }
        .fee-amount-row .form-control {
            min-height:34px;
            text-align:right;
        }
        .fee-safety-note {
            border:1px solid #bfdbfe;
            border-radius:10px;
            background:#eff6ff;
            color:#1e3a8a;
            font-size:.82rem;
            font-weight:700;
            padding:.55rem .7rem;
        }
        .form-actions {
            display:flex;
            justify-content:flex-end;
            padding-top:.25rem;
        }
        .template-pill { border-radius:999px; font-weight:700; }
        .accordion-item {
            border-color:var(--line);
            overflow:hidden;
        }
        .accordion-button {
            gap:.4rem;
            flex-wrap:wrap;
        }
        .accordion-button:not(.collapsed) {
            background:var(--soft);
            color:var(--brand-dark);
            box-shadow:none;
        }
        .template-empty {
            border:1px dashed #cbd8e6;
            background:#f8fbff;
            border-radius:12px;
            padding:1rem;
            color:var(--muted);
        }
        @media (max-width: 992px) {
            .form-grid, .choice-grid {
                grid-template-columns:1fr 1fr;
            }
        }
        @media (max-width: 640px) {
            .form-grid, .choice-grid {
                grid-template-columns:1fr;
            }
            .form-actions {
                justify-content:stretch;
            }
            .form-actions .btn {
                width:100%;
            }
        }
    </style>
</head>
<body>
<?php render_admin_nav('settings'); ?>
<?php render_school_page_header($schoolName, $schoolLogo); ?>

<div class="container settings-shell pb-5">
    <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-4">
        <div>
            <h2 class="page-title mb-1"><i class="fas fa-tags me-2"></i>Finance Adjustment Templates</h2>
            <p class="text-muted mb-0">Create voucher, subsidy, discount, and grant shortcuts for Manage Finance Exceptions.</p>
        </div>
        <div class="d-flex gap-2 flex-wrap">
            <a href="/school-admin-dashboard/modules/financial/finance-adjustment-review.php" class="btn btn-outline-primary">
                <i class="fas fa-table me-1"></i>Review Applied
            </a>
            <a href="/school-admin-dashboard/modules/settings/settings-dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-1"></i>Back to Settings
            </a>
        </div>
    </div>

    <?php if ($pageMessage !== ''): ?>
        <div class="alert alert-<?= htmlspecialchars($pageMessageType) ?>"><?= htmlspecialchars($pageMessage) ?></div>
    <?php endif; ?>

    <?php if (!$tablesReady): ?>
        <div class="alert alert-warning">Finance adjustment schema is not ready. Run the migration tool first.</div>
    <?php else: ?>
        <div class="alert alert-info">
            Templates only define available shortcuts. They do not auto-apply to students and they do not create payments or receipts.
        </div>

        <div class="section-card p-4">
            <div class="mb-3">
                <h5 class="mb-1">Add New Template</h5>
                <div class="text-muted small">Choose the school year, grades, and fee types this shortcut can adjust.</div>
            </div>
            <?php adjustment_template_form([
                'adjustment_type' => 'voucher',
                'school_year_label' => $activeSchoolYear,
                'rule_type' => 'fixed_amount',
                'amount' => 0,
                'is_enabled' => 1,
                'sort_order' => 50,
                'grade_codes_list' => [],
                'covered_fee_types_list' => [],
                'fee_amounts_map' => [],
            ], $gradeRows, $accountTypes, $schoolYearOptions, $csrfToken, 'newTemplate'); ?>
        </div>

        <div class="section-card p-4">
            <div class="mb-3">
                <h5 class="mb-1">Current Templates</h5>
                <div class="text-muted small">Open a template to edit its label, covered fees, amount, or availability.</div>
            </div>
            <?php if ($templates): ?>
                <div class="accordion" id="financeAdjustmentAccordion">
                    <?php foreach ($templates as $template): ?>
                        <?php $templateId = (int) $template['id']; ?>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="adjustmentHeading<?= $templateId ?>">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#adjustmentCollapse<?= $templateId ?>">
                                    <span class="fw-bold me-2"><?= htmlspecialchars((string) $template['name']) ?></span>
                                    <span class="badge text-bg-primary template-pill me-2"><?= htmlspecialchars(finance_adjustment_types()[(string) $template['adjustment_type']] ?? 'Adjustment') ?></span>
                                    <span class="badge <?= !empty($template['is_enabled']) ? 'text-bg-success' : 'text-bg-secondary' ?> template-pill">
                                        <?= !empty($template['is_enabled']) ? 'Active' : 'Disabled' ?>
                                    </span>
                                </button>
                            </h2>
                            <div id="adjustmentCollapse<?= $templateId ?>" class="accordion-collapse collapse" data-bs-parent="#financeAdjustmentAccordion">
                                <div class="accordion-body">
                                    <?php adjustment_template_form($template, $gradeRows, $accountTypes, $schoolYearOptions, $csrfToken, 'template' . $templateId); ?>
                                    <form method="post" class="mt-2" onsubmit="return confirm('Disable this finance adjustment template?');">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                        <input type="hidden" name="adjustment_action" value="disable_template">
                                        <input type="hidden" name="id" value="<?= $templateId ?>">
                                        <button type="submit" class="btn btn-outline-danger"><i class="fas fa-ban me-1"></i>Disable</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="template-empty">No finance adjustment templates yet.</div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
