<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require '../../config/database.php';
require_once 'settings-permissions-roles.php';
require_once 'school-info-helper.php';
require_once 'school-year-helper.php';
include_once($_SERVER['DOCUMENT_ROOT'] . '/school-admin-dashboard/modules/audit/audit-helper.php');

$role = $_SESSION['role'] ?? '';
$username = $_SESSION['username'] ?? 'unknown';
if (!can_access_school_year_settings($role)) {
    header('Location: /school-admin-dashboard/modules/settings/settings-dashboard.php?error=restricted');
    exit();
}

school_year_ensure_table($conn);
$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$message = '';
$messageType = 'success';

function school_year_requires_critical_confirmation(string $action): bool
{
    return in_array($action, ['set_active', 'assign_existing', 'assign_existing_finance'], true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!school_year_verify_csrf($_POST['csrf_token'] ?? '')) {
        $message = 'Invalid request token. Please refresh the page and try again.';
        $messageType = 'danger';
    } else {
        $action = $_POST['school_year_action'] ?? '';
        $schoolYearId = (int) ($_POST['school_year_id'] ?? 0);
        $confirmPhrase = trim((string) ($_POST['critical_confirm_phrase'] ?? ''));

        if (school_year_requires_critical_confirmation($action) && $confirmPhrase !== 'CONFIRM') {
            $message = 'Type CONFIRM before applying this critical school year action.';
            $messageType = 'danger';
        } elseif ($action === 'add') {
            $result = school_year_add($conn, (string) ($_POST['label'] ?? ''));
            $message = $result['message'];
            $messageType = $result['success'] ? 'success' : 'danger';
            if ($result['success']) {
                audit_log($conn, $username, 'Added school year', 'Settings', 'Label: ' . school_year_normalize_label((string) ($_POST['label'] ?? '')));
            }
        } elseif ($action === 'set_active' && $schoolYearId > 0) {
            $result = school_year_set_active($conn, $schoolYearId);
            $message = $result['message'];
            $messageType = $result['success'] ? 'success' : 'danger';
            if ($result['success']) {
                audit_log($conn, $username, 'Updated active school year', 'Settings', 'School Year ID: ' . $schoolYearId);
            }
        } elseif (($action === 'open_enrollment' || $action === 'close_enrollment') && $schoolYearId > 0) {
            $result = school_year_set_enrollment_open($conn, $schoolYearId, $action === 'open_enrollment');
            $message = $result['message'];
            $messageType = $result['success'] ? 'success' : 'danger';
            if ($result['success']) {
                audit_log($conn, $username, $action === 'open_enrollment' ? 'Opened school year enrollment' : 'Closed school year enrollment', 'Settings', 'School Year ID: ' . $schoolYearId);
            }
        } elseif ($action === 'assign_existing') {
            $selectedLabel = (string) ($_POST['assign_school_year_label'] ?? '');
            $assignScope = (string) ($_POST['assign_scope'] ?? 'students');
            $result = school_year_assign_existing_records($conn, $selectedLabel, $assignScope);
            $message = $result['message'];
            $messageType = $result['success'] ? 'success' : 'danger';
            if ($result['success']) {
                audit_log(
                    $conn,
                    $username,
                    'Assigned school year to existing records',
                    'Settings',
                    'Label: ' . school_year_normalize_label($selectedLabel)
                    . ' | Scope: ' . $assignScope
                    . ' | Students: ' . (int) ($result['updated_students'] ?? 0)
                    . ' | Pending: ' . (int) ($result['updated_pending'] ?? 0)
                );
            }
        } elseif ($action === 'assign_existing_finance') {
            $selectedLabel = (string) ($_POST['assign_finance_school_year_label'] ?? '');
            $assignScope = (string) ($_POST['assign_finance_scope'] ?? 'all');
            $result = school_year_assign_existing_finance($conn, $selectedLabel, $assignScope);
            $message = $result['message'];
            $messageType = $result['success'] ? 'success' : 'danger';
            if ($result['success']) {
                audit_log(
                    $conn,
                    $username,
                    'Assigned school year to existing finance records',
                    'Settings',
                    'Label: ' . school_year_normalize_label($selectedLabel)
                    . ' | Scope: ' . $assignScope
                    . ' | Fees: ' . (int) ($result['updated_fees'] ?? 0)
                    . ' | Accounts: ' . (int) ($result['updated_accounts'] ?? 0)
                    . ' | Payments: ' . (int) ($result['updated_payments'] ?? 0)
                );
            }
        }
    }
}

$schoolYears = school_year_get_all($conn);
$activeSchoolYear = school_year_get_active($conn);
$csrfToken = school_year_csrf_token();
$unassignedStudentCount = school_year_count_unassigned($conn, 'students');
$unassignedPendingCount = school_year_count_unassigned($conn, 'student_registration_pending');
$unassignedFeeCount = school_year_count_unassigned($conn, 'fee');
$unassignedAccountCount = school_year_count_unassigned($conn, 'accounts');
$unassignedPaymentCount = school_year_count_unassigned($conn, 'payments');
$financeHealth = school_year_finance_health_summary($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>School Years</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --page-bg: #eef3f9;
            --card-bg: #ffffff;
            --navy: #23395d;
            --blue: #2f74c8;
            --soft-blue: #eaf3ff;
            --soft-border: #d6e3f2;
            --text-muted: #66788d;
            --success-bg: #e8f7ef;
            --success-text: #157347;
            --warning-bg: #fff4e5;
            --warning-text: #9a6700;
        }
        body {
            background: radial-gradient(circle at top left, #f8fbff 0, #eef3f9 58%, #e6edf6 100%);
            font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
        }
        .navbar {
            background: linear-gradient(90deg, #203b63 0%, #274d79 48%, #2f5f92 100%) !important;
        }
        .navbar-brand, .navbar-nav .nav-link { color: #fff !important; }
        .page-shell {
            max-width: 1600px;
            margin: 0 auto;
            padding: 28px 18px 42px;
        }
        .page-header {
            display: flex;
            align-items: center;
            gap: 16px;
            margin: 10px 0 22px;
            padding: 20px 22px;
            background: rgba(255,255,255,0.9);
            border: 1px solid rgba(214,227,242,0.9);
            border-radius: 24px;
            box-shadow: 0 16px 38px rgba(35,57,93,0.08);
        }
        .page-header img {
            width: 72px;
            height: 72px;
            object-fit: contain;
            border-radius: 18px;
            background: #fff;
            border: 1px solid #d8e5f3;
            padding: 6px;
            margin-bottom: 0;
        }
        .page-kicker {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 12px;
            border-radius: 999px;
            background: var(--soft-blue);
            color: var(--blue);
            border: 1px solid var(--soft-border);
            font-size: .78rem;
            font-weight: 800;
            letter-spacing: .05em;
            text-transform: uppercase;
            margin-bottom: 8px;
        }
        .page-header h1 {
            font-size: 1.45rem;
            color: var(--navy);
            font-weight: 800;
            margin-bottom: 2px;
        }
        .page-header p {
            margin: 0;
            color: var(--text-muted);
        }
        .section-card {
            border: 1px solid rgba(214,227,242,0.9);
            border-radius: 22px;
            box-shadow: 0 14px 34px rgba(35,57,93,0.07);
            background: rgba(255,255,255,0.97);
            overflow: hidden;
        }
        .section-card .card-body { padding: 22px; }
        .section-title {
            color: var(--navy);
            font-size: 1.06rem;
            font-weight: 800;
            margin-bottom: 6px;
        }
        .section-note {
            color: var(--text-muted);
            font-size: .92rem;
            margin-bottom: 16px;
            line-height: 1.5;
        }
        .active-pill { background: var(--success-bg); color: var(--success-text); border: 1px solid #b7e4c7; }
        .closed-pill { background: var(--warning-bg); color: var(--warning-text); border: 1px solid #ffe0a3; }
        .health-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 12px; }
        .health-card {
            background: linear-gradient(180deg, #fbfdff 0%, #f4f8fd 100%);
            border: 1px solid #dce8f7;
            border-radius: 16px;
            padding: 14px 15px;
        }
        .health-label { font-size: 0.78rem; text-transform: uppercase; letter-spacing: 0.05em; color: #66788d; margin-bottom: 7px; font-weight: 700; }
        .health-value { font-size: 1.42rem; font-weight: 800; color: var(--navy); line-height: 1; }
        .health-note { font-size: 0.9rem; color: #607388; margin-top: 7px; }
        .form-label { font-weight: 700; color: var(--navy); font-size: .92rem; }
        .form-text { color: var(--text-muted); }
        .school-year-form-card {
            background: linear-gradient(180deg, #ffffff 0%, #f7fbff 100%);
            border: 1px solid #dce8f7;
            border-radius: 18px;
            padding: 16px;
        }
        .active-year-box {
            background: #f8fbff;
            border: 1px solid #d8e5f3;
            border-radius: 18px;
            padding: 16px 18px;
        }
        .active-year-label {
            color: var(--text-muted);
            font-size: .8rem;
            text-transform: uppercase;
            letter-spacing: .05em;
            font-weight: 700;
            margin-bottom: 6px;
        }
        .active-year-value {
            color: var(--navy);
            font-size: 1.1rem;
            font-weight: 800;
        }
        .danger-note { color: #b42318; font-size: .86rem; }
        .count-stack { display: grid; gap: 10px; }
        .count-row {
            display: flex;
            justify-content: space-between;
            gap: 10px;
            font-size: .9rem;
            color: var(--navy);
            padding: 10px 12px;
            border-radius: 14px;
            background: #f8fbff;
            border: 1px solid #dce8f7;
        }
        .count-row strong { font-weight: 800; }
        .school-years-table { margin-bottom: 0; }
        .school-years-table thead th {
            background: #f4f8fd;
            color: var(--navy);
            text-transform: uppercase;
            font-size: .8rem;
            letter-spacing: .05em;
            border-bottom: 1px solid #d8e5f3;
        }
        .school-years-table td, .school-years-table th { vertical-align: middle; }
        .school-years-table tbody tr:hover { background: #f9fbff; }
        .year-label { display: flex; flex-direction: column; gap: 3px; }
        .year-label strong { color: var(--navy); font-size: .98rem; }
        .year-sub { color: var(--text-muted); font-size: .84rem; }
        .action-stack { display: flex; flex-wrap: wrap; gap: 8px; }
        .action-stack form { margin: 0; }
        .small-muted { color: var(--text-muted); font-size: .86rem; }
        @media (max-width: 768px) {
            .page-header { flex-direction: column; text-align: center; }
        }
    </style>
</head>
<body>
<?php render_admin_nav('settings'); ?>

<div class="page-shell">
    <div class="page-header">
        <img src="<?= htmlspecialchars($schoolLogo) ?>" alt="School Logo">
        <div>
            <div class="page-kicker"><i class="fas fa-calendar-days"></i> School Year Control</div>
            <h1><?= htmlspecialchars($schoolName) ?></h1>
            <p>Manage the active school year used for registrations, filtering, and future year preparation.</p>
        </div>
    </div>

    <?php if ($message !== ''): ?>
        <div class="alert alert-<?= htmlspecialchars($messageType) ?>"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <div class="card section-card mb-4">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-3">
                <div>
                    <h5 class="mb-1"><i class="fas fa-wave-square text-primary me-2"></i>Wave 2.5 Finance Consistency</h5>
                    <div class="text-muted small">Final health view for school-year finance alignment before you consider this wave fully clean.</div>
                </div>
                <?php if (!empty($financeHealth['is_ready'])): ?>
                    <span class="badge text-bg-success">Ready / Clean</span>
                <?php else: ?>
                    <span class="badge text-bg-warning text-dark">Needs Review</span>
                <?php endif; ?>
            </div>
            <div class="health-grid mb-3">
                <div class="health-card">
                    <div class="health-label">Active Year</div>
                    <div class="health-value" style="font-size:1rem;"><?= htmlspecialchars($financeHealth['active_label']) ?></div>
                    <div class="health-note">Current school-year finance scope</div>
                </div>
                <div class="health-card">
                    <div class="health-label">Unassigned Fees</div>
                    <div class="health-value"><?= (int) $financeHealth['unassigned_fees'] ?></div>
                    <div class="health-note">Fee rows still missing school year</div>
                </div>
                <div class="health-card">
                    <div class="health-label">Unassigned Accounts</div>
                    <div class="health-value"><?= (int) $financeHealth['unassigned_accounts'] ?></div>
                    <div class="health-note">Account rows still missing school year</div>
                </div>
                <div class="health-card">
                    <div class="health-label">Unassigned Payments</div>
                    <div class="health-value"><?= (int) $financeHealth['unassigned_payments'] ?></div>
                    <div class="health-note">Payment rows still missing school year</div>
                </div>
                <div class="health-card">
                    <div class="health-label">Account Mismatch</div>
                    <div class="health-value"><?= (int) $financeHealth['mismatched_accounts'] ?></div>
                    <div class="health-note">Accounts not matching linked student year</div>
                </div>
                <div class="health-card">
                    <div class="health-label">Payment Mismatch</div>
                    <div class="health-value"><?= (int) $financeHealth['mismatched_payments'] ?></div>
                    <div class="health-note">Payments not matching linked account year</div>
                </div>
            </div>
            <div class="health-grid">
                <div class="health-card">
                    <div class="health-label">Active-Year Fees</div>
                    <div class="health-value"><?= (int) $financeHealth['active_year_fees'] ?></div>
                    <div class="health-note">Fee setups assigned to the active year</div>
                </div>
                <div class="health-card">
                    <div class="health-label">Active-Year Accounts</div>
                    <div class="health-value"><?= (int) $financeHealth['active_year_accounts'] ?></div>
                    <div class="health-note">Accounts currently tagged to the active year</div>
                </div>
                <div class="health-card">
                    <div class="health-label">Active-Year Payments</div>
                    <div class="health-value"><?= (int) $financeHealth['active_year_payments'] ?></div>
                    <div class="health-note">Payments currently tagged to the active year</div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-12 col-lg-4">
            <div class="card section-card">
                <div class="card-body">
                    <div class="section-title"><i class="fas fa-calendar-plus text-primary me-2"></i>Add School Year</div>
                    <div class="section-note">Prepare the next school years here. The system already supports the ready-made range, and you can still add more manually anytime.</div>
                    <div class="school-year-form-card mb-3">
                        <form method="post">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                            <input type="hidden" name="school_year_action" value="add">
                            <div class="mb-3">
                                <label class="form-label">School Year Label</label>
                                <input type="text" name="label" class="form-control" placeholder="SY 2026-2027" maxlength="30" required>
                                <div class="form-text">Use a clear format like <code>SY 2026-2027</code>.</div>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-plus me-1"></i>Add School Year
                            </button>
                        </form>
                    </div>
                    <div class="active-year-box">
                        <div class="active-year-label">Current Active School Year</div>
                        <div class="active-year-value"><?= htmlspecialchars($activeSchoolYear['label'] ?? 'None') ?></div>
                        <div class="small-muted mt-1">Enrollment is <?= !empty($activeSchoolYear['enrollment_open']) ? 'open' : 'closed' ?> for the active year.</div>
                    </div>
                </div>
            </div>

            <div class="card section-card mt-4">
                <div class="card-body">
                    <div class="section-title"><i class="fas fa-layer-group text-primary me-2"></i>Assign Existing Records</div>
                    <div class="section-note">Use this one-time bridge for older records created before Wave 1. Only blank school year values will be updated.</div>
                    <div class="count-stack mb-3">
                        <div class="count-row"><span>Students without school year</span><strong><?= (int) $unassignedStudentCount ?></strong></div>
                        <div class="count-row"><span>Pending without school year</span><strong><?= (int) $unassignedPendingCount ?></strong></div>
                    </div>
                    <form method="post">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                        <input type="hidden" name="school_year_action" value="assign_existing">
                        <div class="mb-3">
                            <label class="form-label">Type CONFIRM to proceed</label>
                            <input type="text" name="critical_confirm_phrase" class="form-control" placeholder="CONFIRM" autocomplete="off">
                            <div class="danger-note">Required because this bulk action updates existing student and pending records.</div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Assign To School Year</label>
                            <select name="assign_school_year_label" class="form-select" required>
                                <option value="">Select school year</option>
                                <?php foreach ($schoolYears as $schoolYear): ?>
                                    <option value="<?= htmlspecialchars($schoolYear['label']) ?>" <?= !empty($activeSchoolYear['label']) && $activeSchoolYear['label'] === $schoolYear['label'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($schoolYear['label']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Scope</label>
                            <select name="assign_scope" class="form-select" required>
                                <option value="students">Existing students only</option>
                                <option value="pending">Existing pending only</option>
                                <option value="both">Students and pending</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-outline-primary w-100" <?= ($unassignedStudentCount + $unassignedPendingCount) === 0 ? 'disabled' : '' ?>>
                            <i class="fas fa-wand-magic-sparkles me-1"></i>Assign Missing School Years
                        </button>
                    </form>
                </div>
            </div>

            <div class="card section-card mt-4">
                <div class="card-body">
                    <div class="section-title"><i class="fas fa-money-check-dollar text-primary me-2"></i>Assign Existing Finance</div>
                    <div class="section-note">This is for old fee, account, and payment rows created before Wave 2. It fixes school year reporting and invoice filtering.</div>
                    <div class="count-stack mb-3">
                        <div class="count-row"><span>Fees without school year</span><strong><?= (int) $unassignedFeeCount ?></strong></div>
                        <div class="count-row"><span>Accounts without school year</span><strong><?= (int) $unassignedAccountCount ?></strong></div>
                        <div class="count-row"><span>Payments without school year</span><strong><?= (int) $unassignedPaymentCount ?></strong></div>
                    </div>
                    <form method="post">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                        <input type="hidden" name="school_year_action" value="assign_existing_finance">
                        <div class="mb-3">
                            <label class="form-label">Type CONFIRM to proceed</label>
                            <input type="text" name="critical_confirm_phrase" class="form-control" placeholder="CONFIRM" autocomplete="off">
                            <div class="danger-note">Required because this bulk action updates fee, account, and payment school-year tags.</div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Assign Blank Finance Records To</label>
                            <select name="assign_finance_school_year_label" class="form-select" required>
                                <option value="">Select school year</option>
                                <?php foreach ($schoolYears as $schoolYear): ?>
                                    <option value="<?= htmlspecialchars($schoolYear['label']) ?>" <?= !empty($activeSchoolYear['label']) && $activeSchoolYear['label'] === $schoolYear['label'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($schoolYear['label']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-text">Accounts and payments will prefer the linked student's school year when available, then fall back to the selected label.</div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Scope</label>
                            <select name="assign_finance_scope" class="form-select" required>
                                <option value="all">Fees, accounts, and payments</option>
                                <option value="fees">Fees only</option>
                                <option value="accounts">Accounts only</option>
                                <option value="payments">Payments only</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-outline-primary w-100" <?= ($unassignedFeeCount + $unassignedAccountCount + $unassignedPaymentCount) === 0 ? 'disabled' : '' ?>>
                            <i class="fas fa-briefcase me-1"></i>Assign Missing Finance School Years
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-12 col-lg-8">
            <div class="card section-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <div class="section-title mb-1"><i class="fas fa-calendar-days text-primary me-2"></i>School Year List</div>
                            <div class="section-note mb-0">Review all configured school years, set the active year, and control enrollment from one place.</div>
                        </div>
                        <span class="small-muted"><?= count($schoolYears) ?> configured</span>
                    </div>
                    <div class="table-responsive">
                        <table class="table school-years-table align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Label</th>
                                    <th>Status</th>
                                    <th>Enrollment</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($schoolYears as $schoolYear): ?>
                                <tr>
                                    <td><div class="year-label"><strong><?= htmlspecialchars($schoolYear['label']) ?></strong><span class="year-sub">School year record</span></div></td>
                                    <td>
                                        <?php if ((int) $schoolYear['is_active'] === 1): ?>
                                            <span class="badge active-pill">Active</span>
                                        <?php else: ?>
                                            <span class="badge text-bg-light border">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ((int) $schoolYear['enrollment_open'] === 1): ?>
                                            <span class="badge text-bg-success">Open</span>
                                        <?php else: ?>
                                            <span class="badge closed-pill">Closed</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-muted small"><?= htmlspecialchars(date('F j, Y', strtotime((string) $schoolYear['created_at']))) ?></td>
                                    <td>
                                        <div class="action-stack">
                                            <?php if ((int) $schoolYear['is_active'] !== 1): ?>
                                                <form method="post" onsubmit="return confirmSchoolYearSetActive(this);">
                                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                                    <input type="hidden" name="school_year_action" value="set_active">
                                                    <input type="hidden" name="school_year_id" value="<?= (int) $schoolYear['id'] ?>">
                                                    <input type="hidden" name="critical_confirm_phrase" value="">
                                                    <button type="submit" class="btn btn-sm btn-outline-primary">Set Active</button>
                                                </form>
                                            <?php endif; ?>
                                            <form method="post">
                                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                                <input type="hidden" name="school_year_action" value="<?= (int) $schoolYear['enrollment_open'] === 1 ? 'close_enrollment' : 'open_enrollment' ?>">
                                                <input type="hidden" name="school_year_id" value="<?= (int) $schoolYear['id'] ?>">
                                                <button type="submit" class="btn btn-sm btn-outline-secondary">
                                                    <?= (int) $schoolYear['enrollment_open'] === 1 ? 'Close Enrollment' : 'Open Enrollment' ?>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
function confirmSchoolYearSetActive(form) {
    const input = window.prompt('Type CONFIRM to set this school year as active.');
    if (input === null) {
        return false;
    }
    form.querySelector('input[name="critical_confirm_phrase"]').value = input.trim();
    return true;
}
</script>
<?= admin_session_warning_script() ?>
</body>
</html>
<?php $conn->close(); ?>
