<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require_once __DIR__ . '/../../includes/ui.php';
require '../../config/database.php';
require_once 'settings-permissions-roles.php';
require_once 'settings-security.php';
require_once 'school-info-helper.php';
require_once 'school-year-helper.php';
require_once 'section-management-helper.php';
require_once 'section-location-helper.php';

$role = (string) ($_SESSION['role'] ?? '');
if (!can_access_section_location_settings($role)) { header('Location: /school-admin-dashboard/dashboard.php?error=settings_denied'); exit(); }
ensure_csrf_token();
$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$activeYear = school_year_get_active_label($conn);
$selectedYear = trim((string) ($_GET['school_year'] ?? $_POST['school_year_label'] ?? $activeYear));
$yearOptions = school_year_filter_options($conn);
if (!in_array($selectedYear, $yearOptions, true)) { $selectedYear = $activeYear; }
$message = ''; $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    if (!section_location_table_exists($conn)) {
        $error = schema_migration_missing_schema_message('Section Locations');
    } elseif (section_location_save($conn, $_POST, (string) ($_SESSION['username'] ?? 'unknown'))) {
        $message = 'Section location assignment saved.';
    } else {
        $error = 'Choose a school year, grade level, and section before saving.';
    }
}

$sectionMap = section_management_get_sections_by_grade($conn, $selectedYear, false);
$studentSections = $conn->prepare("SELECT grade, TRIM(COALESCE(section, '')) AS section_name FROM students WHERE school_year_label = ? AND TRIM(COALESCE(grade, '')) <> '' AND TRIM(COALESCE(section, '')) <> '' GROUP BY grade, TRIM(COALESCE(section, '')) ORDER BY grade, section_name");
if ($studentSections) { $studentSections->bind_param('s', $selectedYear); $studentSections->execute(); $res=$studentSections->get_result(); while($row=$res->fetch_assoc()){ $g=(string)$row['grade']; $s=(string)$row['section_name']; if(!isset($sectionMap[$g]))$sectionMap[$g]=[]; if(!in_array($s,$sectionMap[$g],true))$sectionMap[$g][]=$s; } $studentSections->close(); }
foreach ($sectionMap as &$sections) { sort($sections, SORT_NATURAL | SORT_FLAG_CASE); } unset($sections);
$assignments = section_location_list($conn, $selectedYear);
?>
<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Section Locations | Settings</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"><link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet"><?php ui_css_link(); ?><style>body{background:#f5f8fc}.dashboard-header{text-align:center;margin:28px 0 18px}.dashboard-header img{width:62px;height:62px;object-fit:contain}.panel{background:#fff;border-radius:1rem;box-shadow:0 4px 18px rgba(33,57,93,.09);padding:1.25rem;margin-bottom:1rem}.location-table td,.location-table th{vertical-align:middle}</style></head><body>
<?php render_admin_nav('settings'); ?><div class="dashboard-header"><img src="<?= htmlspecialchars($schoolLogo) ?>" alt="School Logo"><h1 class="h5 mt-2 mb-0"><?= htmlspecialchars($schoolName) ?></h1></div><main class="container"><section class="panel"><div class="d-flex justify-content-between flex-wrap gap-3 align-items-center mb-3"><div><h2 class="h5 mb-1"><i class="fas fa-location-dot me-2"></i>Section Locations</h2><p class="text-muted small mb-0">These assignments appear in the public Student Search Portal. They do not edit student records.</p></div><form method="get"><select name="school_year" class="form-select form-select-sm" onchange="this.form.submit()"><?php foreach($yearOptions as $year): ?><option value="<?= htmlspecialchars($year) ?>" <?= $year===$selectedYear?'selected':'' ?>><?= htmlspecialchars($year) ?></option><?php endforeach; ?></select></form></div>
<?php if(!section_location_table_exists($conn)): ?><div class="alert alert-warning mb-3"><strong>Migration required.</strong> Run <code>C:\xampp\php\php.exe tools\migrate.php</code> once before saving assignments.</div><?php endif; ?><?php if($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?><?php if($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="post" class="row g-3 align-items-end"><?= csrf_input() ?><input type="hidden" name="school_year_label" value="<?= htmlspecialchars($selectedYear) ?>"><div class="col-md-3"><label class="form-label">Grade Level</label><select id="grade" name="grade_level" class="form-select" required><option value="">Select grade</option><?php foreach(section_management_grade_options() as $grade): if(!empty($sectionMap[$grade])): ?><option value="<?= htmlspecialchars($grade) ?>"><?= htmlspecialchars($grade) ?></option><?php endif; endforeach; ?></select></div><div class="col-md-3"><label class="form-label">Section</label><select id="section" name="section_name" class="form-select" required disabled><option value="">Select grade first</option></select></div><div class="col-md-3"><label class="form-label">Adviser</label><input name="adviser_name" class="form-control" maxlength="150" placeholder="Optional"></div><div class="col-md-3"><label class="form-label">Building</label><input name="building_name" class="form-control" maxlength="150" placeholder="Optional"></div><div class="col-md-3"><label class="form-label">Floor</label><input name="floor_name" class="form-control" maxlength="100" placeholder="Optional"></div><div class="col-md-3"><label class="form-label">Room</label><input name="room_name" class="form-control" maxlength="100" placeholder="e.g. 203"></div><div class="col-md-3"><button class="btn btn-primary w-100" <?= section_location_table_exists($conn)?'':'disabled' ?>><i class="fas fa-save me-1"></i> Save Assignment</button></div></form></section>
<section class="panel"><h3 class="h6 mb-3">Saved assignments — <?= htmlspecialchars($selectedYear) ?></h3><div class="table-responsive"><table class="table location-table"><thead><tr><th>Grade / Section</th><th>Adviser</th><th>Location</th><th>Updated</th></tr></thead><tbody><?php foreach($assignments as $row): ?><tr><td><strong><?= htmlspecialchars($row['grade_level']) ?></strong><div class="small text-muted"><?= htmlspecialchars($row['section_name']) ?></div></td><td><?= htmlspecialchars($row['adviser_name']?:'—') ?></td><td><?= htmlspecialchars(implode(' · ',array_filter([$row['building_name'],$row['floor_name'],$row['room_name']]))?:'—') ?></td><td class="small text-muted"><?= htmlspecialchars($row['updated_at']) ?></td></tr><?php endforeach; if(!$assignments): ?><tr><td colspan="4" class="text-center text-muted py-4">No section locations saved yet.</td></tr><?php endif; ?></tbody></table></div></section></main>
<script>const map=<?= json_encode($sectionMap, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>,grade=document.getElementById('grade'),section=document.getElementById('section');grade.addEventListener('change',()=>{const items=map[grade.value]||[];section.disabled=!items.length;section.innerHTML='<option value="">'+(items.length?'Select section':'No section available')+'</option>'+items.map(x=>'<option value="'+x.replace(/"/g,'&quot;')+'">'+x+'</option>').join('');});</script></body></html>
