<?php
require __DIR__ . '/../../includes/admin-session.php';
admin_session_require_login();
require_once __DIR__ . '/../../includes/admin-nav.php';
require '../../config/database.php';
require_once 'settings-permissions-roles.php';
require_once 'school-info-helper.php';

$role = $_SESSION['role'] ?? '';
if (!can_access_settings_page($role, 'maintenance')) {
    header('Location: /school-admin-dashboard/modules/settings/settings-dashboard.php?error=restricted');
    exit();
}

$schoolInfo = get_school_information($conn);
$schoolName = school_info_display_name($schoolInfo);
$schoolLogo = school_info_logo_path($schoolInfo);
$username = $_SESSION['username'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintenance Tools - School Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --main-bg: #f5f8fc;
            --card-bg: #fff;
            --navbar-bg: #23395d;
            --brand-blue: #517fa4;
            --brand-dark: #23395d;
        }
        body { background: var(--main-bg); font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif; }
        .navbar { background: var(--navbar-bg) !important; box-shadow: 0 2px 12px rgba(33,57,93,0.08); }
        .navbar-brand, .navbar-nav .nav-link { color: #fff !important; }
        .dashboard-header { text-align: center; margin-top: 36px; margin-bottom: 18px; }
        .dashboard-header img { width: 70px; height: 70px; object-fit: contain; margin-bottom: 6px; }
        .dashboard-header h1 { font-size: 1.3rem; color: var(--brand-dark); font-weight: 700; margin-bottom: 0; }
        .page-wrap { max-width: 1180px; margin: 0 auto 40px; }
        .hero-card {
            background: linear-gradient(135deg, #fffaf0 0%, #f6fbff 100%);
            border: 1px solid rgba(81,127,164,0.15);
            border-radius: 1.2rem;
            box-shadow: 0 10px 26px rgba(33,57,93,0.08);
            padding: 1.4rem;
            margin-bottom: 1.4rem;
        }
        .tool-card {
            background: var(--card-bg);
            border: 1px solid rgba(81,127,164,0.15);
            border-radius: 1.1rem;
            box-shadow: 0 8px 20px rgba(33,57,93,0.08);
            transition: box-shadow .18s, border-color .18s, transform .18s;
        }
        .tool-card:hover {
            box-shadow: 0 0 10px rgba(81,127,164,0.25);
            border-color: var(--brand-blue);
            transform: translateY(-2px);
        }
        .tool-icon {
            width: 58px;
            height: 58px;
            border-radius: 16px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: #eaf3ff;
            color: var(--brand-blue);
            font-size: 1.45rem;
            margin-bottom: 0.9rem;
        }
        .warning-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            background: #fff3cd;
            color: #8a5a00;
            border: 1px solid #ffe69c;
            border-radius: 999px;
            padding: 0.35rem 0.75rem;
            font-size: 0.86rem;
            font-weight: 600;
        }
        .dashboard-btn-bottom {
            position: fixed;
            left: 28px;
            bottom: 28px;
            z-index: 1060;
            background: #e7f0fd;
            color: var(--brand-blue);
            border: 2px solid #bcdfff;
            box-shadow: 0 5px 16px rgba(33,57,93,0.13);
            border-radius: 50%;
            width: 58px;
            height: 58px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.55em;
            text-decoration: none;
        }
    </style>
</head>
<body>
<?php render_admin_nav('settings'); ?>

<div class="dashboard-header">
    <img src="<?= htmlspecialchars($schoolLogo) ?>" alt="School Logo" class="mb-2 rounded shadow-sm">
    <h1><?= htmlspecialchars($schoolName) ?></h1>
</div>

<div class="container page-wrap">
    <div class="hero-card">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">
            <div>
                <h2 class="mb-2"><i class="fas fa-screwdriver-wrench me-2 text-primary"></i>Maintenance Tools</h2>
                <p class="text-muted mb-2">This area is for controlled cleanup and repair work only. These tools are intentionally separated from normal settings because they can affect historical records and require deliberate review.</p>
                <span class="warning-chip"><i class="fas fa-triangle-exclamation"></i> Super Admin maintenance area</span>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-12 col-md-6">
            <a href="/school-admin-dashboard/modules/settings/settings-duplicate-lrn-cleanup.php" class="text-decoration-none text-dark">
                <div class="tool-card h-100 p-4">
                    <div class="tool-icon"><i class="fas fa-broom"></i></div>
                    <h3 class="h5 mb-2">Duplicate LRN Cleanup</h3>
                    <p class="text-muted mb-3">Review historical duplicate LRNs and resolve only the safe records that should be cleaned.</p>
                    <div class="small text-muted">Best used for registrar/data integrity repair, not day-to-day settings.</div>
                </div>
            </a>
        </div>
        <div class="col-12 col-md-6">
            <a href="/school-admin-dashboard/modules/settings/settings-duplicate-account-cleanup.php" class="text-decoration-none text-dark">
                <div class="tool-card h-100 p-4">
                    <div class="tool-icon"><i class="fas fa-layer-group"></i></div>
                    <h3 class="h5 mb-2">Duplicate Account Cleanup</h3>
                    <p class="text-muted mb-3">Review duplicate fee-account rows and remove only the safe extras after checking payment impact.</p>
                    <div class="small text-muted">Best used for finance repair and old duplicate account correction.</div>
                </div>
            </a>
        </div>
    </div>
</div>

<a href="/school-admin-dashboard/modules/settings/settings-dashboard.php" class="dashboard-btn-bottom" title="Back to Settings">
    <i class="fas fa-arrow-left"></i>
</a>
</body>
</html>
<?php $conn->close(); ?>
