<?php

require_once __DIR__ . '/backup-settings-helper.php';
require_once __DIR__ . '/../../includes/schema-migration.php';

function upload_storage_default_values(): array
{
    $projectRoot = dirname(__DIR__, 2);

    return [
        'student_photo_dir' => $projectRoot . '/uploads/photos',
        'bulk_photo_inbox_dir' => $projectRoot . '/uploads/photo-inbox',
        'bulk_photo_staging_dir' => $projectRoot . '/uploads/photo-staging',
        'bulk_photo_quarantine_dir' => $projectRoot . '/uploads/photo-quarantine',
        'bulk_photo_source_max_mb' => 5,
        'bulk_photo_source_max_width' => 5000,
        'bulk_photo_source_max_height' => 5000,
        'requirement_document_dir' => $projectRoot . '/uploads/requirement-documents',
        'student_photo_max_mb' => 2,
        'requirement_document_max_mb' => 10,
        'student_photo_max_width' => 1600,
        'student_photo_max_height' => 1600,
        'student_photo_jpeg_quality' => 85,
    ];
}

function upload_storage_column_exists(mysqli $conn, string $columnName): bool
{
    $columnName = trim($columnName);
    if ($columnName === '') {
        return false;
    }

    $stmt = $conn->prepare(
        'SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1'
    );
    if (!$stmt) {
        return false;
    }

    $tableName = 'upload_storage_settings';
    $stmt->bind_param('ss', $tableName, $columnName);
    $stmt->execute();
    $exists = $stmt->get_result()->num_rows > 0;
    $stmt->close();

    return $exists;
}

function upload_storage_bulk_photo_schema_ready(mysqli $conn): bool
{
    foreach ([
        'bulk_photo_inbox_dir',
        'bulk_photo_staging_dir',
        'bulk_photo_quarantine_dir',
        'bulk_photo_source_max_mb',
        'bulk_photo_source_max_width',
        'bulk_photo_source_max_height',
    ] as $columnName) {
        if (!upload_storage_column_exists($conn, $columnName)) {
            return false;
        }
    }

    return true;
}

function upload_storage_ensure_table(mysqli $conn): void
{
    if (!schema_migration_mode_enabled()) {
        return;
    }
    $sql = "CREATE TABLE IF NOT EXISTS upload_storage_settings (
        id TINYINT NOT NULL PRIMARY KEY,
        student_photo_dir VARCHAR(255) NOT NULL,
        bulk_photo_inbox_dir VARCHAR(255) NOT NULL,
        bulk_photo_staging_dir VARCHAR(255) NOT NULL,
        bulk_photo_quarantine_dir VARCHAR(255) NOT NULL,
        bulk_photo_source_max_mb INT NOT NULL DEFAULT 5,
        bulk_photo_source_max_width INT NOT NULL DEFAULT 5000,
        bulk_photo_source_max_height INT NOT NULL DEFAULT 5000,
        requirement_document_dir VARCHAR(255) NOT NULL,
        student_photo_max_mb INT NOT NULL DEFAULT 2,
        requirement_document_max_mb INT NOT NULL DEFAULT 10,
        student_photo_max_width INT NOT NULL DEFAULT 1600,
        student_photo_max_height INT NOT NULL DEFAULT 1600,
        student_photo_jpeg_quality INT NOT NULL DEFAULT 85,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    schema_migration_attempt($conn, $sql);

    $bulkColumns = [
        'bulk_photo_inbox_dir' => "VARCHAR(255) NOT NULL DEFAULT ''",
        'bulk_photo_staging_dir' => "VARCHAR(255) NOT NULL DEFAULT ''",
        'bulk_photo_quarantine_dir' => "VARCHAR(255) NOT NULL DEFAULT ''",
        'bulk_photo_source_max_mb' => 'INT NOT NULL DEFAULT 5',
        'bulk_photo_source_max_width' => 'INT NOT NULL DEFAULT 5000',
        'bulk_photo_source_max_height' => 'INT NOT NULL DEFAULT 5000',
    ];
    foreach ($bulkColumns as $columnName => $definition) {
        if (!upload_storage_column_exists($conn, $columnName)) {
            schema_migration_attempt($conn, "ALTER TABLE upload_storage_settings ADD COLUMN {$columnName} {$definition}");
        }
    }

    $countResult = $conn->query("SELECT COUNT(*) AS total FROM upload_storage_settings");
    $count = $countResult ? (int) (($countResult->fetch_assoc()['total'] ?? 0)) : 0;
    if ($countResult) {
        $countResult->close();
    }

    if ($count === 0) {
        $defaults = upload_storage_default_values();
        $stmt = $conn->prepare(
            "INSERT INTO upload_storage_settings
            (id, student_photo_dir, bulk_photo_inbox_dir, bulk_photo_staging_dir, bulk_photo_quarantine_dir, bulk_photo_source_max_mb, bulk_photo_source_max_width, bulk_photo_source_max_height, requirement_document_dir, student_photo_max_mb, requirement_document_max_mb, student_photo_max_width, student_photo_max_height, student_photo_jpeg_quality)
            VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );
        if ($stmt) {
            $stmt->bind_param(
                'ssssiiisiiiii',
                $defaults['student_photo_dir'],
                $defaults['bulk_photo_inbox_dir'],
                $defaults['bulk_photo_staging_dir'],
                $defaults['bulk_photo_quarantine_dir'],
                $defaults['bulk_photo_source_max_mb'],
                $defaults['bulk_photo_source_max_width'],
                $defaults['bulk_photo_source_max_height'],
                $defaults['requirement_document_dir'],
                $defaults['student_photo_max_mb'],
                $defaults['requirement_document_max_mb'],
                $defaults['student_photo_max_width'],
                $defaults['student_photo_max_height'],
                $defaults['student_photo_jpeg_quality']
            );
            $stmt->execute();
            $stmt->close();
        }
    }
}

function upload_storage_normalize_dir(string $dir, string $fallback): string
{
    $dir = trim($dir);
    if ($dir === '') {
        $dir = $fallback;
    }

    return rtrim(str_replace('\\', '/', $dir), '/');
}

function upload_storage_get(mysqli $conn): array
{
    upload_storage_ensure_table($conn);
    $defaults = upload_storage_default_values();
    $result = $conn->query("SELECT * FROM upload_storage_settings WHERE id = 1 LIMIT 1");
    if ($result && $row = $result->fetch_assoc()) {
        $result->close();

        return [
            'student_photo_dir' => upload_storage_normalize_dir((string) ($row['student_photo_dir'] ?? ''), $defaults['student_photo_dir']),
            'bulk_photo_inbox_dir' => upload_storage_normalize_dir((string) ($row['bulk_photo_inbox_dir'] ?? ''), $defaults['bulk_photo_inbox_dir']),
            'bulk_photo_staging_dir' => upload_storage_normalize_dir((string) ($row['bulk_photo_staging_dir'] ?? ''), $defaults['bulk_photo_staging_dir']),
            'bulk_photo_quarantine_dir' => upload_storage_normalize_dir((string) ($row['bulk_photo_quarantine_dir'] ?? ''), $defaults['bulk_photo_quarantine_dir']),
            'bulk_photo_source_max_mb' => max(1, min(25, (int) ($row['bulk_photo_source_max_mb'] ?? $defaults['bulk_photo_source_max_mb']))),
            'bulk_photo_source_max_width' => max(600, min(8000, (int) ($row['bulk_photo_source_max_width'] ?? $defaults['bulk_photo_source_max_width']))),
            'bulk_photo_source_max_height' => max(600, min(8000, (int) ($row['bulk_photo_source_max_height'] ?? $defaults['bulk_photo_source_max_height']))),
            'requirement_document_dir' => upload_storage_normalize_dir((string) ($row['requirement_document_dir'] ?? ''), $defaults['requirement_document_dir']),
            'student_photo_max_mb' => max(1, min(10, (int) ($row['student_photo_max_mb'] ?? $defaults['student_photo_max_mb']))),
            'requirement_document_max_mb' => max(1, min(25, (int) ($row['requirement_document_max_mb'] ?? $defaults['requirement_document_max_mb']))),
            'student_photo_max_width' => max(600, min(5000, (int) ($row['student_photo_max_width'] ?? $defaults['student_photo_max_width']))),
            'student_photo_max_height' => max(600, min(5000, (int) ($row['student_photo_max_height'] ?? $defaults['student_photo_max_height']))),
            'student_photo_jpeg_quality' => max(60, min(95, (int) ($row['student_photo_jpeg_quality'] ?? $defaults['student_photo_jpeg_quality']))),
        ];
    }

    return $defaults;
}

function upload_storage_save(mysqli $conn, array $payload): bool
{
    upload_storage_ensure_table($conn);
    $defaults = upload_storage_default_values();

    $studentPhotoDir = upload_storage_normalize_dir((string) ($payload['student_photo_dir'] ?? ''), $defaults['student_photo_dir']);
    $bulkPhotoInboxDir = upload_storage_normalize_dir((string) ($payload['bulk_photo_inbox_dir'] ?? ''), $defaults['bulk_photo_inbox_dir']);
    $bulkPhotoStagingDir = upload_storage_normalize_dir((string) ($payload['bulk_photo_staging_dir'] ?? ''), $defaults['bulk_photo_staging_dir']);
    $bulkPhotoQuarantineDir = upload_storage_normalize_dir((string) ($payload['bulk_photo_quarantine_dir'] ?? ''), $defaults['bulk_photo_quarantine_dir']);
    $bulkPhotoSourceMaxMb = max(1, min(25, (int) ($payload['bulk_photo_source_max_mb'] ?? $defaults['bulk_photo_source_max_mb'])));
    $bulkPhotoSourceMaxWidth = max(600, min(8000, (int) ($payload['bulk_photo_source_max_width'] ?? $defaults['bulk_photo_source_max_width'])));
    $bulkPhotoSourceMaxHeight = max(600, min(8000, (int) ($payload['bulk_photo_source_max_height'] ?? $defaults['bulk_photo_source_max_height'])));
    $requirementDocumentDir = upload_storage_normalize_dir((string) ($payload['requirement_document_dir'] ?? ''), $defaults['requirement_document_dir']);
    $studentPhotoMaxMb = max(1, min(10, (int) ($payload['student_photo_max_mb'] ?? $defaults['student_photo_max_mb'])));
    $requirementDocumentMaxMb = max(1, min(25, (int) ($payload['requirement_document_max_mb'] ?? $defaults['requirement_document_max_mb'])));
    $studentPhotoMaxWidth = max(600, min(5000, (int) ($payload['student_photo_max_width'] ?? $defaults['student_photo_max_width'])));
    $studentPhotoMaxHeight = max(600, min(5000, (int) ($payload['student_photo_max_height'] ?? $defaults['student_photo_max_height'])));
    $studentPhotoJpegQuality = max(60, min(95, (int) ($payload['student_photo_jpeg_quality'] ?? $defaults['student_photo_jpeg_quality'])));

    $stmt = $conn->prepare(
        "UPDATE upload_storage_settings
         SET student_photo_dir = ?, bulk_photo_inbox_dir = ?, bulk_photo_staging_dir = ?, bulk_photo_quarantine_dir = ?, bulk_photo_source_max_mb = ?, bulk_photo_source_max_width = ?, bulk_photo_source_max_height = ?, requirement_document_dir = ?, student_photo_max_mb = ?, requirement_document_max_mb = ?, student_photo_max_width = ?, student_photo_max_height = ?, student_photo_jpeg_quality = ?
         WHERE id = 1"
    );
    if (!$stmt) {
        return false;
    }

    $stmt->bind_param(
        'ssssiiisiiiii',
        $studentPhotoDir,
        $bulkPhotoInboxDir,
        $bulkPhotoStagingDir,
        $bulkPhotoQuarantineDir,
        $bulkPhotoSourceMaxMb,
        $bulkPhotoSourceMaxWidth,
        $bulkPhotoSourceMaxHeight,
        $requirementDocumentDir,
        $studentPhotoMaxMb,
        $requirementDocumentMaxMb,
        $studentPhotoMaxWidth,
        $studentPhotoMaxHeight,
        $studentPhotoJpegQuality
    );
    $success = $stmt->execute();
    $stmt->close();

    if ($success) {
        upload_storage_ensure_directories($conn);
    }

    return $success;
}

function upload_storage_ensure_directories(mysqli $conn): void
{
    $settings = upload_storage_get($conn);
    foreach ([
        $settings['student_photo_dir'],
        $settings['bulk_photo_inbox_dir'],
        $settings['bulk_photo_staging_dir'],
        $settings['bulk_photo_quarantine_dir'],
        $settings['requirement_document_dir'],
    ] as $dir) {
        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }
    }
}

function upload_storage_relative_path(string $path): string
{
    $path = trim(str_replace('\\', '/', $path));
    $path = ltrim($path, '/');
    $parts = array_filter(explode('/', $path), static function ($segment): bool {
        return $segment !== '' && $segment !== '.' && $segment !== '..';
    });

    return implode('/', $parts);
}

function upload_storage_random_token(int $length = 8): string
{
    try {
        return strtolower(bin2hex(random_bytes(max(4, (int) ceil($length / 2)))));
    } catch (Throwable $e) {
        return strtolower(substr(sha1(uniqid((string) mt_rand(), true)), 0, max(8, $length)));
    }
}

function upload_storage_detect_mime_type(string $absolutePath): string
{
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) {
            $mime = (string) finfo_file($finfo, $absolutePath);
            finfo_close($finfo);
            if ($mime !== '') {
                return $mime;
            }
        }
    }

    return (string) mime_content_type($absolutePath);
}

function upload_storage_is_dangerous_extension(string $extension): bool
{
    return in_array(strtolower($extension), [
        'php', 'php3', 'php4', 'php5', 'phtml', 'phar',
        'exe', 'com', 'bat', 'cmd', 'ps1', 'vbs', 'js', 'sh',
        'cgi', 'pl', 'dll', 'msi', 'scr',
    ], true);
}

function student_photo_allowed_extensions(): array
{
    return ['jpg', 'jpeg', 'png', 'gif'];
}

function student_photo_allowed_mime_types(): array
{
    return ['image/jpeg', 'image/png', 'image/gif'];
}

function student_photo_storage_name(string $lastname, string $firstname, string $grade, string $extension): string
{
    $lastnameClean = strtolower(preg_replace('/[^a-z0-9]+/i', '', $lastname));
    $firstInitial = strtolower(substr(preg_replace('/[^a-z0-9]+/i', '', $firstname), 0, 1));
    $gradeClean = strtolower(str_replace(' ', '', trim($grade)));
    $baseName = ($lastnameClean !== '' ? $lastnameClean : 'student') . ($firstInitial !== '' ? $firstInitial : 'x') . ($gradeClean !== '' ? $gradeClean : 'grade');
    return $baseName . '_' . upload_storage_random_token(10) . '.' . strtolower($extension);
}

function student_photo_storage_settings(mysqli $conn): array
{
    return upload_storage_get($conn);
}

function student_photo_base_dir(mysqli $conn): string
{
    $settings = student_photo_storage_settings($conn);
    return upload_storage_normalize_dir((string) $settings['student_photo_dir'], upload_storage_default_values()['student_photo_dir']);
}

function student_photo_max_bytes(mysqli $conn): int
{
    $settings = student_photo_storage_settings($conn);
    return max(1, (int) $settings['student_photo_max_mb']) * 1024 * 1024;
}

function student_photo_relative_dir(string $grade, string $prefix = ''): string
{
    $gradeFolder = strtolower(trim($grade));
    $gradeFolder = preg_replace('/[^a-z0-9 _-]+/i', '', $gradeFolder);
    $gradeFolder = trim((string) $gradeFolder);
    if ($gradeFolder === '') {
        $gradeFolder = 'unassigned';
    }

    $parts = [];
    if ($prefix !== '') {
        $parts[] = trim($prefix, '/');
    }
    $parts[] = $gradeFolder;

    return upload_storage_relative_path(implode('/', $parts));
}

function student_photo_prepare_target(mysqli $conn, string $grade, string $lastname, string $firstname, string $extension, string $prefix = ''): array
{
    upload_storage_ensure_directories($conn);
    $relativeDir = student_photo_relative_dir($grade, $prefix);
    $targetDir = student_photo_base_dir($conn) . '/' . $relativeDir;
    if (!is_dir($targetDir) && !@mkdir($targetDir, 0775, true) && !is_dir($targetDir)) {
        throw new RuntimeException('Failed to prepare photo folder.');
    }

    $filename = student_photo_storage_name($lastname, $firstname, $grade, $extension);
    $counter = 1;
    while (file_exists($targetDir . '/' . $filename)) {
        $filename = pathinfo($filename, PATHINFO_FILENAME) . '_' . $counter . '.' . $extension;
        $counter++;
    }

    return [
        'target_dir' => $targetDir,
        'relative_path' => $relativeDir . '/' . $filename,
        'absolute_path' => $targetDir . '/' . $filename,
    ];
}

function student_photo_optimize_image(string $absolutePath, string $extension, array $settings): void
{
    if (!function_exists('getimagesize')) {
        return;
    }

    $imageInfo = @getimagesize($absolutePath);
    if (!$imageInfo) {
        return;
    }

    $type = (int) ($imageInfo[2] ?? 0);
    $width = (int) ($imageInfo[0] ?? 0);
    $height = (int) ($imageInfo[1] ?? 0);
    if ($width <= 0 || $height <= 0) {
        return;
    }

    $maxWidth = (int) ($settings['student_photo_max_width'] ?? 1600);
    $maxHeight = (int) ($settings['student_photo_max_height'] ?? 1600);
    $quality = (int) ($settings['student_photo_jpeg_quality'] ?? 85);
    $shouldResize = $width > $maxWidth || $height > $maxHeight;

    switch ($type) {
        case IMAGETYPE_JPEG:
            if (!function_exists('imagecreatefromjpeg') || !function_exists('imagejpeg')) {
                return;
            }
            $source = @imagecreatefromjpeg($absolutePath);
            break;
        case IMAGETYPE_PNG:
            if (!function_exists('imagecreatefrompng') || !function_exists('imagepng')) {
                return;
            }
            $source = @imagecreatefrompng($absolutePath);
            break;
        default:
            return;
    }

    if (!$source) {
        return;
    }

    $target = $source;
    if ($shouldResize && function_exists('imagecreatetruecolor') && function_exists('imagecopyresampled')) {
        $ratio = min($maxWidth / $width, $maxHeight / $height);
        $newWidth = max(1, (int) floor($width * $ratio));
        $newHeight = max(1, (int) floor($height * $ratio));
        $target = imagecreatetruecolor($newWidth, $newHeight);

        if ($type === IMAGETYPE_PNG) {
            imagealphablending($target, false);
            imagesavealpha($target, true);
            $transparent = imagecolorallocatealpha($target, 0, 0, 0, 127);
            imagefilledrectangle($target, 0, 0, $newWidth, $newHeight, $transparent);
        }

        imagecopyresampled($target, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
    }

    if ($type === IMAGETYPE_JPEG) {
        @imagejpeg($target, $absolutePath, $quality);
    } elseif ($type === IMAGETYPE_PNG) {
        @imagepng($target, $absolutePath, 6);
    }

    if ($target !== $source && (is_object($target) || is_resource($target))) {
        imagedestroy($target);
    }
    if (is_object($source) || is_resource($source)) {
        imagedestroy($source);
    }
}

function student_photo_store_uploaded_file(mysqli $conn, array $file, string $grade, string $lastname, string $firstname, string $prefix = ''): array
{
    if (!isset($file['error']) || (int) $file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['path' => '', 'error' => ''];
    }

    if ((int) $file['error'] !== UPLOAD_ERR_OK) {
        return ['path' => '', 'error' => 'Error uploading photo.'];
    }

    if ((int) ($file['size'] ?? 0) > student_photo_max_bytes($conn)) {
        $maxMb = student_photo_storage_settings($conn)['student_photo_max_mb'] ?? 2;
        return ['path' => '', 'error' => 'Photo must not exceed ' . (int) $maxMb . 'MB.'];
    }

    $extension = strtolower(pathinfo((string) ($file['name'] ?? ''), PATHINFO_EXTENSION));
    if ($extension === '' || upload_storage_is_dangerous_extension($extension)) {
        return ['path' => '', 'error' => 'This photo file type is not allowed.'];
    }

    if (!in_array($extension, student_photo_allowed_extensions(), true)) {
        return ['path' => '', 'error' => 'Invalid photo format. Only JPG, JPEG, PNG, GIF allowed.'];
    }

    try {
        $target = student_photo_prepare_target($conn, $grade, $lastname, $firstname, $extension, $prefix);
    } catch (Throwable $e) {
        return ['path' => '', 'error' => $e->getMessage() ?: 'Failed to prepare photo folder.'];
    }

    if (!move_uploaded_file((string) ($file['tmp_name'] ?? ''), $target['absolute_path'])) {
        return ['path' => '', 'error' => 'Failed to save photo.'];
    }

    $detectedMime = upload_storage_detect_mime_type($target['absolute_path']);
    if (!in_array($detectedMime, student_photo_allowed_mime_types(), true)) {
        @unlink($target['absolute_path']);
        return ['path' => '', 'error' => 'The uploaded photo content is not a valid JPG, PNG, or GIF image.'];
    }

    $imageInfo = @getimagesize($target['absolute_path']);
    if (!$imageInfo) {
        @unlink($target['absolute_path']);
        return ['path' => '', 'error' => 'The uploaded photo could not be verified as a readable image.'];
    }

    student_photo_optimize_image($target['absolute_path'], $extension, student_photo_storage_settings($conn));

    return ['path' => $target['relative_path'], 'error' => ''];
}

function student_photo_absolute_path(mysqli $conn, ?string $relativePath): string
{
    $relativePath = upload_storage_relative_path((string) $relativePath);
    if ($relativePath === '') {
        return '';
    }

    return student_photo_base_dir($conn) . '/' . $relativePath;
}

function student_photo_delete(mysqli $conn, ?string $relativePath): void
{
    $absolutePath = student_photo_absolute_path($conn, $relativePath);
    if ($absolutePath !== '' && file_exists($absolutePath)) {
        @unlink($absolutePath);
    }
}

function student_photo_public_url(?string $relativePath): string
{
    $relativePath = upload_storage_relative_path((string) $relativePath);
    if ($relativePath === '') {
        return '/school-admin-dashboard/assets/img/default-profile.png';
    }

    return '/school-admin-dashboard/modules/students/student-photo-file.php?path=' . rawurlencode($relativePath);
}

function student_photo_move_between_folders(mysqli $conn, ?string $photoPath, string $grade, string $lastname, string $firstname): string
{
    $photoPath = upload_storage_relative_path((string) $photoPath);
    if ($photoPath === '') {
        return '';
    }

    $absoluteSource = student_photo_absolute_path($conn, $photoPath);
    if ($absoluteSource === '' || !file_exists($absoluteSource)) {
        return $photoPath;
    }

    $extension = strtolower(pathinfo($absoluteSource, PATHINFO_EXTENSION));
    try {
        $target = student_photo_prepare_target($conn, $grade, $lastname, $firstname, $extension);
    } catch (Throwable $e) {
        return $photoPath;
    }

    if (@rename($absoluteSource, $target['absolute_path']) || @copy($absoluteSource, $target['absolute_path'])) {
        if (file_exists($absoluteSource) && $absoluteSource !== $target['absolute_path']) {
            @unlink($absoluteSource);
        }
        return $target['relative_path'];
    }

    return $photoPath;
}

function requirement_document_storage_settings(mysqli $conn): array
{
    return upload_storage_get($conn);
}

function requirement_document_base_dir(mysqli $conn): string
{
    $settings = requirement_document_storage_settings($conn);
    return upload_storage_normalize_dir((string) $settings['requirement_document_dir'], upload_storage_default_values()['requirement_document_dir']);
}

function requirement_document_max_bytes(mysqli $conn): int
{
    $settings = requirement_document_storage_settings($conn);
    return max(1, (int) $settings['requirement_document_max_mb']) * 1024 * 1024;
}

function requirement_document_absolute_path(mysqli $conn, ?string $relativePath): string
{
    $relativePath = upload_storage_relative_path((string) $relativePath);
    if ($relativePath === '') {
        return '';
    }

    return requirement_document_base_dir($conn) . '/' . $relativePath;
}

function requirement_document_public_url(int $documentId): string
{
    return '/school-admin-dashboard/modules/students/student-requirement-file.php?id=' . $documentId;
}
