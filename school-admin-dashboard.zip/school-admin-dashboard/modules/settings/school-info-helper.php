<?php
require_once __DIR__ . '/../../includes/schema-migration.php';
function ensure_school_information_table(mysqli $conn): void
{
    static $initialized = false;
    if ($initialized) {
        return;
    }

    if (!schema_migration_mode_enabled()) {
        $initialized = true;
        return;
    }

    $sql = "
    CREATE TABLE IF NOT EXISTS school_information (
        id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
        school_name VARCHAR(255) NOT NULL,
        school_short_name VARCHAR(120) DEFAULT NULL,
        owner_name VARCHAR(255) DEFAULT NULL,
        principal_name VARCHAR(255) DEFAULT NULL,
        registrar_name VARCHAR(255) DEFAULT NULL,
        cashier_name VARCHAR(255) DEFAULT NULL,
        address TEXT DEFAULT NULL,
        contact_number VARCHAR(80) DEFAULT NULL,
        email VARCHAR(255) DEFAULT NULL,
        mission TEXT DEFAULT NULL,
        vision TEXT DEFAULT NULL,
        core_values TEXT DEFAULT NULL,
        about_text TEXT DEFAULT NULL,
        receipt_footer_note TEXT DEFAULT NULL,
        logo_path VARCHAR(255) DEFAULT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ";
    schema_migration_attempt($conn, $sql);

    $check = $conn->query("SELECT COUNT(*) AS total FROM school_information");
    $total = $check ? (int) ($check->fetch_assoc()['total'] ?? 0) : 0;
    if ($total === 0) {
        $defaultName = "The Lord's Wisdom Academy Of Caloocan Inc.";
        $defaultLogo = '/school-admin-dashboard/uploads/logo1.png';
        $stmt = $conn->prepare("INSERT INTO school_information (school_name, logo_path) VALUES (?, ?)");
        $stmt->bind_param("ss", $defaultName, $defaultLogo);
        $stmt->execute();
        $stmt->close();
    }

    $initialized = true;
}

function get_school_information(mysqli $conn): array
{
    ensure_school_information_table($conn);

    $defaults = [
        'id' => 0,
        'school_name' => "The Lord's Wisdom Academy Of Caloocan Inc.",
        'school_short_name' => '',
        'owner_name' => '',
        'principal_name' => '',
        'registrar_name' => '',
        'cashier_name' => '',
        'address' => '',
        'contact_number' => '',
        'email' => '',
        'mission' => '',
        'vision' => '',
        'core_values' => '',
        'about_text' => '',
        'receipt_footer_note' => '',
        'logo_path' => '/school-admin-dashboard/uploads/logo1.png',
    ];

    $result = $conn->query("SELECT * FROM school_information ORDER BY id ASC LIMIT 1");
    if ($result && $row = $result->fetch_assoc()) {
        return array_merge($defaults, $row);
    }

    return $defaults;
}

function save_school_information(mysqli $conn, array $input): bool
{
    ensure_school_information_table($conn);

    $current = get_school_information($conn);
    $id = (int) ($current['id'] ?? 0);
    if ($id <= 0) {
        return false;
    }

    $fields = [
        'school_name',
        'school_short_name',
        'owner_name',
        'principal_name',
        'registrar_name',
        'cashier_name',
        'address',
        'contact_number',
        'email',
        'mission',
        'vision',
        'core_values',
        'about_text',
        'receipt_footer_note',
        'logo_path',
    ];

    $values = [];
    foreach ($fields as $field) {
        $value = trim((string) ($input[$field] ?? ''));
        if ($field === 'school_name' && $value === '') {
            $value = $current['school_name'] ?? "The Lord's Wisdom Academy Of Caloocan Inc.";
        }
        $values[$field] = $value;
    }

    $stmt = $conn->prepare("
        UPDATE school_information
        SET school_name = ?, school_short_name = ?, owner_name = ?, principal_name = ?, registrar_name = ?,
            cashier_name = ?, address = ?, contact_number = ?, email = ?, mission = ?, vision = ?,
            core_values = ?, about_text = ?, receipt_footer_note = ?, logo_path = ?
        WHERE id = ?
    ");
    if (!$stmt) {
        return false;
    }

    $stmt->bind_param(
        "sssssssssssssssi",
        $values['school_name'],
        $values['school_short_name'],
        $values['owner_name'],
        $values['principal_name'],
        $values['registrar_name'],
        $values['cashier_name'],
        $values['address'],
        $values['contact_number'],
        $values['email'],
        $values['mission'],
        $values['vision'],
        $values['core_values'],
        $values['about_text'],
        $values['receipt_footer_note'],
        $values['logo_path'],
        $id
    );

    $saved = $stmt->execute();
    $stmt->close();

    return $saved;
}

function school_info_display_name(array $schoolInfo): string
{
    $schoolName = trim((string) ($schoolInfo['school_name'] ?? ''));
    if ($schoolName !== '') {
        return $schoolName;
    }

    return "The Lord's Wisdom Academy Of Caloocan Inc.";
}

function school_info_logo_path(array $schoolInfo): string
{
    $logoPath = trim((string) ($schoolInfo['logo_path'] ?? ''));
    if ($logoPath !== '') {
        return $logoPath;
    }

    return '/school-admin-dashboard/uploads/logo1.png';
}

function school_info_logo_filesystem_path(array $schoolInfo): string
{
    $logoPath = school_info_logo_path($schoolInfo);
    $documentRoot = rtrim((string) ($_SERVER['DOCUMENT_ROOT'] ?? ''), '/\\');

    if ($documentRoot !== '' && str_starts_with($logoPath, '/')) {
        return $documentRoot . str_replace('/', DIRECTORY_SEPARATOR, $logoPath);
    }

    return $logoPath;
}

function school_info_contact_line(array $schoolInfo): string
{
    $parts = [];
    foreach (['address', 'contact_number', 'email'] as $field) {
        $value = trim((string) ($schoolInfo[$field] ?? ''));
        if ($value !== '') {
            $parts[] = $value;
        }
    }

    return implode(' | ', $parts);
}

function school_info_receipt_footer(array $schoolInfo): string
{
    $footer = trim((string) ($schoolInfo['receipt_footer_note'] ?? ''));
    if ($footer !== '') {
        return $footer;
    }

    return 'Thank you for your payment. Please keep this receipt for your records.';
}
